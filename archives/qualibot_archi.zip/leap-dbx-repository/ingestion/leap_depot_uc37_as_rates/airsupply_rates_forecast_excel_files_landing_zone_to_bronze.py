# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # AirSupply rates forecast excel files Landing Zone to Bronze 
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to transform lanzing zone table into bronze tables applying transformations that fix the excel format to make a more "rational" table.
# MAGIC
# MAGIC **bronze goals**
# MAGIC - fix column names to be the correct format for a df but conserving the excel files' logic 
# MAGIC - fill null values of first columns with correct categorization
# MAGIC - drop 'Black' rows
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC AS Rates Pipeline
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC   - {reference_read_env}_landingzone.leap_depot_uc37_as_rates.as_rates
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC N/A
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_bronze.leap_depot_uc37_as_rates.as_rates_bronze

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC     month year column headers are hard-coded, they should be dynamically generated based on the excel columns, in case the header date range is extended

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
import calendar

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common import logger

from leap_utils.common.validation import quality_checks

# Quality checks validation import
#from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# dbutils.widgets.text("reference_read_env", "dev")
# REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = logger.LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# log = logger.get_logger(module_name=__name__)
# logger.setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logger.logging.INFO)

# log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}") #excluded because extraction isn't from pipeline

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "airsupply_rates_forecast_project"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Used to specify which folder Input data is housed in
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ####Input Files Config
# MAGIC Definition of files to ingest

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables Location
# MAGIC
# MAGIC Details on how to read the input tables

# COMMAND ----------

t_landing_zone_as_rates = f"{PIPELINE_READ_ENV}_landingzone.leap_depot_uc37_as_rates.as_rates"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables Location

# COMMAND ----------

TABLE_DEST = f"{PIPELINE_WRITE_ENV}_bronze.leap_depot_uc37_as_rates.as_rates_bronze"

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# Read landing zone table
df_landing_zone_as_rates = spark.read.table(f"{t_landing_zone_as_rates}")
log.debug(display(df_landing_zone_as_rates))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# MAGIC %md
# MAGIC ### S3 files import from folder
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# MAGIC %md
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# MAGIC %md
# MAGIC #### generate_headers
# MAGIC Generate list of monthly headers with "total" column at the end of each year. The reason to keep "total" columns is to follow the bronze medallion logic and keep the data as raw as possible
# MAGIC
# MAGIC Parameters:
# MAGIC - start_year: 
# MAGIC - end_year: 
# MAGIC
# MAGIC Returns:
# MAGIC - list with strings that will be used as dataframe headers

# COMMAND ----------

# Generate a list of months in mmm-YY format and add TOTAL at the end of each year
def generate_headers(start_year, end_year):
    headers = []
    for year in range(start_year, end_year + 1): #loop through years range
        for month in range(1, 13): #loop through 12 months in a year
            month_abbr = calendar.month_abbr[month] #get "mmm" month abbreviated format
            headers.append(f"{month_abbr}_{str(year)[-2:]}") #get last two characters of the year and append to abbreviated month
        headers.append(f"total_{str(year)[-2:]}")   # add TOTAL header at the end of each year to match excel columns
        # turn all headers to lowercase
        headers = [header.lower() for header in headers] # turn to lower case
    return headers

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Change column names

# COMMAND ----------

# Custom initial and final headers
initial_headers = [
    "profit_center_name",
    "profit_center",
    "metric_category",
    "metric",
]

final_headers = [
    "path",
    "modification_time",
    "size",
    "ingestion_time",
]


# COMMAND ----------

# Generate monthly and year-total headers for the middle columns
generated_headers = generate_headers(2019, 2027)

# Replace the middle columns with the generated headers
new_column_names = initial_headers + generated_headers + final_headers 

# Validate header length
if len(new_column_names) != len(df_landing_zone_as_rates.columns):
    raise ValueError("New column names don't match excel column length")

# Create new DataFrame from old but with new column names
df_bronze = df_landing_zone_as_rates.toDF(*new_column_names)

# COMMAND ----------

log.debug(display(df_bronze))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Delete 'Black', ',' and 'STOP' rows

# COMMAND ----------

# Drop rows that contain the values "Black" or ","
df_bronze = df_bronze.filter((~f.col("profit_center_name").isin("Black", ",", "STOP")) | df_bronze.profit_center_name.isNull())

# COMMAND ----------

log.debug(display(df_bronze))

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

table_utils.save_table(
    TABLE_DEST,
    df_bronze,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
