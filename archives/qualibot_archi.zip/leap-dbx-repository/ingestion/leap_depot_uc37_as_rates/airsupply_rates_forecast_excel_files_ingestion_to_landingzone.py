# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # AirSupply rates forecast excel files ingestion to Landing Zone
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to ingest tables from S3 Bucket Excel AirSupply Rates forecast files triggered by file uploads
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC AS Rates Pipeline
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - file upload in S3 folder
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Input Excel Files in S3 bucket**
# MAGIC - s3://leap-s3-raw-weeu1-{pipeline_read_env}/manual/leapdepot/UC37_AS_RATES/*.xlsm
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC   - {pipeline_write_env}_landingzone.leap_depot_uc37_as_rates.as_rates
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC     # Find a way to get column names directly from excel from start
# MAGIC     # Handle error in case new files have new columns
# MAGIC         # Possibly new rows might cause errors as well, specially new metrics
# MAGIC     # Transformation should be done in bronze, but as of now it's not working for the LZ table imported in bronze (unknown reasons): deletes rows
# MAGIC     # A safety mechanism to make sure duplicated files aren't imported, since files in the s3 bucket can be duplicated

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import DataFrame as SparkDataFrame
import re
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = logger.LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# log = logger.get_logger(module_name=__name__)
# logger.setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logger.logging.INFO)

# log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}") #excluded because extraction isn't from pipeline

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "airsupply_rates_forecast_project"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files 

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Used to specify which folder Input data is housed in
# MAGIC

# COMMAND ----------


input_folder_path = (
    f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC37_AS_RATES//"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Input Files Config
# MAGIC Definition of files to ingest

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables Location

# COMMAND ----------

TABLE_DEST =  f"{PIPELINE_READ_ENV}_landingzone.leap_depot_uc37_as_rates.as_rates"

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

def excel_to_df(file_path: str) -> SparkDataFrame:

    # extract year and week from file path because it's related to target sheet name
    yewe_match = re.search(r"(\d{4})-w(\d{2})", file_path)
    year = int(yewe_match.group(1)) 
    week = int(yewe_match.group(2))
    
    df = (
        spark.read.format("com.crealytics.spark.excel")
        .option("inferSchema", "true")
        .option("header", "false")
        .option("dataAddress", "'S&OP synthesis'!B3:DR1000")
        .option("dateFormat", "yyyyMMdd")
        .load(file_path)
    )

    return df



def read_excels_and_join_dataframes(file_list):
    df_union = None
    for file_data in file_list:
        df = excel_to_df(file_data.path)
        df = df.withColumn("path", f.lit(file_data.path))
        df = df.withColumn("modificationTime", f.lit(file_data.modificationTime))
        df = df.withColumn("size", f.lit(file_data.size))
        df = df.withColumn("ingestion_time", f.lit(f.now()))
        if df_union is None:  # Check if df2 is not initialized
            df_union = df  # Initialize df2 with the first DataFrame
        else:
            df_union = df_union.union(df)  # Union with the existing df2
    return df_union

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# MAGIC %md
# MAGIC ### S3 files import from folder
# MAGIC

# COMMAND ----------

file_data = dbutils.fs.ls(input_folder_path)

df_raw = read_excels_and_join_dataframes(file_data)

log.debug(display(df_raw))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Fill null values with correct last not null values
# MAGIC Although not ideal to transform in landing zone, this transformation is not working in bronze (technical debt)

# COMMAND ----------

# Define a window specification to include all preceding rows
window_spec = Window.orderBy(f.lit(0)).rowsBetween(Window.unboundedPreceding, Window.currentRow)

# List of columns to forward fill
columns_to_fill = ["_c0", "_c2"]

# Apply forward fill for each column
for column in columns_to_fill:
    df_raw = df_raw.withColumn(
        column,  
        f.last(f.col(column), ignorenulls=True).over(window_spec)
    )




# COMMAND ----------

log.debug(display(df_raw))

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

table_utils.save_table(
    TABLE_DEST,
    df_raw,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
