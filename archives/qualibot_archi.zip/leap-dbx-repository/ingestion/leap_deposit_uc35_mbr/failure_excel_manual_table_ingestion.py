# Databricks notebook source
# MAGIC %md
# MAGIC # MBR Failure Manual Excel Tables Ingestion
# MAGIC
# MAGIC In the event of a failure during the ingestion of Excel files manually placed in LeapDepot, the affected files should be moved to a designated quarantine area in S3.
# MAGIC This ensures that subsequent ingestion runs can proceed without encountering the same errors, and that problematic files are preserved for further analysis or correction.

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

from databricks.sdk.runtime import dbutils
from leap_utils.common import logger

from leap_utils.ingestion import ingestion_utils

# COMMAND ----------

# MAGIC %md
# MAGIC # Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("pipeline_read_env", "uat")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Setup Logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "Budget amount ingestion"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC fix root logger

# COMMAND ----------

import logging

logging.getLogger().handlers.clear()

# COMMAND ----------

# MAGIC %md
# MAGIC # Constants

# COMMAND ----------

INGESTION_S3_BUCKET = f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/"

INGESTION_S3_FOLDER_PATH = "/manual/leapdepot/UC35_MBR/"

INGESTION_S3_BUCKET_PATH = f"{INGESTION_S3_BUCKET}/{INGESTION_S3_FOLDER_PATH}"

INGESTION_S3_BUCKET_QUARANTINE_PATH = (
    f"{INGESTION_S3_BUCKET}/quarantine/{INGESTION_S3_FOLDER_PATH}"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Read SAP FC excel files in LEAP depot S3 bucket

# COMMAND ----------

# MAGIC %md
# MAGIC ## Find files to put in quarantine

# COMMAND ----------

df_file_list = ingestion_utils.create_dbutils_ls_dataframe(INGESTION_S3_BUCKET_PATH)


if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_file_list.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Put files that failed the ingestion in the quarantine folder

# COMMAND ----------

for row in df_file_list.select("name").collect():
    filename = row["name"]
    dbutils.fs.mv(
        f"{INGESTION_S3_BUCKET_PATH}/{filename}",
        f"{INGESTION_S3_BUCKET_QUARANTINE_PATH}/{filename}",
    )
    log.info("Finished archiving file %s\n", filename)
