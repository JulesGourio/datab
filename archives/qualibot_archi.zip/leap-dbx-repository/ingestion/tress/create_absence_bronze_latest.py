# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC
# MAGIC Stack the two Tress absence bronze feeds into a single, deduplicated `v_leap_abscence_latest`.
# MAGIC
# MAGIC Mexico delivers two near-identical Airbyte views that differ only by the depth of history
# MAGIC they carry. The generic ingestion pipeline lands them in bronze under distinct names:
# MAGIC - `v_leap_abscence_init`  — the one-time **initial** bulk history (from `v_leap_abscence_history`)
# MAGIC - `v_leap_abscence_delta` — the ongoing **current** feed (from `v_leap_abscence`)
# MAGIC
# MAGIC This notebook UNIONs both and drops duplicates on the primary key, keeping the most recent
# MAGIC version, to reconstruct one continuous absence table. No SCD2 / history_change_log is built
# MAGIC (unlike `ingestion/immat/create_history_change_log_from_stack.py`, which this is modelled on) —
# MAGIC the output is a plain latest snapshot.
# MAGIC
# MAGIC **Input:**
# MAGIC - `{PIPELINE_READ_ENV}_bronze_hr.tress.v_leap_abscence_delta_latest`
# MAGIC - `{PIPELINE_READ_ENV}_bronze_hr.tress.v_leap_abscence_init_latest`
# MAGIC
# MAGIC **Output:**
# MAGIC - `{PIPELINE_WRITE_ENV}_bronze_hr.tress.v_leap_abscence_latest`
# MAGIC
# MAGIC **Dedup rule:**
# MAGIC - grain / primary key = `(idemployee, date_)`
# MAGIC - on collision, keep the row with the greatest `(_meta_extraction_timestamp,
# MAGIC   _meta_ingestion_timestamp)` — same DELTA rule as `get_latest_view_from_stack`.
# MAGIC
# MAGIC **How it is written:**
# MAGIC - full overwrite every run (both inputs are already 1-row-per-PK snapshots, so their union
# MAGIC   is the complete current state).
# MAGIC - schema/tags/comments are (re)applied only on (re)build (`do_init`: table missing or
# MAGIC   `force_reinitialization=true`) to avoid flooding the Delta history with no-op metadata
# MAGIC   commits — same convention as the immat changelog notebook.

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings / Config

# COMMAND ----------

# DBTITLE 1,Standard imports
import logging
import time

from pyspark.sql import functions as f
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# DBTITLE 1,Add bundle_root to sys.path (when run from an Asset Bundle)
import sys

dbutils.widgets.text("bundle_root", "")
bundle_root = dbutils.widgets.get("bundle_root")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

# COMMAND ----------

# DBTITLE 1,LEAP imports
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils

# COMMAND ----------

# DBTITLE 1,Widgets
# Read / write environments (dev / uat / prod)
dbutils.widgets.text("pipeline_read_env", "dev")
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# pilotage.yml — source of truth for the table/column tags & comments to mirror onto the
# stacked table (it keeps the same PII business columns as the delta/init feeds).
# Empty → tags/comments skipped.
dbutils.widgets.text("pilotage_yaml", "")
dbutils.widgets.text("reference_read_env", "dev")
PILOTAGE_YAML = dbutils.widgets.get("pilotage_yaml")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# force_reinitialization : wired in the job to {{job.parameters.full_refresh}} — a pipeline full
# refresh (delta/init rebuilt) also forces a schema-overwrite rebuild of the stacked table so its
# tags/comments are re-applied. Parsed case-insensitively.
dbutils.widgets.text("force_reinitialization", "false")
FORCE_REINITIALIZATION = dbutils.widgets.get("force_reinitialization").strip().lower() == "true"

dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# COMMAND ----------

# DBTITLE 1,Global variables & logger
SCHEMA = "tress"
READ_CATALOG = f"{PIPELINE_READ_ENV}_bronze_hr"
WRITE_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze_hr"

DELTA_TABLE = f"{READ_CATALOG}.{SCHEMA}.v_leap_abscence_delta_latest"  # current feed
INIT_TABLE = f"{READ_CATALOG}.{SCHEMA}.v_leap_abscence_init_latest"    # initial bulk history
DEST_TABLE = f"{WRITE_CATALOG}.{SCHEMA}.v_leap_abscence_latest"        # stacked output

# Grain / primary key of the stacked table and the ordering used to keep the latest row.
PK_COLS = ["idemployee", "date_"]
ORDER_COLS = ["_meta_extraction_timestamp", "_meta_ingestion_timestamp"]

# Liquid clustering on the employee id → co-locates all dates of an employee for reads.
CLUSTER_COLS = "idemployee"

# pilotage entry whose tags/comments are mirrored onto the stacked table (delta and init share the
# same columns, so either works).
PILOTAGE_TABLE_NAME = "v_leap_abscence_delta"

log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

log.info(f"DELTA_TABLE = {DELTA_TABLE}")
log.info(f"INIT_TABLE  = {INIT_TABLE}")
log.info(f"DEST_TABLE  = {DEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Main

# COMMAND ----------

start_time = time.time()


def _keep_valid(df):
    # Keep only rows that passed the ingestion validity check (don't pollute the output).
    if "_meta_validity_check" in df.columns:
        return df.filter(f.col("_meta_validity_check") == True)  # noqa: E712
    return df


# ---- Read both bronze feeds ----
df_delta = _keep_valid(spark.read.table(DELTA_TABLE))
df_init = _keep_valid(spark.read.table(INIT_TABLE))

# ---- Union (schemas are identical; allowMissingColumns guards against a late schema evolution
#      on one feed only) then drop duplicates on the PK keeping the most recent version. ----
df_union = df_delta.unionByName(df_init, allowMissingColumns=True)
df_stacked = table_utils.drop_duplicates_by_order(
    df=df_union,
    columns=PK_COLS,
    order_col=ORDER_COLS,
    keep="last",
)

# COMMAND ----------

# DBTITLE 1,Save
# Full overwrite every run (union of two 1-row-per-PK snapshots = complete current state).
#   - (re)build (do_init: table missing or force_reinitialization) → overwriteSchema=True.
#   - normal run → overwriteSchema=False so the UC tags/comments set at (re)build survive the
#     data-only overwrite (no metadata churn in the Delta history).
#   save_table also updates the freshness pilot table ({env}_bronze_hr.data_quality.*).
table_exists = table_utils.UnityCatalogCheckTableExists(DEST_TABLE)
do_init = FORCE_REINITIALIZATION or not table_exists
OVERWRITE_SCHEMA = do_init

try:
    table_utils.save_table(
        dest_table=DEST_TABLE,
        df=df_stacked,
        mode="overwrite",
        overwrite_schema=OVERWRITE_SCHEMA,
        cluster_cols=CLUSTER_COLS,
    )
except AnalysisException:
    log.error(f"Table {DEST_TABLE} could not be created.")
    raise

duration = time.time() - start_time
log.info(f"Table {DEST_TABLE} written in {duration:.1f}s.")

# COMMAND ----------

# DBTITLE 1,Apply the same UC tags, comments & PK as the pilotage tables (delta / init)
# The stacked table keeps the full schema (incl. the PII business columns), so it carries the SAME
# table/column tags & comments as the delta/init feeds — essential so ABAC PII masking applies here
# too. Its grain IS the primary key (idemployee, date_), so PK tags are applied as well.
#
# Applied ONLY on (re)build (do_init): each ALTER ... SET TAGS / COMMENT is a separate Delta commit.
# Tags/comments are static (from pilotage) and survive a data-only overwrite, so we set them once
# when overwriteSchema rebuilt the metadata; normal runs skip the block → zero metadata churn.
if PILOTAGE_YAML and do_init:
    from leap_utils.ingestion.ingestion_declarative_pipeline import load_pilotage_from_yaml

    _attrs_dict = load_pilotage_from_yaml(
        yaml_path=PILOTAGE_YAML,
        reference_read_env=REFERENCE_READ_ENV,
        pipeline_write_env=PIPELINE_WRITE_ENV,
    )
    _attrs = next(
        (v for v in _attrs_dict.values() if v.get("table_name") == PILOTAGE_TABLE_NAME), None
    )
    if _attrs is None:
        log.warning(f"No '{PILOTAGE_TABLE_NAME}' entry in pilotage.yml — tags/comments skipped.")
    else:
        _existing = set(spark.table(DEST_TABLE).columns)

        # --- tags (same as delta/init) ---
        table_utils.apply_table_tags_uc(
            full_table_name=DEST_TABLE,
            table_tags=_attrs.get("table_tags") or {},
            dry_run=False,
        )
        _col_tags = {c: t for c, t in (_attrs.get("column_tags") or {}).items() if c in _existing}
        table_utils.apply_column_tags_uc(
            full_table_name=DEST_TABLE, column_tags=_col_tags, dry_run=False
        )

        # --- PK tags (grain of the stacked table == primary_key) ---
        _pk = [c for c in (_attrs.get("primary_key") or PK_COLS) if c in _existing]
        table_utils.apply_pk_fk_tags_uc(
            full_table_name=DEST_TABLE,
            primary_key=_pk,
            foreign_keys=_attrs.get("foreign_keys") or [],
            dry_run=False,
        )

        # --- comments (same as delta/init) ---
        _table_comment = _attrs.get("table_comment") or ""
        if _table_comment:
            spark.sql(
                f"COMMENT ON TABLE {DEST_TABLE} IS '{_table_comment.replace(chr(39), chr(39) * 2)}'"
            )
        for _c, _cmt in (_attrs.get("column_comments") or {}).items():
            if _cmt and _c in _existing:
                spark.sql(
                    f"ALTER TABLE {DEST_TABLE} ALTER COLUMN {_c} "
                    f"COMMENT '{_cmt.replace(chr(39), chr(39) * 2)}'"
                )
        log.info("Applied UC tags, comments & PK on the stacked table.")
elif not PILOTAGE_YAML:
    log.warning("pilotage_yaml not provided — tags/comments skipped on the stacked table.")
else:
    log.info(
        "Normal run — tags/comments already set at last (re)build, skipping to avoid Delta "
        "metadata churn."
    )

dbutils.notebook.exit(f"ok:{DEST_TABLE}")
