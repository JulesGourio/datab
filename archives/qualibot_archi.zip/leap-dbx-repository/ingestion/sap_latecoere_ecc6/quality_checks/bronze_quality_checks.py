# Databricks notebook source
# MAGIC %md
# MAGIC # Quality checks on bronze SAP tables
# MAGIC
# MAGIC 1. Retrieve historical DataFrame from Unity Catalog
# MAGIC 2. Build statistics and analysis on :
# MAGIC     - **Data uniqueness:**: the presence of duplicated data (check only done the sunday)
# MAGIC     - **Data completeness:**: detection of partial ingestion or weird ingestion
# MAGIC     - **Data increase:** detection of data increase

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Package Imports

# COMMAND ----------

import datetime

import great_expectations as gx
from pyspark.sql import functions as f

from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger
from leap_utils.common.validation import gx_validation, quality_checks

from ingestion.sap_latecoere_ecc6.sap_ingestion.common import (
    input_file_path_parser,
    determine_ingestion_mode,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - **READ_ENV** -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - **LOG_LEVEL** -> Used for specifying what log level is defined inside the notebook
# MAGIC - **TABLES** -> Used for specifying table inputs
# MAGIC - **INPUT_FILE** -> In case of on demand table SAP extraction, should use the INPUT_FILE to retrieve the table name

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("read_env", "dev")
READ_ENV = dbutils.widgets.get("read_env")

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

dbutils.widgets.text("input_file", "")
INPUT_FILE = dbutils.widgets.get("input_file").replace(" ", "")

dbutils.widgets.text("tables", "")
TABLES_LIST = (
    None
    if dbutils.widgets.get("tables") == ""
    else dbutils.widgets.get("tables").upper().replace(" ", "").split(",")
)

ingestion_mode = determine_ingestion_mode()
if ingestion_mode == "TABLES":
    INPUT_TABLES_LIST = [
        f"{READ_ENV}_landingzone.sap_latecoere_ecc6.{table_name.lower()}_stack"
        for table_name in TABLES_LIST
    ]
else:
    _, _, _, table_name, _, _ = input_file_path_parser(INPUT_FILE)
    INPUT_TABLES_LIST = [
        f"{READ_ENV}_landingzone.sap_latecoere_ecc6.{table_name.lower()}_stack"
    ]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transform inputs in order to get it by check typology and log level warning for filling this dictionary
# MAGIC ```json
# MAGIC {
# MAGIC     "completeness": {
# MAGIC       "red": [],
# MAGIC       "amber": []
# MAGIC     },
# MAGIC     "increase": {
# MAGIC       "red": [],
# MAGIC       "amber": []
# MAGIC     }
# MAGIC }
# MAGIC ```

# COMMAND ----------

inputs_to_check_dict = {}

inputs_to_check_dict["completeness"] = {"red": [], "amber": INPUT_TABLES_LIST}
inputs_to_check_dict["increase"] = {"red": [], "amber": INPUT_TABLES_LIST}

log.debug(f"Completeness checks are done on : {inputs_to_check_dict['completeness']}")
log.debug(f"Increase checks are done on : {inputs_to_check_dict['increase']}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Common Functions

# COMMAND ----------


def calculate_id_unicity_on_last_extracted_table(
    table_path: str,
) -> gx.core.ExpectationSuiteValidationResult:
    """
    Calculate the SAP ID unicity on the last table extracted, in filtering the
    last extraction_timestamp

    :param table_path: Unity catalog path of the table
    :type table_path: str
    :return: Validation results done by great expectation.
    :rtype: gx.core.ExpectationSuiteValidationResult
    """
    df_stack_bronze = spark.read.table(table_path)

    max_timestamp = df_stack_bronze.agg(f.max("extraction_timestamp")).first()[0]
    df_last_version = df_stack_bronze.where(
        f.col("extraction_timestamp") == max_timestamp
    )

    dfgx_last_version = gx.dataset.SparkDFDataset(df_last_version, persist=False)
    unicity_results = dfgx_last_version.expect_column_values_to_be_unique(
        "ID", meta={"table_path": table_path}
    )

    return unicity_results


# COMMAND ----------

# MAGIC %md
# MAGIC # Compute bronze stack tables completeness & increase
# MAGIC ### For each table:
# MAGIC
# MAGIC   1. Retrieve nb rows appended per day on stack tables on the last 30 logs of the table history
# MAGIC   2. Detect outliers with IQR method or STD method
# MAGIC   3. Detect tables increase
# MAGIC
# MAGIC $$iqr : outlier \geq threshold*\lvert\frac{value - median}{iqr_{3} - iqr_{1}}\lvert$$
# MAGIC
# MAGIC $$z_{score} : outlier \geq threshold*\lvert\frac{value - mean}{std}\lvert$$
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Compute the number of rows evolution by extraction timestamp
# MAGIC - Used for completeness and increase checks, as is it's done just once

# COMMAND ----------

all_tables_to_get_agg = set(
    inputs_to_check_dict["completeness"]["red"]
    + inputs_to_check_dict["completeness"]["amber"]
    + inputs_to_check_dict["increase"]["red"]
    + inputs_to_check_dict["increase"]["amber"]
)

tables_aggregated_dictionary = (
    quality_checks.get_tables_nb_rows_evolution_by_extraction_timestamp(
        all_tables_to_get_agg,
        history_limit=50,
        filter_condition=None,
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Validate or log a warning if some tables are incomplete
# MAGIC **Info**: The check is done on the last update of the stack tables not on the history

# COMMAND ----------

verbose = LOG_LEVEL == "debug"

if INPUT_TABLES_LIST:
    env = INPUT_TABLES_LIST[0].split(".")[0].split("_")[0]
else:
    env = None

for validation_level in ["red", "amber"]:

    inputs_to_check_completeness = inputs_to_check_dict["completeness"][
        validation_level
    ]
    if inputs_to_check_completeness:
        results_completeness = quality_checks.check_tables_completeness(
            inputs_to_check_completeness,
            tables_aggregated_dictionary,
            verbose=verbose,
            outlier_method="IQR",
            threshold=1.5,
            check_upper_bound=False,
        )
        quality_checks.validate_and_log_quality_check_results(
            results_dict=results_completeness,
            validation_level=validation_level.upper(),
            info_message=f"All tables with {validation_level} validation are complete",
            error_message="Tables are not all complete, check the summary of this run",
            pipeline_write_env=env,
            expectation_type="check_tables_completeness",
            log_to_event_table=True,
            log_successes=True,
        )


# COMMAND ----------

# MAGIC %md
# MAGIC # Validate or log a warning if some tables expected to increase and are not increasing
# MAGIC **Info**: The check is done on the last update of the stack tables not on the history

# COMMAND ----------

verbose = LOG_LEVEL == "debug"

for validation_level in ["red", "amber"]:

    inputs_to_check_increase = inputs_to_check_dict["increase"][validation_level]
    if inputs_to_check_increase:
        results_increase = quality_checks.check_tables_increase(
            inputs_to_check_increase,
            tables_aggregated_dictionary,
            verbose=verbose,
        )
        quality_checks.validate_and_log_quality_check_results(
            results_dict=results_increase,
            validation_level=validation_level.upper(),
            info_message=f"All tables with {validation_level} validation are increasing",
            error_message="Tables are not all increasing, check the summary of this run",
        )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check tables unicity
# MAGIC Run this test only on Sundays, by construction there cannot be duplicates when exporting SAP

# COMMAND ----------

week_day = datetime.datetime.now().weekday()

if week_day == 6:
    red_quality_check_results = [
        calculate_id_unicity_on_last_extracted_table(table_path)
        for table_path in INPUT_TABLES_LIST
    ]

    gx_validation.validate_and_log_gx_results(
        quality_check_results=red_quality_check_results,
        validation_level="RED",
        info_message="All tables have a unique ID on the last extraction_timestamp",
        error_message="At least one table has a duplicated ID on the last extraction_timestamp",
        pipeline_write_env=env,
        table_name="sap_latecoere_ecc6",
        log_to_event_table=True,
        log_successes=True,
    )
else:
    log.debug("No ID unicity checks are done because the week day is not sunday")
