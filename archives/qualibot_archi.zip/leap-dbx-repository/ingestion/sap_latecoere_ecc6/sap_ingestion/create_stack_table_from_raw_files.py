# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC
# MAGIC - The purpose of this notebook is to stack all files from a specific source in an S3 bucket into a single table using the "COPY INTO" (Databricks) -> https://docs.databricks.com/sql/language-manual/delta-copy-into.html
# MAGIC - We will use different options and parameters for the "COPY INTO" command and utilizes Python functions to simplify query execution and debugging.
# MAGIC
# MAGIC **Usage**
# MAGIC This job do mainly 2 tasks :
# MAGIC 1. Extract info from the file_name for retrieving from it
# MAGIC   - `table_name`: Name of the table
# MAGIC   - `file_mode`: Mode of extraction : Full or Delta
# MAGIC   - `folder_path`: Folder path inside the S3 bucket
# MAGIC   - `batch_id`: Talend Batch id of the file
# MAGIC 2. Append new files to a global stack table : each files are appended inside one global table enabling to retrieve specific snapshots. Use of COPY INTO statement with following options :
# MAGIC   - `File Format` : PARQUET
# MAGIC   - `Pattern of files to ingest` : *SAP-{table_name}-*
# MAGIC   - `Columns to select`: All columns of the file + ID + extraction_timestamp + ingestion_timestamp + file_name + file_mode + table_name + file_modification_time
# MAGIC   - `Force`: Whether to reinitialize the data or not
# MAGIC   - `Format options`: For specifying some options , ex:  HEADER='true'
# MAGIC Additionaly.
# MAGIC - A logger enables to log the good update of the table
# MAGIC - Some values are stored in taskValues instance for retrieving it in following notebooks of the workflow
# MAGIC
# MAGIC **Input :**
# MAGIC -  `input_file = s3://leap-s3-raw-weeu1-{reference_read_env}/erp/sap_latecoere_ecc6/tables/{table_name}/active/{filename}`    or    `tables = {table_name1},{table_name2},{table_name3},{table_name4}`
# MAGIC -  `meta_input_file = s3://leap-s3-raw-weeu1-{reference_read_env}/erp/sap_latecoere_ecc6/tables/{table_name}/meta/{filename}`
# MAGIC
# MAGIC **Output :**
# MAGIC - `{pipeline_write_env}_landingzone.sap.{table_name}`
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - AWS lambda listening to file arrivals on SAP S3 bucket (file ending by .end)
# MAGIC
# MAGIC  **TO DO:**
# MAGIC

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
import logging
import time
from datetime import datetime
from typing import Tuple

from dateutil.relativedelta import relativedelta
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# DBTITLE 1,Config LEAP Functions Imports
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils

# COMMAND ----------

# DBTITLE 1,Widgets definition
dbutils.widgets.removeAll()

# Get pipeline write environment variable for output tables (dev / uat / prod)
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Get reference read environment variable for output tables (dev / uat / prod)
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Get pipeline read environment variable for input tables (dev / uat / prod)
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Get input_file variable , input file is an "*_end.end" file that trigger ingestion for a specific table
# input_file is generally provided from lambda, with this format :  s3://leap-s3-raw-weeu1-{ENV}/erp/sap_latecoere_ecc6/tables/{table_name}/active/{filename}_end.end
# example:  s3://leap-s3-raw-weeu1-prod/erp/sap_latecoere_ecc6/tables/COSP/active/20230915_033031_SAP-COSP-DD~4~TIMSTP-01_5166871_end.end
dbutils.widgets.text("input_file", "")
INPUT_FILE = dbutils.widgets.get("input_file").replace(" ", "")

# If force_reinitialization == True then the stack table will be reinitialized
dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = eval(dbutils.widgets.get("force_reinitialization"))

# Get tables variable (List of tables to ingest, comma separated. Table will be catch from input_file if variable tables is empty.)
# tables can be provided by lambda or manually
# ex: AUFK,AFPO,COSS
dbutils.widgets.text("tables", "")
# If 'tables' widget is not null then ignore INPUT_FILE and process tables in 'tables'
TABLES_TO_INGEST = (
    None
    if dbutils.widgets.get("tables") == ""
    else dbutils.widgets.get("tables").upper().replace(" ", "").split(",")
)

# Get COPY INTO modifiedAfter variable (timestamp)
# Example of modifiedAfter value :   2023-12-18 14:32:23.738862 UTC+1
dbutils.widgets.text("modifiedAfter", "")

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# COMMAND ----------

# DBTITLE 1,Config Pipeline Common Functions Imports
from ingestion.sap_latecoere_ecc6.sap_ingestion.common import (
    FILE_HEADER_PATH,
    extract_information_from_header_file,
    get_table_task_parameters,
    input_file_path_parser,
    determine_ingestion_mode,
)

# COMMAND ----------

# DBTITLE 1,Global variables & logger
# From widgets
TABLES_FOLDER_PATH = (
    f"s3://leap-s3-raw-weeu1-{REFERENCE_READ_ENV}/erp/sap_latecoere_ecc6/tables"
)

STACK_CATALOG = f"{PIPELINE_WRITE_ENV}_landingzone"
STACK_DOMAIN = "sap_latecoere_ecc6"

STACK_VIEW_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze"

log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

TABLE_STACK_FIRST_COLS = {
    "stack_row_id": "BIGINT GENERATED ALWAYS AS IDENTITY COMMENT 'STACK UNIQUE ID GENERATED ALWAYS AS IDENTITY'",
    "ID": "STRING",
    "extraction_timestamp": "TIMESTAMP",
    "ingestion_timestamp": "TIMESTAMP",
    "file_name": "STRING",
    "file_mode": "STRING",
    "table_name": "STRING",
    "file_modification_time": "TIMESTAMP",
}

TABLE_STACK_PK_COLS = "ID, extraction_timestamp"
TABLE_STACK_PARTITION_COL = "extraction_timestamp"

# COMMAND ----------

# DBTITLE 1,Functions definition


def query_copy_into(
    table_path: str,
    folder_path: str,
    select_string: str,
    file_format: str,
    pattern: str,
    format_options: str,
    copy_options: str,
) -> str:
    """
    Create query statement for COPY INTO given different arguments : https://docs.databricks.com/en/sql/language-manual/delta-copy-into.html

    :param table_path: Unity catalog path of the table to update
    :type table_path: str
    :param folder_path: S3 Folder path where files are stored
    :type folder_path: str
    :param select_string: Selects the specified columns or expressions from the source data before copying into the Delta table
    :type select_string: str
    :param file_format: The format of the source files to load.
    :type file_format: str
    :param pattern: A glob pattern that identifies the files to load from the source directory
    :type pattern: str
    :param format_options: Options to be passed to the Apache Spark data source reader for the specified format
    :type format_options: str
    :param copy_options: Options to control the operation of the COPY INTO command.
    :type copy_options: str

    :return: Return SQL Statement for copy into
    :return type: str
    """
    return f"""COPY INTO {table_path} FROM ( SELECT {select_string} FROM {folder_path} )
               FILEFORMAT = {file_format.upper()}
               PATTERN = {pattern}
               FORMAT_OPTIONS({format_options})
               COPY_OPTIONS({copy_options})
               """


def create_copy_into_select_string(schema, table_keys) -> str:
    """
    Generate a sql select string like "
        concat_ws('-', MANDT, AUFNR) AS ID,
        to_timestamp(concat(split_part(_metadata.file_name, '_', 1), split_part(_metadata.file_name, '_', 2)), 'yyyyMMddHHmmss') as extraction_timestamp,
        current_timestamp() as ingestion_timestamp,
        _metadata.file_name as file_name,
        CASE WHEN split_part(split_part(_metadata.file_name, '_', 3), '-', 3) = 'F' THEN 'FULL' ELSE 'DELTA' END as file_mode,
        split_part(split_part(_metadata.file_name, '_', 3), '-', 2) as table_name,
        _metadata.file_modification_time as file_modification_time,
        MANDT as {mandt}, AUFNR as {aufnr}, ...,  "

    Parameters:
    - schema (e.g. ["mandt", "aufnr", "gltrp", "gstrp", ...]) : type List
    - table_keys : type List
    """

    # List the table columns in schema
    columns = [column for column in schema]
    # table_columns = ", ".join(column for column in schema)
    table_columns = ", ".join(
        f"IF(coalesce({column},'')='', NULL, {column}) as {column}" for column in schema
    )

    # Generate "ID" field by joining 'table_keys' columns with '-'.
    # sql_id_generator = f"concat_ws('-', {','.join(table_keys)}) AS ID"
    id_columns = ", ".join(
        f"IF(coalesce({column},'')='', NULL, {column})" for column in table_keys
    )
    sql_id_generator = f"concat_ws('-', {id_columns}) AS ID"

    # Generate metadata table columns
    metadata_columns = ", to_timestamp(concat(split_part(_metadata.file_name, '_', 1), split_part(_metadata.file_name, '_', 2)), 'yyyyMMddHHmmss') as extraction_timestamp, current_timestamp() as ingestion_timestamp, _metadata.file_name as file_name, CASE WHEN split_part(split_part(_metadata.file_name, '_', 3), '-', 3) = 'F' THEN 'FULL' ELSE 'DELTA' END as file_mode, split_part(split_part(_metadata.file_name, '_', 3), '-', 2) as table_name, _metadata.file_modification_time as file_modification_time, "

    # Generate sql select string as : ID + metadata columns + data columns
    copy_into_columns = sql_id_generator + metadata_columns + table_columns

    return copy_into_columns


def get_relative_timestamp_from_now(nbdays: int) -> str:
    """
    return timestamp nbdays before now
    """
    today = datetime.now()
    nbJoursGlissants = today + relativedelta(days=-nbdays)

    format = "%Y-%m-%d %H:%M:%S.%f UTC+0"
    relative_timestamp = nbJoursGlissants.strftime(format)
    return relative_timestamp


def process_single_table(
    table_name: str, df_header: SparkDataFrame, existing_tables: str, folder_path: str
) -> Tuple[str, int]:
    """
    process ingestion of a single table
    return Tuple[str, str] with
        {output_table_path} if ok, or None if not
        {numrows} ingested, or None if not ok
    """
    global MODIFIED_AFTER
    global FORCE_REINITIALIZATION
    global PIPELINE_WRITE_ENV

    log.debug("---------------------------------")
    log.debug(f"Process single table : {table_name}")
    if table_name in existing_tables:
        startTime = time.time()

        (
            sap_schema_ordered_list,
            column_uid_list,
        ) = extract_information_from_header_file(
            df_header=df_header, sap_table_name=table_name
        )
        log.debug(f"Column names are : {sap_schema_ordered_list}")
        log.debug(f"UID key is : {column_uid_list}")

        unity_catalog_table_name = f"{table_name.lower().replace('-', '_')}_stack"
        output_table_path = f"{STACK_CATALOG}.{STACK_DOMAIN}.{unity_catalog_table_name}"
        view_table_path = (
            f"{STACK_VIEW_CATALOG}.{STACK_DOMAIN}.{unity_catalog_table_name}"
        )

        log.debug(f"output_table_path:  {output_table_path}")

        # ------------------------------ STORE ------------------------------
        # Create unity catalog table if it does not exist, or reinitialize table if param set to True
        try:
            table_utils.create_unity_catalog_table(
                catalog=STACK_CATALOG,
                domain=STACK_DOMAIN,
                table=unity_catalog_table_name,
                force_reinitialization=FORCE_REINITIALIZATION,
                cluster_cols=None,
                partition_col=TABLE_STACK_PARTITION_COL,
                primary_key_cols=TABLE_STACK_PK_COLS,
                columns=TABLE_STACK_FIRST_COLS,
                force_drop=False,
            )
        except AnalysisException as e:
            log.error(
                f"Table {output_table_path} has not been created, an error occured during creation.\nException is :{e}\n"
            )
            raise Exception()

        # ------------------------------ TABLE FORMATTING ------------------------------
        format_options = f"'HEADER' = 'true' , 'modifiedAfter' = '{MODIFIED_AFTER}'"  ## escape== '\"' "  because -> new files have "

        copy_options = (
            f"'FORCE' = '{str(FORCE_REINITIALIZATION).lower()}', 'MERGESCHEMA' = 'true'"
        )

        # columns for COPY INTO : ID + metadata columns + columns
        selected_schema_query = create_copy_into_select_string(
            sap_schema_ordered_list, column_uid_list
        )

        # Get the query of copy into: copyInto table from (select selected_schema_query and metadataColumns) from PATH_FOLDER (using pattern ) and we will add format_options & copy_options
        copy_into_query = query_copy_into(
            table_path=output_table_path,
            folder_path=folder_path,
            select_string=selected_schema_query,
            file_format="PARQUET",
            pattern=f"'*SAP-{table_name}-*.parquet'",
            format_options=format_options,
            copy_options=copy_options,
        )

        log.info(f"About to COPY INTO to the table {output_table_path}.")
        log.debug(f"COPY INTO query :  {copy_into_query}")

        # Apply the copy into query using spark sql
        try:
            copy_into_query_run = spark.sql(copy_into_query)
            duration = time.time() - startTime
            nbrows = int(copy_into_query_run.first()["num_inserted_rows"])

            if nbrows == 0:
                log.warning(
                    f"No rows have been ingested from {folder_path} to {output_table_path} in {duration} seconds."
                )
            else:
                log.info(
                    f"""Copied {nbrows} rows from {folder_path} to {output_table_path} in {duration} seconds."""
                )
            log.info(f"Table {output_table_path} has been successfully updated")

            # Create the table view in bronze
            table_utils.create_table_view(
                src_full_tablename=output_table_path,
                dest_full_tablename=view_table_path,
                select_statement="*",
                replace_view=True,
            )
        except AnalysisException as e:
            log.critical(
                f"Table {output_table_path} has not been updated, an error occured.\n SQL query is : \n{copy_into_query}, error is : {e}\n error is : \n{e}"
            )
            return None
        else:
            return output_table_path
    else:
        log.error(f"Table {table_name} is not in HEADER.")
        return None


# COMMAND ----------

# DBTITLE 1,Check modifiedAfter
# modifiedAfter will be 30days before now by default if not provided , the format is '2022-10-22 16:14:48.738862 UTC+0'
nb_days_ago_timestamp = get_relative_timestamp_from_now(30)
MODIFIED_AFTER = (
    nb_days_ago_timestamp
    if dbutils.widgets.get("modifiedAfter") == ""
    else dbutils.widgets.get("modifiedAfter")
)

log.debug(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.debug(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.debug(f"INPUT_FILE is:  {INPUT_FILE}")
log.debug(f"MODIFIED_AFTER is:  {MODIFIED_AFTER}")
log.debug(f"FORCE_REINITIALIZATION is:  {FORCE_REINITIALIZATION}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Main

# COMMAND ----------

if __name__ == "__main__":
    # ------------------------------ PARSE ------------------------------
    # Retrieve tables from the "Pilotage table" to convert column name

    ingestion_mode = determine_ingestion_mode()
    log.debug(f"Ingestion mode is : {ingestion_mode}")

    df_header = spark.read.options(header="True", delimiter=";").csv(FILE_HEADER_PATH)

    existing_tables = list(
        df_header.select("query_table").drop_duplicates().toPandas()["query_table"]
    )
    log.debug(f"Existing_tables: {existing_tables}")

    table_output_list = []
    table_error_list = []
    table_history_list = []
    do_history_change_log_task = False
    do_specific_task = False
    do_manual_task = False
    jour = datetime.now().weekday()

    # set task variable skip_run_metajob to False
    dbutils.jobs.taskValues.set("skip_run_metajob", False)

    # On Sunday do optimize task
    if jour == 6:
        do_optimize_task = True
    else:
        do_optimize_task = False
    specific_task_variables_defined = set()

    # Wether to work in "TABLE" mode or in "FILE" mode
    is_error_detected = False
    if ingestion_mode == "TABLES":
        for table_name in TABLES_TO_INGEST:
            # Check if history needed , if specific tasks needed, for this table
            task_dict = get_table_task_parameters(table_name)

            folder_path = f"'{TABLES_FOLDER_PATH}/{table_name}/active/'"
            log.debug(f"table_name is: {table_name}")
            output_table_path = process_single_table(
                table_name, df_header, existing_tables, folder_path
            )
            if output_table_path is not None:
                if task_dict["do_specific_task"]:
                    # Specific process will be done for this table when not manual
                    do_specific_task = True

                    # Force specific task variable to true for this table
                    specific_task_to_add = f"do_specific_task_{table_name}"
                    dbutils.jobs.taskValues.set(key=specific_task_to_add, value=True)
                    specific_task_variables_defined.add(specific_task_to_add)

                    # Set others tasks variables
                    for key, value in task_dict.items():
                        if key not in specific_task_variables_defined:
                            dbutils.jobs.taskValues.set(key=f"{key}", value=value)
                else:
                    # Normal process, append table to list for "latest" processing
                    dict_to_append = {
                        "output_table_path": output_table_path,
                        "table_name": table_name,
                    }
                    table_output_list.append(dict_to_append)

                    # history processing
                    if task_dict["do_history_change_log"]:
                        do_history_change_log_task = True
                        dict_to_append = {
                            "output_table_path": output_table_path,
                            "table_name": table_name,
                        }
                        table_history_list.append(dict_to_append)

            else:
                log.error(f"Error detected for {table_name}")
                table_error_list.append(table_name)
                is_error_detected = True

    elif ingestion_mode == "INPUT_FILE":
        # Parse input_file and retrieve corresponding info
        (
            file_name,
            folder_path,
            batch_id,
            table_name,
            file_mode,
            table_subelement,
        ) = input_file_path_parser(input_file=INPUT_FILE)
        log.debug(f"table_name is: {table_name}")
        log.debug(f"file_name is: {file_name}")
        log.debug(f"file_mode is: {file_mode}")

        if table_subelement == "ONDEMAND":
            do_manual_task = True

        # Check if history needed , if specific tasks needed, for this table
        task_dict = get_table_task_parameters(table_name)

        output_table_path = process_single_table(
            table_name, df_header, existing_tables, folder_path
        )
        if output_table_path is not None:
            if task_dict["do_specific_task"]:
                # Specific process will be done for this table when not manual
                do_specific_task = True

                # Force specific task variable to true for this table
                specific_task_to_add = f"do_specific_task_{table_name}"
                dbutils.jobs.taskValues.set(key=specific_task_to_add, value=True)
                specific_task_variables_defined.add(specific_task_to_add)

                # Set others tasks variables
                for key, value in task_dict.items():
                    if key not in specific_task_variables_defined:
                        dbutils.jobs.taskValues.set(key=f"{key}", value=value)
            else:
                # Normal process, append table to list for "latest" processing
                dict_to_append = {
                    "output_table_path": output_table_path,
                    "table_name": table_name,
                }
                table_output_list.append(dict_to_append)

                # history processing
                if task_dict["do_history_change_log"]:
                    do_history_change_log_task = True
                    dict_to_append = {
                        "output_table_path": output_table_path,
                        "table_name": table_name,
                    }
                    table_history_list.append(dict_to_append)
        else:
            log.error(f"Error detected for {table_name}")
            table_error_list.append(table_name)
            is_error_detected = True
    else:
        log.error("No Parameter provided.")
        raise Exception()

# COMMAND ----------

# DBTITLE 1,Set task values
# Set task values for retrieving it in other notebooks of the workflow
dbutils.jobs.taskValues.set(key="table_output_list", value=table_output_list)
dbutils.jobs.taskValues.set(
    key="do_history_change_log_task", value=do_history_change_log_task
)
dbutils.jobs.taskValues.set(key="table_history_list", value=table_history_list)
dbutils.jobs.taskValues.set(key="do_specific_task", value=do_specific_task)
dbutils.jobs.taskValues.set(key="do_manual_task", value=do_manual_task)
dbutils.jobs.taskValues.set(key="do_optimize_task", value=do_optimize_task)

log.info(
    f"table_output_list = {table_output_list} , table_history_list = {table_history_list}, do_history_change_log_task = {do_history_change_log_task}, do_specific_task = {do_specific_task}, do_manual_task = {do_manual_task}, do_optimize_task = {do_optimize_task}"
)

# COMMAND ----------

# DBTITLE 1,Raise error if detected
if is_error_detected:
    log.critical(
        f"An error has been detected for at least one table(s) in : {table_error_list} see above !"
    )
    raise Exception()
