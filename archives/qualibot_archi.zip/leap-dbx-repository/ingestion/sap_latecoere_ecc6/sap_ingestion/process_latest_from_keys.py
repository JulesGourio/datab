# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to process the latest table and delete each ID not present in the keys_latest table
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - latest
# MAGIC
# MAGIC **Input :**
# MAGIC - xxx_latest
# MAGIC - xxxkeys_latest
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - ingestion pipeline
# MAGIC
# MAGIC
# MAGIC **Things to do:**
# MAGIC - Retrouver les infos depuis les fichiers meta plutôt que l'en tête file

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
import logging
import time

import pyspark.sql.functions as f
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.utils import AnalysisException
from typing import List

# COMMAND ----------

# DBTITLE 1,Config LEAP Functions Imports
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils

# COMMAND ----------

# DBTITLE 1,Widgets definition
# Get pipeline write environment variable for output tables (dev / uat / prod)
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# COMMAND ----------

# DBTITLE 1,Config Pipeline Common Functions Imports
from ingestion.sap_latecoere_ecc6.sap_ingestion.common import (
    FILE_HEADER_PATH,
    THE_ORIGIN,
    extract_information_from_header_file,
)

# COMMAND ----------

# DBTITLE 1,Task values
INPUT_TABLE_LIST = dbutils.jobs.taskValues.get(
    taskKey="Ingest_SAP_Raw_Files_Into_LZ",
    key="table_output_list",
    default="",
    debugValue=[
        {
            "output_table_path": "dev_landingzone.sap_latecoere_ecc6.lipskeys_stack",
            "table_name": "LIPSKEYS",
        }
    ],
)

# COMMAND ----------

# DBTITLE 1,Global variables & logger
LATEST_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze"
LATEST_DOMAIN = "sap_latecoere_ecc6"

log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

log.debug(f"INPUT_TABLE_LIST: {INPUT_TABLE_LIST}")

# COMMAND ----------

# DBTITLE 1,Functions definition
def process_single_table(
    base_table_name: str,
    table_name: str,
    df_header: SparkDataFrame,
    existing_tables: List,
) -> str:
    """
    Process the latest version of a single table and merge it with the base table.

    This function checks if both the specified table and base table exist in the header
    and verifies that their keys are identical. It then reads both tables, fills any
    missing columns with null values, and performs a merge to track deletions.

    :param base_table_name: The name of the base table to compare.
    :type base_table_name: str
    :param table_name: The name of the table to process.
    :type table_name: str
    :param df_header: DataFrame containing the header information with table keys.
    :type df_header: SparkDataFrame
    :param existing_tables: List of existing tables in the header to check for existence.
    :type existing_tables: List

    :return: The path to the processed table if successful, None if an error occurs.
    :rtype: str or None

    :raises Exception: If the tables' keys do not match or if an error occurs during processing.

    **Logs:**
        - Logs key matching, table existence checks, merge operations, and duration.
    """

    # Check both tables exist in the header
    if table_name not in existing_tables or base_table_name not in existing_tables:
        log.error(
            f"At least one table among {base_table_name} and {table_name} is not in HEADER."
        )
        return None

    start_time = time.time()

    # Define table paths and check if tables exist
    unity_catalog_table_name = f"{table_name.lower()}_latest"
    latest_table_path = f"{LATEST_CATALOG}.{LATEST_DOMAIN}.{unity_catalog_table_name}"

    unity_catalog_base_table_name = f"{base_table_name.lower()}_latest"
    latest_base_table_path = (
        f"{LATEST_CATALOG}.{LATEST_DOMAIN}.{unity_catalog_base_table_name}"
    )

    # Check if tables exist
    if not table_utils.UnityCatalogCheckTableExists(latest_table_path):
        log.error(f"Table {latest_table_path} does not exist in Unity Catalog.")
        return None

    if not table_utils.UnityCatalogCheckTableExists(latest_base_table_path):
        log.error(f"Table {latest_base_table_path} does not exist in Unity Catalog.")
        return None

    # Extract tables keys
    _, table_name_column_uid_list = extract_information_from_header_file(
        df_header=df_header, sap_table_name=table_name
    )
    _, base_table_name_column_uid_list = extract_information_from_header_file(
        df_header=df_header, sap_table_name=base_table_name
    )

    log.info(f"ID key for {table_name}: {table_name_column_uid_list}")
    log.info(f"ID key for {base_table_name}: {base_table_name_column_uid_list}")

    if table_name_column_uid_list == base_table_name_column_uid_list:
        log.info(f"Keys of {table_name} and {base_table_name} are identical.")
    else:
        log.error(
            f"Keys of {table_name} and {base_table_name} are different (order or content)."
        )
        return None

    # Read the latest keys table and fill missing columns with nulls
    try:
        dfkeys = spark.read.table(latest_table_path)
        base_table_columns = spark.read.table(latest_base_table_path).columns

        for col in base_table_columns:
            if col not in dfkeys.columns:
                dfkeys = dfkeys.withColumn(col, f.lit(None).cast("string"))
    except AnalysisException as e:
        log.error(
            f"Tables {base_table_name} and {table_name} have not been processed due to an error: {e}"
        )
        return None

    # MERGE {table_name} INTO {base_table_name} latest table to track deletion
    try:
        table_utils.merge_into(
            dfkeys,
            latest_base_table_path,
            base_table_name_column_uid_list,
            do_when_matched=False,  # Update existing keys in the table ? -> NO
            matched_clause=None,
            do_when_notmatched=False,  # Insert new keys in the table ? -> NO
            do_when_notmatchedbysource=True,  # Delete keys in the table that are not in the source dataframe ? -> YES
        ).display()
    except Exception as e:
        log.error(
            f"Table {latest_base_table_path} has not been merged, an error occurred during MERGE INTO. \n {e}"
        )
        return None

    duration = time.time() - start_time
    log.info(
        f"Table {latest_table_path} merged in {duration:.2f} seconds into {latest_base_table_path}."
    )
    return f"{latest_table_path}"

# COMMAND ----------

# MAGIC %md
# MAGIC # Main

# COMMAND ----------

if __name__ == "__main__":
    # ------------------------------ PARSE ------------------------------
    # Retrieve tables from the "Pilotage table" to convert column name
    df_header = spark.read.options(header="True", delimiter=";").csv(FILE_HEADER_PATH)

    # Ensure successful reading of the header file
    if df_header.count() == 0:
        log.error(f"Header file at {FILE_HEADER_PATH} is empty or unreadable.")
        raise FileNotFoundError(
            f"File {FILE_HEADER_PATH} could not be loaded properly."
        )

    existing_tables = list(
        df_header.select("query_table").drop_duplicates().toPandas()["query_table"]
    )
    log.debug(f"Existing_tables: {existing_tables}")

    # Loop through the list of dictionariesé
    for table in INPUT_TABLE_LIST:
        # Get the values of each key in the current dictionary
        table_name = table["table_name"]

        if len(table_name) >= 5 and table_name.lower().endswith("keys"):
            base_table_name = table_name[:-4]

            # Do something with the values
            log.info(f"Processing {base_table_name} , from {table_name}")
            output_table_path = process_single_table(
                base_table_name, table_name, df_header, existing_tables
            )
            if output_table_path is not None:
                log.info(
                    f"Processed successfully {base_table_name} , from {table_name}"
                )
            else:
                log.error(
                    f"Processed unsuccessfully {base_table_name} , from {table_name} -> Aborting"
                )
                raise Exception()
