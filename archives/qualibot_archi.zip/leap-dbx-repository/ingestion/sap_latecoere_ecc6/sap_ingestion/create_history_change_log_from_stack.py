# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC
# MAGIC The purpose of this notebook is to historize data, tracking each time a row changes based on column values.
# MAGIC - When a new ID in inserted
# MAGIC - When data columns are updated for an ID
# MAGIC
# MAGIC The notebook performs the following tasks:
# MAGIC - Get all row changes based on ID and a data_Column column which is a concat of all raw columns
# MAGIC - Add Start_validity and End_Validity columns
# MAGIC - Add Version number based on ID
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - {PIPELINE_WRITE_ENV}_bronze.sap_latecoere_ecc6.{table_name}_history_change_log
# MAGIC
# MAGIC **Input :**
# MAGIC - {PIPELINE_READ_ENV}_bronze.sap_latecoere_ecc6.{table_name}_stack
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - Ingestion Pipeline
# MAGIC
# MAGIC **How to use the history_change_log table:**
# MAGIC - Query the table for an ID with a date >= Start_Validity and < End_Validity
# MAGIC - Start_Validity : is the beginning of validity interval, so must use  >=
# MAGIC - End_Validity : is the beginning of the next validity interval, so must use  < 
# MAGIC
# MAGIC **How the history_change_log table is updated:**
# MAGIC - when force_reinitialization=True or force_changelog_reinitialization=True or when history table does not exists: 
# MAGIC ```
# MAGIC                   -do an init from the Stack table
# MAGIC                    load the Stack
# MAGIC                    find ID discontinuities and fill the gaps if table does not contain DELTA loads
# MAGIC                    find data changes
# MAGIC                    compute  Start_Validity/End_Validity fields
# MAGIC                    save the delta table
# MAGIC ```
# MAGIC - when both force_reinitialization=False and force_changelog_reinitialization=False : 
# MAGIC ```
# MAGIC                   -do an delta update from the previous history table + missing Stacks
# MAGIC                   load the Stack and history table
# MAGIC                   find ID discontinuities and fill the gaps if table does not contain DELTA loads
# MAGIC                   find data changes
# MAGIC                   compute  Start_Validity/End_Validity fields
# MAGIC                   save the delta table
# MAGIC ```
# MAGIC - On last appearance of an ID :
# MAGIC ```
# MAGIC                 -set End_Validity to max_extraction_date + 1day 
# MAGIC                 -                 to 9999-12-31 if still present in the latest Stack
# MAGIC                 -                 to 9999-12-31 if table contain DELTA loads
# MAGIC ```
# MAGIC - On fisrt appearance of an ID :
# MAGIC ```
# MAGIC                 -set Start_Validity to 1900-01-01
# MAGIC ```
# MAGIC - On a period with no appearance of an ID between two dates: 
# MAGIC ```
# MAGIC                 -insert a row with null values except ID, extraction_timestamp, Start_Validity, End_Validity
# MAGIC                  indicating there was no values between those dates
# MAGIC ```
# MAGIC
# MAGIC **Known issues:**
# MAGIC - when changes occurs between two extraction_timestamp of the same day: 
# MAGIC ```
# MAGIC                   -Start_Validity, End_Validity are equals and row can be filtered
# MAGIC                   ex : Table EKES on 2023-09-20 and ID 600-4501248949-00010-0001
# MAGIC
# MAGIC ```
# MAGIC - when processing the table in delta update mode the min_extraction_date and max_extraction_date are distorted: 
# MAGIC ```
# MAGIC                   min_extraction_date and max_extraction_date columns must be kepted in history change log table after init of the table
# MAGIC                   for processing in delta update mode, they must be of type timestamp as column extraction_timestamp
# MAGIC
# MAGIC ```
# MAGIC
# MAGIC **Things to do:**
# MAGIC - see if possible to use MERGE INTO for delta update
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings / Config

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
import logging

import time
import datetime

from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql import functions as f, Column
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# DBTITLE 1,Config LEAP Functions Imports
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils, history_changelog

# COMMAND ----------

# DBTITLE 1,Widgets definition
# Get pipeline write environment variable for output tables (dev / uat / prod)
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# If force_reinitialization == True then the stack table, the latest table and history_change_log table will be reinitialized
dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = eval(dbutils.widgets.get("force_reinitialization"))

# If force_changelog_reinitialization == True then the history_change_log table will be reinitialized
dbutils.widgets.text("force_changelog_reinitialization", "False")
FORCE_CHANGELOG_REINITIALIZATION = eval(
    dbutils.widgets.get("force_changelog_reinitialization")
)

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# COMMAND ----------

# DBTITLE 1,Config Pipeline Common Functions Imports
from ingestion.sap_latecoere_ecc6.sap_ingestion.common import (
    FILE_HEADER_PATH,
    THE_ORIGIN,
    extract_information_from_header_file,
)

# COMMAND ----------

# DBTITLE 1,Task values
INPUT_TABLE_LIST = dbutils.jobs.taskValues.get(
    taskKey="Ingest_SAP_Raw_Files_Into_LZ",
    key="table_history_list",
    default="",
    debugValue=[
        {
            "output_table_path": "prod_landingzone.sap_latecoere_ecc6.ekes_stack",
            "table_name": "EKES",
        }
    ],
)

# COMMAND ----------

# DBTITLE 1,Global variables & logger
HISTORY_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze"
HISTORY_DOMAIN = "sap_latecoere_ecc6"

log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

log.debug(f"INPUT_TABLE_LIST: {INPUT_TABLE_LIST}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Functions

# COMMAND ----------

# DBTITLE 1,Function definition
# from  history_changelog :
## main functions : calculate_history_changelog_delta_update()  and   initialize_history_changelog()

# COMMAND ----------

# DBTITLE 1,Documentation by example
# MAGIC %md
# MAGIC **Sample Output for function : history_changelog.initialize_history_changelog() - INITIALIZATION OF HISTORY CHANGELOG**
# MAGIC ```
# MAGIC Sample output from  history_changelog.initialize_history_changelog()  for table ekes showing what are the attended "extraction_timestamp" , ran on 2024-04-30
# MAGIC
# MAGIC df_table_stack = spark.read.table("prod_landingzone.sap_latecoere_ecc6.ekes_stack")
# MAGIC df_history_changelog = history_changelog.initialize_history_changelog(
# MAGIC     df=df_table_stack,
# MAGIC     id_column_list=["ID"],
# MAGIC     sort_column="extraction_timestamp",
# MAGIC     tracked_column_list=sap_schema_ordered_list,
# MAGIC     data_extraction_mode="FULL",
# MAGIC     calculate_discontinuities=True,
# MAGIC )
# MAGIC display(df_history_changelog)
# MAGIC ```
# MAGIC &#8595;
# MAGIC
# MAGIC stack_row_id |	ID |	extraction_timestamp |	Start_Validity |	End_Validity |	mandt |	ebeln |	ebelp |	min_extraction_date |	max_extraction_date
# MAGIC --- | --- | --- | --- | --- | --- | --- | --- | --- | --- 
# MAGIC 441016457 |	600-4501343650-00010-0001 |	2024-02-13T22:28:20.000+00:00 |	2024-02-13 |	9999-12-31 |	600 |	4501343650 |	00010 |	2024-02-13T22:28:20.000+00:00 |	2024-04-30T22:37:36.000+00:00
# MAGIC

# COMMAND ----------

# DBTITLE 1,Documentation by example
# MAGIC %md
# MAGIC **Sample Output for function : history_changelog.calculate_history_changelog_delta_update() - DELTA UPDATE OF HISTORY CHANGELOG**
# MAGIC ```
# MAGIC Sample output from  history_changelog.calculate_history_changelog_delta_update()  for table ekes showing what are the attended "extraction_timestamp" , ran on 2024-05-04
# MAGIC
# MAGIC df_table_stack = (spark.read.table("prod_landingzone.sap_latecoere_ecc6.ekes_stack@v115"))  # stack on 2024-05-04 23:19:28
# MAGIC df_table_stack_from_last_run_to_current_date = df_table_stack.filter(f.col("extraction_timestamp") > "2024-04-30")  # stack filtered
# MAGIC df_table_history = spark.read.table("prod_bronze.sap_latecoere_ecc6.ekes_history_change_log@v118") # changelog on 2024-05-02 23:28:57
# MAGIC
# MAGIC df_history_changelog_updated = (
# MAGIC     history_changelog.calculate_history_changelog_delta_update(
# MAGIC         df=df_table_stack_from_last_run_to_current_date,
# MAGIC         df_existing_history_changelog=df_table_history,
# MAGIC         id_column_list=["ID"],
# MAGIC         sort_column="extraction_timestamp",
# MAGIC         tracked_column_list=sap_schema_ordered_list,
# MAGIC         data_extraction_mode="FULL",
# MAGIC         calculate_discontinuities=True,
# MAGIC     )
# MAGIC )
# MAGIC display(df_history_changelog)
# MAGIC ```
# MAGIC &#8595;
# MAGIC
# MAGIC stack_row_id |	ID |	extraction_timestamp |	Start_Validity |	End_Validity |	mandt |	ebeln |	ebelp |	min_extraction_date |	max_extraction_date
# MAGIC --- | --- | --- | --- | --- | --- | --- | --- | --- | --- 
# MAGIC 441016457 |	600-4501343650-00010-0001 |	2024-02-13T22:28:20.000+00:00 |	2024-02-13 |	2024-05-02 |	600 |	4501343650 |	00010 |	2024-02-13T22:28:20.000+00:00 |	2024-05-04T22:25:02.000+00:00
# MAGIC null |	600-4501343650-00010-0001 |	2024-05-02T22:34:36.000+00:00 |	2024-05-02 |	2024-05-03 |	null |	null |	null |	2024-02-13T22:28:20.000+00:00 |	2024-05-04T22:25:02.000+00:00
# MAGIC 658854775 |	600-4501343650-00010-0001 |	2024-05-03T22:28:33.000+00:00 |	2024-05-03 |	9999-12-31 |	600 |	4501343650 |	00010 |	2024-02-13T22:28:20.000+00:00 |	2024-05-04T22:25:02.000+00:00
# MAGIC

# COMMAND ----------

# DBTITLE 1,Functions definition
def process_single_table(
    table_name: str,
    df_header: SparkDataFrame,
    existing_tables: str,
    input_table_path: str,
) -> str:
    """
    process ingestion of a single table
    return {output_table_path} if ok, or None if not
    """

    if table_name in existing_tables:
        startTime = time.time()

        # Read stack table
        df_table_stack = spark.read.table(input_table_path)

        # Read header to get the data
        sap_schema_ordered_list, column_uid_list = extract_information_from_header_file(
            df_header=df_header, sap_table_name=table_name
        )

        log.info(f"Column names are : {sap_schema_ordered_list}")
        log.info(f"ID key is : {column_uid_list}")

        Unity_Catalog_Table_Name = f"{table_name.lower()}_history_change_log"

        history_change_log_table_path = (
            f"{HISTORY_CATALOG}.{HISTORY_DOMAIN}.{Unity_Catalog_Table_Name}"
        )

        # get the first_existing_timestamp_of_extraction
        first_existing_timestamp_of_extraction_in_stack = df_table_stack.select(
            f.min("extraction_timestamp")
        ).first()["min(extraction_timestamp)"]
        log.info(
            f"the first timestamp in Stack table is : {first_existing_timestamp_of_extraction_in_stack}"
        )

        # get the last_existing_timestamp_of_extraction
        last_existing_timestamp_of_extraction_in_stack = df_table_stack.select(
            f.max("extraction_timestamp")
        ).first()["max(extraction_timestamp)"]
        log.info(
            f"the last timestamp in Stack table is : {last_existing_timestamp_of_extraction_in_stack}"
        )

        # if history_change_log_table already exists and FORCE_REINITIALIZATION == False and FORCE_CHANGELOG_REINITIALIZATION == False then history_change_log_table processed with needed stacks only
        # else history_change_log_table processed with full stack method
        if (
            (table_utils.UnityCatalogCheckTableExists(history_change_log_table_path))
            and (FORCE_REINITIALIZATION == False)
            and (FORCE_CHANGELOG_REINITIALIZATION == False)
        ):
            log.info(
                f"Computing the DELTA history changelog table {Unity_Catalog_Table_Name}"
            )

            # Read existing history_change_log_table
            df_table_history = spark.read.table(history_change_log_table_path)

            # get the last_existing_timestamp in history_change_log_table
            last_existing_timestamp_in_history_change_log = df_table_history.select(
                f.max("extraction_timestamp")
            ).first()["max(extraction_timestamp)"]

            if last_existing_timestamp_in_history_change_log is None:
                last_existing_timestamp_in_history_change_log = (
                    datetime.datetime.strptime(THE_ORIGIN, "%Y-%m-%d")
                )

            log.info(
                f"the last timestamp in history changelog table is : {last_existing_timestamp_in_history_change_log}"
            )

            # Do processing only if changes are detected in stack
            if (
                last_existing_timestamp_of_extraction_in_stack
                > last_existing_timestamp_in_history_change_log
            ):

                # Filter stack table with needed extraction_timestamps
                df_table_stack_from_last_run_to_current_date = df_table_stack.filter(
                    (
                        df_table_stack.extraction_timestamp
                        > last_existing_timestamp_in_history_change_log
                    )
                )

                df_history_final = (
                    history_changelog.calculate_history_changelog_delta_update(
                        df=df_table_stack_from_last_run_to_current_date,
                        df_existing_history_changelog=df_table_history,
                        id_column_list=["ID"],
                        sort_column="extraction_timestamp",
                        tracked_column_list=sap_schema_ordered_list,
                        data_extraction_mode="FULL",
                        calculate_discontinuities=True,
                    )
                )

            else:
                log.info(f"the table {Unity_Catalog_Table_Name} is already up to date")
                return f"{HISTORY_CATALOG}.{HISTORY_DOMAIN}.{Unity_Catalog_Table_Name}"

        else:
            # Below the computation of the full history table
            log.info(
                f"Computing the FULL history changelog table {Unity_Catalog_Table_Name}"
            )

            df_history_final = history_changelog.initialize_history_changelog(
                df=df_table_stack,
                id_column_list=["ID"],
                sort_column="extraction_timestamp",
                tracked_column_list=sap_schema_ordered_list,
                data_extraction_mode="FULL",
                calculate_discontinuities=True,
            )

        # Save history table
        try:
            result = table_utils.save_table(
                dest_table=history_change_log_table_path,
                df=df_history_final,
                mode="overwrite",
                overwrite_schema=True,
            )
        except AnalysisException as e:
            log.error(
                f"Table {history_change_log_table_path} has not been created, an error occured during creation."
            )
            return None
        else:
            duration = time.time() - startTime
            log.info(
                f"Table {history_change_log_table_path} created in {duration} seconds."
            )
            return f"{history_change_log_table_path}"
    else:
        log.error(f"Table {table_name} is not in HEADER.")
        return None

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Main

# COMMAND ----------

if __name__ == "__main__":
    # ------------------------------ PARSE ------------------------------
    # Retrieve tables from the "Pilotage table" to convert column name
    df_header = spark.read.options(header="True", delimiter=";").csv(FILE_HEADER_PATH)

    existing_tables = list(
        df_header.select("query_table").drop_duplicates().toPandas()["query_table"]
    )
    log.debug(f"Existing_tables: {existing_tables}")

    log.debug(f"INPUT_TABLE_LIST: {INPUT_TABLE_LIST}")
    # Loop through the list of dictionaries
    for table in INPUT_TABLE_LIST:
        log.debug(f"table: {table}")
        # Get the values of each key in the current dictionary
        table_name = table["table_name"]
        input_table_path = table["output_table_path"]

        # Do something with the values
        log.info(f"Processing {table_name} , from {input_table_path}")
        output_table_path = process_single_table(
            table_name, df_header, existing_tables, input_table_path
        )
        if output_table_path is not None:
            log.info(f"Processed successfully {table_name} , to {output_table_path}")
        else:
            log.error(
                f"Processed unsuccessfully {table_name} , to {output_table_path} -> Aborting"
            )
            raise Exception()
