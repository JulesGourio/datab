# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to create two latest tables for MDTB in place of one view.
# MAGIC - a latest full table that will be based on FULL loads from stack.
# MAGIC - a latest daily table that will be based on FULL/DELTA loads from stack.
# MAGIC
# MAGIC In order to manage rows deletion on delta loads only :
# MAGIC - a match will be done against MDKP and MDKPDB on columns MANDT and DTNUM.
# MAGIC - Records not matched on any of these 2 tables will be deleted from MDTB.
# MAGIC
# MAGIC **Output:**
# MAGIC when MDTB is FULL
# MAGIC   - `{PIPELINE_WRITE_ENV}_bronze.sap.mdtb_weekly`
# MAGIC   - `{PIPELINE_WRITE_ENV}_bronze.sap.mdtb_latest`
# MAGIC   - `{PIPELINE_WRITE_ENV}_bronze.sap.mdkp_weekly`
# MAGIC   - `{PIPELINE_WRITE_ENV}_bronze.sap.mdkpdb_weekly`
# MAGIC
# MAGIC when MDTB is DELTA
# MAGIC   - `{PIPELINE_WRITE_ENV}_bronze.sap.mdtb_latest`
# MAGIC
# MAGIC **Input :**
# MAGIC   - `{PIPELINE_READ_ENV}_landingzone.sap.mdtb_stack`
# MAGIC   - `{PIPELINE_READ_ENV}_bronze.sap.mdkp_latest`
# MAGIC   - `{PIPELINE_READ_ENV}_bronze.sap.mdkpdb_latest`
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - SAP Ingestion v2 Workflow
# MAGIC
# MAGIC **Things done:**
# MAGIC - calculate latest ID for MDTB
# MAGIC - process of deleted records regarding against MDKP and MDKPDB
# MAGIC - write tables
# MAGIC

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
import datetime
import logging

from pyspark.sql import functions as f
from collections import defaultdict

# COMMAND ----------

# DBTITLE 1,Config LEAP Functions Imports
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils

# COMMAND ----------

# DBTITLE 1,Widgets definition
dbutils.widgets.removeAll()

# Get pipeline write environment variable for output tables (dev / uat / prod)
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Get pipeline read environment variable for input tables (dev / uat / prod)
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# If force_reinitialization == True then the stack table will be reinitialized
dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = eval(dbutils.widgets.get("force_reinitialization"))

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# Set timedelta allowance in hours between extraction_timestamps
dbutils.widgets.text("timedelta_allowance", "8")
TIME_DELTA_ALLOWANCE = int(dbutils.widgets.get("timedelta_allowance"))

# Skip checks
dbutils.widgets.text("skip_checks", "False")
SKIP_CHECKS = dbutils.widgets.get("skip_checks").lower() == "true"

# COMMAND ----------

# DBTITLE 1,Task values

INPUT_TABLE_LIST = dbutils.jobs.taskValues.get(
    taskKey="Ingest_SAP_Raw_Files_Into_LZ",
    key="table_output_list",
    default="",
    debugValue=[
        {
            "output_table_path": "dev_landingzone.sap_latecoere_ecc6.mdtb_stack",
            "table_name": "MDTB",
        }
    ],
)

# COMMAND ----------

# DBTITLE 1,Globals
STACK_CATALOG = f"{PIPELINE_READ_ENV}_landingzone"
STACK_DOMAIN = "sap_latecoere_ecc6"

INPUT_LATEST_CATALOG = f"{PIPELINE_READ_ENV}_bronze"
OUTPUT_LATEST_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze"
LATEST_DOMAIN = "sap_latecoere_ecc6"

MDTB_STACK_TABLE = f"{STACK_CATALOG}.{STACK_DOMAIN}.mdtb_stack"

MDKP_LATEST_WEEKLY_TABLE = f"{OUTPUT_LATEST_CATALOG}.{LATEST_DOMAIN}.mdkp_weekly"
MDKP_LATEST_DAILY_TABLE = f"{INPUT_LATEST_CATALOG}.{LATEST_DOMAIN}.mdkp_latest"

MDKPDB_LATEST_WEEKLY_TABLE = f"{OUTPUT_LATEST_CATALOG}.{LATEST_DOMAIN}.mdkpdb_weekly"
MDKPDB_LATEST_DAILY_TABLE = f"{INPUT_LATEST_CATALOG}.{LATEST_DOMAIN}.mdkpdb_latest"

MDTB_LATEST_WEEKLY_TABLE = f"{OUTPUT_LATEST_CATALOG}.{LATEST_DOMAIN}.mdtb_weekly"
MDTB_LATEST_DAILY_TABLE = f"{OUTPUT_LATEST_CATALOG}.{LATEST_DOMAIN}.mdtb_latest"

log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)


# COMMAND ----------

# MAGIC %md
# MAGIC # Check Stack Completeness or exit

# COMMAND ----------

# Exécuter la requête SQL
df_files = spark.sql(
    f"""
    SELECT DISTINCT 
        extraction_timestamp,
        SPLIT_PART(file_name, '_', 3) AS file_type
    FROM {MDTB_STACK_TABLE} 
    WHERE extraction_timestamp >= TIMESTAMPADD(HOUR,12,DATE(DATE_SUB(CONVERT_TIMEZONE('UTC', 'Europe/Paris', CURRENT_TIMESTAMP()), 1)))
    ORDER BY extraction_timestamp DESC
"""
)

# Convertir en liste de tuples (extraction_timestamp, file_type)
file_data = [
    (row["extraction_timestamp"], row["file_type"]) for row in df_files.collect()
]

# Regrouper les fichiers par extraction_timestamp
files_by_timestamp = defaultdict(set)
for timestamp, file_type in file_data:
    files_by_timestamp[timestamp].add(file_type)

# Récupérer le dernier extraction_timestamp
latest_timestamp = max(files_by_timestamp.keys()) if files_by_timestamp else None

# Vérifier les conditions
if latest_timestamp:
    latest_files = files_by_timestamp[latest_timestamp]

    if "SAP-MDTB-F" in latest_files:
        log.info(
            f"✅ FULL extraction detected at {latest_timestamp}. Notebook continues."
        )
    else:
        # Vérifier la présence des 2 types dans les dernières 24h
        file_types_last_24h = set().union(*files_by_timestamp.values())

        if {"SAP-MDTB-DSDAT~DD~4-MDKP", "SAP-MDTB-DSDAT~DD~4-MDKPDB"}.issubset(
            file_types_last_24h
        ):
            # Récupérer les extraction_timestamp pour les deux types de fichiers DELTA
            delta_timestamps = []
            for timestamp, file_types in files_by_timestamp.items():
                if (
                    "SAP-MDTB-DSDAT~DD~4-MDKP" in file_types
                    or "SAP-MDTB-DSDAT~DD~4-MDKPDB" in file_types
                ):
                    delta_timestamps.append(timestamp)

            if len(delta_timestamps) == 1:
                log.info("✅ DELTA extraction is complete. Notebook continues.")
                log.info(f"✅ file_types_last_24h : {file_types_last_24h}")
                log.info("✅ DELTA extraction timestamps:")
                for ts in delta_timestamps:
                    log.info(f"   - {ts.strftime('%Y-%m-%d %H:%M:%S')} (Timestamp)")
            elif len(delta_timestamps) == 2:
                # Vérifier la différence de temps entre les deux timestamps
                time_diff = abs(delta_timestamps[0] - delta_timestamps[1])
                time_diff_hours = time_diff.total_seconds() / 3600

                if time_diff_hours > TIME_DELTA_ALLOWANCE:
                    log.error(
                        f"❌ The time difference between the DELTA files exceeds the allowed delta of {TIME_DELTA_ALLOWANCE} hours."
                    )
                    log.error(f"❌ file_types_last_24h : {file_types_last_24h}")
                    log.error(f"❌ delta_timestamps : {delta_timestamps}")
                    dbutils.jobs.taskValues.set("skip_run_metajob", True)
                    dbutils.notebook.exit(
                        f"The time difference between the DELTA files exceeds the allowed delta of {TIME_DELTA_ALLOWANCE} hours. file_types_last_24h : {file_types_last_24h} . delta_timestamps : {delta_timestamps}. Stopping notebook."
                    )
                else:
                    log.info(
                        f"✅ DELTA extraction is complete and within the allowed time delta of {TIME_DELTA_ALLOWANCE} hours. Notebook continues."
                    )
                    log.info(f"✅ file_types_last_24h : {file_types_last_24h}")
                    log.info("✅ DELTA extraction timestamps:")
                    for ts in delta_timestamps:
                        log.info(f"   - {ts.strftime('%Y-%m-%d %H:%M:%S')} (Timestamp)")
            else:
                log.error("❌ Too Many DELTA extraction. Stopping notebook.")
                log.error(f"❌ file_types_last_24h : {file_types_last_24h}")
                log.error(f"❌ delta_timestamps : {delta_timestamps}")
                dbutils.jobs.taskValues.set("skip_run_metajob", True)
                if not SKIP_CHECKS:
                    raise Exception(
                        f"Too Many DELTA extraction. file_types_last_24h : {file_types_last_24h} . delta_timestamps : {delta_timestamps}. Stopping notebook."
                    )
        else:
            log.info(
                "❌ Incomplete DELTA extraction. Stopping notebook without error and wait for completeness of stack."
            )
            log.info(f"❌ file_types_last_24h : {file_types_last_24h}")
            dbutils.jobs.taskValues.set("skip_run_metajob", True)
            dbutils.notebook.exit(
                f"Incomplete DELTA extraction. file_types_last_24h : {file_types_last_24h} . Stopping notebook without error and wait for completeness of stack."
            )

else:
    log.error(
        "❌ No recent files found.  Stopping notebook without error and wait for completeness of stack."
    )
    dbutils.jobs.taskValues.set("skip_run_metajob", True)
    dbutils.notebook.exit(
        "No recent files found.  Stopping notebook without error and wait for completeness of stack."
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Main
# MAGIC

# COMMAND ----------

# DBTITLE 1,Load tables
# Load MDTB stack
df_mdtb_stack = spark.read.format("delta").table(MDTB_STACK_TABLE)

# Load MDTB latest daily table if exists
df_mdtb_latest_daily = None
if table_utils.UnityCatalogCheckTableExists(MDTB_LATEST_DAILY_TABLE):
    # Load MDTB latest
    try:
        df_mdtb_latest_daily = spark.read.format("delta").table(MDTB_LATEST_DAILY_TABLE)
    except:
        log.info(f"the table or view {MDTB_LATEST_DAILY_TABLE} does not exists.")
        df_mdtb_latest_daily = None

# Load MDKP and MDKPDB latest
try:
    df_mdkp_latest_daily = spark.read.format("delta").table(MDKP_LATEST_DAILY_TABLE)
except:
    raise Exception(f"Error loading {MDKP_LATEST_DAILY_TABLE}")
df_mdkp_latest_daily_projected = df_mdkp_latest_daily.select(
    "mandt", "dtnum", "extraction_timestamp"
)

try:
    df_mdkpdb_latest_daily = (
        spark.read.format("delta")
        .table(MDKPDB_LATEST_DAILY_TABLE)
        .select("mandt", "dtnum", "extraction_timestamp")
    )
except:
    raise Exception(f"Error loading {MDKPDB_LATEST_DAILY_TABLE}")
df_mdkpdb_latest_daily_projected = df_mdkpdb_latest_daily.select(
    "mandt", "dtnum", "extraction_timestamp"
)

# COMMAND ----------

# DBTITLE 1,MDTB Get Information
# Add a column to have the mode with value "F" or "D" to MDTB
df_mdtb_stack = df_mdtb_stack.withColumn(
    "mode", f.when(df_mdtb_stack.file_name.contains("SAP-MDTB-F"), "F").otherwise("D")
)
log.info(f"the column 'mode' is added to stack")

# get the last_existing_timestamp_of_extraction in stack table
try:
    mdtb_last_existing_timestamp_of_extraction_stack = df_mdtb_stack.select(
        f.max("extraction_timestamp")
    ).first()[0]
except:
    raise Exception("No extraction date found")
log.info(
    f"the last extraction_timestamp in stack table {MDTB_STACK_TABLE} is : {mdtb_last_existing_timestamp_of_extraction_stack}"
)

# get the mode of last extraction_timestamp in stack table
try:
    mdtb_last_mode = (
        df_mdtb_stack.filter(
            df_mdtb_stack.extraction_timestamp
            == mdtb_last_existing_timestamp_of_extraction_stack
        )
        .select("mode")
        .first()[0]
    )
except:
    raise Exception("No extraction date found")
log.info(f"the last mode of extraction in stack is : {mdtb_last_mode}")

# get the mode of last extraction_timestamp in latest_daily table if exist
if df_mdtb_latest_daily is not None:
    # get the last_existing_timestamp_of_extraction in latest_daily table
    try:
        mdtb_last_existing_timestamp_of_extraction_latest_daily = (
            df_mdtb_latest_daily.select(f.max("extraction_timestamp")).first()[0]
        )
    except:
        mdtb_last_existing_timestamp_of_extraction_latest_daily = "1970-01-01"
        raise Exception(f"No extraction_timestamp found in {MDTB_STACK_TABLE}")
else:
    mdtb_last_existing_timestamp_of_extraction_latest_daily = "1970-01-01"
log.info(
    f"the last day of extraction in latest daily is : {mdtb_last_existing_timestamp_of_extraction_latest_daily}"
)

# COMMAND ----------

# DBTITLE 1,MDKP Get Information and check extraction_timestamp
# get the last_existing_timestamp_of_extraction in MDKP latest table
try:
    mdkp_last_existing_timestamp_of_extraction_latest = (
        df_mdkp_latest_daily_projected.select(f.max("extraction_timestamp")).first()[0]
    )
except:
    raise Exception(f"No extraction_timestamp found in {MDKP_LATEST_DAILY_TABLE}")
else:
    log.info(
        f"the last extraction_timestamp in {MDKP_LATEST_DAILY_TABLE} is : {mdkp_last_existing_timestamp_of_extraction_latest}"
    )

# Check that :  {MDTB_STACK_TABLE} - {TIME_DELTA_ALLOWANCE} hours < {MDKP_LATEST_DAILY_TABLE} < {MDTB_STACK_TABLE} + {TIME_DELTA_ALLOWANCE} hours
# raise error if :  {MDKP_LATEST_DAILY_TABLE} <  {MDTB_STACK_TABLE} - {TIME_DELTA_ALLOWANCE} hours
# or if : {MDKP_LATEST_DAILY_TABLE} >  {MDTB_STACK_TABLE} + {TIME_DELTA_ALLOWANCE} hours
if mdtb_last_mode == "D" and (
    (
        mdkp_last_existing_timestamp_of_extraction_latest
        < (
            mdtb_last_existing_timestamp_of_extraction_stack
            - datetime.timedelta(hours=TIME_DELTA_ALLOWANCE)
        )
    )
    or (
        mdkp_last_existing_timestamp_of_extraction_latest
        > (
            mdtb_last_existing_timestamp_of_extraction_stack
            + datetime.timedelta(hours=TIME_DELTA_ALLOWANCE)
        )
    )
):
    log.error(
        f"the last extraction_timestamp in stack table {MDTB_STACK_TABLE} is : {mdtb_last_existing_timestamp_of_extraction_stack}"
    )
    dbutils.jobs.taskValues.set("skip_run_metajob", True)
    dbutils.notebook.exit(
        f"{MDKP_LATEST_DAILY_TABLE} extraction_timestamp must be aligned on {MDTB_STACK_TABLE} +/-  {TIME_DELTA_ALLOWANCE} hours."
    )

# COMMAND ----------

# DBTITLE 1,MDKPDB Get Information
# get the last_existing_timestamp_of_extraction in MDKPDB latest table
try:
    mdkpdb_last_existing_timestamp_of_extraction_latest = (
        df_mdkpdb_latest_daily_projected.select(f.max("extraction_timestamp")).first()[
            0
        ]
    )
except:
    raise Exception(f"No extraction_timestamp found in {MDKPDB_LATEST_DAILY_TABLE}")
log.info(
    f"the last extraction_timestamp in {MDKPDB_LATEST_DAILY_TABLE} is : {mdkpdb_last_existing_timestamp_of_extraction_latest}"
)

# Check that :  {MDTB_STACK_TABLE} - {TIME_DELTA_ALLOWANCE} hours < {MDKPDB_LATEST_DAILY_TABLE} < {MDTB_STACK_TABLE} + {TIME_DELTA_ALLOWANCE} hours
# raise error if :  {MDKPDB_LATEST_DAILY_TABLE} <  {MDTB_STACK_TABLE} - {TIME_DELTA_ALLOWANCE} hours
# or if : {MDKPDB_LATEST_DAILY_TABLE} >  {MDTB_STACK_TABLE} + {TIME_DELTA_ALLOWANCE} hours
if mdtb_last_mode == "D" and (
    (
        mdkpdb_last_existing_timestamp_of_extraction_latest
        < (
            mdtb_last_existing_timestamp_of_extraction_stack
            - datetime.timedelta(hours=TIME_DELTA_ALLOWANCE)
        )
    )
    or (
        mdkpdb_last_existing_timestamp_of_extraction_latest
        > (
            mdtb_last_existing_timestamp_of_extraction_stack
            + datetime.timedelta(hours=TIME_DELTA_ALLOWANCE)
        )
    )
):
    log.error(
        f"the last extraction_timestamp in stack table {MDTB_STACK_TABLE} is : {mdtb_last_existing_timestamp_of_extraction_stack}"
    )
    dbutils.jobs.taskValues.set("skip_run_metajob", True)
    dbutils.notebook.exit(
        f"{MDKPDB_LATEST_DAILY_TABLE} extraction_timestamp must be aligned on {MDTB_STACK_TABLE} +/-  {TIME_DELTA_ALLOWANCE} hours."
    )

# COMMAND ----------

# DBTITLE 1,MDTB latest from stack , MDKP and MDKPDB
# Calculate the latest MDTB tables

# unpersist unnecessary dataframes
if df_mdtb_latest_daily is not None:
    df_mdtb_latest_daily.unpersist()

# if last mode in stack if F then latest_full=last load in stack , latest_daily=last load in stac
if mdtb_last_mode == "F":
    log.info(
        f"About to recompute the {MDTB_LATEST_WEEKLY_TABLE} and {MDTB_LATEST_DAILY_TABLE} based on last full only."
    )
    df_mdtb_latest = df_mdtb_stack.filter(
        df_mdtb_stack.extraction_timestamp
        == mdtb_last_existing_timestamp_of_extraction_stack
    )

    nbrows = df_mdtb_latest.count()

    # - 1 - write {MDTB_LATEST_WEEKLY_TABLE} as a delta table
    log.info(
        f"About to save {nbrows} rows since {mdtb_last_existing_timestamp_of_extraction_stack} in the table {MDTB_LATEST_WEEKLY_TABLE}."
    )

    result = table_utils.save_table(
        dest_table=MDTB_LATEST_WEEKLY_TABLE,
        df=df_mdtb_latest,
        mode="overwrite",
        overwrite_schema=True,
    )
    log.info(f"Table {MDTB_LATEST_WEEKLY_TABLE} saved.")

    # - 2 - write {MDTB_LATEST_DAILY_TABLE} as a delta table
    log.info(
        f"About to save {nbrows} rows since {mdtb_last_existing_timestamp_of_extraction_stack} in the table {MDTB_LATEST_DAILY_TABLE}."
    )
    result = table_utils.save_table(
        dest_table=MDTB_LATEST_DAILY_TABLE,
        df=df_mdtb_latest,
        mode="overwrite",
        overwrite_schema=True,
    )
    log.info(f"Table {MDTB_LATEST_DAILY_TABLE} saved.")

    # - 3 - write {MDKP_LATEST_WEEKLY_TABLE} as a delta table
    df_mdkp_weekly = df_mdkp_latest_daily
    log.info(f"About to save the table {MDKP_LATEST_WEEKLY_TABLE}.")
    result = table_utils.save_table(
        dest_table=MDKP_LATEST_WEEKLY_TABLE,
        df=df_mdkp_weekly,
        mode="overwrite",
        overwrite_schema=True,
    )
    log.info(f"Table {MDKP_LATEST_WEEKLY_TABLE} saved.")

    # - 4 - write {MDKPDB_LATEST_WEEKLY_TABLE} as a delta table
    df_mdkpdb_weekly = df_mdkpdb_latest_daily
    log.info(f"About to save the table {MDKPDB_LATEST_WEEKLY_TABLE}.")
    result = table_utils.save_table(
        dest_table=MDKPDB_LATEST_WEEKLY_TABLE,
        df=df_mdkpdb_weekly,
        mode="overwrite",
        overwrite_schema=True,
    )
    log.info(f"Table {MDKPDB_LATEST_WEEKLY_TABLE} saved.")

# else compute latest with FULL+DELTAS
else:
    log.info(
        f"About to recompute the {MDTB_LATEST_DAILY_TABLE} based on last full and deltas."
    )

    # Get the date of the latest full
    try:
        mdtb_max_date_full = (
            df_mdtb_stack.filter(df_mdtb_stack.mode == "F")
            .agg(f.max("extraction_timestamp"))
            .first()[0]
        )
        log.info(f"the last full of stack is : {mdtb_max_date_full}")
    except:
        print(f"No full in {MDTB_STACK_TABLE}")
    else:
        if mdtb_max_date_full is None:
            mdtb_max_date_full = "1970-01-01"
            log.info(f"No full : considering {mdtb_max_date_full} as reference")

    # Filter stack between  mdtb_max_date_full and current date
    df_mdtb_from_last_full_to_current_date = df_mdtb_stack.filter(
        (df_mdtb_stack.extraction_timestamp >= mdtb_max_date_full)
    )

    nbrows = df_mdtb_from_last_full_to_current_date.count()
    log.info(f"Table {MDTB_LATEST_DAILY_TABLE} is {nbrows} rows before cleaning.")

    # union of MDKP and MDKPDB
    df_union_mdkp_mdkpdb_projected = df_mdkp_latest_daily_projected.union(
        df_mdkpdb_latest_daily_projected
    ).dropDuplicates()

    # join MDTB with UNION to keep only needed rows
    df_mdtb_cleaned = (
        df_mdtb_from_last_full_to_current_date.alias("MDTB")
        .join(
            df_union_mdkp_mdkpdb_projected.alias("UNION"),
            (
                (f.col("MDTB.mandt") == f.col("UNION.mandt"))
                & (f.col("MDTB.dtnum") == f.col("UNION.dtnum"))
            ),
            "left_semi",
        )
        .drop("mode")
    )

    nbrows = df_mdtb_cleaned.count()
    log.info(
        f"Table {MDTB_LATEST_DAILY_TABLE} is {nbrows} rows after cleaning by join union of mdkp and mdkpdb ."
    )

    # Keep latest version for each ID
    df_mdtb_latest_cleaned = table_utils.get_latest_version_for_each_id_column(
        df_mdtb_cleaned, "ID", "extraction_timestamp"
    )

    nbrows = df_mdtb_latest_cleaned.count()
    log.info(
        f"Table {MDTB_LATEST_DAILY_TABLE} is {nbrows} rows after processing latest."
    )

    # - 1 - write {MDTB_LATEST_DAILY_TABLE} as a delta table
    log.info(
        f"About to save {nbrows} rows since {mdtb_max_date_full} in the table {MDTB_LATEST_DAILY_TABLE}."
    )

    result = table_utils.save_table(
        dest_table=MDTB_LATEST_DAILY_TABLE,
        df=df_mdtb_latest_cleaned,
        mode="overwrite",
        overwrite_schema=True,
    )
    log.info(f"Table {MDTB_LATEST_DAILY_TABLE} saved.")


# COMMAND ----------

# DBTITLE 1,Optimize MDTB stack and latest table
# OPTIMIZE ZORDER the MDTB latest full table by (mandt, dtnum)
log.info(f"About to OPTIMIZE the table {MDTB_LATEST_WEEKLY_TABLE}.")
OPTIMIZE_TABLE_SQL = f"OPTIMIZE {MDTB_LATEST_WEEKLY_TABLE} ZORDER BY (mandt, dtnum)"
spark.sql(OPTIMIZE_TABLE_SQL)
log.info(f"Table {MDTB_LATEST_WEEKLY_TABLE} OPTIMIZED.")


# OPTIMIZE ZORDER the MDTB latest daily table by (mandt, dtnum)
log.info(f"About to OPTIMIZE the table {MDTB_LATEST_DAILY_TABLE}.")
OPTIMIZE_TABLE_SQL = f"OPTIMIZE {MDTB_LATEST_DAILY_TABLE} ZORDER BY (mandt, dtnum)"
spark.sql(OPTIMIZE_TABLE_SQL)
log.info(f"Table {MDTB_LATEST_DAILY_TABLE} OPTIMIZED.")
