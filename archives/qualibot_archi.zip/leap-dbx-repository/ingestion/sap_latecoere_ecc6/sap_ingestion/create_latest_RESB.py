# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to create the latest table of RESB, knowing that each extraction leads to one, two or more datasets ( table subelement )
# MAGIC This latest table can be :
# MAGIC - the single latest FULL loads from stack.
# MAGIC - the two or more latest FULL loads from stack based on an interval of x hours
# MAGIC
# MAGIC **Output:**
# MAGIC   - `{PIPELINE_WRITE_ENV}_bronze.sap.resb_latest`
# MAGIC
# MAGIC **Input :**
# MAGIC   - `{PIPELINE_READ_ENV}_landingzone.sap.resb_stack`
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - SAP Ingestion v2 Workflow
# MAGIC
# MAGIC **Things done:**
# MAGIC - calculate group of extraction_timestamp by interval
# MAGIC - union of latest stack(s) regarding this interval
# MAGIC - write latest table
# MAGIC

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
import logging

from datetime import timedelta

from pyspark.sql import functions as f

# COMMAND ----------

# DBTITLE 1,Config LEAP Functions Imports
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils

# COMMAND ----------

# DBTITLE 1,Widgets definition
dbutils.widgets.removeAll()

# Get pipeline write environment variable for output tables (dev / uat / prod)
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Get pipeline read environment variable for input tables (dev / uat / prod)
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# If force_reinitialization == True then the latest table will be reinitialized
dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = eval(dbutils.widgets.get("force_reinitialization"))

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# Set timedelta allowance in hours between extraction_timestamps
dbutils.widgets.text("timedelta_allowance", "4")
TIME_DELTA_ALLOWANCE = int(dbutils.widgets.get("timedelta_allowance"))

# Set nbrows alert under
dbutils.widgets.text("nbrowsmin_before_alert", "25000000")
NBROWS_MIN_BEFORE_ALERT = int(dbutils.widgets.get("nbrowsmin_before_alert"))

log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)


# COMMAND ----------

# DBTITLE 1,Task values
INPUT_TABLE_LIST = dbutils.jobs.taskValues.get(
    taskKey="Ingest_SAP_Raw_Files_Into_LZ",
    key="table_output_list",
    default="",
    debugValue=[
        {
            "output_table_path": "dev_landingzone.sap_latecoere_ecc6.resb_stack",
            "table_name": "RESB",
        }
    ],
)
log.debug(f"INPUT_TABLE_LIST: {INPUT_TABLE_LIST}")
log.debug(f"TIME_DELTA_ALLOWANCE: {TIME_DELTA_ALLOWANCE}")
log.debug(f"NBROWS_MIN_BEFORE_ALERT: {NBROWS_MIN_BEFORE_ALERT}")

# COMMAND ----------

# DBTITLE 1,Globals
STACK_CATALOG = f"{PIPELINE_READ_ENV}_landingzone"
STACK_DOMAIN = "sap_latecoere_ecc6"

LATEST_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze"
LATEST_DOMAIN = "sap_latecoere_ecc6"

RESB_STACK_TABLE = f"{STACK_CATALOG}.{STACK_DOMAIN}.resb_stack"

RESB_LATEST_TABLE = f"{LATEST_CATALOG}.{LATEST_DOMAIN}.resb_latest"


# COMMAND ----------

# MAGIC %md
# MAGIC # Main
# MAGIC

# COMMAND ----------

# DBTITLE 1,Load tables
# Load RESB stack
df_resb_stack = spark.read.format("delta").table(RESB_STACK_TABLE)

# Load RESB latest table if exists
if table_utils.UnityCatalogCheckTableExists(RESB_LATEST_TABLE):
    try:
        df_resb_latest = spark.read.format("delta").table(RESB_LATEST_TABLE)
    except:
        log.info(f"the table or view {RESB_LATEST_TABLE} does not exists.")
        df_resb_latest = None
else:
    df_resb_latest = None

# COMMAND ----------

# DBTITLE 1,RESB stack Get Information
# get the last_existing_day_of_extraction in stack table
try:
    resb_last_existing_datetime_of_extraction_stack = df_resb_stack.select(
        f.max("extraction_timestamp")
    ).first()[0]
except:
    raise Exception("No extraction date found")
log.info(
    f"the last day of extraction in stack is : {resb_last_existing_datetime_of_extraction_stack}"
)

lower_bound = resb_last_existing_datetime_of_extraction_stack - timedelta(
    hours=TIME_DELTA_ALLOWANCE
)

resb_timestamps = (
    df_resb_stack.select(
        f.col("extraction_timestamp").alias("resb_extraction_timestamp")
    )
    .filter(df_resb_stack.extraction_timestamp > lower_bound)
    .distinct()
    .sort(f.col("resb_extraction_timestamp").desc())
)

log.info(f"RESB extraction_timestamps : ")
resb_timestamps.show()

# COMMAND ----------

# DBTITLE 1,RESB latest Get Information
# get the mode of last extraction_timestamp in latest table if exist
if df_resb_latest is not None:
    # get the last_existing_day_of_extraction in latest table
    try:
        resb_last_existing_datetime_of_extraction_latest = df_resb_latest.select(
            f.max("extraction_timestamp")
        ).first()[0]
    except:
        resb_last_existing_datetime_of_extraction_latest = "1970-01-01"
        raise Exception("No extraction date found")
else:
    resb_last_existing_datetime_of_extraction_latest = "1970-01-01"
log.info(
    f"the last day of extraction in latest is : {resb_last_existing_datetime_of_extraction_latest}"
)

# COMMAND ----------

# DBTITLE 1,RESB latest from stack
# Calculate the latest RESB table

# Do processing in any case to avoid incomplete processing
df_resb_latest = df_resb_stack.join(
    resb_timestamps,
    df_resb_stack.extraction_timestamp == resb_timestamps.resb_extraction_timestamp,
    "inner",
).drop(resb_timestamps.resb_extraction_timestamp)

# COMMAND ----------

# DBTITLE 1, drop duplicates

df_resb_latest = table_utils.drop_duplicates_by_order(
    df=df_resb_latest,
    columns=["ID"],
    order_col="extraction_timestamp",
    keep="last",
)

# COMMAND ----------

# DBTITLE 1,Quality check
nbrows_act = df_resb_latest.filter(f.col("file_name").like("%-ACT%")).count()
nbrows_noact = df_resb_latest.filter(f.col("file_name").like("%-NOACT%")).count()
total_rows = nbrows_act + nbrows_noact

if nbrows_act < NBROWS_MIN_BEFORE_ALERT:
    dbutils.jobs.taskValues.set("skip_run_metajob", True)
    dbutils.notebook.exit(
        "Error: The number of '-ACT' rows in df_resb_latest is less than {NBROWS_MIN_BEFORE_ALERT}."
    )
elif nbrows_noact < NBROWS_MIN_BEFORE_ALERT:
    dbutils.jobs.taskValues.set("skip_run_metajob", True)
    dbutils.notebook.exit(
        "Error: The number of '-NOACT' rows in df_resb_latest is less than {NBROWS_MIN_BEFORE_ALERT}."
    )
else:
    log.info(
        f"Number of rows in df_resb_latest is {nbrows_act} for '-ACT' and {nbrows_noact} for '-NOACT'."
    )

# COMMAND ----------

# DBTITLE 1,Save RESB latest
# write {RESB_LATEST_TABLE} as a delta table
log.info(
    f"About to save {total_rows} rows since {lower_bound} in the table {RESB_LATEST_TABLE}."
)
result = table_utils.save_table(
    dest_table=RESB_LATEST_TABLE,
    df=df_resb_latest,
    mode="overwrite",
    overwrite_schema=True,
)
log.info(f"Table {RESB_LATEST_TABLE} saved.")

# COMMAND ----------

# DBTITLE 1,Optimize RESB latest table
# OPTIMIZE ZORDER the RESB latest daily table by (mandt, rsnum, rspos, rsart)
log.info(f"About to OPTIMIZE the table {RESB_LATEST_TABLE}.")
OPTIMIZE_TABLE_SQL = (
    f"OPTIMIZE {RESB_LATEST_TABLE} ZORDER BY (mandt, rsnum, rspos, rsart)"
)
spark.sql(OPTIMIZE_TABLE_SQL)
log.info(f"Table {RESB_LATEST_TABLE} OPTIMIZED.")
