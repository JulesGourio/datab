import os
import requests
import json
import logging

from typing import Dict, List, Optional, Tuple, Any

from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql import Window
from pyspark.sql import functions as f
from databricks.sdk.runtime import dbutils
from datetime import datetime

from leap_utils.config import spark
from leap_utils.common import logger

logger.setup_applevel_logger()
LOGGER = logger.get_logger(__name__)

# CONSTANT
THE_ORIGIN = "1970-01-01"

# LEAP Entete file aka header
FILE_HEADER_PATH = f"s3://leap-s3-weeu1-prod/sap/0.parameters/LEAP_entete_table.csv"

SPECIFIC_TASKS_FOR_TABLE = {
    "EKPO": {"do_history_change_log": True},
    "EKKO": {"do_history_change_log": True},
    "EKET": {"do_history_change_log": True},
    "EKKN": {"do_history_change_log": True},
    "EKES": {"do_history_change_log": True},
    "MARC": {"do_history_change_log": False},
    "EBAN": {"do_history_change_log": False},
    "EBKN": {"do_history_change_log": False},
    "T052": {"do_history_change_log": True},
    "EKBE": {"do_history_change_log": False},
    "MDTB": {"do_specific_task": True},
    "RESB": {"do_specific_task": True},
}

DEFAULT_VALUES_DICT = {
    "do_history_change_log": False,
    "do_weekly": False,
    "do_specific_task": False,
    "do_latest_partitioning": False,
    "latest_partition_cols": "",
    "do_history_partitioning": False,
    "history_partition_cols": "",
    "do_weekly_partitioning": False,
    "weekly_partition_cols": "",
    "do_specific_task_MDTB": False,
    "do_specific_task_RESB": False,
}

POST_LATEST_JOBS_FOR_TABLE = {
    "2865348338307293": {"GLPCA": "525189333837904"},  # dev
    "3155144190025826": {"GLPCA": "148697349723372"},  # uat
    "1210945332048776": {"GLPCA": "957313140713129"},  # prod
}

PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")
FL804_END_PATH = f"s3://leap-s3-raw-weeu1-{PIPELINE_WRITE_ENV}/erp/sap_latecoere_ecc6/parameters/FL400-804_end.txt"

SAP_METAJOB_PER_DAY = {
    "2865348338307293": {
        "Monday": None,
        "Tuesday": "469343645735363",
        "Wednesday": "469343645735363",
        "Thursday": "469343645735363",
        "Friday": "469343645735363",
        "Saturday": "469343645735363",
        "Sunday": "469343645735363",
    },  # dev
    "3155144190025826": {
        "Monday": "188918887879005",
        "Tuesday": "1009693823631336",
        "Wednesday": "1009693823631336",
        "Thursday": "1009693823631336",
        "Friday": "1009693823631336",
        "Saturday": "1009693823631336",
        "Sunday": "1009693823631336",
    },  # uat
    "1210945332048776": {
        "Monday": "987993319730757",
        "Tuesday": "389302993315561",
        "Wednesday": "389302993315561",
        "Thursday": "389302993315561",
        "Friday": "389302993315561",
        "Saturday": "389302993315561",
        "Sunday": "389302993315561",
    },  # prod
}


def get_table_task_parameters(table_name: str) -> Dict[str, str]:
    """
    Get task parameters for a table (for handling specific cases in the job)

    :param table_name: wanted sap table
    :type table_name: str
    :return: Dictionary with a task parameter as key and its associated value
    :rtype: Dict[str, str]
    """
    global SPECIFIC_TASKS_FOR_TABLE
    global DEFAULT_VALUES_DICT
    if table_name in SPECIFIC_TASKS_FOR_TABLE:
        return DEFAULT_VALUES_DICT | SPECIFIC_TASKS_FOR_TABLE[table_name]
    else:
        return DEFAULT_VALUES_DICT


def get_post_latest_jobid(table_name: str) -> Optional[int]:
    """
    Function to get post latest jobid for a table_name in current workspace id

    :param table_name: table name
    :type table_name: str
    :return: jobid or None
    """
    jobid = None
    workspace_id = spark.conf.get("spark.databricks.clusterUsageTags.clusterOwnerOrgId")

    if workspace_id in POST_LATEST_JOBS_FOR_TABLE:
        jobs_dict = POST_LATEST_JOBS_FOR_TABLE[workspace_id]
        if table_name in jobs_dict:
            jobid = jobs_dict[table_name]

    return jobid


def get_sap_metajobid() -> Optional[int]:
    """
    Function to get the SAP metajob id in current workspace id

    :return: jobid or None
    """
    jobid = None
    workspace_id = spark.conf.get("spark.databricks.clusterUsageTags.clusterOwnerOrgId")

    if workspace_id in SAP_METAJOB_PER_DAY:
        jobs_dict = SAP_METAJOB_PER_DAY[workspace_id]
        current_day = datetime.now().strftime("%A")
        if current_day in jobs_dict:
            jobid = jobs_dict[current_day]

    return jobid


def extract_information_from_header_file(
    df_header: SparkDataFrame, sap_table_name: str
) -> Tuple[List[str], List[str]]:
    """
    Retrieve from header file information on SAP table schema and SAP table key

    :param df_header: Header table
    :type df_header: SparkDataFrame
    :param sap_table_name: SAP table name
    :type sap_table_name: str
    :return: (table schema in an ordered list, columns defining the sap table key in an ordered list)
    :rtype: Tuple[List[str], List[str]]
    """
    table_info = (
        df_header.filter(df_header.query_table == sap_table_name)
        .select("fields", "cles")
        .toPandas()
        .loc[0]
    )
    result_tuple = (
        table_info[en_tete_column].lower().replace(" ", "").replace("/", "_").split(",")
        for en_tete_column in ["fields", "cles"]
    )
    return result_tuple


def determine_ingestion_mode() -> str:
    if dbutils.widgets.get("tables") != "":
        return "TABLES"
    elif dbutils.widgets.get("input_file") != "":
        return "INPUT_FILE"
    else:
        raise ValueError(
            "Impossible to determine the ingestion mode as no tables "
            + "neither file has been set as task parameter"
        )


def input_file_path_parser(input_file: str) -> Tuple[str, str, str, str, str, str]:
    """
    Get the name of technical table name, table name, file_mode , details -> based on the acquisition format
    (e.g  : ZBI-BKPFBSAS, BSAS, Delta, YYYYMMDD-4)

    :param input_file: S3 path of the SAP file stored
    :type input_file: str
    :return: Info extracted from the input file path (file_name, folder_path, batch_id, table_name, file_mode)
    :return type: Tuple[str, str, str, str, str]
    """
    file_name = input_file.split("/")[-1]
    folder_path = "'" + os.path.dirname(input_file) + "'"

    file_info = file_name.split("_")
    batch_id = file_info[3]
    file_spec_list = file_info[2].split("-")

    if file_spec_list[2] == "F":
        file_mode = "F"
    else:
        file_mode = "Delta"

    table_name = file_spec_list[1]

    table_subelement = file_spec_list[3] if len(file_spec_list) > 3 else "N/A"

    return (file_name, folder_path, batch_id, table_name, file_mode, table_subelement)


def job_run_now(job_id: str, idempotency_token_id: str, job_parameters: Dict[str, Any]) -> Dict[str, Any]:
    """
    Trigger a Databricks job run using the Databricks Jobs API.

    This function sends a POST request to the Databricks Jobs API to start a job run with the specified
    `job_id`, `idempotency_token_id`, and `job_parameters`. It handles authentication using the Databricks
    workspace URL and API token, both retrieved from the Databricks environment.

    :param job_id: The ID of the Databricks job to run.
    :type job_id: str

    :param idempotency_token_id: A unique token to ensure idempotency of the job run request.
    :type idempotency_token_id: str

    :param job_parameters: A dictionary of parameters to pass to the Databricks job.
    :type job_parameters: Dict[str, Any]

    :return: A dictionary containing the response details including `status_code`, `job_id`, `run_id`,
             and `body` (which is the response content as a string). If the request is successful,
             `run_id` will contain the Databricks job run ID. On failure, `run_id` will be `"0"`.
    :rtype: Dict[str, Any]

    :example:
        >>> job_run_now("123", "unique-token-456", {"param1": "value1", "param2": "value2"})
        {
            'status_code': 200,
            'job_id': '123',
            'run_id': '789',
            'life_cycle_state': None,
            'headers': {'Content-Type': 'application/json'},
            'body': '{"run_id": "789", "state": "PENDING"}'
        }
    """

    databricks_url = spark.conf.get("spark.databricks.workspaceUrl")
    job_run_url = f"https://{databricks_url}/api/2.1/jobs/run-now"
    myToken = (
        dbutils.notebook.entry_point.getDbutils()
        .notebook()
        .getContext()
        .apiToken()
        .getOrElse(None)
    )
    if myToken is None:
        LOGGER.error("API token is missing.")
        return {
            "status_code": 401,
            "job_id": job_id,
            "run_id": "0",
            "life_cycle_state": None,
            "headers": {"Content-Type": "application/json"},
            "body": "Missing API token",
        }

    # Parameters for calling Databricks Job API
    headers = {
        "Authorization": f"Bearer {myToken}",
        "Content-Type": "application/json",
    }
    data = {
        "job_id": job_id,
        "idempotency_token": idempotency_token_id,
        "job_parameters": job_parameters,
    }

    # Calling Databricks Job API to submit Job for this S3 object
    response = requests.post(job_run_url, json=data, headers=headers)
    if response.status_code == 200:
        job_data = json.loads(response.text)
        if len(job_data) > 0:
            run_id = job_data["run_id"]
            return {
                "status_code": 200,
                "job_id": job_id,
                "run_id": run_id,
                "life_cycle_state": None,
                "headers": {"Content-Type": "application/json"},
                "body": str(response),
            }
        else:
            LOGGER.error(
                f"Request received empty response, job_run_url is {job_run_url} , data is {data}, response is {response}"
            )
            return {
                "status_code": 500,
                "job_id": job_id,
                "run_id": "0",
                "life_cycle_state": None,
                "headers": {"Content-Type": "application/json"},
                "body": str(response),
            }
    else:
        LOGGER.error(
            f"Request error, job_run_url is {job_run_url} , data is {data}, response is {response}"
        )
        return {
            "status_code": response.status_code,
            "job_id": job_id,
            "run_id": "0",
            "life_cycle_state": None,
            "headers": {"Content-Type": "application/json"},
            "body": str(response),
        }