# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to run Jobs Post Latest computation in specific cases
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - N/A
# MAGIC
# MAGIC **Input :**
# MAGIC - latest
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - ingestion pipeline
# MAGIC
# MAGIC
# MAGIC **Things to do:**
# MAGIC - N/A

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
import logging
import time

from typing import Tuple

# COMMAND ----------

# DBTITLE 1,Config LEAP Functions Imports
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# DBTITLE 1,Widgets definition
# Get pipeline write environment variable for output tables (dev / uat / prod)
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# COMMAND ----------

# DBTITLE 1,Config Pipeline Common Functions Imports
from ingestion.sap_latecoere_ecc6.sap_ingestion.common import (
    FILE_HEADER_PATH,
    get_post_latest_jobid,
    job_run_now,
)

# COMMAND ----------

# DBTITLE 1,Task values
INPUT_TABLE_LIST = dbutils.jobs.taskValues.get(
    taskKey="Ingest_SAP_Raw_Files_Into_LZ",
    key="table_output_list",
    default="",
    debugValue=[
        {
            "output_table_path": "dev_landingzone.sap_latecoere_ecc6.glpca_stack",
            "table_name": "GLPCA",
        }
    ],
)

# COMMAND ----------

# DBTITLE 1,Global variables & logger
LATEST_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze"
LATEST_DOMAIN = "sap_latecoere_ecc6"

log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

log.debug(f"INPUT_TABLE_LIST: {INPUT_TABLE_LIST}")

# COMMAND ----------

# DBTITLE 1,Functions definition
def process_single_table(table_name: str, existing_tables: str) -> Tuple[str, str]:
    """
    process job for a single table
    return Tuple ({job_id}, {run_id}) or (None, None)
    """
    if table_name in existing_tables:
        startTime = time.time()

        job_id = get_post_latest_jobid(table_name)
        # Do job here
        if job_id is not None:
            try:
                get_job_data = job_run_now(
                    job_id,
                    idempotency_token_id=str(int(time.time())),
                    job_parameters={},
                )
                status_code = get_job_data["status_code"]
                if status_code == 200:
                    run_id = get_job_data["run_id"]
                    return (f"{job_id}", f"{run_id}")
                else:
                    log.error(
                        f"Job run failed for table {table_name} with status code {status_code}."
                    )
                    return (f"{job_id}", "0")
            except Exception as e:
                log.error(
                    f"Exception occurred while running job for table {table_name}: {str(e)}"
                )
                return (f"{job_id}", "0")
        else:
            log.error(f"No job_id found for table {table_name}.")
            return ("0", "0")
    else:
        log.error(f"Table {table_name} is not in HEADER.")
        return (None, None)

# COMMAND ----------

# MAGIC %md
# MAGIC # Main

# COMMAND ----------

if __name__ == "__main__":
    # ------------------------------ PARSE ------------------------------
    # Retrieve tables from the "Pilotage table" to convert column name
    df_header = spark.read.options(header="True", delimiter=";").csv(FILE_HEADER_PATH)

    existing_tables = list(
        df_header.select("query_table").drop_duplicates().toPandas()["query_table"]
    )
    log.debug(f"Existing_tables: {existing_tables}")

    is_error_detected = False
    table_error_list = []

    # Loop through the list of dictionary
    for table in INPUT_TABLE_LIST:
        # Get the values of each key in the current dictionary
        table_name = table["table_name"]

        # Do something with the values
        log.info(f"Processing {table_name} ")
        job_id, run_id = process_single_table(table_name, existing_tables)
        if (run_id is not None) and (job_id is not None):
            if job_id == "0":
                log.info(f"No Job_Id to run for table {table_name} ")
            elif run_id != "0":
                log.info(
                    f"Processed successfully {table_name} , job_id {job_id}, run_id {run_id}"
                )
            else:
                log.error(
                    f"Error processing {table_name} , error running job_id {job_id}"
                )
                is_error_detected = True
                table_error_list.append(table_name)
        else:
            log.error(f"Processed unsuccessfully {table_name} -> Aborting")
            is_error_detected = True
            table_error_list.append(table_name)

# COMMAND ----------

# DBTITLE 1,Raise error if detected
if is_error_detected:
    log.critical(
        f"An error has been detected for at least one table(s) in : {table_error_list} see above !"
    )
    raise Exception()
