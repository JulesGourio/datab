# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to compute OPTIMIZE on stack , latest and history_change_log tables
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - N/A
# MAGIC
# MAGIC **Input :**
# MAGIC - stack tables list
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - ingestion pipeline
# MAGIC
# MAGIC
# MAGIC **Things done:**
# MAGIC - Optimize stack table ZORDER by ID
# MAGIC - Optimize history_change_log table ZORDER by ["ID", "Start_Validity", "End_Validity"] + data_columns
# MAGIC - Optimize latest table ZORDER by data_columns
# MAGIC
# MAGIC **Info:**
# MAGIC - ZORDER columns are limited to 9
# MAGIC

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
import logging

import time

from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# DBTITLE 1,Config LEAP Functions Imports
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils

# COMMAND ----------

# DBTITLE 1,Widgets definition
# Get pipeline write environment variable for output tables (dev / uat / prod)
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# COMMAND ----------

# DBTITLE 1,Config Pipeline Common Functions Imports
from ingestion.sap_latecoere_ecc6.sap_ingestion.common import (
    FILE_HEADER_PATH,
    extract_information_from_header_file,
)

# COMMAND ----------

# DBTITLE 1,Task values

INPUT_TABLE_LIST = dbutils.jobs.taskValues.get(
    taskKey="Ingest_SAP_Raw_Files_Into_LZ",
    key="table_output_list",
    default="",
    debugValue=[
        {"output_table_path": "dev_landingzone.sap_latecoere_ecc6.ekes_stack", "table_name": "EKES"}
    ],
)


# COMMAND ----------

# DBTITLE 1,Global variables & logger
LATEST_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze"
LATEST_DOMAIN = "sap_latecoere_ecc6"

HISTORY_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze"
HISTORY_DOMAIN = "sap_latecoere_ecc6"

log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# DBTITLE 1,Functions definition

def process_single_table(
    table_name: str,
    df_header: SparkDataFrame,
    existing_tables: str,
    input_table_path: str,
) -> str:
    """
    process ingestion of a single table
    return {output_table_path} if ok, or None if not
    """
    if table_name in existing_tables:
        startTime = time.time()

        (
            sap_schema_ordered_list,
            column_uid_list,
        ) = extract_information_from_header_file(
            df_header=df_header, sap_table_name=table_name
        )

        log.info(f"Column names are : {sap_schema_ordered_list}")
        log.info(f"UID key is : {column_uid_list}")

        # --------
        # OPTIMIZE ZORDER the stack table by ID
        startTime = time.time()
        log.info(f"About to OPTIMIZE the table {input_table_path}.")
        OPTIMIZE_TABLE_SQL = f"OPTIMIZE {input_table_path} ZORDER BY (ID)"
        log.debug(f"OPTIMIZE SQL QUERY : {OPTIMIZE_TABLE_SQL}")
        try:
            spark.sql(OPTIMIZE_TABLE_SQL)
        except:
            log.error(
                f"Table {input_table_path} has not been optimized, an error occured."
            )
            return None
        else:
            duration = time.time() - startTime
            log.info(f"Table {input_table_path} OPTIMIZED in {duration} seconds.")

        # --------
        # OPTIMIZE ZORDER the history_change_log table by columns in column_uid_list if table exists
        Unity_Catalog_Table_Name = f"{table_name.lower()}_history_change_log"
        if table_utils.UnityCatalogCheckTableExists(
            f"{HISTORY_CATALOG}.{HISTORY_DOMAIN}.{Unity_Catalog_Table_Name}"
        ):
            startTime = time.time()
            log.info(
                f"About to OPTIMIZE the table {HISTORY_CATALOG}.{HISTORY_DOMAIN}.{Unity_Catalog_Table_Name} ."
            )
            metadata_columns = ["ID", "Start_Validity", "End_Validity"]
            metadata_columns = metadata_columns[:9]
            columns = ", ".join(metadata_columns + [column for column in column_uid_list[:9-len(metadata_columns)]])
            OPTIMIZE_TABLE_SQL = f"OPTIMIZE {HISTORY_CATALOG}.{HISTORY_DOMAIN}.{Unity_Catalog_Table_Name} ZORDER BY ({columns})"
            log.debug(f"OPTIMIZE SQL QUERY : {OPTIMIZE_TABLE_SQL}")
            try:
                spark.sql(OPTIMIZE_TABLE_SQL)
            except AnalysisException as e:
                log.error(
                    f"Table {HISTORY_CATALOG}.{HISTORY_DOMAIN}.{Unity_Catalog_Table_Name} has not been optimized, an error occured during SQL query."
                )
                return None
            else:
                duration = time.time() - startTime
                log.info(
                    f"Table {HISTORY_CATALOG}.{HISTORY_DOMAIN}.{Unity_Catalog_Table_Name} OPTIMIZED in {duration} seconds."
                )

        # --------
        # OPTIMIZE ZORDER the latest table by columns in column_uid_list
        startTime = time.time()
        Unity_Catalog_Table_Name = f"{table_name.lower()}_latest"
        log.info(
            f"About to OPTIMIZE the table {LATEST_CATALOG}.{LATEST_DOMAIN}.{Unity_Catalog_Table_Name} ."
        )
        columns = ", ".join(column for column in column_uid_list[:9])
        OPTIMIZE_TABLE_SQL = f"OPTIMIZE {LATEST_CATALOG}.{LATEST_DOMAIN}.{Unity_Catalog_Table_Name} ZORDER BY ({columns})"
        log.debug(f"OPTIMIZE SQL QUERY : {OPTIMIZE_TABLE_SQL}")
        try:
            spark.sql(OPTIMIZE_TABLE_SQL)
        except AnalysisException as e:
            log.error(
                f"Table {LATEST_CATALOG}.{LATEST_DOMAIN}.{Unity_Catalog_Table_Name} has not been optimized, an error occured during SQL query."
            )
            return None
        else:
            duration = time.time() - startTime
            log.info(
                f"Table {LATEST_CATALOG}.{LATEST_DOMAIN}.{Unity_Catalog_Table_Name} OPTIMIZED in {duration} seconds."
            )
            return f"{LATEST_CATALOG}.{LATEST_DOMAIN}.{Unity_Catalog_Table_Name}"

    else:
        log.error(f"Table {table_name} is not in HEADER.")
        return None


# COMMAND ----------

# MAGIC %md
# MAGIC # Main

# COMMAND ----------

if __name__ == "__main__":
    # ------------------------------ PARSE ------------------------------
    # Retrieve tables from the "Pilotage table" to convert column name
    df_header = spark.read.options(header="True", delimiter=";").csv(FILE_HEADER_PATH)

    existing_tables = list(
        df_header.select("query_table").drop_duplicates().toPandas()["query_table"]
    )
    log.debug(f"Existing_tables: {existing_tables}")

    # Loop through the list of dictionaries
    for table in INPUT_TABLE_LIST:
        # Get the values of each key in the current dictionary
        table_name = table["table_name"]
        input_table_path = table["output_table_path"]

        # Do something with the values
        log.info(f"Processing {table_name} , from {input_table_path}")
        output_table_path = process_single_table(
            table_name, df_header, existing_tables, input_table_path
        )
        if output_table_path is not None:
            log.info(f"Processed successfully {table_name} , {output_table_path}")
        else:
            log.critical(
                f"Processed unsuccessfully {table_name} , {output_table_path} -> Aborting"
            )
            raise Exception()
