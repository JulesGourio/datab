# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to retrieve the latest version for each ID and remove removed ID from the latest version
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - latest
# MAGIC
# MAGIC **Input :**
# MAGIC - stack
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - ingestion pipeline
# MAGIC
# MAGIC
# MAGIC **Things to do:**
# MAGIC - Retrouver les infos depuis les fichiers meta plutôt que l'en tête file
# MAGIC - Placer dans les utils la fonction permettant de récupérer le snapshot
# MAGIC - Problème sur les tables ZBI

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
import logging
import time

import pyspark.sql.functions as f
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.utils import AnalysisException
from typing import List

# COMMAND ----------

# DBTITLE 1,Config LEAP Functions Imports
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils

# COMMAND ----------

# DBTITLE 1,Widgets definition
# Get pipeline write environment variable for output tables (dev / uat / prod)
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# If force_reinitialization == True then the stack table will be reinitialized
dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = eval(dbutils.widgets.get("force_reinitialization"))

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# COMMAND ----------

# DBTITLE 1,Config Pipeline Common Functions Imports
from ingestion.sap_latecoere_ecc6.sap_ingestion.common import (
    FILE_HEADER_PATH,
    THE_ORIGIN,
    extract_information_from_header_file,
)

# COMMAND ----------

# DBTITLE 1,Task values

INPUT_TABLE_LIST = dbutils.jobs.taskValues.get(
    taskKey="Ingest_SAP_Raw_Files_Into_LZ",
    key="table_output_list",
    default="",
    debugValue=[
        {
            "output_table_path": "dev_landingzone.sap_latecoere_ecc6.t001_stack",
            "table_name": "T001",
        }
    ],
)

# COMMAND ----------

# DBTITLE 1,Global variables & logger

LATEST_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze"
LATEST_DOMAIN = "sap_latecoere_ecc6"

log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

log.debug(f"INPUT_TABLE_LIST: {INPUT_TABLE_LIST}")
log.debug(f"FORCE_REINITIALIZATION: {FORCE_REINITIALIZATION}")

TABLE_LATEST_FIRST_COLS = {
    "stack_row_id": "BIGINT NOT NULL",
    "ID": "STRING NOT NULL",
    "extraction_timestamp": "TIMESTAMP",
    "ingestion_timestamp": "TIMESTAMP",
    "file_name": "STRING",
    "file_mode": "STRING",
    "table_name": "STRING",
    "file_modification_time": "TIMESTAMP"
}

TABLE_LATEST_PK_COLS = "ID"

# COMMAND ----------

# DBTITLE 1,Functions definition
def process_single_table(
    table_name: str,
    df_header: SparkDataFrame,
    existing_tables: List[str],
    input_table_path: str,
) -> str:
    """
    process latest for a single table
    return {output_table_path} if ok, or None if not
    """
    if table_name in existing_tables:
        start_time = time.time()

        # Read stack table
        df_table_stack = spark.read.table(input_table_path)

        (
            sap_schema_ordered_list,
            column_uid_list,
        ) = extract_information_from_header_file(
            df_header=df_header, sap_table_name=table_name
        )

        log.info(f"Column names are : {sap_schema_ordered_list}")
        log.info(f"ID key is : {column_uid_list}")

        unity_catalog_table_name = f"{table_name.lower()}_latest"
        latest_table_path = (
            f"{LATEST_CATALOG}.{LATEST_DOMAIN}.{unity_catalog_table_name}"
        )

        # get the last_existing_timestamp_of_extraction
        last_existing_timestamp_of_extraction = df_table_stack.select(
            f.max("extraction_timestamp")
        ).first()["max(extraction_timestamp)"]
        log.info(
            f"the last timestamp in Stack table is : {last_existing_timestamp_of_extraction}"
        )

        # Get the mode of extraction
        df_filtered = df_table_stack.filter(
            df_table_stack.extraction_timestamp == last_existing_timestamp_of_extraction
        )
        file_mode = list(
            df_filtered.select("file_mode").drop_duplicates().toPandas()["file_mode"]
        )

        if len(file_mode) > 1:
            raise Exception(
                f"Different SAP modes of extraction appears on table : {table_name} , modes are : {file_mode}"
            )

        # if file_mode == "FULL" then  latest_table = latest_extraction_timestamp in stack
        if file_mode[0] == "FULL":
            log.info(f"Stack table is in FULL mode")
            df_latest = df_filtered
        else:
            log.info(f"Stack table is in DELTA mode")

            # if latest_table already exists and FORCE_REINITIALIZATION == False then latest_table processed with MERGE INTO method
            # else latest_table processed with legacy method
            if (table_utils.UnityCatalogCheckTableExists(latest_table_path)) and (
                FORCE_REINITIALIZATION == False
            ):
                log.info(f"Using MERGE INTO method")

                # Read latest table
                df_table_latest = spark.read.table(latest_table_path)

                # get the last_existing_timestamp in latest table
                last_existing_timestamp_in_latest = df_table_latest.select(
                    f.max("extraction_timestamp")
                ).first()["max(extraction_timestamp)"]

                if last_existing_timestamp_in_latest is None:
                    last_existing_timestamp_in_latest = THE_ORIGIN

                log.info(
                    f"the last timestamp in {unity_catalog_table_name} is : {last_existing_timestamp_in_latest}"
                )

                df_from_last_run_to_current_date = df_table_stack.filter(
                    (
                        df_table_stack.extraction_timestamp
                        > last_existing_timestamp_in_latest
                    )
                )

                # For each ID in Dataframe keep the latest extraction_timestamp
                df_from_last_run_to_current_date_filtered = (
                    table_utils.get_latest_version_for_each_id_column(
                        df_from_last_run_to_current_date,
                        "ID",
                        "extraction_timestamp",
                    )
                )
                log.info(
                    f"{df_from_last_run_to_current_date_filtered.count()} rows to merge"
                )

                # MERGE INTO latest table
                try:
                    table_utils.merge_into(
                        df_source=df_from_last_run_to_current_date_filtered,
                        target_table=latest_table_path,
                        list_id_matching_columns=[TABLE_LATEST_PK_COLS],
                    ).display()
                except Exception as e:
                    log.error(
                        f"Table {latest_table_path} has not been created, an error occured during MERGE INTO."
                    )
                    all_target_cols = spark.read.table(f"{latest_table_path}").columns
                    log.error(
                        f"Dataframe cols : {df_from_last_run_to_current_date_filtered.columns}\n----\n"
                    )
                    log.error(f"Tables cols : {all_target_cols}\n----\n")
                    return None
                else:
                    duration = time.time() - start_time
                    log.info(f"Table {latest_table_path} merged in {duration} seconds.")
                    return f"{latest_table_path}"

            else:
                # get the lastest existing_timestamp where mode == FULL mode in the stack table
                max_date_full = (
                    df_table_stack.filter(df_table_stack.file_mode == "FULL")
                    .select(f.max("extraction_timestamp"))
                    .first()["max(extraction_timestamp)"]
                )
                if max_date_full:
                    df_from_last_full_to_current_date = df_table_stack.filter(
                        (df_table_stack.extraction_timestamp >= max_date_full)
                    )
                else:
                    df_from_last_full_to_current_date = df_table_stack

                # For each ID in Dataframe keep the latest extraction_timestamp
                df_latest = table_utils.get_latest_version_for_each_id_column(
                    df_from_last_full_to_current_date,
                    "ID",
                    "extraction_timestamp",
                )

        # Save the latest table from Dataframe df_latest
        try:
            table_utils.create_unity_catalog_table(
                catalog=LATEST_CATALOG,
                domain=LATEST_DOMAIN,
                table=unity_catalog_table_name,
                force_reinitialization=FORCE_REINITIALIZATION,
                cluster_cols=None,
                partition_col=None,
                primary_key_cols=TABLE_LATEST_PK_COLS,
                columns=TABLE_LATEST_FIRST_COLS,
                force_drop=False,
            )

            result = table_utils.save_table(
                dest_table=latest_table_path,
                df=df_latest,
                mode="overwrite",
                overwrite_schema=True,
            )
        except AnalysisException as e:
            log.error(
                f"Table {LATEST_CATALOG}.{LATEST_DOMAIN}.{unity_catalog_table_name} has not been created, an error occured during creation."
            )
            return None
        else:
            duration = time.time() - start_time
            log.info(
                f"Table {LATEST_CATALOG}.{LATEST_DOMAIN}.{unity_catalog_table_name} created in {duration} seconds."
            )

        # Add Primary Key if not exists
        pk_name = f"{unity_catalog_table_name}_pk"
        nb_cons = spark.sql(
            f"select count(*) from system.information_schema.table_constraints where table_catalog='{LATEST_CATALOG}' and table_schema='{LATEST_DOMAIN}' and table_name='{unity_catalog_table_name}' and constraint_name='{pk_name}' "
        ).first()[0]
        if nb_cons == 0:
            # set_table_column_not_null and add_table_primary_key
            try:
                # Before adding Primary Key, need to set columns NOT NULL
                table_latest_pk_cols_list = TABLE_LATEST_PK_COLS.split(",")
                for col in table_latest_pk_cols_list:
                    table_utils.set_table_column_not_null(
                        table_path=latest_table_path, column=col.strip()
                    )

                # add_primary_key
                table_utils.add_table_primary_key(
                    table_path=f"{latest_table_path}",
                    pk_name=f"{pk_name}",
                    columns=TABLE_LATEST_PK_COLS,
                )
            except AnalysisException as e:
                log.error(
                    f"Error adding PRIMARY KEY to table {LATEST_CATALOG}.{LATEST_DOMAIN}.{unity_catalog_table_name} "
                )

        return f"{LATEST_CATALOG}.{LATEST_DOMAIN}.{unity_catalog_table_name}"

    else:
        log.error(f"Table {table_name} is not in HEADER.")
        return None

# COMMAND ----------

# MAGIC %md
# MAGIC # Main

# COMMAND ----------

if __name__ == "__main__":
    # ------------------------------ PARSE ------------------------------
    # Retrieve tables from the "Pilotage table" to convert column name
    df_header = spark.read.options(header="True", delimiter=";").csv(FILE_HEADER_PATH)

    existing_tables = list(
        df_header.select("query_table").drop_duplicates().toPandas()["query_table"]
    )
    log.debug(f"Existing_tables: {existing_tables}")

    # Loop through the list of dictionariesé
    for table in INPUT_TABLE_LIST:
        # Get the values of each key in the current dictionary
        table_name = table["table_name"]
        input_table_path = table["output_table_path"]

        # Do something with the values
        log.info(f"Processing {table_name} , from {input_table_path}")
        output_table_path = process_single_table(
            table_name, df_header, existing_tables, input_table_path
        )
        if output_table_path is not None:
            log.info(f"Processed successfully {table_name} , to {output_table_path}")
        else:
            log.error(
                f"Processed unsuccessfully {table_name} , to {output_table_path} -> Aborting"
            )
            raise Exception()
