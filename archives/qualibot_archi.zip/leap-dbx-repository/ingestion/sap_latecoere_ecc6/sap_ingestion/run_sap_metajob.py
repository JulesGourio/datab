# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to run the SAP metajob at the end of last SAP ingestion V2
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - N/A
# MAGIC
# MAGIC **Input :**
# MAGIC - file FL804_END_PATH present and all tables are fresh
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - ingestion pipeline
# MAGIC
# MAGIC
# MAGIC **Things to do:**
# MAGIC - N/A

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
import logging

from typing import Tuple
from datetime import datetime

# COMMAND ----------

# DBTITLE 1,Config LEAP Functions Imports
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# DBTITLE 1,Widgets definition
# Get pipeline write environment variable for output tables (dev / uat / prod)
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("skip_file_check", "False")
SKIP_FILE_CHECK = dbutils.widgets.get("skip_file_check").lower() == "true"

dbutils.widgets.text("force_run_metajob", "False")
FORCE_RUN_METAJOB = dbutils.widgets.get("force_run_metajob").lower() == "true"

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# COMMAND ----------

# DBTITLE 1,Config Pipeline Common Functions Imports
from ingestion.sap_latecoere_ecc6.sap_ingestion.common import (
    FL804_END_PATH,
    get_sap_metajobid,
    job_run_now,
)

current_day = datetime.now().strftime("%A")
current_day_yyyy_mm_dd = datetime.now().strftime("%Y-%m-%d")

# COMMAND ----------

# DBTITLE 1,Global variables & logger
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------


# DBTITLE 1,Functions definition
def process_metajob() -> Tuple[str, str]:
    """
    process metajob
    return Tuple ({job_id}, {run_id}) or (None, None)
    """

    # Do job here
    job_id = get_sap_metajobid()
    if job_id is not None:
        try:
            get_job_data = job_run_now(
                job_id, idempotency_token_id=current_day_yyyy_mm_dd, job_parameters={}
            )
            status_code = get_job_data["status_code"]
            if status_code == 200:
                run_id = get_job_data["run_id"]
                return (f"{job_id}", f"{run_id}")
            else:
                log.error(f"Meta job run failed with status code {status_code}.")
                return (f"{job_id}", "0")
        except Exception as e:
            log.error(f"Exception occurred while running meta job: {str(e)}")
            return (f"{job_id}", "0")
    else:
        log.error("No job_id found for meta job.")
        return ("0", "0")


def file_exists(file_path: str) -> bool:
    """
    Checks if a file exists in an S3 location.

    :param file_path: The S3 path to the file to check (e.g., "s3://bucket-name/path/to/file").
    :type file_path: str

    :return: `True` if the file exists, `False` otherwise.
    :rtype: bool

    :example:
        >>> file_exists("s3://bucket-name/data/file.txt")
        True
    """
    try:
        dbutils.fs.head(file_path, 1)  # Tente de lire le début du fichier
        return True
    except Exception as e:
        return False


# COMMAND ----------

# MAGIC %md
# MAGIC # Main

# COMMAND ----------

if __name__ == "__main__":
    is_error_detected = False
    table_error_list = []

    # Query to check if all tables are fresh
    freshness_query = f"""
    SELECT table_name 
    FROM {PIPELINE_WRITE_ENV}_bronze.data_quality.freshness_checks_table 
    WHERE schema_name = 'sap_latecoere_ecc6' 
    AND table_name like "{PIPELINE_WRITE_ENV}_%"
    AND frequency IS NOT NULL 
    AND freshness_check = False
    """
    df = spark.sql(freshness_query)
    query_result_empty = df.count() == 0
    file_fl804_end_ok = file_exists(FL804_END_PATH) or SKIP_FILE_CHECK

    # if we force the run, ignore the checks
    if FORCE_RUN_METAJOB:
        log.warning(
            "⚠️ force_run_metajob is true — the freshness check and the file check will be ignored."
        )
        should_run_metajob = True
    else:
        should_run_metajob = query_result_empty and file_fl804_end_ok

    if should_run_metajob:
        log.info(f"Conditions are satisfied : launching SAP metajob ")
        try:
            job_id, run_id = process_metajob()
        except:
            is_error_detected = True
            log.exception("Error processing SAP metajob")
        if (run_id is not None) and (job_id is not None):
            if job_id == "0":
                log.info(f"No Job_Id to run")
            elif run_id != "0":
                log.info(
                    f"Processed successfully SAP metajob , job_id {job_id}, run_id {run_id}"
                )
                log.info(f"Deleting file {FL804_END_PATH} ")
                dbutils.fs.rm(FL804_END_PATH)
            else:
                log.error(
                    f"Error processing SAP metajob , error running job_id {job_id}"
                )
                is_error_detected = True
        else:
            log.error(f"Processed unsuccessfully SAP metajob -> Aborting")
            is_error_detected = True
    else:
        log.info(
            f"Conditions are not satisfied : metajob is not launched (tables not all fresh ou end file missing)"
        )

# COMMAND ----------

# DBTITLE 1,Raise error if detected
if is_error_detected:
    log.critical(f"An error has been detected , see above !")
    raise Exception()
