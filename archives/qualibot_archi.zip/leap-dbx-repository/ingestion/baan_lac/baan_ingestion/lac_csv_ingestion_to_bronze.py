# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # AVCORP RAW FILES INGESTION
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to ingest tables from S3 CSV files, these tables are extracted from Baan at Latecoere Canada (LAC).
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - lac ingestion.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC - s3://leap-s3-raw-avcorp-{reference_read_env}/erp/baan/transaction/lac_delta_inventory_level/active/
# MAGIC - s3://leap-s3-raw-avcorp-{reference_read_env}/erp/baan/transaction/lac_delta_recurring_revenue/active/
# MAGIC - s3://leap-s3-raw-avcorp-{reference_read_env}/erp/baan/transaction/lac_general_ledger_dimensions/active/
# MAGIC - s3://leap-s3-raw-avcorp-{reference_read_env}/erp/baan/transaction/lac_general_ledger_accounts/active/
# MAGIC - s3://leap-s3-raw-avcorp-{reference_read_env}/manual/depot/lac_provisions/
# MAGIC - s3://leap-s3-raw-avcorp-{reference_read_env}/erp/baan/transaction/lac_delta_general_ledger/active/
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC N/A
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_landingzone.baan_lac.inventorylevel_stack
# MAGIC - {pipeline_write_env}_landingzone.baan_lac.provisions_stack
# MAGIC - {pipeline_write_env}_landingzone.baan_lac.revenue_stack
# MAGIC - {pipeline_write_env}_landingzone.baan_lac.gldimensions_stack
# MAGIC - {pipeline_write_env}_landingzone.baan_lac.glaccounts_stack
# MAGIC - {pipeline_write_env}_landingzone.baan_lac.glpl_stack
# MAGIC
# MAGIC - {pipeline_write_env}_bronze.baan_lac.inventorylevel_latest
# MAGIC - {pipeline_write_env}_bronze.baan_lac.provisions_latest
# MAGIC - {pipeline_write_env}_bronze.baan_lac.revenue_latest
# MAGIC - {pipeline_write_env}_bronze.baan_lac.gldimensions_latest
# MAGIC - {pipeline_write_env}_bronze.baan_lac.glaccounts_latest
# MAGIC - {pipeline_write_env}_bronze.baan_lac.glpl_latest
# MAGIC
# MAGIC **Output Files Pipeline**
# MAGIC - s3://leap-s3-raw-avcorp-{reference_read_env}/archive/erp/baan/transaction/lac_delta_inventory_level/SCHEMA_{n}/
# MAGIC - s3://leap-s3-raw-avcorp-{reference_read_env}/archive/erp/baan/transaction/lac_delta_recurring_revenue/SCHEMA_{n}/
# MAGIC - s3://leap-s3-raw-avcorp-{reference_read_env}/archive/erp/baan/transaction/lac_general_ledger_dimensions/SCHEMA_{n}/
# MAGIC - s3://leap-s3-raw-avcorp-{reference_read_env}/archive/erp/baan/transaction/lac_general_ledger_accounts/SCHEMA_{n}/
# MAGIC - s3://leap-s3-raw-avcorp-{reference_read_env}/archive/manual/depot/lac_provisions/SCHEMA_{n}/
# MAGIC - s3://leap-s3-raw-avcorp-{reference_read_env}/archive/erp/baan/transaction/lac_delta_general_ledger/SCHEMA_{n}/
# MAGIC
# MAGIC   ***schema number is incremental and starts from 0***
# MAGIC
# MAGIC **CSV structure of known files**
# MAGIC ```
# MAGIC ```
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
import re
import os
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame
from typing import List, Tuple
from pyspark.sql.types import TimestampType

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("force_new_schema", "False")
FORCE_NEW_SCHEMA = dbutils.widgets.get("force_new_schema").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ### force_reinitialization Boolean
# MAGIC
# MAGIC force_reinitialization -> Used for force ingestion of all S3 files.

# COMMAND ----------

# If force_reinitialization == True then the stack table will be reinitialized
dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = dbutils.widgets.get("force_reinitialization").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

# Global variables
BUCKET_NAME = f"leap-s3-raw-avcorp-{REFERENCE_READ_ENV}"
ROOT_DIR_PREFIX = "erp/baan/"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

# regex describing filenames for inventorylevel
INVENTORYLEVEL_FILENAME_REGEX = r"^(\d{8})_(\d{6})_inventorylevel-.*.csv"

# regex describing filenames for provisions
PROVISIONS_FILENAME_REGEX = r"^(\d{8})_(\d{6})_provisions-F.csv"

# regex describing filenames for revenue
REVENUE_FILENAME_REGEX = r"^(\d{8})_(\d{6})_revenue-DATE_GRP.*.csv"

# regex describing filenames for gldimensions
GLDIMENSIONS_FILENAME_REGEX = r"^(\d{8})_(\d{6})_gldimensions-F.csv"

# regex describing filenames for glaccounts
GLACCOUNTS_FILENAME_REGEX = r"^(\d{8})_(\d{6})_glaccounts-F.csv"

# regex describing filenames for glpl (P&L)
GLPL_FILENAME_REGEX = r"^(\d{8})_(\d{6})_glpl-.*.csv"

# List of dictionaries, each one describing attributes of an expected category of file
FILES_ATTRS_DICT = [
    {
        "table_name": "inventorylevel",
        "file_regex": INVENTORYLEVEL_FILENAME_REGEX,
        "dir_prefix": "erp/baan/transaction/lac_delta_inventory_level/active/",
        "file_mode": "FULL",
        "csv_field_delimiter": ",",
        "file_expected_cols": [
            "AS_AT",
            "SKU",
            "ITEM_NO",
            "ITEM_GRP",
            "QUANTITY",
            "CURRENCY",
            "INVENTORY_TYPE",
            "WAREHOUSE",
            "GL_CODE",
        ],
        "primary_key": "SKU, WAREHOUSE",
        "notnull_cols": "AS_AT, SKU, WAREHOUSE",
    },
    {
        "table_name": "provisions",
        "file_regex": PROVISIONS_FILENAME_REGEX,
        "dir_prefix": "manual/depot/lac_provisions/",
        "file_mode": "FULL",
        "csv_field_delimiter": ",",
        "file_expected_cols": [
            "BAAN_CO",
            "AS_AT",
            "WH",
            "PROD_ORDER",
            "ITEM",
            "ITEM_GRP",
            "LOT_TRIMMED",
            "PRJ",
            "QTY",
            "STD_COST_EA",
            "STD_COST_EXTD",
        ],
        "primary_key": "ITEM, WH, LOT_TRIMMED, PROD_ORDER, PRJ",
        "notnull_cols": "AS_AT, ITEM, ITEM_GRP, WH",
    },
    {
        "table_name": "revenue",
        "file_regex": REVENUE_FILENAME_REGEX,
        "dir_prefix": "erp/baan/transaction/lac_delta_recurring_revenue/active/",
        "file_mode": "FULL",
        "csv_field_delimiter": ",",
        "file_expected_cols": [
            "AS_AT",
            "DATE_GRP",
            "MONTH_END_DATE",
            "GL_ACCT",
            "TDIM1",
            "TDIM2",
            "TDIM3",
            "TDIM4",
            "TDIM5",
            "AMOUNT_HC",
        ],
        "primary_key": "DATE_GRP, MONTH_END_DATE, GL_ACCT, TDIM1, TDIM2, TDIM3, TDIM4, TDIM5",
        "notnull_cols": "AS_AT, DATE_GRP, MONTH_END_DATE, AMOUNT_HC",
    },
    {
        "table_name": "glaccounts",
        "file_regex": GLACCOUNTS_FILENAME_REGEX,
        "dir_prefix": "erp/baan/transaction/lac_general_ledger_accounts/active/",
        "file_mode": "FULL",
        "csv_field_delimiter": ",",
        "file_expected_cols": ["GL_ACCT", "GL_DESC", "GL_STATUS"],
        "primary_key": "GL_ACCT",
        "notnull_cols": "GL_ACCT",
    },
    {
        "table_name": "gldimensions",
        "file_regex": GLDIMENSIONS_FILENAME_REGEX,
        "dir_prefix": "erp/baan/transaction/lac_general_ledger_dimensions/active/",
        "file_mode": "FULL",
        "csv_field_delimiter": ",",
        "file_expected_cols": ["DIM_TYPE", "DIM_CODE", "DIM_DESC", "DIM_STATUS"],
        "primary_key": "DIM_TYPE, DIM_CODE",
        "notnull_cols": "DIM_TYPE, DIM_CODE",
    },
    {
        "table_name": "glpl",
        "file_regex": GLPL_FILENAME_REGEX,
        "dir_prefix": "erp/baan/transaction/lac_delta_general_ledger/active/",
        "file_mode": "FULL",
        "csv_field_delimiter": ",",
        "file_expected_cols": [
            "AS_AT",
            "DATE_GRP",
            "MONTH_END_DATE",
            "GL_ACCT",
            "TDIM1",
            "TDIM2",
            "TDIM3",
            "TDIM4",
            "TDIM5",
            "AMOUNT_HC",
        ],
        "primary_key": "DATE_GRP, MONTH_END_DATE, GL_ACCT, TDIM1, TDIM2, TDIM3, TDIM4, TDIM5",
        "notnull_cols": "AS_AT, DATE_GRP, MONTH_END_DATE, AMOUNT_HC",
    },
]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

ARCHIVE_BUCKET_NAME = (
    f"leap-s3-raw-avcorp-{PIPELINE_WRITE_ENV}"  # Same ENV as output tables
)
ROOT_ARCHIVE_DIR_PREFIX = "archive/erp/baan/"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

LANDING_ZONE_CATALOG = f"{PIPELINE_WRITE_ENV}_landingzone"
LANDING_ZONE_SCHEMA = "baan_lac"
BRONZE_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze"
BRONZE_SCHEMA = "baan_lac"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

TABLE_STACK_FIRST_COLS = {
    "_meta_stack_row_id": "BIGINT GENERATED ALWAYS AS IDENTITY COMMENT 'STACK UNIQUE ID GENERATED ALWAYS AS IDENTITY'",
    "_meta_ID": "STRING",
    "_meta_extraction_timestamp": "TIMESTAMP",
    "_meta_ingestion_timestamp": "TIMESTAMP",
    "_meta_file_name": "STRING",
    "_meta_file_mode": "STRING",
    "_meta_file_path": "STRING",
}

TABLE_LATEST_FIRST_COLS = {
    "_meta_stack_row_id": "BIGINT COMMENT 'STACK UNIQUE ID GENERATED ALWAYS AS IDENTITY'",
    "_meta_ID": "STRING",
    "_meta_extraction_timestamp": "TIMESTAMP",
    "_meta_ingestion_timestamp": "TIMESTAMP",
    "_meta_file_name": "STRING",
    "_meta_file_mode": "STRING",
    "_meta_file_path": "STRING",
}

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

THE_ORIGIN = "1970-01-01"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"BUCKET_NAME is:  {BUCKET_NAME}")
log.info(f"ROOT_DIR_PREFIX is:  {ROOT_DIR_PREFIX}")
log.info(f"ARCHIVE_BUCKET_NAME is:  {ARCHIVE_BUCKET_NAME}")
log.info(f"ROOT_ARCHIVE_DIR_PREFIX is:  {ROOT_ARCHIVE_DIR_PREFIX}")
log.info(f"FORCE_REINITIALIZATION is:  {FORCE_REINITIALIZATION}")
log.info(f"LANDING_ZONE_CATALOG is:  {LANDING_ZONE_CATALOG}")
log.info(f"LANDING_ZONE_SCHEMA is:  {LANDING_ZONE_SCHEMA}")
log.info(f"BRONZE_CATALOG is:  {BRONZE_CATALOG}")
log.info(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.info(f"FORCE_NEW_SCHEMA is:  {FORCE_NEW_SCHEMA}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC
# MAGIC [USER GUIDE] - [DELETE BELOW BEFORE PROD]
# MAGIC
# MAGIC List of all data inputs, big and small, for the scripts, N.B. that manual lists etc are also data inputs.
# MAGIC
# MAGIC - File reads (check to see if this should not be done by an ingestion script)
# MAGIC - Table read (or specific SQL reads )
# MAGIC - Manual declarations - e.g. hard coded lists *that can't be avoided*
# MAGIC
# MAGIC N.B. Each input should have a markdown cell with a title & description followed by code cell to import
# MAGIC
# MAGIC
# MAGIC Coding practices
# MAGIC - All spark dataframes to start df_
# MAGIC - All pandas dataframes to start dfp_
# MAGIC - Ensure that dataframes are appropriately named: ensure the name is descriptive of content of the dataframe and don't over shorten then name
# MAGIC - Unless for specific performance reasons, import dataframes as "df_xx_raw" and perform preperations in the next stage
# MAGIC
# MAGIC [USER GUIDE] - [DELETE ABOVE BEFORE PROD]
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------


def get_last_schema_version(folder_info: List) -> int:
    """
    Get the last schema version from the given folder information.
    Given folder should be where all previous schema are located

    :param folder_info: List of folder information
    :type folder_info: List
    :return: Last schema version
    :rtype: int
    """
    if not folder_info:
        return 0
    df = spark.createDataFrame(folder_info)
    df = df.withColumn("version", f.regexp_extract("name", r"_(\d+)/$", 1).cast("int"))
    return df.agg(f.max("version")).collect()[0][0]


# COMMAND ----------


def is_same_schema(
    old_schema: List[str], new_schema: List[str], metadata_info: List[Tuple[str, str]]
) -> bool:
    """
    Check if two schema are the same after cleaning elements of the second schema.

    :param old_schema: List of column names in the old schema
    :type old_schema: List[str]
    :param new_schema: List of column names in the new schema
    :type new_schema: List[str]
    :return: Whether the schemas are the same or not
    :rtype: bool
    """
    strings_to_remove = [item[0] for item in metadata_info]
    cleaned_new_schema = sorted(
        [table_utils._cleanup_column_name(item) for item in new_schema]
    )
    cleaned_old_schema = sorted(
        [item for item in old_schema if item not in strings_to_remove]
    )
    return cleaned_old_schema == cleaned_new_schema


# COMMAND ----------


def cleanup_schema(
    schema: List[str], metadata_info: List[Tuple[str, str]]
) -> List[str]:
    """
    Cleanup schema column names.

    :param schema: List of column names
    :type schema: List[str]
    :return: cleaned schema
    :rtype: List[str]
    """
    strings_to_remove = [item[0] for item in metadata_info]
    cleaned_schema = [table_utils._cleanup_column_name(item) for item in schema]
    return cleaned_schema


# COMMAND ----------


def list_files_in_s3_bucket_with_prefix(
    bucket: str, prefix: str, recursive: bool = False
) -> List[str]:
    """
    return a list of files in a bucket and a given prefix in this bucket.

    :param bucket: bucket name
    :type bucket: str
    :param prefix: path after the bucket name, example :   erp/baan/
    :type prefix: str
    :param recursive: boolean meaning if the search apply to subfolders also
    :type recursive: bool
    :return: List of file names starting by the prefix and below, not the bucket name
    :rtype: List[str]
    """
    s3_folder_path = f"s3://{bucket}/{prefix}"
    files = []

    # need dbutils
    try:
        ls_result = dbutils.fs.ls(s3_folder_path)
    except:
        print(f"Error reading {s3_folder_path}")
        return []

    for file_info in ls_result:
        file_path = file_info.path
        file_name = file_info.name
        if file_info.isFile():
            files.append(file_path)
        elif file_info.isDir() and recursive:
            files.extend(
                list_files_in_s3_bucket_with_prefix(
                    bucket, file_path.replace(f"s3://{bucket}/", ""), recursive
                )
            )

    return files


# COMMAND ----------


def archive_file(
    source_bucket: str,
    source_prefix: str,
    dest_bucket: str,
    dest_prefix: str,
    filename: str,
) -> bool:
    """
    move a file to an archive folder.

    :param source_bucket: source bucket name
    :type source_bucket: str
    :param source_prefix: path after the bucket name, example :   erp/baan/
    :type source_prefix: str
    :param dest_bucket: destination bucket name
    :type dest_bucket: str
    :param dest_prefix: path after the bucket name, example :   archive/erp/baan/
    :type dest_prefix: str
    :param filename: file short name
    :type filename: str
    :return: True or False
    :rtype: bool
    """

    source_path = f"s3://{source_bucket}/{source_prefix}{filename}"
    dest_path = f"s3://{dest_bucket}/{dest_prefix}{filename}"
    try:
        dbutils.fs.mv(source_path, dest_path)
    except Exception as e:
        print(f"Erreur archiving file, error is : {e}")
        raise Exception()

    log.info(f"File {filename} archived to {dest_path}\n--")
    return True


# COMMAND ----------


def parse_and_convert_date_columns(
    df: SparkDataFrame, date_cols: List[str]
) -> SparkDataFrame:
    """
    Parse and convert date columns in the DataFrame to a standard timestamp format.

    This function iterates through the specified list of date columns in the input DataFrame
    (`df`), applying several predefined date formats to convert values into a consistent
    timestamp format (`TimestampType`). It handles various common date and datetime formats
    such as `yyyyMMdd`, `yyyy-MM-dd`, `MM/dd/yyyy`, and others, based on column length and
    content patterns.

    The conversion is done in a way that if the value in the column doesn't match any of
    the supported formats, the original value is preserved.

    :param df: The input DataFrame containing the date columns to be converted.
    :type df: pyspark.sql.DataFrame

    :param date_cols: A list of column names in the DataFrame that should be processed for date conversion.
    :type date_cols: List[str]

    :return: A new DataFrame with the date columns converted to timestamps.
    :rtype: pyspark.sql.DataFrame
    """
    # Liste des formats de dates et leurs conditions
    date_formats = [
        # Format yyyyMMdd
        (
            "yyyyMMdd",
            lambda col_: (f.length(col_) == 8) & (f.col(col_).rlike("^[0-9]{8}$")),
        ),
        # Format yyyy-MM-dd
        (
            "yyyy-MM-dd",
            lambda col_: (f.length(col_) == 10)
            & (f.col(col_).rlike("^[0-9]{4}-[0-9]{2}-[0-9]{2}$")),
        ),
        # Format dd/MM/yyyy
        (
            "dd/MM/yyyy",
            lambda col_: (
                (f.length(col_) == 10)
                & (f.col(col_).rlike("^[0-9]{2}/[0-9]{2}/[0-9]{4}$"))
                & (f.split(col_, "/")[1].cast("int") <= 12)  # Mois ≤ 12
            ),
        ),
        # Format MM/dd/yyyy
        (
            "MM/dd/yyyy",
            lambda col_: (
                (f.length(col_) == 10)
                & (f.col(col_).rlike("^[0-9]{2}/[0-9]{2}/[0-9]{4}$"))
                & (f.split(col_, "/")[0].cast("int") <= 12)  # Mois ≤ 12
                & (f.split(col_, "/")[1].cast("int") > 12)  # Jour > 12
            ),
        ),
        # Format yyyy-MM-dd HH:mm:ss
        (
            "yyyy-MM-dd HH:mm:ss",
            lambda col_: (
                (f.length(col_) == 19)
                & (
                    f.col(col_).rlike(
                        "^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}$"
                    )
                )
            ),
        ),
        # Format dd/MM/yyyy HH:mm:ss
        (
            "dd/MM/yyyy HH:mm:ss",
            lambda col_: (
                (f.length(col_) == 19)
                & (
                    f.col(col_).rlike(
                        "^[0-9]{2}/[0-9]{2}/[0-9]{4} [0-9]{2}:[0-9]{2}:[0-9]{2}$"
                    )
                )
                & (f.split(col_, "/")[1].cast("int") <= 12)  # Mois ≤ 12
            ),
        ),
        # Format MM/dd/yyyy HH:mm:ss
        (
            "MM/dd/yyyy HH:mm:ss",
            lambda col_: (
                (f.length(col_) == 19)
                & (
                    f.col(col_).rlike(
                        "^[0-9]{2}/[0-9]{2}/[0-9]{4} [0-9]{2}:[0-9]{2}:[0-9]{2}$"
                    )
                )
                & (f.split(col_, "/")[0].cast("int") <= 12)  # Mois ≤ 12
                & (f.split(col_, "/")[1].cast("int") > 12)  # Jour > 12
            ),
        ),
        # Format yyyy-MM-dd HH:mm:ss.SSSSSS
        (
            "yyyy-MM-dd HH:mm:ss.SSSSSS",
            lambda col_: (
                (f.length(col_) >= 20)
                & (f.col(col_).contains("-"))
                & (f.col(col_).contains(":"))
                & (f.col(col_).contains("."))
                & (
                    f.col(col_).rlike(
                        "^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{1,10}$"
                    )
                )
            ),
        ),
        # Format dd-MMM-yyyy HH:mm:ss (insensible à la casse)
        (
            "dd-MMM-yyyy HH:mm:ss",
            lambda col_: (
                (f.length(col_) == 20)
                & (f.col(col_).contains("-"))
                & (f.col(col_).contains(":"))
                & (
                    f.col(col_).rlike(
                        "^[0-9]{2}-[A-Za-z]{3}-[0-9]{4} [0-9]{2}:[0-9]{2}:[0-9]{2}$"
                    )
                )
                & (
                    f.lower(f.split(col_, "-")[1]).isin(
                        [
                            "jan",
                            "feb",
                            "mar",
                            "apr",
                            "may",
                            "jun",
                            "jul",
                            "aug",
                            "sep",
                            "oct",
                            "nov",
                            "dec",
                        ]
                    )
                )
            ),
        ),
        # Format dd-MMM-yyyy HH.mm.ss (insensible à la casse)
        (
            "dd-MMM-yyyy HH.mm.ss",
            lambda col_: (
                (f.length(col_) == 20)
                & (f.col(col_).contains("-"))
                & (f.col(col_).contains("."))
                & (
                    f.col(col_).rlike(
                        "^[0-9]{2}-[A-Za-z]{3}-[0-9]{4} [0-9]{2}.[0-9]{2}.[0-9]{2}$"
                    )
                )
                & (
                    f.lower(f.split(col_, "-")[1]).isin(
                        [
                            "jan",
                            "feb",
                            "mar",
                            "apr",
                            "may",
                            "jun",
                            "jul",
                            "aug",
                            "sep",
                            "oct",
                            "nov",
                            "dec",
                        ]
                    )
                )
            ),
        ),
        # Format dd-MMM-yyyy (insensible à la casse)
        (
            "dd-MMM-yyyy",
            lambda col_: (
                (f.length(col_) == 11)
                & (f.col(col_).rlike("^[0-9]{2}-[A-Za-z]{3}-[0-9]{4}$"))
                & (
                    f.lower(f.split(col_, "-")[1]).isin(
                        [
                            "jan",
                            "feb",
                            "mar",
                            "apr",
                            "may",
                            "jun",
                            "jul",
                            "aug",
                            "sep",
                            "oct",
                            "nov",
                            "dec",
                        ]
                    )
                )
            ),
        ),
        # Format dd-MMM-yy (insensible à la casse)
        (
            "dd-MMM-yy",
            lambda col_: (
                (f.length(col_) == 9)
                & (f.col(col_).rlike("^[0-9]{2}-[A-Za-z]{3}-[0-9]{2}$"))
                & (
                    f.lower(f.split(col_, "-")[1]).isin(
                        [
                            "jan",
                            "feb",
                            "mar",
                            "apr",
                            "may",
                            "jun",
                            "jul",
                            "aug",
                            "sep",
                            "oct",
                            "nov",
                            "dec",
                        ]
                    )
                )
            ),
        ),
        # Format d-MMM-yy (insensible à la casse)
        (
            "d-MMM-yy",
            lambda col_: (
                (f.length(col_) == 8)
                & (f.col(col_).rlike("^[0-9]{1}-[A-Za-z]{3}-[0-9]{2}$"))
                & (
                    f.lower(f.split(col_, "-")[1]).isin(
                        [
                            "jan",
                            "feb",
                            "mar",
                            "apr",
                            "may",
                            "jun",
                            "jul",
                            "aug",
                            "sep",
                            "oct",
                            "nov",
                            "dec",
                        ]
                    )
                )
            ),
        ),
    ]

    # Transformer chaque colonne spécifiée
    for col in date_cols:
        temp_col = f"{col}_temp"
        df = df.withColumn(temp_col, f.lit(None).cast(TimestampType()))

        # Appliquer les règles
        for fmt, condition in date_formats:
            df = df.withColumn(
                temp_col,
                f.when(condition(col), f.to_timestamp(col, fmt)).otherwise(
                    f.col(temp_col)
                ),  # Conserver la valeur initiale si aucun format ne correspond
            )
        df = df.withColumn(col, f.coalesce(f.col(temp_col), f.col(col))).drop(temp_col)
        df = df.withColumn(col, f.col(col).cast(TimestampType()))
    return df


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : search_for_files
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to search for files on certain criteria.
# MAGIC
# MAGIC **How to call:**
# MAGIC file_list = search_for_files(BUCKET_NAME, PREFIX, FILES_ATTRS_DICT[0] )
# MAGIC
# MAGIC **Output:**
# MAGIC List of dicts, each dict having following keys : "filename","filepath","fileprefix","filemode","tablename","timestamp"
# MAGIC

# COMMAND ----------


def search_for_files(
    bucket: str, dir_prefix: str, search_attributes: dict
) -> List[dict]:
    # Search files to process in s3://{bucket}/{dir_prefix} that match regex and return a list
    # Input : bucket -> type str
    # Input : dirprefix -> type str
    # Input : search_attributes -> type dict with following expected keys :
    #
    """
    {
    "table_name": "<table_name>",
    "file_regex": "<regex name>",
    "file_mode": "FULL|DELTA"
    }
    """
    # Output : List of dict
    # Example of Output :
    """
        [{
            "filename": "<filename>",  #ex: '20240513_033000_inventorylevel-F.csv'
            "filepath": "<filepath>",  #ex: 's3://leap-s3-raw-avcorp-dev/erp/baan/transaction/lac_delta_inventory_level/active/20240513_033000_inventorylevel-F.csv'
            "fileprefix": "<fileprefix>",  #ex: 'inventorylevel'
            "filekey": "<filekey>",  #ex: 'erp/baan/transaction/lac_delta_inventory_level/active/20240513_033000_inventorylevel-F.csv'
            "dirprefix": "<dirprefix>",  #ex: 'erp/baan/transaction/lac_delta_inventory_level/active/'
            "filemode": 'FULL' or 'DELTA',
            "tablename": "<bronze table_name>", #ex: 'inventorylevel'
            "timestamp": "<_meta_extraction_timestamp>",  #ex: '2024-02-22T10:16:20Z'
        },
        {
            "filename": "<filename>",
            "filepath": "<filepath>",
            "fileprefix": "<fileprefix>",
            "filekey": "<filekey>",
            "dirprefix": "<dirprefix>",
            "filemode": 'FULL' or 'DELTA',
            "tablename": "<bronze table_name>",
            "timestamp": "<_meta_extraction_timestamp>",
        }
        ]
    """

    # Get the list of all objects in the bucket and prefix
    file_list = list_files_in_s3_bucket_with_prefix(bucket, dir_prefix, recursive=True)

    # Filter file_list
    file_list = [
        file
        for file in file_list
        if re.match(search_attributes["file_regex"], os.path.basename(file))
    ]

    # Returned file list
    output_file_list = []

    for item in file_list:
        filename = os.path.basename(item)
        protocol, s3_path_rest = item.split("://", 1)
        bucket_name, filekey = s3_path_rest.split("/", 1)
        dirprefix = filekey.rsplit("/", 1)[0]

        match = re.match(search_attributes["file_regex"], filename)
        if match:
            date = match.group(1)
            timestamp = match.group(2)
            fileprefix = os.path.splitext(filename)[0].split("_")[2].split("-")[0]
            filemode = os.path.splitext(filename)[0].split("_")[2].split("-")[1]
            if filemode == "F":
                filemode = "FULL"
            else:
                filemode = "DELTA"
            # convert strings from format "YYYYMMDD" and "HHmmss" to timestamp
            last_modified_datetime = time.strptime(
                f"{date} {timestamp}", "%Y%m%d %H%M%S"
            )
            # convert timestamp to string
            last_modified_string = (
                time.strftime("%Y-%m-%dT%H:%M:%S", last_modified_datetime) + "Z"
            )
            log.debug(f"search_for_files(): Found file to process : {filename}.\n--")
            output_file_list.append(
                {
                    "filename": filename,
                    "filepath": item,
                    "fileprefix": fileprefix,
                    "filekey": filekey,
                    "dirprefix": dirprefix,
                    "filemode": filemode,
                    "tablename": search_attributes["table_name"],
                    "timestamp": last_modified_string,
                }
            )
        else:
            log.info(f"File ignored {filename} , bad format !!!\n--")

    return output_file_list


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : process_one_csv_file
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to load one CSV file, write stack table and add primary key.
# MAGIC
# MAGIC **How to call:**
# MAGIC process_one_csv_file(files_dict_list, file_expected_cols, input_table_name, input_table_primary_key_columns, input_table_notnull_columns, file_csv_field_delimiter )
# MAGIC
# MAGIC **Output:**
# MAGIC None if ERROR

# COMMAND ----------


def process_one_csv_file(
    file_dict: dict,
    file_expected_cols: List[str],
    input_table_primary_key_columns: str,
    input_table_notnull_columns: str,
    file_csv_field_delimiter: str,
    sql_id_generator: str,
    output_table_path: str,
    schema_version_number: str,
):
    """
    process on csv file at a time : read CSV, tranform, write table, archive CSV.

    :param file_dict: a structure containing CSV file informations
    :type file_dict: dict
    :param file_expected_cols: a list of columns expected to be found in the CSV file
    :type file_expected_cols: List[str]
    :param input_table_primary_key_columns: list of columns to define the primary key, must represent an unique row
    :type input_table_primary_key_columns: str
    :param input_table_notnull_columns: list of columns that must be not null
    :type input_table_notnull_columns: str
    :param file_csv_field_delimiter: CSV field separator
    :type file_csv_field_delimiter: str
    :param sql_id_generator: an expression to build the ID column "_meta_ID"
    :type sql_id_generator: str
    :param output_table_path: path to the destination table
    :type output_table_path: str
    :param schema_version_number: the schema version number for the destination table
    :type schema_version_number: str
    :return: None
    """

    global is_error_detected
    global file_error_list
    global table_error_list

    startTime = time.time()

    # Get file attributes from dict
    file_name = file_dict["filename"].strip()
    file_path = file_dict["filepath"].strip()
    file_mode = file_dict["filemode"].strip()
    file_modification_timestamp = file_dict["timestamp"]
    dirprefix = file_dict["dirprefix"].strip()
    dirprefix = f"{dirprefix}/"
    archive_file_dir = dirprefix.replace(BUCKET_NAME, ARCHIVE_BUCKET_NAME).replace(
        "/active/", "/"
    )
    archive_file_dir = f"archive/{archive_file_dir}SCHEMA_{schema_version_number}/"

    log.info(f"--------\nProcessing file {file_name}.\n--------\n")
    log.debug(f"--------\ndirprefix {dirprefix}.\n--------\n")
    log.debug(f"--------\narchive_file_dir {archive_file_dir}.\n--------\n")
    log.debug(f"--------\nsql_id_generator {sql_id_generator}.\n--------\n")
    log.debug(f"--------\nschema_version_number {schema_version_number}.\n--------\n")

    # A voir quand copy_into sera mis en prod
    # df = ingestion_utils.copy_into(
    #     output_stack_database=f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}",
    #     output_stack_table_name=table_name,
    #     columns_selection=new_schema,
    #     s3_path=file_path,
    #     metadata=metadata_statement,
    #     format_options=format_options,
    # )

    # Read CSV file
    df_raw = (
        spark.read.option("multiLine", "true")
        .option("delimiter", file_csv_field_delimiter)
        .option("header", True)
        .option("escape", '"')
        .option("inferSchema", "false")
        .option("nullValue", "")
        .csv(file_path)
    )

    # Cleanup column names
    columns = df_raw.columns
    for column in columns:
        df_raw = df_raw.withColumnRenamed(
            column, table_utils._cleanup_column_name(column)
        )

    # Convert _meta_extraction_timestamp to format `TimestampType`
    df_raw_ets = df_raw.withColumn(
        "_meta_extraction_timestamp",
        f.to_timestamp(f.lit(file_modification_timestamp), "yyyy-MM-dd'T'HH:mm:ss'Z'"),
    )

    # Add _meta_ingestion_timestamp metadata
    df_raw_its = df_raw_ets.withColumn(
        "_meta_ingestion_timestamp", f.current_timestamp()
    )

    # Add _meta_file_name metadata
    df_raw_fnam = df_raw_its.withColumn("_meta_file_name", f.lit(file_name))

    # Add _meta_file_mode metadata
    df_raw_fmod = df_raw_fnam.withColumn("_meta_file_mode", f.lit(file_mode))

    # Add _meta_file_path metadata
    df_raw_fpath = df_raw_fmod.withColumn("_meta_file_path", f.lit(file_path))

    # Prepare metadatas columns for reordering
    metadatas = []
    if "Id" in df_raw_fpath.columns:
        metadatas.append("Id")
    else:
        if sql_id_generator is not None:
            df_raw_fpath = df_raw_fpath.withColumn("_meta_ID", f.expr(sql_id_generator))
        else:
            df_raw_fpath = df_raw_fpath.withColumn("_meta_ID", f.lit(None))
        metadatas.append("_meta_ID")

    metadatas.extend(
        [
            "_meta_extraction_timestamp",
            "_meta_ingestion_timestamp",
            "_meta_file_name",
            "_meta_file_mode",
            "_meta_file_path",
        ]
    )
    # Prepare datas columns for reordering
    datas = [col for col in df_raw_fpath.columns if col not in metadatas]

    # Reorder columns
    df_reordered = df_raw_fpath.select(*(metadatas + datas))

    # Convert all columns containing timestamps, from type string to type to timestamp
    timestamp_cols = [
        cname
        for cname, dtype in df_reordered.dtypes
        if dtype == "string"
        and (
            "_date" in cname.lower()
            or "date_" in cname.lower()
            or "as_at" in cname.lower()
            or "time" in cname.lower()
            or cname in ("Created", "Modified", "Creation", "Modification")
        )
    ]

    log.info(f"Converting columns {timestamp_cols} from string to timestamp")
    df_reordered = parse_and_convert_date_columns(df_reordered, timestamp_cols)

    # Check requested columns
    all_req_columns = all(col in df_reordered.columns for col in file_expected_cols)
    if all_req_columns:
        log.info(f"Expected columns all OK : {file_expected_cols}")
    else:
        missing_cols = [
            col for col in file_expected_cols if col not in df_reordered.columns
        ]
        log.error(
            f"Table {table_name} has not expected columns: \n missing columns : {missing_cols} \n actual columns : {df_reordered.columns}"
        )
        df_reordered.printSchema()
        file_error_list.append(file_path)
        is_error_detected = True
        return None

    # Quality checks with great_expectations : uniqueness for input_table_primary_key_columns and notnull for input_table_notnull_columns
    # Raise an Exception if not pass the checks
    if (input_table_primary_key_columns) and (input_table_primary_key_columns != ""):
        gx_validation.gx_check_compound_uniqueness(
            df=df_raw,
            cols=input_table_primary_key_columns,
            validation_level="RED",
            pipeline_write_env=PIPELINE_WRITE_ENV,
            table_name=output_table_path,
        )

    notnull_columns = input_table_notnull_columns.split(",")
    for one_col in notnull_columns:
        gx_validation.gx_check_not_null(
            df=df_raw,
            col=one_col.strip(),
            validation_level="RED",
            pipeline_write_env=PIPELINE_WRITE_ENV,
            table_name=output_table_path,
        )

    # Check if _meta_extraction_timestamp already exists to avoid duplicates and if yes delete previous _meta_extraction_timestamp
    try:
        df_table_stack = spark.read.table(output_table_path)
        is_extraction_timestamp_existing = df_table_stack.filter(
            f.col("_meta_extraction_timestamp") == f.lit(file_modification_timestamp)
        ).first()
        if is_extraction_timestamp_existing:
            spark.sql(
                f"""DELETE FROM {output_table_path} WHERE _meta_extraction_timestamp = '{file_modification_timestamp}' """
            )
    except AnalysisException as e:
        log.error(
            f"Table {output_table_path} has not been created, an error occured during deletion of an already existing timestamp {file_modification_timestamp}."
        )
        file_error_list.append(file_path)
        is_error_detected = True
        return None

    # write csv to table
    # Append the stack table with Dataframe df_reordered
    try:
        result = table_utils.save_table(
            dest_table=output_table_path,
            df=df_reordered,
            mode="append",
            overwrite_schema=False,
            partition_col="_meta_extraction_timestamp",
            merge_schema=True,
        )
    except AnalysisException as e:
        log.error(
            f"Table {output_table_path} has not been saved, an error occured during creation.\nException is :{e}\n"
        )
        file_error_list.append(file_path)
        is_error_detected = True
        return None

    duration = time.time() - startTime
    log.info(
        f"--------\nData from file {file_name} has been written to Delta Lake table {output_table_path} in {duration} seconds.\n--------\n"
    )

    status = archive_file(
        BUCKET_NAME,
        dirprefix,
        ARCHIVE_BUCKET_NAME,
        archive_file_dir,
        file_name,
    )


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : process_csv_files_for_one_table
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to load CSV files, write stack tables and add primary key.
# MAGIC
# MAGIC **How to call:**
# MAGIC process_csv_files_for_one_table(files_dict_list, file_expected_cols, input_table_name, input_table_primary_key_columns, input_table_notnull_columns, file_csv_field_delimiter )
# MAGIC
# MAGIC **Output:**
# MAGIC None if ERROR

# COMMAND ----------


def process_csv_files_for_one_table(
    files_dict_list: List[dict],
    file_expected_cols: List[str],
    input_table_name: str,
    input_table_primary_key_columns: str,
    input_table_notnull_columns: str,
    file_csv_field_delimiter: str,
):
    """
    Process each file in the list of dict, reading CSV file and writing to a corresponding delta table
    Input : files_dict_list -> type "List of dict" where dict contains the following expected keys :
        {
            "filename": "<filename>",  #ex: '20240513_033000_inventorylevel-F.csv'
            "filepath": "<filepath>",  #ex: 's3://leap-s3-raw-avcorp-dev/erp/baan/transaction/lac_delta_inventory_level/active/20240513_033000_inventorylevel-F.csv'
            "fileprefix": "<fileprefix>",  #ex: 'inventorylevel'
            "filekey": "<filekey>",  #ex: 'erp/baan/transaction/lac_delta_inventory_level/active/20240513_033000_inventorylevel-F.csv'
            "dirprefix": "<dirprefix>",  #ex: 'erp/baan/transaction/lac_delta_inventory_level/active/'
            "filemode": 'FULL' or 'DELTA',
            "tablename": "<bronze table_name>", #ex: 'inventorylevel'
            "timestamp": "<_meta_extraction_timestamp>",  #ex: '2024-02-22T10:16:20Z'
        }
    Input : file_expected_cols -> type "List of str"
    Input : input_table_name -> type "str"
    Input : input_table_primary_key_columns -> type "str"
    Input : input_table_notnull_columns -> type "str"
    Input : file_csv_field_delimiter -> type "str"
    Output : None
    """

    global is_error_detected
    global file_error_list
    global table_error_list

    spark.conf.set("spark.sql.legacy.parseDoublesAsDecimal", False)
    spark.conf.set("spark.sql.legacy.multiLine", True)
    spark.conf.set("spark.sql.legacy.wholeFile", True)
    log.info(f"--------\nProcessing table {input_table_name}.\n--------\n")

    table_name = input_table_name + "_stack"
    # output table in Databricks Unity Catalog
    output_table_path = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}"
    output_table_path = output_table_path.strip().lower()

    # Generate "ID" field by joining 'table_keys' columns with '-'.
    if (input_table_primary_key_columns) and (input_table_primary_key_columns != ""):
        id_columns = ", ".join(
            f"IF(coalesce(rtrim(`{column}`),'')='', NULL, rtrim(`{column}`))"
            for column in input_table_primary_key_columns.replace(" ", "").split(",")
        )
        sql_id_generator = f"concat_ws('-', {id_columns})"
    else:
        sql_id_generator = None

    # Generate metadata statement for COPY INTO wrapper
    if (input_table_primary_key_columns) and (input_table_primary_key_columns != ""):
        metadata_statement = [
            (f"{sql_id_generator} AS _meta_ID", "STRING"),
        ]
    else:
        metadata_statement = [
            ("lit(None) AS _meta_ID", "STRING"),
        ]
    metadata_statement = metadata_statement + [
        (
            "to_timestamp(concat(split_part(_metadata.file_name, '_', 1), split_part(_metadata.file_name, '_', 2)), 'yyyyMMddHHmmss') AS _meta_extraction_timestamp",
            "TIMESTAMP",
        ),
        ("current_timestamp() AS _meta_ingestion_timestamp", "TIMESTAMP"),
        ("_metadata.file_name AS _meta_file_name", "STRING"),
        (
            "CASE WHEN split_part(split_part(_metadata.file_name, '_', 3), '-', 2) = 'F' THEN 'FULL' ELSE 'DELTA' END AS _meta_file_mode",
            "STRING",
        ),
        ("_metadata.file_path AS _meta_file_path", "STRING"),
    ]
    metadata_info = [
        (f"{entry.split(' AS ')[1]}", f"{data_type}")
        for entry, data_type in metadata_statement
    ]

    format_options = {
        "header": "True",
        "delimiter": ";",
        "mode": "PERMISSIVE",
        "escape": '"',
        "quote": '"',
    }

    # If table already exists, catch the schema of the existing table, except fields _meta* and name it old_schema
    if table_utils.UnityCatalogCheckTableExists(output_table_path):
        old_schema = spark.read.table(output_table_path).columns
        old_schema = [col for col in old_schema if not col.startswith("_meta")]
    else:
        old_schema = None

    # For new files catch the schema and name it new_schema
    base_prefix = files_dict_list[0]["dirprefix"]
    base_file = files_dict_list[0]["filepath"]
    new_schema = spark.read.csv(
        base_file, header=True, sep=file_csv_field_delimiter
    ).columns

    # Get last schema number based on last archived folder
    archive_file_dir = f"s3://{ARCHIVE_BUCKET_NAME}/archive/{base_prefix}/"
    archive_file_dir = archive_file_dir.replace("/active/", "/")
    try:
        schema_version_number = get_last_schema_version(dbutils.fs.ls(archive_file_dir))
    except:
        schema_version_number = 0
    log.debug(f"schema_version_number is {schema_version_number}")

    # Decision tree wether to continue or abort
    if not old_schema:
        lets_continue = True  # Table does not exists, create it
        log.info("Old schema is empty, ingesting new files as current schema.")
    elif is_same_schema(
        old_schema=old_schema, new_schema=new_schema, metadata_info=metadata_info
    ):
        lets_continue = True
        log.info(
            "Old and New schemas are identical, ingesting new files as current schema."
        )
    elif FORCE_NEW_SCHEMA:
        lets_continue = True
        log.info(
            "Old and New schemas are different and FORCE_NEW_SCHEMA == True, ingesting new files as a new schema. "
        )
        try:
            # move stack to stack_{n} in landing_zone
            spark.sql(
                f"ALTER TABLE {output_table_path} RENAME TO {output_table_path}_{schema_version_number}"
            )
        except:
            log.error(
                f"Table {output_table_path} has not been renamed to {output_table_path}_{schema_version_number}, an error occured."
            )
            table_error_list.append(table_name)
            is_error_detected = True
            return None
        else:
            log.info(
                f"Table {output_table_path} has been renamed to {output_table_path}_{schema_version_number}, cause new schema detected."
            )
            schema_version_number = schema_version_number + 1
    else:
        strings_to_remove = {item[0] for item in metadata_info}
        new_schema_cleaned = [
            table_utils._cleanup_column_name(item) for item in new_schema
        ]
        removed_items = set(old_schema).difference(strings_to_remove) - set(
            new_schema_cleaned
        )
        added_items = set(new_schema_cleaned) - set(old_schema).difference(
            strings_to_remove
        )
        raise Exception(
            f"""
Schema are not the same, here is the list of different column : \n
Columns removed in new schema : {removed_items}  \n
Columns added in new schema : {added_items} 
                        """
        )

    # If table does not exists, create it with first columns specially for the _meta_stack_row_id
    if (table_utils.UnityCatalogCheckTableExists(output_table_path) == False) or (
        FORCE_REINITIALIZATION == True
    ):
        # Create unity catalog table if it does not exist, or reinitialize table if param set to True
        try:
            table_utils.create_unity_catalog_table(
                catalog=LANDING_ZONE_CATALOG,
                domain=LANDING_ZONE_SCHEMA,
                table=table_name,
                force_reinitialization=FORCE_REINITIALIZATION,
                cluster_cols=None,
                partition_col="_meta_extraction_timestamp",
                columns=TABLE_STACK_FIRST_COLS,
                force_drop=True,
            )
        except AnalysisException as e:
            log.error(
                f"Table {output_table_path} has not been created, an error occured during creation.\nException is :{e}\n"
            )
            table_error_list.append(table_name)
            is_error_detected = True
            return None

    # Loop through the CSV files and ingest
    for file_dict in files_dict_list:
        process_one_csv_file(
            file_dict=file_dict,
            file_expected_cols=file_expected_cols,
            input_table_primary_key_columns=input_table_primary_key_columns,
            input_table_notnull_columns=input_table_notnull_columns,
            file_csv_field_delimiter=file_csv_field_delimiter,
            sql_id_generator=sql_id_generator,
            output_table_path=output_table_path,
            schema_version_number=schema_version_number,
        )


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : process_view_for_stack_table
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to provide a view giving union of all stack tables.
# MAGIC
# MAGIC **How to call:**
# MAGIC process_view_for_stack_table(input_table_name)
# MAGIC
# MAGIC **Output:**
# MAGIC - None
# MAGIC
# MAGIC **Globals**
# MAGIC -  is_error_detected
# MAGIC -  table_error_list

# COMMAND ----------


def process_view_for_stack_table(
    input_table_name: str,
):
    """
    Create a bronze view of stack tables, by doing the union of all stack tables

    Input : input_table_name -> type "str"
    Output : None
    """
    global is_error_detected
    global table_error_list

    table_name = input_table_name + "_stack"

    # output table in Databricks Unity Catalog
    output_table_path = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}"
    output_table_path = output_table_path.strip().lower()
    output_view_path = f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}"
    output_view_path = output_view_path.strip().lower()

    # Get table names from the source schema
    df_table_names = spark.sql(
        f"SHOW TABLES IN {LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}"
    )
    table_names = [
        row.tableName
        for row in df_table_names.collect()
        if row.tableName.startswith(table_name)
    ]
    if len(table_names) == 0:
        log.warning(
            f"View {output_view_path} not created, no stack table named : {input_table_name}"
        )
        return None

    if len(table_names) == 1:
        log.info(f"Creating view {output_view_path} for table : {table_names[0]}")
        select_query = f"SELECT * FROM {LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_names[0]}"
    else:
        log.info(f"Creating view {output_view_path} for tables : {table_names}")

        # get biggest schema
        all_table_schemas = {}
        for table in table_names:
            all_table_schemas[table] = spark.table(
                f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table}"
            ).schema
        sorted_schemas = sorted(
            all_table_schemas.values(), key=lambda x: len(x), reverse=True
        )
        biggest_schema = sorted_schemas[0]

        # Generate SQL to select data from each table with adjusted schemas
        select_queries = []
        for idx, table in enumerate(table_names):
            table_schema = spark.table(
                f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table}"
            ).schema
            adjusted_cols = []
            for f in biggest_schema:
                if f.name not in [col.name for col in table_schema]:
                    adjusted_cols.append(f"NULL AS {f.name}")
                elif f.name == "_meta_stack_row_id":
                    # Add unique value to _meta_stack_row_id based on table index
                    adjusted_cols.append(
                        f"concat('{idx}_', cast(_meta_stack_row_id as string)) AS _meta_stack_row_id"
                    )
                else:
                    adjusted_cols.append(f.name)
            select_query = f"SELECT {', '.join(adjusted_cols)} FROM {LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table}"
            select_queries.append(select_query)

        # Concatenate select queries with UNION
        select_query = " UNION ".join(select_queries)

    # Create or replace the view using SQL in the destination schema
    try:
        # Create the table view in bronze
        view_query = f"CREATE OR REPLACE VIEW {BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name} AS {select_query}"
        spark.sql(view_query)
    except AnalysisException as e:
        log.error(
            f"View {output_view_path} has not been created, an error occured during creation.\nException is :{e}\n"
        )
        is_error_detected = True
        table_error_list.append(table_name)
        return None


# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks - Functions

# COMMAND ----------


# N/A


# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Files Read
# MAGIC - Build the stack tables
# MAGIC - Files Archiving

# COMMAND ----------

# MAGIC %md
# MAGIC ### MAIN - Stack tables Processing
# MAGIC - Read files
# MAGIC - Build the stack tables from files

# COMMAND ----------

Found = False
is_error_detected = False
file_error_list = []
table_error_list = []

for attr_dict in FILES_ATTRS_DICT:
    # Search in S3 for files corresponding to those prefixes {FILE_PREFIX_LIST} and build a list of files to ingest
    table_name = attr_dict["table_name"]
    dir_prefix = attr_dict["dir_prefix"]
    csv_field_delimiter = attr_dict["csv_field_delimiter"]
    print(f"Searching files for table {table_name}")
    discovered_file_list_dict = search_for_files(BUCKET_NAME, dir_prefix, attr_dict)
    primary_key = attr_dict["primary_key"]
    notnull_cols = attr_dict["notnull_cols"]

    if len(discovered_file_list_dict) != 0:
        # Process the ingestion of files from the list
        file_expected_cols = attr_dict["file_expected_cols"]
        process_csv_files_for_one_table(
            files_dict_list=discovered_file_list_dict,
            file_expected_cols=file_expected_cols,
            input_table_name=table_name,
            input_table_primary_key_columns=primary_key,
            input_table_notnull_columns=notnull_cols,
            file_csv_field_delimiter=csv_field_delimiter,
        )
        Found = True

    process_view_for_stack_table(input_table_name=table_name)

if not Found:
    log.info(f"No file to process !!!\n--------\n")

if is_error_detected:
    error_list = set(table_error_list + file_error_list)
    log.critical(
        f"An error has been detected for at least one table(s) in : {error_list} see above !"
    )
    raise Exception()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1
# MAGIC
# MAGIC No specific preparation identified

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

## Quality Checks - Common Functions defined in leap_utils

#### validate_and_log_gx_results()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - Uniqueness
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Quality checks are done in file ingestion above
# in the section ## Inputs Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 2 - Not null expectation
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Quality checks are done in file ingestion above
# in the section ## Inputs Processing

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : process_single_latest_table
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is compute latest from stack.
# MAGIC
# MAGIC **How to call:**
# MAGIC process_single_latest_table(table_name, input_table_path, primary_key_columns, output_table_path )
# MAGIC
# MAGIC **Output:**
# MAGIC output_table_path if OK , None if ERROR

# COMMAND ----------


def process_single_latest_table(
    table_name: str,
    input_table_path: str,
    primary_key_columns: str,
    output_table_path: str,
) -> SparkDataFrame:
    """
    process a single latest table from a stack table.

    :param input_table_path: path to stack table
    :type input_table_path: str
    :param primary_key_columns: list of columns to define the primary key, must represent an unique row
    :type primary_key_columns: str
    :param output_table_path: path to latest table
    :type output_table_path: str
    :return: {SparkDataFrame} if ok, or None if not
    """

    global FORCE_REINITIALIZATION
    startTime = time.time()

    # Read stack table and catch the schema as new_schema
    try:
        df_table_stack = spark.read.table(input_table_path)
        new_schema = df_table_stack.columns

        # get the last_existing_timestamp_of_extraction
        last_existing_timestamp_of_extraction = df_table_stack.select(
            f.max("_meta_extraction_timestamp")
        ).first()["max(_meta_extraction_timestamp)"]
        log.info(
            f"the last timestamp in Stack table is : {last_existing_timestamp_of_extraction}"
        )
    except Exception as e:
        log.error(f"Error reading able {input_table_path}.")
        is_error_detected = True
        table_error_list.append(table_name)
        return None

    # If latest table already exists, catch the schema as old_schema
    output_table_name = f"{table_name.lower()}_latest"
    output_table_path = f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{output_table_name}"
    if table_utils.UnityCatalogCheckTableExists(output_table_path):
        old_schema = spark.read.table(output_table_path).columns
    else:
        old_schema = None
        FORCE_REINITIALIZATION = True  # Don't MERGE if table does not exists

    # Get the mode of extraction in the stack and check it is Unique
    df_filtered = df_table_stack.filter(
        df_table_stack._meta_extraction_timestamp
        == last_existing_timestamp_of_extraction
    )
    df_mode = df_filtered.select("_meta_file_mode").drop_duplicates()
    if df_mode.count() > 1:
        log.critical(
            f"Different SAP modes of extraction appears on table : {table_name}"
        )
        is_error_detected = True
        table_error_list.append(table_name)
        return None

    # Set Delta table clustered by "_meta_ID" if and only if there is a primary key
    if (primary_key_columns) and (primary_key_columns != ""):
        cluster_cols = "_meta_ID"
        primary_key_columns = "_meta_ID"
    else:
        cluster_cols = None
        primary_key_columns = None
        FORCE_REINITIALIZATION = True  # Don't MERGE if no primary key - Cannot process DELTA if no primary key

    if (old_schema is not None) and (
        not is_same_schema(
            old_schema=old_schema, new_schema=new_schema, metadata_info=[]
        )
    ):
        FORCE_REINITIALIZATION = True  # Don't MERGE if schema has changed

    # if df_mode[0][0] == "FULL" then  latest_table = latest_extraction_timestamp in stack
    if df_mode.collect()[0][0] == "FULL":
        log.info(f"Stack table is in FULL mode")
        df_latest = df_filtered  # Dataframe to save
    else:
        log.info(f"Stack table is in DELTA mode")

        if primary_key_columns is None:
            log.critical(
                f"Cannot process LATEST on table : {table_name} without identified primary key"
            )
            is_error_detected = True
            table_error_list.append(table_name)
            return None

        # if latest_table already exists and FORCE_REINITIALIZATION == False then latest_table processed with MERGE INTO method
        # else latest_table processed with legacy method
        if FORCE_REINITIALIZATION == False:
            log.info(f"Using MERGE INTO method")

            # Read latest table
            df_table_latest = spark.read.table(output_table_path)

            # get the last_existing_timestamp in latest table
            last_existing_timestamp_in_latest = df_table_latest.select(
                f.max("_meta_extraction_timestamp")
            ).first()["max(_meta_extraction_timestamp)"]

            if last_existing_timestamp_in_latest is None:
                last_existing_timestamp_in_latest = THE_ORIGIN

            log.info(
                f"the last timestamp in {output_table_name} is : {last_existing_timestamp_in_latest}"
            )

            df_from_last_run_to_current_date = df_table_stack.filter(
                (
                    df_table_stack._meta_extraction_timestamp
                    > last_existing_timestamp_in_latest
                )
            )

            # For each ID in Dataframe keep the latest _meta_extraction_timestamp
            df_from_last_run_to_current_date_filtered = (
                table_utils.get_latest_version_for_each_id_column(
                    df_from_last_run_to_current_date,
                    primary_key_columns,
                    "_meta_extraction_timestamp",
                )
            )  # Dataframe to MERGE
            log.info(
                f"{df_from_last_run_to_current_date_filtered.count()} rows to merge"
            )

            # MERGE INTO latest table - UPSERT MODE
            try:
                table_utils.merge_into(
                    df_from_last_run_to_current_date_filtered,
                    output_table_path,
                    [primary_key_columns],
                ).display()
            except Exception as e:
                log.error(
                    f"Table {output_table_path} has not been created, an error occured during MERGE INTO."
                )
                all_target_cols = [
                    x[0]
                    for x in spark.sql(f"DESCRIBE {output_table_path}")
                    .select("col_name")
                    .collect()
                ]
                log.error(
                    f"Dataframe cols : {df_from_last_run_to_current_date_filtered.columns}\n----\n"
                )
                log.error(f"Tables cols : {all_target_cols}\n----\n")
                is_error_detected = True
                table_error_list.append(table_name)
                return None
            else:
                duration = time.time() - startTime
                log.info(f"Table {output_table_path} merged in {duration} seconds.")
                return f"{output_table_path}"
        else:
            # get the lastest existing_timestamp where mode == FULL mode in the stack table
            max_date_full = (
                df_table_stack.filter(df_table_stack._meta_file_mode == "FULL")
                .select(f.max("_meta_extraction_timestamp"))
                .first()["max(_meta_extraction_timestamp)"]
            )
            if max_date_full:
                df_from_last_full_to_current_date = df_table_stack.filter(
                    (df_table_stack._meta_extraction_timestamp >= max_date_full)
                )
            else:
                df_from_last_full_to_current_date = df_table_stack

            # For each ID in Dataframe keep the latest _meta_extraction_timestamp
            df_latest = table_utils.get_latest_version_for_each_id_column(
                df_from_last_full_to_current_date,
                primary_key_columns,
                "_meta_extraction_timestamp",
            )  # Dataframe to save

    # Save the latest table from Dataframe df_latest
    try:
        result = table_utils.save_table(
            dest_table=output_table_path,
            df=df_latest,
            mode="overwrite",
            overwrite_schema=True,
            cluster_cols=cluster_cols,
        )
    except Exception as e:
        log.error(
            f"Table {output_table_path} has not been created, an error occured during creation.\nException is :{e}\n"
        )
        is_error_detected = True
        table_error_list.append(table_name)
        return None
    else:
        duration = time.time() - startTime
        log.info(f"Table {output_table_path} created in {duration} seconds.")

    # set PK
    if primary_key_columns is not None:
        # Add Primary Key if not exists and if defined for this table
        catalog, schema, table = output_table_path.split(".")
        pk_name = f"{output_table_name}_pk"
        nb_cons = spark.sql(
            f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
        ).first()[0]
        if nb_cons == 0:
            try:
                # Before adding Primary Key, need to set columns NOT NULL
                primary_key_columns_list = primary_key_columns.replace(" ", "").split(
                    ","
                )
                for col in primary_key_columns_list:
                    table_utils.set_table_column_not_null(
                        table_path=f"{output_table_path}", column=col.strip()
                    )
                # add_table_primary_key
                table_utils.add_table_primary_key(
                    table_path=f"{output_table_path}",
                    pk_name=f"{pk_name}",
                    columns=primary_key_columns,
                )
            except Exception as e:
                log.error(
                    f"Error adding PRIMARY KEY to table {output_table_path}.\nException is :{e}\n"
                )
                return None

    return f"{output_table_path}"


# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### MAIN - Latest tables Processing
# MAGIC - Read stack tables
# MAGIC - Build the latest tables from stack
# MAGIC

# COMMAND ----------

Found = False
is_error_detected = False
table_error_list = []

for attr_dict in FILES_ATTRS_DICT:
    # Process each table
    table_name = attr_dict["table_name"]
    primary_key = attr_dict["primary_key"]
    notnull_cols = attr_dict["notnull_cols"]
    log.debug(
        f"--------\ntable_name = '{table_name}', primary_key = '{primary_key}', notnull_cols = '{notnull_cols}'"
    )

    # input / output table in Databricks Unity Catalog
    input_table_Path = (
        f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}_stack"
    )
    input_table_Path = input_table_Path.strip().lower()
    output_table_Path = f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest"
    output_table_Path = output_table_Path.strip().lower()

    log.info(f"Processing input table : {input_table_Path}.")

    # Process stack table to latest table
    repeat = True
    while repeat:
        output_table_path = process_single_latest_table(
            table_name, input_table_Path, primary_key, output_table_Path
        )
        if output_table_path is not None:
            log.info(
                f"Processed successfully {table_name} , to {output_table_path}\n--------\n"
            )
            repeat = False
        else:
            if FORCE_REINITIALIZATION == False:
                FORCE_REINITIALIZATION = True
                log.error(
                    f"Processed unsuccessfully {table_name} , to {output_table_path} -> Retrying with reinitialization of the table\n--------\n"
                )
            else:
                log.error(
                    f"Processed unsuccessfully {table_name} , to {output_table_path} -> Aborting\n--------\n"
                )
                is_error_detected = True
                table_error_list.append(table_name)
                repeat = False

if is_error_detected:
    error_list = set(table_error_list)
    log.critical(
        f"An error has been detected for at least one table(s) in : {error_list} see above !"
    )
    raise Exception()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
