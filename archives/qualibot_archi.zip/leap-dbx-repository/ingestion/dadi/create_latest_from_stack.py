# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The purpose of this notebook is to retrieve the latest version for each UID and remove removed UID from the latest version 
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - `{WRITE_ENV}_bronze.dadi.{table_name}_latest`
# MAGIC
# MAGIC **Input :**  
# MAGIC   - `{WRITE_ENV}_landingzone.dadi.{table_name}_stack` 
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> Ingestion raw data dadi
# MAGIC
# MAGIC **Things done:** 
# MAGIC - calculate latest ID
# MAGIC

# COMMAND ----------

# DBTITLE 1,Input variables
WRITE_ENV = dbutils.jobs.taskValues.get(taskKey = "ingest_xml_raw_files_to_stack", key = "write_env", default = "", debugValue="dev")
READ_ENV = dbutils.jobs.taskValues.get(taskKey = "ingest_xml_raw_files_to_stack", key = "read_env", default = "", debugValue="dev")
TABLE_LIST = dbutils.jobs.taskValues.get(taskKey = "ingest_xml_raw_files_to_stack", key = "table_list", default = "", debugValue="")

# COMMAND ----------

# DBTITLE 1,Librairies
import logging
from pyspark.sql.types import StructType, StructField, StringType
from typing import List
from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, to_timestamp, current_timestamp, lit
from pyspark.sql.window import Window
from pyspark.sql import DataFrame as SparkDataFrame
import pyspark.sql.functions as f

from leap_utils.data_asset import table_utils


# Global variables
DEBUG = False
LANDING_ZONE_SCHEMA = f"{WRITE_ENV}_landingzone.dadi"
BRONZE_SCHEMA = f"{WRITE_ENV}_bronze.dadi"

# COMMAND ----------

# DBTITLE 1,Set up logger
import logging
from pyspark.sql.utils import AnalysisException
from leap_utils.common.logger import get_logger, setup_applevel_logger

setup_applevel_logger(log_level=logging.INFO, file_log_level=logging.INFO)

log = get_logger(module_name=__name__)

# COMMAND ----------

# DBTITLE 1,Function to save table
def create_unity_catalog_table(table_path: str, force_reinitialization: bool) -> None:
    """
    Function for creating a unity catalog if it does not exist. Also possible to reinitialize the table
    if :param force_reinitialization: is set to True

    :param table_path: Unity catalog path
    :type table_path: str
    :param force_reinitialization: Whether to reinitialize the table or not
    :type force_reinitialization: bool
    """
    # Create table if it does not exist
    spark.sql(
        f"CREATE TABLE IF NOT EXISTS {table_path} (stack_row_id BIGINT COMMENT 'STACK UNIQUE ID GENERATED ALWAYS AS IDENTITY', ID BIGINT, extraction_timestamp TIMESTAMP, ingestion_timestamp TIMESTAMP, file_name STRING, file_mode STRING, PRIMARY KEY (ID, extraction_timestamp) ) USING DELTA"
    )

    # Force reinitialization is param is True
    if force_reinitialization == True:
        spark.sql(f"DELETE FROM {table_path} ")
        log.info(f"Table {table_path} has been reinitialized")

# COMMAND ----------

# DBTITLE 1,Functions
def get_latest_version_for_every_uid_delta(df: SparkDataFrame, uid_col: str, extraction_date_col: str) -> SparkDataFrame:
    
    """
    extract the latest version for every uid 
    """

    window = Window.partitionBy(uid_col).orderBy(f.col(extraction_date_col).desc())
    df_latest = df.withColumn("row", f.row_number().over(window)).filter(f.col("row") == 1).drop("row")
    
    return df_latest
  
def check_table_exist(db_tbl_name:str) -> bool:

    """Check if table Exists or not"""

    try:
        a = spark.catalog.tableExists(db_tbl_name)
        return a
    except:
        print("check Catalog Name")
        print(db_tbl_name)
        return False

def check_table_if_good_format_else_drop(table_path: str) -> bool:
    """
    Stack tables have been redesigned with column stack_row_id
    Check if table Exists with good format else drop it
    """

    try:
        # Read stack table
        df=spark.read.table(table_path)
        column_list = df.columns
        if 'stack_row_id' in column_list :
            log.info(f"Table {table_path} is ok")
            return True
        else:
            # Drop table
            try:
                spark.sql(f"DROP TABLE {table_path} ")
                log.info(f"Table {table_path} dropped because was old format")
                return True
            except:
                log.error(f"Cannot drop Table {table_path}")
                return False        
    except:
        log.info(f"Table {table_path} does not exist")
        return True

# COMMAND ----------

# DBTITLE 1,Functions to process tables
def process_tables(tables: List[str]) -> List[str]:
    # process a list of tables from stack to latest and return the list of new tables
    # Input : tables -> List of str
    # Output : List of str

    # initialize new_tables list
    new_tables = []

    # Loop through the table list
    for table in tables:
        # Read XML Data file
        input_table_Path = table
        output_table_Path = table.replace('landingzone','bronze').replace('_stack','_latest')

        log.info(f"Processing input table : {input_table_Path}.--")

        # Read stack table
        df=spark.read.table(input_table_Path)

        # get stack table metadata columns
        df_cols = df.columns
        df_cols.remove('stack_row_id')

        # get the lastest ID
        df_latest = get_latest_version_for_every_uid_delta(df,'ID','extraction_timestamp')

        if DEBUG == True:
            display(df_latest,1000)

        # Save as delta table
        create_unity_catalog_table(
            table_path=output_table_Path, force_reinitialization=False
        )

        if check_table_if_good_format_else_drop(output_table_Path) == False:
            raise Exception(f"Table {output_table_Path} not in good format and cannot drop it !")

        table_utils.save_table(
            dest_table=output_table_Path,
            df=df_latest,
            mode="overwrite",
            overwrite_schema=True
        )

     
        log.info(
            f"Table {input_table_Path} merged into {output_table_Path}.\n--"
        )

        # Append new_tables list
        new_tables.append(output_table_Path)
    
    return new_tables

# COMMAND ----------

# DBTITLE 1,Main
# Main
# Process the list of tables

new_table_list = []

if len(TABLE_LIST) != 0 :
    # Process the tables from the list
    TABLE_LIST = [s.strip().lower() for s in TABLE_LIST]
    TABLE_LIST = list(set(TABLE_LIST))
    log.info(f"Tables to process : {TABLE_LIST}.\n--")
    new_table_list = process_tables(TABLE_LIST)
else:
    log.info(f"No table to process !!!\n--")

# COMMAND ----------

# DBTITLE 1,Set task value
# Set task values for retrieving it in other notebooks of the workflow
dbutils.jobs.taskValues.set(key = "write_env", value = WRITE_ENV)
dbutils.jobs.taskValues.set(key = "read_env", value = READ_ENV)
dbutils.jobs.taskValues.set(key = "table_list", value = new_table_list)

log.info(
    f"Table list passed to job : {new_table_list}\n--"
)
