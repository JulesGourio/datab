# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to ingest tables from S3, these tables are extracted from dadi sharepoint application. 
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - `{WRITE_ENV}_landingzone.dadi.{table_name}_stack`
# MAGIC
# MAGIC **Input :**  
# MAGIC   - `s3://leap-s3-raw-weeu1-{READ_ENV}/dadi/YYYYMMDD_HHMMSS_{table_name}_{delta_pattern}.xml` 
# MAGIC
# MAGIC **Archive file to :**  
# MAGIC   - `s3://leap-s3-raw-weeu1-{READ_ENV}/archive/apps/dadi/YYYYMMDD_HHMMSS_{table_name}_{delta_pattern}.xml` 
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> Ingestion raw data dadi
# MAGIC
# MAGIC **Things done:** 
# MAGIC - Parse XML
# MAGIC - Write delta table
# MAGIC - Archive input file
# MAGIC
# MAGIC **XML Structure:** 
# MAGIC
# MAGIC ```
# MAGIC -Applications
# MAGIC root
# MAGIC  |-- z:row: array (nullable = true)
# MAGIC  |    |-- element: struct (containsNull = true)
# MAGIC  |    |    |-- _VALUE: string (nullable = true)
# MAGIC  |    |    |-- _ows_Author: string (nullable = true)
# MAGIC  |    |    |-- _ows_Created: timestamp (nullable = true)
# MAGIC  |    |    |-- _ows_Created_x0020_Date: string (nullable = true)
# MAGIC  |    |    |-- _ows_FSObjType: string (nullable = true)
# MAGIC  |    |    |-- _ows_FileLeafRef: string (nullable = true)
# MAGIC  |    |    |-- _ows_FileRef: string (nullable = true)
# MAGIC  |    |    |-- _ows_ID: long (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_ApprobCourant: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Approvisionneur: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Branche: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_BudgetGlob: double (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_DemGestStock: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Division: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_ErpId: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Fourn: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_GroupeMarch: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Invites: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Motif: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Perimetre: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Societe: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_StatutCode: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_StatutLib: string (nullable = true)
# MAGIC  |    |    |-- _ows_LinkTitle: string (nullable = true)
# MAGIC  |    |    |-- _ows_Modified: timestamp (nullable = true)
# MAGIC  |    |    |-- _ows_PermMask: string (nullable = true)
# MAGIC  |    |    |-- _ows_Title: string (nullable = true)
# MAGIC  |    |    |-- _ows_UniqueId: string (nullable = true)
# MAGIC  |    |    |-- _ows__Level: long (nullable = true)
# MAGIC  |    |    |-- _ows__ModerationStatus: long (nullable = true)
# MAGIC  |    |    |-- _ows_owshiddenversion: long (nullable = true)
# MAGIC
# MAGIC -Items
# MAGIC root
# MAGIC  |-- z:row: array (nullable = true)
# MAGIC  |    |-- element: struct (containsNull = true)
# MAGIC  |    |    |-- _VALUE: string (nullable = true)
# MAGIC  |    |    |-- _ows_Created: timestamp (nullable = true)
# MAGIC  |    |    |-- _ows_FSObjType: string (nullable = true)
# MAGIC  |    |    |-- _ows_FileRef: string (nullable = true)
# MAGIC  |    |    |-- _ows_ID: long (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_CentreCout: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Commentaire: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_CompteCompt: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_DateBesoin: timestamp (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Demande: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Libelle: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Monnaie: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_OetCode: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_OtpCode: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_PrixUnitEst: double (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_PrixUnitNego: double (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_QteDemandee: double (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_UniteGest: string (nullable = true)
# MAGIC  |    |    |-- _ows_MetaInfo: string (nullable = true)
# MAGIC  |    |    |-- _ows_Modified: timestamp (nullable = true)
# MAGIC  |    |    |-- _ows_PermMask: string (nullable = true)
# MAGIC  |    |    |-- _ows_UniqueId: string (nullable = true)
# MAGIC  |    |    |-- _ows__Level: long (nullable = true)
# MAGIC  |    |    |-- _ows__ModerationStatus: long (nullable = true)
# MAGIC  |    |    |-- _ows_owshiddenversion: long (nullable = true)
# MAGIC
# MAGIC -Monitorings
# MAGIC root
# MAGIC  |-- z:row: array (nullable = true)
# MAGIC  |    |-- element: struct (containsNull = true)
# MAGIC  |    |    |-- _VALUE: string (nullable = true)
# MAGIC  |    |    |-- _ows_Created: timestamp (nullable = true)
# MAGIC  |    |    |-- _ows_FSObjType: string (nullable = true)
# MAGIC  |    |    |-- _ows_FileRef: string (nullable = true)
# MAGIC  |    |    |-- _ows_ID: long (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Action: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_AssigneA: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_CopyTo: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Demande: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Description: string (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Mail: long (nullable = true)
# MAGIC  |    |    |-- _ows_LAT_WFDA_Responsable: string (nullable = true)
# MAGIC  |    |    |-- _ows_Modified: timestamp (nullable = true)
# MAGIC  |    |    |-- _ows_PermMask: string (nullable = true)
# MAGIC  |    |    |-- _ows_UniqueId: string (nullable = true)
# MAGIC  |    |    |-- _ows__Level: long (nullable = true)
# MAGIC  |    |    |-- _ows__ModerationStatus: long (nullable = true)
# MAGIC  |    |    |-- _ows_owshiddenversion: long (nullable = true)
# MAGIC ```
# MAGIC
# MAGIC
# MAGIC **Prerequisites:** 
# MAGIC
# MAGIC Maven library : com.databricks:spark-xml_2.12:0.17.0

# COMMAND ----------

# DBTITLE 1,Librairies
import logging
import time
import os
import re
from pyspark.sql.types import StructType, StructField, StringType
from typing import List
from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, to_timestamp, current_timestamp, lit
from leap_utils.data_asset import table_utils

# Get read environment variable
dbutils.widgets.text("read_env", "prod")
READ_ENV = dbutils.widgets.get("read_env")

# Get write environment variable
dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

# Get file_prefix_list environment variable
dbutils.widgets.text("file_prefix_list", "Applications, Items")
FILE_PREFIX_LIST = (
    None
    if dbutils.widgets.get("file_prefix_list") == ""
    else dbutils.widgets.get("file_prefix_list").replace(" ", "").split(",")
)

# If force_reinitialization == True then the stack table will be reinitialized
dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = eval(dbutils.widgets.get("force_reinitialization"))

# Global variables
HEADER_READ_ENV = "prod"
DEBUG = False
BUCKET_NAME = f"leap-s3-raw-weeu1-{READ_ENV}"
ARCHIVE_BUCKET_NAME = f"leap-s3-raw-weeu1-{READ_ENV}"
PREFIX = "apps/dadi/"
ARCHIVE_PREFIX = "archive/apps/dadi/"
LANDING_ZONE_SCHEMA = f"{WRITE_ENV}_landingzone.dadi"
BRONZE_SCHEMA = f"{WRITE_ENV}_bronze.dadi"
TABLE_LIST = []

# set up context
sqlContext.sql("set spark.sql.caseSensitive=true")

# COMMAND ----------

# DBTITLE 1,Set up logger
import logging
from pyspark.sql.utils import AnalysisException
from leap_utils.common.logger import get_logger, setup_applevel_logger

setup_applevel_logger(log_level=logging.INFO, file_log_level=logging.INFO)

log = get_logger(module_name=__name__)

# COMMAND ----------

# DBTITLE 1,Functions
def delete_local_file(fileName: str):
    # receive a file_name without path as input
    # remove the local file in /tmp
    local_path = f"/tmp/{fileName}"
    dbutils.fs.rm(f"file:{local_path}")


def archive_file(
    source_bucket: str,
    source_prefix: str,
    dest_bucket: str,
    dest_prefix: str,
    filename: str,
) -> bool:
    # move file to archive folder
    # Input : source_bucket -> str
    # Input : source_prefix -> str
    # Input : dest_bucket -> str
    # Input : dest_prefix -> str
    # Input : filename -> str
    # Output : bool

    source_path = f"s3://{source_bucket}/{source_prefix}{filename}"
    dest_path = f"s3://{dest_bucket}/{dest_prefix}{filename}"
    try:
        dbutils.fs.mv(source_path, dest_path)
    except Exception as e:
        print(f"Erreur dans archivage fichier : {e}")
        exit(1)
        return False
    
    log.info(f"File {filename} archived to {dest_path}\n--")
    return True


def create_unity_catalog_table(table_path: str, force_reinitialization: bool) -> None:
    """
    Function for creating a unity catalog if it does not exist. Also possible to reinitialize the table
    if :param force_reinitialization: is set to True

    :param table_path: Unity catalog path
    :type table_path: str
    :param force_reinitialization: Whether to reinitialize the table or not
    :type force_reinitialization: bool
    """
    # Create table if it does not exist
    spark.sql(
        f"CREATE TABLE IF NOT EXISTS {table_path} (stack_row_id BIGINT GENERATED ALWAYS AS IDENTITY COMMENT 'STACK UNIQUE ID GENERATED ALWAYS AS IDENTITY', ID BIGINT, extraction_timestamp TIMESTAMP, ingestion_timestamp TIMESTAMP, file_name STRING, file_mode STRING, PRIMARY KEY (ID, extraction_timestamp) ) USING DELTA"
    )

    # Force reinitialization is param is True
    if force_reinitialization == True:
        spark.sql(f"DELETE FROM {table_path} ")
        log.info(f"Table {table_path} has been reinitialized")


def list_files_in_s3_bucket_with_prefix(bucket: str, prefix: str) -> List[str]:
    # List files under s3://{bucket}/{prefix} and return a list
    # Input : bucket -> str
    # Input : prefix -> str
    # Output : List of str
    s3_folder_path = f"s3://{bucket}/{prefix}"

    # need dbutils
    files = dbutils.fs.ls(s3_folder_path)

    # Create a list of attribute file.name for each file in the list
    file_names = [file.name for file in files]

    # Return the list
    return file_names


def search_for_xml_files(
    bucket: str, dir_prefix: str, files_prefix_list: List[str]
) -> List[dict]:
    # Search files to process in s3://{bucket}/{dir_prefix} that match prefix list in files_prefix_list and return a list
    # Input : bucket -> str
    # Input : dirprefix -> str
    # Input : files_prefix_list -> List of str
    # Output : List of dict
    regex_pattern = r"^(\d{8})_(\d{6})_(\w+)_([\w\-]+)\.xml$"

    # Get the list of all objects in the bucket and prefix
    file_list = list_files_in_s3_bucket_with_prefix(bucket, dir_prefix)

    # Filter file_list
    file_list = [
        file
        for file in file_list
        if any(file_prefix in file for file_prefix in files_prefix_list)
    ]

    # Returned file list
    xml_file_list = []

    for filename in file_list:
        match = re.match(regex_pattern, filename)
        if match:
            date = match.group(1)
            timestamp = match.group(2)
            fileprefix = match.group(3)
            filemode = match.group(4)
            if filemode == "F":
                filemode = "FULL"
            else:
                filemode = "DELTA"
            filepath = os.path.join(f"s3://{bucket}", dir_prefix, filename)
            # convert strings from format "YYYYMMDD" and "HHmmss" to timestamp
            last_modified_datetime = time.strptime(
                f"{date} {timestamp}", "%Y%m%d %H%M%S"
            )
            # convert timestamp to string
            last_modified_string = (
                time.strftime("%Y-%m-%dT%H:%M:%S", last_modified_datetime) + "Z"
            )
            log.info(f"Found file to process : {filename}.\n--")
            xml_file_list.append(
                {
                    "filename": filename,
                    "filepath": filepath,
                    "fileprefix": fileprefix,
                    "filemode": filemode,
                    "timestamp": last_modified_string,
                }
            )
        else:
            log.info(f"File ignored {filename} , bad format !!!\n--")

    return xml_file_list


def process_xml_files(files_dict: List[dict]):
    """
    Process each file in the list of dict, reading XML file and writing to a corresponding delta table
    Input : files_dict -> List of dict
                {
                    "filename": xxx,
                    "filepath": xxx,
                    "fileprefix": xxx,
                    "filemode": filemode,
                    "timestamp": "%Y-%m-%dT%H:%M:%S"
                }
    Output : None
    """

    # Loop through the XML files
    for file_dict in files_dict:
        # Read XML Data file
        spark.conf.set("spark.sql.legacy.parseDoublesAsDecimal", False)
        spark.conf.set("spark.sql.legacy.multiLine", True)
        spark.conf.set("spark.sql.legacy.wholeFile", True)

        filename = file_dict["filename"].strip()
        filepath = file_dict["filepath"].strip()
        filemode = file_dict["filemode"].strip()

        # table_name will be based on fileprefix
        table_name = file_dict["fileprefix"]

        # output table in Databricks Unity Catalog
        output_table_Path = f"{LANDING_ZONE_SCHEMA}.{table_name}_stack"
        output_table_Path = output_table_Path.strip().lower()

        # Get file timestamp
        fileModificationTS = file_dict["timestamp"]

        # Read XML file
        df = (
            spark.read.format("com.databricks.spark.xml")
            .options(rowTag="rs:data")
            .option("mode", "PERMISSIVE")
            .option("inferSchema", "true")
            .option("nullValue", "")
            .load(filepath)
        )

        # Read root fields : "z:row" as new column "entry" which is an array of records
        # Add ingestion_timestamp metadata
        df = df.selectExpr(
            "current_timestamp() as ingestion_timestamp",
            "`z:row` as entry",
        )

        # Convert extraction_timestamp to format `TimestampType`
        df = df.withColumn(
            "extraction_timestamp",
            to_timestamp(lit(fileModificationTS), "yyyy-MM-dd'T'HH:mm:ss'Z'"),
        )

        # Add file_name and file_mode metadata
        df = df.withColumn("file_name", lit(filename),).withColumn(
            "file_mode",
            lit(filemode),
        )

        # Explode array "entry"
        exploded_df = (
            df.selectExpr(
                "extraction_timestamp",
                "ingestion_timestamp",
                "file_name",
                "file_mode",
                "entry",
            )
            .withColumn("exploded_content", explode("entry"))
            .drop("entry")
        )

        nbItems = exploded_df.count()
        if nbItems <= 0:
            continue
        log.info(
            f"File {filename}, extraction_time : {fileModificationTS}, {nbItems} records"
        )

        # Read fields under content.properties for each elem in entry, drop duplicate column Id
        data_df = exploded_df.selectExpr(
            "extraction_timestamp",
            "ingestion_timestamp",
            "file_name",
            "file_mode",
            "exploded_content.*",
        )

        # Rename all columns beginning by "_ows_"
        for cname in data_df.columns:
            if cname.startswith("_ows_"):
                data_df = data_df.withColumnRenamed(cname, cname.replace("_ows_", ""))

        # Drop unwanted columns
        data_df = data_df.drop("_VALUE", "LAT_WFDA_Age")

        # Convert all columns containing timestamps, from type string to type to timestamp
        timestamp_cols = [
            cname
            for cname, dtype in data_df.dtypes
            if dtype == "string"
            and ("_date" in cname.lower() or cname in ("Created", "Modified"))
        ]
        for cname in timestamp_cols:
            data_df = data_df.withColumn(
                cname, to_timestamp(cname, "yyyy-MM-dd'T'HH:mm:ss'Z'")
            )

        # Set up "ID" as first column of Table
        data_df_cols = data_df.columns
        data_df_cols.remove("ID")
        updated_data_df_cols = ["ID"] + data_df_cols
        data_df = data_df.select(*updated_data_df_cols)

        # Save as delta table
        create_unity_catalog_table(
            table_path=output_table_Path, force_reinitialization=FORCE_REINITIALIZATION
        )

        spark.sql(
            f"""DELETE FROM {output_table_Path} WHERE extraction_timestamp = '{fileModificationTS}' """
        )

        table_utils.save_table(
            dest_table=output_table_Path,
            df=data_df,
            mode="append",
            overwrite_schema=False,
            merge_schema=True
        )

        # Remove the local file
        delete_local_file(filename)

        # Append table list
        TABLE_LIST.append(output_table_Path)

        log.info(
            f"Data from file {filename} has been written to Delta Lake table {table_name}_stack.\n--"
        )

        status = archive_file(
            BUCKET_NAME, PREFIX, ARCHIVE_BUCKET_NAME, ARCHIVE_PREFIX, filename
        )
    
    log.info(f"All files processed\n--")

# COMMAND ----------

# DBTITLE 1,Main
# Main

if not PREFIX.endswith("/"):
    PREFIX = f"{PREFIX}/"

if not ARCHIVE_PREFIX.endswith("/"):
    ARCHIVE_PREFIX = f"{ARCHIVE_PREFIX}/"

# Process the list of files prefix to ingest
FILE_PREFIX_LIST = [s.strip() for s in FILE_PREFIX_LIST]
FILE_PREFIX_LIST = list(set(FILE_PREFIX_LIST))
log.info(f"On the way to ingest all files with prefix(es) in list : {FILE_PREFIX_LIST}")

# Search in S3 for files corresponding to those prefixes {FILE_PREFIX_LIST} and build a list of files to ingest
xml_file_list = search_for_xml_files(BUCKET_NAME, PREFIX, FILE_PREFIX_LIST)

if len(xml_file_list) != 0:
    # Process the ingestion of files from the list
    process_xml_files(xml_file_list)
else:
    log.info(f"No file to process !!!\n--")

# COMMAND ----------

# DBTITLE 1,Set task value
# Set task values for retrieving it in other notebooks of the workflow
dbutils.jobs.taskValues.set(key="write_env", value=WRITE_ENV)
dbutils.jobs.taskValues.set(key="read_env", value=READ_ENV)
dbutils.jobs.taskValues.set(key="table_list", value=TABLE_LIST)

log.info(f"Table list passed to job : {TABLE_LIST}\n--")
