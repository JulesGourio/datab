import functools
import re
from typing import List

from pyspark.sql import functions as f, Window, DataFrame

from leap_utils.config import spark


def create_file_header_validation(
    s3_files_path: str,
    expected_header_columns: List[str],
    csv_read_options: dict = None,
    debug: bool = False,
) -> DataFrame:
    """
    Read every first line (header) of all files in the specified S3 path.
    Create a row in the output dataframe for each CSV file,
    and compare the header with the provided expected header column list.
    In the resulting dataframe, `is_expected_header`
    is equal to True if the file has the same header as the expected header.

    :param s3_files_path: S3 path of the files to read and validate.
        You can use wildcards like `/path/*.csv`.
    :param expected_header_columns: The list of column names to be expected in each file's header.
    :param csv_read_options: Read option dictionary to use in `spark.read.csv`.
    :param debug: Print the various spark dataframes, step by step, if True.
    For debugging purpose only.
    :return: A spark dataframe containing information on each file's header, as well as the `is_expected_header`
    column to check if every file is equal to the provided expected header list.
    """
    if csv_read_options is None:
        csv_read_options = {}

    # Make sure the `header = True` option is not used in `csv_read_options`
    csv_read_options_header = csv_read_options.get("header", "false").lower() == "true"
    if csv_read_options_header:
        raise Exception(
            f"Using {csv_read_options['header']=} is not supported, "
            f"because files should be read without headers, "
            f"in order to compare all file headers with the expected header list."
        )

    # Read files from S3
    csv_files = spark.read.options(**csv_read_options).csv(s3_files_path)

    # Column expression to select the first row of each file
    row_number_per_file = (
        f.row_number()
        .over(Window.partitionBy("_metadata.file_name").orderBy("_metadata.file_name"))
        .alias("row_number")
    )

    # Cleanup filename when it contains spaces, printed as `%20`
    filename_cleaned = f.regexp_replace(f.col("_metadata.file_name"), "%20", " ").alias(
        "filename"
    )

    # Get files headers
    csv_headers = csv_files.select(
        row_number_per_file,
        filename_cleaned,
        "*",
    ).where(f.col("row_number") == 1)

    if debug:
        csv_headers.display()

    # Get the list of columns associated with csv headers (all columns matching _c0, _c1, etc.)
    csv_header_columns = list(
        filter(functools.partial(re.fullmatch, r"\_c\d+"), csv_headers.columns)
    )

    if debug:
        print(f"{csv_header_columns=}")

    # Unpivot CSV headers (file headers columns are put into rows, for each filename)
    csv_headers_unpivoted = csv_headers.unpivot(
        ids=["filename"],
        values=csv_header_columns,
        variableColumnName="header_identifier",
        valueColumnName="header_name",
    )

    if debug:
        print(f"{csv_headers_unpivoted=}")

    # Get the list of headers for each file
    csv_headers_list = csv_headers_unpivoted.groupBy("filename").agg(
        f.collect_list("header_name").alias("file_headers")
    )

    if debug:
        csv_headers_list.display()

    # Compare headers
    csv_headers_with_expected_header = csv_headers_list.withColumn(
        "is_expected_header", f.col("file_headers") == f.lit(expected_header_columns)
    )

    return csv_headers_with_expected_header
