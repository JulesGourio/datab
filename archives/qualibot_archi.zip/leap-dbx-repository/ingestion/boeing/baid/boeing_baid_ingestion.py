# Databricks notebook source
# MAGIC %md
# MAGIC # Setup

# COMMAND ----------

# MAGIC %md
# MAGIC **Python dependencies needed**
# MAGIC
# MAGIC `%pip install fsspec s3fs great-expectations`

# COMMAND ----------

# %% Imports
import re

import pandas as pd
from databricks.sdk.runtime import dbutils
from great_expectations.dataset import SparkDFDataset
from IPython.display import display
from pyspark.sql import functions as f

from ingestion.boeing import boeing_validation
from leap_utils.common.validation import gx_validation
from leap_utils.ingestion import ingestion_utils

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reset_stack", "False")
RESET_STACK = dbutils.widgets.get("reset_stack").lower() == "true"

dbutils.widgets.text("force_data_asset_computation", "False")
FORCE_DATA_ASSET_COMPUTATION = (
    dbutils.widgets.get("force_data_asset_computation").lower() == "true"
)

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Constants
BAID_STACK_DATABASE = (
    f"{PIPELINE_WRITE_ENV}_bronze.leap_depot_uc22_demand_management_is_boeing"
)
BAID_STACK_TABLENAME = "baid_bronze_stack"

BAID_COLUMNS = [
    "Model",
    "LineNo",
    "Eff",
    "Bundle",
    "Dash",
    "ADCN",
    "SADate",
    "Qty",
    "Sheet",
    "Title",
]

INGESTION_BUCKET = f"s3://leap-s3-raw-weeu1-{REFERENCE_READ_ENV}"
BOEING_LEAPDEPOT = "manual/leapdepot/UC22_DEMAND_MANAGEMENT_IS_BOEING"

BOEING_INPUT_S3_PATH = f"{INGESTION_BUCKET}/{BOEING_LEAPDEPOT}"
BOEING_ARCHIVE_S3_PATH = f"{INGESTION_BUCKET}/archive/{BOEING_LEAPDEPOT}"

BAID_GENERATED_TXT_S3_PATH = (
    f"{INGESTION_BUCKET}/manual/use_case_processing/UC22_DEMAND_MANAGEMENT_IS_BOEING/"
    f"engineering_forecasts/baid/gen_txt"
)

BAID_LEAPDEPOT_TEXT_FILENAME_REGEX = r"\d{8}_\d{6}_BAID-6_\d{8}_\d{6}.(?i)TXT"

# COMMAND ----------

# MAGIC %md
# MAGIC # Find files to ingest

# COMMAND ----------

# %% List all files in the BOEING leapdepot S3 folder
boeing_leapdepot_s3_files = ingestion_utils.create_dbutils_ls_dataframe(
    BOEING_INPUT_S3_PATH
)

if DEBUG:
    display(boeing_leapdepot_s3_files.toPandas())

# COMMAND ----------

# %% Filter files to obtain only TXT BAID files
baid_s3_txt_files = boeing_leapdepot_s3_files.where(
    f.regexp(f.col("name"), f.lit(BAID_LEAPDEPOT_TEXT_FILENAME_REGEX))
)

if DEBUG:
    display(baid_s3_txt_files.toPandas())

# COMMAND ----------

# %% If there are no BAID files to ingest, exit the notebook
# (Note: make sure to use this value to prevent further tasks from running for nothing)

files_to_ingest = baid_s3_txt_files.count() > 0

compute_data_asset = files_to_ingest | FORCE_DATA_ASSET_COMPUTATION

dbutils.jobs.taskValues.set("compute_data_asset", compute_data_asset)

if not files_to_ingest:
    dbutils.notebook.exit(
        f"There are no BAID files to ingest, exiting notebook: {baid_s3_txt_files.count()=}"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Ingest files

# COMMAND ----------

# %% Cleanup generated TXT folder before converting files
dbutils.fs.rm(BAID_GENERATED_TXT_S3_PATH, recurse=True)

# COMMAND ----------

# %% Copy files to generated TXT folder
files_to_copy_list = list(baid_s3_txt_files.toPandas()["path"])

for file_to_copy in files_to_copy_list:
    file_name_to_copy = file_to_copy.split("/")[-1]
    converted_file_name = re.sub(
        r"\.TXT", ".txt", file_name_to_copy, flags=re.IGNORECASE
    )

    dbutils.fs.cp(file_to_copy, f"{BAID_GENERATED_TXT_S3_PATH}/{converted_file_name}")

    if DEBUG:
        print(f"{converted_file_name=}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Header validation

# COMMAND ----------

# %% TXT header validation
csv_headers_with_expected_header = boeing_validation.create_file_header_validation(
    f"{BAID_GENERATED_TXT_S3_PATH}/*.txt",
    BAID_COLUMNS,
    csv_read_options={"delimiter": "\t"},
    debug=DEBUG,
)

if DEBUG:
    csv_headers_with_expected_header.display()

# COMMAND ----------

# %% Use GX to assert all files have the expected header
gx_csv_headers = SparkDFDataset(csv_headers_with_expected_header, persist=False)

headers_validation = [
    gx_csv_headers.expect_column_values_to_be_in_set(
        column="is_expected_header", value_set=[True]
    )
]

# COMMAND ----------

# %% Raise exception if the validation failed, CSV headers should not change, red quality check
gx_validation.validate_and_log_gx_results(
    quality_check_results=headers_validation,
    validation_level="RED",
    info_message="All headers of CSV files are OK",
    error_message="Could not validate headers of CSV files.",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name=BAID_STACK_TABLENAME,
    log_to_event_table=True,
    log_successes=True,
)


# COMMAND ----------

# MAGIC %md
# MAGIC # Copy into ingestion

# COMMAND ----------

# %% Ingest TXTs using copy into
format_options = {
    "header": "True",
    "delimiter": "\t",
    "mode": "FAILFAST",
}
df_copy_into = ingestion_utils.copy_into(
    output_stack_database=BAID_STACK_DATABASE,
    output_stack_table_name=BAID_STACK_TABLENAME,
    columns_selection=BAID_COLUMNS,
    s3_path=f"{BAID_GENERATED_TXT_S3_PATH}/",
    empty_stack=RESET_STACK,
    merge_schema=RESET_STACK,
    use_column_mapping=False,
    debug=DEBUG,
    format_options=format_options,
)

if DEBUG:
    display(df_copy_into.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC # Ingestion clean-up

# COMMAND ----------

# %% Cleanup generated TXT folder after copying ingested files
dbutils.fs.rm(BAID_GENERATED_TXT_S3_PATH, recurse=True)

# COMMAND ----------

# %% Archive TXT files
for baid_filepath in files_to_copy_list:
    baid_filename = baid_filepath.split("/")[-1]

    dbutils.fs.mv(
        f"{BOEING_INPUT_S3_PATH}/{baid_filename}",
        f"{BOEING_ARCHIVE_S3_PATH}/{baid_filename}",
    )