# Databricks notebook source
# MAGIC %md
# MAGIC # boeing_sils_kit_ingestion
# MAGIC
# MAGIC **Description:**
# MAGIC It read Sils Kit Cancel file (.xlsx) that arrives on S3, matches the regex expression (name file convention), it will be read them, create CSV files and ingested it one 1 table.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - F_Boeing_SILS_Kit_Data_Asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_bronze.leap_depot_uc22_demand_management_is_boeing.sils_kit_bronze_stack

# COMMAND ----------

# MAGIC %md
# MAGIC **Python dependencies needed**
# MAGIC
# MAGIC `%pip install fsspec s3fs openpyxl xlrd great-expectations`

# COMMAND ----------

# %% Imports
import re

import pandas as pd
from databricks.sdk.runtime import dbutils
from great_expectations.dataset import SparkDFDataset
from IPython.display import display
from pyspark.sql import functions as f

from ingestion.boeing import boeing_validation
from leap_utils.common.validation import gx_validation
from leap_utils.ingestion import ingestion_utils

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reset_stack", "False")
RESET_STACK = dbutils.widgets.get("reset_stack").lower() == "true"

dbutils.widgets.text("force_data_asset_computation", "False")
FORCE_DATA_ASSET_COMPUTATION = (
    dbutils.widgets.get("force_data_asset_computation").lower() == "true"
)

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Constante variables

# COMMAND ----------

SILS_KIT_STACK_DATABASE = (
    f"{PIPELINE_WRITE_ENV}_bronze.leap_depot_uc22_demand_management_is_boeing"
)
SILS_KIT_STACK_TABLENAME = "sils_kit_bronze_stack"

SILS_KIT_COLUMNS = [
    "PlanShipDate",
    "PlanRqmtDate",
    "Reference",
    "VINNumb",
    "AssyKit",
    "Item",
    "WB",
    "Schedule #",
    "Pos",
    "QtyCalledOff",
    "Contract",
    "ContractPos",
    "LineStation",
    "AssyOrdOp",
    "AddrCode",
    "BoeingCo",
    "StAdds",
    "RecLoc",
    "PCALoc",
    "CityStZip",
]

# TODO one day use "s3://leap-s3-raw-weeu1-{READ_ENV}/manual/leapdepot/UC22_DEMAND_MANAGEMENT_IS_BOEING/
#  orders/sils_kit/xlsx" instead when leapdepot architecture can be replicated in S3

INGESTION_BUCKET = f"s3://leap-s3-raw-weeu1-{REFERENCE_READ_ENV}"
BOEING_LEAPDEPOT = "manual/leapdepot/UC22_DEMAND_MANAGEMENT_IS_BOEING/Sils_Kit"

BOEING_INPUT_S3_PATH = f"{INGESTION_BUCKET}/{BOEING_LEAPDEPOT}"
BOEING_ARCHIVE_S3_PATH = f"{INGESTION_BUCKET}/archive/{BOEING_LEAPDEPOT}"

SILS_KIT_GENERATED_CSV_S3_PATH = (
    f"{INGESTION_BUCKET}/manual/use_case_processing/UC22_DEMAND_MANAGEMENT_IS_BOEING/"
    f"orders/sils_kit/gen_csv"
)

SILS_KIT_LEAPDEPOT_EXCEL_FILENAME_REGEX = (
    r"\d{8}\-\d{6}\_\d{1}\_\d{8}_SILS KITS LATECOERE "
    r"BUMP ESRC \d+ Wire Bundles Call-Off Data.xlsx"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check (read) files on S3 Path

# COMMAND ----------

# %% List all files in the BOEING leapdepot S3 folder
boeing_leapdepot_s3_files = ingestion_utils.create_dbutils_ls_dataframe(
    BOEING_INPUT_S3_PATH
)

if DEBUG:
    display(boeing_leapdepot_s3_files.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check and filter files that match the file name convension for this process

# COMMAND ----------

# %% Filter files to obtain only Excel SILS Kit files
sils_kit_s3_xlsx_files = boeing_leapdepot_s3_files.where(
    f.regexp(f.col("name"), f.lit(SILS_KIT_LEAPDEPOT_EXCEL_FILENAME_REGEX))
)

if DEBUG:
    display(sils_kit_s3_xlsx_files.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC ## File validation checkpoint
# MAGIC - Here we check if there is a file new and as expected (name convension), if not it will exit the notebook
# MAGIC - If there are no SILS Kit files to ingest, exit the notebook
# MAGIC
# MAGIC **Note:** make sure to use this value to prevent further tasks from running for nothing

# COMMAND ----------

# %% If there are no SILS Kit files to ingest, exit the notebook
# (Note: make sure to use this value to prevent further tasks from running for nothing)
files_to_ingest = sils_kit_s3_xlsx_files.count() > 0

compute_data_asset = files_to_ingest | FORCE_DATA_ASSET_COMPUTATION

dbutils.jobs.taskValues.set("compute_data_asset", compute_data_asset)

if not files_to_ingest:
    dbutils.notebook.exit(
        f"There are no SILS Kit files to ingest, exiting notebook: {sils_kit_s3_xlsx_files.count()=}"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Start process

# COMMAND ----------

# MAGIC %md
# MAGIC ### Cleanup generated CSV folder before converting files

# COMMAND ----------

# %% Cleanup generated CSV folder before converting files
dbutils.fs.rm(SILS_KIT_GENERATED_CSV_S3_PATH, recurse=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ###  Convert files to CSVs

# COMMAND ----------

# TODO : Remove write CSV and save directly, things to do:
# 1 - Remove delete code for remove csv files (cell 16,28),
# 2 - Create a DF to stack with each file read,
# 3 - Change code header validation to validate directly the DF created on step 2 ,
# 4 - Change SAVE table function to leap.utils save table (not using csv files df instead)
# %% Convert files to CSVs
files_to_convert_list = list(sils_kit_s3_xlsx_files.toPandas()["path"])

for file_to_convert in files_to_convert_list:
    file_name_to_convert = file_to_convert.split("/")[-1]
    converted_file_name = re.sub(r"\.xlsx", ".csv", file_name_to_convert)

    # 1 - As Spark creates multiple files, we need to coalesce them to one file, then move it to the final location
    spark_folder = converted_file_name[0 : len(converted_file_name) - 4]
    df_spark_excel = (
        spark.read.format("com.crealytics.spark.excel")
        .option("header", "true")
        .load(file_to_convert)
    )

    # 2 - Set the date format of dates columns. (Due spark and pandas reads different date formats)
    # This should be on silver but due is already in prod this could affect if not done here
    df_spark_excel = df_spark_excel.withColumn(
        "PlanRqmtDate",
        f.coalesce(
            f.to_date("PlanRqmtDate", "M/d/yy"),  # Format for dates like 9/18/2024
            f.to_date("PlanRqmtDate", "yyyy-MM-dd"),
        ),
    )
    df_spark_excel = df_spark_excel.withColumn(
        "PlanShipDate",
        f.coalesce(
            f.to_date("PlanShipDate", "dd-MMM-yy"),  # Format for dates like 12-Sep-2024
            f.to_date("PlanShipDate", "yyyy-MM-dd"),
        ),
    )
    # 3 - Write the CSV file
    df_spark_excel.coalesce(1).write.option("header", "true").option(
        "delimiter", ","
    ).option("inferSchema", "true").mode("overwrite").csv(
        f"{SILS_KIT_GENERATED_CSV_S3_PATH}/{spark_folder}"
    )

    # 4 - Read csv file create by Databrcks and move it to the main folder and rename it
    for file in dbutils.fs.ls(f"{SILS_KIT_GENERATED_CSV_S3_PATH}/{spark_folder}"):
        if file.name.endswith(".csv"):
            dbutils.fs.mv(
                f"{SILS_KIT_GENERATED_CSV_S3_PATH}/{spark_folder}/{file.name}",
                f"{SILS_KIT_GENERATED_CSV_S3_PATH}/{converted_file_name}",
            )
            break

    if DEBUG:
        print(f"{converted_file_name=}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### CSV header validation

# COMMAND ----------

csv_headers_with_expected_header = boeing_validation.create_file_header_validation(
    f"{SILS_KIT_GENERATED_CSV_S3_PATH}/*.csv", SILS_KIT_COLUMNS, debug=DEBUG
)

if DEBUG:
    csv_headers_with_expected_header.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Use GX to assert all files have the expected header

# COMMAND ----------

gx_csv_headers = SparkDFDataset(csv_headers_with_expected_header, persist=False)

headers_validation = [
    gx_csv_headers.expect_column_values_to_be_in_set(
        column="is_expected_header", value_set=[True]
    )
]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Raise exception if the validation failed, CSV headers should not change, red quality check

# COMMAND ----------

gx_validation.validate_and_log_gx_results(
    quality_check_results=headers_validation,
    validation_level="RED",
    info_message="All headers of CSV files are OK",
    error_message="Could not validate headers of CSV files.",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name=SILS_KIT_STACK_TABLENAME,
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save table (Copy INTO)
# MAGIC For more information -> https://docs.databricks.com/en/sql/language-manual/delta-copy-into.html

# COMMAND ----------

# %% Ingest CSVs using copy into
format_options = {
    "header": "True",
    "mode": "FAILFAST",
}
df_copy_into = ingestion_utils.copy_into(
    output_stack_database=SILS_KIT_STACK_DATABASE,
    output_stack_table_name=SILS_KIT_STACK_TABLENAME,
    columns_selection=SILS_KIT_COLUMNS,
    s3_path=f"{SILS_KIT_GENERATED_CSV_S3_PATH}/",
    empty_stack=RESET_STACK,
    merge_schema=RESET_STACK,
    use_column_mapping=False,
    debug=DEBUG,
    format_options=format_options,
)

if DEBUG:
    display(df_copy_into.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Cleanup generated CSV folder after copying ingested files

# COMMAND ----------

# %% Cleanup generated CSV folder after copying ingested files
dbutils.fs.rm(SILS_KIT_GENERATED_CSV_S3_PATH, recurse=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Archive xlsx files

# COMMAND ----------

for sils_kit_filepath in files_to_convert_list:
    sils_kit_filename = sils_kit_filepath.split("/")[-1]

    dbutils.fs.mv(
        f"{BOEING_INPUT_S3_PATH}/{sils_kit_filename}",
        f"{BOEING_ARCHIVE_S3_PATH}/{sils_kit_filename}",
    )
