# Databricks notebook source
# MAGIC %md
# MAGIC # Boeing Sils Kit Cancel Ingestion
# MAGIC
# MAGIC **Description:**
# MAGIC It read Sils Kit Cancel file (.xlsx) that arrives on S3, matches the regex expression (name file convention), it will be read them, create CSV files and ingested it one 1 table.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - F_Boeing_SILS_Kit_Data_Asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_zone.leap_depot_uc22_demand_management_is_boeing.sils_kit_canceled_bronze_stack
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **Python dependencies needed**
# MAGIC
# MAGIC `%pip install fsspec s3fs openpyxl xlrd great-expectations`

# COMMAND ----------

# MAGIC %md
# MAGIC ## Libraries

# COMMAND ----------

# %% Imports
import re

import pandas as pd
from databricks.sdk.runtime import dbutils
from great_expectations.dataset import SparkDFDataset
from pyspark.sql import functions as f

from ingestion.boeing import boeing_validation
from leap_utils.common.validation import gx_validation
from leap_utils.ingestion import ingestion_utils

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reset_stack", "False")
RESET_STACK = dbutils.widgets.get("reset_stack").lower() == "true"

dbutils.widgets.text("force_data_asset_computation", "False")
FORCE_DATA_ASSET_COMPUTATION = (
    dbutils.widgets.get("force_data_asset_computation").lower() == "true"
)

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Constants
SILS_KIT_STACK_DATABASE = (
    f"{PIPELINE_WRITE_ENV}_bronze.leap_depot_uc22_demand_management_is_boeing"
)

SILS_KIT_CANCELED_STACK_TABLENAME = "sils_kit_canceled_bronze_stack"

# New file added from same mail, it has different structure
SILS_KIT_CANCELED_COLUMNS = [
    "ProgramSupport",
    "PS",
    "PS_POS",
    "ITEM",
    "PURLINEPLNDDELDATE",
    "BUYFROMBPNAME",
    "BUYFROMBP",
    "PURLINESTATUSDESC",
    "LINE_STATION",
    "VINNUMB",
]

# As for default the value "ingestion_timestamp" set it as string causing issue, we manually change the value to timestamp
# TODO : Modify it, this is a dictionary used by leap_utils "copy_into()", currently not changed due will impact other project already on PROD
METADATA_Cancel_File = [
    {
        "selection_expression": "_metadata.file_name",
        "alias_name": "filename",
        "schema_type": "string",
    },
    {
        "selection_expression": "_metadata.file_path",
        "alias_name": "filepath",
        "schema_type": "string",
    },
    {
        "selection_expression": "_metadata.file_modification_time",
        "alias_name": "modification_timestamp",
        "schema_type": "timestamp",
    },
    {
        "selection_expression": "now()",
        "alias_name": "ingestion_timestamp",
        "schema_type": "timestamp",
    },
]

# TODO one day use "s3://leap-s3-raw-weeu1-{READ_ENV}/manual/leapdepot/UC22_DEMAND_MANAGEMENT_IS_BOEING/
#  orders/sils_kit/xlsx" instead when leapdepot architecture can be replicated in S3

INGESTION_BUCKET = f"s3://leap-s3-raw-weeu1-{REFERENCE_READ_ENV}"
BOEING_LEAPDEPOT = "manual/leapdepot/UC22_DEMAND_MANAGEMENT_IS_BOEING/Sils_Kit"

BOEING_INPUT_S3_PATH = f"{INGESTION_BUCKET}/{BOEING_LEAPDEPOT}"
BOEING_ARCHIVE_S3_PATH = f"{INGESTION_BUCKET}/archive/{BOEING_LEAPDEPOT}"

SILS_KIT_Canceled_GENERATED_CSV_S3_PATH = (
    f"{INGESTION_BUCKET}/manual/use_case_processing/UC22_DEMAND_MANAGEMENT_IS_BOEING/"
    f"orders/sils_kit/gen_cancel_csv"
)
# Get Sils Kit Cancel File
SILS_KIT_LEAPDEPOT_CANCELED_EXCEL_FILENAME_REGEX = (
    r"\d{8}\-\d{6}\_\d{1}\_\d{8}_SILS KITS LATECOERE "
    r"ESRC .* Wire Bundle CANCEL Call-Off Data.xlsx"
)

# COMMAND ----------

# %% List all files in the BOEING leapdepot S3 folder
boeing_leapdepot_s3_files = ingestion_utils.create_dbutils_ls_dataframe(
    BOEING_INPUT_S3_PATH
)

if DEBUG:
    boeing_leapdepot_s3_files.display()

# COMMAND ----------

# %% Filter files to obtain only Excel SILS Kit files
sils_kit_canceled_s3_xlsx_files = boeing_leapdepot_s3_files.where(
    f.regexp(f.col("name"), f.lit(SILS_KIT_LEAPDEPOT_CANCELED_EXCEL_FILENAME_REGEX))
)

if DEBUG:
    sils_kit_canceled_s3_xlsx_files.display()

# COMMAND ----------

# %% If there are no SILS Kit files to ingest, exit the notebook
# (Note: make sure to use this value to prevent further tasks from running for nothing)
files_to_ingest = sils_kit_canceled_s3_xlsx_files.count() > 0

compute_data_asset = files_to_ingest | FORCE_DATA_ASSET_COMPUTATION

dbutils.jobs.taskValues.set("compute_data_asset", compute_data_asset)

if not files_to_ingest:
    dbutils.notebook.exit(
        f"There are no SILS Kit files to ingest, exiting notebook: {sils_kit_canceled_s3_xlsx_files.count()=}"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Clean Cleanup generated CSV folder before converting files

# COMMAND ----------

dbutils.fs.rm(SILS_KIT_Canceled_GENERATED_CSV_S3_PATH, recurse=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read xlxs files and create a csv file

# COMMAND ----------

# %% Convert files to CSVs
files_to_convert_list_Canceled = list(
    sils_kit_canceled_s3_xlsx_files.toPandas()["path"]
)

# Sils Kit Cancel file
for file_to_convert in files_to_convert_list_Canceled:
    file_name_to_convert = file_to_convert.split("/")[-1]
    converted_file_name = re.sub(r"\.xlsx", ".csv", file_name_to_convert)
    spark_folder = converted_file_name[0 : len(converted_file_name) - 4]

    # 1 - Read Excel file
    df_spark_excel = (
        spark.read.format("com.crealytics.spark.excel")
        .option("header", "true")
        .load(file_to_convert)
    )

    # FIX: New Column added so will move "VINNUMB" column to the end
    col_to_move = "VINNUMB"
    list_columns_new_order = [c for c in df_spark_excel.columns if c != col_to_move] + [
        col_to_move
    ]
    # Reorder DataFrame
    df_spark_excel = df_spark_excel.select(list_columns_new_order)

    # 2 - Write CSV File
    df_spark_excel.coalesce(1).write.option("header", "true").option(
        "delimiter", ","
    ).option("inferSchema", "true").mode("overwrite").csv(
        f"{SILS_KIT_Canceled_GENERATED_CSV_S3_PATH}/{spark_folder}"
    )

    # 3 - Read and move file
    # Read csv file create by Databrcks and move it to the main folder and rename it
    for file in dbutils.fs.ls(
        f"{SILS_KIT_Canceled_GENERATED_CSV_S3_PATH}/{spark_folder}"
    ):
        if file.name.endswith(".csv"):
            dbutils.fs.mv(
                f"{SILS_KIT_Canceled_GENERATED_CSV_S3_PATH}/{spark_folder}/{file.name}",
                f"{SILS_KIT_Canceled_GENERATED_CSV_S3_PATH}/{converted_file_name}",
            )
            break

    if DEBUG:
        print(f"{converted_file_name=}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validations

# COMMAND ----------

# %% CSV header validation
# Validation for Cancel csv file as has different columns
if files_to_convert_list_Canceled:
    csv_headers_with_expected_header_cancel_csv = (
        boeing_validation.create_file_header_validation(
            f"{SILS_KIT_Canceled_GENERATED_CSV_S3_PATH}/*.csv",
            SILS_KIT_CANCELED_COLUMNS,
            debug=DEBUG,
        )
    )

if DEBUG:
    csv_headers_with_expected_header_cancel_csv.display()

# COMMAND ----------

# %% Use GX to assert all files have the expected header
gx_csv_headers_cancel_csv = SparkDFDataset(
    csv_headers_with_expected_header_cancel_csv, persist=False
)

headers_validation_cancel_csv = [
    gx_csv_headers_cancel_csv.expect_column_values_to_be_in_set(
        column="is_expected_header", value_set=[True]
    )
]

# COMMAND ----------

gx_validation.validate_and_log_gx_results(
    quality_check_results=headers_validation_cancel_csv,
    validation_level="RED",
    info_message="All headers of CSV files are OK",
    error_message="Could not validate headers of CSV files.",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name=SILS_KIT_CANCELED_STACK_TABLENAME,
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save File
# MAGIC Using copy into
# MAGIC https://docs.databricks.com/en/sql/language-manual/delta-copy-into.html

# COMMAND ----------

# %% Ingest CSVs using copy into
format_options = {
    "header": "True",
    "mode": "FAILFAST",
}

df_copy_into_canceled = ingestion_utils.copy_into(
    output_stack_database=SILS_KIT_STACK_DATABASE,
    output_stack_table_name=SILS_KIT_CANCELED_STACK_TABLENAME,
    columns_selection=SILS_KIT_CANCELED_COLUMNS,
    s3_path=f"{SILS_KIT_Canceled_GENERATED_CSV_S3_PATH}/",
    empty_stack=RESET_STACK,
    merge_schema=RESET_STACK,
    use_column_mapping=False,
    debug=DEBUG,
    format_options=format_options,
    metadata=METADATA_Cancel_File,
)

if DEBUG:
    df_copy_into_canceled.limit(10).display()

# COMMAND ----------

# %% Cleanup generated CSV folder after copying ingested files
dbutils.fs.rm(SILS_KIT_Canceled_GENERATED_CSV_S3_PATH, recurse=True)

# COMMAND ----------

# %% Archive xlsx files
for sils_kit_canceled_filepath in files_to_convert_list_Canceled:
    sils_kit_filename = sils_kit_canceled_filepath.split("/")[-1]

    dbutils.fs.mv(
        f"{BOEING_INPUT_S3_PATH}/{sils_kit_filename}",
        f"{BOEING_ARCHIVE_S3_PATH}/{sils_kit_filename}",
    )
