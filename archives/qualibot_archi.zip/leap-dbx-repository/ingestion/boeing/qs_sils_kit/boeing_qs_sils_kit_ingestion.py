# Databricks notebook source
# MAGIC %md
# MAGIC **Python dependencies needed**
# MAGIC
# MAGIC `%pip install fsspec s3fs openpyxl xlrd great-expectations`

# COMMAND ----------

# %% Imports
import re

import pandas as pd
from databricks.sdk.runtime import dbutils
from great_expectations.dataset import SparkDFDataset
from IPython.display import display
from pyspark.sql import functions as f

from ingestion.boeing import boeing_validation
from leap_utils.common.validation import gx_validation
from leap_utils.ingestion import ingestion_utils

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("read_env", "dev")
READ_ENV = dbutils.widgets.get("read_env")

dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

dbutils.widgets.text("reset_stack", "False")
RESET_STACK = dbutils.widgets.get("reset_stack").lower() == "true"

dbutils.widgets.text("force_data_asset_computation", "False")
FORCE_DATA_ASSET_COMPUTATION = (
    dbutils.widgets.get("force_data_asset_computation").lower() == "true"
)

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Constants
QS_SILS_KIT_STACK_DATABASE = (
    f"{WRITE_ENV}_bronze.leap_depot_uc22_demand_management_is_boeing"
)
QS_SILS_KIT_STACK_TABLENAME = "qs_sils_kit_bronze_stack"

QS_SILS_KIT_COLUMNS = [
    "PlanRqmtDate",
    "Reference",
    "VinNumb",
    "AssyKit",
    "Item",
    "WB",
    "Schedule #",
    "PurSchPos",
    "QtyCalledOff",
    "LineStation",
    "AssyOrdOp",
    "AddrCode",
    "BoeingCo",
    "StAdds",
    "RecLoc",
    "PCALoc",
    "CityStZip",
    "ShipFromBP",
]

INGESTION_BUCKET = f"s3://leap-s3-raw-weeu1-{READ_ENV}"
BOEING_LEAPDEPOT = "manual/leapdepot/UC22_DEMAND_MANAGEMENT_IS_BOEING"

BOEING_INPUT_S3_PATH = f"{INGESTION_BUCKET}/{BOEING_LEAPDEPOT}"
BOEING_ARCHIVE_S3_PATH = f"{INGESTION_BUCKET}/archive/{BOEING_LEAPDEPOT}"

QS_SILS_KIT_GENERATED_CSV_S3_PATH = (
    f"{INGESTION_BUCKET}/manual/use_case_processing/UC22_DEMAND_MANAGEMENT_IS_BOEING/"
    f"orders/qs_sils_kit/gen_csv"
)

QS_SILS_KIT_LEAPDEPOT_EXCEL_FILENAME_REGEX = (
    r"\d{8}\_\d{6}\_\d{8} QS_Latecore SILS Kits.xls"
)

# COMMAND ----------

# %% List all files in the BOEING leapdepot S3 folder
boeing_leapdepot_s3_files = ingestion_utils.create_dbutils_ls_dataframe(
    BOEING_INPUT_S3_PATH
)

if DEBUG:
    display(boeing_leapdepot_s3_files.toPandas())

# COMMAND ----------

# %% Filter files to obtain only Excel QS SILS Kit files
qs_sils_kit_s3_xls_files = boeing_leapdepot_s3_files.where(
    f.regexp(f.col("name"), f.lit(QS_SILS_KIT_LEAPDEPOT_EXCEL_FILENAME_REGEX))
)

if DEBUG:
    display(qs_sils_kit_s3_xls_files.toPandas())

# COMMAND ----------

# %% If there are no QS SILS Kit files to ingest, exit the notebook
# (Note: make sure to use this value to prevent further tasks from running for nothing)

files_to_ingest = qs_sils_kit_s3_xls_files.count() > 0

compute_data_asset = files_to_ingest | FORCE_DATA_ASSET_COMPUTATION

dbutils.jobs.taskValues.set("compute_data_asset", compute_data_asset)

if not files_to_ingest:
    dbutils.notebook.exit(
        f"There are no QS SILS Kit files to ingest, exiting notebook: {qs_sils_kit_s3_xls_files.count()=}"
    )

# %% Cleanup generated CSV folder before converting files
dbutils.fs.rm(QS_SILS_KIT_GENERATED_CSV_S3_PATH, recurse=True)

# COMMAND ----------

# %% Convert files to CSVs
files_to_convert_list = list(qs_sils_kit_s3_xls_files.toPandas()["path"])

for file_to_convert in files_to_convert_list:
    file_name_to_convert = file_to_convert.split("/")[-1]
    converted_file_name = re.sub(r"\.xls", ".csv", file_name_to_convert)

    pd_excel = pd.read_excel(file_to_convert, dtype="object")
    pd_excel.to_csv(
        f"{QS_SILS_KIT_GENERATED_CSV_S3_PATH}/{converted_file_name}",
        header=True,
        index=False,
        sep=",",
    )

    if DEBUG:
        print(f"{converted_file_name=}")

# COMMAND ----------

# %% CSV header validation
csv_headers_with_expected_header = boeing_validation.create_file_header_validation(
    f"{QS_SILS_KIT_GENERATED_CSV_S3_PATH}/*.csv", QS_SILS_KIT_COLUMNS, debug=DEBUG
)

if DEBUG:
    csv_headers_with_expected_header.display()

# COMMAND ----------

# %% Use GX to assert all files have the expected header
gx_csv_headers = SparkDFDataset(csv_headers_with_expected_header, persist=False)

headers_validation = [
    gx_csv_headers.expect_column_values_to_be_in_set(
        column="is_expected_header", value_set=[True]
    )
]

# COMMAND ----------

# %% Raise exception if the validation failed, CSV headers should not change, red quality check
gx_validation.validate_and_log_gx_results(
    quality_check_results=headers_validation,
    validation_level="RED",
    info_message="All headers of CSV files are OK",
    error_message="Could not validate headers of CSV files.",
    pipeline_write_env=WRITE_ENV,
    table_name=QS_SILS_KIT_STACK_TABLENAME,
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# %% Ingest CSVs using copy into
format_options = {
    "header": "True",
    "mode": "FAILFAST",
}
df_copy_into = ingestion_utils.copy_into(
    output_stack_database=QS_SILS_KIT_STACK_DATABASE,
    output_stack_table_name=QS_SILS_KIT_STACK_TABLENAME,
    columns_selection=QS_SILS_KIT_COLUMNS,
    s3_path=f"{QS_SILS_KIT_GENERATED_CSV_S3_PATH}/",
    empty_stack=RESET_STACK,
    merge_schema=RESET_STACK,
    use_column_mapping=False,
    debug=DEBUG,
    format_options=format_options,
)

if DEBUG:
    display(df_copy_into.toPandas())

# COMMAND ----------

# %% Cleanup generated CSV folder after copying ingested files
dbutils.fs.rm(QS_SILS_KIT_GENERATED_CSV_S3_PATH, recurse=True)

# COMMAND ----------

# %% Archive xlsx files
for qs_sils_kit_filepath in files_to_convert_list:
    qs_sils_kit_filename = qs_sils_kit_filepath.split("/")[-1]

    dbutils.fs.mv(
        f"{BOEING_INPUT_S3_PATH}/{qs_sils_kit_filename}",
        f"{BOEING_ARCHIVE_S3_PATH}/{qs_sils_kit_filename}",
    )
