# Databricks notebook source
# MAGIC %md
# MAGIC # boeing_demand_part_numbers_company_ingestion
# MAGIC
# MAGIC **Description:**  
# MAGIC It reads an (.xlsx) that arrives on S3, matches the regex expression (name file convention), then create the table.
# MAGIC
# MAGIC Key Points:
# MAGIC - This table is used for several process of Boeing Demand IS (proj/uc22_boeing_demand_IS)
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - F_Boeing_IS_Part_Numbers_Data_Asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_zone.leap_depot_uc22_demand_management_is_boeing.part_numbers_company_stack
# MAGIC

# COMMAND ----------

# %% Imports
import re

from databricks.sdk.runtime import dbutils
from IPython.display import display
from pyspark.sql import functions as f
from pyspark.sql.utils import AnalysisException
from datetime import datetime, timezone
from leap_utils.config import spark

from leap_utils.ingestion import ingestion_utils
from leap_utils.data_asset import table_utils

# COMMAND ----------

# Get read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.text("force_data_asset_computation", "False")
FORCE_DATA_ASSET_COMPUTATION = (
    dbutils.widgets.get("force_data_asset_computation").lower() == "true"
)

# COMMAND ----------

INGESTION_BUCKET = f"s3://leap-s3-raw-weeu1-{REFERENCE_READ_ENV}"
BOEING_LEAPDEPOT = "manual/leapdepot/UC22_DEMAND_MANAGEMENT_IS_BOEING"

BOEING_INPUT_S3_PATH = f"{INGESTION_BUCKET}/{BOEING_LEAPDEPOT}/part_numbers_company"
BOEING_ARCHIVE_S3_PATH = (
    f"{INGESTION_BUCKET}/archive/{BOEING_LEAPDEPOT}/part_numbers_company"
)

catalog = f"{PIPELINE_WRITE_ENV}_bronze"
domain = "leap_depot_uc22_demand_management_is_boeing"
table = "part_numbers_company_stack"

LEAPDEPOT_EXCEL_FILENAME_REGEX = r"\d{8}\_\d{6}\_Latecoere part list by company.*\.xlsx"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1 - Check (read) files on S3 Path

# COMMAND ----------

# %% List all files in the BOEING leapdepot S3 folder
df_boeing_leapdepot_s3_files = ingestion_utils.create_dbutils_ls_dataframe(
    BOEING_INPUT_S3_PATH
)

if DEBUG:
    df_boeing_leapdepot_s3_files.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2 - Search file name (regex)

# COMMAND ----------

# %% Filter files to obtain only Excel files
df_xlsx_files_pn = df_boeing_leapdepot_s3_files.where(
    f.regexp(f.col("name"), f.lit(LEAPDEPOT_EXCEL_FILENAME_REGEX))
)

if DEBUG:
    df_xlsx_files_pn.limit(20).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## File validation checkpoint
# MAGIC - Here we check if there is a file new and as expected (name convension), if not it will exit the notebook
# MAGIC - If there are no Cutover files to ingest, exit the notebook
# MAGIC
# MAGIC **Note:** make sure to use this value to prevent further tasks from running for nothing

# COMMAND ----------

# %% If there are no PN files to ingest, exit the notebook
# (Note: make sure to use this value to prevent further tasks from running for nothing)

files_to_ingest = df_xlsx_files_pn.count() > 0

compute_data_asset = files_to_ingest | FORCE_DATA_ASSET_COMPUTATION

dbutils.jobs.taskValues.set("compute_data_asset", compute_data_asset)

if not files_to_ingest:
    dbutils.notebook.exit(
        f"There are no Part Number files to ingest, exiting notebook: {df_xlsx_files_pn.count()=}"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3 - Read File
# MAGIC It will be read 2 sheets, by name

# COMMAND ----------

df_pn_company_stack = None
for row in df_xlsx_files_pn.collect():
    # 1 - Read Excel file
    df_spark_excel = (
        spark.read.format("com.crealytics.spark.excel")
        .option("header", "true")
        .load(row["path"])
    )

    # 2 - Add Ingestion Columns Information for each file
    df_spark_excel = df_spark_excel.withColumns(
        {
            "file_name": f.lit(row["name"]),
            "file_path": f.lit(row["path"]),
            "modification_timestamp": f.lit(row["modification_timestamp"]),
            "ingestion_timestamp": f.lit(datetime.now()),
        }
    )
    # 3 - Joint DF to a single DF
    if df_pn_company_stack:
        # 3° and next iterations - Union (append)
        df_pn_company_stack = df_pn_company_stack.union(df_spark_excel)
    else:
        df_pn_company_stack = df_spark_excel

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4 - Save table

# COMMAND ----------

df_pn_company_all = df_pn_company_stack

if spark.catalog.tableExists(f"{catalog}.{domain}.{table}"):
    df_pn_company_previous_data = spark.read.table(f"{catalog}.{domain}.{table}")
    df_pn_company_all = df_pn_company_previous_data.unionByName(df_pn_company_stack)

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_pn_company_all,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5 - Archive files

# COMMAND ----------

# %% Archive xlsx files
for row in df_xlsx_files_pn.collect():
    file_name = row["name"]

    dbutils.fs.mv(
        f"{BOEING_INPUT_S3_PATH}/{file_name}",
        f"{BOEING_ARCHIVE_S3_PATH}/{file_name}",
    )
