# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Ingestion - BOM IS quality check
# MAGIC
# MAGIC **Context:**
# MAGIC
# MAGIC Bill of materials data comes from the ERP sap. In sap, there are no rules implemented to check consistency of the data.
# MAGIC To solve this problem, a notebook with quality checks is implemented directly by the supply chain and ingested in this notebook. Thanks to that, supply can independently evolve quality checks and it will automatically performs quality checks on data.
# MAGIC
# MAGIC In this notebook only ingestion is performed, quality checks are performed on project side.
# MAGIC
# MAGIC http://confluence.lat.corp:8090/pages/viewpage.action?pageId=46274032
# MAGIC
# MAGIC
# MAGIC **Inputs:** Files in s3://leap-s3-raw-weeu1-{env}/manual/leapdepot/UC27_AVERAGE_BOM/
# MAGIC
# MAGIC **Output table(s):**
# MAGIC
# MAGIC - {REFERENCE_READ_ENV}_bronze.manual_input.bom_IS_QC
# MAGIC
# MAGIC **Used by:**
# MAGIC
# MAGIC proj/UC27-averageBOM
# MAGIC **Triggered by:**
# MAGIC
# MAGIC File arrival in s3://leap-s3-raw-weeu1-{env}/manual/leapdepot/UC27_AVERAGE_BOM/

# COMMAND ----------

# MAGIC %md
# MAGIC # Import

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import libraries

# COMMAND ----------

import re
import os
from typing import Optional, Tuple

from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.types import StringType
import datetime

import great_expectations as gx
from leap_utils.config import spark
from leap_utils.common.validation import gx_validation
from leap_utils.data_asset.table_utils import save_table
from leap_utils.common import logger
from leap_utils.business_data_consistency import validate_input_rules


# COMMAND ----------

# MAGIC %md
# MAGIC ## Widget

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("env", "dev")
ENV = dbutils.widgets.get("env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("re_init_stack", "False")
RE_INIT_STACK = dbutils.widgets.get("re_init_stack").lower() == "true"

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"


dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # User config for ingestion
# MAGIC
# MAGIC **Goal of a user config:**
# MAGIC - Dev speed: Dev only have to fill configuration, then every step is done automatically
# MAGIC - maintainable: Factorize code ease up code maintanability
# MAGIC - standardise process:
# MAGIC
# MAGIC ### **Config options:**
# MAGIC
# MAGIC **Obligatory parameters:**
# MAGIC - folder_path: absolute path of folder
# MAGIC - file_name: name of the file
# MAGIC - dest_table: Destination path in Unity Catalog format: Catalog.Schema.table
# MAGIC
# MAGIC **Optionnal parameters:**
# MAGIC - quality_checks: Enumeration of all the quality checks that the dev wants to test on input dataframe.
# MAGIC     - Exhaustive list of possible quality checks:
# MAGIC         - expected columns:
# MAGIC         - null values in columns:
# MAGIC - removed_columns_space: Automatically removes space of columns names and change it by "_"
# MAGIC - stack_ids: Create ID columns from the concatenation of the columns gives in the list

# COMMAND ----------

columns_information_rules = ["rule_idx", "object", "description", "error_type"]

input_file_path_base = (
    f"s3://leap-s3-raw-weeu1-{ENV}/manual/leapdepot/UC27_AVERAGE_BOM/"
)

dest_schema = f"{REFERENCE_READ_ENV}_bronze.manual_input"

CONFIG = {
    "folder_path": input_file_path_base,
    "dest_table": dest_schema,
    "quality_checks": {
        "expected_columns": columns_information_rules,
    },
    "removed_columns_space": True,
}

# COMMAND ----------

# MAGIC %md
# MAGIC # Specific Code for ingestion BOM IS Quality Checks
# MAGIC
# MAGIC Implement specific logic for this specific ingestion

# COMMAND ----------


def remove_extension(file_name: str) -> str:
    """
    Remove file extension from a given file name.

    :param file_name: the file name
    :type file_name: str
    :return: the file name without extension
    :rtype: str
    """
    return os.path.splitext(file_name)[0]


def delete_null_rows(df: DataFrame) -> DataFrame:
    """
    Delete rows that are null in all columns of the DataFrame.

    :param df: the input DataFrame
    :type df: pyspark.sql.DataFrame
    :param df: name of the column
    :type df: str
    :return: DataFrame without rows with all null values
    :rtype: pyspark.sql.DataFrame
    """
    df_filtered = df.na.drop(how="all")
    return df_filtered


clean_keywords_udf = f.udf(validate_input_rules.clean_keywords, StringType())


def extract_date_and_table_name(filename: str) -> Optional[Tuple[datetime.date, str]]:
    """
    Extracts the date and table name from a filename that follows the pattern:
    '<date>_<time>_<table_name>.csv', where date is in 'YYYYMMDD' format and
    time is in 'HHMMSS' format.

    :param filename: The input filename string.
    :type filename: str
    :return: A tuple containing the extracted date (as a datetime.date object) and table name.
    :rtype: tuple(date, str)
    """
    match = re.search(r"(\d{8})_(\d{6})_(.*)\.csv", filename)

    if match:
        date_str = match.group(1)
        table_name = match.group(3)

        # Convert the date string to a datetime object
        date = datetime.datetime.strptime(date_str, "%Y%m%d").date()

        return date, table_name
    return None, None


# COMMAND ----------

# MAGIC %md
# MAGIC # Generic code for ingestion

# COMMAND ----------

# MAGIC %md
# MAGIC ## Utils function

# COMMAND ----------

from leap_utils.data_asset.table_utils import (
    remove_start_and_end_spaces_from_column_names,
    _cleanup_column_name,
)

# COMMAND ----------


def remove_column_space_dataframe(df: DataFrame) -> DataFrame:
    """
    Clean column names using _cleanup_column_name function.

    :param df: the DataFrame
    :return: DataFrame with column names without spaces
    """
    cleaned_columns = [_cleanup_column_name(col).lower() for col in df.columns]
    return df.select(
        [
            f.col(col).alias(cleaned_col)
            for col, cleaned_col in zip(df.columns, cleaned_columns)
        ]
    )


def archive_file(folder_path: str, file_name: str) -> None:
    """
    Move a file to the 'archive' folder within the same directory.

    :param folder_path: the path of the folder containing the file
    :type folder_path: str
    :param file_name: the name of the file to be archived
    :type file_name: str
    """
    parts = folder_path.split("/")
    parts.insert(3, "archive")
    new_path = "/".join(parts)
    dbutils.fs.mv(f"{folder_path}/{file_name}", f"{new_path}/{file_name}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks

# COMMAND ----------


def quality_checks_on_input_file(df: DataFrame, config: dict[str, any]):
    """
    Perform quality checks on the input DataFrame using Great Expectations.

    :param df: the input DataFrame
    :type df: pyspark.sql.DataFrame
    :param config: configuration dictionary containing quality check parameters
    :type config: dict[str, any]
    """
    # Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
    red_quality_check_results = []

    df_gx = gx.dataset.SparkDFDataset(df, persist=False)
    for quality_check_name, quality_check_parameter in config["quality_checks"].items():
        if quality_check_name == "expected_columns":
            for column_ref in quality_check_parameter:
                red_quality_check_results.append(
                    df_gx.expect_column_to_exist(column=column_ref)
                )

        if quality_check_name == "columns_not_null":
            for column_not_null in quality_check_parameter:
                red_quality_check_results.append(
                    df_gx.expect_column_values_to_not_be_null(column=column_not_null)
                )

    # Validate all red quality checks, if at least one fails the job stops
    gx_validation.validate_and_log_gx_results(
        quality_check_results=red_quality_check_results,
        validation_level="RED",
        info_message="All quality checks passed",
        error_message="At least one red quality checks is KO, the job has stopped, check corresponding results",
        pipeline_write_env=ENV,
        table_name="UC27_AVERAGE_BOM_bronze",
        log_to_event_table=True,
        log_successes=True,
    )


# COMMAND ----------

# MAGIC %md
# MAGIC # Execute Ingestion

# COMMAND ----------

# MAGIC %md
# MAGIC ## Retrieve budget file in s3 bucket

# COMMAND ----------

df_s3_files = spark.createDataFrame(dbutils.fs.ls(f"{input_file_path_base}"))
name_list = [
    (row.name, row.path)
    for row in df_s3_files.filter((f.col("name").endswith("csv"))).collect()
]
if len(name_list) == 0:
    raise Exception(f"No files in {input_file_path_base}")

log.info(f"Number of file: {len(name_list)}\nFiles names: {name_list}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Main

# COMMAND ----------

quality_checks_table = {}
table_path = {}
for file_name, input_complete_file_path in name_list:
    df = spark.read.options(header="True", delimiter=";").csv(input_complete_file_path)

    df = delete_null_rows(df=df)
    df = remove_start_and_end_spaces_from_column_names(df=df)

    if "removed_columns_space" in CONFIG.keys():
        if CONFIG["removed_columns_space"]:
            df = remove_column_space_dataframe(df=df)

    if "quality_checks" in CONFIG.keys():
        quality_checks_on_input_file(df, config=CONFIG)

    # validate if rules are well written
    df = df.fillna("N/A")
    validate_input_rules.validate_rules(
        rules_df=df, columns_information_rules=columns_information_rules
    )
    columns_rules = [
        column for column in df.columns if column not in columns_information_rules
    ]
    clean_dict = {}
    for column_rule in columns_rules:
        clean_dict[column_rule] = clean_keywords_udf(f.col(column_rule))
    df = df.withColumns(clean_dict)

    # Add a column with the file name - contains the Talend extraction timestamps
    df_with_file_name = df.withColumn(
        "file_name", f.lit(remove_extension(file_name=file_name))
    )
    # Read, if exists, the bronze stack/history table
    extraction_date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:00")
    df_final = df_with_file_name.withColumn("extraction_date", f.lit(extraction_date))
    df_final_id = df_final.withColumn(
        "ID",
        f.concat_ws(
            "_", f.col("file_name"), f.col("extraction_date"), f.col("rule_idx")
        ),
    ).drop("file_name", "extraction_date")
    quality_checks_table[file_name] = df_final_id
    table_path[file_name] = input_complete_file_path

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save and archive tables

# COMMAND ----------

split_dest_table = dest_schema.lower().split(".")
catalog = split_dest_table[0]
domain = split_dest_table[1]
for file_name, df in quality_checks_table.items():
    date, table_name = extract_date_and_table_name(filename=file_name)
    save_table(
        dest_table=f"{catalog}.{domain}.{table_name}_latest",
        df=df,
        mode="overwrite",
        overwrite_schema=True,
    )
    save_table(
        dest_table=f"{catalog}.{domain}.{table_name}_history",
        df=df,
        mode="append",
        merge_schema=True,
    )
    archive_file(folder_path=input_file_path_base, file_name=file_name)
