# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # PBI LOGS INGESTION
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to ingest tables from S3 JSON files, these tables are extracted from PowerBI logs.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - PowerBI logs ingestion.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC - s3://leap-s3-raw-weeu1-{pipeline_read_env}/apps/pbi/*
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC N/A
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_landingzone.pbi.pbi_activity_events_stack
# MAGIC - {pipeline_write_env}_landingzone.pbi.pbi_users_stack
# MAGIC
# MAGIC **Output Files Pipeline**
# MAGIC s3://leap-s3-raw-weeu1-{pipeline_read_env}/archive/apps/pbi/
# MAGIC
# MAGIC **JSON structure of known files**
# MAGIC ```
# MAGIC -PowerBIProUsers
# MAGIC [
# MAGIC     {
# MAGIC         "UserPrincipalName":  "mathieu.neyrolles@latecoere.aero",
# MAGIC         "Mail":  "mathieu.neyrolles@latecoere.aero",
# MAGIC         "DisplayName":  "NEYROLLES Mathieu",
# MAGIC         "CompanyName":  "LAT",
# MAGIC         "Department":  "DOPSL"
# MAGIC     },
# MAGIC     {
# MAGIC         "UserPrincipalName":  "marianne.arnolfo.external@latecoere.aerom",
# MAGIC         "Mail":  "marianne.arnolfo.external@latecoere.aero",
# MAGIC         "DisplayName":  "ARNOLFO Marianne (Archery Consulting)",
# MAGIC         "CompanyName":  "LAT",
# MAGIC         "Department":  "DAMBZ"
# MAGIC     },
# MAGIC     {
# MAGIC         "UserPrincipalName":  "L0037917@latecoereaero.onmicrosoft.com",
# MAGIC         "Mail":  null,
# MAGIC         "DisplayName":  "LALJI Sham",
# MAGIC         "CompanyName":  "AVC3",
# MAGIC         "Department":  "DFIN"
# MAGIC     },
# MAGIC ]
# MAGIC
# MAGIC -PowerBIActivityEvents
# MAGIC [
# MAGIC   {
# MAGIC     "Id": "6c409103-c751-46c9-b14e-f0188fcbce38",
# MAGIC     "RecordType": 20,
# MAGIC     "CreationTime": "2024-01-24T00:42:29Z",
# MAGIC     "Operation": "ViewReport",
# MAGIC     "OrganizationId": "bbd06402-4bce-4ba0-81fd-babe864e4af1",
# MAGIC     "UserType": 0,
# MAGIC     "UserKey": "10032002814B6879",
# MAGIC     "Workload": "PowerBI",
# MAGIC     "UserId": "ivan.kabasakalov@latecoere.aero",
# MAGIC     "ClientIP": "94.156.218.140",
# MAGIC     "UserAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
# MAGIC     "Activity": "ViewReport",
# MAGIC     "ItemName": "Calibration A2P doors",
# MAGIC     "WorkSpaceName": "PersonalWorkspace-Ivan KABASAKALOV",
# MAGIC     "DatasetName": "Calibration A2P doors",
# MAGIC     "ReportName": "Calibration A2P doors",
# MAGIC     "CapacityId": "69ED62D3-EC0E-4CE9-A7A7-97C3973B0E20",
# MAGIC     "CapacityName": "Shared On Premium - Reserved",
# MAGIC     "WorkspaceId": "f2b22c25-7624-406b-8860-25ceebf129a6",
# MAGIC     "ObjectId": "Calibration A2P doors",
# MAGIC     "DatasetId": "fb629a3d-fc61-428e-b486-fd754ac998ce",
# MAGIC     "ReportId": "2f36fc89-a2f5-49ad-9d24-66214ed2bf0f",
# MAGIC     "ArtifactId": "2f36fc89-a2f5-49ad-9d24-66214ed2bf0f",
# MAGIC     "ArtifactName": "Calibration A2P doors",
# MAGIC     "IsSuccess": true,
# MAGIC     "ReportType": "PowerBIReport",
# MAGIC     "RequestId": "99fdc27b-f30c-43b1-beb2-0097b220987a",
# MAGIC     "ActivityId": "62b9ed4d-d139-4f5a-bd8c-da26f139b3a9",
# MAGIC     "DistributionMethod": "Workspace",
# MAGIC     "ConsumptionMethod": "Power BI Web",
# MAGIC     "ArtifactKind": "Report",
# MAGIC     "RefreshEnforcementPolicy": 0
# MAGIC   },
# MAGIC   {
# MAGIC   ...
# MAGIC   }
# MAGIC ]
# MAGIC ```

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. Solve debt for updating null values in CompanyNAme and Department
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
import re
import os
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.types import ArrayType
from typing import List

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

## functions used from "leap_utils.data_asset.table_utils"
#### create_unity_catalog_table()
#### UnityCatalogCheckTableExists()
#### get_latest_version_for_each_id_column()
#### merge_into()
#### save_table()
#### set_table_column_not_null()
#### add_table_primary_key()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ### force_reinitialization Boolean
# MAGIC
# MAGIC force_reinitialization -> Used for force ingestion of all S3 files.

# COMMAND ----------

# If force_reinitialization == True then the stack table will be reinitialized
dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = eval(dbutils.widgets.get("force_reinitialization"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

# Global variables
BUCKET_NAME = f"leap-s3-raw-weeu1-{REFERENCE_READ_ENV}"
PREFIX = "apps/pbi/"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

# regex describing filenames for Activity Events
ACTIVITY_EVENTS_FILENAME_REGEX = r"^(\d{8})_(\d{6})_PowerBIActivityEvents_DELTA.json"

# regex describing filenames for Users
PBI_USERS_FILENAME_REGEX = r"^(\d{8})_(\d{6})_PowerBIProUsers_FULL.json"

# List of dictionaries, each one describing attributes of an expected category of file
FILES_ATTRS_DICT = [
    {
        "table_name": "pbi_activity_events",
        "file_regex": ACTIVITY_EVENTS_FILENAME_REGEX,
        "file_mode": "DELTA",
        "file_expected_cols": [
            "Id",
            "CreationTime",
            "Operation",
            "UserId",
            "ClientIP",
            "Activity",
            "ItemName",
            "WorkSpaceName",
            "DatasetName",
            "ReportName",
            "CapacityId",
            "CapacityName",
            "WorkspaceId",
            "ObjectId",
            "DatasetId",
            "ReportId",
            "ArtifactId",
            "ArtifactName",
            "IsSuccess",
            "ReportType",
            "RequestId",
            "ActivityId",
        ],
        "primary_key": "Id",
        "notnull_cols": "Id, CreationTime",
    },
    {
        "table_name": "pbi_users",
        "file_regex": PBI_USERS_FILENAME_REGEX,
        "file_mode": "FULL",
        "file_expected_cols": [
            "UserPrincipalName",
            "Mail",
            "DisplayName",
            "CompanyName",
            "Department",
        ],
        "primary_key": "UserPrincipalName",
        "notnull_cols": "UserPrincipalName",
    },
]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

ARCHIVE_BUCKET_NAME = (
    f"leap-s3-raw-weeu1-{PIPELINE_WRITE_ENV}"  # Same ENV as output tables
)
ARCHIVE_PREFIX = "archive/apps/pbi/"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

LANDING_ZONE_CATALOG = f"{PIPELINE_WRITE_ENV}_landingzone"
LANDING_ZONE_SCHEMA = "pbi"
BRONZE_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze"
BRONZE_SCHEMA = "pbi"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

TABLE_STACK_FIRST_COLS = {
    "stack_row_id": "BIGINT GENERATED ALWAYS AS IDENTITY COMMENT 'STACK UNIQUE ID GENERATED ALWAYS AS IDENTITY'",
    "extraction_timestamp": "TIMESTAMP",
    "ingestion_timestamp": "TIMESTAMP",
    "file_name": "STRING",
    "file_mode": "STRING",
}

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

THE_ORIGIN = "1970-01-01"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.debug(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.debug(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.debug(f"BUCKET_NAME is:  {BUCKET_NAME}")
log.debug(f"PREFIX is:  {PREFIX}")
log.debug(f"FORCE_REINITIALIZATION is:  {FORCE_REINITIALIZATION}")
log.debug(f"LANDING_ZONE_CATALOG is:  {LANDING_ZONE_CATALOG}")
log.debug(f"LANDING_ZONE_SCHEMA is:  {LANDING_ZONE_SCHEMA}")
log.debug(f"BRONZE_CATALOG is:  {BRONZE_CATALOG}")
log.debug(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC
# MAGIC [USER GUIDE] - [DELETE BELOW BEFORE PROD]
# MAGIC
# MAGIC List of all data inputs, big and small, for the scripts, N.B. that manual lists etc are also data inputs.
# MAGIC
# MAGIC - File reads (check to see if this should not be done by an ingestion script)
# MAGIC - Table read (or specific SQL reads )
# MAGIC - Manual declarations - e.g. hard coded lists *that can't be avoided*
# MAGIC
# MAGIC N.B. Each input should have a markdown cell with a title & description followed by code cell to import
# MAGIC
# MAGIC
# MAGIC Coding practices
# MAGIC - All spark dataframes to start df_
# MAGIC - All pandas dataframes to start dfp_
# MAGIC - Ensure that dataframes are appropriately named: ensure the name is descriptive of content of the dataframe and don't over shorten then name
# MAGIC - Unless for specific performance reasons, import dataframes as "df_xx_raw" and perform preperations in the next stage
# MAGIC
# MAGIC [USER GUIDE] - [DELETE ABOVE BEFORE PROD]
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------


def drop_empty_array_columns(df: SparkDataFrame) -> SparkDataFrame:
    """
    This function takes a Spark DataFrame as input and returns a new DataFrame
    where the Array type columns that are empty (i.e., have no values) are dropped.

    Parameters:
    df (SparkDataFrame): The input DataFrame.

    Returns:
    SparkDataFrame: A new DataFrame with the empty columns dropped.
    """
    # List to store the columns to keep
    columns_to_keep = []

    # Loop through each column
    for field in df.schema.fields:
        # Check if the type is an array
        if isinstance(field.dataType, ArrayType):
            # Add the column to the list if it's not an empty array
            non_empty_array = df.filter(f.size(f.col(field.name)) > 0).count() > 0
            if non_empty_array:
                columns_to_keep.append(field.name)
        else:
            # Keep the columns that are not arrays
            columns_to_keep.append(field.name)

    # Return the DataFrame keeping only the relevant columns
    return df.select(columns_to_keep)


# COMMAND ----------


def list_files_in_s3_bucket_with_prefix(bucket: str, prefix: str) -> List[str]:
    # List files under s3://{bucket}/{prefix} and return a list
    # Input : bucket -> str
    # Input : prefix -> str
    # Output : List of str
    s3_folder_path = f"s3://{bucket}/{prefix}"

    # need dbutils
    try:
        files = dbutils.fs.ls(s3_folder_path)
    except Exception as e:
        print(f"Error reading bucket , error is : {e}")
        return []

    # Create a list of attribute file.name for each file in the list
    file_names = [file.name for file in files]

    # Return the list
    return file_names


# COMMAND ----------


def archive_file(
    source_bucket: str,
    source_prefix: str,
    dest_bucket: str,
    dest_prefix: str,
    filename: str,
) -> bool:
    # move file to archive (dest) folder
    # Input : source_bucket -> str
    # Input : source_prefix -> str
    # Input : dest_bucket -> str
    # Input : dest_prefix -> str
    # Input : filename -> str
    # Output : bool

    source_path = f"s3://{source_bucket}/{source_prefix}{filename}"
    dest_path = f"s3://{dest_bucket}/{dest_prefix}{filename}"
    try:
        dbutils.fs.mv(source_path, dest_path)
    except Exception as e:
        print(f"Erreur archiving file, error is : {e}")
        raise Exception()

    log.info(f"File {filename} archived to {dest_path}\n--")
    return True


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : search_for_json_files
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to search for JSON files on certain criteria.
# MAGIC
# MAGIC **How to call:**
# MAGIC file_list = search_for_json_files(BUCKET_NAME, PREFIX, FILES_ATTRS_DICT[0] )
# MAGIC
# MAGIC **Output:**
# MAGIC List of dicts, each dict having following keys : "filename","filepath","fileprefix","filemode","tablename","timestamp"
# MAGIC

# COMMAND ----------


def search_for_json_files(
    bucket: str, dir_prefix: str, search_attributes: dict
) -> List[dict]:
    # Search files to process in s3://{bucket}/{dir_prefix} that match regex and return a list
    # Input : bucket -> type str
    # Input : dirprefix -> type str
    # Input : search_attributes -> type dict with following expected keys :
    #
    """
    {
    "table_name": "<table_name>",
    "file_regex": "<regex name>",
    "file_mode": "FULL|DELTA"
    }
    """
    # Output : List of dict
    # Example of Output :
    """
        [{
            "filename": "<filename>",  #ex: '20240222_101620_PowerBIActivityEvents_DELTA.json'
            "filepath": "<filepath>",  #ex: 's3://leap-s3-raw-weeu1-dev/apps/pbi/20240222_101620_PowerBIActivityEvents_DELTA.json'
            "fileprefix": "<fileprefix>",  #ex: 'PowerBIActivityEvents'
            "filemode": 'FULL' or 'DELTA',
            "tablename": "<bronze table_name>", #ex: 'pbi_activity_events'
            "timestamp": "<extraction_timestamp>",  #ex: '2024-02-22T10:16:20Z'
        },
        {
            "filename": "<filename>",
            "filepath": "<filepath>",
            "fileprefix": "<fileprefix>",
            "filemode": 'FULL' or 'DELTA',
            "tablename": "<bronze table_name>",
            "timestamp": "<extraction_timestamp>",
        }
        ]
    """

    # Get the list of all objects in the bucket and prefix
    file_list = list_files_in_s3_bucket_with_prefix(bucket, dir_prefix)

    # Filter file_list
    file_list = [
        file for file in file_list if re.match(search_attributes["file_regex"], file)
    ]

    # Returned file list
    json_file_list = []

    for filename in file_list:
        match = re.match(search_attributes["file_regex"], filename)
        if match:
            date = match.group(1)
            timestamp = match.group(2)
            filepath = os.path.join(f"s3://{bucket}", dir_prefix, filename)
            fileprefix = os.path.splitext(os.path.basename(filename))[0].split("_")[2]
            # convert strings from format "YYYYMMDD" and "HHmmss" to timestamp
            last_modified_datetime = time.strptime(
                f"{date} {timestamp}", "%Y%m%d %H%M%S"
            )
            # convert timestamp to string
            last_modified_string = (
                time.strftime("%Y-%m-%dT%H:%M:%S", last_modified_datetime) + "Z"
            )
            log.debug(
                f"search_for_json_files(): Found file to process : {filename}.\n--"
            )
            json_file_list.append(
                {
                    "filename": filename,
                    "filepath": filepath,
                    "fileprefix": fileprefix,
                    "filemode": search_attributes["file_mode"],
                    "tablename": search_attributes["table_name"],
                    "timestamp": last_modified_string,
                }
            )
        else:
            log.info(f"File ignored {filename} , bad format !!!\n--")

    return json_file_list


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : process_json_files
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to load JSON files, write stack tables and add primary key.
# MAGIC
# MAGIC **How to call:**
# MAGIC process_json_files(files_dict_list, file_expected_cols, file_table_name, file_table_primary_key_columns, file_table_notnull_columns )
# MAGIC
# MAGIC **Output:**
# MAGIC N/A

# COMMAND ----------


def process_json_files(
    files_dict_list: List[dict],
    file_expected_cols: List[str],
    file_table_name: str,
    file_table_primary_key_columns: str,
    file_table_notnull_columns: str,
):
    """
    Process each file in the list of dict, reading JSON file and writing to a corresponding delta table
    Input : files_dict_list -> type "List of dict" where dict contains the following expected keys :
        {
            "filename": "<filename>",  #ex: '20240222_101620_PowerBIActivityEvents_DELTA.json'
            "filepath": "<filepath>",  #ex: 's3://leap-s3-raw-weeu1-dev/apps/pbi/20240222_101620_PowerBIActivityEvents_DELTA.json'
            "fileprefix": "<fileprefix>",  #ex: 'PowerBIActivityEvents'
            "filemode": 'FULL' or 'DELTA',
            "tablename": "<bronze table_name>", #ex: 'pbi_activity_events'
            "timestamp": "<extraction_timestamp>",  #ex: '2024-02-22T10:16:20Z'
        }
    Input : file_expected_cols -> type "List of str"
    Input : file_table_name -> type "str"
    Input : file_table_primary_key_columns -> type "str"
    Input : file_table_notnull_columns -> type "str"
    Output : None
    """

    table_name = file_table_name + "_stack"
    # output table in Databricks Unity Catalog
    output_table_Path = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}"
    output_table_Path = output_table_Path.strip().lower()

    # Create unity catalog table if it does not exist, or reinitialize table if param set to True
    try:
        table_utils.create_unity_catalog_table(
            catalog=LANDING_ZONE_CATALOG,
            domain=LANDING_ZONE_SCHEMA,
            table=table_name,
            force_reinitialization=FORCE_REINITIALIZATION,
            cluster_cols=None,
            partition_col="extraction_timestamp",
            primary_key_cols="stack_row_id",
            columns=TABLE_STACK_FIRST_COLS,
            force_drop=False,
        )
    except AnalysisException as e:
        log.error(
            f"Table {output_table_Path} has not been created, an error occured during creation.\nException is :{e}\n"
        )
        raise Exception()

    # Loop through the JSON files
    for file_dict in files_dict_list:
        # Read JSON Data file
        spark.conf.set("spark.sql.legacy.parseDoublesAsDecimal", False)
        spark.conf.set("spark.sql.legacy.multiLine", True)
        spark.conf.set("spark.sql.legacy.wholeFile", True)

        startTime = time.time()

        file_name = file_dict["filename"].strip()
        file_path = file_dict["filepath"].strip()
        file_mode = file_dict["filemode"].strip()

        log.info(f"--------\nProcessing file {file_name}.\n--------\n")

        # Get file timestamp
        file_modification_timestamp = file_dict["timestamp"]

        # Read JSON file
        df_raw = (
            spark.read.option("multiLine", "true")
            .option("mode", "PERMISSIVE")
            .option("columnNameOfCorruptRecord", "corrupt_record")
            .option("inferSchema", "true")
            .option("nullValue", "")
            .json(file_path)
        )

        # Convert extraction_timestamp to format `TimestampType`
        df_raw_ets = df_raw.withColumn(
            "extraction_timestamp",
            f.to_timestamp(
                f.lit(file_modification_timestamp), "yyyy-MM-dd'T'HH:mm:ss'Z'"
            ),
        )

        # Add ingestion_timestamp metadata
        df_raw_its = df_raw_ets.withColumn("ingestion_timestamp", f.current_timestamp())

        # Add file_name metadata
        df_raw_fnam = df_raw_its.withColumn("file_name", f.lit(file_name))

        # Add file_mode metadata
        df_raw_fmod = df_raw_fnam.withColumn("file_mode", f.lit(file_mode))

        # Prepare metadatas columns for reordering
        metadatas = []
        if "Id" in df_raw_fmod.columns:
            metadatas.append("Id")
        metadatas.extend(
            ["extraction_timestamp", "ingestion_timestamp", "file_name", "file_mode"]
        )
        # Prepare datas columns for reordering
        datas = [col for col in df_raw_fmod.columns if col not in metadatas]

        # Reorder columns
        df_reordered = df_raw_fmod.select(*(metadatas + datas))

        # Convert all columns containing timestamps, from type string to type to timestamp
        timestamp_cols = [
            cname
            for cname, dtype in df_reordered.dtypes
            if dtype == "string"
            and (
                "_date" in cname.lower()
                or "time" in cname.lower()
                or cname in ("Created", "Modified", "Creation", "Modification")
            )
        ]
        for cname in timestamp_cols:
            df_reordered = df_reordered.withColumn(
                cname, f.to_timestamp(cname, "yyyy-MM-dd'T'HH:mm:ss'Z'")
            )

        # Remove empty arrays columns to avoid errors in mergeschema
        df_reordered = drop_empty_array_columns(df_reordered)

        # Check requestes columns
        all_req_columns = all(col in df_reordered.columns for col in file_expected_cols)
        if all_req_columns:
            log.info(f"Expected columns all OK : {file_expected_cols}")
        else:
            missing_cols = [
                col for col in file_expected_cols if col not in df_reordered.columns
            ]
            log.error(
                f"Table {table_name} has not expected columns: \n missing columns : {missing_cols} \n actual columns : {df_reordered.columns}"
            )
            df_reordered.printSchema()
            raise Exception()

        # Quality checks with great_expectations : uniqueness for file_table_primary_key_columns and notnull for file_table_notnull_columns
        # Raise an Exception if not pass the checks
        primary_key_columns = file_table_primary_key_columns.split(",")
        for one_col in primary_key_columns:
            gx_validation.gx_check_uniqueness(
                df=df_raw,
                col=one_col.strip(),
                validation_level="RED",
                pipeline_write_env=PIPELINE_WRITE_ENV,
                table_name="pbi_logs_bronze",
            )

        notnull_columns = file_table_notnull_columns.split(",")
        for one_col in notnull_columns:
            gx_validation.gx_check_not_null(
                df=df_raw,
                col=one_col.strip(),
                validation_level="RED",
                pipeline_write_env=PIPELINE_WRITE_ENV,
                table_name="pbi_logs_bronze",
            )

        # Check if extraction_timestamp already exists to avoid duplicates and if yes delete previous extraction_timestamp
        df_table_stack = spark.read.table(output_table_Path)
        is_extraction_timestamp_existing = df_table_stack.filter(
            f.col("extraction_timestamp") == f.lit(file_modification_timestamp)
        ).first()
        if is_extraction_timestamp_existing:
            spark.sql(
                f"""DELETE FROM {output_table_Path} WHERE extraction_timestamp = '{file_modification_timestamp}' """
            )

        try:
            table_utils.save_table(
                dest_table=output_table_Path,
                df=df_reordered,
                mode="append",
                overwrite_schema=False,
                merge_schema=True,
            )
        except AnalysisException as e:
            log.error(
                f"Table {output_table_Path} has not been created, an error occured during creation. {e}"
            )
            df_reordered.printSchema()
            raise Exception()

        duration = time.time() - startTime
        log.info(
            f"--------\nData from file {file_name} has been written to Delta Lake table {output_table_Path} in {duration} seconds.\n--------\n"
        )

        if PIPELINE_WRITE_ENV == "prod":
            status = archive_file(
                BUCKET_NAME, PREFIX, ARCHIVE_BUCKET_NAME, ARCHIVE_PREFIX, file_name
            )


# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks - Functions

# COMMAND ----------


# N/A


# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Files Read
# MAGIC - Build the stack tables
# MAGIC - Files Archiving

# COMMAND ----------

Found = False
for attr_dict in FILES_ATTRS_DICT:
    # Search in S3 for files corresponding to those prefixes {FILE_PREFIX_LIST} and build a list of files to ingest
    json_file_list = search_for_json_files(BUCKET_NAME, PREFIX, attr_dict)
    table_name = attr_dict["table_name"]
    primary_key = attr_dict["primary_key"]
    notnull_cols = attr_dict["notnull_cols"]

    if len(json_file_list) != 0:
        # Process the ingestion of files from the list
        file_expected_cols = attr_dict["file_expected_cols"]
        process_json_files(
            json_file_list, file_expected_cols, table_name, primary_key, notnull_cols
        )
        Found = True

if not Found:
    log.info(f"No file to process !!!\n--------\n")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1
# MAGIC
# MAGIC No specific preparation identified

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

## Quality Checks - Common Functions defined in leap_utils

#### validate_and_log_gx_results()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - Uniqueness
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Quality checks are done in file ingestion above
# in the section ## Inputs Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 2 - Not null expectation
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Quality checks are done in file ingestion above
# in the section ## Inputs Processing

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------


def process_single_latest_table(
    table_name: str,
    input_table_path: str,
    primary_key_columns: str,
    output_table_path: str,
) -> SparkDataFrame:
    """
    process latest for a single table
    return {SparkDataFrame} if ok, or None if not
    """

    startTime = time.time()

    # Read stack table
    df_table_stack = spark.read.table(input_table_path)

    Unity_Catalog_Table_Name = f"{table_name.lower()}_latest"

    # get the last_existing_timestamp_of_extraction
    last_existing_timestamp_of_extraction = df_table_stack.select(
        f.max("extraction_timestamp")
    ).first()["max(extraction_timestamp)"]
    log.info(
        f"the last timestamp in Stack table is : {last_existing_timestamp_of_extraction}"
    )

    # Get the mode of extraction
    df_filtered = df_table_stack.filter(
        df_table_stack.extraction_timestamp == last_existing_timestamp_of_extraction
    )
    file_mode = list(
        df_filtered.select("file_mode").drop_duplicates().toPandas()["file_mode"]
    )

    if len(file_mode) > 1:
        raise Exception(
            f"Different SAP modes of extraction appears on table : {table_name} , modes are : {file_mode}"
        )

    # if file_mode == "FULL" then  latest_table = latest_extraction_timestamp in stack
    if file_mode[0] == "FULL":
        log.info(f"Stack table is in FULL mode")
        df_latest = df_filtered
    else:
        log.info(f"Stack table is in DELTA mode")

        # if latest_table already exists and FORCE_REINITIALIZATION == False then latest_table processed with MERGE INTO method
        # else latest_table processed with legacy method
        if (table_utils.UnityCatalogCheckTableExists(output_table_path)) and (
            FORCE_REINITIALIZATION == False
        ):
            log.info(f"Using MERGE INTO method")

            # Read latest table
            df_table_latest = spark.read.table(output_table_path)

            # get the last_existing_timestamp in latest table
            last_existing_timestamp_in_latest = df_table_latest.select(
                f.max("extraction_timestamp")
            ).first()["max(extraction_timestamp)"]

            if last_existing_timestamp_in_latest is None:
                last_existing_timestamp_in_latest = THE_ORIGIN

            log.info(
                f"the last timestamp in {Unity_Catalog_Table_Name} is : {last_existing_timestamp_in_latest}"
            )

            df_from_last_run_to_current_date = df_table_stack.filter(
                (
                    df_table_stack.extraction_timestamp
                    > last_existing_timestamp_in_latest
                )
            )

            # For each ID in Dataframe keep the latest extraction_timestamp
            df_from_last_run_to_current_date_filtered = (
                table_utils.get_latest_version_for_each_id_column(
                    df_from_last_run_to_current_date,
                    primary_key_columns,
                    "extraction_timestamp",
                )
            )
            log.info(
                f"{df_from_last_run_to_current_date_filtered.count()} rows to merge"
            )

            # MERGE INTO latest table
            try:
                table_utils.merge_into(
                    df_source=df_from_last_run_to_current_date_filtered,
                    target_table=output_table_path,
                    list_id_matching_columns=[primary_key_columns],
                ).display()

            except Exception as e:
                log.error(
                    f"Table {output_table_path} has not been created, an error occured during MERGE INTO."
                )
                all_target_cols = [
                    x[0]
                    for x in spark.sql(f"DESCRIBE {output_table_path}")
                    .select("col_name")
                    .collect()
                ]
                log.error(
                    f"Dataframe cols : {df_from_last_run_to_current_date_filtered.columns}\n----\n"
                )
                log.error(f"Tables cols : {all_target_cols}\n----\n")
                return None
            else:
                duration = time.time() - startTime
                log.info(f"Table {output_table_path} merged in {duration} seconds.")
                return f"{output_table_path}"
        else:
            # get the lastest existing_timestamp where mode == FULL mode in the stack table
            max_date_full = (
                df_table_stack.filter(df_table_stack.file_mode == "FULL")
                .select(f.max("extraction_timestamp"))
                .first()["max(extraction_timestamp)"]
            )
            if max_date_full:
                df_from_last_full_to_current_date = df_table_stack.filter(
                    (df_table_stack.extraction_timestamp >= max_date_full)
                )
            else:
                df_from_last_full_to_current_date = df_table_stack

            # For each ID in Dataframe keep the latest extraction_timestamp
            df_latest = table_utils.get_latest_version_for_each_id_column(
                df_from_last_full_to_current_date,
                primary_key_columns,
                "extraction_timestamp",
            )

    # Save the latest table from Dataframe df_latest
    try:
        result = table_utils.save_table(
            dest_table=output_table_path,
            df=df_latest,
            mode="overwrite",
            overwrite_schema=True,
        )
    except AnalysisException as e:
        log.error(
            f"Table {output_table_path} has not been created, an error occured during creation.\nException is :{e}\n"
        )
        return None
    else:
        duration = time.time() - startTime
        log.info(f"Table {output_table_path} created in {duration} seconds.")

    # Add Primary Key if not exists
    catalog, schema, table = output_table_path.split(".")
    pk_name = f"{Unity_Catalog_Table_Name}_pk"
    nb_cons = spark.sql(
        f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
    ).first()[0]
    if nb_cons == 0:
        # set_table_column_not_null and add_table_primary_key
        try:
            table_utils.set_table_column_not_null(
                table_path=f"{output_table_path}",
                column=primary_key_columns,
            )
            table_utils.add_table_primary_key(
                table_path=f"{output_table_path}",
                pk_name=f"{pk_name}",
                columns=primary_key_columns,
            )
        except AnalysisException as e:
            log.error(f"Error adding PRIMARY KEY to table {output_table_path} ")

    return f"{output_table_path}"


# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Latest tables Processing
# MAGIC - Read stack tables
# MAGIC - Build the latest tables from stack
# MAGIC

# COMMAND ----------

for attr_dict in FILES_ATTRS_DICT:
    # Process each table
    table_name = attr_dict["table_name"]
    primary_key = attr_dict["primary_key"]
    notnull_cols = attr_dict["notnull_cols"]
    log.info(
        f"--------\ntable_name = '{table_name}', primary_key = '{primary_key}', notnull_cols = '{notnull_cols}'"
    )

    # input / output table in Databricks Unity Catalog
    input_table_Path = (
        f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}_stack"
    )
    input_table_Path = input_table_Path.strip().lower()
    output_table_Path = f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest"
    output_table_Path = output_table_Path.strip().lower()

    log.info(f"Processing input table : {input_table_Path}.")

    # Process stack table to latest table
    repeat = True
    while repeat:
        output_table_path = process_single_latest_table(
            table_name, input_table_Path, primary_key, output_table_Path
        )
        if output_table_path is not None:
            log.info(
                f"Processed successfully {table_name} , to {output_table_path}\n--------\n"
            )
            repeat = False
        else:
            if FORCE_REINITIALIZATION == False:
                FORCE_REINITIALIZATION = True
                log.error(
                    f"Processed unsuccessfully {table_name} , to {output_table_path} -> Retrying with reinitialization of the table\n--------\n"
                )
            else:
                log.error(
                    f"Processed unsuccessfully {table_name} , to {output_table_path} -> Aborting\n--------\n"
                )
                raise Exception()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced

# COMMAND ----------

# DBTITLE 1,Fix technical debt
spark.sql(
    f"UPDATE {PIPELINE_WRITE_ENV}_bronze.pbi.pbi_users_latest SET CompanyName = 'UNKNOWN' WHERE CompanyName IS NULL;"
)
spark.sql(
    f"UPDATE {PIPELINE_WRITE_ENV}_bronze.pbi.pbi_users_latest SET Department = 'UNKNOWN' WHERE Department IS NULL;"
)
spark.sql(
    f"UPDATE {PIPELINE_WRITE_ENV}_bronze.pbi.pbi_users_latest SET Mail = 'UNKNOWN' WHERE Mail IS NULL;"
)
