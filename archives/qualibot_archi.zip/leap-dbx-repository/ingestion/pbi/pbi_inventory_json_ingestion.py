# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # PBI Inventory Ingestion
# MAGIC
# MAGIC **Description:**
# MAGIC Ingests the daily Power BI tenant inventory: every workspace, report and semantic model, with the Power Query
# MAGIC expression behind each model table. The JSON is nested five levels deep and is flattened here into one stack table
# MAGIC per entity, then the latest extraction of each is published to Bronze. Files are archived once ingested in
# MAGIC production, like the other files of the folder.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - A semantic model is repeated under every report built on it, so model-level rows are deduplicated — see
# MAGIC   *Preparation - Flatten the inventory*
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - UC091 Leap Suite Overview — Power BI Inventory
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC - `s3://leap-s3-raw-weeu1-{reference_read_env}/apps/pbi/YYYYMMDD_HHMMSS_powerBI_attribute_FULL.json`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - *(none)*
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_landingzone.pbi.pbi_inventory_workspaces_stack`
# MAGIC - `{pipeline_write_env}_landingzone.pbi.pbi_inventory_reports_stack`
# MAGIC - `{pipeline_write_env}_landingzone.pbi.pbi_inventory_model_tables_stack`
# MAGIC - `{pipeline_write_env}_landingzone.pbi.pbi_inventory_model_parameters_stack`
# MAGIC - `{pipeline_write_env}_landingzone.pbi.pbi_inventory_model_datasources_stack`
# MAGIC - `{pipeline_write_env}_bronze.pbi.pbi_inventory_workspaces_latest`
# MAGIC - `{pipeline_write_env}_bronze.pbi.pbi_inventory_reports_latest`
# MAGIC - `{pipeline_write_env}_bronze.pbi.pbi_inventory_model_tables_latest`
# MAGIC - `{pipeline_write_env}_bronze.pbi.pbi_inventory_model_parameters_latest`
# MAGIC - `{pipeline_write_env}_bronze.pbi.pbi_inventory_model_datasources_latest`
# MAGIC
# MAGIC **Output Files Pipeline**
# MAGIC - `s3://leap-s3-raw-weeu1-{pipeline_write_env}/archive/apps/pbi/` (production only)

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC 1. Personal workspaces are not in the inventory file, so their models never reach Bronze; the extract must include them.

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Package Imports

# COMMAND ----------

import re

import great_expectations as gx
import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ## LEAP Function Imports

# COMMAND ----------

from leap_utils.common import logger
from leap_utils.common.files import files_utils
from leap_utils.common.validation import gx_validation
from leap_utils.data_asset.table_utils import save_table

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Other config
# MAGIC
# MAGIC The folder is shared with the activity logs files, which another ingestion owns; only inventory files are taken.
# MAGIC Archiving is production only, as for those files: a development run must not take a file away from production.
# MAGIC Only full extracts are taken (`_FULL`, or no suffix): the Latest tables treat each file as the whole inventory, so a
# MAGIC partial `_DELTA` extract would drop every report it does not list.

# COMMAND ----------

SOURCE_BUCKET = f"leap-s3-raw-weeu1-{REFERENCE_READ_ENV}"
SOURCE_PREFIX = "apps/pbi/"
ARCHIVE_BUCKET = f"leap-s3-raw-weeu1-{PIPELINE_WRITE_ENV}"
ARCHIVE_PREFIX = "archive/apps/pbi/"
ARCHIVE_ENV = "prod"

INVENTORY_FILE_PATTERN = re.compile(r"^\d{8}_\d{6}_powerBI_attribute(_FULL)?\.json$")
HAS_NEW_INVENTORY_TASK_VALUE = "has_new_inventory"

LANDING_SCHEMA = f"{PIPELINE_WRITE_ENV}_landingzone.pbi"
BRONZE_SCHEMA = f"{PIPELINE_WRITE_ENV}_bronze.pbi"
ENTITIES = ["workspaces", "reports", "model_tables", "model_parameters", "model_datasources"]
STACK_TABLES = {entity: f"{LANDING_SCHEMA}.pbi_inventory_{entity}_stack" for entity in ENTITIES}
LATEST_TABLES = {entity: f"{BRONZE_SCHEMA}.pbi_inventory_{entity}_latest" for entity in ENTITIES}

# The extract writes a UTF-8 byte order mark, which the JSON parser would read as an invalid first character.
BYTE_ORDER_MARK = "﻿"

# Declared rather than inferred: an inferred schema shifts whenever a run happens to have no value for a field.
INVENTORY_SCHEMA = """
GeneratedUtc STRING,
Workspaces ARRAY<STRUCT<
  Id: STRING, Name: STRING, Description: STRING, DomainId: STRING, Domain: STRING,
  Tags: ARRAY<STRUCT<Id: STRING, Name: STRING>>,
  Contacts: ARRAY<STRUCT<DisplayName: STRING, Email: STRING>>,
  Reports: ARRAY<STRUCT<
    Id: STRING, Name: STRING, Description: STRING, ReportType: STRING, WebUrl: STRING, ModifiedBy: STRING,
    Contacts: ARRAY<STRUCT<DisplayName: STRING, Email: STRING>>,
    Tags: ARRAY<STRUCT<Id: STRING, Name: STRING>>,
    SemanticModel: STRUCT<
      Id: STRING, Name: STRING, WorkspaceId: STRING, Note: STRING,
      DataSources: ARRAY<STRUCT<
        DataSourceType: STRING,
        ConnectionDetails: STRUCT<
          database: STRING, extensionDataSourceKind: STRING, extensionDataSourcePath: STRING, path: STRING,
          server: STRING, sharePointSiteUrl: STRING, url: STRING
        >
      >>,
      Expressions: ARRAY<STRUCT<Name: STRING, Description: STRING, Expression: STRING>>,
      Tables: ARRAY<STRUCT<Name: STRING, IsHidden: BOOLEAN, Source: ARRAY<STRUCT<Expression: STRING>>>>
    >
  >>
>>
"""

# The dashboard lineage is built from the model tables' expressions; an extract without them would empty it.
# Some model tables legitimately have none (calculated tables), about 6% today.
MIN_SHARE_OF_MODEL_TABLES_WITH_EXPRESSION = 0.8

log.info(f"Source folder: s3://{SOURCE_BUCKET}/{SOURCE_PREFIX}")
log.info(f"Archive folder: s3://{ARCHIVE_BUCKET}/{ARCHIVE_PREFIX} (archiving on {ARCHIVE_ENV} only)")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## File reads
# MAGIC
# MAGIC Each file is read whole, as one text row, and parsed with the declared schema. Files left in the folder are
# MAGIC re-ingested on the next run, which is harmless: a stack is rewritten per extraction.

# COMMAND ----------

inventory_files = sorted(
    path
    for path in files_utils.list_files_in_s3_bucket_with_prefix(SOURCE_BUCKET, SOURCE_PREFIX)
    if INVENTORY_FILE_PATTERN.match(path.split("/")[-1])
)
log.info(f"Inventory files to ingest: {len(inventory_files)}")
for path in inventory_files:
    log.info(f"  {path}")

# The job also starts on the activity logs files of the folder; Silver, Gold and the lineage only follow a new
# inventory.
if not inventory_files:
    dbutils.jobs.taskValues.set(HAS_NEW_INVENTORY_TASK_VALUE, False)
    dbutils.notebook.exit("No inventory file to ingest")

df_inventory_raw = spark.read.text(inventory_files, wholetext=True).select(
    f.col("_metadata.file_name").alias("file_name"),
    f.from_json(f.regexp_replace(f.col("value"), f"^{BYTE_ORDER_MARK}", ""), INVENTORY_SCHEMA).alias("inventory"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Extraction timestamp
# MAGIC
# MAGIC The extraction time is the generation time written inside the file, in UTC; the file name carries local time.
# MAGIC A file the schema cannot read has no generation time, which the RED check below catches.

# COMMAND ----------

df_inventory_prep = df_inventory_raw.select(
    "file_name",
    f.col("inventory.GeneratedUtc").try_cast("timestamp").alias("extraction_timestamp"),
    "inventory",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Flatten the inventory
# MAGIC
# MAGIC A model's tables, parameters and data sources are repeated under each report built on it; identical rows are
# MAGIC collapsed, and the uniqueness check in *Quality Checks* would catch two differing copies of the same model.

# COMMAND ----------

df_workspaces_exploded = df_inventory_prep.select(
    "extraction_timestamp", "file_name", f.explode("inventory.Workspaces").alias("workspace")
)

df_reports_exploded = df_workspaces_exploded.select(
    "extraction_timestamp",
    "file_name",
    f.col("workspace.Id").alias("WorkspaceId"),
    f.explode("workspace.Reports").alias("report"),
)

df_models_exploded = df_reports_exploded.where(f.col("report.SemanticModel.Id").isNotNull()).select(
    "extraction_timestamp",
    "file_name",
    f.col("report.SemanticModel.Id").alias("SemanticModelId"),
    f.col("report.SemanticModel").alias("model"),
)

df_workspaces_end = df_workspaces_exploded.select(
    "extraction_timestamp",
    "file_name",
    f.col("workspace.Id").alias("WorkspaceId"),
    f.col("workspace.Name").alias("WorkspaceName"),
    f.col("workspace.Description").alias("WorkspaceDescription"),
    f.col("workspace.DomainId").alias("DomainId"),
    f.col("workspace.Domain").alias("Domain"),
    f.col("workspace.Tags.Name").alias("Tags"),
    f.col("workspace.Contacts.Email").alias("ContactEmails"),
)

df_reports_end = df_reports_exploded.select(
    "extraction_timestamp",
    "file_name",
    "WorkspaceId",
    f.col("report.Id").alias("ReportId"),
    f.col("report.Name").alias("ReportName"),
    f.col("report.Description").alias("ReportDescription"),
    f.col("report.ReportType").alias("ReportType"),
    f.col("report.WebUrl").alias("WebUrl"),
    f.col("report.ModifiedBy").alias("ModifiedBy"),
    f.col("report.Tags.Name").alias("Tags"),
    f.col("report.Contacts.Email").alias("ContactEmails"),
    f.col("report.SemanticModel.Id").alias("SemanticModelId"),
    f.col("report.SemanticModel.Name").alias("SemanticModelName"),
    f.col("report.SemanticModel.WorkspaceId").alias("SemanticModelWorkspaceId"),
    f.col("report.SemanticModel.Note").alias("SemanticModelNote"),
)

df_model_tables_end = (
    df_models_exploded.select(
        "extraction_timestamp", "file_name", "SemanticModelId", f.explode("model.Tables").alias("model_table")
    )
    .select(
        "extraction_timestamp",
        "file_name",
        "SemanticModelId",
        f.col("model_table.Name").alias("TableName"),
        f.col("model_table.IsHidden").alias("IsHidden"),
        f.posexplode_outer("model_table.Source").alias("SourceIndex", "source"),
    )
    .select(
        "extraction_timestamp",
        "file_name",
        "SemanticModelId",
        "TableName",
        "IsHidden",
        "SourceIndex",
        f.col("source.Expression").alias("Expression"),
    )
    .dropDuplicates()
)

df_model_parameters_end = (
    df_models_exploded.select(
        "extraction_timestamp", "file_name", "SemanticModelId", f.explode("model.Expressions").alias("parameter")
    )
    .select(
        "extraction_timestamp",
        "file_name",
        "SemanticModelId",
        f.col("parameter.Name").alias("ParameterName"),
        f.col("parameter.Description").alias("ParameterDescription"),
        f.col("parameter.Expression").alias("Expression"),
    )
    .dropDuplicates()
)

df_model_datasources_end = (
    df_models_exploded.select(
        "extraction_timestamp",
        "file_name",
        "SemanticModelId",
        f.posexplode("model.DataSources").alias("DataSourceIndex", "datasource"),
    )
    .select(
        "extraction_timestamp",
        "file_name",
        "SemanticModelId",
        "DataSourceIndex",
        f.col("datasource.DataSourceType").alias("DataSourceType"),
        f.col("datasource.ConnectionDetails.extensionDataSourceKind").alias("ConnectionKind"),
        f.col("datasource.ConnectionDetails.extensionDataSourcePath").alias("ConnectionPath"),
        f.col("datasource.ConnectionDetails.server").alias("Server"),
        f.col("datasource.ConnectionDetails.database").alias("Database"),
        f.col("datasource.ConnectionDetails.path").alias("Path"),
        f.col("datasource.ConnectionDetails.url").alias("Url"),
        f.col("datasource.ConnectionDetails.sharePointSiteUrl").alias("SharePointSiteUrl"),
    )
    .dropDuplicates()
)

entity_frames = {
    "workspaces": df_workspaces_end,
    "reports": df_reports_end,
    "model_tables": df_model_tables_end,
    "model_parameters": df_model_parameters_end,
    "model_datasources": df_model_datasources_end,
}

if DEBUG:
    for entity, df_entity in entity_frames.items():
        log.debug(entity)
        df_entity.limit(5).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks
# MAGIC
# MAGIC RED: a file the schema cannot read, an entity key repeated within one extraction, or a newest file without the
# MAGIC model expressions would publish a partial, double-counted or lineage-less inventory.

# COMMAND ----------

dfgx_inventory = gx.dataset.SparkDFDataset(df_inventory_prep, persist=False)
dfgx_workspaces = gx.dataset.SparkDFDataset(df_workspaces_end, persist=False)
dfgx_reports = gx.dataset.SparkDFDataset(df_reports_end, persist=False)
dfgx_model_tables = gx.dataset.SparkDFDataset(df_model_tables_end, persist=False)
dfgx_model_parameters = gx.dataset.SparkDFDataset(df_model_parameters_end, persist=False)
dfgx_model_datasources = gx.dataset.SparkDFDataset(df_model_datasources_end, persist=False)

# Only the newest file becomes the Bronze latest tables, so only it must carry the expressions; an older file
# left in the folder is stacked as it is.
newest_extraction = df_inventory_prep.agg(f.max("extraction_timestamp")).first()[0]
dfgx_newest_model_tables = gx.dataset.SparkDFDataset(
    df_model_tables_end.where(f.col("extraction_timestamp") == f.lit(newest_extraction)), persist=False
)

red_results = [
    dfgx_inventory.expect_column_values_to_not_be_null(column="extraction_timestamp"),
    dfgx_workspaces.expect_compound_columns_to_be_unique(column_list=["extraction_timestamp", "WorkspaceId"]),
    dfgx_reports.expect_compound_columns_to_be_unique(column_list=["extraction_timestamp", "ReportId"]),
    dfgx_model_tables.expect_compound_columns_to_be_unique(
        column_list=["extraction_timestamp", "SemanticModelId", "TableName", "SourceIndex"]
    ),
    dfgx_model_parameters.expect_compound_columns_to_be_unique(
        column_list=["extraction_timestamp", "SemanticModelId", "ParameterName"]
    ),
    dfgx_model_datasources.expect_compound_columns_to_be_unique(
        column_list=["extraction_timestamp", "SemanticModelId", "DataSourceIndex"]
    ),
    dfgx_newest_model_tables.expect_column_values_to_not_be_null(
        column="Expression", mostly=MIN_SHARE_OF_MODEL_TABLES_WITH_EXPRESSION
    ),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="Power BI inventory: every file parsed, and every entity key is unique within its extraction.",
    error_message="Power BI inventory: a file did not match the declared schema, an entity key is repeated within "
    "one extraction, or the newest file lacks the model expressions — the extract format may have changed.",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Stack tables
# MAGIC
# MAGIC Each run replaces the rows of the extractions it ingests, so a file ingested twice is not stacked twice.

# COMMAND ----------

extraction_timestamps = sorted(
    row["extraction_timestamp"] for row in df_inventory_prep.select("extraction_timestamp").distinct().collect()
)
replace_condition = "extraction_timestamp IN ({})".format(
    ", ".join(f"TIMESTAMP'{timestamp.isoformat(sep=' ')}'" for timestamp in extraction_timestamps)
)
log.info(f"Extractions ingested: {replace_condition}")

for entity, df_entity in entity_frames.items():
    stack_table = STACK_TABLES[entity]
    if spark.catalog.tableExists(stack_table):
        save_table(
            dest_table=stack_table,
            df=df_entity,
            mode="overwrite",
            overwrite_schema=False,
            merge_schema=True,
            replace_where=replace_condition,
        )
    else:
        save_table(dest_table=stack_table, df=df_entity, mode="overwrite", overwrite_schema=True)
    log.info(f"Saved: {stack_table}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Latest tables
# MAGIC
# MAGIC Every file is a full inventory, so the latest extraction alone is the current state.

# COMMAND ----------

for entity in ENTITIES:
    df_stack = spark.table(STACK_TABLES[entity])
    latest_extraction = df_stack.agg(f.max("extraction_timestamp")).first()[0]
    save_table(
        dest_table=LATEST_TABLES[entity],
        df=df_stack.where(f.col("extraction_timestamp") == f.lit(latest_extraction)),
        mode="overwrite",
        overwrite_schema=True,
    )
    log.info(f"Saved: {LATEST_TABLES[entity]} (extraction {latest_extraction})")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

if PIPELINE_WRITE_ENV == ARCHIVE_ENV:
    for path in inventory_files:
        files_utils.archive_file(SOURCE_BUCKET, SOURCE_PREFIX, ARCHIVE_BUCKET, ARCHIVE_PREFIX, path.split("/")[-1])
else:
    log.info(f"Files left in place: archiving runs on {ARCHIVE_ENV} only.")

dbutils.jobs.taskValues.set(HAS_NEW_INVENTORY_TASK_VALUE, True)
