# Databricks notebook source
# MAGIC %md
# MAGIC # Template tables for budget app
# MAGIC #
# MAGIC - Notebook for table Creation / Reinitialization
# MAGIC
# MAGIC Run on serverless as well as on job cluster

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.dropdown(
    "target_env", "dev", ["dev", "uat", "prod"], "Target environment"
)

dbutils.widgets.dropdown(
    "reinit_table", "False", ["True", "False"], "Reinitialize Tables"
)

dbutils.widgets.dropdown(
    "selected_table",
    "ALL",
    ["ALL"] + [f"template_{i}" for i in range(1, 9)],
    "Select Template Table to Create/ReInit",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Global variables

# COMMAND ----------

TARGET_ENV = dbutils.widgets.get("target_env")
REINIT_TABLE = dbutils.widgets.get("reinit_table")
SELECTED_TABLE = dbutils.widgets.get("selected_table")
if SELECTED_TABLE != "ALL":
    SELECTED_TABLE_KEY = f"template_table_{SELECTED_TABLE.split('_')[1]}"
else:
    SELECTED_TABLE_KEY = "ALL"

SCHEMA_NAME = f"{TARGET_ENV}_bronze.budget_app"

TABLE_NAMES = {
    f"template_table_{i}": f"{SCHEMA_NAME}.template_{i}" for i in range(1, 9)
}

CREATE_STATEMENT = (
    "CREATE OR REPLACE TABLE"
    if REINIT_TABLE == "True"
    else "CREATE TABLE IF NOT EXISTS"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tables definitions

# COMMAND ----------

# Table definitions
table_definitions = {
    "template_table_1": """
        division STRING,
        company_code STRING,
        account_number STRING,
        profit_center STRING,
        cost_center STRING,
        currency_key STRING,
        fiscal_year STRING,
        amount_01 DOUBLE,
        amount_02 DOUBLE,
        amount_03 DOUBLE,
        amount_04 DOUBLE,
        amount_05 DOUBLE,
        amount_06 DOUBLE,
        amount_07 DOUBLE,
        amount_08 DOUBLE,
        amount_09 DOUBLE,
        amount_10 DOUBLE,
        amount_11 DOUBLE,
        amount_12 DOUBLE,
        upload_timestamp TIMESTAMP,
        uploaded_by STRING,
        source_file_name STRING,
        id STRING,
        id_row STRING
    """,
    "template_table_2": """
        division STRING,
        company_code STRING,
        account_number STRING,
        profit_center STRING,
        cost_center STRING,
        currency_key STRING,
        fiscal_year STRING,
        amount_01 DOUBLE,
        amount_02 DOUBLE,
        amount_03 DOUBLE,
        amount_04 DOUBLE,
        amount_05 DOUBLE,
        amount_06 DOUBLE,
        amount_07 DOUBLE,
        amount_08 DOUBLE,
        amount_09 DOUBLE,
        amount_10 DOUBLE,
        amount_11 DOUBLE,
        amount_12 DOUBLE,
        upload_timestamp TIMESTAMP,
        uploaded_by STRING,
        source_file_name STRING,
        id_row STRING,
        id STRING
    """,
    "template_table_3": """
        division STRING,
        company_code STRING,
        profit_center STRING,
        material_number STRING,
        cost_center STRING,
        WBS_code STRING,
        quantity_unit STRING,
        fiscal_year STRING,
        quantity_01 DOUBLE,
        quantity_02 DOUBLE,
        quantity_03 DOUBLE,
        quantity_04 DOUBLE,
        quantity_05 DOUBLE,
        quantity_06 DOUBLE,
        quantity_07 DOUBLE,
        quantity_08 DOUBLE,
        quantity_09 DOUBLE,
        quantity_10 DOUBLE,
        quantity_11 DOUBLE,
        quantity_12 DOUBLE,
        upload_timestamp TIMESTAMP,
        uploaded_by STRING,
        source_file_name STRING,
        id_row STRING,
        id STRING
    """,
    "template_table_4": """
        division STRING,
        company_code STRING,
        trading_partner_id STRING,
        account_number STRING,
        profit_center STRING,
        material_number STRING,
        plant_assembly STRING,
        plant_production_purchase STRING,
        cost_center STRING,
        WBS_code STRING,
        currency_key STRING,
        fiscal_year STRING,
        amount_01 DOUBLE,
        amount_02 DOUBLE,
        amount_03 DOUBLE,
        amount_04 DOUBLE,
        amount_05 DOUBLE,
        amount_06 DOUBLE,
        amount_07 DOUBLE,
        amount_08 DOUBLE,
        amount_09 DOUBLE,
        amount_10 DOUBLE,
        amount_11 DOUBLE,
        amount_12 DOUBLE,
        upload_timestamp TIMESTAMP,
        uploaded_by STRING,
        source_file_name STRING,
        id_row STRING,
        id STRING
    """,
    "template_table_5": """
        division STRING,
        company_code STRING,
        trading_partner_id STRING,
        account_number STRING,
        profit_center STRING,
        cost_center STRING,
        currency_key STRING,
        fiscal_year STRING,
        amount_01 DOUBLE,
        amount_02 DOUBLE,
        amount_03 DOUBLE,
        amount_04 DOUBLE,
        amount_05 DOUBLE,
        amount_06 DOUBLE,
        amount_07 DOUBLE,
        amount_08 DOUBLE,
        amount_09 DOUBLE,
        amount_10 DOUBLE,
        amount_11 DOUBLE,
        amount_12 DOUBLE,
        upload_timestamp TIMESTAMP,
        uploaded_by STRING,
        source_file_name STRING,
        id_row STRING,
        id STRING
    """,
    "template_table_6": """
        division STRING,
        company_code STRING,
        final_site STRING,
        profit_center STRING,
        material_number STRING,
        unit STRING,
        fiscal_year STRING,
        quantity_01 DOUBLE,
        quantity_02 DOUBLE,
        quantity_03 DOUBLE,
        quantity_04 DOUBLE,
        quantity_05 DOUBLE,
        quantity_06 DOUBLE,
        quantity_07 DOUBLE,
        quantity_08 DOUBLE,
        quantity_09 DOUBLE,
        quantity_10 DOUBLE,
        quantity_11 DOUBLE,
        quantity_12 DOUBLE,
        upload_timestamp TIMESTAMP,
        uploaded_by STRING,
        source_file_name STRING,
        id_row STRING,
        id STRING
    """,
    "template_table_7": """
        division STRING,
        company_code STRING,
        cost_center STRING,
        unit STRING,
        fiscal_year STRING,
        quantity_01 DOUBLE,
        quantity_02 DOUBLE,
        quantity_03 DOUBLE,
        quantity_04 DOUBLE,
        quantity_05 DOUBLE,
        quantity_06 DOUBLE,
        quantity_07 DOUBLE,
        quantity_08 DOUBLE,
        quantity_09 DOUBLE,
        quantity_10 DOUBLE,
        quantity_11 DOUBLE,
        quantity_12 DOUBLE,
        upload_timestamp TIMESTAMP,
        uploaded_by STRING,
        source_file_name STRING,
        id_row STRING,
        id STRING
    """,
    "template_table_8": """
        fiscal_year STRING,
        allocation_key_type STRING,
        cost_center_from STRING,
        cost_center_to STRING,
        account_number_allocation STRING,
        allocation_base DOUBLE,
        account_allocation_base STRING,
        indexPNL_allocation_base STRING,
        upload_timestamp TIMESTAMP,
        uploaded_by STRING,
        source_file_name STRING,
        id_row STRING,
        id STRING
    """,
}


# COMMAND ----------

# MAGIC %md
# MAGIC ## Schema creation

# COMMAND ----------

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA_NAME}")
print(f"✅ Schéma créé ou déjà existant : {SCHEMA_NAME}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Table creation

# COMMAND ----------

# -- Table creation

if SELECTED_TABLE_KEY == "ALL":
    tables_to_process = table_definitions.keys()
else:
    tables_to_process = [SELECTED_TABLE_KEY]

for key in tables_to_process:
    full_table_name = TABLE_NAMES[key]
    columns = table_definitions[key]

    query = f"""
    {CREATE_STATEMENT} IDENTIFIER('{full_table_name}') (
        {columns}
    )
    USING DELTA;
    """

    # Exécution
    spark.sql(query)

    # Message de confirmation
    action = "reinitialized" if REINIT_TABLE == "True" else "created if not existing"
    print(f"✅ Table `{full_table_name}` {action}.")

# COMMAND ----------


# MAGIC %md
# MAGIC ## Comments on table

# COMMAND ----------

# Dictionary of tables comments
table_comments = {
    "template_table_1": """Amount Non SAP companies.
Company code for Non SAP companies: LBE1 (TAC), LAC1 (Avcorp TBD1), LAC2 (Avcorp TBD2), LAC3 (Avcorp Corporate), LSP1 (MADES), LUK1""",
    "template_table_2": "Amount per CC - SAP companies. Upload amount data per cost center for SAP companies",
    "template_table_3": "Workload.",
    "template_table_4": "Amount on direct PC - SAP companies",
    "template_table_5": "Intercompany flows. Warning: Must be balanced",
    "template_table_6": "Rates. Program rates",
    "template_table_7": "FTE / Headcount.",
    "template_table_8": "Allocation key. Only for M&T",
}

if SELECTED_TABLE_KEY == "ALL":
    tables_to_process = table_comments.keys()
else:
    tables_to_process = [SELECTED_TABLE_KEY]

failed_table_comments = []
for key in tables_to_process:
    full_table_name = TABLE_NAMES[key]
    comment = table_comments[key]

    stmt = f"""
    COMMENT ON TABLE IDENTIFIER('{full_table_name}') IS '{comment}';
    """

    print(stmt.strip())
    try:
        spark.sql(stmt).display()
        print(f"✅ Comment applied on table `{full_table_name}`.")
    except Exception as e:
        print(f"-- ❌ Échec sur la table `{full_table_name}` : {e}")
        failed_table_comments.append(full_table_name)

if failed_table_comments:
    print("\n⚠️ Tables failed, to retry manually :", failed_table_comments)
else:
    print("\n✅ All table comments applied successfully.")

# COMMAND ----------


# MAGIC %md
# MAGIC ## Comments on table columns

# COMMAND ----------

column_comments = {
    "template_table_1": {
        "id": "Unique auto-generated identifier",
        "division": "Division code",
        "company_code": "Company code (SAP or non-SAP)",
    },
    "template_table_2": {
        "id": "Unique auto-generated identifier",
        "division": "Division code",
        "company_code": "Company code (SAP or non-SAP)",
    },
    "template_table_3": {
        "id": "Unique auto-generated identifier",
        "division": "Division code",
        "company_code": "Company code (SAP or non-SAP)",
    },
    "template_table_4": {
        "id": "Unique auto-generated identifier",
        "division": "Division code",
        "company_code": "Company code (SAP or non-SAP)",
    },
    "template_table_5": {
        "id": "Unique auto-generated identifier",
        "division": "Division code",
        "company_code": "Company code (SAP or non-SAP)",
    },
    "template_table_6": {
        "id": "Unique auto-generated identifier",
        "division": "Division code",
        "company_code": "Company code (SAP or non-SAP)",
    },
    "template_table_7": {
        "id": "Unique auto-generated identifier",
        "division": "Division code",
        "company_code": "Company code (SAP or non-SAP)",
    },
    "template_table_8": {
        "id": "Unique auto-generated identifier",
    },
}

if SELECTED_TABLE_KEY == "ALL":
    tables_to_process = column_comments.keys()
else:
    tables_to_process = [SELECTED_TABLE_KEY]


failed_column_comments = []
for key in tables_to_process:
    full_table_name = TABLE_NAMES[key]
    for col, comment in column_comments[key].items():
        stmt = f"""
        ALTER TABLE IDENTIFIER('{full_table_name}') ALTER COLUMN {col} COMMENT '{comment}';
        """
        print(stmt.strip())
        try:
            spark.sql(stmt).display()
            print(f"✅ Comment applied on column `{full_table_name}.{col}`.")
        except Exception as e:
            print(f"-- ❌ Failed on {full_table_name}.{col} : {e}")
            failed_column_comments.append(stmt.strip())

if failed_column_comments:
    print("\n⚠️ Failed column comments, retry manually :")
    for stmt in failed_column_comments:
        print(stmt)
else:
    print("\n✅ All column comments applied successfully.")
