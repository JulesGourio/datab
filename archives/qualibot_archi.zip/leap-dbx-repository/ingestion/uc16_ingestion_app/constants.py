"""
This module contains constants definition for the budget (P&L) app
"""

from os import getenv

from leap_utils.platform import deployment_environments

workspace_id = getenv("DATABRICKS_WORKSPACE_ID")
if workspace_id is None:
    raise EnvironmentError("DATABRICKS_WORKSPACE_ID must be set")
PIPELINE_WRITE_ENV = deployment_environments.WorkspaceIds(int(workspace_id)).name

try:
    WAREHOUSE_PATH = deployment_environments.DefaultSqlWarehouse[
        PIPELINE_WRITE_ENV
    ].value
    WAREHOUSE_ID = WAREHOUSE_PATH.split("/")[-1]
except KeyError:
    raise KeyError(f"No SQL warehouse defined for environment {PIPELINE_WRITE_ENV}")

HARDCODED_TABLES = {
    1: {
        "name": f"{PIPELINE_WRITE_ENV}_bronze.budget_app.template_1",
        "description": "Amount Non SAP companies",
        "subdescription": "Company code for Non SAP companies: LBE1 (TAC), LAC1 (Avcorp TBD1), LAC2 (Avcorp TBD2), LAC3 (Avcorp Corporate), LSP1 (MADES), LUK1",
    },
    2: {
        "name": f"{PIPELINE_WRITE_ENV}_bronze.budget_app.template_2",
        "description": "Amount per CC - SAP companies",
        "subdescription": "Upload amount data per cost center for SAP companies",
    },
    3: {
        "name": f"{PIPELINE_WRITE_ENV}_bronze.budget_app.template_3",
        "description": "Workload",
        "subdescription": "",
    },
    4: {
        "name": f"{PIPELINE_WRITE_ENV}_bronze.budget_app.template_4",
        "description": "Amount on direct PC - SAP companies",
        "subdescription": "",
    },
    5: {
        "name": f"{PIPELINE_WRITE_ENV}_bronze.budget_app.template_5",
        "description": "Intercompany flows",
        "subdescription": "Warning: Must be balanced",
    },
    6: {
        "name": f"{PIPELINE_WRITE_ENV}_bronze.budget_app.template_6",
        "description": "Rates",
        "subdescription": "Program rates",
    },
    7: {
        "name": f"{PIPELINE_WRITE_ENV}_bronze.budget_app.template_7",
        "description": "FTE / Headcount",
        "subdescription": "",
    },
    8: {
        "name": f"{PIPELINE_WRITE_ENV}_bronze.budget_app.template_8",
        "description": "Allocation key",
        "subdescription": "Only for M&T",
    },
}
