# Coma ingestion App

This app enables business users to manually ingest .xls files for the budget.


## Deployment

### Prerequisites

A configured ``databricks`` CLI is required to deploy the app.

#### Install the CLI

If you do not have it, please follow the [installation instructions](https://docs.databricks.com/aws/en/dev-tools/cli/install).

#### Configure the CLI

Next, follow [the instructions to set up the connection to the Databricks workspace](https://docs.databricks.com/aws/en/dev-tools/cli/tutorial#configure-access-to-your-workspace)

**/!\\** Make sure you are connected to the adequate workspace (dev, uat, prd)

### Deploy the app source code from : ( ingestion/uc16_ingestion_app/ and leap_utils/ ) to : /Workspace/Shared/budget-ingestion-src/

To deploy the source code, run the following commands from the source folder of the REPO :

```commandline
databricks auth login --profile UAT   #  DEV or UAT or PROD
databricks sync leap_utils/ /Workspace/Shared/budget-ingestion-src/leap_utils/ --full --profile UAT
```

```commandline
databricks sync ingestion/uc16_ingestion_app/ /Workspace/Shared/budget-ingestion-src/ingestion/uc16_ingestion_app/ --full --profile UAT
```

```commandline
databricks sync ingestion/uc16_ingestion_app/ /Workspace/Shared/budget-ingestion-src/ --exclude *.py --exclude .streamlit --exclude *.json --full --profile UAT
```
(N.B. : The last command is a bit tricky : we want to put ``ingestion/uc16_ingestion_app/app.yml`` and
``ingestion/uc16_ingestion_app/requirements.txt`` at the root level of
``/Workspace/Shared/budget-ingestion-src/``. Yet, the command ``databricks sync`` does not allow to send files, only directories ...
_Luckily_, it offers the possibility to exclude file patterns, so that's what we are doing)

### Sigma Budget App Creation
```commandline for app creation - just one time for App creation
databricks apps create budget-ingestion --description "upload excel files for pnl budget" --profile UAT
```

### Sigma Budget App Deployment
```commandline for app deployment - command to deploy App after each code sync
databricks apps deploy budget-ingestion --source-code-path /Workspace/Shared/budget-ingestion-src --profile UAT
```

### Sigma Budget App Permissions
```commandline for app permissions - command to set permissions after each code sync
databricks apps update-permissions budget-ingestion --json @ingestion/uc16_ingestion_app/permissions.json --profile UAT
```

### Databricks notebook to set up App permissions
``` go to Databricks workspaces DEV/UAT/PROD and run the following notebook with a serverless cluster, if needed update the JSON template inside the notebook to add more permissions
platform/app_grants/Grant_Permissions_App_Budget.py
```


### Run the App code locally :
```commandline
python -m venv venv_test
cd venv_test/Scripts
./Activate.ps1
cd ../..
pip install -r requirements.txt
$env:DATABRICKS_HOST="https://dbc-c623749d-731b.cloud.databricks.com/"  # DEV
$env:DATABRICKS_WORKSPACE_ID="2865348338307293"   # DEV
$env:DATABRICKS_TOKEN="dapixxx" # Put your token here
streamlit run main.py
```