import streamlit as st
import pandas as pd
import os
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent.parent))
from ingestion.uc16_ingestion_app import constants, library

from databricks import sql
from databricks.sql.client import Connection
from databricks.sdk.core import Config

try:
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.sql import StatementExecutionAPI

    DATABRICKS_SDK_AVAILABLE = True
except ImportError:
    DATABRICKS_SDK_AVAILABLE = False


from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

log = setup_applevel_logger(
    log_level=LOGGER_MAPPING[os.getenv("LOG_LEVEL", "info").lower()]
)

cfg = Config()


def get_databricks_client():
    """Initialize Databricks workspace client"""
    try:
        # In Databricks Apps, authentication is handled automatically
        w = WorkspaceClient()
        log.info("Initialized workspace client.")
        return w
    except Exception as e:
        log.error(str(e), exc_info=True)
        st.error(f"Failed to initialize Databricks client: {str(e)}")
        return None


def get_connection() -> Connection:
    """
    Get a connection to a remote Databricks SQL warehouse.
    Uses the global variable ``WAREHOUSE_PATH``.

    :return: Connection to a SQL warehouse
    :rtype: Connection
    """
    connection = sql.connect(
        server_hostname=cfg.host,
        http_path=constants.WAREHOUSE_PATH,
        credentials_provider=lambda: cfg.authenticate,
    )
    log.info("Initialized SQL warehouse connection.")
    return connection


def validate_email(email: str, experimental_user_email: str):
    """Validate Latecoere email format and return username"""
    if email and email.endswith("@latecoere.aero"):
        return True, library.get_user_name_from_email(email), email
    elif experimental_user_email and experimental_user_email.endswith(
        "@latecoere.aero"
    ):
        return (
            True,
            library.get_user_name_from_email(experimental_user_email),
            experimental_user_email,
        )
    return False, None, None


# Initialize Databricks client
def main():
    """Main Streamlit application with improved schema validation display"""
    st.set_page_config(
        page_title="Budget app - Upload your Excel data",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    # Header with reload button
    header_col1, header_col2 = st.columns([4, 1])

    with header_col1:
        st.title("📊 Budget app - Upload your Excel data")
        st.markdown(
            "Upload Excel files and select worksheets to validate schema before uploading data"
        )

    with header_col2:
        st.markdown("---")
        if st.button("🔄 Reload app", type="secondary"):
            st.cache_data.clear()
            st.cache_resource.clear()
            st.session_state.clear()
            st.success("✅ Cache cleared! App will reload...")
            st.rerun()
    st.divider()

    # Check if SDK is available
    if not DATABRICKS_SDK_AVAILABLE:
        st.error(
            "❌ Databricks SDK is not available. Please install it using: `pip install databricks-sdk`"
        )
        st.stop()

    # Display Databricks Environment in sidebar
    dbx_logo = library.get_base64_image(
        "ingestion/uc16_ingestion_app/assets/databricks.png"
    )
    st.sidebar.markdown(
        f"""
        <h3 style="display:flex; align-items:center; gap:10px; margin-top:0;">
            <img src="data:image/png;base64,{dbx_logo}" width="24">
            Environment
        </h3>
        """,
        unsafe_allow_html=True,
    )
    st.sidebar.info(
        f"**Current environment:** `{constants.PIPELINE_WRITE_ENV.upper()}`"
    )

    # Email validation in sidebar
    st.sidebar.subheader("🔐 Authentication")

    # Initialize Databricks client
    client = get_databricks_client()
    if not client:
        return

    # Detect user via SSO
    email_valid, username = False, None
    user_email = None

    try:
        me = client.current_user.me()
        user_email = me.user_name
        # Récupérer les en-têtes HTTP
        headers = st.context.headers
        experimental_user_email = headers.get("X-Forwarded-Email", "Unknown User")
        email_valid, username, user_email = validate_email(
            user_email, experimental_user_email
        )

        if email_valid:
            st.sidebar.info(f"Detected email from SSO: {user_email}")
            st.sidebar.success("✅ Email validated")
            st.sidebar.info(f"👤 Username: {username}")
            log.info(f"👤 SSO Username: {username}")
        else:
            st.sidebar.warning(
                "⚠️ Email detected from SSO is not a Latecoere email. Please enter it manually."
            )
            user_email = None
    except Exception as e:
        st.sidebar.warning(
            f"⚠️ Could not detect user via SSO: {str(e)}. Please enter your email manually."
        )
        user_email = None

    # Manual email input
    if not email_valid:
        user_email = st.sidebar.text_input(
            "Enter your Latecoere email address",
            placeholder="user@latecoere.aero",
            help="Your Latecoere email address",
        )
        email_valid, username, user_email = validate_email(user_email, None)

        if email_valid:
            st.sidebar.success("✅ Email validated manually")
            st.sidebar.info(f"👤 Username: {username}")
            log.info(f"👤 Entered Username: {username}")
        else:
            st.sidebar.error(
                "❌ Please enter a valid Latecoere email address ending with @latecoere.aero"
            )

    if not email_valid:
        st.warning("Please provide a valid Latecoere email to proceed.")
        st.stop()

    metadata_columns = [
        "upload_timestamp",
        "uploaded_by",
        "source_file_name",
        "id",
        "id_row",
    ]

    # Create 8 upload sections
    for i in range(1, 9):
        table_config = constants.HARDCODED_TABLES[i]
        table_name = table_config["name"]
        table_description = table_config["description"]
        table_subdescription = table_config.get("subdescription", "")

        st.header(f"Upload Section {i}: {table_description}")

        with st.expander(f"📤 Excel Upload {i} - {table_description}", expanded=False):
            # --- 🔑 Initialzation of variables ---
            is_match = False
            differences = {}
            excel_df = None
            excel_df_converted = None
            conversion_log = []
            schema_valid = False
            division_check_passed = True
            division_error = None
            # ------------------------------------------------------------

            # Display table information
            col1, col2 = st.columns([2, 1])
            with col1:
                # st.info(f"🎯 **Target Table:** `{table_name}`")
                st.write(f"**Description:** {table_description}")
                if table_subdescription:
                    st.write(f"{table_subdescription}")

            with col2:
                # File upload for this section
                uploaded_file = st.file_uploader(
                    f"Choose Excel file",
                    type=["xlsx", "xls"],
                    key=f"file_upload_{i}",
                    help=f"Select the Excel file for {table_description}",
                )

            if uploaded_file is not None:
                # st.success(f"✅ File uploaded: {uploaded_file.name}")

                # Read Excel file to get sheet names
                try:
                    sheet_names, _ = library.read_excel_file(uploaded_file)

                    if not sheet_names:
                        st.error("❌ Could not read Excel file or no sheets found")
                        continue

                    # Sheet selection
                    st.subheader("📋 Select Worksheet")

                    # Display available sheets
                    col1, col2 = st.columns([1, 2])

                    with col1:
                        selected_sheet = st.selectbox(
                            f"Available worksheets ({len(sheet_names)}):",
                            sheet_names,
                            key=f"sheet_select_{i}",
                            help="Choose which worksheet to process",
                        )

                    # Read the selected sheet
                    if selected_sheet:
                        _, excel_df = library.read_excel_file(
                            uploaded_file, selected_sheet
                        )
                        if excel_df is None:
                            st.error(f"❌ Could not read worksheet '{selected_sheet}'")
                            log.error(f"❌ Could not read worksheet '{selected_sheet}'")
                            continue

                        # Detect and display decimal format issues
                        decimal_issues = library.detect_decimal_format_issues(excel_df)

                        # Show basic Excel info first
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("📊 Total Rows", f"{len(excel_df):,}")
                        with col2:
                            st.metric("🔢 Total Columns", len(excel_df.columns))
                        with col3:
                            st.metric(
                                "💾 File Size", f"{uploaded_file.size / 1024:.1f} KB"
                            )

                        # Excel preview with checkbox
                        show_excel_preview = st.checkbox(
                            "📋 Show Excel preview", key=f"excel_preview_{i}"
                        )

                        if show_excel_preview:
                            st.subheader(f"📋 Excel Preview - Sheet: {selected_sheet}")
                            st.dataframe(excel_df.head(10))

                            # Show Excel column types
                            st.write("🔍 **Excel Column Types:**")
                            col_info = []
                            for col in excel_df.columns:
                                sql_type = library.pandas_to_sql_type(
                                    excel_df[col].dtype
                                )
                                sample_value = (
                                    str(excel_df[col].iloc[0])[:50]
                                    if len(excel_df) > 0
                                    else "N/A"
                                )
                                col_info.append(
                                    {
                                        "Column": col,
                                        "Data Type": sql_type,
                                        "Sample": sample_value,
                                        "Non-null Count": excel_df[col].notna().sum(),
                                    }
                                )
                            st.dataframe(
                                pd.DataFrame(col_info), use_container_width=True
                            )

                except Exception as e:
                    st.error(f"❌ Error reading Excel file: {str(e)}")
                    log.error(f"❌ Error reading Excel file: {str(e)}")
                    continue

                # Continue with schema validation if we have data
                if excel_df is not None:
                    # Get target schema first
                    with st.spinner(f"Getting target table schema..."):
                        target_schema = library.get_table_schema_via_sql(
                            client, table_name, metadata_columns
                        )

                    if target_schema is None:
                        st.error(
                            f"❌ Could not retrieve target table schema. Please check the table name and your permissions."
                        )
                        log.error(
                            f"❌ Could not retrieve target table schema. Please check the table name and your permissions."
                        )
                        continue

                    # Division uniqueness check for templates 2, 3, 4
                    division_check_passed = True
                    division_error = None
                    if i in [2, 3, 4]:
                        division_check_passed, division_error = (
                            library.check_division_uniqueness(excel_df, i)
                        )

                    # Compare schemas
                    is_match, differences = library.compare_schemas_pandas_flexible(
                        excel_df, target_schema
                    )
                    excel_df_converted = excel_df.copy()
                    conversion_log = []

                    if differences.get("auto_convertible"):
                        # Apply conversions automatically
                        excel_df_converted, conversion_log = (
                            library.convert_columns_for_databricks(
                                excel_df, target_schema, template_number=i
                            )
                        )

                        # Re-validate after conversion
                        is_match_after_conversion, differences_after = (
                            library.compare_schemas_pandas(
                                excel_df_converted, target_schema
                            )
                        )

                        # Use result after conversion
                        is_match = is_match_after_conversion
                        differences = differences_after

                    # Overall validation status (schema + division for templates 2-4)
                    schema_valid = is_match and division_check_passed

                    # Display main validation status
                    if schema_valid:
                        st.success("✅ **Schema validation passed - Ready to upload!**")

                        # Checkbox to see validation details
                        show_validation_details = st.checkbox(
                            "🔍 Show validation details", key=f"validation_details_{i}"
                        )

                        if show_validation_details:
                            st.info("**📋 Schema Validation Details:**")
                            st.write("• All columns match the target schema")
                            st.write("• All data types are compatible")

                            if conversion_log:
                                st.write("**🔄 Applied Conversions:**")
                                for log_entry in conversion_log:
                                    st.write(f"  • {log_entry}")

                            # Division check for templates 2-4
                            if i in [2, 3, 4]:
                                st.write("**🔍 Division Uniqueness Check:**")
                                st.write("• Division column uniqueness validated")

                            st.write("• Schema validation completed successfully")
                            st.write(
                                f"• Validation timestamp: {library.get_paris_timestamp()}"
                            )

                            # Target schema details
                            if st.button(
                                "🎯 View target table schema",
                                key=f"target_schema_detailed_{i}",
                            ):
                                st.write(
                                    f"🎯 **Target Table Schema** (excluding metadata columns):"
                                )
                                schema_df = pd.DataFrame(
                                    [
                                        {"Column": col_name, "Type": col_type}
                                        for col_name, col_type in target_schema.items()
                                    ]
                                )
                                st.dataframe(schema_df, use_container_width=True)

                    else:
                        # Validation failed - display errors directly
                        st.error("❌ **Schema validation failed!**")

                        # Display schema errors
                        if not is_match:
                            st.error("**📋 Schema Validation Errors:**")

                            if differences["missing_in_excel"]:
                                st.error("**🔴 Missing columns in Excel:**")
                                for col in differences["missing_in_excel"]:
                                    st.write(f"  • {col}")

                            if differences["extra_in_excel"]:
                                st.warning("**🟡 Extra columns in Excel:**")
                                for col in differences["extra_in_excel"]:
                                    st.write(f"  • {col}")

                            if differences["type_mismatches"]:
                                st.error("**🔴 Data type mismatches:**")
                                for mismatch in differences["type_mismatches"]:
                                    st.write(f"  • {mismatch}")

                            if differences.get("auto_convertible"):
                                st.info("**🔄 Automatic conversions available:**")
                                for conversion in differences["auto_convertible"]:
                                    st.write(f"  • {conversion}")

                        # Display division errors
                        if not division_check_passed and division_error:
                            st.error("**🔍 Division Uniqueness Check:**")
                            st.write(f"  • {division_error}")

                        # Target schema for debug
                        if st.button(
                            "🎯 View target table schema",
                            key=f"target_schema_debug_{i}",
                        ):
                            st.write(
                                f"🎯 **Target Table Schema** (excluding metadata columns):"
                            )
                            schema_df = pd.DataFrame(
                                [
                                    {"Column": col_name, "Type": col_type}
                                    for col_name, col_type in target_schema.items()
                                ]
                            )
                            st.dataframe(schema_df, use_container_width=True)

                    # Upload section - Direct upload interface
                    if schema_valid:
                        st.subheader(f"🚀 Upload Data")
                        st.info(
                            f"📤 Ready to upload **{len(excel_df):,} rows** from sheet **'{selected_sheet}'**"
                        )

                        # Upload button
                        if st.button(
                            f"🚀 Upload to {table_description}",
                            key=f"upload_btn_{i}",
                            type="primary",
                        ):
                            with st.spinner(
                                f"Uploading {len(excel_df):,} rows from '{selected_sheet}' to {table_description}..."
                            ):
                                success, message = library.upload_dataframe_to_table(
                                    client,
                                    excel_df_converted,
                                    table_name,
                                    f"{uploaded_file.name}#{selected_sheet}",
                                    user_email,
                                    i,
                                )

                            if success:
                                st.success(f"🎉 {message}")
                                st.snow()

                                # Show summary
                                st.subheader(f"📋 Upload Summary")
                                summary_cols = st.columns(2)

                                with summary_cols[0]:
                                    st.metric(
                                        "✅ Rows Uploaded",
                                        f"{len(excel_df_converted):,}",
                                    )
                                    st.metric(
                                        "📅 Upload Time", library.get_paris_timestamp()
                                    )

                                with summary_cols[1]:
                                    st.metric(
                                        "👤 Uploaded By", f"{username} ({user_email})"
                                    )
                                    st.metric(
                                        "📄 Source",
                                        f"{uploaded_file.name} - {selected_sheet}",
                                    )

                            else:
                                st.error(f"❌ Upload failed: {message}")
                    else:
                        # Validation failed - no upload section
                        st.subheader("❌ Cannot Upload")
                        st.warning(
                            "Please fix the validation issues above before uploading."
                        )

            # Add separator between sections (except for the last one)
            if i < 8:
                st.divider()


if __name__ == "__main__":
    main()
