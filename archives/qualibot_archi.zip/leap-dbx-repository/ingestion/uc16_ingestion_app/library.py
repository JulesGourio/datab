"""
Tools & functions for uc16 budget app.
"""

import sys
import pandas as pd
import streamlit as st
import datetime
import pytz
import base64
from typing import Dict, List, Tuple, Optional
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent.parent))
from ingestion.uc16_ingestion_app import constants

from leap_utils.common import logger

log = logger.get_logger(module_name=__name__)


def get_base64_image(image_path: str) -> str:
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode()


def get_user_name_from_email(email: str) -> str:
    """
    Extract username from email address (part before @)

    Args:
        email: Email address

    Returns:
        str: Username part before @
    """
    if "@" in email:
        return email.split("@")[0]
    return email


def check_division_uniqueness(
    df: pd.DataFrame, template_number: int
) -> Tuple[bool, Optional[str]]:
    """
    Check division column uniqueness for templates 2, 3 and 4.

    Args:
        df: DataFrame to check
        template_number: Template number

    Returns:
        Tuple[bool, Optional[str]]: (is_unique, error_message)
    """
    # Only check for templates 2, 3 and 4
    if template_number not in [2, 3, 4]:
        return True, None

    # Check if division column exists
    if "division" not in df.columns:
        return False, "❌ Division column is missing from the Excel file"

    # Check uniqueness
    division_values = df["division"].dropna()
    unique_values = division_values.unique()

    if len(unique_values) > 1:
        return (
            False,
            f"❌ More than 1 unique value in the column 'division': {', '.join(map(str, unique_values))}",
        )

    return True, None


def get_paris_timestamp() -> str:
    """
    Return current timestamp in Paris timezone

    Returns:
        str: Formatted timestamp in Paris timezone (compatible with Databricks)
    """
    paris_tz = pytz.timezone("Europe/Paris")
    paris_time = datetime.datetime.now(paris_tz)
    return paris_time.strftime("%Y-%m-%d %H:%M:%S")


def get_table_schema_via_sql(
    client, table_name: str, metadata_columns: List[str] = None
) -> Optional[Dict]:
    """
    Get table schema using SQL queries via Databricks SDK

    Args:
        client: Databricks WorkspaceClient
        table_name: Name of the target table (catalog.schema.table)
        metadata_columns: List of metadata columns to exclude

    Returns:
        Dict with column information or None if error
    """
    if metadata_columns is None:
        metadata_columns = ["upload_timestamp", "uploaded_by", "source_file_name"]

    try:
        # Query to get table schema
        query = f"DESCRIBE TABLE {table_name}"

        # Execute query using SQL execution API
        response = client.statement_execution.execute_statement(
            statement=query, warehouse_id=constants.WAREHOUSE_ID
        )

        # Parse results
        if response.result and response.result.data_array:
            columns = {}
            for row in response.result.data_array:
                col_name = row[0]
                col_type = row[1]

                # Skip metadata columns and comment/partition info
                if col_name not in metadata_columns and not col_name.startswith("#"):
                    columns[col_name] = col_type

            return columns

        return None

    except Exception as e:
        st.error(f"Error getting table schema: {str(e)}")
        return None


def display_schema_validation_results(
    is_match,
    differences,
    conversion_log=None,
    division_check_passed=True,
    division_error=None,
    template_number=None,
):
    """
    Display schema validation results with improved design for success

    Args:
        is_match: Boolean indicating if schema matches
        differences: Dict with detected differences
        conversion_log: List of applied conversions (optional)
        division_check_passed: Boolean indicating if division check passed
        division_error: Division check error message
        template_number: Template number
    """

    # Overall validation status (schema + division for templates 2-4)
    overall_validation_passed = is_match and division_check_passed

    if overall_validation_passed:
        # Complete validation passed - simplified display
        st.success("✅ Schema validation passed!")

        # Option to see details with checkbox
        show_details = st.checkbox(
            "🔍 Show validation details", key=f"details_checkbox_{template_number}"
        )

        if show_details:
            st.info("**📋 Schema Validation Details:**")
            st.write("• All columns match the target schema")
            st.write("• All data types are compatible")

            if conversion_log:
                st.write("**🔄 Applied Conversions:**")
                for log_entry in conversion_log:
                    st.write(f"  • {log_entry}")

            # Division check for templates 2-4
            if template_number in [2, 3, 4]:
                st.write("**🔍 Division Uniqueness Check:**")
                st.write("• Division column uniqueness validated")

            st.write("• Schema validation completed successfully")
            st.write(f"• Validation timestamp: {get_paris_timestamp()}")

    else:
        # Validation failed - display errors
        st.error("❌ Validation failed!")

        # Display schema errors
        if not is_match:
            st.write("**📋 Schema Validation Errors:**")

            if differences["missing_in_excel"]:
                st.write("**🔴 Missing columns in Excel:**")
                for col in differences["missing_in_excel"]:
                    st.write(f"  • {col}")

            if differences["extra_in_excel"]:
                st.write("**🟡 Extra columns in Excel:**")
                for col in differences["extra_in_excel"]:
                    st.write(f"  • {col}")

            if differences["type_mismatches"]:
                st.write("**🔴 Data type mismatches:**")
                for mismatch in differences["type_mismatches"]:
                    st.write(f"  • {mismatch}")

            if differences.get("auto_convertible"):
                st.info("**🔄 Automatic conversions available:**")
                for conversion in differences["auto_convertible"]:
                    st.write(f"  • {conversion}")

        # Display division errors
        if not division_check_passed and division_error:
            st.write("**🔍 Division Uniqueness Check:**")
            st.write(f"  • {division_error}")


def read_excel_file(uploaded_file, sheet_name=None):
    """
    Read Excel file and return information about sheets and data
    Enhanced with decimal handling and proper empty column management

    Args:
        uploaded_file: File uploaded by Streamlit
        sheet_name: Sheet name to read (optional)

    Returns:
        tuple: (sheet_names, dataframe) or (sheet_names, None) if no sheet selected
    """
    try:
        # Read Excel file to get sheet list
        excel_file = pd.ExcelFile(uploaded_file)
        sheet_names = excel_file.sheet_names

        if sheet_name is None:
            return sheet_names, None

        # Read specific sheet
        # df = pd.read_excel(uploaded_file, sheet_name=sheet_name)
        df = pd.read_excel(uploaded_file, sheet_name=sheet_name, dtype=str)

        # Clean data - Remove only completely empty ROWS
        df = df.dropna(how="all")  # Remove empty rows only

        # Do NOT remove empty columns automatically - they might be needed for schema matching
        # Instead, we'll handle empty columns during schema validation and conversion

        # Clean column names (remove spaces, etc.)
        df.columns = df.columns.str.strip()

        # Handle decimal separator issues (virgule vs point)
        df = normalize_decimal_columns(df)

        return sheet_names, df

    except Exception as e:
        st.error(f"Error reading Excel file: {str(e)}")
        return [], None


def restore_missing_columns(
    df: pd.DataFrame, target_schema: Dict
) -> Tuple[pd.DataFrame, List[str]]:
    """
    Restore missing columns that should exist based on target schema

    Args:
        df: DataFrame that might be missing columns
        target_schema: Target table schema {column_name: sql_type}

    Returns:
        Tuple[DataFrame with restored columns, List of restoration logs]
    """
    df_restored = df.copy()
    restoration_log = []

    # Find missing columns that exist in target schema
    existing_columns = set(df_restored.columns)
    target_columns = set(target_schema.keys())
    missing_columns = target_columns - existing_columns

    # Add missing columns with appropriate default values
    for col in missing_columns:
        target_type = target_schema[col].lower()

        if target_type in ["int", "bigint", "integer"]:
            df_restored[col] = None  # Will be converted to 0 during type conversion
            restoration_log.append(
                f"🔄 Restored missing column '{col}' as integer (NULL values)"
            )
        elif target_type in ["double", "float", "decimal"]:
            df_restored[col] = None  # Will be converted to 0.0 during type conversion
            restoration_log.append(
                f"🔄 Restored missing column '{col}' as float (NULL values)"
            )
        else:  # string, varchar, etc.
            df_restored[col] = None
            restoration_log.append(
                f"🔄 Restored missing column '{col}' as string (NULL values)"
            )

    return df_restored, restoration_log


def handle_empty_columns(
    df: pd.DataFrame, target_schema: Dict
) -> Tuple[pd.DataFrame, List[str]]:
    """
    Handle completely empty columns in the DataFrame

    Args:
        df: DataFrame to process
        target_schema: Target table schema {column_name: sql_type}

    Returns:
        Tuple[DataFrame with handled empty columns, List of handling logs]
    """
    df_handled = df.copy()
    handling_log = []

    for col in df_handled.columns:
        if col in target_schema:
            # Check if column is completely empty (all NaN/None)
            if df_handled[col].isna().all():
                target_type = target_schema[col].lower()

                # Fill with appropriate default values based on target type
                if target_type in ["int", "bigint", "integer"]:
                    df_handled[col] = 0
                    handling_log.append(
                        f"🔄 Filled empty column '{col}' with 0 (integer)"
                    )
                elif target_type in ["double", "float", "decimal"]:
                    df_handled[col] = 0.0
                    handling_log.append(
                        f"🔄 Filled empty column '{col}' with 0.0 (float)"
                    )
                else:  # string, varchar, etc.
                    df_handled[col] = None  # Keep as NULL for strings
                    handling_log.append(
                        f"🔄 Kept empty column '{col}' as NULL (string)"
                    )

    return df_handled, handling_log


def normalize_decimal_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalize decimal columns to handle various number formats:
    - Comma as decimal separator: 1234,56
    - Dot as decimal separator: 1234.56
    - Comma as thousand separator + dot as decimal: 1,234.56
    - Space as thousand separator + comma as decimal: 1 234,56
    - Mixed formats in the same column

    Args:
        df: DataFrame to normalize

    Returns:
        DataFrame with normalized decimal values
    """
    df_normalized = df.copy()
    alphanumeric_columns = [
        "company_code",
        "trading_partner_id",
        "account_number",
        "profit_center",
        "material_number",
        "plant_assembly",
        "plant_production_purchase",
        "WBS_code",
        "cost_center",
        "cost_center_from",
        "cost_center_to",
        "account_number_allocation",
        "account_allocation_base",
        "indexPNL_allocation_base",
        "fiscal_year",
    ]

    for col in [c for c in df_normalized.columns if c not in alphanumeric_columns]:
        # Check if column contains object/string data that might be numbers
        if df_normalized[col].dtype == "object":
            # Get sample values for pattern detection
            sample_values = df_normalized[col].dropna().astype(str).head(20)

            if len(sample_values) == 0:
                continue

            # Define patterns for different number formats
            patterns = {
                "comma_thousand_dot_decimal": r"^\s*-?\d{1,3}(?:,\d{3})*\.\d+\s*$",  # -1,234.56 or 1,234.56
                "space_thousand_comma_decimal": r"^\s*-?\d{1,3}(?:\s\d{3})*,\d+\s*$",  # -1 234,56 or 1 234,56
                "simple_comma_decimal": r"^\s*-?\d+,\d+\s*$",  # -1234,56 (no thousand separator)
                "simple_dot_decimal": r"^\s*-?\d+\.\d+\s*$",  # -1234.56 (no thousand separator)
                "integer_only": r"^\s*-?\d+\s*$",  # Just integers
            }

            # Count matches for each pattern
            pattern_counts = {}
            for pattern_name, pattern in patterns.items():
                count = sample_values.str.match(pattern, na=False).sum()
                if count > 0:
                    pattern_counts[pattern_name] = count

            # Determine the predominant format
            if not pattern_counts:
                continue  # No numeric patterns detected

            dominant_pattern = max(pattern_counts, key=pattern_counts.get)

            try:
                if dominant_pattern == "comma_thousand_dot_decimal":
                    # Format: -1,234.56 (comma as thousand, dot as decimal)
                    df_normalized[col] = df_normalized[col].astype(str).str.strip()
                    df_normalized[col] = df_normalized[col].str.replace(
                        ",", "", regex=False
                    )  # Remove thousand separators
                    df_normalized[col] = pd.to_numeric(
                        df_normalized[col], errors="coerce"
                    )
                    # st.info(
                    #     f"🔄 Column '{col}': Converted comma-thousand + dot-decimal format (e.g., -1,234.56)"
                    # )

                elif dominant_pattern == "space_thousand_comma_decimal":
                    # Format: -1 234,56 (space as thousand, comma as decimal)
                    df_normalized[col] = df_normalized[col].astype(str).str.strip()
                    df_normalized[col] = df_normalized[col].str.replace(
                        r"\s+", "", regex=True
                    )  # Remove spaces
                    df_normalized[col] = df_normalized[col].str.replace(
                        ",", ".", regex=False
                    )  # Replace comma with dot
                    df_normalized[col] = pd.to_numeric(
                        df_normalized[col], errors="coerce"
                    )
                    # st.info(
                    #     f"🔄 Column '{col}': Converted space-thousand + comma-decimal format (e.g., -1 234,56)"
                    # )

                elif dominant_pattern == "simple_comma_decimal":
                    # Format: -1234,56 (comma as decimal, no thousand separator)
                    df_normalized[col] = df_normalized[col].astype(str).str.strip()
                    df_normalized[col] = df_normalized[col].str.replace(
                        ",", ".", regex=False
                    )  # Replace comma with dot
                    df_normalized[col] = pd.to_numeric(
                        df_normalized[col], errors="coerce"
                    )
                    # st.info(
                    #     f"🔄 Column '{col}': Converted comma-decimal format (e.g., -1234,56)"
                    # )

                elif dominant_pattern == "simple_dot_decimal":
                    # Format: -1234.56 (already correct, but might be stored as string)
                    df_normalized[col] = pd.to_numeric(
                        df_normalized[col], errors="coerce"
                    )
                    # st.info(
                    #     f"🔄 Column '{col}': Converted string numbers to numeric (e.g., -1234.56)"
                    # )

                elif dominant_pattern == "integer_only":
                    # Just integers, convert to numeric
                    df_normalized[col] = pd.to_numeric(
                        df_normalized[col], errors="coerce"
                    )
                    # st.info(f"🔄 Column '{col}': Converted string integers to numeric")

            except Exception as e:
                st.warning(
                    f"⚠️ Could not convert numeric format for column '{col}': {str(e)}"
                )

    return df_normalized


def detect_decimal_format_issues(df: pd.DataFrame) -> Dict[str, str]:
    """
    Detect and report various number format patterns in DataFrame columns

    Args:
        df: DataFrame to analyze

    Returns:
        Dict with column names and detected format details
    """
    issues = {}

    for col in df.columns:
        if df[col].dtype == "object":
            sample_values = df[col].dropna().astype(str).head(10)

            if len(sample_values) == 0:
                continue

            # Check for various patterns
            patterns_found = []

            # Comma thousand + dot decimal (e.g., -1,234.56)
            if sample_values.str.match(
                r"^\s*-?\d{1,3}(?:,\d{3})*\.\d+\s*$", na=False
            ).any():
                patterns_found.append("comma-thousand + dot-decimal (e.g., -1,234.56)")

            # Space thousand + comma decimal (e.g., -1 234,56)
            if sample_values.str.match(
                r"^\s*-?\d{1,3}(?:\s\d{3})*,\d+\s*$", na=False
            ).any():
                patterns_found.append(
                    "space-thousand + comma-decimal (e.g., -1 234,56)"
                )

            # Simple comma decimal (e.g., -1234,56)
            if sample_values.str.match(r"^\s*-?\d+,\d+\s*$", na=False).any():
                patterns_found.append("comma-decimal (e.g., -1234,56)")

            # Simple dot decimal (e.g., -1234.56)
            if sample_values.str.match(r"^\s*-?\d+\.\d+\s*$", na=False).any():
                patterns_found.append("dot-decimal (e.g., -1234.56)")

            # Integer only
            if sample_values.str.match(r"^\s*-?\d+\s*$", na=False).any():
                patterns_found.append("integer format")

            if patterns_found:
                issues[col] = "; ".join(patterns_found)
                # Show sample values for clarity
                sample_display = sample_values.head(3).tolist()
                issues[col] += f" | Samples: {', '.join(sample_display)}"

    return issues


def convert_columns_for_databricks(
    df: pd.DataFrame, target_schema: Dict, template_number: int = None
) -> Tuple[pd.DataFrame, List[str]]:
    """
    Conversion robuste :
    - Colonnes alphanumériques toujours en string (même si Excel les a lues en nombres)
    - Noms de colonnes/schema normalisés (lower/strip) pour éviter les ratés
    - Journalisation claire
    """
    df_converted = df.copy()
    conversion_log: List[str] = []

    # Colonnes pouvant contenir des codes mixtes (alphanumériques)
    alphanumeric_columns = [
        "company_code",
        "trading_partner_id",
        "account_number",
        "profit_center",
        "material_number",
        "plant_assembly",
        "plant_production_purchase",
        "WBS_code",
        "cost_center",
        "cost_center_from",
        "cost_center_to",
        "account_number_allocation",
        "account_allocation_base",
        "indexPNL_allocation_base",
        "fiscal_year",
    ]
    alpha_set = {c.strip().lower() for c in alphanumeric_columns}

    # --- Normalise la vue du schéma pour éviter les soucis de casse/espaces
    schema_norm = {
        str(k).strip().lower(): str(v).strip().lower() for k, v in target_schema.items()
    }

    df_converted["profit_center"] = (
        df_converted["profit_center"].astype(str).str.replace("\.0$", "", regex=True)
    )

    # Helpers
    def safe_string_conversion(x):
        if pd.isna(x):
            return None

        # Numérique → string propre (retire .0 si entier)
        if isinstance(x, (int, float)):
            # Evite 1.0 → '1.0': on cast intelligemment
            try:
                if float(x).is_integer():
                    return str(int(x))
                # sinon, garde la représentation canonique (évite '1.0' pour des non-entiers)
                return str(x)
            except Exception:
                return str(x)

        # Déjà en str ou autre → string nettoyée
        x_str = str(x).strip()
        if x_str.lower() in ("nan", "none", ""):
            return None
        # Cas "100.0" encodé en str
        if x_str.endswith(".0") and x_str[:-2].replace("-", "").isdigit():
            return x_str[:-2]
        return x_str

    # --- Restaure/traite colonnes manquantes & vides (tes fonctions existantes)
    if "restore_missing_columns" in globals():
        df_converted, restoration_log = restore_missing_columns(
            df_converted, target_schema
        )
        conversion_log.extend(restoration_log)
    if "handle_empty_columns" in globals():
        df_converted, handling_log = handle_empty_columns(df_converted, target_schema)
        conversion_log.extend(handling_log)

    # --- Boucle colonnes
    for col in df_converted.columns:
        col_key = str(col).strip().lower()
        current_dtype = str(df_converted[col].dtype).lower()

        if col_key not in schema_norm:
            conversion_log.append(
                f"ℹ️ Column '{col}': absente du target_schema (aucune conversion guidée)."
            )
            # Même si pas dans le schema, on protège les colonnes alphanum.
            if col_key in alpha_set:
                before_sample = df_converted[col].head(3).tolist()
                df_converted[col] = (
                    df_converted[col].map(safe_string_conversion).astype("string")
                )
                after_sample = df_converted[col].head(3).tolist()
                conversion_log.append(
                    f"✅ Column '{col}': forcée en string (alphanum) hors schéma. Exemples avant→après: {before_sample} → {after_sample}"
                )
            continue

        target_type = schema_norm[col_key]

        # --- 1) Colonnes alphanumériques : on force TOUJOURS en string
        if col_key in alpha_set:
            if target_type not in ["string", "varchar"]:
                conversion_log.append(
                    f"⚠️ Column '{col}': schéma dit '{target_type}' mais détectée alphanum → forcée en string."
                )
            before_sample = df_converted[col].head(3).tolist()
            df_converted[col] = (
                df_converted[col].map(safe_string_conversion).astype("string")
            )
            after_sample = df_converted[col].head(3).tolist()
            conversion_log.append(
                f"✅ Column '{col}': {current_dtype} → string (alphanum). Exemples avant→après: {before_sample} → {after_sample}"
            )
            # On n'applique rien d'autre sur cette colonne
            continue

        # --- 2) Conversions numériques "pures" (colonnes non alphanum)
        if target_type in ["int", "bigint", "integer"] and current_dtype in [
            "object",
            "string",
        ]:
            try:
                df_converted[col] = clean_and_convert_to_numeric(
                    df_converted[col], "int"
                )
                conversion_log.append(f"✅ Column '{col}': string → integer")
            except Exception as e:
                conversion_log.append(
                    f"⚠️ Column '{col}': conversion string → integer échouée: {e}"
                )

        elif target_type in ["double", "float", "decimal"] and current_dtype in [
            "object",
            "string",
        ]:
            try:
                df_converted[col] = clean_and_convert_to_numeric(
                    df_converted[col], "float"
                )
                conversion_log.append(f"✅ Column '{col}': string → double")
            except Exception as e:
                conversion_log.append(
                    f"⚠️ Column '{col}': conversion string → double échouée: {e}"
                )

        # --- 3) Normalisation des colonnes déjà numériques
        elif target_type in ["double", "float", "decimal"] and current_dtype in [
            "float64",
            "float32",
        ]:
            df_converted[col] = df_converted[col].astype("float64").fillna(0.0)
            conversion_log.append(f"✅ Column '{col}': normalisation des valeurs float")

        elif target_type in ["int", "bigint", "integer"] and current_dtype in [
            "int64",
            "int32",
        ]:
            # astype int ne supporte pas NaN → on remplace avant
            df_converted[col] = df_converted[col].fillna(0).astype("int64")
            conversion_log.append(f"✅ Column '{col}': normalisation des valeurs int")

    return df_converted, conversion_log


def compare_schemas_pandas_flexible(
    excel_df: pd.DataFrame, target_schema: Dict
) -> Tuple[bool, Dict]:
    """
    Flexible schema comparison that accepts automatic conversions and handles missing columns
    Enhanced to properly handle mixed alphanumeric columns

    Returns:
        tuple: (is_match, differences)
    """
    excel_columns = set(excel_df.columns)
    target_columns = set(target_schema.keys())

    missing_in_excel = target_columns - excel_columns
    extra_in_excel = excel_columns - target_columns

    # Check data types for common columns with more flexibility
    type_mismatches = []
    auto_convertible = []
    common_columns = excel_columns & target_columns

    # Columns that can contain mixed alphanumeric values and should be converted to string
    alphanumeric_columns = [
        "company_code",
        "trading_partner_id",
        "account_number",
        "profit_center",
        "material_number",
        "plant_assembly",
        "plant_production_purchase",
        "WBS_code",
        "cost_center",
        "cost_center_from",
        "cost_center_to",
        "account_number_allocation",
        "account_allocation_base",
        "indexPNL_allocation_base",
        "fiscal_year",
    ]

    for col in common_columns:
        excel_type = pandas_to_sql_type(excel_df[col].dtype)
        target_type = target_schema[col].lower()

        # Enhanced compatibility check
        compatible_types = (
            (
                excel_type in ["bigint", "double"]
                and target_type in ["int", "bigint", "double", "float"]
            )
            or (excel_type == "string" and target_type in ["string", "varchar"])
            or
            # Allow ANY type to string conversion for alphanumeric columns (handles mixed values)
            (target_type in ["string", "varchar"] and col in alphanumeric_columns)
            or
            # Allow string to numeric ONLY for non-alphanumeric columns
            (
                excel_type == "string"
                and target_type in ["int", "bigint", "double", "float"]
                and col not in alphanumeric_columns
            )
        )

        if excel_type != target_type and not compatible_types:
            # Check if auto-convertible
            if col in alphanumeric_columns and target_type in ["string", "varchar"]:
                auto_convertible.append(
                    f"Column '{col}': {excel_type} → {target_type} (automatic conversion - preserves mixed alphanumeric/numeric values)"
                )
            elif (
                col not in alphanumeric_columns
                and excel_type == "string"
                and target_type in ["int", "bigint", "double", "float"]
            ):
                auto_convertible.append(
                    f"Column '{col}': {excel_type} → {target_type} (automatic conversion)"
                )
            else:
                type_mismatches.append(
                    f"Column '{col}': Excel has {excel_type}, target expects {target_type}"
                )

    # Handle missing columns
    if missing_in_excel:
        for col in missing_in_excel:
            auto_convertible.append(
                f"Column '{col}': Missing column will be restored with NULL/default values"
            )

    # Schema match if no extra columns and no true type mismatches
    # Missing columns are now auto-convertible, so they don't prevent matching
    is_match = len(extra_in_excel) == 0 and len(type_mismatches) == 0

    differences = {
        "missing_in_excel": missing_in_excel,
        "extra_in_excel": extra_in_excel,
        "type_mismatches": type_mismatches,
        "auto_convertible": auto_convertible,
    }

    return is_match, differences


def detect_mixed_alphanumeric_values(series: pd.Series) -> Dict[str, any]:
    """
    Detect if a series contains mixed alphanumeric and numeric values

    Args:
        series: pandas Series to analyze

    Returns:
        Dict with analysis results
    """
    if series.dtype != "object":
        return {
            "has_mixed": False,
            "numeric_count": 0,
            "alphanumeric_count": 0,
            "samples": [],
        }

    # Convert to string and clean
    str_values = series.dropna().astype(str)

    if len(str_values) == 0:
        return {
            "has_mixed": False,
            "numeric_count": 0,
            "alphanumeric_count": 0,
            "samples": [],
        }

    numeric_count = 0
    alphanumeric_count = 0
    samples = {"numeric": [], "alphanumeric": []}

    for value in str_values.head(20):  # Check first 20 values
        cleaned_value = value.strip().replace(".0", "")  # Remove .0 for pure integers

        # Check if purely numeric (allowing negative numbers)
        if cleaned_value.replace("-", "").isdigit():
            numeric_count += 1
            if len(samples["numeric"]) < 3:
                samples["numeric"].append(value)
        else:
            alphanumeric_count += 1
            if len(samples["alphanumeric"]) < 3:
                samples["alphanumeric"].append(value)

    has_mixed = numeric_count > 0 and alphanumeric_count > 0

    return {
        "has_mixed": has_mixed,
        "numeric_count": numeric_count,
        "alphanumeric_count": alphanumeric_count,
        "samples": samples,
    }


def pandas_to_sql_type(dtype) -> str:
    """Convert pandas dtype to SQL type string"""
    dtype_str = str(dtype).lower()

    if "int" in dtype_str:
        return "bigint"
    elif "float" in dtype_str:
        return "double"
    elif "bool" in dtype_str:
        return "boolean"
    elif "datetime" in dtype_str:
        return "timestamp"
    elif "object" in dtype_str:
        return "string"
    else:
        return "string"


def clean_and_convert_to_numeric(
    series: pd.Series, target_type: str = "float"
) -> pd.Series:
    """
    Clean and convert a pandas Series to numeric, handling various formats

    Args:
        series: pandas Series to convert
        target_type: 'int' or 'float'

    Returns:
        Converted pandas Series
    """
    if series.dtype != "object":
        # Already numeric
        return series.fillna(0.0 if target_type == "float" else 0)

    # Convert to string and clean
    cleaned = series.astype(str).str.strip()

    # Handle different number formats
    def clean_number_string(x):
        if pd.isna(x) or x in ["", "nan", "None"]:
            return "0"

        # Remove any leading/trailing whitespace
        x = str(x).strip()

        # Pattern 1: Comma thousand + dot decimal (e.g., -1,234.56)
        if "," in x and "." in x and x.rfind(",") < x.rfind("."):
            # Remove commas (thousand separators), keep dots (decimal)
            return x.replace(",", "")

        # Pattern 2: Space thousand + comma decimal (e.g., -1 234,56)
        elif " " in x and "," in x and "." not in x:
            # Remove spaces, replace comma with dot
            return x.replace(" ", "").replace(",", ".")

        # Pattern 3: Simple comma decimal (e.g., -1234,56)
        elif "," in x and "." not in x:
            # Replace comma with dot
            return x.replace(",", ".")

        # Pattern 4: Already correct format or integer
        else:
            return x

    # Apply cleaning
    cleaned = cleaned.apply(clean_number_string)

    # Convert to numeric
    numeric_series = pd.to_numeric(cleaned, errors="coerce")

    # Fill NaN with appropriate default
    if target_type == "int":
        return numeric_series.fillna(0).astype(int)
    else:
        return numeric_series.fillna(0.0)


def compare_schemas_pandas(
    excel_df: pd.DataFrame, target_schema: Dict
) -> Tuple[bool, Dict]:
    """
    Standard schema comparison

    Returns:
        tuple: (is_match, differences)
    """
    excel_columns = set(excel_df.columns)
    target_columns = set(target_schema.keys())

    missing_in_excel = target_columns - excel_columns
    extra_in_excel = excel_columns - target_columns

    # Check data types for common columns
    type_mismatches = []
    common_columns = excel_columns & target_columns

    for col in common_columns:
        excel_type = pandas_to_sql_type(excel_df[col].dtype)
        target_type = target_schema[col].lower()

        # Compatible types
        compatible_types = (
            excel_type in ["bigint", "double"]
            and target_type in ["int", "bigint", "double", "float"]
        ) or (excel_type == "string" and target_type in ["string", "varchar"])

        if excel_type != target_type and not compatible_types:
            type_mismatches.append(
                f"Column '{col}': Excel has {excel_type}, target expects {target_type}"
            )

    # Schema match if no missing/extra columns and no type mismatches
    is_match = (
        len(missing_in_excel) == 0
        and len(extra_in_excel) == 0
        and len(type_mismatches) == 0
    )

    differences = {
        "missing_in_excel": missing_in_excel,
        "extra_in_excel": extra_in_excel,
        "type_mismatches": type_mismatches,
        "auto_convertible": [],
    }

    return is_match, differences


def upload_dataframe_to_table(
    client,
    df: pd.DataFrame,
    table_name: str,
    filename: str,
    user_email: str,
    template_nber: int,
) -> Tuple[bool, str]:
    """
    Upload optimized with fixed batch size and improved SQL value handling
    """
    try:
        # Add metadata columns
        df_with_metadata = df.copy()
        df_with_metadata["upload_timestamp"] = get_paris_timestamp()
        df_with_metadata["uploaded_by"] = get_user_name_from_email(user_email)
        df_with_metadata["source_file_name"] = filename
        df_with_metadata["id_row"] = range(1, len(df_with_metadata) + 1)

        if template_nber == 8:
            df_with_metadata["id"] = (
                df_with_metadata["upload_timestamp"]
                + "_by_"
                + df_with_metadata["uploaded_by"]
            )
        elif template_nber == 1:
            df_with_metadata["id"] = (
                df_with_metadata["upload_timestamp"]
                + "_by_"
                + df_with_metadata["uploaded_by"]
                + "_for_"
                + df_with_metadata["company_code"]
            )
        else:
            df_with_metadata["id"] = (
                df_with_metadata["upload_timestamp"]
                + "_by_"
                + df_with_metadata["uploaded_by"]
                + "_for_"
                + df_with_metadata["division"]
            )

        # Get warehouse ID
        if not constants.WAREHOUSE_ID:
            return False, "No SQL warehouse available"

        total_rows = len(df_with_metadata)
        batch_size = 1000  # Fixed batch size - sufficient for max 200k rows
        successful_rows = 0
        failed_batches = []

        # Get columns for the insert
        columns = list(df_with_metadata.columns)
        columns_str = ", ".join([f"`{col}`" for col in columns])

        # Colonnes qui doivent être traitées comme des strings même si elles ressemblent à des nombres
        string_columns = {
            "account_number",
            "fiscal_year",
            "company_code",
            "profit_center",
            "cost_center",
            "plant_assembly",
            "uploaded_by",
            "source_file_name",
            "id",
            "plant_production_purchase",
            "material_number",
            "cost_center_from",
            "cost_center_to",
            "WBS_Code",
            "trading_partner_id",
            "account_number_allocation",
            "account_allocation_base",
            "indexPNL_allocation_base",
        }

        for batch_num in range(0, total_rows, batch_size):
            batch_df = df_with_metadata.iloc[batch_num : batch_num + batch_size]
            current_batch_size = len(batch_df)

            # Build VALUES clause with improved type handling
            values_list = []
            for _, row in batch_df.iterrows():
                row_values = []
                for col, value in zip(columns, row):
                    if pd.isna(value) or value is None:
                        row_values.append("NULL")
                    elif col in string_columns or isinstance(value, str):
                        # Force string treatment for specific columns or actual strings
                        str_value = str(value)
                        # Properly escape strings
                        escaped_value = (
                            str_value.replace("'", "''")
                            .replace("\\", "\\\\")
                            .replace("\n", " ")
                            .replace("\r", " ")
                        )
                        row_values.append(f"'{escaped_value}'")
                    else:
                        # For pure numeric values (not in string_columns)
                        row_values.append(str(value))

                values_list.append(f"({', '.join(row_values)})")

            # Create INSERT with VALUES
            values_clause = ", ".join(values_list)
            insert_query = (
                f"INSERT INTO {table_name} ({columns_str}) VALUES {values_clause}"
            )

            try:
                response = client.statement_execution.execute_statement(
                    statement=insert_query, warehouse_id=constants.WAREHOUSE_ID
                )

                # Simplified success verification
                if response.status and response.status.state.value == "SUCCEEDED":
                    successful_rows += current_batch_size
                else:
                    error_msg = (
                        response.status.error.message
                        if (response.status and response.status.error)
                        else "Unknown error"
                    )
                    failed_batches.append(
                        f"Batch {batch_num//batch_size + 1}: {error_msg}"
                    )
                    st.error(
                        f"❌ Batch {batch_num//batch_size + 1} failed: {error_msg}"
                    )

                # Progress update
                progress = min((batch_num + batch_size) / total_rows, 1.0)
                rows_processed = min(batch_num + batch_size, total_rows)

            except Exception as batch_error:
                error_msg = str(batch_error)
                failed_batches.append(f"Batch {batch_num//batch_size + 1}: {error_msg}")
                st.error(
                    f"❌ Exception in batch {batch_num//batch_size + 1}: {error_msg}"
                )

        # Simplified final result
        if successful_rows == total_rows:
            return (
                True,
                f"Upload completed successfully: {successful_rows:,} rows uploaded",
            )
        elif successful_rows > 0:
            return (
                False,
                f"Partial upload: {successful_rows:,}/{total_rows:,} rows uploaded. {len(failed_batches)} batches failed",
            )
        else:
            return (
                False,
                f"Upload failed completely. First error: {failed_batches[0] if failed_batches else 'Unknown error'}",
            )

    except Exception as e:
        return False, f"Critical error uploading data: {str(e)}"
