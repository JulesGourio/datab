# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC **Description:**  
# MAGIC The aim is to create ingestion for Custom Maroc input Business 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_READ_ENV}_bronze.customs_maroc.invoice_base
# MAGIC   - {PIPELINE_READ_ENV}_bronze.customs_maroc.situation_latest
# MAGIC
# MAGIC **Input :**  
# MAGIC   - f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/" *Invoice_Base_Maroc*  
# MAGIC   - f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/" *DUM_Status_Maroc*  
# MAGIC   
# MAGIC **Triggered by:**  
# MAGIC   - File available on S3
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **Python dependencies needed**
# MAGIC
# MAGIC `%pip install fsspec s3fs openpyxl`

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark import pandas as ps
import re
import pyspark.sql.functions as f
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC **Link MLV // Sommier**  
# MAGIC HS Code :   sommier.nomenclature = mlv.code_march
# MAGIC Valuation : sommier.gross value = mlv.value_declared  
# MAGIC Unit : sommier.Unit = mlv.Unit
# MAGIC Qty : sommier.quantity = mlv.quantity
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")
# Get pipeline environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
# Get write environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")



# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC The inputs of this notebook are excel files that are in S3 manual/leapdepot/UC02_INVENTORY. Only files that contain "INVENTORY_IS_USA" is acceptable. \
# MAGIC Warning: This notebook needs to work if only one branch put a file. 

# COMMAND ----------

list_external_files = []
files = dbutils.fs.ls(
    f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/Invoices/"
)
# if not files:
#     raise Exception("No files found in the Invoices folder")
if files:
    df = spark.createDataFrame(files)

    if df.count() > 1:
        raise Exception("More than 1 file in the folder, check and come back")

    if df.filter(f.col("name").contains("Invoice_Base_Maroc")).count() == 1:
        list_external_files.append("BASE_FACT")

files2 = dbutils.fs.ls(
    f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/Dum_Status/"
)
# if not files2:
#     raise Exception("No files found in the Dum_Status folder")
if  files2:
    df2 = spark.createDataFrame(files2)

    if df2.count() > 1:
        raise Exception("More than 1 file in the folder, check and come back")

    if df2.filter(f.col("name").contains("DUM_Status_Maroc")).count() == 1:
        list_external_files.append("STATUS_DUM")

list_external_files

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Ingestion 1 - Base Invoicing

# COMMAND ----------

if "BASE_FACT" in list_external_files:
    path_to_reference_file_as = list(
        spark.createDataFrame(
            dbutils.fs.ls(
                f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/Invoices/"
            )
        )
        .filter(f.col("name").contains("Invoice_Base_Maroc"))
        .select("path")
        .toPandas()["path"]
    )[0]

    # Create DataFrame according AS Excel Files
    sheet_name = "Base"
    # We read the database saved in the corresponding sheet_name
    pdf_invoice_maroc = ps.read_excel(
        path_to_reference_file_as, sheet_name=sheet_name, dtype="string"
    )
    ## Keep solution where we used Header from Excel Files
    # Rename column headers and replace invalid characters
    pdf_invoice_maroc.columns = [
        re.sub("\W+", "_", col.strip()) for col in pdf_invoice_maroc.columns
    ]
    df_invoice_maroc = pdf_invoice_maroc.to_spark()
    # -----------------------------------------------------------------------
    # Upload Bronze Table vbrp for linked invoice and DUM
    df_vbrp = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.vbrp_latest"
    ).select(
        f.col("vbeln").alias("Invoice"),
        f.col("posnr").alias("Invoice_item"),
        f.col("vgbel").alias("delivery_note"),
        f.col("vgpos").alias("delivery_item"),
        f.col("aubel").alias("p_order"),
        f.col("aupos").alias("order_item"),
        f.col("erdat").alias("Date_cde"),
    )
    # Remove leading zeros from Material_Number and Work_Order
    df_vbrp_end = table_utils.remove_leading_zeros(
        df_vbrp,
        [
            "Invoice",
            "Invoice_item",
            "delivery_note",
            "delivery_item",
            "p_order",
            "order_item",
        ],
    )
    df_join = df_invoice_maroc.join(
        df_vbrp_end,
        ["invoice", "Invoice_item"],
        "left",
    )
    # -----------------------------------------------------------------------
    # Management Interco/Standard
    df_maroc_interco = df_join.withColumn(
        "Purchase_Order",
        f.when(f.col("Type") == "Interco", f.col("p_order")).otherwise(
            f.col("Purchase_Number")
        ),
    )
    df_maroc_interco = df_maroc_interco.withColumn(
        "Purchase_Order_Item",
        f.when(f.col("Type") == "Interco", f.col("order_item")).otherwise(
            f.col("Purchase_Item")
        ),
    ).drop("Purchase_Number", "Purchase_Item", "p_order", "order_item")
    # -----------------------------------------------------------------------

    # Management bad currency
    df_maroc_interco = df_maroc_interco.withColumn(
        "Country",
        f.when(f.col("Country") == "CZ", f.lit("REP")).otherwise(f.col("Country")),
    )
    # -----------------------------------------------------------------------
    # Cancel Space on key columns
    df_maroc_interco = df_maroc_interco.withColumn(
        "Sous_DUM", f.regexp_replace(f.rtrim(f.col("Sous_DUM")),  "\\s+", ""),
    ).withColumn(
        "Unit", f.regexp_replace(f.rtrim(f.col("Unit")),  "\\s+", ""),
    ).withColumn(
        "Country", f.regexp_replace(f.rtrim(f.col("Country")),  "\\s+", ""),
    )
    # Management bad unit
    df_maroc_interco = df_maroc_interco.withColumn(
        "Unit",
        f.when((f.col("Unit") == "PC2")|(f.col("Unit") == "UN"), f.lit("U"))
        .when(f.col("Unit") == "G", f.lit("GR. NET"))
        .when(f.col("Unit") == "KG", f.lit("KG. NET"))
        .otherwise(f.col("Unit")),
    )
    # Creation Key Base Fact
    df_maroc_key = df_maroc_interco.withColumn(
        "Key_DUM", f.concat_ws("_", f.col("Unit"), f.col("Country"), f.col("Sous_DUM"))
    )

    # -----------------------------------------------------------------------
    catalog = f"{PIPELINE_WRITE_ENV}_bronze"
    domain = "customs_maroc"
    table = "invoice_base"

    spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

    table_utils.save_table(
        dest_table=f"{catalog}.{domain}.{table}",
        df=df_maroc_key,
        mode="overwrite",
        overwrite_schema=True,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Ingestion 2 - BASE DUM Situation

# COMMAND ----------

if "STATUS_DUM" in list_external_files:
    path_to_reference_file_dum = list(
        spark.createDataFrame(
            dbutils.fs.ls(
                f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/Dum_Status/"
            )
        )
        .filter(f.col("name").contains("DUM_Status_Maroc"))
        .select("path")
        .toPandas()["path"]
    )[0]

    # Create DataFrame according AS Excel Files
    sheet_name = "Base"
    # We read the database saved in the corresponding sheet_name
    pdf_dum_maroc_follow = ps.read_excel(
        path_to_reference_file_dum, sheet_name=sheet_name, dtype="string"
    )
    ## Keep solution where we used Header from Excel Files
    # Rename column headers and replace invalid characters
    pdf_dum_maroc_follow.columns = [
        re.sub("\W+", "_", col.strip()) for col in pdf_dum_maroc_follow.columns
    ]
    df_dum_maroc_follow = pdf_dum_maroc_follow.to_spark()
    # ---------------------------------------------------------------------------------------
    List_regim = ["022", "023", "082"]
    df_dum_maroc_filter = df_dum_maroc_follow.filter(f.col("Regime").isin(List_regim))
    # ---------------------------------------------------------------------------------------
    # Cast Column dum
    quantity_columns = [
        "Qty_open",
        "Qty_closed",
        "Qty_in_progress",
        "Value_open",
        "Value_closed",
        "Value_in_progress",
    ]
    for col in quantity_columns:
        df_dum_maroc_filter = df_dum_maroc_filter.withColumn(
            col,
            f.when(
                f.col(col).isNotNull(),
                f.regexp_replace(f.trim(f.col(col)), ",", ".").cast("double"),
            ).otherwise(f.lit(0)),
        )
    # ---------------------------------------------------------------------------------------
    df_dum_maroc_clean = (
        df_dum_maroc_filter.withColumn(
            "Date_end_validity", f.to_date(f.col("Date_end_validity"))
        )
        .withColumn("Date", f.to_date(f.col("Date")))
        .withColumn(
            "Unit",
            f.when(f.col("Unit") == "NB", f.lit("U"))
            .when(f.col("Unit") == "ROULEAU", f.lit("ROU"))
            .otherwise(f.col("Unit")),
        )
        .dropDuplicates()
    )
    # ---------------------------------------------------------------------------------------
    # Add Key Dum
    df_dum_maroc_key = df_dum_maroc_clean.withColumn(
        "Key_DUM_Base",
        f.concat_ws(
            "_",
            f.col("DUM"),
            f.col("HS_Code"),
            f.col("Unit"),
            f.col("Qty_open"),
            f.col("Value_open"),
        ),
    )
    # ---------------------------------------------------------------------------------
    # Management of Quantity still available in DUM
    df_dum_maroc_status = (
        df_dum_maroc_key.withColumn(
            "Qty_remaining", f.col("Qty_open") - f.col("Qty_in_progress")
        )
        .withColumn(
            "Value_remaining",
            f.col("Qty_remaining") * f.col("Value_open") / f.col("Qty_open"),
        )
        .withColumn(
            "Qty_waiting",
            f.col("Qty_in_progress") - f.col("Qty_closed"),
        )
    )
    # ---------------------------------------------------------------------------------
    # Creation of statut of actual statuts
    df_dum_maroc_status_end = df_dum_maroc_status.withColumn(
        "Status",
        f.when(f.col("Value_remaining") <= 0, f.lit("Closed"))
        .when(f.col("Date_end_validity") < f.current_date(), f.lit("Expired"))
        .otherwise(f.lit("Open")),
    )
    # --------------------------------------------------------------------------------
    # Save Bronze Table
    catalog = f"{PIPELINE_WRITE_ENV}_bronze"
    domain = "customs_maroc"
    table = "situation_latest"

    spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

    table_utils.save_table(
        dest_table=f"{catalog}.{domain}.{table}",
        df=df_dum_maroc_status_end,
        mode="overwrite",
        overwrite_schema=True,
    )
    # --------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC #Archive files in S3

# COMMAND ----------

# MAGIC %md
# MAGIC ##1-Archive files Invoices Files

# COMMAND ----------

if files:
    source_path = (
        f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/Invoices/"
    )
    target_path = f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/archive/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/Invoices/"
    #-------------------------------------------------------------------------
    if len(dbutils.fs.ls(f"{source_path}/")) > 0:
        s3_files = spark.createDataFrame(dbutils.fs.ls(f"{source_path}/"))
        # List of all file name to ingest
        name_list = [row.name for row in s3_files.select("name").collect()]
    #-------------------------------------------------------------------------
    for i in range(len(name_list)):
        file_path = name_list[i]
        dbutils.fs.mv(f"{source_path}/{file_path}", f"{target_path}/{file_path}")

# COMMAND ----------

# MAGIC %md
# MAGIC ##2-Archive files Dum status

# COMMAND ----------

if files2:
    source_path = (
        f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/Dum_Status/"
    )
    target_path = f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/archive/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/Dum_Status/"
    #-------------------------------------------------------------------------
    if len(dbutils.fs.ls(f"{source_path}/")) > 0:
        s3_files = spark.createDataFrame(dbutils.fs.ls(f"{source_path}/"))
        # List of all file name to ingest
        name_list = [row.name for row in s3_files.select("name").collect()]
    #-------------------------------------------------------------------------
    for i in range(len(name_list)):
        file_path = name_list[i]
        dbutils.fs.mv(f"{source_path}/{file_path}", f"{target_path}/{file_path}")
