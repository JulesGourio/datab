"""
Streamlit application for the ingestion of .pdf files for the project Customs Morocco
"""

import io
import sys
from datetime import timedelta
from os import getenv, mkdir
from pathlib import Path
from tempfile import TemporaryDirectory

import pandas as pd
import streamlit as st
from databricks import sql
from databricks.sdk import WorkspaceClient
from databricks.sdk.core import Config
from databricks.sql.client import Connection
from streamlit_pdf_viewer import pdf_viewer

sys.path.append(str(Path(__file__).parent.parent.parent.parent))

from ingestion.Customs_Maroc.ingestion_app import constants, dbx_constants, library
from leap_utils.common.files import pdf_utils
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger
from leap_utils.data_asset import table_utils_sql

log = setup_applevel_logger(
    log_level=LOGGER_MAPPING[getenv("LOG_LEVEL", "info").lower()]
)

cfg = Config()

workspace = WorkspaceClient()

st.set_page_config(layout="wide")

if "file_parsed" not in st.session_state:
    st.session_state.files_uploaded = False
    st.session_state.file_type = None
    st.session_state.file_parsed = False
    st.session_state.remaining_files = []
    st.session_state.temp_folder = None
    st.session_state.input_file = None
    st.session_state.output_file = None
    st.session_state.parsed_data = None
    st.session_state.header_data = None
    st.session_state.items_data = None
    st.session_state.edited_header_data = None
    st.session_state.edited_items_data = None
    st.session_state.data_submitted = False
    st.session_state.data_is_valid = True
    st.session_state.data_saving_error = False
    st.session_state.process_next_file = False
    st.session_state.found_existing_document_in_db = None
    st.session_state.has_missing_items_warning = False


@st.cache_resource(ttl=timedelta(minutes=15), show_spinner=False)
def get_connection() -> Connection:
    """
    Get a connection to a remote Databricks SQL warehouse.
    Uses the global variable ``WAREHOUSE_PATH``.

    :return: Connection to a SQL warehouse
    :rtype: Connection
    """
    connection = sql.connect(
        server_hostname=cfg.host,
        http_path=dbx_constants.WAREHOUSE_PATH,
        credentials_provider=lambda: cfg.authenticate,
    )
    log.info("Initialized SQL warehouse connection.")
    return connection


def reset_parsing() -> None:
    """
    Callback to reset the file parsing process of the current file.

    Invoked when the file type was changed (component ``selectbox``).
    """
    st.session_state.file_parsed = False
    st.session_state.parsed_data = None
    st.session_state.header_data = None
    st.session_state.items_data = None
    st.session_state.edited_header_data = None
    st.session_state.edited_items_data = None
    st.session_state.data_submitted = False
    st.session_state.data_is_valid = True
    st.session_state.data_saving_error = False
    st.session_state.found_existing_document_in_db = None


def reset_page() -> None:
    """
    Callback to reset the page entirely.
    """
    reset_parsing()
    st.session_state.input_file = None
    st.session_state.output_file = None
    st.session_state.temp_folder = None
    st.session_state.files_uploaded = False
    st.session_state.remaining_files = []
    st.session_state.process_next_file = False


def process_next_file() -> None:
    """
    Callback to process the next remaining file :

    - pop one element of `st.session_state.remaining_files`
    - create a temp folder
    - write the input file in it
    - set the session state variables `temp_folder`, `input_file` and `output_file`
    """
    # reset the value of the session state variable
    st.session_state.process_next_file = False

    file_to_process = st.session_state.remaining_files.pop()

    file_bytes = file_to_process.read()

    temp_directory = TemporaryDirectory()
    # store the temporary directory in the session state so that
    # it is not garbage-collected
    st.session_state.temp_folder = temp_directory

    mkdir(Path(temp_directory.name) / "input")
    mkdir(Path(temp_directory.name) / "output")
    input_file = Path(temp_directory.name) / "input" / file_to_process.name
    output_file = Path(temp_directory.name) / "output" / file_to_process.name

    with open(input_file, "wb") as fp:
        fp.write(file_bytes)

    st.session_state.input_file = input_file
    st.session_state.output_file = output_file


def disable_submit_button() -> None:
    """
    Callback to disable the submit button once the user clicked it

    Invoked when the component ``button`` changes
    """
    st.session_state.data_submitted = True

def get_missing_value_locations(df: pd.DataFrame) -> list[tuple[int, int]]:
    """
    Return the locations of rows containing missing values.

    A row is considered "missing" if it contains at least one empty string ("")
    or NaN/NA value in any column.

    Returns
    -------
    list[tuple[int, int]]
        A sorted list of unique (page_number, item_number) pairs indicating
        where missing values were found in the dataframe.
    """
    missing_rows = (
        df.replace("", pd.NA)
        .isna()
        .any(axis=1)
    )

    return sorted(
        df.loc[missing_rows, ["page_number", "item_number"]]
        .drop_duplicates()
        .itertuples(index=False, name=None)
    )

def is_designation_empty_items_only(df: pd.DataFrame) -> bool:
    items = df[constants.SPLIT_DESIGNATION_COLS].replace(["", " "], pd.NA)
    valid_rows = items.notna().any(axis=1)
    return valid_rows.sum() == 0

def is_sous_dum_empty(df: pd.DataFrame) -> bool:
    return (
        df["sous_dum"]
        .astype("string")
        .str.strip()
        .replace("", pd.NA)
        .isna()
        .all()
    )


with st.form("pdf_uploader", clear_on_submit=True):
    uploaded_files = st.file_uploader(
        label="Upload .pdf MLV or Sommier files",
        type="pdf",
        accept_multiple_files=True,
    )
    st.form_submit_button(label="submit", on_click=reset_page)


if uploaded_files and not st.session_state.files_uploaded:
    st.session_state.files_uploaded = True
    st.session_state.remaining_files = uploaded_files
    process_next_file()
elif st.session_state.remaining_files and (
    st.session_state.process_next_file or not st.session_state.input_file
):
    reset_parsing()
    process_next_file()
    st.rerun()

if st.session_state.remaining_files:
    st.text("Remaining files to process : ")
    st.html(
        "<ul>\n<li>"
        + "</li>\n<li>".join([file.name for file in st.session_state.remaining_files])
        + "</li>\n</ul>"
    )

if st.session_state.input_file:
    st.title(f"Processing file {st.session_state.input_file.name}")

    with st.empty():
        if not st.session_state.data_submitted:
            if st.button(
                label="Skip this file",
                help="Discard this file",
                type="secondary",
            ):
                if st.session_state.remaining_files:
                    st.session_state.process_next_file = True
                    st.rerun()
                else:
                    reset_page()
                    st.session_state.files_uploaded = True
                    st.rerun()

progress_bar = st.progress(value=0)
progress_bar.empty()

with st.empty():
    if st.session_state.input_file and not st.session_state.file_parsed:
        st.session_state.file_type = st.selectbox(
            label="file type",
            options=["MLV (detailled)", "MLV (simplified)", "SOMMIER"],
            index=None,
            on_change=reset_parsing,
            placeholder="Select file type",
            accept_new_options=False,
        )

if st.session_state.input_file and not st.session_state.file_parsed:
    if (
        st.session_state.file_type == "MLV (detailled)"
        or st.session_state.file_type == "MLV (simplified)"
    ):
        progress_bar.progress(value=0, text="reading pdf file ...")
        try:
            progress_bar.progress(value=20, text="adding missing lines ...")

            pdf_utils.process_pdf_lines_completion(
                input_pdf_path=st.session_state.input_file,
                output_pdf_path=st.session_state.output_file,
                temporary_path=st.session_state.temp_folder.name,
                x_completion=5,
                y_top_completion=13,
                y_bottom_completion=25,
                y_len_min=10,
                connect_disjoint_verticals=False,
            )

            progress_bar.progress(value=40, text="extracting data from refined pdf ...")

            raw_extracted_data = pdf_utils.extract_mlv_main_table(
                pdf_path=st.session_state.output_file,
                main_balise_aliases=constants.MLV_MAIN_TAGS,
                item_balise_aliases=constants.MLV_ITEM_TAGS,
            )

            progress_bar.progress(value=60, text="post-processing extracted data ...")

            post_processed_data = pdf_utils.mlv_post_processing(
                df=pd.DataFrame(raw_extracted_data),
                mlv_type = st.session_state.file_type
            )

            progress_bar.progress(value=80, text="running quality checks ...")

            st.session_state.data_is_valid = (
                pdf_utils.customs_pdf_extracted_data_is_valid(
                    df=post_processed_data,
                    column_to_sum="value_declared",
                    column_to_compare_to="total_value_declared",
                )
            )

            st.session_state.parsed_data = post_processed_data

            st.session_state.file_parsed = True
            st.session_state.data_is_valid = True

            progress_bar.progress(value=100, text="Parsing done !")

        except Exception as exception:
            log.error(exception, exc_info=True)
            st.error("Unable to parse file, did you select the correct file type ?")

    elif st.session_state.file_type == "SOMMIER":
        progress_bar.progress(value=0, text="reading pdf file ...")
        try:
            progress_bar.progress(value=20, text="adding missing lines ...")

            pdf_utils.process_pdf_lines_completion(
                input_pdf_path=st.session_state.input_file,
                output_pdf_path=st.session_state.output_file,
                temporary_path=st.session_state.temp_folder.name,
                add_border=False,
                x_completion=5,
                y_top_completion=5,
                y_bottom_completion=50,
                y_len_min=5,
                connect_disjoint_verticals=True,
            )

            progress_bar.progress(value=40, text="extracting data from refined pdf ...")

            expected_columns = (
                constants.SOMMIER_HEADER_COLUMNS + constants.SOMMIER_TABLE_COLUMNS
            )
            expected_num_columns = len(expected_columns)

            raw_extracted_data = pdf_utils.extract_sommier_header_and_main_table(
                pdf_path=st.session_state.output_file,
                expected_number_of_columns=expected_num_columns,
            )

            progress_bar.progress(value=60, text="post-processing extracted data ...")

            post_processed_data = pdf_utils.sommier_post_processing(
                df=pd.DataFrame(raw_extracted_data, columns=expected_columns),
            )

            progress_bar.progress(value=80, text="running quality checks ...")

            st.session_state.data_is_valid = (
                pdf_utils.customs_pdf_extracted_data_is_valid(
                    df=post_processed_data,
                    column_to_sum="gross_value",
                    column_to_compare_to="total_value_declared",
                )
            )

            st.session_state.parsed_data = post_processed_data

            st.session_state.file_parsed = True
            st.session_state.data_is_valid = True

            progress_bar.progress(value=100, text="Parsing done !")

        except Exception as exception:
            log.error(str(exception), exc_info=True)
            st.error("Unable to parse file, did you select the correct file type ?")

    else:
        st.error("Please select a pdf type")
        st.session_state.file_parsed = None
        progress_bar.empty()

    progress_bar.empty()

if st.session_state.file_parsed:
    left_column, right_column = st.columns(2, vertical_alignment="top")

    with left_column:
        with st.container(height=600):
            pdf_viewer(
                input=st.session_state.input_file,
                on_annotation_click=None,
                width="100%",
                resolution_boost=2,
                pages_vertical_spacing=25,
            )

    header_data, items_data = library.split_parsed_data(
        data=pd.DataFrame(st.session_state.parsed_data)
    )
    items_data = (
        pd.DataFrame(items_data)
        .astype({"page_number": int, "item_number": int})
        .sort_values(
            by=[
                "page_number",
                constants.HS_CODE_COLUMN[st.session_state.file_type],
                "item_number",
            ],
            ignore_index=True,
        )
    )

    if st.session_state.header_data is None or st.session_state.items_data is None:
        # initialize the data editor with the original parsed data
        st.session_state.header_data = header_data
        st.session_state.items_data = items_data

    with right_column:
        with st.spinner("Looking for matches in DB ..."):
            identifying_column = constants.DOC_IDENTIFYING_COLUMN[
                st.session_state.file_type
            ]
            document_identifier = header_data.loc[0, identifying_column]
            document_extraction_timestamp = header_data.loc[
                0, "_meta_extraction_timestamp"
            ]

            if st.session_state.found_existing_document_in_db is None:
                existing_document_in_db = library.existing_file_in_db(
                    conn=get_connection(),
                    file_identifier=document_identifier,
                    table_name=dbx_constants.DESTINATION_TABLES[st.session_state.file_type],
                    identifying_column=identifying_column,
                )
                st.session_state.found_existing_document_in_db = (
                    existing_document_in_db is not None
                )

        if st.session_state.found_existing_document_in_db:
            st.warning(
                f"An existing {st.session_state.file_type} with the same "
                f"{identifying_column} ( {document_identifier} ) was found in DB !\n"
                "If you submit data, it will overwrite the existing data in DB."
            )

        if not st.session_state.data_is_valid:
            st.error(
                "The total declared sum (header) is not equal to "
                "the sum of individual values !"
            )
        else:
            st.empty()
        if not st.session_state.data_submitted:
            st.header(body="Header Data", anchor=False, divider=False)
            st.session_state.edited_header_data = st.data_editor(
                data=st.session_state.header_data,
                key="data_editor_header",
                hide_index=True,
                column_config=library.columns_configuration(
                    extracted_dataframe=st.session_state.header_data
                ),
                num_rows="fixed",
            )
            st.header(body="Items Data", anchor=False, divider=False)

            st.session_state.edited_items_data = st.data_editor(
                data=st.session_state.items_data,
                key="data_editor_items",
                hide_index=True,
                column_config=library.columns_configuration(
                    extracted_dataframe=st.session_state.items_data,
                ),
                num_rows="dynamic",
            )

            def display_unallowed_ingestion(text: str):
                st.error(f"Document cannot be ingested: {text}")
                st.session_state.data_is_valid = False
                st.session_state.has_missing_items_warning = False

            if (
                st.session_state.file_type == "MLV (detailled)"
                and is_designation_empty_items_only(st.session_state.edited_items_data)
                ):
                display_unallowed_ingestion("no item detected in designation fields.")

            elif is_sous_dum_empty(st.session_state.edited_header_data):
                display_unallowed_ingestion("sous dum is null.")

            else:
                st.session_state.data_is_valid = True
                st.session_state.has_missing_items_warning = True


            locations = get_missing_value_locations(st.session_state.edited_items_data)

            if locations and st.session_state.has_missing_items_warning:
                items = "\n".join(f"- {p} (item number {i})" for p, i in locations)
                st.warning(f"Some fields are empty on page(s):\n{items}")

        else:
            st.header(body="Header Data", anchor=False, divider=False)
            st.dataframe(
                data=st.session_state.edited_header_data,
                hide_index=True,
                column_config=library.columns_configuration(
                    extracted_dataframe=st.session_state.edited_header_data
                ),
            )
            st.header(body="Items Data", anchor=False, divider=False)
            st.dataframe(
                data=st.session_state.edited_items_data,
                hide_index=True,
                column_config=library.columns_configuration(
                    extracted_dataframe=st.session_state.edited_items_data
                ),
            )

        if st.button(
            label="Submit",
            help="submit (modified) parsed data",
            type="primary",
            on_click=disable_submit_button,
            disabled=st.session_state.data_submitted
            or not st.session_state.data_is_valid,
        ):
            regrouped_data = library.regroup_edited_header_and_items_data(
                header_data=st.session_state.edited_header_data,
                items_data=st.session_state.edited_items_data,
            )
            if not pdf_utils.customs_pdf_extracted_data_is_valid(
                df=regrouped_data,
                column_to_sum="gross_value"
                if "gross_value" in regrouped_data.columns
                else "value_declared",
                column_to_compare_to="total_value_declared",
            ):
                st.session_state.data_submitted = False
                st.session_state.data_is_valid = False
                # use the edited data to (re)initialize the data editor
                st.session_state.header_data = (
                    st.session_state.edited_header_data.copy()
                )
                st.session_state.items_data = st.session_state.edited_items_data.copy()
                st.rerun()
            else:
                st.session_state.data_is_valid = True
                if st.session_state.file_type == "MLV (detailled)":
                    # Presta removal is added here to verify the condition
                    # sum of values declared equals to total_value declared
                    regrouped_data = regrouped_data[
                        ~(
                            regrouped_data["delivery_note"].str.contains(
                                "PRESTA", case=False, na=False) |
                            regrouped_data["invoice"].astype(str).str.contains(
                                "PRESTA", case=False, na=False)
                        )]
                manually_edited_data_df = library.generate_manually_edited_data_df(
                    edition_report_header=st.session_state.data_editor_header,
                    edition_report_items=st.session_state.data_editor_items,
                    regrouped_data=regrouped_data,
                    doc_type=st.session_state.file_type,
                )
                try:
                    with st.spinner("Saving data in Databricks ..."):

                        if st.session_state.file_type == "MLV (detailled)":
                            regrouped_data["designation"] = None
                            regrouped_data["detailled"] = True
                        elif st.session_state.file_type == "MLV (simplified)":
                            for field in constants.SPLIT_DESIGNATION_COLS:
                                regrouped_data[field] = None
                            regrouped_data["detailled"] = False

                        table_utils_sql.merge_into(
                            conn=get_connection(),
                            source_dataframe=regrouped_data,
                            target_table=dbx_constants.DESTINATION_TABLES[
                                st.session_state.file_type
                            ],
                            list_id_matching_columns=[
                                "pdf_name",
                                "_meta_extraction_timestamp",
                                constants.DOC_IDENTIFYING_COLUMN[
                                    st.session_state.file_type
                                ],
                                constants.HS_CODE_COLUMN[st.session_state.file_type],
                                "item_number",
                            ],
                            do_when_matched=True,
                            do_when_notmatched=True,
                            do_when_notmatchedbysource=False,
                        )
                    with st.spinner("Saving metadata in Databricks ..."):
                        library.update_manually_edited_data_table(
                            conn=get_connection(),
                            doc_type=st.session_state.file_type,
                            edited_data_df=manually_edited_data_df,
                            extraction_timestamp=document_extraction_timestamp,
                            doc_identifier=document_identifier,
                        )
                    with st.spinner("Archiving the pdf file ..."):
                        with open(st.session_state.input_file, "rb") as input_file:
                            binary_data = io.BytesIO(input_file.read())
                        workspace.files.upload(
                            file_path=(
                                f"{dbx_constants.ARCHIVE_PATHS[st.session_state.file_type]}"
                                f"{st.session_state.input_file.name}"
                            ),
                            contents=binary_data,
                            overwrite=True,
                        )
                    st.session_state.data_saving_error = False
                except Exception as exception:
                    log.error(str(exception), exc_info=True)
                    st.session_state.data_saving_error = True

            st.rerun()

        if st.session_state.data_submitted:
            if not st.session_state.data_saving_error:
                if st.session_state.remaining_files:
                    st.success(
                        "Data saved ! Please process next file !",
                        icon=":material/check:",
                    )
                    if st.button(
                        label="Process Next File",
                        help="Process the next file of the batch",
                        type="secondary",
                    ):
                        st.session_state.process_next_file = True
                        st.rerun()
                else:
                    st.success(
                        "No more files to process. You can leave or refresh the page !",
                        icon=":material/check:",
                    )
            else:
                st.error(
                    "Unable to save data in Databricks, "
                    "please report this to the dev team !"
                )
