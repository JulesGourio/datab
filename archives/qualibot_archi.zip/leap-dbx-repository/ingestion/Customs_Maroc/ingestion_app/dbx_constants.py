"""
This module contains definition of constants related to Databricks configuration
for the ingestion app
"""

from os import getenv

from leap_utils.platform import deployment_environments

PIPELINE_WRITE_ENV = deployment_environments.WorkspaceIds(
    int(getenv("DATABRICKS_WORKSPACE_ID"))
).name

DESTINATION_TABLES = {
    "MLV (detailled)": f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.mlv_bronze_stack",
    "MLV (simplified)": f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.mlv_bronze_stack",
    "SOMMIER": f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.sommier_bronze_stack",
}

MANUAL_EDITS_TABLES = {
    "MLV (detailled)":
    f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.mlv_manual_edits",
    "MLV (simplified)":
    f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.mlv_manual_edits",
    "SOMMIER": f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.sommier_manual_edits",
}

ARCHIVE_PATHS = {
    "MLV (detailled)":
    f"/Volumes/{PIPELINE_WRITE_ENV}_bronze/customs_maroc/archived_mlv_pdfs/",
    "MLV (simplified)":
    f"/Volumes/{PIPELINE_WRITE_ENV}_bronze/customs_maroc/archived_mlv_pdfs/",
    "SOMMIER": f"/Volumes/{PIPELINE_WRITE_ENV}_bronze/customs_maroc/archived_sommier_pdfs/",  # noqa: E501
}

WAREHOUSE_PATH = deployment_environments.DefaultSqlWarehouse[PIPELINE_WRITE_ENV].value
