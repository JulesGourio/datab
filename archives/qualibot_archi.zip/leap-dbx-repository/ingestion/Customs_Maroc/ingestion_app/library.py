"""
Tools & functions for the pdf parsing app.
"""

from typing import Any, Literal, TypedDict

import pandas as pd
from databricks.sql.client import Connection
from streamlit.column_config import Column
from streamlit.elements.lib.column_types import ColumnConfig

from ingestion.Customs_Maroc.ingestion_app import constants, dbx_constants
from leap_utils.common import logger

log = logger.get_logger(module_name=__name__)


class DataEditor(TypedDict):
    """
    Representation of the contents of the data editor in the session state

    (used for type-hinting)
    """

    edited_rows: dict[int, dict[str, Any]]
    """Mapping {row_index -> dict{col_name -> updated_value}}"""

    added_rows: list[dict[str, Any]]
    """Contents of the manually added rows"""

    deleted_rows: list[dict[str, Any]]
    """Contents of the manually deleted rows"""


def existing_file_in_db(
    conn: Connection,
    file_identifier: str,
    table_name: str,
    identifying_column: Literal["sous_dum", "reference"],
) -> pd.DataFrame | None:
    """
    If an MLV or Sommier file exists in DB with the same identifier, returns its data,
    otherwise return None

    :param conn: Connection to a Databricks SQL Warehouse
    :type conn: Connection
    :param file_identifier: The file's "sous_dum" if it is an MLV, or "reference" if it
        is a Sommier
    :type file_identifier: str
    :param table_name: name of the table in which matching documents will be searched.
    :type table_name: str
    :param identifying_column: Name of the column identifying the document.
    :type identifying_column: Literal["sous_dum", "reference"]

    :return: The data already in DB for this document if such data exists, or None
    :rtype: pd.DataFrame | None
    """
    with conn.cursor() as cursor:
        cursor.execute(
            f"SELECT * FROM {table_name} "
            f"WHERE {identifying_column} == '{file_identifier}';"
        )
        result_df = cursor.fetchall_arrow().to_pandas()

    if len(result_df.index) == 0:
        log.debug(f"No matches found in DB for {identifying_column} {file_identifier}")
        return None

    log.debug(f"Matches found in DB for {identifying_column} {file_identifier} !")
    return result_df


def columns_configuration(extracted_dataframe: pd.DataFrame) -> dict[str, ColumnConfig]:
    """
    Generate columns configurations for the DataFrame ``extracted_dataframe`` :

    - mark all columns as required
    - mark some columns as read only

    :param extracted_dataframe: The DataFrame with the data parsed from the pdf file.
    :type extracted_dataframe: pd.DataFrame

    :return: A dict mapping each column name to its streamlit ColumnConfig
    :rtype: dict[str, ColumnConfig]
    """
    return {
        col_name: Column(
            disabled=(
                (col_name in constants.NON_EDITABLE_COLUMN_NAMES)
                or col_name.startswith(constants.NON_EDITABLE_COLUMN_NAMES_PREFIX)
            ),
            required=col_name not in constants.OPTIONAL_COLUMNS,
        )
        for col_name in extracted_dataframe.columns
    }


def split_parsed_data(
    data: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Splits the parsed data in two DataFrames : the "header data" and the "items data"

    :param data: The (post-processed) parsed data
    :type data: pd.DataFrame

    :return: header data, items data
    :rtype: tuple[pd.DataFrame, pd.DataFrame]
    """
    header_columns = (
        [
            "pdf_name",
            "_meta_extraction_timestamp",
            "_meta_ingestion_timestamp",
            "_meta_file_name",
        ]
        + constants.MLV_HEADER_COLUMNS
        + constants.SOMMIER_HEADER_COLUMNS
    )

    header_columns.remove("page_number")

    df_header_cols = [col for col in data.columns if col in header_columns]
    df_items_cols = [col for col in data.columns if col not in header_columns]

    df_header = data[df_header_cols].drop_duplicates(keep="first")
    if len(df_header.index) > 1:
        raise ValueError("Header data is not unique !")
    df_items = data[df_items_cols]

    return df_header, df_items


def regroup_edited_header_and_items_data(
    header_data: pd.DataFrame,
    items_data: pd.DataFrame,
) -> pd.DataFrame:
    """
    Regroups the header and items DataFrames in a single DataFrame, repeating the
    header data for each item row.

    :param header_data: The user-edited data for the header of the document. It should
        contain a single row
    :type header_data: pd.DataFrame
    :param items_data: The user-edited data for the items.
    :type items_data: pd.DataFrame

    :return: A single DataFrame with the header data repeated for each item row.
    :rtype: pd.DataFrame
    """
    if len(header_data.index) != 1:
        raise ValueError("Headers should only contain a single row !")

    output = items_data.copy()
    for column in header_data.columns:
        output[column] = header_data[column][0]
    return output


def generate_manually_edited_data_df(
    edition_report_header: DataEditor,
    edition_report_items: DataEditor,
    regrouped_data: pd.DataFrame,
    doc_type: Literal["MLV", "SOMMIER"],
) -> pd.DataFrame:
    """
    Generate a DataFrame to keep track of which cells were manually updated.

    The output DataFrame will have the following columns :
    - "_meta_extraction_timestamp"
    - "sous_dum" if ``doc_type`` is "MLV" ; "SOMMIER" if ``doc_type`` is "SOMMIER"
    - "item_number"
    - "modified_column"

    :param edition_report_header: The manually edited rows in the header data
    :type edition_report_header: dict[str, dict[int, dict[str, Any]]]
    :param edition_report_items: The manually edited rows in the items data
    :type edition_report_items: dict[str, dict[int, dict[str, Any]]]
    :param regrouped_data: The DataFrame with the final data to be exported to
        Databricks
    :type regrouped_data: pd.DataFrame
    :param doc_type: The type of document. Must be one of "MLV", "SOMMIER".
    :type doc_type: Literal["MLV", "SOMMIER"]

    :return: A DataFrame with the updated columns and rows
    :rtype: pd.DataFrame
    """
    document_identifying_column = constants.DOC_IDENTIFYING_COLUMN[doc_type]

    if not (
        edition_report_header["edited_rows"]
        or edition_report_items["edited_rows"]
        or edition_report_items["added_rows"]
    ):
        return pd.DataFrame()

    output_data = []

    # register changes from the header data : they should be applied to each item number
    for changed_column in edition_report_header["edited_rows"].get(0, {}).keys():
        for row_index in range(len(regrouped_data.index)):
            output_data.append(
                {
                    "_meta_extraction_timestamp": regrouped_data.at[
                        row_index, "_meta_extraction_timestamp"
                    ],
                    document_identifying_column: regrouped_data.at[
                        row_index, document_identifying_column
                    ],
                    "item_number": regrouped_data.at[row_index, "item_number"],
                    "modified_column": changed_column,
                }
            )

    # register changes from the items data
    for row_index, changed_cells in edition_report_items["edited_rows"].items():
        for changed_column in changed_cells.keys():
            output_data.append(
                {
                    "_meta_extraction_timestamp": regrouped_data.at[
                        row_index, "_meta_extraction_timestamp"
                    ],
                    document_identifying_column: regrouped_data.at[
                        row_index, document_identifying_column
                    ],
                    "item_number": regrouped_data.at[row_index, "item_number"],
                    "modified_column": changed_column,
                }
            )

    # register added rows
    for row_data in edition_report_items["added_rows"]:
        for column in row_data.keys():
            output_data.append(
                {
                    "_meta_extraction_timestamp": row_data[
                        "_meta_extraction_timestamp"
                    ],
                    document_identifying_column: row_data[document_identifying_column],
                    "item_number": row_data["item_number"],
                    "modified_column": column,
                }
            )

    return pd.DataFrame(output_data).drop_duplicates(keep="first", ignore_index=True)


def update_manually_edited_data_table(
    conn: Connection,
    doc_type: Literal["MLV", "SOMMIER"],
    edited_data_df: pd.DataFrame,
    extraction_timestamp: str,
    doc_identifier: str,
) -> None:
    """
    Update the manually edited data table with the contents of the DataFrame.

    - Delete all records from ``table_name`` with the specified ``extraction_timestamp``
      and ``doc_identifier``.
    - If `edited_data_df` is not empty, insert the new rows in the table.

    :param conn: Connection to a remote Databricks SQL warehouse
    :type conn: Connection
    :param doc_type: The document type (MLV or SOMMIER)
    :type doc_type: Literal["MLV", "SOMMIER"]
    :param edited_data_df: DataFrame with the contents to insert in the new table
    :type edited_data_df: pd.DataFrame
    :param extraction_timestamp: The extraction timestamp, used to identify which rows
        to delete
    :type extraction_timestamp: str
    :param doc_identifier: The document identifier ("reference" or "sous_dum", used to
        identify which rows to delete
    :type doc_identifier: str
    """
    identifier_column = constants.DOC_IDENTIFYING_COLUMN[doc_type]
    table_name = dbx_constants.MANUAL_EDITS_TABLES[doc_type]

    # delete previously stored manually updated rows and columns information
    delete_statement = (
        f"DELETE FROM {table_name} "
        f"WHERE _meta_extraction_timestamp == '{extraction_timestamp}' "
        f"AND {identifier_column} == '{doc_identifier}' ;"
    )

    with conn.cursor() as cursor:
        log.debug(delete_statement)
        cursor.execute(delete_statement)

    # insert new manually updated rows and columns information
    if len(edited_data_df.index) > 0:
        columns = ", ".join(edited_data_df.columns)
        rows = list(edited_data_df.itertuples(index=False))
        values = ",".join(
            [
                "("
                + ",".join(
                    (repr(item) if not pd.isnull(item) else "null" for item in row)
                )
                + ")"
                for row in rows
            ]
        )

        insert_statement = f"INSERT INTO {table_name} ({columns}) VALUES {values};"

        with conn.cursor() as cursor:
            log.debug(insert_statement)
            cursor.execute(insert_statement)
