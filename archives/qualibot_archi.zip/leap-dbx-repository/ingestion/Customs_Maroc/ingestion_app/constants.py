"""
This module contains constants definition for the ingestion app
"""

DOC_IDENTIFYING_COLUMN = {
    "MLV (detailled)": "sous_dum",
    "MLV (simplified)": "sous_dum",
    "SOMMIER": "reference",
}

HS_CODE_COLUMN = {
    "MLV (detailled)": "code_march",
    "MLV (simplified)": "code_march",
    "SOMMIER": "nomenclature",
}

MLV_MAIN_TAGS = {
    "MINISTERE": "depot",
    "Déposée": "depot",
    "Clôturée": "depot",
    "A ENREGISTREMENT": "enregistrement",
    "1 DECLARATION": "declaration",
    "4 bureau": "bureau",
    "3 Nombre total\ndes articles": "total_item_count",
    "19 Taux de change": "currency_change",
    "23 Valeur totale déclarée": "total_value_declared",
}

MLV_ITEM_TAGS = {
    "29 N° d'ordre\nde l'art.": "item_number",
    "36 Pays d'origine (Nom et code)": "country_of_origin",
    "31 Valeur déclarée": "value_declared",
    "34 AP ou SP": "ap_sp",
    "designation": "designation",
    "qty": "qty",
    "unit": "unit",
    "30 Code marchandises": "code_march",
}

MLV_HEADER_COLUMNS = [
    "depot",
    "declaration",
    "enregistrement",
    "total_item_count",
    "bureau",
    "currency_change",
    "total_value_declared",
    "reginfo",
    "regnum",
    "reg_date",
    "reg_year",
    "sous_dum",
    "initial_dum",
]

SOMMIER_HEADER_COLUMNS = [
    "pdf_name",
    "page_number",
    "reference",
    "reference_date",
    "state",
    "echeance_date",
    "demandeur",
    "registre",
    "total_value_declared",
]

SOMMIER_TABLE_COLUMNS = [
    "nomenclature",
    "item_number",
    "dec_apurement",
    "dec_apurement_2",
    "dec_apurement_3",
    "quantity",
    "unit",
    "rate",
    "quantity_waste",
    "gross_value",
    "account",
    "apu",
    "date",
]

NON_EDITABLE_COLUMN_NAMES = ["pdf_name", "is_valid"]

NON_EDITABLE_COLUMN_NAMES_PREFIX = "_meta"

OPTIONAL_COLUMNS = [
    "dec_apurement",
    "rate",
    "quantity_waste",
    "account",
    "apu",
    "date",
    "is_valid",
]

SPLIT_DESIGNATION_COLS = [
    "material_number",
    "material_description",
    "delivery_note",
    "invoice",
    "invoice_item"
]
