# Coma ingestion App

This app enables business users to manually ingest .pdf files from the moroccan customs.


## Deployment

### Prerequisites

A configured ``databricks`` CLI is required to deploy the app.

#### Install the CLI

If you do not have it, please follow the [installation instructions](https://docs.databricks.com/aws/en/dev-tools/cli/install).

#### Configure the CLI

Next, follow [the instructions to set up the connection to the Databricks workspace](https://docs.databricks.com/aws/en/dev-tools/cli/tutorial#configure-access-to-your-workspace)

**/!\\** Make sure you are connected to the adequate workspace (dev, uat, prd)

### Deploy the app source code

To deploy the source code, run the following commands :

```commandline
databricks sync leap_utils/ /Workspace/Shared/coma-ingestion-src/leap_utils/ --full
```

```commandline
databricks sync ingestion/Customs_Maroc/ingestion_app/ /Workspace/Shared/coma-ingestion-src/ingestion/Customs_Maroc/ingestion_app/ --full
```

```commandline
databricks sync ingestion/Customs_Maroc/ingestion_app/ /Workspace/Shared/coma-ingestion-src/ --exclude *.py --exclude *.md --exclude .streamlit --full
```

(N.B. : The last command is a bit tricky : we want to put ``ingestion/Customs_Maroc/ingestion_app/app.yml`` and
``ingestion/Customs_Maroc/ingestion_app/requirements.txt`` at the root level of
``/Workspace/Shared/coma-ingestion-src/``. Yet, the command ``databricks sync`` does not allow to send files, only directories ...
_Luckily_, it offers the possibility to exclude file patterns, so that's what we are doing)
