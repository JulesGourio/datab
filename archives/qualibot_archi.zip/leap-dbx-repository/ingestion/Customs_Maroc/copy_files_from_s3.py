# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC **Description:**
# MAGIC The aim is to copy S3 files from leap-depot into the adequate volume in Databricks
# MAGIC
# MAGIC **Output volume(s):**
# MAGIC   - {PIPELINE_WRITE_ENV}_bronze.customs_maroc.input_mlv_pdfs
# MAGIC   - {PIPELINE_WRITE_ENV}_bronze.customs_maroc.input_sommier_pdfs
# MAGIC
# MAGIC **Input(s):**
# MAGIC   - s3://leap-s3-raw-weeu1-{REFERENCE_READ_ENV}/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/mlv
# MAGIC   - s3://leap-s3-raw-weeu1-{REFERENCE_READ_ENV}/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/sommier
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - Scheduled or manual trigger

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import logging
from leap_utils.common.logger import setup_applevel_logger

log = setup_applevel_logger(log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets
# MAGIC

# COMMAND ----------

dbutils.widgets.removeAll()
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")
# Get pipeline environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
# Get read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Process
# MAGIC - The inputs of this notebook are S3 buckets
# MAGIC - The outputs of this notebook are Databricks volumes 

# COMMAND ----------

for file in dbutils.fs.ls(f"s3://leap-s3-raw-weeu1-{REFERENCE_READ_ENV}/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/mlv"):
    dbutils.fs.cp(file.path, f"/Volumes/{PIPELINE_WRITE_ENV}_bronze/customs_maroc/input_mlv_pdfs/{file.name}")
    log.info(f"Copied {file.name} in Databricks volumes")

    dbutils.fs.rm(file.path)
    log.info(f"Removed {file.name} in S3")

for file in dbutils.fs.ls(f"s3://leap-s3-raw-weeu1-{REFERENCE_READ_ENV}/manual/leapdepot/UC38_CUSTOMS_TRACABILITY/sommier"):
    dbutils.fs.cp(file.path, f"/Volumes/{PIPELINE_WRITE_ENV}_bronze/customs_maroc/input_sommier_pdfs/{file.name}")
    log.info(f"Copied {file.name} in Databricks volumes")

    dbutils.fs.rm(file.path)
    log.info(f"Removed {file.name} in S3")
