import logging
import os
from typing import List, Tuple
from datetime import datetime

import pyspark.sql.functions as f
from pyspark.sql import DataFrame

from leap_utils.config import spark
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils
from databricks.sdk.runtime import dbutils

LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)


def is_same_schema(
    old_schema: List[str], new_schema: List[str], metadata_info: List[Tuple[str, str]]
) -> bool:
    """
    Check if two schema are the same after cleaning elements of the second schema.

    :param old_schema: List of column names in the old schema
    :type old_schema: List[str]
    :param new_schema: List of column names in the new schema
    :type new_schema: List[str]
    :return: Whether the schemas are the same or not
    :rtype: bool
    """
    strings_to_remove = [item[0] for item in metadata_info]
    cleaned_new_schema = sorted(
        [table_utils._cleanup_column_name(item) for item in new_schema]
    )
    cleaned_old_schema = sorted(
        [item for item in old_schema if item not in strings_to_remove]
    )
    return cleaned_old_schema == cleaned_new_schema


def move_files(
    source_bucket: str,
    dest_bucket: str,
) -> bool:
    """
    Move files from the source bucket to the destination bucket.

    :param source_bucket: Source bucket path
    :type source_bucket: str
    :param dest_bucket: Destination bucket path
    :type dest_bucket: str
    :return: Whether the files are moved successfully or not
    :rtype: bool
    """
    files = dbutils.fs.ls(f"{source_bucket}")
    if files:
        for file_info in files:
            try:
                filename = os.path.basename(file_info.path)
                source_path = f"{source_bucket}{filename}"
                dest_path = os.path.join(dest_bucket, filename)
                dbutils.fs.mv(source_path, dest_path)
                log.info(f"file : {source_path}  move to {dest_path}")
            except Exception as e:
                log.error(f"Erreur archiving file, error is : {e}")
                raise Exception()

        log.info(f"File {filename} archived to {dest_path}\n--")
    else:
        log.info("No files found in the source directory.")
    return True


def get_last_schema_version(folder_info: List) -> int:
    """
    Get the last schema version from the given folder information.
    Given folder should be where all previous schema are located

    :param folder_info: List of folder information
    :type folder_info: List
    :return: Last schema version
    :rtype: int
    """
    if not folder_info:
        return 0
    df = spark.createDataFrame(folder_info)
    df = df.withColumn("version", f.regexp_extract("name", r"_(\d+)/$", 1).try_cast("int"))
    return df.agg(f.max("version")).collect()[0][0]


def is_one_EDI(edi_s3_folder: str):
    files = dbutils.fs.ls(f"{edi_s3_folder}")
    dates = set()
    if files:
        for file in files:
            date_str = file.name.split("_")[2]
            date_str = date_str[0:8]
            date = datetime.strptime(date_str, "%Y%m%d").date()
            dates.add(date)
    return len(dates) == 1


def get_last_date(df: DataFrame, column: str):
    """
    Get the last date from the specified column in the DataFrame.

    :param df: DataFrame
    :type df: DataFrame
    :param column: Name of the column containing dates
    :type column: str
    :return: Last date
    :rtype: datetime.date
    """
    last_date = df.select(f.max(f.col(column))).collect()[0][0]
    return last_date


def get_last_forecast_edi(df: DataFrame):
    """
    Get the last forecast EDI from the DataFrame based on the EDISnapshotDate.

    :param df: DataFrame
    :type df: DataFrame
    :return: DataFrame containing the last forecast EDI
    :rtype: DataFrame
    """
    last_date = get_last_date(df=df, column="EDISnapshotDate")
    return df.filter(f.col("EDISnapshotDate") == last_date)