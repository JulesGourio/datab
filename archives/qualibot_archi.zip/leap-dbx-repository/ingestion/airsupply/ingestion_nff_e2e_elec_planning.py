# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC Ingest weekly NFF Electrical Planning files from S3 (`NFF_E2E_Elec_Planning_CWXX-YYYY_*.csv`), enrich them with technical metadata (`ingestion_timestamp`, `week`, `year`, `YearMonth`), standardise column names, and persist them into a Delta table with partition overwrite per `YearMonth` (latest file wins).
# MAGIC
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {pipeline_write_env}_bronze.commercial_and_program_demand_management.nff_e2e_elec_planning
# MAGIC
# MAGIC **Input(s) :**  
# MAGIC `s3://leap-s3-raw-weeu1-{pipeline_read_env}/manual/leapdepot/UC4_customer_demand_management/NFF_E2E/NFF_E2E_Elec_Planning_*`

# COMMAND ----------

# MAGIC %md
# MAGIC # Import

# COMMAND ----------

# MAGIC %md
# MAGIC ## Librairies

# COMMAND ----------

import logging
import unicodedata
import re

import pyspark.sql.functions as f
from pyspark.sql.utils import AnalysisException

from leap_utils.common.logger import get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils

LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_read_env", "dev")
pipeline_read_env = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
reference_read_env = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
pipeline_write_env = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("skip_task", "False")
skip_task = dbutils.widgets.get("skip_task").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Constant

# COMMAND ----------

S3_RAW_BASE_PATH = f"s3://leap-s3-raw-weeu1-{pipeline_read_env}"
FOLDER_FILE_PATH = S3_RAW_BASE_PATH + "/manual/leapdepot/UC4_customer_demand_management/NFF_E2E/"

RAW_CSV_FILE_PATTERN = "*NFF_E2E_Elec_Planning_*"

PATH_PATTERN = FOLDER_FILE_PATH + RAW_CSV_FILE_PATTERN

TARGET_TABLE = f"{pipeline_write_env}_bronze.commercial_and_program_demand_management.nff_e2e_elec_planning"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Functions

# COMMAND ----------

def read_raw_files(path_pattern: str):
    df = (
        spark.read.format("csv")
        .option("inferSchema", "true")
        .option("header", "true")
        .option("delimiter", ";")
        .load(path_pattern)
        .withColumn("source_path_full", f.col("_metadata.file_path"))
        .withColumn("source_file", f.col("_metadata.file_name"))
    )
    return df


def enrich_with_metadata(df):
    week_col = f.regexp_extract(
        "source_file", r"CW(\d{2})-(\d{4})", 1
    )
    year_col = f.regexp_extract(
        "source_file", r"CW(\d{2})-(\d{4})", 2
    )

    df = (
        df
        .withColumn("ingestion_timestamp", f.current_timestamp())
        .withColumn("week", week_col.cast("int"))
        .withColumn("year", year_col.cast("int"))
    )

    df = df.withColumn(
        "year_week",
        f.format_string("%04d-W%02d", f.col("year"), f.col("week"))
    )

    return df.drop("week_start")

def clean_column_name(col: str) -> str:
    col = col.replace("�", "a") # file contains â which are in some cases read as �
    col = col.replace("\u00e2", "a").replace("\u00c2", "A")  # replace â/Â by a/A before normalization
    col = unicodedata.normalize("NFKD", col).encode("ascii", "ignore").decode()
    col = col.lower()
    col = col.replace(" ", "_")
    col = re.sub(r"[^a-z0-9_]", "_", col)
    col = re.sub(r"__+", "_", col)
    if not re.match(r"^[a-z_]", col):
        col = "_" + col
    return col


def clean_all_columns(df):
    mapping = {c: clean_column_name(c) for c in df.columns}
    print("[clean_all_columns] mapping:")
    for k, v in mapping.items():
        print(f"  {k} -> {v}")
    return df.select([f.col(c).alias(mapping[c]) for c in df.columns])

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Ingestion

# COMMAND ----------

try:
    df_nff_e2e = spark.read.csv(
        PATH_PATTERN, header=True, sep=";"
    )
except AnalysisException as e:
    log.error(
        f"Path '{FOLDER_FILE_PATH}' does not contain any files."
        f"\n Error is : \n {e}"
    )
    dbutils.notebook.exit("No file in S3 bucket")

# COMMAND ----------

df_raw = read_raw_files(PATH_PATTERN)
df_clean = clean_all_columns(df_raw)
df_enriched = enrich_with_metadata(df_clean).withColumn(
    "msn", f.col("msn").try_cast("int")
)

yearweeks = [
    r["year_week"] for r in df_enriched.select("year_week").distinct().collect()
]
predicate = "year_week IN ({})".format(",".join([f"'{ym}'" for ym in yearweeks]))

print(f"[overwrite_target_partitions] target={TARGET_TABLE}")
print(f"[overwrite_target_partitions] predicate={predicate}")
print(f"[overwrite_target_partitions] rows_in_batch={df_enriched.count()}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Cast to existing schema

# COMMAND ----------

if table_utils.UnityCatalogCheckTableExists(TARGET_TABLE):
    target_schema = {field.name: field.dataType for field in spark.read.table(TARGET_TABLE).schema}
    for col_name in df_enriched.columns:
        if col_name in target_schema:
            df_enriched = df_enriched.withColumn(col_name, f.col(col_name).try_cast(target_schema[col_name]))
    print("[schema_alignment] Columns cast to match existing table schema.")

# COMMAND ----------

# MAGIC %md
# MAGIC # Save Output Table

# COMMAND ----------

if not (table_utils.UnityCatalogCheckTableExists(TARGET_TABLE)):
    table_utils.save_table(dest_table=TARGET_TABLE, df=df_enriched, mode="overwrite")
else:
    table_utils.save_table(
        dest_table=TARGET_TABLE,
        df=df_enriched,
        mode="overwrite",
        replace_where=predicate
    )
    print(
        f"[overwrite_target_partitions] overwritten partitions for YearWeek={yearweeks}"
    )
