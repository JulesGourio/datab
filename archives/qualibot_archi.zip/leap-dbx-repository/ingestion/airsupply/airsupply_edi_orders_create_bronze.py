# Databricks notebook source
# MAGIC %md
# MAGIC # EDI Orders create history change log bronze Table
# MAGIC
# MAGIC **Description:**  
# MAGIC Create the history change log bronze table for EDI orders. In landing zone, we have different stacks of orders. Each stack correspond to a specific schema. This notebook aims to union the stack of orders, create a single table and then process history change log on the single table.
# MAGIC If different stacks have same common column and more or less added column it will work without any user operation.
# MAGIC
# MAGIC **WARNING**: If different stacks (schema) have completely different column name but with same purpose, a manual renaming needs to be done on different stacks.
# MAGIC
# MAGIC
# MAGIC Example 1: Different number of column and same naming
# MAGIC
# MAGIC     - landing_zone.airsupply.orders_stack:
# MAGIC | EDISnapshot| ID        | Quantity     | 
# MAGIC |------------|-----------|--------------|
# MAGIC | 2023-01-01 | P001      | 10           | 
# MAGIC | 2023-01-02 | P002      | 5            |
# MAGIC
# MAGIC     - landing_zone.airsupply.orders_stack_0:
# MAGIC
# MAGIC | EDISnapshot| ID        | Quantity        | AddedColumn|
# MAGIC |------------|-----------|-----------------|------------|
# MAGIC | 2024-01-01 | P001      | 50              | 1000.00    |
# MAGIC | 2024-01-02 | P002      | 30              | 900.00     |
# MAGIC
# MAGIC     The result single table will be:
# MAGIC | EDISnapshot| ID        | Quantity        | AddedColumn|
# MAGIC |------------|-----------|-----------------|------------|
# MAGIC | 2023-01-01 | P001      | 10              | NULL
# MAGIC | 2023-01-02 | P002      | 5               | NULL
# MAGIC | 2024-01-01 | P001      | 50              | 1000.00    |
# MAGIC | 2024-01-02 | P002      | 30              | 900.00     |
# MAGIC
# MAGIC Example 2: Different number of column and different naming
# MAGIC
# MAGIC     - landing_zone.airsupply.orders_stack:
# MAGIC | EDISnapshot| ID        | Quantity     | 
# MAGIC |------------|-----------|--------------|
# MAGIC | 2023-01-01 | P001      | 10           | 
# MAGIC | 2023-01-02 | P002      | 5            |
# MAGIC
# MAGIC     - landing_zone.airsupply.orders_stack_0:
# MAGIC
# MAGIC | Date       | ID        | QTY             | AddedColumn|      
# MAGIC |------------|-----------|-----------------|------------|
# MAGIC | 2024-01-01 | P001      | 50              | 1000.00    |
# MAGIC | 2024-01-02 | P002      | 30              | 900.00     |
# MAGIC
# MAGIC User needs to rename Date to EDISnapshot and QTY to Quantity to match the union.
# MAGIC
# MAGIC     IF RENAMING The result single table will be:
# MAGIC | EDISnapshot| ID        | Quantity        | AddedColumn|
# MAGIC |------------|-----------|-----------------|------------|
# MAGIC | 2023-01-01 | P001      | 10              | NULL
# MAGIC | 2023-01-02 | P002      | 5               | NULL
# MAGIC | 2024-01-01 | P001      | 50              | 1000.00    |
# MAGIC | 2024-01-02 | P002      | 30              | 900.00     |
# MAGIC
# MAGIC **Widget(s):**
# MAGIC - new_schema (default: False) -> When new schema is coming for first time, widget needs to be specified to True to recompute FULL history change log.
# MAGIC - force_reinitialization (default: False) -> If user wants to force reinitialize, the FULL history change log will be recompute.
# MAGIC - skip_task (default: False) -> If user wants to skip task without failing entire job, set skip_task to True
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).
# MAGIC
# MAGIC **Output table(s):** 
# MAGIC - {pipeline_write_env}_bronze.airsupply.airsupply_edi_orders_history_change_log
# MAGIC
# MAGIC **Input(s) :**  
# MAGIC ALL stack tables contain in landing_zone
# MAGIC - {pipeline_read_env}_landingzone.airsupply.orders_stack_....
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC TODO: create job

# COMMAND ----------

# MAGIC %md
# MAGIC # Import

# COMMAND ----------

# MAGIC %md
# MAGIC ## Libraries

# COMMAND ----------

import re
import os
import logging
import time
import datetime
from typing import List, Tuple

import pyspark.sql.functions as f
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from pyspark.sql.types import StructType

from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils, history_changelog
from leap_utils.ingestion import ingestion_utils
from ingestion.airsupply import airsupply_ingestion_utils

LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.text("new_schema", "False")
new_schema = dbutils.widgets.get("new_schema").lower() == "true"

dbutils.widgets.text("pipeline_read_env", "dev")
pipeline_read_env = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
reference_read_env = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
pipeline_write_env = dbutils.widgets.get("pipeline_write_env")


dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = dbutils.widgets.get("force_reinitialization").lower() == "true"

dbutils.widgets.text("skip_task", "False")
skip_task = dbutils.widgets.get("skip_task").lower() == "true"

# COMMAND ----------

if skip_task:
    dbutils.notebook.exit("skip task")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Hard coded variable

# COMMAND ----------

LANDING_ZONE_DEST_TABLE = f"{pipeline_write_env}_landingzone.airsupply.orders_stack"
LANDING_ZONE_DATABASE = f"{pipeline_write_env}_landingzone.airsupply"
LANDING_ZONE_DEST_TABLE_NAME = "orders_stack"

orders_latest = f"{pipeline_write_env}_bronze.airsupply.airsupply_edi_orders_latest"
orders_history = f"{pipeline_write_env}_bronze.commercial_and_program_demand_management.airsupply_edi_orders"

# COMMAND ----------

# MAGIC %md
# MAGIC # Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Union all stacks table

# COMMAND ----------

catalog_lz = f"{pipeline_write_env}_landingzone"
schema_lz = "airsupply"
dest_catalog = f"{pipeline_write_env}_bronze"
dest_schema = "commercial_and_program_demand_management"
view_name = "airsupply_edi_orders_history_view"

df_table_names = spark.sql(f"SHOW TABLES IN {catalog_lz}.{schema_lz}")
table_names = [
    row.tableName
    for row in df_table_names.collect()
    if row.tableName.startswith("orders_stack")
]

merged_schema = StructType()
column_to_drop = "PO_OriginalComment"

for table in table_names:
    current_schema  = spark.table(f"{catalog_lz}.{schema_lz}.{table}").schema
    for field in current_schema:
        if field.name not in [f.name for f in merged_schema] and field.name != column_to_drop:
            merged_schema.add(field)

log.info(f"the schema of the table is : {merged_schema}")
df_union = spark.createDataFrame([], merged_schema)

for table_name in table_names:
    df = spark.read.table(f"{catalog_lz}.{schema_lz}.{table_name}")
    if table_name == "orders_stack_1" or table_name =="order_stack_0":
        df.withColumnRenamed("PO_OriginalComment", "PO_CustomerComment")
    df_union = df_union.unionByName(df, allowMissingColumns=True)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create history change log

# COMMAND ----------

def process_table(table_name: str, df_table_stack: DataFrame) -> str:
    """
    process ingestion of a table
    return {output_table_path} if ok, or None if not
    """
    startTime = time.time()

    Unity_Catalog_Table_Name = f"{table_name.lower()}_history_change_log"
    history_change_log_table_path = Unity_Catalog_Table_Name

    # get the first_existing_timestamp_of_extraction
    first_existing_timestamp_of_extraction_in_stack = df_table_stack.select(
        f.min("EDISnapshotDate")
    ).first()["min(EDISnapshotDate)"]
    log.info(
        f"the first timestamp in Stack table is : {first_existing_timestamp_of_extraction_in_stack}"
    )

    # get the last_existing_timestamp_of_extraction
    last_existing_timestamp_of_extraction_in_stack = df_table_stack.select(
        f.max("EDISnapshotDate")
    ).first()["max(EDISnapshotDate)"]
    log.info(
        f"the last timestamp in Stack table is : {last_existing_timestamp_of_extraction_in_stack}"
    )

    # if history_change_log_table already exists and FORCE_REINITIALIZATION == False and FORCE_CHANGELOG_REINITIALIZATION == False then history_change_log_table processed with needed stacks only
    # else history_change_log_table processed with full stack method
    if (
        (table_utils.UnityCatalogCheckTableExists(history_change_log_table_path))
        and (not new_schema)
        and (not FORCE_REINITIALIZATION)
    ):
        log.info(
            f"Computing the DELTA history changelog table {Unity_Catalog_Table_Name}"
        )

        # Read existing history_change_log_table
        df_table_history = spark.read.table(history_change_log_table_path)

        # get the last_existing_timestamp in history_change_log_table
        last_existing_timestamp_in_history_change_log = df_table_history.select(
            f.max("EDISnapshotDate")
        ).first()["max(EDISnapshotDate)"]

        log.info(
            f"the last timestamp in history changelog table is : {last_existing_timestamp_in_history_change_log}"
        )

        # Do processing only if changes are detected in stack
        if (
            last_existing_timestamp_of_extraction_in_stack
            > last_existing_timestamp_in_history_change_log
        ):

            # Filter stack table with needed extraction_timestamps
            df_table_stack_from_last_run_to_current_date = df_table_stack.filter(
                (
                    df_table_stack.EDISnapshotDate
                    > last_existing_timestamp_in_history_change_log
                )
            )

            df_history_final = history_changelog.calculate_history_changelog_delta_update(
                df=df_table_stack_from_last_run_to_current_date,
                df_existing_history_changelog=df_table_history,
                id_column_list=["PO_PoNumber", "PO_PosNumber"],
                sort_column="EDISnapshotDate",
                tracked_column_list=df_table_stack_from_last_run_to_current_date.columns,
                data_extraction_mode="DELTA",
                calculate_discontinuities=False,
                allow_duplicate=True,
                duplicate_sorting=["PO_UpdateVersion"],
            )

        else:
            log.info(f"the table {Unity_Catalog_Table_Name} is already up to date")
            return f"{Unity_Catalog_Table_Name}"

    else:
        # Below the computation of the full history table
        log.info(
            f"Computing the FULL history changelog table {Unity_Catalog_Table_Name}"
        )

        df_history_final = history_changelog.initialize_history_changelog(
            df=df_table_stack,
            id_column_list=["PO_PoNumber", "PO_PosNumber"],
            sort_column="EDISnapshotDate",
            tracked_column_list=df_table_stack.columns,
            data_extraction_mode="DELTA",
            calculate_discontinuities=False,
            allow_duplicate=True,
            duplicate_sorting=["PO_UpdateVersion"],
        )

    # Save history table
    try:
        result = table_utils.save_table(
            dest_table=history_change_log_table_path,
            df=df_history_final,
            mode="overwrite",
            overwrite_schema=True,
            merge_schema=True,
        )
    except AnalysisException as e:
        log.error(
            f"Table {history_change_log_table_path} has not been created, an error occured during creation."
        )
        return None
    else:
        duration = time.time() - startTime
        log.info(
            f"Table {history_change_log_table_path} created in {duration} seconds."
        )
        return df_history_final

# COMMAND ----------

table_name = orders_history
df_stack = LANDING_ZONE_DEST_TABLE
df = process_table(table_name, df_union)

# COMMAND ----------


