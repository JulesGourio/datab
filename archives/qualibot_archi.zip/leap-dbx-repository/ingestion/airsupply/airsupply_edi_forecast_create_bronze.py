# Databricks notebook source
# MAGIC %md
# MAGIC # EDI forecast create bronze Table
# MAGIC
# MAGIC **Description:**  
# MAGIC Create the bronze table view for EDI forecast. In landing zone, we have different stacks of forecast. Each stack correspond to a specific schema. This notebook aims to union the stack of forecast and create a single view table that contains all data.
# MAGIC If different stacks have same common column and more or less added column it will work without any user operation.
# MAGIC
# MAGIC **WARNING**: If different stacks (schema) have completely different column name but with same purpose, a manual renaming needs to be done on different stacks.
# MAGIC
# MAGIC
# MAGIC Example 1: Different number of column and same naming
# MAGIC
# MAGIC     - landing_zone.airsupply.forecast_stack:
# MAGIC | EDISnapshot| ID        | Quantity     | 
# MAGIC |------------|-----------|--------------|
# MAGIC | 2023-01-01 | P001      | 10           | 
# MAGIC | 2023-01-02 | P002      | 5            |
# MAGIC
# MAGIC     - landing_zone.airsupply.forecast_stack_0:
# MAGIC
# MAGIC | EDISnapshot| ID        | Quantity        | AddedColumn|
# MAGIC |------------|-----------|-----------------|------------|
# MAGIC | 2024-01-01 | P001      | 50              | 1000.00    |
# MAGIC | 2024-01-02 | P002      | 30              | 900.00     |
# MAGIC
# MAGIC     The result single table view will be:
# MAGIC | EDISnapshot| ID        | Quantity        | AddedColumn|
# MAGIC |------------|-----------|-----------------|------------|
# MAGIC | 2023-01-01 | P001      | 10              | NULL
# MAGIC | 2023-01-02 | P002      | 5               | NULL
# MAGIC | 2024-01-01 | P001      | 50              | 1000.00    |
# MAGIC | 2024-01-02 | P002      | 30              | 900.00     |
# MAGIC
# MAGIC Example 2: Different number of column and different naming
# MAGIC
# MAGIC     - landing_zone.airsupply.forecast_stack:
# MAGIC | EDISnapshot| ID        | Quantity     | 
# MAGIC |------------|-----------|--------------|
# MAGIC | 2023-01-01 | P001      | 10           | 
# MAGIC | 2023-01-02 | P002      | 5            |
# MAGIC
# MAGIC     - landing_zone.airsupply.forecast_stack_0:
# MAGIC
# MAGIC | Date       | ID        | QTY             | AddedColumn|      
# MAGIC |------------|-----------|-----------------|------------|
# MAGIC | 2024-01-01 | P001      | 50              | 1000.00    |
# MAGIC | 2024-01-02 | P002      | 30              | 900.00     |
# MAGIC
# MAGIC User needs to rename Date to EDISnapshot and QTY to Quantity to match the union.
# MAGIC
# MAGIC     IF RENAMING The result single view table will be:
# MAGIC | EDISnapshot| ID        | Quantity        | AddedColumn|
# MAGIC |------------|-----------|-----------------|------------|
# MAGIC | 2023-01-01 | P001      | 10              | NULL
# MAGIC | 2023-01-02 | P002      | 5               | NULL
# MAGIC | 2024-01-01 | P001      | 50              | 1000.00    |
# MAGIC | 2024-01-02 | P002      | 30              | 900.00     |
# MAGIC
# MAGIC **Widget(s):**
# MAGIC - skip_task (default: False) -> If user wants to skip task without failing entire job, set skip_task to True
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).
# MAGIC
# MAGIC **Output table(s):** 
# MAGIC - {pipeline_write_env}_bronze.airsupply.edi_airsupply_forecast_history_view
# MAGIC - {pipeline_write_env}_bronze.airsupply.edi_airsupply_forecast_latest
# MAGIC
# MAGIC **Input(s) :**  
# MAGIC ALL stack tables contain in landing_zone
# MAGIC - {pipeline_read_env}_landingzone.airsupply.forecast_stack_....
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC TODO: create job

# COMMAND ----------

# MAGIC %md
# MAGIC # Import
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Libraries

# COMMAND ----------

import logging

import pyspark.sql.functions as f
from pyspark.sql.utils import AnalysisException

from leap_utils.common.logger import get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils
from ingestion.airsupply import airsupply_ingestion_utils

LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_read_env", "dev")
pipeline_read_env = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
reference_read_env = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
pipeline_write_env = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("skip_task", "False")
skip_task = dbutils.widgets.get("skip_task").lower() == "true"

# COMMAND ----------

if skip_task:
    dbutils.notebook.exit("Skip Task")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Hard coded variable

# COMMAND ----------

LANDING_ZONE_DEST_TABLE = f"{pipeline_write_env}_landingzone.airsupply.forecast_stack"
LANDING_ZONE_DATABASE = f"{pipeline_write_env}_landingzone.airsupply"
LANDING_ZONE_DEST_TABLE_NAME = "forecast_stack"

forecast_latest = f"{pipeline_write_env}_bronze.commercial_and_program_demand_management.edi_airsupply_forecast_latest"

# COMMAND ----------

# MAGIC %md
# MAGIC # Import

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import - Leap Table

# COMMAND ----------

df_forecast_stack = spark.read.table(LANDING_ZONE_DEST_TABLE)

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP table view forecast history

# COMMAND ----------

catalog_lz = f"{pipeline_write_env}_landingzone"
schema_lz = "airsupply"
dest_catalog = f"{pipeline_write_env}_bronze"
dest_schema = "commercial_and_program_demand_management"
view_name = "edi_airsupply_forecast_history_view"

# Get table names from the source schema
df_table_names = spark.sql(f"SHOW TABLES IN {catalog_lz}.{schema_lz}")
table_names = [
    row.tableName
    for row in df_table_names.collect()
    if row.tableName.startswith("forecast_stack")
]

# get biggest schema
all_table_schemas = {}
for table in table_names:
    all_table_schemas[table] = spark.table(f"{catalog_lz}.{schema_lz}.{table}").schema
sorted_schemas = sorted(all_table_schemas.values(), key=lambda x: len(x), reverse=True)
biggest_schema = sorted_schemas[0]

# Generate SQL to select data from each table with adjusted schemas
select_queries = []
for table in table_names:
    table_schema = spark.table(f"{catalog_lz}.{schema_lz}.{table}").schema
    adjusted_cols = []
    for f in biggest_schema:
        if f.name not in [col.name for col in table_schema]:
            adjusted_cols.append(f"NULL AS {f.name}")
        else:
            adjusted_cols.append(f.name)
    select_query = (
        f"SELECT {', '.join(adjusted_cols)} FROM {catalog_lz}.{schema_lz}.{table}"
    )
    select_queries.append(select_query)

# Concatenate select queries with UNION
union_query = " UNION ".join(select_queries)

# Create or replace the view using SQL in the destination schema
view_query = (
    f"CREATE OR REPLACE VIEW {dest_catalog}.{dest_schema}.{view_name} AS {union_query}"
)
spark.sql(view_query)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Leap latest table

# COMMAND ----------

df_forecast_latest = airsupply_ingestion_utils.get_last_forecast_edi(
    df=df_forecast_stack
)
try:
    table_utils.save_table(
        dest_table=forecast_latest, df=df_forecast_latest, mode="overwrite"
    )
except AnalysisException as e:
    log.error(
        f"Table {forecast_latest} has not been created, an error occured during creation."
        f"\n Error is : \n {e}"
    )
    raise e

# COMMAND ----------


