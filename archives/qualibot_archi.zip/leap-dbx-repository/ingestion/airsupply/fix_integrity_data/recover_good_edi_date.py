# Databricks notebook source
import pyspark.sql.functions as f
import re
import os

# COMMAND ----------

dbutils.widgets.text("pipeline_read_env", "dev")
pipeline_read_env = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
reference_read_env = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
pipeline_write_env = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

S3_RAW_BASE_PATH = f"s3://leap-s3-raw-weeu1-{pipeline_read_env}"
EDI_ORDERS_FOLDER_PATH = S3_RAW_BASE_PATH + "/apps/airsupply/IS_order"

FILE_PATH_BASE = f"{EDI_ORDERS_FOLDER_PATH}"
DEST_ARCHIVES_BUCKET = f"{S3_RAW_BASE_PATH}/archive/apps/airsupply/IS_order/"

RAW_CSV_FILE_PATTERN_RECOVER_LIST = [
    r"IS_SO-OrdersOverview_20240131.*\.csv$",
    r"IS_SO-OrdersOverview_20240527.*\.csv$",
]

# COMMAND ----------

i = 0
for pattern_csv in RAW_CSV_FILE_PATTERN_RECOVER_LIST:
    all_files = dbutils.fs.ls(FILE_PATH_BASE)
    matching_files = [
        (f.path, f.name) for f in all_files if re.match(pattern_csv, f.name)
    ]
    full_matching_files = [
        infos_matching_file[0] for infos_matching_file in matching_files
    ]
    print(full_matching_files)
    if not matching_files:
        print(f"no file in {FILE_PATH_BASE} that match pattern {pattern_csv}")
        continue
    try:
        df_orders = spark.read.csv(full_matching_files, header=True, sep=";")
    except:
        print(f"Can't read file in {full_matching_files}")
        continue
    print(df_orders.count())
    # ADD EDI SnapshotDate
    date_pattern = r"(\d{4})(\d{2})(\d{2})"
    match = re.search(date_pattern, pattern_csv)
    if match:
        date_extracted = f"{match.group(1)}-{match.group(2)}-{match.group(3)}"
        date_extracted_edi_name = f"{match.group(1)}{match.group(2)}{match.group(3)}"
    else:
        raise Exception("no date in pattern")

    df_orders = df_orders.withColumn(
        "EDISnapshotDate", f.to_date(f.lit(date_extracted), "yyyy-MM-dd")
    )

    df_orders_converted = df_orders.withColumn(
        "PO_LineLastMod", f.to_date(f.col("PO_LineLastMod"), "yyyyMMddHHmmss")
    )
    df_orders_converted = df_orders_converted.withColumn(
        "supposed_edi_date", f.date_add(f.col("PO_LineLastMod"), 1)
    )
    df_orders_with_diff = df_orders_converted.withColumn(
        "diff_edi_day", f.datediff(f.col("EDISnapshotDate"), f.col("PO_LineLastMod"))
    )
    df_to_split = df_orders_with_diff.filter(f.col("diff_edi_day") > 3)
    df_unchanged = df_orders_converted.filter(
        f.datediff(f.col("EDISnapshotDate"), f.col("PO_LineLastMod")) <= 3
    )
    df_unchanged = df_unchanged.drop(
        "supposed_edi_date", "diff_edi_day", "EDISnapshotDate"
    )
    unfiltered_output_path = (
        f"{FILE_PATH_BASE}/IS_SO-OrdersOverview_{date_extracted_edi_name}.csv"
    )
    df_unchanged.toPandas().to_csv(unfiltered_output_path, index=False, sep=";")
    print(f"unchanged : {df_unchanged.count()}")
    tot_count = 0
    distinct_dates = df_to_split.select("supposed_edi_date").distinct().collect()
    for row in distinct_dates:
        date_value = row["supposed_edi_date"]
        df_date_filtered = df_to_split.filter(f.col("supposed_edi_date") == date_value)
        df_date_filtered = df_date_filtered.drop(
            "supposed_edi_date", "diff_edi_day", "EDISnapshotDate"
        )
        print(f"{date_value}: {df_date_filtered.count()}")
        tot_count += df_date_filtered.count()
        date_str = date_value.strftime("%Y%m%d")
        output_path = f"{FILE_PATH_BASE}/IS_SO-OrdersOverview_{date_str}{i}.csv"
        pdf_date_filtered = df_date_filtered.toPandas()
        # Save to CSV file
        pdf_date_filtered.to_csv(output_path, index=False, sep=";")
    print(tot_count)
    i += 1
    for file_infos in matching_files:
        try:
            source_path = file_infos[0]
            dest_path = os.path.join(
                DEST_ARCHIVES_BUCKET, f"compromised_data/{file_infos[1]}"
            )
            dbutils.fs.mv(source_path, dest_path)
            print(f"file : {source_path}  move to {dest_path}")
        except Exception as e:
            print(f"Erreur archiving file, error is : {e}")
            raise Exception()
