# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC Ingestion of EDI forecast raw csv files located in 's3://leap-s3-raw-weeu1-dev/airsupply/IS_forecast/'. 
# MAGIC
# MAGIC This notebook handle different usecases:
# MAGIC - Incoming csv schemas are the same as latest forecast EDI schema:
# MAGIC   - COPY INTO newest file into _landing.airsupply.forecast_stack
# MAGIC   - Move raw file to folder 's3://leap-s3-raw-weeu1-dev/archive/apps/airsupply/IS_forecast/schema_n/' avec n = actuel schema version
# MAGIC
# MAGIC - Incoming csv schemas are different from latest forecast EDI schema:
# MAGIC   - Raise Exception to inform LEAP Team that schema changed
# MAGIC
# MAGIC   - LEAP TEAM can rerun notebook: (Activate widget new_schema == "True")
# MAGIC     - Create New Schema:
# MAGIC       - Rename _landing_zone.airsupply.forecast_stack to _landing_zone.airsupply.forecast_stack{schema_number}
# MAGIC       - Create new _landing_zone.airsupply.forecast_stack with new schema
# MAGIC       - COPY INTO newest files into _landing_zone.airsupply.forecast_stack with new columns from new schema
# MAGIC       -  Creation of new archives schema folder: Move raw file to folder 's3://leap-s3-raw-weeu1-dev/archive/apps/airsupply/IS_forecast/schema_n+1/' avec n = actuel schema version
# MAGIC
# MAGIC **Widget(s):**
# MAGIC - new_schema (default: False) -> If user accept new schema and widget is set to True, the process describe above will run.
# MAGIC - multiple_EDI (default: False) -> By default, pipeline should process one EDI date by one EDI. There is the possibility to handle multiple EDI if multiple_EDI is set to True.
# MAGIC - force_reinitialization (default: False) -> If user wants to force reinitialization of landing zone stacks table with incoming data. It will delete all orders_stack and write a new one with incoming data 
# MAGIC - skip_task (default: False) -> If user wants to skip task without failing entire job, set skip_task to True
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {pipeline_write_env}_landingzone.airsupply.forecast_stack
# MAGIC - (OPTIONNAL) {pipeline_write_env}_landingzone.airsupply.forecast_stack{schema_number} IF New Schema
# MAGIC
# MAGIC **Input(s) :**  
# MAGIC s3://leap-s3-raw-weeu1-dev/apps/airsupply/IS_forecast/file_arrival/'
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC TODO: create job
# MAGIC
# MAGIC **Things to do:** 
# MAGIC - Find way to move files in S3 faster

# COMMAND ----------

# MAGIC %md
# MAGIC # Import

# COMMAND ----------

# MAGIC %md
# MAGIC ## Librairies

# COMMAND ----------

import logging

import pyspark.sql.functions as f
from pyspark.sql.utils import AnalysisException

from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils
from leap_utils.ingestion import ingestion_utils
from ingestion.airsupply import airsupply_ingestion_utils

LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.text("new_schema", "False")
new_schema = dbutils.widgets.get("new_schema").lower() == "true"

dbutils.widgets.text("pipeline_read_env", "dev")
pipeline_read_env = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
reference_read_env = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
pipeline_write_env = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = dbutils.widgets.get("force_reinitialization").lower() == "true"

dbutils.widgets.text("multiple_EDI", "False")
MULTIPLE_EDI = dbutils.widgets.get("multiple_EDI").lower() == "true"

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.text("skip_task", "False")
skip_task = dbutils.widgets.get("skip_task").lower() == "true"

# COMMAND ----------

if skip_task:
    dbutils.notebook.exit("skip task")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Constant

# COMMAND ----------

S3_RAW_BASE_PATH = f"s3://leap-s3-raw-weeu1-{pipeline_read_env}"
EDI_FORECAST_FOLDER_PATH = S3_RAW_BASE_PATH + "/apps/airsupply/IS_forecast"

FILE_PATH_BASE = f"{EDI_FORECAST_FOLDER_PATH}/"
DEST_ARCHIVES_BUCKET = f"{S3_RAW_BASE_PATH}/archive/apps/airsupply/IS_forecast/"

LANDING_ZONE_DEST_TABLE = f"{pipeline_write_env}_landingzone.airsupply.forecast_stack"
LANDING_ZONE_DATABASE = f"{pipeline_write_env}_landingzone.airsupply"
LANDING_ZONE_DEST_TABLE_NAME = "forecast_stack"

forecast_latest = f"{pipeline_write_env}_bronze.airsupply.edi_airsupply_forecast_latest"

RAW_CSV_FILE_PATTERN = "'IS_SO-ForecastOverview_*'"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tables

# COMMAND ----------

try:
    df_forecast_new_arrival = spark.read.csv(
        FILE_PATH_BASE + "IS_SO-ForecastOverview_*", header=True, sep=";"
    )
except AnalysisException as e:
    log.error(
        f"Path '{FILE_PATH_BASE}/IS_SO-ForecastOverview_*' does not contain any files."
        f"\n Error is : \n {e}"
    )
    dbutils.notebook.exit("No file in S3 bucket")

# COMMAND ----------

metadata_statement = [
    {
        "selection_expression": "_metadata.file_name",
        "alias_name": "OriginalFileSource",
        "schema_type": "string",
    },
    {
        "selection_expression": "_metadata.file_path",
        "alias_name": "OriginalFilePath",
        "schema_type": "string",
    },
    {
        "selection_expression": "current_timestamp()",
        "alias_name": "ingestion_timestamp",
        "schema_type": "TIMESTAMP",
    },
    {
        "selection_expression": "split_part(_metadata.file_name, '_', 3)",
        "alias_name": "EDISnapshotRaw",
        "schema_type": "string",
    },
    {
        "selection_expression": "to_date(substring(split_part(_metadata.file_name, '_', 3) from 1 for 8), 'yyyyMMdd')",
        "alias_name": "EDISnapshotDate",
        "schema_type": "DATE",
    },
    {
        "selection_expression": "CONCAT(_metadata.file_name, '_', ROW_NUMBER() OVER (PARTITION BY _metadata.file_name ORDER BY (SELECT NULL)))",
        "alias_name": "BronzeUID",
        "schema_type": "string",
    },
]
metadata_info = [
    (f"{dict_info['alias_name']}", f"{dict_info['schema_type']}")
    for dict_info in metadata_statement
]

format_options = {
    "header": "True",
    "delimiter": ";",
    "mode": "PERMISSIVE",
    "escape": '"',
    "quote": '"',
}

# COMMAND ----------

# MAGIC %md
# MAGIC ## Checks on multiple EDI

# COMMAND ----------

if not airsupply_ingestion_utils.is_one_EDI(FILE_PATH_BASE):
    if MULTIPLE_EDI:
        log.info("Pipeline running on multiple EDI")
    else:
        raise Exception(f"Multiple EDI in {FILE_PATH_BASE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Main Run

# COMMAND ----------

split_dest_table = LANDING_ZONE_DEST_TABLE.lower().split(".")
STACK_CATALOG = split_dest_table[0]
STACK_DOMAIN = split_dest_table[1]
unity_catalog_table_name = split_dest_table[2]

version_number = airsupply_ingestion_utils.get_last_schema_version(
    dbutils.fs.ls(DEST_ARCHIVES_BUCKET)
)
if (
    table_utils.UnityCatalogCheckTableExists(LANDING_ZONE_DEST_TABLE)
    and not FORCE_REINITIALIZATION
):
    df_forecast_stack_actual = spark.read.table(LANDING_ZONE_DEST_TABLE)
    if airsupply_ingestion_utils.is_same_schema(
        old_schema=df_forecast_stack_actual.columns,
        new_schema=df_forecast_new_arrival.columns,
        metadata_info=metadata_info,
    ):
        log.info("Incoming Schema matches with latest schema - COPY INTO new files")
        df = ingestion_utils.copy_into(
            output_stack_database=LANDING_ZONE_DATABASE,
            output_stack_table_name=LANDING_ZONE_DEST_TABLE_NAME,
            columns_selection=df_forecast_new_arrival.columns,
            s3_path=FILE_PATH_BASE + "IS_SO-ForecastOverview_*",
            metadata=metadata_statement,
            format_options=format_options,
        )
        DEST_ARCHIVES_BUCKET_VERSIONNED = (
            f"{DEST_ARCHIVES_BUCKET}SCHEMA_{version_number}"
        )
        airsupply_ingestion_utils.move_files(
            source_bucket=FILE_PATH_BASE, dest_bucket=DEST_ARCHIVES_BUCKET_VERSIONNED
        )
    else:
        log.info("Incoming schema mismatches with latest schema")
        if not new_schema:
            strings_to_remove = {item[0] for item in metadata_info}
            new_schema_cleaned = [
                table_utils._cleanup_column_name(item)
                for item in df_forecast_new_arrival.columns
            ]
            removed_items = set(df_forecast_stack_actual.columns).difference(
                strings_to_remove
            ) - set(new_schema_cleaned)
            added_items = set(new_schema_cleaned) - set(
                df_forecast_stack_actual.columns
            ).difference(strings_to_remove)
            raise Exception(
                f"""
Schema are not the same, here is the list of different column : \n
Columns removed in new schema : {removed_items}  \n
Columns added in new schema : {added_items} 
                            """
            )
        else:
            log.info("Creation of new table with new schema")
            DEST_ARCHIVES_BUCKET_VERSIONNED = (
                f"{DEST_ARCHIVES_BUCKET}SCHEMA_{version_number + 1}"
            )
            schema_version_number = airsupply_ingestion_utils.get_last_schema_version(
                dbutils.fs.ls(DEST_ARCHIVES_BUCKET)
            )
            # move stack to stack_{n} in landing_zone
            spark.sql(
                f"ALTER TABLE {LANDING_ZONE_DEST_TABLE} RENAME TO {LANDING_ZONE_DEST_TABLE}_{schema_version_number}"
            )
            df = ingestion_utils.copy_into(
                output_stack_database=LANDING_ZONE_DATABASE,
                output_stack_table_name=LANDING_ZONE_DEST_TABLE_NAME,
                columns_selection=df_forecast_new_arrival.columns,
                s3_path=FILE_PATH_BASE + "IS_SO-ForecastOverview_*",
                file_format="CSV",
                metadata=metadata_statement,
                format_options=format_options,
            )
            airsupply_ingestion_utils.move_files(
                source_bucket=FILE_PATH_BASE,
                dest_bucket=DEST_ARCHIVES_BUCKET_VERSIONNED,
            )
else:
    log.info("First run of notebook - Initialisation of tables")
    if FORCE_REINITIALIZATION:
        log.info("Force reinitialization of tables")
        df_table_names = spark.sql(f"SHOW TABLES IN {LANDING_ZONE_DATABASE}")
        table_names = [
            row.tableName
            for row in df_table_names.collect()
            if row.tableName.startswith("forecast_stack")
        ]
        for table_name in table_names:
            table_full_name = f"{LANDING_ZONE_DATABASE}.{table_name}"
            log.info(f"Deleting table: {table_full_name}")
            spark.sql(f"DROP TABLE IF EXISTS {table_full_name}")

    df = ingestion_utils.copy_into(
        output_stack_database=LANDING_ZONE_DATABASE,
        output_stack_table_name=LANDING_ZONE_DEST_TABLE_NAME,
        columns_selection=df_forecast_new_arrival.columns,
        s3_path=FILE_PATH_BASE + "IS_SO-ForecastOverview_*",
        file_format="CSV",
        metadata=metadata_statement,
        format_options=format_options,
    )
    DEST_ARCHIVES_BUCKET_VERSIONNED = f"{DEST_ARCHIVES_BUCKET}SCHEMA_{version_number}"
    airsupply_ingestion_utils.move_files(
        source_bucket=FILE_PATH_BASE, dest_bucket=DEST_ARCHIVES_BUCKET_VERSIONNED
    )

# COMMAND ----------

row = df.collect()[0]
formatted_string = (
    f"Number of affected rows: {row['num_affected_rows']}, "
    f"Number of inserted rows: {row['num_inserted_rows']}, "
    f"Number of skipped corrupt files: {row['num_skipped_corrupt_files']}"
)
log.info(formatted_string)
