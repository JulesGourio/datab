# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # GENERIC TABLE INGESTION PIPELINE (SDP Version)
# MAGIC
# MAGIC **Description:**
# MAGIC Creates landingzone and bronze tables for each table defined in the pilotage table.
# MAGIC This version uses **Spark Declarative Pipelines (SDP)** instead of DLT.
# MAGIC
# MAGIC **Supported File Formats:**
# MAGIC - CSV
# MAGIC - PARQUET
# MAGIC - XML (requires spark-xml library on classic clusters)
# MAGIC
# MAGIC **Sample Output Tables:**
# MAGIC - `{pipeline_write_env}_landingzone.{target_schema}.{tablename}_stack`
# MAGIC - `{pipeline_write_env}_bronze.{target_schema}.{tablename}_stack` (optional)
# MAGIC - `{pipeline_write_env}_bronze.{target_schema}.{tablename}_latest`

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Standard Package Imports

# COMMAND ----------

from pyspark import pipelines as dp
import pyspark.sql.functions as f
from pyspark.sql import DataFrame
from functools import reduce
from typing import Dict, Any

# COMMAND ----------

# MAGIC %md
# MAGIC ## LEAP Function Imports

# COMMAND ----------

# Add bundle_root to sys.path for leap_utils imports (when running from Asset Bundle)
import sys
bundle_root = spark.conf.get("bundle_root", "")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger
from leap_utils.ingestion.ingestion_declarative_pipeline import (
    get_pilotage_structure,
    get_raw_data,
    get_latest_view_from_stack,
    normalize_table_tags_for_uc,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pipeline Configuration Parameters

# COMMAND ----------

# Read configuration from pipeline parameters
pipeline_read_env_param = spark.conf.get("pipeline_read_env", "dev")
pipeline_write_env_param = spark.conf.get("pipeline_write_env", "dev")
reference_read_env_param = spark.conf.get("reference_read_env", "dev")
pipeline_name_param = spark.conf.get("pipeline_name", "default_pipeline")
landingzone_catalog_param = spark.conf.get("landingzone_catalog", "dev_landingzone")
bronze_catalog_param = spark.conf.get("bronze_catalog", "dev_bronze")
target_schema_param = spark.conf.get("target_schema", "default_schema")
log_level_param = spark.conf.get("log_level", "debug")
lowercase_columns_param = spark.conf.get("lowercase_columns", "true")

# COMMAND ----------

# Create widgets for interactive testing
dbutils.widgets.text("pipeline_write_env", pipeline_write_env_param)
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", pipeline_read_env_param)
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", reference_read_env_param)
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_name", pipeline_name_param)
PIPELINE_NAME = dbutils.widgets.get("pipeline_name")

dbutils.widgets.text("landingzone_catalog", landingzone_catalog_param)
LANDINGZONE_CATALOG = dbutils.widgets.get("landingzone_catalog")

dbutils.widgets.text("bronze_catalog", bronze_catalog_param)
BRONZE_CATALOG = dbutils.widgets.get("bronze_catalog")

dbutils.widgets.text("target_schema", target_schema_param)
TARGET_SCHEMA = dbutils.widgets.get("target_schema")

dbutils.widgets.dropdown(
    "lowercase_columns",
    defaultValue=lowercase_columns_param,
    choices=["true", "false"],
)
LOWERCASE_COLUMNS = dbutils.widgets.get("lowercase_columns").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger Setup

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue=log_level_param,
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = setup_applevel_logger(
    log_level=LOG_LEVEL,
    file_log_level=LOG_LEVEL,
    log_format="%(asctime)s - %(name)s - %(levelname)s - %(funcName)s - %(message)s",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Global Variables

# COMMAND ----------

# Catalog and schema configuration
LANDING_ZONE_CATALOG = LANDINGZONE_CATALOG
LANDING_ZONE_SCHEMA = TARGET_SCHEMA
BRONZE_SCHEMA = TARGET_SCHEMA

# Pilotage table location
DLT_PILOTAGE_TABLE = f"{REFERENCE_READ_ENV}_bronze.data_quality.dlt_pilotage_table"

# Enable auto merge for schema evolution
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Configuration

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV: {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV: {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV: {PIPELINE_WRITE_ENV}")
log.info(f"DLT_PILOTAGE_TABLE: {DLT_PILOTAGE_TABLE}")
log.info(f"PIPELINE_NAME: {PIPELINE_NAME}")
log.info(f"LANDING_ZONE_CATALOG: {LANDING_ZONE_CATALOG}")
log.info(f"LANDING_ZONE_SCHEMA: {LANDING_ZONE_SCHEMA}")
log.info(f"BRONZE_CATALOG: {BRONZE_CATALOG}")
log.info(f"BRONZE_SCHEMA: {BRONZE_SCHEMA}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load Pipeline Structure from Pilotage Table

# COMMAND ----------

# Get dictionary structure from pilotage table
FILES_ATTRS_DICT = get_pilotage_structure(
    pipeline_name=PIPELINE_NAME,
    pilotage_table=DLT_PILOTAGE_TABLE,
    reference_read_env=REFERENCE_READ_ENV,
    pipeline_write_env=PIPELINE_WRITE_ENV,
)
log.info(f"FILES_ATTRS_DICT: {FILES_ATTRS_DICT}")

# COMMAND ----------

# MAGIC %md
# MAGIC # SDP Table Creation Functions

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stack Table Creation (Landingzone)

# COMMAND ----------

def create_sdp_stack_table(table_id: str, attrs: Dict[str, Any]):
    """
    Create a SDP streaming table for the landingzone stack.

    :param table_id: The identifier of the table.
    :param attrs: Dictionary containing table attributes.
    """
    table_name = attrs["table_name"]
    log.info(f"Creating stack streaming table for {table_id}: {table_name}")

    base_props = {"quality": "landingzone"}
    tag_props = normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    @dp.table(
        name=f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}_stack",
        comment="Landingzone stack streaming table",
        table_properties=table_props,
    )
    def stack_table():
        df = get_raw_data(
            attr_dict=attrs,
            table_id=table_id,
            lowercase_columns=LOWERCASE_COLUMNS,
            dbutils=dbutils,
        )
        return df


def create_sdp_stack_view(table_id: str, attrs: Dict[str, Any]):
    """
    Create a SDP view for non-streaming scenarios.

    :param table_id: The identifier of the table.
    :param attrs: Dictionary containing table attributes.
    """
    table_name = attrs["table_name"]
    log.info(f"Creating stack view for {table_id}: {table_name}")

    @dp.view(
        name=f"{table_name}_stack",
        comment="Landingzone stack view",
    )
    def stack_view():
        df = get_raw_data(
            attr_dict=attrs,
            table_id=table_id,
            lowercase_columns=LOWERCASE_COLUMNS,
            dbutils=dbutils,
        )
        return df


# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze Stack Table Creation (Optional)

# COMMAND ----------

def create_sdp_bronze_stack(table_id: str, attrs: Dict[str, Any]):
    """
    Create a SDP materialized view for the bronze stack (optional).

    :param table_id: The identifier of the table.
    :param attrs: Dictionary containing table attributes.
    """
    table_name = attrs["table_name"]
    log.info(f"Creating bronze stack table for {table_id}: {table_name}")

    base_props = {"quality": "bronze"}
    tag_props = normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    source_table = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}_stack"

    @dp.table(
        name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_stack",
        comment="Bronze stack materialized view",
        table_properties=table_props,
    )
    def bronze_stack():
        df_stack = spark.read.table(source_table)
        return df_stack


# COMMAND ----------

# MAGIC %md
# MAGIC ## Latest View Creation (Bronze)

# COMMAND ----------

def create_sdp_latest_from_streaming(table_id: str, attrs: Dict[str, Any]):
    """
    Create a SDP materialized view for the latest data from a streaming stack table.

    :param table_id: The identifier of the table.
    :param attrs: Dictionary containing table attributes.
    """
    table_name = attrs["table_name"]
    log.info(f"Creating latest view for {table_id}: {table_name}")

    if LOWERCASE_COLUMNS:
        primary_key_cols = [col.lower() for col in attrs["primary_key_cols"]]
    else:
        primary_key_cols = attrs["primary_key_cols"]

    if len(primary_key_cols) == 0:
        primary_key_cols = ["_meta_id"]

    file_mode = attrs["file_mode"]

    base_props = {"quality": "bronze"}
    tag_props = normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    source_table = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}_stack"

    @dp.table(
        name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest",
        comment="Bronze latest materialized view",
        table_properties=table_props,
    )
    def latest_table():
        df_stack = spark.read.table(source_table)
        df_latest = get_latest_view_from_stack(df_stack, primary_key_cols, file_mode)
        return df_latest


def create_sdp_latest_from_view(table_id: str, attrs: Dict[str, Any]):
    """
    Create a SDP materialized view for the latest data from a non-streaming view.

    :param table_id: The identifier of the table.
    :param attrs: Dictionary containing table attributes.
    """
    table_name = attrs["table_name"]
    log.info(f"Creating latest view from view for {table_id}: {table_name}")

    if LOWERCASE_COLUMNS:
        primary_key_cols = [col.lower() for col in attrs["primary_key_cols"]]
    else:
        primary_key_cols = attrs["primary_key_cols"]

    if len(primary_key_cols) == 0:
        primary_key_cols = ["_meta_id"]

    file_mode = attrs["file_mode"]

    base_props = {"quality": "bronze"}
    tag_props = normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    @dp.table(
        name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest",
        comment="Bronze latest materialized view",
        table_properties=table_props,
    )
    def latest_table():
        # Read from local view defined in the same pipeline
        df_stack = spark.table(f"LIVE.{table_name}_stack")
        df_latest = get_latest_view_from_stack(df_stack, primary_key_cols, file_mode)
        return df_latest


# COMMAND ----------

# MAGIC %md
# MAGIC # Pipeline Execution

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 1: Create Stack Tables/Views

# COMMAND ----------

for table_id, attrs in FILES_ATTRS_DICT.items():
    stacked_stream = attrs["stacked_stream"]
    if stacked_stream:
        log.info(f"Creating stack streaming table for {table_id}")
        create_sdp_stack_table(table_id=table_id, attrs=attrs)
    else:
        log.info(f"Creating stack view for {table_id}")
        create_sdp_stack_view(table_id=table_id, attrs=attrs)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 2: Create Optional Bronze Stack Tables

# COMMAND ----------

for table_id, attrs in FILES_ATTRS_DICT.items():
    table_name = attrs["table_name"]

    # Skip special tables
    if table_name == "talend_job_summary":
        continue

    stacked_stream = attrs["stacked_stream"]
    optional_bronze_stack = attrs["optional_bronze_stack"]

    if stacked_stream and optional_bronze_stack:
        log.info(f"Creating bronze stack table for {table_id}")
        create_sdp_bronze_stack(table_id=table_id, attrs=attrs)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 3: Create Latest Materialized Views

# COMMAND ----------

for table_id, attrs in FILES_ATTRS_DICT.items():
    table_name = attrs["table_name"]

    # Skip special tables
    if table_name == "talend_job_summary":
        continue

    log.info(f"Creating latest view for {table_id}")
    stacked_stream = attrs["stacked_stream"]

    if stacked_stream:
        create_sdp_latest_from_streaming(table_id=table_id, attrs=attrs)
    else:
        create_sdp_latest_from_view(table_id=table_id, attrs=attrs)

# COMMAND ----------

# MAGIC %md
# MAGIC # Freshness Monitoring

# COMMAND ----------

freshness_view_names = []


def create_freshness_view(
    source_table: str,
    table_name_short: str,
    frequency: int,
    schema_name: str,
    job_name: str,
    view_name: str,
):
    """
    Create a freshness monitoring view for a table.
    """
    @dp.view(name=view_name)
    def _freshness_view():
        return (
            spark.read.table(source_table)
            .agg(f.max("_meta_ingestion_timestamp").alias("last_update_time"))
            .withColumn("frequency", f.lit(frequency).cast("int"))
            .withColumn("schema_name", f.lit(schema_name))
            .withColumn("job_name", f.lit(job_name))
            .withColumn("table_name", f.lit(source_table))
            .withColumn("table_name_short", f.lit(table_name_short))
        )

    return _freshness_view


for table_id, attrs in FILES_ATTRS_DICT.items():
    table_name = attrs["table_name"]

    # Skip special tables
    if table_name == "talend_job_summary":
        continue

    frequency = attrs["frequency"]
    view_name = f"{table_name}_freshness"
    source_table = f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest"

    freshness_view_names.append(f"LIVE.{view_name}")

    create_freshness_view(
        source_table=source_table,
        table_name_short=table_name,
        frequency=frequency,
        schema_name=BRONZE_SCHEMA,
        job_name=PIPELINE_NAME,
        view_name=view_name,
    )


@dp.view(
    name="freshness_all_temp",
    comment="Temporary view aggregating all freshness views",
)
def freshness_all_temp():
    dfs = [spark.table(name) for name in freshness_view_names]
    return reduce(lambda a, b: a.unionByName(b), dfs)


@dp.table(
    name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{PIPELINE_NAME}_freshness_all",
    comment="Aggregated freshness monitoring table",
)
def freshness_all():
    df_freshness = spark.table("LIVE.freshness_all_temp")

    # Try to read talend_job_summary_stack if it exists
    try:
        df_tjs = (
            spark.table("LIVE.talend_job_summary_stack")
            .withColumn(
                "table_name_short",
                f.regexp_extract(
                    f.col("nomfichier"), r"^\d{8}_\d{6}_[^-]+-([^-]+).*", 1
                ),
            )
            .select(
                f.col("_meta_extraction_timestamp").alias("last_pipeline_ts"),
                "table_name_short",
                f.col("nbrlignes").alias("last_row_count"),
            )
        )
        df_latest_tjs = table_utils.drop_duplicates_by_order(
            df=df_tjs,
            columns=["table_name_short"],
            order_col=["last_pipeline_ts"],
            keep="last",
        )
    except Exception:
        return df_freshness

    # Join on table_name_short
    df_joined = df_freshness.join(df_latest_tjs, on="table_name_short", how="left")

    # Override last_update_time if last_row_count == 0
    df_final = (
        df_joined
        .withColumn(
            "last_update_time",
            f.when(f.col("last_row_count") == 0, f.col("last_pipeline_ts"))
            .otherwise(f.col("last_update_time")),
        )
        .filter(f.col("last_update_time").isNotNull())
        .drop("last_pipeline_ts", "last_row_count", "table_name_short")
    )

    return df_final

# COMMAND ----------

# MAGIC %md
# MAGIC # End of Pipeline
