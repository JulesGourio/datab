# Generic Table Ingestion Pipelines

This folder contains generic ingestion notebooks for creating Bronze-layer streaming tables from files (CSV, PARQUET, XML).

## Available Notebooks

| Notebook | API | Description |
|----------|-----|-------------|
| `Generic_table_ingestion_DLT_notebook.py` | DLT | Original version using Delta Live Tables API |
| `Generic_table_ingestion_SDP_notebook.py` | SDP | New version using Spark Declarative Pipelines |

## Architecture Overview

```mermaid
flowchart TB
    subgraph INPUT["Input Sources"]
        S3["S3 Bucket<br/>(CSV, PARQUET, XML)"]
    end

    subgraph CONFIG["Configuration"]
        PILOT["dlt_pilotage_table<br/>(bronze.data_quality)"]
    end

    subgraph NOTEBOOK["Generic Ingestion Notebook"]
        READ["get_raw_data()<br/>cloudFiles Auto Loader"]
        META["Add Metadata<br/>_meta_id, _meta_extraction_timestamp, ..."]
        VALID["Validity Check<br/>NOT NULL, missing columns"]
    end

    subgraph OUTPUT["Output Tables"]
        LZ["landingzone.schema.table_stack<br/>(Streaming Table)"]
        BZ_STACK["bronze.schema.table_stack<br/>(Optional Materialized View)"]
        BZ_LATEST["bronze.schema.table_latest<br/>(Deduplicated View)"]
    end

    PILOT --> NOTEBOOK
    S3 --> READ
    READ --> META
    META --> VALID
    VALID --> LZ
    LZ --> BZ_STACK
    LZ --> BZ_LATEST

    style S3 fill:#f9f,stroke:#333,color:#1a1a1a
    style PILOT fill:#ff9,stroke:#333,color:#1a1a1a
    style LZ fill:#9cf,stroke:#333,color:#1a1a1a
    style BZ_LATEST fill:#9f9,stroke:#333,color:#1a1a1a
```

## DLT vs SDP Comparison

```mermaid
flowchart LR
    subgraph DLT["DLT API"]
        DLT_IMP["import dlt"]
        DLT_TBL["@dlt.table()"]
        DLT_VIEW["@dlt.view()"]
        DLT_READ["dlt.read()"]
    end

    subgraph SDP["SDP API"]
        SDP_IMP["from pyspark import pipelines as dp"]
        SDP_TBL["@dp.table()"]
        SDP_VIEW["@dp.view()"]
        SDP_READ["spark.read.table()"]
    end

    DLT_IMP -.->|"migration"| SDP_IMP
    DLT_TBL -.->|"migration"| SDP_TBL
    DLT_VIEW -.->|"migration"| SDP_VIEW
    DLT_READ -.->|"migration"| SDP_READ

    style DLT fill:#fdd,stroke:#933,color:#1a1a1a
    style SDP fill:#dfd,stroke:#393,color:#1a1a1a
```

## Supported File Formats

| Format | Serverless | Options | Use Case |
|--------|------------|---------|----------|
| **CSV** | ✅ Yes | delimiter, header, escape, quote | Text exports, legacy systems |
| **PARQUET** | ✅ Yes | (none required) | Columnar data, best performance |
| **XML** | ❌ No (classic only) | rowTag, attributePrefix, valueTag | Structured data exchange |

**Schema Handling:** All formats use `inferSchema=true` and `mergeSchema=true` when files exist. If no files are present, the schema defined in the pilotage table is used.

```mermaid
flowchart LR
    subgraph FORMATS["File Formats"]
        CSV["CSV"]
        PARQUET["PARQUET"]
        XML["XML"]
    end

    subgraph LOADER["cloudFiles Auto Loader"]
        AL["spark.readStream<br/>.format('cloudFiles')<br/>inferSchema=true<br/>mergeSchema=true"]
    end

    subgraph OUTPUT["Streaming Table"]
        ST["_stack table"]
    end

    CSV --> AL
    PARQUET --> AL
    XML --> AL
    AL --> ST

    style CSV fill:#dfd,stroke:#393,color:#1a1a1a
    style PARQUET fill:#dfd,stroke:#393,color:#1a1a1a
    style XML fill:#ffc,stroke:#333,color:#1a1a1a
```

### CSV Options

| Option | Default | Description |
|--------|---------|-------------|
| `csv_delimiter` | `;` | Field delimiter |
| `csv_header` | `true` | First row contains column names |
| `csv_escape_char` | `"` | Escape character |
| `csv_quote_char` | `"` | Quote character |

### PARQUET

No format-specific options required. PARQUET is the recommended format for performance.

## Data Flow: Stack to Latest

```mermaid
flowchart TB
    subgraph STACK["_stack Table (Streaming)"]
        direction TB
        S1["File 1: 2024-01-01<br/>id=A, value=10"]
        S2["File 2: 2024-01-02<br/>id=A, value=20"]
        S3["File 3: 2024-01-02<br/>id=B, value=30"]
    end

    subgraph DEDUP["Deduplication Logic"]
        FULL["FULL Mode:<br/>Keep latest file only"]
        DELTA["DELTA Mode:<br/>Keep latest per PK"]
    end

    subgraph LATEST["_latest Table (Materialized)"]
        L1["id=A, value=20<br/>(from File 2)"]
        L2["id=B, value=30<br/>(from File 3)"]
    end

    S1 --> DEDUP
    S2 --> DEDUP
    S3 --> DEDUP
    DEDUP --> LATEST

    style STACK fill:#ffd,stroke:#333,color:#1a1a1a
    style LATEST fill:#dff,stroke:#333,color:#1a1a1a
```

## Metadata Columns

All ingested tables include these metadata columns:

| Column | Type | Description |
|--------|------|-------------|
| `_meta_id` | STRING | Composite key from primary key columns |
| `_meta_extraction_timestamp` | TIMESTAMP | Extracted from filename (YYYYMMDD_HHMMSS) |
| `_meta_ingestion_timestamp` | TIMESTAMP | Current timestamp at ingestion |
| `_meta_file_name` | STRING | Source filename |
| `_meta_file_mode` | STRING | FULL or DELTA (from filename suffix) |
| `_meta_file_path` | STRING | Full S3 path |
| `_meta_validity_check` | BOOLEAN | NOT NULL and column presence validation |

## Pilotage Table Schema

The `dlt_pilotage_table` drives the pipeline configuration:

```mermaid
erDiagram
    DLT_PILOTAGE_TABLE {
        bigint id PK
        string pipeline_name
        string database_name
        string table_name
        string stream_format
        boolean stacked_stream
        boolean optional_bronze_stack
        string file_format
        string file_keyword_simplified
        string file_regex
        string file_mode
        string bucket_name
        string file_prefix
        string archive_bucket_name
        string archive_file_prefix
        string csv_delimiter
        boolean csv_header
        string csv_escape_char
        string csv_quote_char
        int frequency
        array columns
        map table_tags
        map column_tags
        array primary_key
        array foreign_keys
        string xml_row_tag
        string xml_attribute_prefix
        string xml_value_tag
        boolean xml_exclude_attributes
    }

    COLUMNS_STRUCT {
        string column_name
        boolean is_expected
        boolean is_primary_key
        boolean null_allowed
        string column_type
    }

    DLT_PILOTAGE_TABLE ||--o{ COLUMNS_STRUCT : contains
```

### Pilotage Table Fields Reference

#### Core Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | BIGINT | Auto | Auto-generated unique identifier |
| `pipeline_name` | STRING | ✅ | Unique pipeline name. Used to filter entries for a specific pipeline. |
| `database_name` | STRING | ✅ | Source system/database name (informational). Multiple sources can exist per pipeline. |
| `table_name` | STRING | ✅ | Target table name (lowercase). Will create `{table_name}_stack` and `{table_name}_latest`. |

#### Stream Configuration

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `stream_format` | STRING | ✅ | Currently only `'file'` is supported. Future: stream sources. |
| `stacked_stream` | BOOLEAN | ✅ | `TRUE` = creates a **streaming table** `_stack` in landingzone catalog.<br/>`FALSE` = creates a **view** `_stack` instead. |
| `optional_bronze_stack` | BOOLEAN | ✅ | `TRUE` = creates an additional **materialized view** `_stack` in bronze catalog. Useful to access stack data from bronze. |

#### File Configuration

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `file_format` | STRING | ✅ | `'CSV'`, `'PARQUET'`, or `'XML'` (uppercase). |
| `file_keyword_simplified` | STRING | ✅ | Glob pattern used in `pathGlobfilter` option of cloudFiles Auto Loader. Example: `'MY_TABLE'` matches `*MY_TABLE*`. |
| `file_regex` | STRING | ✅ | Regex applied **after** file loading to filter rows by `_meta_file_name`. Example: `'^(\d{8})_(\d{6})_MY_TABLE.*\.parquet$'` |
| `file_mode` | STRING | ✅ | `'FULL'` = each file is a complete snapshot → `_latest` keeps only the most recent file.<br/>`'DELTA'` = files contain incremental changes → `_latest` deduplicates by primary key, keeping latest per PK. |
| `bucket_name` | STRING | ✅ | S3 bucket for input files. Supports `{REFERENCE_READ_ENV}` placeholder. |
| `file_prefix` | STRING | ✅ | Path prefix within the bucket. Example: `'apps/my_source/'` |
| `archive_bucket_name` | STRING | ❌ | **Deprecated.** Archiving is handled by external job (not by the pipeline). |
| `archive_file_prefix` | STRING | ❌ | **Deprecated.** Archiving is handled by external job (not by the pipeline). |

#### Environment Variables in Bucket Names

| Placeholder | Usage | Example |
|-------------|-------|---------|
| `{REFERENCE_READ_ENV}` | Read data **external** to the pipeline (input files, pilotage table) | `leap-s3-raw-weeu1-{REFERENCE_READ_ENV}` |
| `{PIPELINE_READ_ENV}` | Read data **within** the pipeline (e.g., bronze when creating silver) | `{PIPELINE_READ_ENV}_bronze.schema.table` |
| `{PIPELINE_WRITE_ENV}` | Write output data | `leap-s3-raw-weeu1-{PIPELINE_WRITE_ENV}` |

#### CSV Options

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `csv_delimiter` | STRING | For CSV | `;` | Field delimiter |
| `csv_header` | BOOLEAN | For CSV | `true` | First row contains column names |
| `csv_escape_char` | STRING | For CSV | `"` | Escape character |
| `csv_quote_char` | STRING | For CSV | `"` | Quote character |

#### Freshness Monitoring

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `frequency` | INT | ✅ | Expected refresh frequency in **days**. Used to create freshness views that are merged into `bronze.data_quality.freshness_pilot_table` after pipeline execution. |

#### Columns Definition

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `columns` | ARRAY | ✅ | Array of column definitions (see structure below) |

**COLUMNS_STRUCT fields:**

| Field | Type | Description |
|-------|------|-------------|
| `column_name` | STRING | Column name (case-insensitive, will be lowercased) |
| `is_expected` | BOOLEAN | If `TRUE` and column is missing from file → `_meta_validity_check = FALSE` |
| `is_primary_key` | BOOLEAN | If `TRUE`, column is used to build `_meta_id` composite key |
| `null_allowed` | BOOLEAN | If `FALSE` and column contains NULL → `_meta_validity_check = FALSE` |
| `column_type` | STRING | Target data type. Supported values: see SQL_TO_SPARK_TYPE_MAPPING below |

**Supported column_type values:**

```
VARCHAR, STRING, TEXT, CHAR, NCHAR, NVARCHAR, NTEXT, CLOB
INT, INTEGER, TINYINT, SMALLINT, MEDIUMINT, BIGINT, LONG
DECIMAL, NUMERIC, REAL, FLOAT, DOUBLE, NUMBER
BOOLEAN, BOOL, BIT
DATE, DATETIME, TIMESTAMP, SMALLDATETIME
JSON, JSONB
```

#### Example: Full INSERT Statement

```sql
INSERT INTO dev_bronze.data_quality.dlt_pilotage_table (
  pipeline_name, database_name, table_name,
  stream_format, stacked_stream, optional_bronze_stack,
  file_format, file_keyword_simplified, file_regex, file_mode,
  bucket_name, file_prefix,
  csv_delimiter, csv_header,
  frequency,
  columns,
  table_tags
)
VALUES (
  'my_pipeline',           -- pipeline_name: unique identifier
  'erp_system',            -- database_name: source system (info only)
  'sales_orders',          -- table_name: creates sales_orders_stack + sales_orders_latest
  'file',                  -- stream_format: only 'file' supported
  TRUE,                    -- stacked_stream: TRUE = streaming table, FALSE = view
  FALSE,                   -- optional_bronze_stack: TRUE = also create _stack in bronze
  'CSV',                   -- file_format: CSV, PARQUET, or XML
  'SALES_ORDERS',          -- file_keyword_simplified: glob pattern for pathGlobfilter
  '^(\d{8})_(\d{6})_SALES_ORDERS.*\.csv$',  -- file_regex: filter after load
  'DELTA',                 -- file_mode: FULL or DELTA (affects deduplication)
  'leap-s3-raw-weeu1-{REFERENCE_READ_ENV}',  -- bucket_name with env placeholder
  'apps/erp/',             -- file_prefix: path in bucket
  ';',                     -- csv_delimiter
  TRUE,                    -- csv_header
  1,                       -- frequency: 1 day (for freshness monitoring)
  ARRAY(
    STRUCT('order_id', TRUE, TRUE, FALSE, 'VARCHAR'),      -- PK, expected, nullable
    STRUCT('customer_id', TRUE, FALSE, FALSE, 'VARCHAR'),  -- expected, not null
    STRUCT('amount', TRUE, FALSE, TRUE, 'DECIMAL'),        -- expected, nullable
    STRUCT('order_date', TRUE, FALSE, FALSE, 'DATE')       -- expected, not null
  ),
  map('domain', 'Sales', 'refresh_frequency', 'daily')     -- table_tags for UC
);
```

### File Naming Convention

**Required format:** Files MUST start with a timestamp prefix:

```
YYYYMMDD_HHMMSS_<identifier>[-F|-D].<extension>
```

| Part | Description | Example |
|------|-------------|---------|
| `YYYYMMDD_HHMMSS` | **Required** timestamp at start | `20260301_143022` |
| `<identifier>` | Table/source identifier | `SALES_ORDERS` |
| `-F` or `-D` | Optional: `F` = FULL, `D` = DELTA | `-F` |
| `.<extension>` | File extension | `.csv`, `.parquet`, `.xml` |

**Examples:**
- `20260301_143022_SALES_ORDERS-F.csv` → FULL mode, timestamp = 2026-03-01 14:30:22
- `20260301_000000_MY_TABLE.parquet` → timestamp = 2026-03-01 00:00:00

The notebook extracts `_meta_extraction_timestamp` from the filename using regex `(\d{8}_\d{6})`.

### Unity Catalog Tags & Constraints Columns

These columns are used by the `Apply_unity_catalog_tags_on_DLT_assets.py` notebook to apply metadata to tables after pipeline execution.

| Column | Type | Description |
|--------|------|-------------|
| `table_tags` | `MAP<STRING, STRING>` | Table-level Unity Catalog tags (key → value) |
| `column_tags` | `MAP<STRING, MAP<STRING, STRING>>` | Column-level tags (column_name → (tag_key → value)) |
| `primary_key` | `ARRAY<STRING>` | Logical primary key columns (for documentation/tags) |
| `foreign_keys` | `ARRAY<STRUCT<...>>` | Logical foreign keys (see format below) |

#### table_tags Format

```sql
map('domain', 'Production_Manufacturing', 'refresh_frequency', 'daily')
```

#### column_tags Format

```sql
map(
  'customer_id', map('pii', 'true', 'classification', 'confidential'),
  'email', map('pii', 'true')
)
```

#### primary_key Format

```sql
ARRAY('col1', 'col2')  -- Composite primary key
```

#### foreign_keys Format

```sql
ARRAY(
  STRUCT(
    ARRAY('local_col1', 'local_col2') AS columns,
    STRUCT('catalog.schema.ref_table' AS table, ARRAY('ref_col1', 'ref_col2') AS columns) AS references,
    'fk_constraint_name' AS constraint_name
  )
)
```

## XML Support (Extension)

XML format requires a **classic cluster** (non-serverless) because spark-xml is a JAR library. spark-xml is built into Databricks Runtime 15.4+, so no Maven dependency is needed.

### XML-Specific Options

| Option | Default | Description |
|--------|---------|-------------|
| `xml_row_tag` | `row` | XML tag delimiting each record |
| `xml_attribute_prefix` | `_` | Prefix for XML attributes as columns |
| `xml_value_tag` | `_VALUE` | Column name for element text content |
| `xml_exclude_attributes` | `false` | Exclude XML attributes from output |

### XML Structure Example (Airbus)

```xml
<?xml version="1.0" ?>
<O>
    <ADAPCI>
        <row>
            <ADAPCINUMBER><![CDATA[DME92Z470100]]></ADAPCINUMBER>
            <ENGLISHTITLE><![CDATA[EQUIPEMENT 72VU]]></ENGLISHTITLE>
            <STATE><![CDATA[PUBLISHED]]></STATE>
        </row>
    </ADAPCI>
</O>
```

**Configuration:** `xml_row_tag = "row"`, `xml_exclude_attributes = true`

### Cluster Requirements for XML

```mermaid
flowchart LR
    subgraph SERVERLESS["Serverless Pipeline"]
        SL_CSV["CSV ✅"]
        SL_PARQUET["PARQUET ✅"]
        SL_XML["XML ❌"]
    end

    subgraph CLASSIC["Classic Cluster Pipeline"]
        CL_CSV["CSV ✅"]
        CL_PARQUET["PARQUET ✅"]
        CL_XML["XML ✅<br/>(spark-xml built-in)"]
    end

    style SL_XML fill:#fdd,stroke:#933,color:#1a1a1a
    style CL_XML fill:#dfd,stroke:#393,color:#1a1a1a
```

## Usage

### Pipeline Parameters

The generic ingestion notebook reads configuration from pipeline parameters (passed via `spark.conf.get()`). These parameters are set in the `configuration:` block of the pipeline YAML.

| Parameter | Default | Required | Description |
|-----------|---------|----------|-------------|
| `pipeline_name` | `default_pipeline` | ✅ | Unique name matching the `pipeline_name` column in the pilotage table. Used to filter which tables to ingest. |
| `pipeline_write_env` | `dev` | ✅ | Environment for writing output tables. Replaces `{PIPELINE_WRITE_ENV}` in bucket names. Values: `dev`, `prod`. |
| `reference_read_env` | `dev` | ✅ | Environment for reading external data (input files, pilotage table). Replaces `{REFERENCE_READ_ENV}` in bucket names. Values: `dev`, `prod`. |
| `pipeline_read_env` | `dev` | ❌ | Environment for reading internal pipeline data (not used by this notebook, but available). |
| `landingzone_catalog` | `dev_landingzone` | ✅ | Catalog where `_stack` streaming tables are created. Typically `{env}_landingzone`. |
| `bronze_catalog` | `dev_bronze` | ✅ | Catalog where `_latest` views are created. Typically `{env}_bronze`. |
| `target_schema` | `default_schema` | ✅ | Schema within the catalogs where tables are created. |
| `log_level` | `debug` | ❌ | Logging verbosity level (`debug`, `info`, `warning`, `error`). |

**How parameters flow:**

```mermaid
flowchart LR
    subgraph YAML["pipeline.yml"]
        CONF["configuration:<br/>pipeline_name: my_pipeline<br/>pipeline_write_env: dev<br/>..."]
    end

    subgraph NOTEBOOK["SDP Notebook"]
        READ["spark.conf.get('pipeline_name')"]
        PILOT["Filter pilotage table<br/>WHERE pipeline_name = ?"]
        TABLES["Create tables in<br/>{landingzone_catalog}.{target_schema}"]
    end

    CONF --> READ
    READ --> PILOT
    PILOT --> TABLES

    style YAML fill:#ffd,stroke:#333,color:#1a1a1a
    style NOTEBOOK fill:#dfd,stroke:#333,color:#1a1a1a
```

### Pipeline Configuration

```yaml
resources:
  pipelines:
    my_pipeline:
      name: my_ingestion_pipeline
      catalog: dev_landingzone
      target: my_schema
      serverless: true  # Set to false only for XML format

      libraries:
        - notebook:
            path: /Workspace/Shared/leap-dbx-repository/ingestion/dlt/Generic_table_ingestion_SDP_notebook

      configuration:
        pipeline_name: my_pipeline_name
        pipeline_write_env: dev
        reference_read_env: dev
        landingzone_catalog: dev_landingzone
        bronze_catalog: dev_bronze
        target_schema: my_schema
```

### Pilotage Table Entry (PARQUET example)

```sql
INSERT INTO dev_bronze.data_quality.dlt_pilotage_table (
  pipeline_name, database_name, table_name,
  stream_format, stacked_stream, optional_bronze_stack,
  file_format, file_keyword_simplified, file_regex, file_mode,
  bucket_name, file_prefix, archive_bucket_name, archive_file_prefix,
  frequency, columns
)
VALUES (
  'my_pipeline_name', 'source_db', 'my_table',
  'file', TRUE, FALSE,
  'PARQUET', 'MY_TABLE', '^(\\d{8})_(\\d{6})_MY_TABLE.*\\.parquet$', 'DELTA',
  'leap-s3-raw-weeu1-{REFERENCE_READ_ENV}', 'apps/my_source/',
  'leap-s3-raw-weeu1-{PIPELINE_WRITE_ENV}', 'archive/apps/my_source/',
  1,
  ARRAY(
    STRUCT('col1', TRUE, TRUE, FALSE, 'VARCHAR'),
    STRUCT('col2', TRUE, FALSE, TRUE, 'INTEGER')
  )
);
```

### Pilotage Table Entry (CSV example)

```sql
INSERT INTO dev_bronze.data_quality.dlt_pilotage_table (
  pipeline_name, database_name, table_name,
  stream_format, stacked_stream, optional_bronze_stack,
  file_format, file_keyword_simplified, file_regex, file_mode,
  bucket_name, file_prefix, archive_bucket_name, archive_file_prefix,
  csv_delimiter, csv_header, csv_escape_char, csv_quote_char,
  frequency, columns
)
VALUES (
  'my_csv_pipeline', 'source_db', 'my_table',
  'file', TRUE, FALSE,
  'CSV', 'MY_TABLE', '^(\\d{8})_(\\d{6})_MY_TABLE.*\\.csv$', 'DELTA',
  'leap-s3-raw-weeu1-{REFERENCE_READ_ENV}', 'apps/my_source/',
  'leap-s3-raw-weeu1-{PIPELINE_WRITE_ENV}', 'archive/apps/my_source/',
  ';', TRUE, '"', '"',
  1,
  ARRAY(
    STRUCT('col1', TRUE, TRUE, FALSE, 'VARCHAR'),
    STRUCT('col2', TRUE, FALSE, TRUE, 'INTEGER')
  )
);
```

## Creating a New Ingestion Pipeline

To create a new ingestion pipeline using these generic notebooks, follow these steps:

### 1. Create a Databricks Asset Bundle

Create a new bundle under `platform/asset_bundle/<your_pipeline_name>/` with this structure:

```
platform/asset_bundle/<your_pipeline_name>/
├── databricks.yml           # Bundle configuration
├── resources/
│   ├── pipeline.yml         # Pipeline definition
│   └── job.yml              # Job definition (optional)
├── src/
│   └── configure_pipeline.py  # Pilotage table configuration notebook
└── README.md                # Bundle documentation
```

### 2. Configure the Bundle

In `databricks.yml`:
```yaml
bundle:
  name: <your_pipeline_name>

variables:
  pipeline_write_env:
    default: dev
  reference_read_env:
    default: dev
  target_catalog:
    default: ${var.pipeline_write_env}_landingzone
  bronze_catalog:
    default: ${var.pipeline_write_env}_bronze
  target_schema:
    default: <your_schema>

targets:
  dev:
    default: true
    variables:
      pipeline_write_env: dev
      reference_read_env: dev
  prod:
    variables:
      pipeline_write_env: prod
      reference_read_env: prod
```

### 3. Define the Pipeline

In `resources/pipeline.yml`:
```yaml
resources:
  pipelines:
    <your_pipeline_name>_pipeline:
      name: ${bundle.name}_pipeline
      catalog: ${var.target_catalog}
      target: ${var.target_schema}
      serverless: true  # Set to false only for XML format

      libraries:
        - notebook:
            path: /Workspace/Shared/leap-dbx-repository/ingestion/dlt/Generic_table_ingestion_SDP_notebook

      configuration:
        pipeline_name: "<your_pipeline_name>"
        pipeline_write_env: ${var.pipeline_write_env}
        reference_read_env: ${var.reference_read_env}
        landingzone_catalog: ${var.target_catalog}
        bronze_catalog: ${var.bronze_catalog}
        target_schema: ${var.target_schema}
```

### 4. Create the Pilotage Table Configuration

In `src/configure_pipeline.py`, create a Databricks notebook that:
1. Creates the pilotage table if not exists
2. Inserts configuration entries for each table to ingest

See the `airbus_bom` bundle for a complete example.

### 5. Deploy and Run

```bash
# Deploy the bundle
cd platform/asset_bundle/<your_pipeline_name>
databricks bundle deploy --target dev

# Run the configuration notebook first (manually or via job)
# Then run the pipeline
databricks bundle run <your_pipeline_name>_pipeline --target dev
```

For detailed examples, see the bundle README files:
- `platform/asset_bundle/airbus_bom/README.md` - XML ingestion example
- `platform/asset_bundle/mimecast_ingestion/README.md` - CSV ingestion example
- `platform/asset_bundle/mes_ingestion/README.md` - PARQUET ingestion example

## Apply Unity Catalog Tags (Post-Pipeline)

The notebook `Apply_unity_catalog_tags_on_DLT_assets.py` applies Unity Catalog tags to tables **after** the pipeline execution.

### Why a Separate Notebook?

DLT/SDP pipelines cannot directly apply Unity Catalog tags during table creation. This notebook reads the tag configuration from the pilotage table and applies them to the materialized tables.

### When to Run

- **Option 1:** As the 2nd task in the Workflow job (after the pipeline refresh)
- **Option 2:** Once a day via a scheduled job (recommended for cost optimization)

### Job Configuration Example

```yaml
tasks:
  - task_key: refresh_pipeline
    pipeline_task:
      pipeline_id: ${resources.pipelines.my_pipeline.id}

  - task_key: apply_tags
    depends_on:
      - task_key: refresh_pipeline
    notebook_task:
      notebook_path: /Workspace/Shared/leap-dbx-repository/ingestion/dlt/Apply_unity_catalog_tags_on_DLT_assets
      base_parameters:
        pipeline_name: "my_pipeline_name"
        pipeline_read_env: "${var.pipeline_read_env}"
        pipeline_write_env: "${var.pipeline_write_env}"
        target_schema: "${var.target_schema}"
        tag_stack: "true"
        tag_latest: "true"
        apply_pk_fk: "true"
        dry_run: "false"
```

### Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `pipeline_name` | - | Name of the pipeline in pilotage table |
| `pipeline_read_env` | `dev` | Environment to read pilotage table from |
| `pipeline_write_env` | `dev` | Environment of target tables to tag |
| `target_schema` | - | Schema containing the tables |
| `tag_stack` | `true` | Apply tags to `_stack` tables (landingzone) |
| `tag_latest` | `true` | Apply tags to `_latest` tables (bronze) |
| `apply_pk_fk` | `true` | Apply logical PK/FK as tags |
| `only_tables_csv` | `` | Comma-separated list of tables (empty = all) |
| `dry_run` | `false` | Preview changes without applying |

### What Gets Applied

1. **Table-level tags** from `table_tags` column
2. **Column-level tags** from `column_tags` column
3. **Primary key tags** from `primary_key` column (if `apply_pk_fk=true`)
4. **Foreign key tags** from `foreign_keys` column (if `apply_pk_fk=true`)

## Module: leap_utils.ingestion.ingestion_declarative_pipeline

Reusable functions extracted for both DLT and SDP notebooks:

| Function | Description |
|----------|-------------|
| `get_pilotage_structure()` | Reads pilotage table and builds config dict |
| `get_raw_data()` | Loads data from CSV/PARQUET/XML with cloudFiles |
| `get_latest_view_from_stack()` | Deduplicates stack for FULL/DELTA modes |
| `normalize_table_tags_for_uc()` | Converts tags to UC table properties |
| `spark_type_from_str()` | Maps type strings to PySpark types |
| `get_spark_schema()` | Builds StructType from column config |
