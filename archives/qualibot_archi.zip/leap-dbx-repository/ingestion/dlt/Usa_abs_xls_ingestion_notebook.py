# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # USA ABSENCES — XLS INGESTION PIPELINE (SDP)
# MAGIC
# MAGIC **Description:**
# MAGIC Ingests `.xls` / `.xlsx` files deposited manually in a Unity Catalog volume.
# MAGIC Uses Auto Loader (`cloudFiles.format = "excel"`) to process each new file incrementally
# MAGIC and append its rows to a **stack** table in the landingzone.
# MAGIC
# MAGIC **Source volume:**
# MAGIC `/Volumes/{pipeline_write_env}_landingzone_hr/manual_files/usa_abs/`
# MAGIC
# MAGIC **Output table (stack):**
# MAGIC `{landingzone_catalog}.usa_abs.usa_abs_stack`
# MAGIC
# MAGIC **Design choices:**
# MAGIC - **Streaming append** — Auto Loader (`cloudFiles.format=excel`) tracks processed files;
# MAGIC   each new monthly file is appended once and never re-processed.
# MAGIC - `dataAddress`: `Time Off Report!A1:J99999` — no single quotes, range limited to the
# MAGIC   10 data columns (A→J) to avoid empty `_c10+` artefact columns.
# MAGIC - Column names are lowercased and special characters replaced with underscores.
# MAGIC - Metadata columns follow the `_meta_*` naming convention of the generic pipeline.
# MAGIC - `_meta_extraction_timestamp` is parsed from the filename prefix `YYYYMMDD_HHmmss`.
# MAGIC - `_meta_validity_check` flags rows where `employee_id` is not null.
# MAGIC
# MAGIC **Runtime requirement:** Databricks Runtime 17.1+

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Standard Package Imports

# COMMAND ----------

import re
import sys
from pyspark import pipelines as dp
import pyspark.sql.functions as f
from pyspark.sql.types import StringType, StructField, StructType

# COMMAND ----------

# MAGIC %md
# MAGIC ## LEAP Function Imports

# COMMAND ----------

bundle_root = spark.conf.get("bundle_root", "")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

# COMMAND ----------

from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pipeline Configuration Parameters

# COMMAND ----------

pipeline_write_env_param  = spark.conf.get("pipeline_write_env",  "dev")
landingzone_catalog_param = spark.conf.get("landingzone_catalog", "dev_landingzone_hr")
log_level_param           = spark.conf.get("log_level",           "debug")

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", pipeline_write_env_param)
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("landingzone_catalog", landingzone_catalog_param)
LANDINGZONE_CATALOG = dbutils.widgets.get("landingzone_catalog")

dbutils.widgets.dropdown(
    "log_level",
    defaultValue=log_level_param,
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger Setup

# COMMAND ----------

log = setup_applevel_logger(
    log_level=LOG_LEVEL,
    file_log_level=LOG_LEVEL,
    log_format="%(asctime)s - %(name)s - %(levelname)s - %(funcName)s - %(message)s",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Global Variables

# COMMAND ----------

VOLUME_PATH    = f"/Volumes/{PIPELINE_WRITE_ENV}_landingzone_hr/manual_files/usa_abs"
TARGET_SCHEMA  = "usa_abs"
TARGET_TABLE   = "usa_abs_stack"

spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

log.info(f"PIPELINE_WRITE_ENV  : {PIPELINE_WRITE_ENV}")
log.info(f"LANDINGZONE_CATALOG : {LANDINGZONE_CATALOG}")
log.info(f"VOLUME_PATH         : {VOLUME_PATH}")
log.info(f"TARGET              : {LANDINGZONE_CATALOG}.{TARGET_SCHEMA}.{TARGET_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Helper Functions

# COMMAND ----------

def _normalize_columns(sdf):
    """Rename all columns to snake_case (lowercase + underscores)."""
    return sdf.toDF(*[
        re.sub(r"[^a-z0-9]+", "_", c.strip().lower()).strip("_")
        for c in sdf.columns
    ])

# Schema declared explicitly — Auto Loader cannot infer schema for Excel format.
# Column names must match the Excel header row exactly (normalisation applied after read).
# Inspected from: 20260401_000000_TimeOffReporting 04.26.xls
USA_ABS_SCHEMA = StructType([
    StructField("Employee Name",     StringType(),      True),
    StructField("Employee Id",       StringType(),      True),  # leading zeros — keep as string
    StructField("Supervisor",        StringType(),      True),
    StructField("Department",        StringType(),      True),
    StructField("Time Off Type",     StringType(),      True),
    StructField("Leave Status Desc", StringType(),      True),
    StructField("Time Off Start",    StringType(),      True),  # MM/DD/YYYY text
    StructField("Time Off End",      StringType(),      True),  # MM/DD/YYYY text
    StructField("Total Hours",       StringType(),      True),  # string while numeric in Excel
    StructField("Last Updated Date", StringType(),      True),  # MM/DD/YYYY text
])

# COMMAND ----------

# MAGIC %md
# MAGIC # SDP Table Definition

# COMMAND ----------

# MAGIC %md
# MAGIC ## `usa_abs_stack` — Landingzone streaming stack table

# COMMAND ----------

@dp.table(
    name=f"{LANDINGZONE_CATALOG}.{TARGET_SCHEMA}.{TARGET_TABLE}",
    comment=(
        "USA absences — append-only stack of all XLS files ingested from the "
        "landingzone_hr.manual_files.usa_abs volume. "
        "Each file is processed once by Auto Loader and its rows appended."
    ),
    table_properties={
        "quality": "landingzone",
        "delta.autoOptimize.optimizeWrite": "true",
        "pipelines.reset.allowed": "true",
    },
    cluster_by=["_meta_extraction_timestamp", "_meta_id"],
)
def usa_abs_stack():
    sdf = (
        spark.readStream
        .format("cloudFiles")
        .option("cloudFiles.format", "excel")
        .option("pathGlobFilter", "????????_??????_TimeOffReporting*.xls*")  # YYYYMMDD_HHmmss_TimeOffReporting*
        .option("cloudFiles.schemaEvolutionMode", "none")  # excel format doesn't support addNewColumns
        .option("headerRows", 1)
        .option("dataAddress", "Time Off Report!A1:J9999")  # A:J = 10 data cols, drops empty _c10+ cols
        .schema(USA_ABS_SCHEMA)
        .load(VOLUME_PATH)
    )

    sdf = _normalize_columns(sdf)

    # Extract extraction timestamp from filename pattern: YYYYMMDD_HHmmss_...
    extraction_ts = f.to_timestamp(
        f.regexp_extract(f.col("_metadata.file_name"), r"(\d{8}_\d{6})", 1),
        "yyyyMMdd_HHmmss",
    )

    # Meta columns first, then data columns (norm: _meta_* / data / _meta_validity_check)
    data_cols = [f.col(c) for c in sdf.columns]

    return (
        sdf
        .withColumn("_meta_id",                   f.concat_ws("-",
                                                   f.col("employee_id"),
                                                   f.col("time_off_start"),
                                                   f.col("time_off_end"),
                                                   f.col("total_hours"),
                                               ))
        .withColumn("_meta_extraction_timestamp",  extraction_ts)
        .withColumn("_meta_ingestion_timestamp",   f.current_timestamp())
        .withColumn("_meta_file_name",             f.col("_metadata.file_name"))
        .withColumn("_meta_file_mode",             f.lit("DELTA"))  # each file = one month's records only
        .withColumn("_meta_file_path",             f.col("_metadata.file_path"))
        .withColumn("_meta_validity_check", (
                f.col("employee_id").isNotNull() &
                f.col("time_off_start").isNotNull() &
                f.col("time_off_end").isNotNull() &
                f.col("total_hours").isNotNull()
        ))
        .filter(f.col("_meta_validity_check"))
        .select(
            f.col("_meta_id"),
            f.col("_meta_extraction_timestamp"),
            f.col("_meta_ingestion_timestamp"),
            f.col("_meta_file_name"),
            f.col("_meta_file_mode"),
            f.col("_meta_file_path"),
            *data_cols,
            f.col("_meta_validity_check"),
        )
    )
