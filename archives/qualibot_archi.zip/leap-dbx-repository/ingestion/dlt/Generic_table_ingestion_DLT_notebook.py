# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # GENERIC TABLE INGESTION PIPELINE
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to create a landingzone and bronze table for each kind of table received for a given pipeline_name
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC Know how to use DLT features
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Database table ingestion like HQA, ENC ...
# MAGIC
# MAGIC **Sample Input File**
# MAGIC - s3://leap-s3-raw-weeu1-{reference_read_env}/apps/horoquartz/YYYYMMDD_HHmmSS_HQA-{tablename}-{deltapattern}.csv
# MAGIC
# MAGIC **Sample Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_landingzone.{target_schema}.{tablename}_stack`
# MAGIC - `{pipeline_write_env}_bronze.{target_schema}.{tablename}_stack`
# MAGIC - `{pipeline_write_env}_bronze.{target_schema}.{tablename}_latest`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. Missing file archival when not in streaming mode, and modifiedAfter when in streaming mode
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import dlt
import pyspark.sql.functions as f
import fnmatch
from pyspark.sql import DataFrame as DataFrame
from pyspark.sql.window import Window
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    IntegerType,
    LongType,
    DoubleType,
    BooleanType,
    TimestampType,
    DateType,
)
from typing import Dict, List, Any
from delta.exceptions import ConcurrentAppendException
from functools import reduce

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.files import files_utils
from leap_utils.common import retry
from leap_utils.common.merge_into import merge_into_spark
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

pipeline_read_env_param = spark.conf.get("pipeline_read_env", "default_value")
pipeline_write_env_param = spark.conf.get("pipeline_write_env", "default_value")
reference_read_env_param = spark.conf.get("reference_read_env", "default_value")
pipeline_name_param = spark.conf.get("pipeline_name", "default_value")
landingzone_catalog_param = spark.conf.get("landingzone_catalog", "default_value")
bronze_catalog_param = spark.conf.get("bronze_catalog", "default_value")
target_schema_param = spark.conf.get("target_schema", "default_value")
log_level_param = spark.conf.get("log_level", "debug")
lowercase_columns_param = spark.conf.get("lowercase_columns", "true")

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", pipeline_write_env_param)
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", pipeline_read_env_param)
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", reference_read_env_param)
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_name", pipeline_name_param)
PIPELINE_NAME = dbutils.widgets.get("pipeline_name")

dbutils.widgets.text("landingzone_catalog", landingzone_catalog_param)
LANDINGZONE_CATALOG = dbutils.widgets.get("landingzone_catalog")

dbutils.widgets.text("bronze_catalog", bronze_catalog_param)
BRONZE_CATALOG = dbutils.widgets.get("bronze_catalog")

dbutils.widgets.text("target_schema", target_schema_param)
TARGET_SCHEMA = dbutils.widgets.get("target_schema")

dbutils.widgets.dropdown(
    "lowercase_columns",
    defaultValue=lowercase_columns_param,
    choices=["true", "false"],
)
LOWERCASE_COLUMNS = dbutils.widgets.get("lowercase_columns").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### LOG LEVEL
# MAGIC
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue=log_level_param,
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = setup_applevel_logger(
    log_level=LOG_LEVEL,
    file_log_level=LOG_LEVEL,
    log_format="%(asctime)s - %(name)s - %(levelname)s - %(funcName)s - %(message)s",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# Catched from DLT_PILOTAGE_TABLE in "Data Preparation" section

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

# Catched from DLT_PILOTAGE_TABLE in "Data Preparation" section

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

# Catched from DLT_PILOTAGE_TABLE in "Data Preparation" section

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# Catched from DLT_PILOTAGE_TABLE in "Data Preparation" section

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

# Catched from pipeline parameters
# A DLT pipeline ask for a target catalog and a target schema , here where need two catalogs but each time we use the same schema inside
LANDING_ZONE_CATALOG = LANDINGZONE_CATALOG
LANDING_ZONE_SCHEMA = TARGET_SCHEMA
BRONZE_CATALOG = BRONZE_CATALOG
BRONZE_SCHEMA = TARGET_SCHEMA

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

DLT_PILOTAGE_TABLE = f"{REFERENCE_READ_ENV}_bronze.data_quality.dlt_pilotage_table"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"DLT_PILOTAGE_TABLE is:  {DLT_PILOTAGE_TABLE}")
log.info(f"PIPELINE_NAME is:  {PIPELINE_NAME}")
log.info(f"LANDING_ZONE_CATALOG is:  {LANDING_ZONE_CATALOG}")
log.info(f"LANDING_ZONE_SCHEMA is:  {LANDING_ZONE_SCHEMA}")
log.info(f"BRONZE_CATALOG is:  {BRONZE_CATALOG}")
log.info(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------


def get_dlt_pipeline_structure(
    pipeline_name: str, pilotage_table: str = None
) -> Dict[str, Dict[str, Any]]:
    """
    Retrieves the table structure for processing in the DLT pipeline from the pilot table.

    :param pipeline_name: Name of the pipeline to filter.
    :type pipeline_name: str
    :param pilotage_table: Full name of the pilot table (schema.table).
    :type pilotage_table: str
    :return: A structured dictionary equivalent to FILES_ATTRS_DICT.
    :rtype: Dict[str, Dict[str, Any]]

    Example return format:
    {
        "1-atpeven": {
            "database_name": "hqaprod",
            "table_name": "atpeven",
            "stream_format": stream_format,
            "stacked_stream": True,
            "optional_bronze_stack": True,
            "file_format": "CSV",
            "file_keyword_simplified": "HQA-ATPEVEN",
            "file_regex": "regex_pattern",
            "file_mode": "FULL",
            "bucket_name": "s3-bucket-name",
            "file_prefix": "apps/horoquartz/",
            "archive_bucket_name": "s3-bucket-name",
            "archive_file_prefix": "apps/horoquartz/",
            "csv_delimiter": ";",
            "csv_header": True,
            "csv_escape_char": '"',
            "csv_quote_char": '"',
            "frequency": 1,
            "file_expected_cols": ["DATE_JOUR", "HEURE", "ORDRE", "MATRI", ...],
            "metadatas_cols": ["_meta_id", "_meta_extraction_timestamp", ...],
            "primary_key_cols": ["DATE_JOUR", "HEURE", "ORDRE", "MATRI"],
            "notnull_cols": "DATE_JOUR,HEURE,ORDRE,MATRI,CODE_EVENT,PROFIT,DIVISION,NOMPRE,CLE_POP,EVENMENT,DUREE_EVE,TPS_TOTAL,OPE",
            "column_types": {
                "DATE_JOUR": "DATE",
                "HEURE": "STRING",
                "ORDRE": "INTEGER",
                ...
            },
        },
        ...
    }
    """
    if pilotage_table is None:
        raise ValueError("The pilotage table must be provided.")

    # Read the pilot table
    try:
        df_pilotage: DataFrame = spark.read.table(pilotage_table)
    except Exception as e:
        log.error(f"Error reading pilotage table {pilotage_table}: {e}")
        raise

    # Filter for the relevant pipeline
    df_pilotage = df_pilotage.filter(f.col("pipeline_name") == PIPELINE_NAME)
    if df_pilotage.isEmpty():
        log.warning(
            f"No records found for pipeline: {PIPELINE_NAME} . Please populate correctly the pilotage table."
        )

    # Initialize the final dictionary
    files_attrs_dict: Dict[str, Dict[str, Any]] = {}

    # Convert DataFrame rows into dictionary format
    for row in df_pilotage.collect():
        id: str = row["id"]
        database_name: str = row["database_name"]
        table_name: str = row["table_name"]
        stream_format: str = row["stream_format"]
        stacked_stream: bool = row["stacked_stream"]
        optional_bronze_stack: bool = row["optional_bronze_stack"]
        file_format: str = row[
            "file_format"
        ].upper()  # Ensure uppercase format (CSV, JSON, etc.)
        file_keyword_simplified: str = row["file_keyword_simplified"]
        file_regex: str = row["file_regex"]
        file_mode: str = row["file_mode"]
        csv_delimiter: str = row.asDict().get("csv_delimiter", ";")
        csv_header: bool = row["csv_header"]
        csv_escape_char: str = row.asDict().get("csv_escape_char", '"')
        csv_quote_char: str = row.asDict().get("csv_quote_char", '"')
        frequency: int = row["frequency"]
        bucket_name_template = row["bucket_name"]
        bucket_name = bucket_name_template.format(REFERENCE_READ_ENV=REFERENCE_READ_ENV)
        file_prefix: str = row["file_prefix"]
        archive_bucket_name_template = row["archive_bucket_name"]
        archive_bucket_name = archive_bucket_name_template.format(
            PIPELINE_WRITE_ENV=PIPELINE_WRITE_ENV
        )
        archive_file_prefix: str = row["archive_file_prefix"]
        table_tags = row.asDict().get("table_tags", {})
        column_tags = row.asDict().get("column_tags", {})

        # Extract column details
        columns = row["columns"]
        file_expected_cols = [
            col["column_name"] for col in columns if col["is_expected"]
        ]
        primary_key_cols = [
            col["column_name"] for col in columns if col["is_primary_key"]
        ]
        notnull_cols = [
            col["column_name"] for col in columns if not col["null_allowed"]
        ]

        # Mapping Databases types to Databricks
        SQL_TO_DLT_TYPE_MAPPING = {
            "jsonb": "STRING",
            "json": "STRING",
            "clob": "STRING",
            "character varying": "STRING",
            "varchar": "STRING",
            "varchar2": "STRING",
            "nvarchar": "STRING",
            "text": "STRING",
            "ntext": "STRING",
            "char": "STRING",
            "nchar": "STRING",
            "tinyint": "INT",
            "smallint": "INT",
            "int": "INT",
            "integer": "INT",
            "mediumint": "INT",
            "bigint": "BIGINT",
            "long": "BIGINT",
            "decimal": "DOUBLE",
            "numeric": "DOUBLE",
            "real": "DOUBLE",
            "float": "DOUBLE",
            "double": "DOUBLE",
            "double precision": "DOUBLE",
            "number": "DOUBLE",  # Oracle's generic numeric
            "bit": "BOOLEAN",  # SQL Server
            "boolean": "BOOLEAN",
            "bool": "BOOLEAN",
            "date": "DATE",
            "datetime": "TIMESTAMP",
            "timestamp": "TIMESTAMP",
            "timestamp without time zone": "TIMESTAMP",
            "timestamp with time zone": "TIMESTAMP",
            "smalldatetime": "TIMESTAMP",
        }

        # Clean up column types
        column_types = {
            col["column_name"]: SQL_TO_DLT_TYPE_MAPPING.get(
                col["column_type"].lower(), "STRING"
            )
            for col in columns
        }

        # Store table attributes in the dictionary
        key = f"{id}_{table_name}"
        files_attrs_dict[key] = {
            "database_name": database_name,
            "table_name": table_name,
            "stream_format": stream_format,
            "stacked_stream": stacked_stream,
            "optional_bronze_stack": optional_bronze_stack,
            "file_format": file_format,
            "file_keyword_simplified": file_keyword_simplified,
            "file_regex": file_regex,
            "file_mode": file_mode,
            "bucket_name": bucket_name,
            "file_prefix": file_prefix,
            "archive_bucket_name": archive_bucket_name,
            "archive_file_prefix": archive_file_prefix,
            "csv_delimiter": csv_delimiter,
            "csv_header": csv_header,
            "csv_escape_char": csv_escape_char,
            "csv_quote_char": csv_quote_char,
            "file_expected_cols": file_expected_cols,
            "metadatas_cols": [
                "_meta_id",
                "_meta_extraction_timestamp",
                "_meta_ingestion_timestamp",
                "_meta_file_name",
                "_meta_file_mode",
                "_meta_file_path",
            ],
            "primary_key_cols": primary_key_cols,
            "notnull_cols": ",".join(notnull_cols),  # Convert to comma-separated string
            "column_types": column_types,
            "frequency": frequency,
            "table_tags": table_tags,
            "column_tags": column_tags,
        }

    return files_attrs_dict


# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Load pipeline strcture from delta table {DLT_PILOTAGE_TABLE}

# COMMAND ----------

# Get dictionary structure from delta table
FILES_ATTRS_DICT = get_dlt_pipeline_structure(PIPELINE_NAME, DLT_PILOTAGE_TABLE)
log.info(f"FILES_ATTRS_DICT: {FILES_ATTRS_DICT}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations and output
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------


def spark_type_from_str(type_str: str):
    """
    Maps a string representation of a data type to a corresponding PySpark data type.

    :param type_str: A string representing the data type (e.g., "string", "int", "timestamp").
    :type type_str: str

    :return: A PySpark data type corresponding to the input string. Defaults to StringType if unrecognized.
    :rtype: pyspark.sql.types.DataType
    """
    mapping = {
        "string": StringType(),
        "int": IntegerType(),
        "integer": IntegerType(),
        "bigint": LongType(),
        "long": LongType(),
        "double": DoubleType(),
        "float": DoubleType(),
        "boolean": BooleanType(),
        "timestamp": TimestampType(),
        "date": DateType(),
    }
    return mapping.get(type_str.lower(), StringType())


def get_spark_schema(
    column_types: Dict[str, str], metadatas_cols: List[str]
) -> StructType:
    """
    Builds a Spark StructType schema including metadata columns (first) and user-defined data columns.

    :param column_types: Dictionary mapping column names to their data types as strings.
    :type column_types: Dict[str, str]
    :param metadatas_cols: List of metadata column names to prepend to the schema.
    :type metadatas_cols: List[str]
    :return: Spark StructType schema with metadata fields followed by actual table fields.
    :rtype: StructType

    Example:
    >>> get_spark_schema({"ORDRE": "int", "HEURE": "string"}, ["_meta_id", "_meta_timestamp"])
    StructType([...])
    """
    fields = []

    # Add metadata columns first (default to StringType) and actual table columns with declared types
    fields = [
        StructField(meta_col, StringType(), True) for meta_col in metadatas_cols
    ] + [
        StructField(col_name, spark_type_from_str(type_str), True)
        for col_name, type_str in column_types.items()
    ]  # True = nullable

    return StructType(fields)


def is_any_file(folder_path: str, pattern: str) -> bool:
    """
    Check if any file in the specified folder contains the given keyword in its name.

    :param folder_path: The path of the folder to check for files.
    :type folder_path: str
    :param pattern: A regex pattern to match file names (e.g., r'.*MES-tool-.*\.parquet').
    :type pattern: str
    :return: True if at least one file containing the keyword is found, False otherwise.
    :rtype: bool

    :raises Exception: If an error occurs while accessing the folder.
    """
    try:
        # Check folder_path
        file_list = dbutils.fs.ls(folder_path)
        files_exist = False
        if len(file_list) > 0:
            for file in file_list:
                if fnmatch.fnmatch(file.name, pattern):
                    files_exist = True
                    log.debug(
                        f"First file found in path {folder_path} matching regex {pattern}:  {file.name}"
                    )
                    return files_exist
    except Exception as e:
        # Si le dossier n'existe pas du tout, on suppose qu'il est vide
        files_exist = False
        log.debug(
            f"No files found in path {folder_path} with regex {pattern}: {str(e)}"
        )

    return files_exist


def log_df_count(batch_df, batch_id, message=""):
    """
    Log the number of rows in each micro-batch with a custom message.

    :param batch_df: The batch DataFrame.
    :param batch_id: The batch ID.
    :param message: Custom message for logging.
    """
    log.info(
        f"Batch {batch_id} - {message} - {batch_df.count()=}"
    )  # Nb rows in the micro-batch


def get_raw_data(attr_dict: Dict[str, Dict[str, Any]], table_id: str) -> DataFrame:
    """
    Generic function to load and transform data based on the table type.

    :param attr_dict: A structured dictionary containing attributes for data loading.
    :type attr_dict: Dict[str, Dict[str, Any]]
    :param table_id: The id of table (e.g., "atpeven", "other_table").
    :type table_id: str

    :return: A filtered DataFrame with transformed data.
    :rtype: DataFrame
    """
    # Get input parameters
    log.info(f"Available keys in attr_dict: {list(attr_dict.keys())}")
    log.info(f"Values in attr_dict: {attr_dict}")
    table_name = attr_dict["table_name"]

    # Expression for Globfilter
    glob_filter = attr_dict["file_keyword_simplified"]

    stream_format = attr_dict["stream_format"]
    stacked_stream = attr_dict["stacked_stream"]

    # Récupère les attributs spécifiques aux colonnes
    primary_key_cols = [col.lower() for col in attr_dict["primary_key_cols"]]
    expected_cols = [col.lower() for col in attr_dict["file_expected_cols"]]
    metadatas_cols = [col.lower() for col in attr_dict["metadatas_cols"]]
    not_null_cols = [col.lower() for col in attr_dict["notnull_cols"].split(",")]
    column_types = attr_dict["column_types"]

    if stream_format == "file":
        bucket_name = attr_dict["bucket_name"]
        file_prefix = attr_dict["file_prefix"]
        file_format = attr_dict["file_format"].lower()
        input_path = f"s3://{bucket_name}/{file_prefix}"
        log.info(f"Input path : {input_path}")

        archive_bucket_name = attr_dict["archive_bucket_name"]
        archive_file_prefix = attr_dict["archive_file_prefix"]
        archive_path = f"s3://{archive_bucket_name}/{archive_file_prefix}"
        log.info(f"archive path : {archive_path}")

        path_glob_filter = f"*{glob_filter}*.{file_format.lower()}"
        log.info(f"Filtering files with path_glob_filter : {path_glob_filter}")
        file_regex = attr_dict["file_regex"]
        if file_format == "csv":
            csv_delimiter = attr_dict["csv_delimiter"]
            csv_header = (
                "true" if attr_dict["csv_header"] else "false"
            )  # Convert boolean to string
            csv_escape_char = attr_dict["csv_escape_char"]
            csv_quote_char = attr_dict["csv_quote_char"]
        elif file_format == "parquet":
            csv_header = "false"
        else:
            raise ValueError(
                "Invalid file format. Only 'csv' and 'parquet' formats supported."
            )
        # Check if file exist in the bucket
        files_exist = is_any_file(input_path, path_glob_filter)

        if stacked_stream:
            # Read streaming files from input_path
            df_raw = (
                spark.readStream.format("cloudFiles")
                .option("cloudFiles.format", file_format)
                .option("header", csv_header)
                # .option("cloudFiles.useManagedFileEvents", "true")
                .option("cloudFiles.includeExistingFiles", "true")
                .option("cloudFiles.useIncrementalListing", "true")
                .option("cloudFiles.allowOverwrites", "true")
                # .option("cloudFiles.cleanSource", "MOVE")
                # .option("cloudFiles.cleanSource.retentionDuration", "7 days")
                # .option(
                #     "cloudFiles.cleanSource.moveDestination",
                #     archive_path,
                # )
                # .option("cloudFiles.validateOptions", "false")
                .option("pathGlobfilter", path_glob_filter)
            )
        else:
            # Read files from input_path
            df_raw = (
                spark.read.format(file_format)
                .option("header", csv_header)
                .option("pathGlobfilter", path_glob_filter)
            )

        # Add CSV-specific options
        if file_format == "csv":
            df_raw = (
                df_raw.option("delimiter", csv_delimiter)
                .option("escape", csv_escape_char)
                .option("quote", csv_quote_char)
                .option("multiLine", "true")
            )

        if files_exist:
            print(
                f"***{table_name} - Files exist in path {input_path} - infering schema"
            )
            df_raw = df_raw.option("inferSchema", "true").option("mergeSchema", "true")
        else:
            print(
                f"***{table_name} - Files doesn't exist in path {input_path} - defining schema"
            )
            df_raw = (
                df_raw.schema(
                    get_spark_schema(
                        column_types=column_types, metadatas_cols=metadatas_cols
                    )
                )
                .option("inferSchema", "false")
                .option("mergeSchema", "true")
            )
    else:
        raise ValueError(
            "Invalid stream format. Only 'file' stream format supported currently. Others coming."
        )

    # Load files and filter those matching the regex
    df_raw = df_raw.load(input_path)

    # Logging df.count()
    if stacked_stream:
        custom_message = f"Processing table {table_id} - After df_raw.load() "
        log.debug(custom_message)
        # df_stream = (
        #     df_raw.writeStream.foreachBatch(
        #         partial(log_df_count, message=custom_message)
        #     )
        #     .outputMode("append")
        #     .start()
        # )

    # Cleanup column names (unicode-aware: transliterates accents to ASCII)
    rename_dict = {col: table_utils._cleanup_column_name_unicode(col) for col in df_raw.columns}
    for old_name, new_name in rename_dict.items():
        df_raw = df_raw.withColumnRenamed(old_name, new_name)

    if LOWERCASE_COLUMNS:
        df_raw = df_raw.toDF(*[c.lower() for c in df_raw.columns])

    if not LOWERCASE_COLUMNS:
        # dictionnaire {lower(df_col): df_col_original}
        colmap_real = {c.lower(): c for c in df_raw.columns}

        def resolve_col_name(lower_name: str) -> str:
            # renvoie le vrai nom de colonne (respecte la casse initiale) si présent, sinon le nom passé
            return colmap_real.get(lower_name, lower_name)

        # Remapper les listes pilotées (déjà en minuscule) vers les noms réels du DF
        primary_key_cols = [resolve_col_name(c) for c in primary_key_cols]
        expected_cols = [resolve_col_name(c) for c in expected_cols]
        metadatas_cols = [resolve_col_name(c) for c in metadatas_cols]
        not_null_cols = [resolve_col_name(c) for c in not_null_cols]

        # Adapter column_types : clés minuscule -> clés réelles
        column_types = {resolve_col_name(k.lower()): v for k, v in column_types.items()}

    # Check existing columns in DataFrame
    existing_cols = set(df_raw.columns)

    # Check missing columns
    missing_cols = set(expected_cols) - existing_cols
    missing_cols_expr = f.lit(False) if missing_cols else f.lit(True)

    # Cast Types
    # for col_name, col_type in column_types.items():
    #     col_name_lower = col_name.lower()
    #     if col_name_lower in existing_cols:
    #         if col_type == "timestamp":
    #             df_raw = df_raw.withColumn(
    #                 col_name_lower,
    #                 f.to_timestamp(f.col(col_name_lower)),
    #             )
    #         elif col_type == "date":
    #             df_raw = df_raw.withColumn(
    #                 col_name_lower, f.to_date(f.col(col_name_lower))
    #             )
    #         else:
    #             df_raw = df_raw.withColumn(
    #                 col_name_lower, f.col(col_name_lower).cast(col_type)
    #             )

    for col_name, col_type in column_types.items():
        # col_name est déjà "réel" si LOWERCASE_COLUMNS==False (grâce au remapping plus haut),
        # et il est en minuscule si LOWERCASE_COLUMNS==True.
        target_col = col_name if not LOWERCASE_COLUMNS else col_name.lower()

        if target_col in existing_cols:
            if col_type == "timestamp":
                df_raw = df_raw.withColumn(
                    target_col, f.to_timestamp(f.col(target_col))
                )
            elif col_type == "date":
                df_raw = df_raw.withColumn(target_col, f.to_date(f.col(target_col)))
            else:
                df_raw = df_raw.withColumn(target_col, f.col(target_col).cast(col_type))

    # build validity check expression
    valid_not_null_cols = [col for col in not_null_cols if col in existing_cols]
    not_null_expr = (
        f.expr(" AND ".join([f"{col} IS NOT NULL" for col in valid_not_null_cols]))
        if valid_not_null_cols
        else f.lit(True)
    )
    validity_check_expr = missing_cols_expr & not_null_expr

    # Expression pour créer l'ID de métadonnées basé sur les clés primaires
    meta_id_expr = (
        f.concat_ws("-", *[f.col(c) for c in primary_key_cols])
        if primary_key_cols
        else f.sha2(f.concat_ws("-", *df_raw.columns), 256)
    )

    # Add metadatas columns
    df_meta = (
        df_raw.withColumn("_meta_id", meta_id_expr)
        .withColumn(
            "_meta_extraction_timestamp",
            f.to_timestamp(
                f.regexp_extract(f.col("_metadata.file_path"), r"(\d{8}_\d{6})", 1),
                "yyyyMMdd_HHmmss",
            ),
        )
        .withColumn("_meta_ingestion_timestamp", f.current_timestamp())
        .withColumn(
            "_meta_file_name",
            f.regexp_extract(f.col("_metadata.file_path"), r"([^/]+)$", 1),
        )
        .withColumn(
            "_meta_file_mode",
            f.when(
                f.regexp_extract(f.col("_meta_file_name"), r"-(\w+)\.(csv|parquet)$", 1)
                == "F",
                "FULL",
            ).otherwise("DELTA"),
        )
        .withColumn("_meta_file_path", f.col("_metadata.file_path"))
        .withColumn("_meta_validity_check", validity_check_expr)
    )

    # Get non metadata columns
    data_cols = [col for col in df_meta.columns if col not in metadatas_cols]

    # Reorder columns
    df_reordered = df_meta.select(*(metadatas_cols + data_cols))

    # Apply a filter to keep files matching the file_regex
    df_filtered = df_reordered.filter(f.col("_meta_file_name").rlike(file_regex))
    log.info(f"Filtering files with regex : {file_regex}")

    # Logging df.count()
    if stacked_stream:
        custom_message = f"Processing table {table_id} - After df_reordered.filter() "
        log.debug(custom_message)
        # df_stream = (
        #     df_filtered.writeStream.foreachBatch(
        #         partial(log_df_count, message=custom_message)
        #     )
        #     .outputMode("append")
        #     .start()
        # )

    # Return result
    return df_filtered


# COMMAND ----------


def _normalize_table_tags_for_uc(table_tags: dict | None) -> dict[str, str]:
    """
    Normalize table-level tags into Unity Catalog table properties.

    This helper converts a dictionary of tags defined as ``{key: value | None}``
    into a dictionary of Unity Catalog-compatible table properties of the form
    ``{"tag.<key>": "<value>"}``, typically used during table or DLT creation.

    Tags with a ``None`` value (key-only tags) cannot be expressed via
    ``table_properties`` and are therefore ignored by this function.
    Such tags must be applied later using
    ``ALTER TABLE ... SET TAGS ('key')``.

    All non-None tag values are cast to strings.

    :param table_tags:
        Dictionary of table tags where values may be strings or ``None``.
        If ``None`` or empty, no properties are generated.
    :type table_tags: dict | None

    :return:
        A dictionary of Unity Catalog table properties prefixed with ``"tag."``.
        Only tags with non-None values are included.
    :rtype: dict[str, str]
    """
    if not table_tags:
        return {}
    props = {}
    for k, v in table_tags.items():
        if v is None:
            # key-only tag: impossible à exprimer dans table_properties
            # On le gérera après création avec un ALTER TABLE SET TAGS ('key')
            continue
        props[f"tag.{k}"] = str(v)
    return props


def get_latest_view_from_stack(
    df_stack: DataFrame, primary_key_cols: list[str], file_mode: str
) -> DataFrame:
    """
    Get the latest view from the stack DataFrame based on the file mode.

    :param df_stack: The stack DataFrame containing the data.
    :type df_stack: DataFrame
    :param primary_key_cols: List of primary key column names.
    :type primary_key_cols: list[str]
    :param file_mode: The file mode, either "FULL" or other.
    :type file_mode: str
    :return: A DataFrame with the latest view based on the file mode.
    :rtype: DataFrame
    """
    if file_mode == "FULL":
        max_ts_ext = df_stack.agg(
            f.max("_meta_extraction_timestamp").alias("max_extraction_timestamp")
        )
        max_ts_ing = df_stack.agg(
            f.max("_meta_ingestion_timestamp").alias("max_ingestion_timestamp")
        )
        df_latest = (
            df_stack.join(
                max_ts_ext,
                df_stack["_meta_extraction_timestamp"]
                == max_ts_ext["max_extraction_timestamp"],
                "inner",
            )
            .join(
                max_ts_ing,
                df_stack["_meta_ingestion_timestamp"]
                == max_ts_ing["max_ingestion_timestamp"],
                "inner",
            )
            .drop("max_extraction_timestamp", "max_ingestion_timestamp")
        )
    else:
        df_latest = table_utils.drop_duplicates_by_order(
            df=df_stack,
            columns=primary_key_cols,
            order_col=["_meta_extraction_timestamp", "_meta_ingestion_timestamp"],
            keep="last",
        )
    return df_latest


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - DLT Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------


def create_dlt_stack_tables(table_id, attrs):
    """
    Create a DLT stack table for the specified table type and attributes.

    :param table_id: The id of table (e.g., "atpeven", "other_table").
    :type table_id: str
    :param attrs: A dictionary containing attributes for the table.
    :type attrs: dict
    """
    table_name = attrs["table_name"]
    log.info(f"Table name for table_id {table_id} is {table_name}")

    base_props = {"quality": "landingzone"}
    tag_props = _normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    @dlt.table(
        name=f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}_stack",
        comment="landingzone stack table",
        # table_properties={"quality": "landingzone"},  # "delta.appendOnly": "true"
        table_properties=table_props,
        cluster_by=["_meta_extraction_timestamp", "_meta_id"],
    )
    def table_stack():
        df = get_raw_data(attr_dict=attrs, table_id=table_id)
        return df


# COMMAND ----------


def create_dlt_stack_view(table_id, attrs):
    """
    Create a DLT stack view for the specified table type and attributes.

    :param table_id: The id of table (e.g., "atpeven", "other_table").
    :type table_id: str
    :param attrs: A dictionary containing attributes for the table.
    :type attrs: dict
    """
    table_name = attrs["table_name"]
    log.info(f"Table name for table_id {table_id} is {table_name}")

    @dlt.view(
        name=f"{table_name}_stack",
        comment="landingzone stack view",
    )
    def view_stack():
        df = get_raw_data(attr_dict=attrs, table_id=table_id)
        return df


# COMMAND ----------


def create_dlt_view_for_stack_tables(table_id, attrs):
    """
    Create a DLT materialized view for the specified stack table type and attributes.

    :param table_id: The id of table (e.g., "atpeven", "other_table").
    :type table_id: str
    :param attrs: A dictionary containing attributes for the table.
    :type attrs: dict
    """
    table_name = attrs["table_name"]

    base_props = {"quality": "bronze"}
    tag_props = _normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    @dlt.table(
        name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_stack",
        comment="bronze stack view",
        table_properties=table_props,
        cluster_by=["_meta_extraction_timestamp", "_meta_id"],
    )
    def table_stack():
        # read streaming table and return
        df_stack = dlt.read(
            f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}_stack"
        )
        return df_stack


# COMMAND ----------


def create_latest_dlt_view_for_stack_tables(table_id, attrs):
    """
    Create a DLT materialized view for the latest stack table type and attributes.

    :param table_id: The id of table (e.g., "atpeven", "other_table").
    :type table_id: str
    :param attrs: A dictionary containing attributes for the table.
    :type attrs: dict
    :param attrs.table_name: The name of the table.
    :type attrs.table_name: str
    :param attrs.primary_key_cols: List of primary key columns.
    :type attrs.primary_key_cols: list
    :param attrs.file_mode: The mode of the file (e.g., "FULL", "INCREMENTAL").
    :type attrs.file_mode: str
    """
    table_name = attrs["table_name"]

    if LOWERCASE_COLUMNS:
        primary_key_cols = [col.lower() for col in attrs["primary_key_cols"]]
    else:
        primary_key_cols = attrs["primary_key_cols"]

    if len(primary_key_cols) == 0:
        primary_key_cols = ["_meta_id"]
    file_mode = attrs["file_mode"]

    base_props = {"quality": "bronze"}
    tag_props = _normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    @dlt.table(
        name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest",
        comment="bronze latest view",
        table_properties=table_props,
        cluster_by=["_meta_id"],
    )
    def table_latest():
        # read stack table
        df_stack = dlt.read(
            f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}_stack"
        )
        df_latest = get_latest_view_from_stack(df_stack, primary_key_cols, file_mode)
        return df_latest


# COMMAND ----------


def create_latest_dlt_view_for_stack_view(table_id, attrs):
    """
    Create a DLT materialized view for the latest stack view type and attributes.

    :param table_id: The id of table (e.g., "atpeven", "other_table").
    :type table_id: str
    :param attrs: A dictionary containing attributes for the table.
    :type attrs: dict
    :param attrs.table_name: The name of the table.
    :type attrs.table_name: str
    :param attrs.primary_key_cols: List of primary key columns.
    :type attrs.primary_key_cols: list
    :param attrs.file_mode: The mode of the file (e.g., "FULL", "INCREMENTAL").
    :type attrs.file_mode: str
    """
    table_name = attrs["table_name"]

    if LOWERCASE_COLUMNS:
        primary_key_cols = [col.lower() for col in attrs["primary_key_cols"]]
    else:
        primary_key_cols = attrs["primary_key_cols"]

    if len(primary_key_cols) == 0:
        primary_key_cols = ["_meta_id"]
    file_mode = attrs["file_mode"]

    base_props = {"quality": "bronze"}
    tag_props = _normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    @dlt.table(
        name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest",
        comment="bronze latest view",
        table_properties=table_props,
        cluster_by=["_meta_id"],
    )
    def table_latest():
        # read stack table
        df_stack = dlt.read(f"{table_name}_stack")
        df_latest = get_latest_view_from_stack(df_stack, primary_key_cols, file_mode)
        return df_latest


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Process stack level
# MAGIC - create streaming table from files
# MAGIC - or just a temporary view

# COMMAND ----------

for table_id, attrs in FILES_ATTRS_DICT.items():
    stacked_stream = attrs["stacked_stream"]
    if stacked_stream:
        # Need to load files into a streaming table
        log.info(f"Creating stack streaming table for table_id {table_id}")
        create_dlt_stack_tables(table_id=table_id, attrs=attrs)
    else:
        # Need to load files into a temporary view
        log.info(f"Creating a temporary view for table_id {table_id}")
        create_dlt_stack_view(table_id=table_id, attrs=attrs)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - create materialized view from streaming table
# MAGIC - Optional stack materialized view in bronze catalog

# COMMAND ----------

for table_id, attrs in FILES_ATTRS_DICT.items():
    table_name = attrs["table_name"]

    # ❌ Skip talend_job_summary
    if table_name == "talend_job_summary":
        continue

    stacked_stream = attrs["stacked_stream"]
    optional_bronze_stack = attrs["optional_bronze_stack"]
    if stacked_stream and optional_bronze_stack:
        log.info(f"Creating stack view for table_id {table_id}")
        # Need to have a view for the stack table
        create_dlt_view_for_stack_tables(table_id=table_id, attrs=attrs)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - create latest materialized view
# MAGIC

# COMMAND ----------

for table_id, attrs in FILES_ATTRS_DICT.items():
    table_name = attrs["table_name"]

    # ❌ Skip talend_job_summary
    if table_name == "talend_job_summary":
        continue

    log.info(f"Creating latest materialized view for table_id {table_id}")
    stacked_stream = attrs["stacked_stream"]
    if stacked_stream:
        # Need to materialize latest from streaming table
        create_latest_dlt_view_for_stack_tables(table_id=table_id, attrs=attrs)
    else:
        # Need to materialize latest from view
        create_latest_dlt_view_for_stack_view(table_id=table_id, attrs=attrs)

# COMMAND ----------

# MAGIC %md
# MAGIC # Archiving

# COMMAND ----------

# To be Defined Later
# Archiving cause an issue to streaming data source when input folder is empty

# COMMAND ----------

# MAGIC %md
# MAGIC ## Archiving - Common Functions
# MAGIC

# COMMAND ----------


def archive_processed_files(table_id: str, attrs: dict) -> None:
    """
    Archive processed files for a given table.

    This function identifies files that have been processed and archives them from the input S3 bucket to the archive S3 bucket.
    It creates a Delta Table to track the archived filenames.

    :param table_id: The identifier of the table.
    :type table_id: str
    :param attrs: Attributes of the table including bucket names, file prefixes, and table name.
    :type attrs: dict
    """
    table_name = attrs["table_name"]
    global file_error_list

    @dlt.view(
        name=f"{table_name}_archived_filenames",
        comment=f"{table_name}_archived_filenames",
    )
    def update_archived_files_and_archive():
        # Get bucket_name and file_prefix
        bucket_name = attrs["bucket_name"]
        file_prefix = attrs["file_prefix"]
        archive_bucket_name = attrs["archive_bucket_name"]
        archive_file_prefix = attrs["archive_file_prefix"]
        input_path = f"s3://{bucket_name}/{file_prefix}"

        source_latest_table = f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest"
        source_stack_table = f"{table_name}_stack"
        target_table = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}_archived_filenames"

        # read latest table and return filenames
        df_latest_files_to_archive = (
            dlt.read(source_latest_table)
            .select(
                "_meta_file_name",
                "_meta_extraction_timestamp",
                "_meta_ingestion_timestamp",
            )
            .distinct()
        )
        df_stack_files = (
            dlt.read(source_stack_table)
            .select(
                "_meta_file_name",
                "_meta_extraction_timestamp",
                "_meta_ingestion_timestamp",
            )
            .distinct()
        )
        df_latest_files_to_archive = df_latest_files_to_archive.unionByName(
            df_stack_files
        ).dropDuplicates(["_meta_file_name"])

        if table_utils.UnityCatalogCheckTableExists(DbxTablePath=target_table):
            retry.retry(
                func=merge_into_spark._merge_into_python,
                exceptions=(ConcurrentAppendException,),
                df_source=df_latest_files_to_archive,
                target_table=target_table,
                list_id_matching_columns=["_meta_file_name"],
            )
        else:
            df_latest_files_to_archive.write.mode("overwrite").format(
                "delta"
            ).saveAsTable(target_table)

        df_all_files = spark.read.table(target_table)
        window_spec = Window.orderBy(
            f.col("_meta_extraction_timestamp").desc(),
            f.col("_meta_ingestion_timestamp").desc(),
        )
        df_with_rn = df_all_files.withColumn("rn", f.row_number().over(window_spec))
        df_to_archive = df_with_rn.filter(f.col("rn") > 1).drop("rn")

        # list files in input path
        try:
            s3_files = dbutils.fs.ls(input_path)
        except Exception as e:
            log.error(f"Error accessing S3 path {input_path}: {e}")
            return spark.createDataFrame([], "string").toDF("_meta_file_name")

        if not s3_files:
            log.warning(f"No file found in {input_path}")
            return spark.createDataFrame([], "string").toDF("_meta_file_name")

        # create dataframe from S3 files
        df_s3_files = (
            spark.createDataFrame(s3_files)
            .select("name")
            .withColumnRenamed("name", "_meta_file_name")
        )

        df_to_archive = df_to_archive.join(
            df_s3_files, on="_meta_file_name", how="inner"
        )

        # Intersect the two lists to get common files
        files_to_archive = [row["_meta_file_name"] for row in df_to_archive.collect()]
        log.debug(f"Files to archive for table {table_name} : {files_to_archive}")

        # archive files
        archived_files = []
        for file_name in files_to_archive:
            try:
                status = files_utils.archive_file(
                    bucket_name,
                    file_prefix,
                    archive_bucket_name,
                    archive_file_prefix,
                    file_name,
                )
                archived_files.append((file_name,))
                log.info(
                    f"File {file_name} archived successfully for table {table_name}."
                )
            except OSError as e:
                log.error(
                    f"File {file_name} has not been archived, an error occurred during archiving.\nException is :{e}\n"
                )
                file_error_list.append(file_name)
                is_error_detected = True

        if file_error_list:
            log.error(
                f"Archiving failed for the following files: {file_error_list} for table {table_name}"
            )

        if not archived_files:
            return spark.createDataFrame([], "string").toDF("_meta_file_name")
        else:
            df_archived_files = spark.createDataFrame(
                archived_files, ["_meta_file_name"]
            )

        return df_archived_files


# COMMAND ----------

# MAGIC %md
# MAGIC ## Archiving - Files

# COMMAND ----------

# archive input files for processed files in streaming table
global file_error_list
global is_error_detected
file_error_list = []
is_error_detected = False

for table_id, attrs in FILES_ATTRS_DICT.items():
    table_name = attrs["table_name"]

    # ❌ Skip talend_job_summary
    if table_name == "talend_job_summary":
        continue

    stacked_stream = attrs["stacked_stream"]
    if not stacked_stream:
        # No need to archive when in streaming mode, but recommended in classic read mode because modifiedAfter is not supported and we don't want to read a huge number of old files
        log.info(f"Archiving files for table_type {table_id}")
        archive_processed_files(table_id, attrs)

if is_error_detected:
    error_list = set(file_error_list)
    log.critical(
        f"An error has been detected for at least one table(s) in : {error_list} see above !"
    )
    raise AssertionError()

# COMMAND ----------

# MAGIC %md
# MAGIC # Freshness

# COMMAND ----------

freshness_view_names = []


def create_freshness_view(
    source_table, table_name_short, frequency, schema_name, job_name, view_name
):
    @dlt.view(name=view_name)
    def _generated_view():
        return (
            dlt.read(source_table)
            .agg(
                f.max("_meta_ingestion_timestamp").alias("last_update_time"),
            )
            .withColumn("frequency", f.lit(frequency).cast("int"))
            .withColumn("schema_name", f.lit(schema_name))
            .withColumn("job_name", f.lit(job_name))
            .withColumn("table_name", f.lit(source_table))
            .withColumn("table_name_short", f.lit(table_name_short))
        )

    return _generated_view  # return is optional in this case


for table_id, attrs in FILES_ATTRS_DICT.items():
    table_name = attrs["table_name"]

    # ❌ Skip talend_job_summary
    if table_name == "talend_job_summary":
        continue

    frequency = attrs["frequency"]
    view_name = f"{table_name}_freshness"
    source_table = f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest"

    freshness_view_names.append(f"LIVE.{view_name}")

    # Appel pour générer une nouvelle vue avec nom unique (chaque appel génère une nouvelle fonction)
    create_freshness_view(
        source_table=source_table,
        table_name_short=table_name,
        frequency=frequency,
        schema_name=BRONZE_SCHEMA,
        job_name=PIPELINE_NAME,
        view_name=view_name,
    )


@dlt.view(
    name="freshness_all_temp",
    comment="update_freshness_for_all_schema temp view",
)
def update_freshness_all_temp():
    dfs = [spark.table(name) for name in freshness_view_names]
    return reduce(lambda a, b: a.unionByName(b), dfs)


@dlt.table(
    name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{PIPELINE_NAME}_freshness_all",
    comment="update_freshness_for_schema",
)
def update_freshness_all():

    df_freshness = dlt.read("freshness_all_temp")

    # --- Lire talend_job_summary_stack si elle existe ---
    try:
        df_tjs = (
            dlt.read("talend_job_summary_stack")
            .withColumn(
                "table_name_short",
                f.regexp_extract(
                    f.col("nomfichier"), r"^\d{8}_\d{6}_[^-]+-([^-]+).*", 1
                ),
            )
            .select(
                f.col("_meta_extraction_timestamp").alias("last_pipeline_ts"),
                "table_name_short",
                f.col("nbrlignes").alias("last_row_count"),
            )
        )
        df_latest_tjs = table_utils.drop_duplicates_by_order(
            df=df_tjs,
            columns=["table_name_short"],
            order_col=["last_pipeline_ts"],
            keep="last",
        )
    except:
        return df_freshness

    # --- Join sur last_file_name ---
    df_joined = df_freshness.join(df_latest_tjs, on="table_name_short", how="left")

    # si last_row_count == 0 → override
    df_final = (
        df_joined.withColumn(
            "last_update_time",
            f.when(f.col("last_row_count") == 0, f.col("last_pipeline_ts")).otherwise(
                f.col("last_update_time")
            ),
        )
        .filter(f.col("last_update_time").isNotNull())
        .drop("last_pipeline_ts", "last_row_count", "table_name_short")
    )

    return df_final


# COMMAND ----------

# MAGIC %md
# MAGIC # Hooks

# COMMAND ----------

# N/A
