# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Cell 1
# MAGIC %md
# MAGIC
# MAGIC # ABSENCE MATRIX — XLS INGESTION PIPELINE (SDP + YAML Version)
# MAGIC
# MAGIC **Description:**
# MAGIC Ingests `.xlsx` files deposited manually in a Unity Catalog volume.
# MAGIC Uses Auto Loader (`cloudFiles.format = "excel"`) with per-file pandas processing
# MAGIC to parse each file and append its rows to a **stack** table in the landingzone.
# MAGIC
# MAGIC Table-specific parsing parameters (`skip_rows`, `col_stop_marker`, `row_stop_marker`,
# MAGIC `identification_cols`, `excel_max_cell`) are loaded from a `pilotage.yml` file
# MAGIC deployed with the bundle via `load_pilotage_from_yaml`.
# MAGIC
# MAGIC **Source volume:**
# MAGIC `/Volumes/{PIPELINE_WRITE_ENV}_landingzone_hr/manual_files/{TARGET_SCHEMA}/`
# MAGIC
# MAGIC **Output table (stack):**
# MAGIC `{LANDINGZONE_CATALOG}.{TARGET_SCHEMA}.{target_table}`
# MAGIC
# MAGIC **Design choices:**
# MAGIC - **Streaming append** — Auto Loader tracks processed files;
# MAGIC   each new file is appended once and never re-processed.
# MAGIC - Table parsing parameters are externalized in `pilotage.yml` (not hardcoded).
# MAGIC - Day columns are normalised to `day_01` … `day_31`.
# MAGIC - Metadata columns follow the `_meta_*` naming convention of the generic pipeline.
# MAGIC
# MAGIC **Runtime requirement:** Databricks Runtime 17.1+

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Standard Package Imports

# COMMAND ----------

# DBTITLE 1,Cell 4
import re
import sys
import uuid
import unicodedata
import pandas as pd

from pyspark import pipelines as dp
import pyspark.sql.functions as f
from pyspark.sql.types import StructType, StructField, BooleanType, StringType, TimestampType

# COMMAND ----------

# MAGIC %md
# MAGIC ## LEAP Function Imports

# COMMAND ----------

bundle_root = spark.conf.get("bundle_root", "")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

# COMMAND ----------

# DBTITLE 1,Cell 7
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger
from leap_utils.ingestion.ingestion_declarative_pipeline import load_pilotage_from_yaml

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pipeline Configuration Parameters

# COMMAND ----------

# DBTITLE 1,Cell 9
# Read parameters from pipeline configuration
pipeline_write_env_param  = spark.conf.get("pipeline_write_env",  "dev")
reference_read_env_param  = spark.conf.get("reference_read_env",  "dev")
landingzone_catalog_param = spark.conf.get("landingzone_catalog", "dev_landingzone_hr")
log_level_param           = spark.conf.get("log_level",           "debug")
target_schema_param       = spark.conf.get("target_schema",       "default_schema")
pilotage_yaml_param       = spark.conf.get("pilotage_yaml_stack", "")

# COMMAND ----------

# DBTITLE 1,Cell 10
# LEAP constants for this notebook
dbutils.widgets.text("pipeline_write_env", pipeline_write_env_param)
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", reference_read_env_param)
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("landingzone_catalog", landingzone_catalog_param)
LANDINGZONE_CATALOG = dbutils.widgets.get("landingzone_catalog")

dbutils.widgets.dropdown(
    "log_level",
    defaultValue=log_level_param,
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

TARGET_SCHEMA = target_schema_param
PILOTAGE_YAML = pilotage_yaml_param

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger Setup

# COMMAND ----------

log = setup_applevel_logger(
    log_level=LOG_LEVEL,
    file_log_level=LOG_LEVEL,
    log_format="%(asctime)s - %(name)s - %(levelname)s - %(funcName)s - %(message)s",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Global Variables

# COMMAND ----------

# Load table configuration from pilotage YAML
if not PILOTAGE_YAML:
    raise ValueError("pilotage_yaml parameter is required. Set it in the pipeline configuration.")

files_attrs_dict = load_pilotage_from_yaml(
    yaml_path=PILOTAGE_YAML,
    reference_read_env=REFERENCE_READ_ENV,
    pipeline_write_env=PIPELINE_WRITE_ENV,
)
log.info(f"Loaded {len(files_attrs_dict)} table(s) from YAML: {PILOTAGE_YAML}")

table_conf = list(files_attrs_dict.values())[0]

target_table        = table_conf["table_name"]
excel_max_cell      = table_conf["excel_max_cell"]
skip_rows           = int(table_conf["excel_skip_rows"])
IDENTIFICATION_COLS = table_conf["excel_identification_cols"]
col_stop_marker     = table_conf["excel_col_stop_marker"]
row_stop_marker     = table_conf["excel_row_stop_marker"]
day_header_format        = table_conf.get("excel_day_header_format", "")
day_filename_pattern     = table_conf.get("excel_day_filename_pattern", "")
file_keyword_simplified  = table_conf.get("file_keyword_simplified", "")
file_regex_pattern       = table_conf.get("file_regex", "")
# If excel_max_cell contains a sheet reference (e.g. "grafik!A5:AU999"), use as-is;
# otherwise compose the standard range from skip_rows and max cell (e.g. "A5:AZ999")
excel_data_address  = excel_max_cell if "!" in excel_max_cell else f"A{skip_rows + 1}:{excel_max_cell}"

VOLUME_PATH = f"/Volumes/{PIPELINE_WRITE_ENV}_landingzone_hr/manual_files/{TARGET_SCHEMA}"

spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

log.info(f"PIPELINE_WRITE_ENV  : {PIPELINE_WRITE_ENV}")
log.info(f"LANDINGZONE_CATALOG : {LANDINGZONE_CATALOG}")
log.info(f"VOLUME_PATH         : {VOLUME_PATH}")
log.info(f"TARGET              : {LANDINGZONE_CATALOG}.{TARGET_SCHEMA}.{target_table}")
log.info(f"HEADER_COLS         : {IDENTIFICATION_COLS}")
log.info(f"col_stop_marker     : {col_stop_marker}")
log.info(f"row_stop_marker     : {row_stop_marker}")
log.info(f"day_header_format        : {day_header_format!r}")
log.info(f"day_filename_pattern     : {day_filename_pattern!r}")
log.info(f"file_keyword_simplified  : {file_keyword_simplified!r}")
log.info(f"file_regex_pattern       : {file_regex_pattern!r}")
log.info(f"excel_data_address       : {excel_data_address}")

# COMMAND ----------

# MAGIC %md
# MAGIC # SDP Table Definition

# COMMAND ----------

# DBTITLE 1,Cell 18
# MAGIC %md
# MAGIC ## Landingzone streaming stack table

# COMMAND ----------

# -- Helpers ----------------------------------------------------------------

# note: the following function is more or less one from table_utils but there is an error
# with imported leap_utils functions used in the file processing
# Root Cause: ModuleNotFoundError: No module named 'leap_utils' on worker nodes.
def _excel_col_to_num(col_str: str) -> int:
    """Convert Excel column letter(s) to 1-based index. E.g. 'A'=1, 'Z'=26, 'AA'=27, 'AU'=47."""
    num = 0
    for c in col_str.upper():
        num = num * 26 + (ord(c) - ord('A') + 1)
    return num

def _raw_excel_col_count(data_address: str) -> int:
    """Count columns covered by an Excel data_address range.

    Handles plain ranges ('A5:AZ999') and sheet-prefixed ranges ("grafik!A5:AU999").
    Returns end_col - start_col + 1, or 100 as a safe fallback.
    """
    addr = data_address.split("!")[-1].strip() if "!" in data_address else data_address.strip()
    m = re.match(r"([A-Za-z]+)\d*:([A-Za-z]+)\d*", addr)
    if m:
        return _excel_col_to_num(m.group(2)) - _excel_col_to_num(m.group(1)) + 1
    return 100

def cleanup_column_name(name: str) -> str | None:
    """Remove accents, replace spaces with underscores,
    strip other special characters (e.g. '/')."""
    if not isinstance(name, str):
        return None
    nfkd = unicodedata.normalize("NFKD", name)
    name = "".join(c for c in nfkd if not unicodedata.combining(c))
    name = name.replace(" ", "_")
    name = re.sub(r"[^a-zA-Z0-9_]", "", name)
    return name.lower().strip()

def _to_nullable_str(series: pd.Series) -> pd.Series:
    """Convert series values to string, preserving nulls as None."""
    mask = series.notna()
    out = pd.Series(None, index=series.index, dtype="object")
    out[mask] = series[mask].astype(str)
    return out


# -- Per-file pandas processing ---------------------------------------------
def process_absence_matrix_file(
    pdf: pd.DataFrame,
    output_cols: list[str],
    identification_cols: list[str],
    column_stop_name: str | None,
    row_stop_name: str | None,
) -> pd.DataFrame:
    """Parse a single absence-matrix Excel file into a flat DataFrame.

    Called once per file via `applyInPandas` (grouped by __file_path).
    The input DataFrame uses positional column names (_c0, _c1, …) because
    Auto Loader reads with headerRows=0; the actual header is row 0 of the data.

    Processing steps:
      1. Extract the header row (row 0) and normalise labels.
      2. Locate the column stop marker to determine how many day columns exist.
      3. Filter out footer/legend rows (row stop marker) and blank rows.
      4. Extract identification columns and normalise day columns to day_01…day_31.
      5. Attach _meta_* columns (id, file path, timestamps).

    Args:
        pdf: All rows for one file, with positional columns plus
             __file_path and __file_name (added upstream).
        output_cols: Ordered column names for the returned DataFrame.
        identification_cols: Cleaned names for the leading ID columns
             (e.g. ["employee_no", "employee_name"]). Pass [] if the
             file has no identification columns before the day columns.
        column_stop_name: Cleaned label of the column that marks the end
             of day columns (e.g. "present"). Pass None to use all
             columns after the identification columns as day columns.
        row_stop_name: Cleaned value in the first ID column that marks
             the start of footer rows to discard (e.g. "legend"). Pass
             None to keep all non-blank rows (no footer filtering).

    Returns:
        A DataFrame with columns matching `output_cols`, or an empty
        DataFrame (same schema) when the file is invalid or empty.
    """
    # Define an empty DataFrame (0 rows) with the expected schema
    #   It is the return value in case of an empty file or invalid input
    empty = pd.DataFrame(columns=output_cols)
    if pdf.empty:
        return empty

    # Extract file path and name from metadata columns.
    #   These columns contain the same value at every row, we simply extract
    #   one string being the first positional element (.iloc[0]) of the column.
    #
    #   Nota: Pandas indexing pdf["column_name"] gives the column "column_name",
    #   in fact a pandas Series object
    file_path = str(pdf["__file_path"].iloc[0])
    file_name = str(pdf["__file_name"].iloc[0])

    # Drop Auto Loader metadata columns, we do not need them in the return DataFrame
    data = pdf.drop(columns=["__file_path", "__file_name"])
    # from now on, data has the same schema as pdf minus the metadata columns

    # Normalize the header labels with cleanup_column_name from leap_utils
    #   Row 0 (data.iloc[0, :] = data.iloc[0]) is the Excel header row
    #   If the value is null or contains only spaces, it is converted to an empty string
    #
    #   Nota: .iloc[i_row, i_col] is a DataFrame positional indexing using integer values,
    #   very much like numpy 2D arrays.
    header_vals = [
        cleanup_column_name(str(v)) if (pd.notna(v) and str(v).strip()) else ""
        for v in data.iloc[0, :]
    ]
    log.info(f"Header row: {header_vals}")

    # Eventually we want to remove all useless columns, they start from the column
    # named column_stop_name.
    #   We find column stop marker — its position (integer value column_stop_idx) delimits day
    #   columns from the rest.
    #   If column_stop_name is None, use all remaining columns as day columns.
    if column_stop_name is None:
        column_stop_idx = len(header_vals)
    elif column_stop_name not in header_vals:
        log.error(
            f"Stop marker '{column_stop_name}' not found in {file_name} — file skipped."
        )
        return empty
    else:
        column_stop_idx = header_vals.index(column_stop_name)

    # Drop header row, keep only data rows
    #   Nota: by default, a pandas DataFrame is integer-indexed from index 0 to max row - 1
    #   .iloc[1:] enable to keep all rows from row 1 to the end
    #   after this instruction data has indexes starting from 1, we therefore reset
    #   the panda indexing to make it start from 0 instead of 1
    #   (drop = True means we do not keep the old indexes as an additional column)
    data = data.iloc[1:].reset_index(drop=True)
    if data.empty:
        return empty

    # Filter out footer (for instance a legend at the bottom of the file) and blank rows based
    # on the first identification column. If no identification columns, keep all rows.
    if identification_cols:
        # Get the first DataFrame column (.iloc[:, 0]) as string or None
        first_column_values = _to_nullable_str(data.iloc[:, 0])
        # Define mask to be a boolean indexing array which is True only for non null
        # or empty string values
        mask = first_column_values.notna() & (first_column_values.str.strip() != "")
        # Isolate all rows from (and including) the first row which first element value matches row_stop_name
        if row_stop_name is not None:
            # Make sure to clean the row values
            first_column_values_cleaned = first_column_values.apply(
                cleanup_column_name
            )
            # Get all the indexes of the occurrence of row_stop_name as the first row value, it is not
            # expected, but there could be several
            stop_indexes = first_column_values_cleaned[
                first_column_values_cleaned == row_stop_name
            ].index
            if len(stop_indexes) > 0:
                # If any index was found, use the first one and update the mask so only the rows before
                # this first occurrence of row_stop_name are kept
                mask = mask & (first_column_values.index < stop_indexes[0])
        # Use mask for boolean indexing on data rows. Only the rows for which the value of mask is True will be
        # kept. Reset index again since we potentially changed the number of rows.
        data = data[mask].reset_index(drop=True) 
    if data.empty:
        return empty
    log.info(f"Number of rows after masking: {len(data)}")

    # Build the result DataFrame with the same index as data
    # We will use the data to fill the values of result using the fact that
    # both DataFrame share the same index
    result = pd.DataFrame(index=data.index)

    # Identification columns (first positional columns of data)
    for i, col_name in enumerate(identification_cols):
        # Construct a new column in result and fill the values with data
        result[col_name] = _to_nullable_str(data.iloc[:, i])

    # Identify day columns that contain at least one non-empty value after
    # identification columns
    day_col_positions = [
        pos # mark the column at position pos to be a day column
        for pos in range(len(identification_cols), column_stop_idx) # for all columns position after identification columns
        if data.iloc[:, pos].notna().any() # At least one non null value must be in the column pos to be kept
        and (data.iloc[:, pos].astype(str).str.strip() != "").any() # At least one non empty string value must be in the column pos to be kept
    ]
    # Keep the value (should be a non-formatted date) of the first day column name
    day_01_value = header_vals[day_col_positions[0]] if day_col_positions else ""
    log.info(f"First day in : {day_01_value}")

    # Transfer the day data from data to result, but in day columns that have normalized names
    result["day_01_value"] = day_01_value
    for di, col_pos in enumerate(day_col_positions): # for each day column that was found
        result[f"day_{di + 1:02d}"] = _to_nullable_str(data.iloc[:, col_pos])
    for di in range(len(day_col_positions), 31): # we always want 31 day columns, so fill the rest with None
        result[f"day_{di + 1:02d}"] = None

    # Attach ingestion metadata (timestamps are placeholders — overwritten by Spark after applyInPandas)
    n_rows = len(result)
    result = result.assign(
        _meta_extraction_timestamp=pd.NaT,
        _meta_id=[str(uuid.uuid4()) for _ in range(n_rows)], # one uuid per row
        _meta_file_path=file_path,
        _meta_file_name=file_name,
        _meta_file_mode="full",
        _meta_ingestion_timestamp=pd.NaT,
    )

    # _meta_validity_check: True if the first identification column is non-null and non-empty
    if identification_cols:
        first_id_vals = _to_nullable_str(result[identification_cols[0]])
        result["_meta_validity_check"] = first_id_vals.notna() & (first_id_vals.str.strip() != "")
    else:
        result["_meta_validity_check"] = True

    log.info(
        f"{file_name}: {n_rows} rows, {len(day_col_positions)} day col(s), day_01='{day_01_value}'"
    )
    return result[output_cols]

# COMMAND ----------

# DBTITLE 1,Cell 19
@dp.table(
    name=f"{LANDINGZONE_CATALOG}.{TARGET_SCHEMA}.{target_table}",
    comment=(
        "Absences data — streaming stack of matrix-styled XLSX files ingested from a volume."
    ),
    table_properties={
        "quality": "landingzone",
        "delta.autoOptimize.optimizeWrite": "true",
        "pipelines.reset.allowed": "true",
    },
    cluster_by=["_meta_extraction_timestamp", "_meta_id"],
)
def create_absence_stack_table():
    # -- Pre-compute cleaned markers (same for every file) ------------------
    identification_cols_clean = [cleanup_column_name(h) for h in IDENTIFICATION_COLS]
    column_stop_name = cleanup_column_name(col_stop_marker)
    row_stop_name = cleanup_column_name(row_stop_marker)

    # -- Fixed output schema ------------------------------------------------
    output_schema = StructType(
        [
            StructField("_meta_extraction_timestamp", TimestampType()),  # placeholder, overwritten by Spark below
            StructField("_meta_file_mode", StringType()),
            StructField("_meta_file_name", StringType()),
            StructField("_meta_file_path", StringType()),
            StructField("_meta_id", StringType()),
            StructField("_meta_ingestion_timestamp", TimestampType()),   # placeholder, overwritten by Spark below
        ]
        + [StructField(c, StringType()) for c in identification_cols_clean]
        + [StructField("day_01_value", StringType())]  # standardized 1st day value
        + [StructField(f"day_{i:02d}", StringType()) for i in range(1, 32)]
        + [StructField("_meta_validity_check", BooleanType())]
    )
    output_cols = [field.name for field in output_schema.fields]

    # -- Auto Loader read — headerRows=0 forces positional column names ------
    # The Excel header row (row SKIP_ROWS+1) is included in the data stream as
    # the first row of each file; it is consumed inside process_absence_matrix_file above.
    #
    # Explicit raw schema: when dataAddress contains a sheet reference (e.g. "grafik!A5:AU999"),
    # Auto Loader cannot infer the schema (it reads the first sheet, not the target sheet).
    # Providing an explicit schema of _c0…_c(N-1) bypasses inference entirely.
    path_glob = f"*{file_keyword_simplified}*.xls*" if file_keyword_simplified else "*.xls*"
    _n_raw_cols = _raw_excel_col_count(excel_data_address)
    raw_input_schema = StructType([StructField(f"_c{i}", StringType()) for i in range(_n_raw_cols)])
    log.info(f"raw_input_schema     : {_n_raw_cols} positional columns (_c0…_c{_n_raw_cols - 1})")
    sdf = (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "excel")
        .option("pathGlobFilter", path_glob)
        .option("headerRows", 0)
        .option("dataAddress", excel_data_address)
        .option("inferSchema", "false")
        .option("cloudFiles.schemaEvolutionMode", "none")
        .schema(raw_input_schema)
        .load(VOLUME_PATH)
    )

    # Surface file metadata as plain columns before groupBy
    sdf = sdf.withColumns(
        {
            "__file_path": f.col("_metadata.file_path"),
            "__file_name": f.col("_metadata.file_name"),
        }
    )

    # Post-load filename filter (file_regex) — drop rows from files that don't match the expected naming convention
    if file_regex_pattern:
        sdf = sdf.filter(f.col("__file_name").rlike(file_regex_pattern))
        log.info(f"Applied file_regex filter: {file_regex_pattern}")

    # Group by file -> each group is sent to process_absence_matrix_file as a pandas DataFrame
    sdf_stack = sdf.groupBy("__file_path").applyInPandas(
        lambda df: process_absence_matrix_file(
            df,
            output_cols=output_cols,
            identification_cols=identification_cols_clean,
            column_stop_name=column_stop_name,
            row_stop_name=row_stop_name,
        ),
        schema=output_schema,
    )

    # _meta_extraction_timestamp: parsed from filename prefix YYYYMMDD_HHmmss or YYYYMMDD_HHmm
    # _meta_ingestion_timestamp: when the pipeline processed the file
    extraction_ts = f.coalesce(
        f.to_timestamp(f.regexp_extract(f.col("_meta_file_name"), r"(\d{8}_\d{6})", 1), "yyyyMMdd_HHmmss"),
        f.to_timestamp(f.regexp_extract(f.col("_meta_file_name"), r"(\d{8}_\d{4})", 1), "yyyyMMdd_HHmm"),
    )
    return (
        sdf_stack
        .withColumn("_meta_extraction_timestamp", extraction_ts)
        .withColumn("_meta_ingestion_timestamp", f.current_timestamp())
    )

# COMMAND ----------

# DBTITLE 1,Unpivoted table
# MAGIC %md
# MAGIC    
# MAGIC ## Unpivoted streaming table
# MAGIC
# MAGIC Reads from the stack table above and transforms wide day columns (`day_01`…`day_31`)
# MAGIC into individual rows with a computed `date` column derived from `day_01_value` + day offset.
# MAGIC Null day values are filtered out.

# COMMAND ----------

# DBTITLE 1,Unpivoted absence table definition
@dp.table(
    name=f"{LANDINGZONE_CATALOG}.{TARGET_SCHEMA}.{target_table.removesuffix('_stack')}_unpivot_stack",
    comment=(
        "Absences data — unpivoted view of the matrix stack table. "
        "Each row represents one employee-day with its absence code."
    ),
    table_properties={
        "quality": "landingzone",
        "delta.autoOptimize.optimizeWrite": "true",
        "pipelines.reset.allowed": "true",
    },
    cluster_by=["_meta_extraction_timestamp", "date"],
)
def create_absence_unpivot_table():
    # Read from the upstream stack table
    identification_cols_clean = [cleanup_column_name(h) for h in IDENTIFICATION_COLS]
    day_cols = [f"day_{i:02d}" for i in range(1, 32)]
    _fr_en_map = f.create_map(
            f.lit("janvier"), f.lit("january"), f.lit("février"), f.lit("february"),
            f.lit("fevrier"), f.lit("february"), f.lit("mars"), f.lit("march"),
            f.lit("avril"), f.lit("april"), f.lit("mai"), f.lit("may"),
            f.lit("juin"), f.lit("june"), f.lit("juillet"), f.lit("july"),
            f.lit("août"), f.lit("august"), f.lit("aout"), f.lit("august"),
            f.lit("septembre"), f.lit("september"), f.lit("octobre"), f.lit("october"),
            f.lit("novembre"), f.lit("november"), f.lit("décembre"), f.lit("december"),
            f.lit("decembre"), f.lit("december"),
        )

    # Columns to keep as-is (identification + metadata)
    id_cols = (
        ["_meta_extraction_timestamp", "_meta_file_mode", "_meta_file_name",
         "_meta_file_path", "_meta_id", "_meta_ingestion_timestamp"]
        + identification_cols_clean
        + ["day_01_value"]
    )

    # Read the upstream stack streaming table
    sdf = spark.readStream.table(f"{LANDINGZONE_CATALOG}.{TARGET_SCHEMA}.{target_table}")

    # Unpivot: each day column becomes a row with (day_num, day_value)
    stack_expr = f"stack(31, " + ", ".join(
        [f"'{col}', {col}" for col in day_cols]
    ) + ") as (day_num, day_value)"

    sdf_unpivot = (
        sdf.selectExpr(*id_cols, stack_expr)
        .where("day_value is not null")
    )

    # Compute the actual date from day_01_value and the day offset
    sdf_unpivot = sdf_unpivot.withColumn(
        "day_index",
        (f.regexp_extract("day_num", r"day_(\d+)", 1).cast("int") - 1)
    )
    if day_header_format and not day_filename_pattern:
        # India: full date string in header (e.g. "21_jan_2025") — parse directly + day offset
        sdf_unpivot = (
            sdf_unpivot
            .withColumn("day_01_date", f.to_date("day_01_value", day_header_format))
            .withColumn("date", f.date_add(f.col("day_01_date"), f.col("day_index")))
            .drop("day_01_date")
        )
    elif day_header_format and day_filename_pattern:
        # Morocco: header is "d/M" (e.g. "2/3"), cleanup removes "/" → day_01_value = str(day)+str(month) (e.g. "23")
        # Month and year come from filename (2-group pattern). Day = strip trailing month digits from day_01_value.
        # Normalize French month names to English for date parsing
        _month_raw = f.lower(f.regexp_extract("_meta_file_name", day_filename_pattern, 1))
        month_name_col = f.initcap(f.coalesce(_fr_en_map[_month_raw], _month_raw))
        year_str_col   = f.regexp_extract("_meta_file_name", day_filename_pattern, 2)
        ref_date_col   = f.to_date(f.concat_ws(" ", f.lit("1"), month_name_col, year_str_col), "d MMMM yyyy")
        sdf_unpivot = (
            sdf_unpivot
            .withColumn("_month_num", f.month(ref_date_col))
            .withColumn("_year_int",  f.year(ref_date_col))
            .withColumn("_day_int",
                f.expr("cast(substring(day_01_value, 1, length(day_01_value) - case when _month_num < 10 then 1 else 2 end) as int)")
            )
            .withColumn("day_01_date", f.make_date(f.col("_year_int"), f.col("_month_num"), f.col("_day_int")))
            .withColumn("date", f.date_add(f.col("day_01_date"), f.col("day_index")))
            .drop("_month_num", "_year_int", "_day_int", "day_01_date")
        )
    elif day_filename_pattern:
        # Bulgaria: ordinal day integer in header (e.g. "21"), month+year from filename (2-group pattern)
        # Normalize French month names to English for date parsing
        _month_raw   = f.lower(f.regexp_extract("_meta_file_name", day_filename_pattern, 1))
        month_name   = f.initcap(f.coalesce(_fr_en_map[_month_raw], _month_raw))
        year_str     = f.regexp_extract("_meta_file_name", day_filename_pattern, 2)
        day_of_month = f.col("day_01_value").cast("int") + f.col("day_index")
        ref_date     = f.to_date(f.concat_ws(" ", f.lit("1"), month_name, year_str), "d MMMM yyyy")
        sdf_unpivot  = (
            sdf_unpivot
            .withColumn("_day_of_month", day_of_month)
            .withColumn("date", f.date_add(ref_date, f.col("_day_of_month") - 1))
            .drop("_day_of_month")
        )
    else:
        # No date derivation possible
        sdf_unpivot = sdf_unpivot.withColumn("date", f.lit(None).cast("date"))
    sdf_unpivot = sdf_unpivot.drop("day_index", "day_01_value", "day_num")

    return sdf_unpivot