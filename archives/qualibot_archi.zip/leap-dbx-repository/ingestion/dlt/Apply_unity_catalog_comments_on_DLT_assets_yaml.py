# Databricks notebook source
# MAGIC %md
# MAGIC # Apply Unity Catalog Comments on tables (Post-DLT, YAML version)
# MAGIC
# MAGIC Apply **Unity Catalog comments** (table description + column descriptions) on the tables
# MAGIC materialized by the DLT pipeline.
# MAGIC - Source of truth: `pilotage.yml` deployed with the bundle (no pilotage Delta table required)
# MAGIC - Targets: `{landingzone_catalog}.{schema}.{table}_stack` and/or `{bronze_catalog}.{schema}.{table}_latest`
# MAGIC - Applies: table-level comment (`table_comment`) + column-level comments (`comment` per column)
# MAGIC
# MAGIC > Run this notebook **after** the pipeline execution (e.g. as a task in the Workflow, after `update_tags`).

# COMMAND ----------

# Add bundle_root to sys.path for leap_utils imports (when running from Asset Bundle)
import sys
dbutils.widgets.text("bundle_root", "")
bundle_root = dbutils.widgets.get("bundle_root")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.ingestion.ingestion_declarative_pipeline import load_pilotage_from_yaml

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1) Parameters

# COMMAND ----------

dbutils.widgets.text("pilotage_yaml", "", "Path to pilotage.yml (workspace or /dbfs path)")
dbutils.widgets.text("landingzone_catalog", "dev_landingzone", "Landingzone catalog (e.g. dev_landingzone_hr)")
dbutils.widgets.text("bronze_catalog", "dev_bronze", "Bronze catalog (e.g. dev_bronze_hr)")
dbutils.widgets.text("target_schema", "", "Schema of target tables")
dbutils.widgets.dropdown("comment_stack", "true", ["true", "false"])
dbutils.widgets.dropdown("comment_latest", "true", ["true", "false"])
dbutils.widgets.text("only_tables_csv", "")  # e.g. "table1,table2" (empty = all)
dbutils.widgets.dropdown("dry_run", "false", ["true", "false"])

# Env placeholders used only for bucket_name substitution in file-mode tables (optional)
dbutils.widgets.text("reference_read_env", "dev", "Env for {REFERENCE_READ_ENV} substitution")
dbutils.widgets.text("pipeline_write_env", "dev", "Env for {PIPELINE_WRITE_ENV} substitution")

PILOTAGE_YAML      = dbutils.widgets.get("pilotage_yaml")
LANDINGZONE_CATALOG = dbutils.widgets.get("landingzone_catalog")
BRONZE_CATALOG     = dbutils.widgets.get("bronze_catalog")
TARGET_SCHEMA      = dbutils.widgets.get("target_schema")
COMMENT_STACK      = dbutils.widgets.get("comment_stack") == "true"
COMMENT_LATEST     = dbutils.widgets.get("comment_latest") == "true"
ONLY_TABLES_CSV    = dbutils.widgets.get("only_tables_csv").strip()
DRY_RUN            = dbutils.widgets.get("dry_run") == "true"
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

print(f"[CONFIG] pilotage_yaml={PILOTAGE_YAML}")
print(f"[CONFIG] landingzone_catalog={LANDINGZONE_CATALOG}, bronze_catalog={BRONZE_CATALOG}, target_schema={TARGET_SCHEMA}")
print(f"[CONFIG] comment_stack={COMMENT_STACK}, comment_latest={COMMENT_LATEST}, dry_run={DRY_RUN}")

ONLY_TABLES = (
    [t.strip() for t in ONLY_TABLES_CSV.split(",") if t.strip()]
    if ONLY_TABLES_CSV
    else []
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2) Load configuration from YAML

# COMMAND ----------

if not PILOTAGE_YAML:
    raise ValueError(
        "pilotage_yaml parameter is required.\n"
        "Example: /Workspace/Shared/.bundle/my_bundle/dev/files/platform/asset_bundle/my_bundle/src/pilotage.yml"
    )

FILES_ATTRS_DICT = load_pilotage_from_yaml(
    yaml_path=PILOTAGE_YAML,
    reference_read_env=REFERENCE_READ_ENV,
    pipeline_write_env=PIPELINE_WRITE_ENV,
)

if ONLY_TABLES:
    FILES_ATTRS_DICT = {k: v for k, v in FILES_ATTRS_DICT.items() if v["table_name"] in ONLY_TABLES}

print(f"[INFO] Loaded {len(FILES_ATTRS_DICT)} entries from YAML.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3) Apply comments (stack and/or latest)
# MAGIC
# MAGIC **Delta-aware**: current comments are read once per catalog from `information_schema`
# MAGIC (`.columns` for column comments, `.tables` for the table comment). Only comments that are
# MAGIC **missing or different** from the YAML value are re-applied — a stable re-run emits 0 `ALTER`.
# MAGIC `_get_object_type` (needed for the `ALTER {TABLE|VIEW|MATERIALIZED VIEW}` syntax) is called
# MAGIC **only** when a table actually has at least one column comment to change.
# MAGIC
# MAGIC > Note: like before, a comment removed from the YAML is NOT unset on the object.

# COMMAND ----------

def _escape(text: str) -> str:
    """Escape single quotes for SQL string literals."""
    return text.replace("'", "''")


def _get_object_type(full_table_name: str) -> str:
    """Return 'MATERIALIZED VIEW', 'VIEW', 'STREAMING TABLE', or 'TABLE' for a Unity Catalog object."""
    try:
        rows = spark.sql(f"DESCRIBE EXTENDED {full_table_name}").collect()
        for row in rows:
            if str(row["col_name"]).strip() == "Type":
                t = str(row["data_type"]).upper()
                if "MATERIALIZED" in t:
                    return "MATERIALIZED VIEW"
                if "STREAMING" in t:
                    return "STREAMING TABLE"
                if "VIEW" in t:
                    return "VIEW"
    except Exception:
        pass
    return "TABLE"


# Current-state caches, populated once per catalog (bronze tables are mostly materialized views,
# but also plain Delta tables / streaming tables — information_schema covers all object types).
_col_comments_cache = {}  # catalog -> {(table_name, column_name): current_comment}
_tbl_comments_cache = {}  # catalog -> {table_name: current_comment}


def _load_current_comments(catalog: str):
    """Read current table & column comments for TARGET_SCHEMA in `catalog` (one query each)."""
    if catalog in _col_comments_cache:
        return
    col_map = {}
    for r in spark.sql(
        f"SELECT table_name, column_name, comment "
        f"FROM {catalog}.information_schema.columns "
        f"WHERE table_schema = '{TARGET_SCHEMA}'"
    ).collect():
        col_map[(r["table_name"], r["column_name"])] = r["comment"]
    _col_comments_cache[catalog] = col_map

    tbl_map = {}
    for r in spark.sql(
        f"SELECT table_name, comment "
        f"FROM {catalog}.information_schema.tables "
        f"WHERE table_schema = '{TARGET_SCHEMA}'"
    ).collect():
        tbl_map[r["table_name"]] = r["comment"]
    _tbl_comments_cache[catalog] = tbl_map


def _apply_comments(full_table_name: str, table_comment: str, column_comments: dict, dry_run: bool):
    """Apply ONLY the missing/changed comments on a UC table, view, or materialized view.

    Returns (n_applied, n_total) where n_total counts the non-empty comments defined in the YAML
    for this object (1 table comment + N column comments).

    - Table comment : COMMENT ON TABLE ... (works for all object types)
    - Column comment: ALTER TABLE / ALTER VIEW / ALTER MATERIALIZED VIEW ... ALTER COLUMN ... COMMENT
    """
    catalog, _, table = full_table_name.split(".", 2)
    _load_current_comments(catalog)
    cur_cols = _col_comments_cache[catalog]
    cur_tbls = _tbl_comments_cache[catalog]

    n_total = 0
    n_applied = 0

    # Table-level comment — apply only if different from the current one.
    if table_comment:
        n_total += 1
        if cur_tbls.get(table) != table_comment:
            sql = f"COMMENT ON TABLE {full_table_name} IS '{_escape(table_comment)}'"
            print(f"  [TABLE ] {sql[:120]}")
            if not dry_run:
                spark.sql(sql)
            n_applied += 1

    # Column-level comments — collect the delta first, so _get_object_type is called only if needed.
    pending = []
    for col, comment in column_comments.items():
        if comment:
            n_total += 1
            if cur_cols.get((table, col)) != comment:
                pending.append((col, comment))

    if pending:
        obj_type = _get_object_type(full_table_name)
        for col, comment in pending:
            sql = f"ALTER {obj_type} {full_table_name} ALTER COLUMN {col} COMMENT '{_escape(comment)}'"
            print(f"  [COLUMN] {sql[:120]}")
            if not dry_run:
                spark.sql(sql)
            n_applied += 1

    return n_applied, n_total


results = []
for _, attrs in FILES_ATTRS_DICT.items():
    t               = attrs["table_name"]
    table_comment   = attrs.get("table_comment") or ""
    column_comments = attrs.get("column_comments") or {}

    if not table_comment and not column_comments:
        print(f"[SKIP] {t} — no comments defined in YAML")
        continue

    # 3.1) STACK (landingzone_catalog.<schema>.<table>_stack)
    if COMMENT_STACK:
        stack_full = f"{LANDINGZONE_CATALOG}.{TARGET_SCHEMA}.{t}_stack"
        status = "skipped"
        error = None
        if table_utils.UnityCatalogCheckTableExists(DbxTablePath=stack_full):
            try:
                n_applied, n_total = _apply_comments(stack_full, table_comment, column_comments, DRY_RUN)
                verb = "dry-run" if DRY_RUN else "ok"
                status = f"{verb} ({n_applied}/{n_total} applied)"
            except Exception as e:
                status = "error"
                error = str(e)[:4000]
        else:
            status = "missing"
        results.append((stack_full, "landingzone", status, error))

    # 3.2) LATEST (bronze_catalog.<schema>.<table>_latest)
    if COMMENT_LATEST:
        latest_full = f"{BRONZE_CATALOG}.{TARGET_SCHEMA}.{t}_latest"
        status = "skipped"
        error = None
        if table_utils.UnityCatalogCheckTableExists(DbxTablePath=latest_full):
            try:
                n_applied, n_total = _apply_comments(latest_full, table_comment, column_comments, DRY_RUN)
                verb = "dry-run" if DRY_RUN else "ok"
                status = f"{verb} ({n_applied}/{n_total} applied)"
            except Exception as e:
                status = "error"
                error = str(e)[:4000]
        else:
            status = "missing"
        results.append((latest_full, "bronze", status, error))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4) Summary

# COMMAND ----------

schema = "table_full_name string, zone string, status string, error string"
df_res = (
    spark.createDataFrame(results, schema)
    if results
    else spark.createDataFrame([], schema)
)
display(df_res.orderBy("zone", "table_full_name"))

print("[DONE] UC comments applied.")
