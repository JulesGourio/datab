# Databricks notebook source
# MAGIC %md
# MAGIC ## Unset Governed Tags Before Full Refresh
# MAGIC
# MAGIC SDP full refresh drops and recreates streaming tables. Unity Catalog
# MAGIC blocks `DROP TABLE` when columns carry governed tags (ABAC, PK).
# MAGIC
# MAGIC This notebook strips all column-level governed tags from the stack and
# MAGIC latest tables **before** the pipeline full refresh. The `update_tags`
# MAGIC task (downstream in the job) re-applies them from `pilotage.yml`.

# COMMAND ----------

dbutils.widgets.text("landingzone_catalog", "dev_landingzone_hr")
dbutils.widgets.text("bronze_catalog", "dev_bronze_hr")
dbutils.widgets.text("target_schema", "usa_abs")

LANDINGZONE_CATALOG = dbutils.widgets.get("landingzone_catalog")
BRONZE_CATALOG = dbutils.widgets.get("bronze_catalog")
TARGET_SCHEMA = dbutils.widgets.get("target_schema")

# COMMAND ----------

# Dynamically discover and unset all governed column tags on stack + latest
tables = [
    f"{LANDINGZONE_CATALOG}.{TARGET_SCHEMA}.{TARGET_SCHEMA}_stack",
    f"{BRONZE_CATALOG}.{TARGET_SCHEMA}.{TARGET_SCHEMA}_latest",
]

total_unset = 0
for table in tables:
    catalog_name, schema_name, table_name = table.split(".")

    rows = spark.sql(f"""
        SELECT column_name, COLLECT_LIST(tag_name) AS tags
        FROM {catalog_name}.information_schema.column_tags
        WHERE table_name = '{table_name}' AND schema_name = '{schema_name}'
        GROUP BY column_name
    """).collect()

    if not rows:
        print(f"[SKIP] {table} -- no governed tags found")
        continue

    for row in rows:
        tag_list = ", ".join(f"'{t}'" for t in row.tags)
        spark.sql(f"ALTER TABLE {table} ALTER COLUMN {row.column_name} UNSET TAGS ({tag_list})")
        print(f"[UNSET] {table}.{row.column_name} -- {row.tags}")
        total_unset += len(row.tags)

print(f"\nDone -- {total_unset} tag(s) removed across {len(tables)} table(s).")
