# Databricks notebook source
# MAGIC %md
# MAGIC # Apply Unity Catalog Tags on tables (Post-DLT)
# MAGIC
# MAGIC Apply **Unity Catalog tags** on the tables materialized by the DLT pipeline.
# MAGIC - Source of truth: control table (configure_dlt.py)
# MAGIC - Targets: landingzone.<schema>.<table>_stack and/or bronze.<schema>.<table>_latest
# MAGIC - Unity Catalog Tags: table-level + column-level (+ optional logical PK/FK)
# MAGIC
# MAGIC > Run this notebook **after** the pipeline execution, as the 2nd task in the Workflow or just once a day.

# COMMAND ----------

# Add bundle_root to sys.path for leap_utils imports (when running from Asset Bundle)
import sys
dbutils.widgets.text("bundle_root", "")
bundle_root = dbutils.widgets.get("bundle_root")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

# COMMAND ----------
from typing import Dict, Any, Optional, List
from pyspark.sql.functions import col
from delta.exceptions import ConcurrentAppendException, MetadataChangedException
from leap_utils.data_asset import table_utils
from leap_utils.common import retry

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1) Parameters

# COMMAND ----------

# Widgets
dbutils.widgets.text("pipeline_name", "mes_ingestion")

dbutils.widgets.dropdown(
    "pipeline_read_env",
    "dev",
    ["dev", "uat", "prod"],
    "Env from where pilotage table is read",
)
dbutils.widgets.dropdown(
    "pipeline_write_env",
    "dev",
    ["dev", "uat", "prod", "sd_dev", "sd_uat", "sd_prod"],
    "Env of target tables to tag",
)

dbutils.widgets.text(
    "target_schema", "mes", "Schema of target tables to tag in landingzone and bronze"
)

dbutils.widgets.dropdown("tag_stack", "true", ["true", "false"])
dbutils.widgets.dropdown("tag_latest", "true", ["true", "false"])
dbutils.widgets.text(
    "only_tables_csv", ""
)  # e.g. "factory,line,work_order" (empty = all)
dbutils.widgets.dropdown("dry_run", "false", ["true", "false"])
dbutils.widgets.dropdown(
    "apply_pk_fk", "true", ["true", "false"]
)  # also applies logical PK/FK as tags

# Read widgets
PIPELINE_NAME = dbutils.widgets.get("pipeline_name")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")
PILOTAGE_CS = f"{PIPELINE_READ_ENV}_bronze.data_quality"
LANDING_ZONE_CATALOG = f"{PIPELINE_WRITE_ENV}_landingzone"
BRONZE_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze"
TARGET_SCHEMA = dbutils.widgets.get("target_schema")
TAG_STACK = dbutils.widgets.get("tag_stack") == "true"
TAG_LATEST = dbutils.widgets.get("tag_latest") == "true"
ONLY_TABLES_CSV = dbutils.widgets.get("only_tables_csv").strip()
DRY_RUN = dbutils.widgets.get("dry_run") == "true"
APPLY_PK_FK = dbutils.widgets.get("apply_pk_fk") == "true"

DLT_PILOTAGE_TABLE = f"{PILOTAGE_CS}.dlt_pilotage_table"

print(f"[CONFIG] pipeline_name={PIPELINE_NAME}")
print(f"[CONFIG] pilotage={DLT_PILOTAGE_TABLE}")
print(
    f"[CONFIG] landingzone_catalog={LANDING_ZONE_CATALOG}, bronze_catalog={BRONZE_CATALOG}, target_schema={TARGET_SCHEMA}"
)
print(
    f"[CONFIG] tag_stack={TAG_STACK}, tag_latest={TAG_LATEST}, dry_run={DRY_RUN}, apply_pk_fk={APPLY_PK_FK}"
)

# Optional filter by table list
ONLY_TABLES = (
    [t.strip() for t in ONLY_TABLES_CSV.split(",") if t.strip()]
    if ONLY_TABLES_CSV
    else []
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2) Reload configuration from control table

# COMMAND ----------


def load_files_attrs_dict(
    pipeline_name: str, pilotage_table: str, only_tables: Optional[List[str]] = None
) -> Dict[str, Dict[str, Any]]:
    """
    Load table and column metadata for a given pipeline from a pilotage table.

    This function reads a Spark table containing metadata definitions, filters
    rows based on the provided pipeline name and optional table list, and
    returns a dictionary keyed by a unique identifier composed of the row ID
    and table name.

    Each entry in the returned dictionary contains table-level attributes
    such as tags, column tags, primary keys, and foreign keys.

    :param pipeline_name:
        Name of the pipeline used to filter rows in the pilotage table.
    :type pipeline_name: str

    :param pilotage_table:
        Fully qualified name of the Spark table containing pilotage metadata.
    :type pilotage_table: str

    :param only_tables:
        Optional list of table names to further restrict the selection.
        If None, all tables for the given pipeline are included.
    :type only_tables: Optional[List[str]]

    :return:
        A dictionary mapping a unique key (``<id>_<table_name>`` or
        ``<table_name>`` if id is missing) to a dictionary of table attributes:
        ``table_name``, ``table_tags``, ``column_tags``,
        ``primary_key``, and ``foreign_keys``.
    :rtype: Dict[str, Dict[str, Any]]
    """
    df = spark.table(pilotage_table).filter(col("pipeline_name") == pipeline_name)
    if only_tables:
        df = df.filter(col("table_name").isin(only_tables))

    if df.isEmpty():
        print(
            f"[WARN] No rows in {pilotage_table} for pipeline_name={pipeline_name} (filter={only_tables})"
        )
        return {}

    rows = df.collect()
    files_attrs_dict: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        rd = r.asDict()
        rid = rd.get("id")
        table_name = rd.get("table_name")
        key = f"{rid}_{table_name}" if rid is not None else f"{table_name}"
        files_attrs_dict[key] = {
            "table_name": table_name,
            "table_tags": rd.get("table_tags") or {},
            "column_tags": rd.get("column_tags") or {},
            "primary_key": rd.get("primary_key") or [],
            "foreign_keys": rd.get("foreign_keys") or [],
        }
    return files_attrs_dict


FILES_ATTRS_DICT = load_files_attrs_dict(
    pipeline_name=PIPELINE_NAME,
    pilotage_table=DLT_PILOTAGE_TABLE,
    only_tables=ONLY_TABLES,
)
print(f"[INFO] Loaded {len(FILES_ATTRS_DICT)} entries.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3) Apply tags (stack and/or latest)

# COMMAND ----------


results = []
for _, attrs in FILES_ATTRS_DICT.items():
    t = attrs["table_name"]
    ttags = attrs.get("table_tags")
    ctags = attrs.get("column_tags")
    pk = attrs.get("primary_key")
    fks = attrs.get("foreign_keys")

    # 3.1) STACK (landingzone.<schema>.<table>_stack)
    if TAG_STACK:
        stack_full = f"{LANDING_ZONE_CATALOG}.{TARGET_SCHEMA}.{t}_stack"
        status = "skipped"
        error = None
        if table_utils.UnityCatalogCheckTableExists(DbxTablePath=stack_full):
            try:
                retry.retry(
                    func=table_utils.apply_table_tags_uc,
                    exceptions=(ConcurrentAppendException, MetadataChangedException),
                    full_table_name=stack_full,
                    table_tags=ttags,
                    dry_run=DRY_RUN,
                )
                retry.retry(
                    func=table_utils.apply_column_tags_uc,
                    exceptions=(ConcurrentAppendException, MetadataChangedException),
                    full_table_name=stack_full,
                    column_tags=ctags,
                    dry_run=DRY_RUN,
                )
                if APPLY_PK_FK:
                    retry.retry(
                        func=table_utils.apply_pk_fk_tags_uc,
                        exceptions=(
                            ConcurrentAppendException,
                            MetadataChangedException,
                        ),
                        full_table_name=stack_full,
                        primary_key=pk,
                        foreign_keys=fks,
                        dry_run=DRY_RUN,
                    )
                status = "ok" if not DRY_RUN else "dry-run"
            except Exception as e:
                status = "error"
                error = str(e)[:4000]
        else:
            status = "missing"
        results.append((stack_full, "landingzone", status, error))

    # 3.2) LATEST (bronze.<schema>.<table>_latest)
    if TAG_LATEST:
        latest_full = f"{BRONZE_CATALOG}.{TARGET_SCHEMA}.{t}_latest"
        status = "skipped"
        error = None
        if table_utils.UnityCatalogCheckTableExists(DbxTablePath=latest_full):
            try:
                retry.retry(
                    func=table_utils.apply_table_tags_uc,
                    exceptions=(ConcurrentAppendException, MetadataChangedException),
                    full_table_name=latest_full,
                    table_tags=ttags,
                    dry_run=DRY_RUN,
                )
                retry.retry(
                    func=table_utils.apply_column_tags_uc,
                    exceptions=(ConcurrentAppendException, MetadataChangedException),
                    full_table_name=latest_full,
                    column_tags=ctags,
                    dry_run=DRY_RUN,
                )
                if APPLY_PK_FK:
                    retry.retry(
                        func=table_utils.apply_pk_fk_tags_uc,
                        exceptions=(
                            ConcurrentAppendException,
                            MetadataChangedException,
                        ),
                        full_table_name=latest_full,
                        primary_key=pk,
                        foreign_keys=fks,
                        dry_run=DRY_RUN,
                    )
                status = "ok" if not DRY_RUN else "dry-run"
            except Exception as e:
                status = "error"
                error = str(e)[:4000]
        else:
            status = "missing"
        results.append((latest_full, "bronze", status, error))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4) Summary

# COMMAND ----------

schema = "table_full_name string, zone string, status string, error string"
df_res = (
    spark.createDataFrame(results, schema)
    if results
    else spark.createDataFrame([], schema)
)
display(df_res.orderBy("zone", "table_full_name"))

print("[DONE] UC tags applied.")
