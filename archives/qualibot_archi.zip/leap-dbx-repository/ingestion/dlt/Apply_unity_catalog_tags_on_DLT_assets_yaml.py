# Databricks notebook source
# MAGIC %md
# MAGIC # Apply Unity Catalog Tags on tables (Post-DLT, YAML version)
# MAGIC
# MAGIC Apply **Unity Catalog tags** on the tables materialized by the DLT pipeline.
# MAGIC - Source of truth: `pilotage.yml` deployed with the bundle (no pilotage Delta table required)
# MAGIC - Targets: `{landingzone_catalog}.{schema}.{table}_stack`, `{bronze_catalog}.{schema}.{table}_latest`,
# MAGIC   and `{bronze_catalog}.{schema}.{table}_stack` when `optional_bronze_stack: true` (bronze history stack)
# MAGIC - Unity Catalog Tags: table-level + column-level (+ optional logical PK/FK)
# MAGIC
# MAGIC > Run this notebook **after** the pipeline execution, as the 2nd task in the Workflow or just once a day.

# COMMAND ----------

# Add bundle_root to sys.path for leap_utils imports (when running from Asset Bundle)
import sys
dbutils.widgets.text("bundle_root", "")
bundle_root = dbutils.widgets.get("bundle_root")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

# COMMAND ----------

from typing import Dict, Any, Optional, List
from delta.exceptions import ConcurrentAppendException, MetadataChangedException
from leap_utils.data_asset import table_utils
from leap_utils.common import retry
from leap_utils.ingestion.ingestion_declarative_pipeline import load_pilotage_from_yaml

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1) Parameters

# COMMAND ----------

dbutils.widgets.text("pilotage_yaml", "", "Path to pilotage.yml (workspace or /dbfs path)")
dbutils.widgets.text("landingzone_catalog", "dev_landingzone", "Landingzone catalog (e.g. dev_landingzone_hr)")
dbutils.widgets.text("bronze_catalog", "dev_bronze", "Bronze catalog (e.g. dev_bronze_hr)")
dbutils.widgets.text("target_schema", "", "Schema of target tables to tag")
dbutils.widgets.dropdown("tag_stack", "true", ["true", "false"])
dbutils.widgets.dropdown("tag_latest", "true", ["true", "false"])
dbutils.widgets.text("only_tables_csv", "")  # e.g. "table1,table2" (empty = all)
dbutils.widgets.dropdown("dry_run", "false", ["true", "false"])
dbutils.widgets.dropdown("apply_pk_fk", "true", ["true", "false"])

# Env placeholders used only for bucket_name substitution in file-mode tables (optional)
dbutils.widgets.text("reference_read_env", "dev", "Env for {REFERENCE_READ_ENV} substitution")
dbutils.widgets.text("pipeline_write_env", "dev", "Env for {PIPELINE_WRITE_ENV} substitution")

PILOTAGE_YAML = dbutils.widgets.get("pilotage_yaml")
LANDINGZONE_CATALOG = dbutils.widgets.get("landingzone_catalog")
BRONZE_CATALOG = dbutils.widgets.get("bronze_catalog")
TARGET_SCHEMA = dbutils.widgets.get("target_schema")
TAG_STACK = dbutils.widgets.get("tag_stack") == "true"
TAG_LATEST = dbutils.widgets.get("tag_latest") == "true"
ONLY_TABLES_CSV = dbutils.widgets.get("only_tables_csv").strip()
DRY_RUN = dbutils.widgets.get("dry_run") == "true"
APPLY_PK_FK = dbutils.widgets.get("apply_pk_fk") == "true"
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

print(f"[CONFIG] pilotage_yaml={PILOTAGE_YAML}")
print(f"[CONFIG] landingzone_catalog={LANDINGZONE_CATALOG}, bronze_catalog={BRONZE_CATALOG}, target_schema={TARGET_SCHEMA}")
print(f"[CONFIG] tag_stack={TAG_STACK}, tag_latest={TAG_LATEST}, dry_run={DRY_RUN}, apply_pk_fk={APPLY_PK_FK}")

ONLY_TABLES = (
    [t.strip() for t in ONLY_TABLES_CSV.split(",") if t.strip()]
    if ONLY_TABLES_CSV
    else []
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2) Load configuration from YAML

# COMMAND ----------

if not PILOTAGE_YAML:
    raise ValueError(
        "pilotage_yaml parameter is required.\n"
        "Example: /Workspace/Shared/.bundle/my_bundle/dev/files/platform/asset_bundle/my_bundle/src/pilotage.yml"
    )

FILES_ATTRS_DICT = load_pilotage_from_yaml(
    yaml_path=PILOTAGE_YAML,
    reference_read_env=REFERENCE_READ_ENV,
    pipeline_write_env=PIPELINE_WRITE_ENV,
)

if ONLY_TABLES:
    FILES_ATTRS_DICT = {k: v for k, v in FILES_ATTRS_DICT.items() if v["table_name"] in ONLY_TABLES}

print(f"[INFO] Loaded {len(FILES_ATTRS_DICT)} entries from YAML.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3) Apply tags (stack and/or latest)
# MAGIC
# MAGIC **Delta-aware**: current tags are read once per catalog from `information_schema`
# MAGIC (`.column_tags` and `.table_tags`). Only tags that are **missing or different** from the
# MAGIC desired value are re-applied — a stable re-run emits 0 `ALTER`, and also skips the per-column
# MAGIC `DESCRIBE TABLE` that `_normalize_column_name` runs inside `apply_column_tags_uc`.
# MAGIC
# MAGIC > A valueless tag (e.g. `abac_hr_pii_standard`) is stored with an empty `tag_value` — treated
# MAGIC > as "no value" for comparison. A tag removed from the YAML is NOT unset (same as before).

# COMMAND ----------

# DBTITLE 1,Current-state caches + delta helpers
_MISSING = object()  # sentinel: distinguishes "tag absent" from "tag present with empty/null value"

_col_tags_cache = {}  # catalog -> {(table_name, column_lower, tag_name): tag_value}
_tbl_tags_cache = {}  # catalog -> {(table_name, tag_name): tag_value}


def _norm(v):
    """Normalize a tag value for comparison: empty/None -> None, else str(v)."""
    return None if v is None or v == "" else str(v)


def _norm_ci(v):
    """Case-insensitive normalize — for PK/FK values that embed (normalized) column names."""
    n = _norm(v)
    return n.lower() if n is not None else None


def _fmt_tag(k, v):
    """Render a tag for logging: ('key' = 'value') or ('key') for a valueless tag."""
    return f"('{k}')" if _norm(v) is None else f"('{k}' = '{v}')"


def _load_current_tags(catalog: str):
    """Read current column & table tags for TARGET_SCHEMA in `catalog` (one query each)."""
    if catalog in _col_tags_cache:
        return
    col_map = {}
    for r in spark.sql(
        f"SELECT table_name, column_name, tag_name, tag_value "
        f"FROM {catalog}.information_schema.column_tags "
        f"WHERE schema_name = '{TARGET_SCHEMA}'"
    ).collect():
        col_map[(r["table_name"], r["column_name"].lower(), r["tag_name"])] = r["tag_value"]
    _col_tags_cache[catalog] = col_map

    tbl_map = {}
    for r in spark.sql(
        f"SELECT table_name, tag_name, tag_value "
        f"FROM {catalog}.information_schema.table_tags "
        f"WHERE schema_name = '{TARGET_SCHEMA}'"
    ).collect():
        tbl_map[(r["table_name"], r["tag_name"])] = r["tag_value"]
    _tbl_tags_cache[catalog] = tbl_map


def _expected_pk_fk_tags(pk, fks):
    """The tags apply_pk_fk_tags_uc WOULD set, as comparable descriptors:
       ('col', column_lower, tag_name, value) or ('tbl', tag_name, value).
       Column-name case is compared case-insensitively (the util normalizes it at apply time)."""
    exp = []
    pk_cols = [c for c in (pk or []) if c]
    if pk_cols:
        for c in pk_cols:
            exp.append(("col", c.lower(), "primary_key", None))
        exp.append(("tbl", "primary_key_columns", ", ".join(pk_cols)))
    fk_summaries = []
    for fk in (fks or []):
        cols = fk.get("columns") or []
        ref = fk.get("references")
        if not ref:
            continue
        ref_str = f"{ref['table']}({', '.join(ref['columns'])})"
        cname = fk.get("constraint_name")
        for c in cols:
            exp.append(("col", c.lower(), "foreign_key", ref_str))
            if cname:
                exp.append(("col", c.lower(), "foreign_key_constraint_name", cname))
        fk_summaries.append(f"{', '.join(cols)} -> {ref_str}")
    if fk_summaries:
        exp.append(("tbl", "foreign_keys", "\n".join(fk_summaries)))
    return exp


def _pk_fk_present(cur_col, cur_tbl, table, e):
    """True if descriptor `e` already exists on the target with a matching (ci) value."""
    if e[0] == "col":
        _, col, tag, val = e
        cur = cur_col.get((table, col, tag), _MISSING)
    else:
        _, tag, val = e
        cur = cur_tbl.get((table, tag), _MISSING)
    return cur is not _MISSING and _norm_ci(cur) == _norm_ci(val)


def _apply_tags_to_target(full_table_name, ttags, ctags, pk, fks):
    """Apply ONLY the missing/changed tags on one target. Returns (n_applied, n_considered)."""
    catalog, _, table = full_table_name.split(".", 2)
    _load_current_tags(catalog)
    cur_col = _col_tags_cache[catalog]
    cur_tbl = _tbl_tags_cache[catalog]

    n_applied = 0
    n_considered = 0

    # --- table-level tags ---
    ttags_delta = {}
    for k, v in (ttags or {}).items():
        n_considered += 1
        cur = cur_tbl.get((table, k), _MISSING)
        if cur is _MISSING or _norm(cur) != _norm(v):
            ttags_delta[k] = v
    if ttags_delta:
        for k, v in ttags_delta.items():
            print(f"  [TABLE ] {full_table_name} SET TAGS {_fmt_tag(k, v)}")
        retry.retry(
            func=table_utils.apply_table_tags_uc,
            exceptions=(ConcurrentAppendException, MetadataChangedException),
            full_table_name=full_table_name,
            table_tags=ttags_delta,
            dry_run=DRY_RUN,
        )
        n_applied += len(ttags_delta)

    # --- column-level tags ---
    ctags_delta = {}
    for col, tags in (ctags or {}).items():
        d = {}
        for k, v in tags.items():
            n_considered += 1
            cur = cur_col.get((table, col.lower(), k), _MISSING)
            if cur is _MISSING or _norm(cur) != _norm(v):
                d[k] = v
        if d:
            ctags_delta[col] = d
    if ctags_delta:
        for col, tags in ctags_delta.items():
            for k, v in tags.items():
                print(f"  [COLUMN] {full_table_name}.{col} SET TAGS {_fmt_tag(k, v)}")
        retry.retry(
            func=table_utils.apply_column_tags_uc,
            exceptions=(ConcurrentAppendException, MetadataChangedException),
            full_table_name=full_table_name,
            column_tags=ctags_delta,
            dry_run=DRY_RUN,
        )
        n_applied += sum(len(v) for v in ctags_delta.values())

    # --- PK/FK tags (re-applied as a whole only if any expected tag is missing/different) ---
    if APPLY_PK_FK and (pk or fks):
        expected = _expected_pk_fk_tags(pk, fks)
        n_considered += len(expected)
        missing = [e for e in expected if not _pk_fk_present(cur_col, cur_tbl, table, e)]
        if missing:
            for e in missing:
                if e[0] == "col":
                    print(f"  [PK/FK ] {full_table_name}.{e[1]} SET TAGS {_fmt_tag(e[2], e[3])}")
                else:
                    print(f"  [PK/FK ] {full_table_name} SET TAGS {_fmt_tag(e[1], e[2])}")
            retry.retry(
                func=table_utils.apply_pk_fk_tags_uc,
                exceptions=(ConcurrentAppendException, MetadataChangedException),
                full_table_name=full_table_name,
                primary_key=pk,
                foreign_keys=fks,
                dry_run=DRY_RUN,
            )
            n_applied += len(missing)

    return n_applied, n_considered


# COMMAND ----------

# DBTITLE 1,Apply loop (delta-aware)
results = []
for _, attrs in FILES_ATTRS_DICT.items():
    t = attrs["table_name"]
    ttags = attrs.get("table_tags") or {}
    pk = attrs.get("primary_key") or []
    fks = attrs.get("foreign_keys") or []
    ctags = attrs.get("column_tags") or {}

    # 3.1) STACK (landingzone_catalog.<schema>.<table>_stack)
    if TAG_STACK:
        stack_full = f"{LANDINGZONE_CATALOG}.{TARGET_SCHEMA}.{t}_stack"
        status = "skipped"
        error = None
        if table_utils.UnityCatalogCheckTableExists(DbxTablePath=stack_full):
            try:
                n_applied, n_total = _apply_tags_to_target(stack_full, ttags, ctags, pk, fks)
                verb = "dry-run" if DRY_RUN else "ok"
                status = f"{verb} ({n_applied}/{n_total} applied)"
            except Exception as e:
                status = "error"
                error = str(e)[:4000]
        else:
            status = "missing"
        results.append((stack_full, "landingzone", status, error))

    # 3.2) LATEST (bronze_catalog.<schema>.<table>_latest)
    if TAG_LATEST:
        latest_full = f"{BRONZE_CATALOG}.{TARGET_SCHEMA}.{t}_latest"
        status = "skipped"
        error = None
        if table_utils.UnityCatalogCheckTableExists(DbxTablePath=latest_full):
            try:
                n_applied, n_total = _apply_tags_to_target(latest_full, ttags, ctags, pk, fks)
                verb = "dry-run" if DRY_RUN else "ok"
                status = f"{verb} ({n_applied}/{n_total} applied)"
            except Exception as e:
                status = "error"
                error = str(e)[:4000]
        else:
            status = "missing"
        results.append((latest_full, "bronze", status, error))

    # 3.3) BRONZE STACK (bronze_catalog.<schema>.<table>_stack) — optional history stack
    #      Created when optional_bronze_stack: true. Holds the same (PII) columns as latest,
    #      so it must receive the same tags. Gated by TAG_STACK (same intent as the lz stack).
    if TAG_STACK and attrs.get("optional_bronze_stack"):
        bronze_stack_full = f"{BRONZE_CATALOG}.{TARGET_SCHEMA}.{t}_stack"
        status = "skipped"
        error = None
        if table_utils.UnityCatalogCheckTableExists(DbxTablePath=bronze_stack_full):
            try:
                n_applied, n_total = _apply_tags_to_target(bronze_stack_full, ttags, ctags, pk, fks)
                verb = "dry-run" if DRY_RUN else "ok"
                status = f"{verb} ({n_applied}/{n_total} applied)"
            except Exception as e:
                status = "error"
                error = str(e)[:4000]
        else:
            status = "missing"
        results.append((bronze_stack_full, "bronze-stack", status, error))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4) Summary

# COMMAND ----------

schema = "table_full_name string, zone string, status string, error string"
df_res = (
    spark.createDataFrame(results, schema)
    if results
    else spark.createDataFrame([], schema)
)
display(df_res.orderBy("zone", "table_full_name"))

print("[DONE] UC tags applied.")
