# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # GENERIC TABLE INGESTION PIPELINE (SDP + YAML Version)
# MAGIC
# MAGIC **Description:**
# MAGIC Creates bronze tables for each table defined in a YAML configuration file.
# MAGIC This version uses **Spark Declarative Pipelines (SDP)** and loads its configuration
# MAGIC from a `pilotage.yml` file deployed with the bundle — no pilotage Delta table required.
# MAGIC
# MAGIC **Supported stream formats:**
# MAGIC - `file`: reads from S3/object-storage files via Auto Loader (CSV, PARQUET, XML).
# MAGIC   Creates a landingzone stack then a bronze latest.
# MAGIC - `table`: reads from an existing Delta table in the source catalog (e.g. landingzone_hr).
# MAGIC   Creates a bronze latest directly. No landingzone stack is written.
# MAGIC
# MAGIC **Sample Output Tables:**
# MAGIC - `{bronze_catalog}.{target_schema}.{tablename}_latest`     ← always created
# MAGIC - `{bronze_catalog}.{target_schema}.{tablename}_stack`      ← optional (`optional_bronze_stack: true`)
# MAGIC - `{landingzone_catalog}.{target_schema}.{tablename}_stack` ← file mode only

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Standard Package Imports

# COMMAND ----------

from pyspark import pipelines as dp
import pyspark.sql.functions as f
from pyspark.sql import DataFrame
from functools import reduce
from typing import Dict, Any

# COMMAND ----------

# MAGIC %md
# MAGIC ## LEAP Function Imports

# COMMAND ----------

# Add bundle_root to sys.path for leap_utils imports (when running from Asset Bundle)
import sys
bundle_root = spark.conf.get("bundle_root", "")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger
from leap_utils.ingestion.ingestion_declarative_pipeline import (
    load_pilotage_from_yaml,
    get_raw_data,
    get_raw_data_from_table,
    get_latest_view_from_stack,
    normalize_table_tags_for_uc,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pipeline Configuration Parameters

# COMMAND ----------

# Read configuration from pipeline parameters (set in bundle resources/*.pipeline.yml)
pipeline_read_env_param = spark.conf.get("pipeline_read_env", "dev")
pipeline_write_env_param = spark.conf.get("pipeline_write_env", "dev")
reference_read_env_param = spark.conf.get("reference_read_env", "dev")
pipeline_name_param = spark.conf.get("pipeline_name", "default_pipeline")
pilotage_yaml_param = spark.conf.get("pilotage_yaml", "")
landingzone_catalog_param = spark.conf.get("landingzone_catalog", "dev_landingzone")
bronze_catalog_param = spark.conf.get("bronze_catalog", "dev_bronze")
target_schema_param = spark.conf.get("target_schema", "default_schema")
log_level_param = spark.conf.get("log_level", "debug")
lowercase_columns_param = spark.conf.get("lowercase_columns", "true")

# COMMAND ----------

# Create widgets for interactive testing
dbutils.widgets.text("pipeline_write_env", pipeline_write_env_param)
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", pipeline_read_env_param)
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", reference_read_env_param)
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_name", pipeline_name_param)
PIPELINE_NAME = dbutils.widgets.get("pipeline_name")

dbutils.widgets.text("pilotage_yaml", pilotage_yaml_param)
PILOTAGE_YAML = dbutils.widgets.get("pilotage_yaml")

dbutils.widgets.text("landingzone_catalog", landingzone_catalog_param)
LANDINGZONE_CATALOG = dbutils.widgets.get("landingzone_catalog")

dbutils.widgets.text("bronze_catalog", bronze_catalog_param)
BRONZE_CATALOG = dbutils.widgets.get("bronze_catalog")

dbutils.widgets.text("target_schema", target_schema_param)
TARGET_SCHEMA = dbutils.widgets.get("target_schema")

dbutils.widgets.dropdown(
    "lowercase_columns",
    defaultValue=lowercase_columns_param,
    choices=["true", "false"],
)
LOWERCASE_COLUMNS = dbutils.widgets.get("lowercase_columns").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger Setup

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue=log_level_param,
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = setup_applevel_logger(
    log_level=LOG_LEVEL,
    file_log_level=LOG_LEVEL,
    log_format="%(asctime)s - %(name)s - %(levelname)s - %(funcName)s - %(message)s",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Global Variables

# COMMAND ----------

# Catalog and schema configuration
LANDING_ZONE_CATALOG = LANDINGZONE_CATALOG
LANDING_ZONE_SCHEMA = TARGET_SCHEMA
BRONZE_SCHEMA = TARGET_SCHEMA

# Enable auto merge for schema evolution
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Configuration

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV: {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV: {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV: {PIPELINE_WRITE_ENV}")
log.info(f"PIPELINE_NAME: {PIPELINE_NAME}")
log.info(f"PILOTAGE_YAML: {PILOTAGE_YAML}")
log.info(f"LANDING_ZONE_CATALOG: {LANDING_ZONE_CATALOG}")
log.info(f"LANDING_ZONE_SCHEMA: {LANDING_ZONE_SCHEMA}")
log.info(f"BRONZE_CATALOG: {BRONZE_CATALOG}")
log.info(f"BRONZE_SCHEMA: {BRONZE_SCHEMA}")
log.info(f"LOWERCASE_COLUMNS: {LOWERCASE_COLUMNS}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load Pipeline Structure from YAML

# COMMAND ----------

if not PILOTAGE_YAML:
    raise ValueError(
        "pilotage_yaml parameter is required. "
        "Set it in the pipeline configuration to the workspace path of your pilotage.yml file.\n"
        "Example: /Workspace/Repos/leap-dbx-repository/platform/asset_bundle/my_bundle/src/pilotage.yml"
    )

FILES_ATTRS_DICT = load_pilotage_from_yaml(
    yaml_path=PILOTAGE_YAML,
    reference_read_env=REFERENCE_READ_ENV,
    pipeline_write_env=PIPELINE_WRITE_ENV,
)
log.info(f"Loaded {len(FILES_ATTRS_DICT)} tables from YAML: {PILOTAGE_YAML}")
log.debug(f"FILES_ATTRS_DICT: {FILES_ATTRS_DICT}")

# COMMAND ----------

# MAGIC %md
# MAGIC # SDP Table Creation Functions

# COMMAND ----------

# MAGIC %md
# MAGIC ## File Mode — Stack Table/View Creation (Landingzone)

# COMMAND ----------

def create_sdp_stack_table(table_id: str, attrs: Dict[str, Any]):
    """
    Create a SDP streaming table for the landingzone stack (file mode, stacked_stream=True).
    """
    table_name = attrs["table_name"]
    table_comments = attrs.get("table_comments", "Landingzone stack streaming table")
    log.info(f"Creating landingzone stack streaming table for {table_id}: {table_name}")

    base_props = {"quality": "landingzone"}
    tag_props = normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    @dp.table(
        name=f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}_stack",
        comment=table_comments,
        table_properties=table_props,
    )
    def stack_table():
        return get_raw_data(
            attr_dict=attrs,
            table_id=table_id,
            lowercase_columns=LOWERCASE_COLUMNS,
            dbutils=dbutils,
        )


def create_sdp_stack_view(table_id: str, attrs: Dict[str, Any]):
    """
    Create a SDP view for non-streaming file mode (stacked_stream=False).
    """
    table_name = attrs["table_name"]
    log.info(f"Creating landingzone stack view for {table_id}: {table_name}")

    @dp.view(
        name=f"{table_name}_stack",
        comment="Landingzone stack view",
    )
    def stack_view():
        return get_raw_data(
            attr_dict=attrs,
            table_id=table_id,
            lowercase_columns=LOWERCASE_COLUMNS,
            dbutils=dbutils,
        )


# COMMAND ----------

# MAGIC %md
# MAGIC ## Optional Bronze Stack Table Creation

# COMMAND ----------

def create_sdp_bronze_stack_from_file(table_id: str, attrs: Dict[str, Any]):
    """
    Create a SDP materialized view for the bronze stack (file mode, optional).
    Reads from the landingzone stack table.
    """
    table_name = attrs["table_name"]
    log.info(f"Creating bronze stack table (file) for {table_id}: {table_name}")

    base_props = {"quality": "bronze"}
    tag_props = normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    source_table = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}_stack"

    @dp.table(
        name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_stack",
        comment="Bronze stack (copy from landingzone)",
        table_properties=table_props,
    )
    def bronze_stack():
        return spark.read.table(source_table)


def create_sdp_bronze_stack_from_table(table_id: str, attrs: Dict[str, Any]):
    """
    Create a SDP materialized view for the bronze stack (table mode, optional).
    Reads from the source table in the landingzone catalog and normalises it.
    """
    table_name = attrs["table_name"]
    source_table_name = attrs.get("source_table_name", table_name)
    source_has_stack_suffix = attrs.get("source_has_stack_suffix", False)
    source_suffix = "_stack" if source_has_stack_suffix else ""
    source_table = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{source_table_name}{source_suffix}"

    log.info(f"Creating bronze stack table (table) for {table_id}: {table_name} <- {source_table}")

    base_props = {"quality": "bronze"}
    tag_props = normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    @dp.table(
        name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_stack",
        comment="Bronze stack (normalised from source table)",
        table_properties=table_props,
    )
    def bronze_stack():
        return get_raw_data_from_table(
            attr_dict=attrs,
            source_table=source_table,
            lowercase_columns=LOWERCASE_COLUMNS,
        )


# COMMAND ----------

# MAGIC %md
# MAGIC ## Latest Materialized View Creation (Bronze)

# COMMAND ----------

def create_sdp_latest_from_streaming(table_id: str, attrs: Dict[str, Any]):
    """
    Create a SDP materialized view for the latest data from a landingzone streaming stack table.
    (file mode, stacked_stream=True)
    """
    table_name = attrs["table_name"]
    log.info(f"Creating bronze latest (from streaming) for {table_id}: {table_name}")

    primary_key_cols = (
        [col.lower() for col in attrs["primary_key_cols"]]
        if LOWERCASE_COLUMNS
        else attrs["primary_key_cols"]
    )
    if not primary_key_cols:
        primary_key_cols = ["_meta_id"]

    file_mode = attrs["file_mode"]

    base_props = {"quality": "bronze"}
    tag_props = normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    source_table = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}_stack"

    @dp.table(
        name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest",
        comment="Bronze latest materialized view",
        table_properties=table_props,
    )
    def latest_table():
        df_stack = spark.read.table(source_table)
        return get_latest_view_from_stack(df_stack, primary_key_cols, file_mode)


def create_sdp_latest_from_view(table_id: str, attrs: Dict[str, Any]):
    """
    Create a SDP materialized view for the latest data from a local pipeline view.
    (file mode, stacked_stream=False)
    """
    table_name = attrs["table_name"]
    log.info(f"Creating bronze latest (from view) for {table_id}: {table_name}")

    primary_key_cols = (
        [col.lower() for col in attrs["primary_key_cols"]]
        if LOWERCASE_COLUMNS
        else attrs["primary_key_cols"]
    )
    if not primary_key_cols:
        primary_key_cols = ["_meta_id"]

    file_mode = attrs["file_mode"]

    base_props = {"quality": "bronze"}
    tag_props = normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    @dp.table(
        name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest",
        comment="Bronze latest materialized view",
        table_properties=table_props,
    )
    def latest_table():
        df_stack = spark.table(f"LIVE.{table_name}_stack")
        return get_latest_view_from_stack(df_stack, primary_key_cols, file_mode)


def create_sdp_latest_from_table_source(table_id: str, attrs: Dict[str, Any]):
    """
    Create a SDP materialized view for the bronze latest directly from a source Delta table.
    (table mode: landingzone_xxx -> bronze_xxx, no landingzone write)

    The source table is normalised (column cleanup, metadata columns, type casting)
    via get_raw_data_from_table(), then deduplicated by get_latest_view_from_stack().

    Source table name: {landingzone_catalog}.{schema}.{source_table_name}
    (source_table_name defaults to table_name; append _stack if
    source_has_stack_suffix: true in YAML)
    """
    table_name = attrs["table_name"]
    source_table_name = attrs.get("source_table_name", table_name)
    source_has_stack_suffix = attrs.get("source_has_stack_suffix", False)
    source_suffix = "_stack" if source_has_stack_suffix else ""
    source_table = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{source_table_name}{source_suffix}"

    log.info(f"Creating bronze latest (from table source) for {table_id}: {table_name} <- {source_table}")

    primary_key_cols = (
        [col.lower() for col in attrs["primary_key_cols"]]
        if LOWERCASE_COLUMNS
        else attrs["primary_key_cols"]
    )
    if not primary_key_cols:
        primary_key_cols = ["_meta_id"]

    file_mode = attrs["file_mode"]

    base_props = {"quality": "bronze"}
    tag_props = normalize_table_tags_for_uc(attrs.get("table_tags"))
    table_props = {**base_props, **tag_props}

    @dp.table(
        name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest",
        comment="Bronze latest from table source",
        table_properties=table_props,
    )
    def latest_table():
        df = get_raw_data_from_table(
            attr_dict=attrs,
            source_table=source_table,
            lowercase_columns=LOWERCASE_COLUMNS,
        )
        return get_latest_view_from_stack(df, primary_key_cols, file_mode)


# COMMAND ----------

# MAGIC %md
# MAGIC # Pipeline Execution

# COMMAND ----------

# Tables that are NOT real bronze data assets but ingested only for side-channel
# metadata. They get a landingzone stack (view) so the freshness step can read them,
# but must be skipped for bronze latest and freshness view creation.
#   - talend_job_summary: per-run export summary (nomFichier, nbrLignes) used to
#     detect tables exported with 0 rows (see freshness_all()).
SPECIAL_TABLES = {"talend_job_summary"}

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 1: Create Landingzone Stack Tables/Views (file mode only)

# COMMAND ----------

for table_id, attrs in FILES_ATTRS_DICT.items():
    stream_format = attrs.get("stream_format", "file")
    if stream_format != "file":
        log.info(f"Skipping landingzone stack for {table_id} (stream_format={stream_format})")
        continue

    stacked_stream = attrs["stacked_stream"]
    if stacked_stream:
        log.info(f"Creating landingzone stack streaming table for {table_id}")
        create_sdp_stack_table(table_id=table_id, attrs=attrs)
    else:
        log.info(f"Creating landingzone stack view for {table_id}")
        create_sdp_stack_view(table_id=table_id, attrs=attrs)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 2: Create Optional Bronze Stack Tables

# COMMAND ----------

for table_id, attrs in FILES_ATTRS_DICT.items():
    if not attrs.get("optional_bronze_stack", False):
        continue

    stream_format = attrs.get("stream_format", "file")
    stacked_stream = attrs.get("stacked_stream", True)

    if stream_format == "file" and stacked_stream:
        log.info(f"Creating bronze stack table (file) for {table_id}")
        create_sdp_bronze_stack_from_file(table_id=table_id, attrs=attrs)
    elif stream_format == "table":
        log.info(f"Creating bronze stack table (table) for {table_id}")
        create_sdp_bronze_stack_from_table(table_id=table_id, attrs=attrs)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 3: Create Bronze Latest Materialized Views

# COMMAND ----------

for table_id, attrs in FILES_ATTRS_DICT.items():
    # Skip special tables (e.g. talend_job_summary): they have a landingzone stack
    # only, no bronze latest.
    if attrs["table_name"] in SPECIAL_TABLES:
        continue

    stream_format = attrs.get("stream_format", "file")
    stacked_stream = attrs.get("stacked_stream", True)

    if stream_format == "table":
        create_sdp_latest_from_table_source(table_id=table_id, attrs=attrs)
    elif stacked_stream:
        create_sdp_latest_from_streaming(table_id=table_id, attrs=attrs)
    else:
        create_sdp_latest_from_view(table_id=table_id, attrs=attrs)

# COMMAND ----------

# MAGIC %md
# MAGIC # Freshness Monitoring

# COMMAND ----------

freshness_view_names = []


def create_freshness_view(
    source_table: str,
    table_name_short: str,
    frequency: int,
    schema_name: str,
    job_name: str,
    view_name: str,
):
    """
    Create a freshness monitoring view for a bronze latest table.
    """
    @dp.view(name=view_name)
    def _freshness_view():
        return (
            spark.read.table(source_table)
            .agg(f.max("_meta_ingestion_timestamp").alias("last_update_time"))
            .withColumn("frequency", f.lit(frequency).cast("int"))
            .withColumn("schema_name", f.lit(schema_name))
            .withColumn("job_name", f.lit(job_name))
            .withColumn("table_name", f.lit(source_table))
            .withColumn("table_name_short", f.lit(table_name_short))
        )

    return _freshness_view


for table_id, attrs in FILES_ATTRS_DICT.items():
    table_name = attrs["table_name"]

    # Skip special tables (e.g. talend_job_summary): no bronze latest to monitor.
    if table_name in SPECIAL_TABLES:
        continue

    frequency = attrs["frequency"]
    view_name = f"{table_name}_freshness"
    source_table = f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest"

    freshness_view_names.append(f"LIVE.{view_name}")

    create_freshness_view(
        source_table=source_table,
        table_name_short=table_name,
        frequency=frequency,
        schema_name=BRONZE_SCHEMA,
        job_name=PIPELINE_NAME,
        view_name=view_name,
    )


@dp.view(
    name="freshness_all_temp",
    comment="Temporary view aggregating all freshness views",
)
def freshness_all_temp():
    dfs = [spark.table(name) for name in freshness_view_names]
    return reduce(lambda a, b: a.unionByName(b), dfs)


@dp.table(
    name=f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{PIPELINE_NAME}_freshness_all",
    comment="Aggregated freshness monitoring table",
)
def freshness_all():
    df_freshness = spark.table("LIVE.freshness_all_temp")

    # Optional overlay from talend_job_summary: when a source table was exported
    # with 0 rows, no file lands and the bronze latest keeps its previous
    # _meta_ingestion_timestamp. The talend export summary lists every table and its
    # exported row count, so we use it to mark 0-row tables as "fresh as of the
    # pipeline run" instead of stale.
    #
    # Config-driven guard (NOT try/except): we build the join only when a
    # talend_job_summary is actually declared in the pilotage. This makes the
    # dependency on LIVE.talend_job_summary_stack UNCONDITIONAL when configured
    # (so it is linked in the pipeline graph) and lets any real error surface,
    # instead of being silently swallowed. Bundles without a talend_job_summary
    # entry simply return the plain freshness table (backward compatible).
    has_talend = any(
        a["table_name"] == "talend_job_summary" for a in FILES_ATTRS_DICT.values()
    )
    if not has_talend:
        return df_freshness

    df_tjs = (
        spark.table("LIVE.talend_job_summary_stack")
        # nomfichier is either a bare export file name
        #   "20260706_180934_QIM-FRM_Action-F.csv"
        # or a full mount path
        #   "/mnt/.../DEPOT/20260724_143720_INTRAQUAL-GD_DOC-F.parquet".
        # (?:.*/)? drops any leading path; the captured token is lowercased to
        # match the lowercase bronze table_name (lowercase_columns=true).
        .withColumn(
            "table_name_short",
            f.lower(
                f.regexp_extract(
                    f.col("nomfichier"),
                    r"(?:.*/)?\d{8}_\d{6}_[^-]+-([^-]+).*",
                    1,
                )
            ),
        )
        .select(
            f.col("_meta_extraction_timestamp").alias("last_pipeline_ts"),
            "table_name_short",
            f.col("nbrlignes").alias("last_row_count"),
        )
    )
    df_latest_tjs = table_utils.drop_duplicates_by_order(
        df=df_tjs,
        columns=["table_name_short"],
        order_col=["last_pipeline_ts"],
        keep="last",
    )

    # Join on table_name_short
    df_joined = df_freshness.join(df_latest_tjs, on="table_name_short", how="left")

    # Override last_update_time with the pipeline run timestamp when the table was
    # exported with 0 rows.
    df_final = (
        df_joined
        .withColumn(
            "last_update_time",
            f.when(f.col("last_row_count") == 0, f.col("last_pipeline_ts"))
            .otherwise(f.col("last_update_time")),
        )
        .filter(f.col("last_update_time").isNotNull())
        .drop("last_pipeline_ts", "last_row_count", "table_name_short")
    )

    return df_final

# COMMAND ----------

# MAGIC %md
# MAGIC # End of Pipeline
