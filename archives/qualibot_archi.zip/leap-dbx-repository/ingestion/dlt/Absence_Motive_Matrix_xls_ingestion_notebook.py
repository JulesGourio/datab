# Databricks notebook source
# DBTITLE 1,Cell 1
# MAGIC %md
# MAGIC
# MAGIC # ABSENCE MOTIVE MATRIX — XLS INGESTION PIPELINE (SDP + YAML Version)
# MAGIC
# MAGIC **Description:**
# MAGIC Ingests `.xlsx` files deposited manually in a Unity Catalog volume.
# MAGIC Uses Auto Loader (`cloudFiles.format = "excel"`) with per-file pandas processing
# MAGIC to parse each file and append its rows to a **stack** table in the landingzone.
# MAGIC
# MAGIC **Matrix layout:** identification × absence motives, cell = occurrence count → stack table (long format).
# MAGIC Each (employee, motive) pair becomes one row with `motive_name` and `occurrence_count` columns.
# MAGIC
# MAGIC Table-specific parsing parameters (`skip_rows`, `col_stop_marker`, `row_stop_marker`,
# MAGIC `identification_cols`, `excel_max_cell`) are loaded from a `pilotage.yml`
# MAGIC file deployed with the bundle via `load_pilotage_from_yaml`.
# MAGIC
# MAGIC **Source volume:**
# MAGIC `/Volumes/{PIPELINE_WRITE_ENV}_landingzone_hr/manual_files/{TARGET_SCHEMA}/`
# MAGIC
# MAGIC **Output table:**
# MAGIC - Stack: `{LANDINGZONE_CATALOG}.{TARGET_SCHEMA}.{target_table}`
# MAGIC
# MAGIC **Design choices:**
# MAGIC - **Streaming append** — Auto Loader tracks processed files;
# MAGIC   each new file is appended once and never re-processed.
# MAGIC - Table parsing parameters are externalized in `pilotage.yml` (not hardcoded).
# MAGIC - Each (employee, motive) pair becomes one row in the stack table.
# MAGIC - Metadata columns follow the `_meta_*` naming convention of the generic pipeline.
# MAGIC - `year_month` is optionally derived from the filename pattern.
# MAGIC
# MAGIC **Runtime requirement:** Databricks Runtime 17.1+

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Standard Package Imports

# COMMAND ----------

# DBTITLE 1,Cell 4
import re
import sys
import uuid
import unicodedata
import pandas as pd

from pyspark import pipelines as dp
import pyspark.sql.functions as f
from pyspark.sql.types import StructType, StructField, BooleanType, StringType, TimestampType

# COMMAND ----------

# MAGIC %md
# MAGIC ## LEAP Function Imports

# COMMAND ----------

bundle_root = spark.conf.get("bundle_root", "")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

# COMMAND ----------

# DBTITLE 1,Cell 7
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger
from leap_utils.ingestion.ingestion_declarative_pipeline import load_pilotage_from_yaml

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pipeline Configuration Parameters

# COMMAND ----------

# DBTITLE 1,Cell 9
# Read parameters from pipeline configuration
pipeline_write_env_param  = spark.conf.get("pipeline_write_env",  "dev")
reference_read_env_param  = spark.conf.get("reference_read_env",  "dev")
landingzone_catalog_param = spark.conf.get("landingzone_catalog", "dev_landingzone_hr")
log_level_param           = spark.conf.get("log_level",           "debug")
target_schema_param       = spark.conf.get("target_schema",       "default_schema")
pilotage_yaml_param       = spark.conf.get("pilotage_yaml_stack", "")

# COMMAND ----------

# DBTITLE 1,Cell 10
# LEAP constants for this notebook
dbutils.widgets.text("pipeline_write_env", pipeline_write_env_param)
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", reference_read_env_param)
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("landingzone_catalog", landingzone_catalog_param)
LANDINGZONE_CATALOG = dbutils.widgets.get("landingzone_catalog")

dbutils.widgets.dropdown(
    "log_level",
    defaultValue=log_level_param,
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

TARGET_SCHEMA = target_schema_param
PILOTAGE_YAML = pilotage_yaml_param

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger Setup

# COMMAND ----------

log = setup_applevel_logger(
    log_level=LOG_LEVEL,
    file_log_level=LOG_LEVEL,
    log_format="%(asctime)s - %(name)s - %(levelname)s - %(funcName)s - %(message)s",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Global Variables

# COMMAND ----------

# DBTITLE 1,Cell 14
# Load table configuration from pilotage YAML
if not PILOTAGE_YAML:
    raise ValueError("pilotage_yaml parameter is required. Set it in the pipeline configuration.")

files_attrs_dict = load_pilotage_from_yaml(
    yaml_path=PILOTAGE_YAML,
    reference_read_env=REFERENCE_READ_ENV,
    pipeline_write_env=PIPELINE_WRITE_ENV,
)
log.info(f"Loaded {len(files_attrs_dict)} table(s) from YAML: {PILOTAGE_YAML}")

table_conf = list(files_attrs_dict.values())[0]

target_table        = table_conf["table_name"]
excel_max_cell      = table_conf["excel_max_cell"]
skip_rows           = int(table_conf["excel_skip_rows"])
IDENTIFICATION_COLS = table_conf["excel_identification_cols"]
col_stop_marker     = table_conf["excel_col_stop_marker"]
row_stop_marker     = table_conf["excel_row_stop_marker"]
day_filename_pattern     = table_conf.get("excel_day_filename_pattern", "")
file_keyword_simplified  = table_conf.get("file_keyword_simplified", "")
file_regex_pattern       = table_conf.get("file_regex", "")
# If excel_max_cell contains a sheet reference (e.g. "grafik!A5:AU999"), use as-is;
# otherwise compose the standard range from skip_rows and max cell (e.g. "A5:AZ999")
excel_data_address  = excel_max_cell if "!" in excel_max_cell else f"A{skip_rows + 1}:{excel_max_cell}"

VOLUME_PATH = f"/Volumes/{PIPELINE_WRITE_ENV}_landingzone_hr/manual_files/{TARGET_SCHEMA}"

spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

log.info(f"PIPELINE_WRITE_ENV  : {PIPELINE_WRITE_ENV}")
log.info(f"LANDINGZONE_CATALOG : {LANDINGZONE_CATALOG}")
log.info(f"VOLUME_PATH         : {VOLUME_PATH}")
log.info(f"TARGET              : {LANDINGZONE_CATALOG}.{TARGET_SCHEMA}.{target_table}")
log.info(f"HEADER_COLS         : {IDENTIFICATION_COLS}")
log.info(f"col_stop_marker     : {col_stop_marker}")
log.info(f"row_stop_marker     : {row_stop_marker}")
log.info(f"day_filename_pattern     : {day_filename_pattern!r}")
log.info(f"file_keyword_simplified  : {file_keyword_simplified!r}")
log.info(f"file_regex_pattern       : {file_regex_pattern!r}")
log.info(f"excel_data_address       : {excel_data_address}")

# COMMAND ----------

# MAGIC %md
# MAGIC # SDP Table Definition

# COMMAND ----------

# DBTITLE 1,Cell 18
# MAGIC %md
# MAGIC ## Landingzone streaming table
# MAGIC
# MAGIC **Motive matrix:** identification × absence motives, cell = occurrence count → stack table (long format, one row per employee-motive pair).

# COMMAND ----------

# DBTITLE 1,Helpers — utilities, matrix parsing, and stream builder
# -- Utility helpers --------------------------------------------------------

# note: the following function is more or less one from table_utils but there is an error
# with imported leap_utils functions used in the file processing
# Root Cause: ModuleNotFoundError: No module named 'leap_utils' on worker nodes.
def _excel_col_to_num(col_str: str) -> int:
    """Convert Excel column letter(s) to 1-based index. E.g. 'A'=1, 'Z'=26, 'AA'=27, 'AU'=47."""
    num = 0
    for c in col_str.upper():
        num = num * 26 + (ord(c) - ord("A") + 1)
    return num


def _raw_excel_col_count(data_address: str) -> int:
    """Count columns covered by an Excel data_address range.

    Handles plain ranges ('A5:AZ999') and sheet-prefixed ranges ("grafik!A5:AU999").
    Returns end_col - start_col + 1, or 100 as a safe fallback.
    """
    addr = (
        data_address.split("!")[-1].strip()
        if "!" in data_address
        else data_address.strip()
    )
    m = re.match(r"([A-Za-z]+)\d*:([A-Za-z]+)\d*", addr)
    if m:
        return _excel_col_to_num(m.group(2)) - _excel_col_to_num(m.group(1)) + 1
    return 100


def cleanup_column_name(name: str) -> str:
    """Remove accents, replace spaces with underscores,
    strip other special characters (e.g. '/')."""
    if not isinstance(name, str):
        return None
    nfkd = unicodedata.normalize("NFKD", name)
    name = "".join(c for c in nfkd if not unicodedata.combining(c))
    name = name.strip().replace(" ", "_")
    name = re.sub(r"[^a-zA-Z0-9_]", "", name)
    return name.lower().strip()


def _to_nullable_str(series: pd.Series) -> pd.Series:
    """Convert series values to string, preserving nulls as None."""
    mask = series.notna()
    out = pd.Series(None, index=series.index, dtype="object")
    out[mask] = series[mask].astype(str)
    return out


# -- Common matrix parsing core ---------------------------------------------
def _parse_matrix_core(
    pdf: pd.DataFrame,
    identification_cols: list[str],
    column_stop_name: str | None,
    row_stop_name: str | None,
) -> tuple | None:
    """Common parsing logic for the motive-matrix processor.

    Handles:
      1. File metadata extraction (__file_path, __file_name)
      2. Header row (row 0) extraction and normalisation via cleanup_column_name
      3. Column stop marker detection to delimit value columns
      4. Footer/blank row filtering via row stop marker
      5. Value column identification (non-empty columns after identification)

    Returns:
        Tuple (data, header_vals, value_col_positions, file_path, file_name)
        or None if the file is invalid or empty.
    """
    if pdf.empty:
        return None

    # Extract file path and name from metadata columns.
    #   These columns contain the same value at every row, we simply extract
    #   one string being the first positional element (.iloc[0]) of the column.
    #
    #   Nota: Pandas indexing pdf["column_name"] gives the column "column_name",
    #   in fact a pandas Series object
    file_path = str(pdf["__file_path"].iloc[0])
    file_name = str(pdf["__file_name"].iloc[0])

    # Drop Auto Loader metadata columns, we do not need them in the return DataFrame
    data = pdf.drop(columns=["__file_path", "__file_name"])
    # from now on, data has the same schema as pdf minus the metadata columns

    # Normalize the header labels with cleanup_column_name
    #   Row 0 (data.iloc[0, :] = data.iloc[0]) is the Excel header row
    #   If the value is null or contains only spaces, it is converted to an empty string
    #
    #   Nota: .iloc[i_row, i_col] is a DataFrame positional indexing using integer values,
    #   very much like numpy 2D arrays.
    header_vals = [
        cleanup_column_name(str(v)) if (pd.notna(v) and str(v).strip()) else ""
        for v in data.iloc[0, :]
    ]
    log.info(f"Header row: {header_vals}")

    # Eventually we want to remove all useless columns, they start from the column
    # named column_stop_name.
    #   We find column stop marker — its position (integer value column_stop_idx) delimits
    #   value columns from the rest.
    #   If column_stop_name is None, use all remaining columns as value columns.
    if column_stop_name is None:
        column_stop_idx = len(header_vals)
    elif column_stop_name not in header_vals:
        log.error(
            f"Stop marker '{column_stop_name}' not found in {file_name} — file skipped."
        )
        return None
    else:
        column_stop_idx = header_vals.index(column_stop_name)

    # Drop header row, keep only data rows
    #   Nota: by default, a pandas DataFrame is integer-indexed from index 0 to max row - 1
    #   .iloc[1:] enable to keep all rows from row 1 to the end
    #   after this instruction data has indexes starting from 1, we therefore reset
    #   the panda indexing to make it start from 0 instead of 1
    #   (drop = True means we do not keep the old indexes as an additional column)
    data = data.iloc[1:].reset_index(drop=True)
    if data.empty:
        return None

    # Filter out footer (for instance a legend at the bottom of the file) and blank rows based
    # on the first identification column. If no identification columns, keep all rows.
    if identification_cols:
        # Get the first DataFrame column (.iloc[:, 0]) as string or None
        first_column_values = _to_nullable_str(data.iloc[:, 0])
        # Define mask to be a boolean indexing array which is True only for non null
        # or empty string values or equal to indentification columns names
        forbidden_values = ["", *[col.lower() for col in identification_cols]]
        mask = first_column_values.notna() & (
            ~first_column_values.str.strip().str.lower().isin(forbidden_values)
        )
        # Isolate all rows from (and including) the first row which first element value matches row_stop_name
        if row_stop_name is not None:
            # Make sure to clean the row values
            first_column_values_cleaned = first_column_values.apply(cleanup_column_name)
            # Get all the indexes of the occurrence of row_stop_name as the first row value, it is not
            # expected, but there could be several
            stop_indexes = first_column_values_cleaned[
                first_column_values_cleaned == row_stop_name
            ].index
            if len(stop_indexes) > 0:
                # If any index was found, use the first one and update the mask so only the rows before
                # this first occurrence of row_stop_name are kept
                mask = mask & (first_column_values.index < stop_indexes[0])
        # Use mask for boolean indexing on data rows. Only the rows for which the value of mask is True will be
        # kept. Reset index again since we potentially changed the number of rows.
        data = data[mask].reset_index(drop=True)
    if data.empty:
        return None
    log.info(f"Number of rows after masking: {len(data)}")

    # Identify value columns that contain at least one non-empty value after
    # identification columns
    value_col_positions = [
        pos  # mark the column at position pos to be a value column
        for pos in range(
            len(identification_cols), column_stop_idx
        )  # for all columns after identification
        if header_vals[pos] # header cannot be empty
        and data.iloc[:, pos].notna().any()  # At least one non null value in data part
        and (
            data.iloc[:, pos].astype(str).str.strip() != ""
        ).any()  # At least one non empty string
    ]

    return (data, header_vals, value_col_positions, file_path, file_name)


# -- Motive matrix per-file processing --------------------------------------
def process_absence_motive_matrix(
    pdf: pd.DataFrame,
    output_cols: list[str],
    identification_cols: list[str],
    column_stop_name: str | None,
    row_stop_name: str | None,
) -> pd.DataFrame:
    """Parse a motive-matrix Excel file into a long DataFrame.

    Matrix layout: identification columns × absence motive columns,
    cell value = number of occurrences of that motive.
    Output: long format — one row per (employee, motive) pair with
    motive_name and occurrence_count columns. Null/empty cells are filtered out.

    Called once per file via `applyInPandas` (grouped by __file_path).
    The input DataFrame uses positional column names (_c0, _c1, …) because
    Auto Loader reads with headerRows=0; the actual header is row 0 of the data.
    """
    empty = pd.DataFrame(columns=output_cols)

    parsed = _parse_matrix_core(
        pdf, identification_cols, column_stop_name, row_stop_name
    )
    if parsed is None:
        return empty

    data, header_vals, value_col_positions, file_path, file_name = parsed

    # Build a temporary DataFrame with identification + motive value columns
    # for vectorized unpivot via pandas melt
    temp_df = pd.DataFrame(index=data.index)

    # Identification columns (first positional columns of data)
    for i, col_name in enumerate(identification_cols):
        temp_df[col_name] = _to_nullable_str(data.iloc[:, i])

    # Motive columns: use positional temporary names to avoid collisions
    # if two motive columns happen to share the same cleaned header name
    motive_col_labels = []
    for idx, col_pos in enumerate(value_col_positions):
        col_label = f"_motive_{idx}"
        temp_df[col_label] = _to_nullable_str(data.iloc[:, col_pos])
        motive_col_labels.append(col_label)

    # Melt: unpivot motive columns into long format (vectorized, no iterrows)
    melted = temp_df.melt(
        id_vars=identification_cols,
        value_vars=motive_col_labels,
        var_name="_motive_idx",
        value_name="occurrence_count",
    )

    # Map positional index back to actual motive name from header row
    idx_to_name = {
        f"_motive_{idx}": header_vals[pos]
        for idx, pos in enumerate(value_col_positions)
    }
    melted["motive_name"] = melted["_motive_idx"].map(idx_to_name)
    melted = melted.drop(columns=["_motive_idx"])

    # Filter out null/empty occurrence values (no motive recorded for that cell)
    melted = melted[
        melted["occurrence_count"].notna()
        & (melted["occurrence_count"].str.strip() != "")
    ].reset_index(drop=True)

    if melted.empty:
        return empty

    # Attach ingestion metadata (timestamps are placeholders — overwritten by Spark)
    n_rows = len(melted)
    melted = melted.assign(
        _meta_extraction_timestamp=pd.NaT,
        _meta_id=[str(uuid.uuid4()) for _ in range(n_rows)],
        _meta_file_path=file_path,
        _meta_file_name=file_name,
        _meta_file_mode="full",
        _meta_ingestion_timestamp=pd.NaT,
    )

    # _meta_validity_check: True if the first identification column is non-null and non-empty
    if identification_cols:
        first_id_vals = _to_nullable_str(melted[identification_cols[0]])
        melted["_meta_validity_check"] = first_id_vals.notna() & (
            first_id_vals.str.strip() != ""
        )
    else:
        melted["_meta_validity_check"] = True

    log.info(
        f"{file_name}: {len(data)} employees, {len(value_col_positions)} motive col(s), "
        f"{n_rows} total rows after melt"
    )
    return melted[output_cols]


# -- Shared Auto Loader stream builder --------------------------------------
def _build_auto_loader_stream(
    schema: StructType,
    output_cols: list[str],
    identification_cols_clean: list[str],
    column_stop_name: str | None,
    row_stop_name: str | None,
    process_fn,
):
    """Build the streaming DataFrame from Auto Loader through applyInPandas + timestamps.

    Core of the motive matrix pipeline:
      1. Auto Loader reads Excel files with positional column names
      2. File metadata is surfaced as plain columns
      3. Optional filename regex filter is applied
      4. groupBy(__file_path).applyInPandas processes each file with process_fn
      5. Extraction and ingestion timestamps are computed

    Returns:
        Streaming DataFrame with timestamps applied.
    """
    # Auto Loader read — headerRows=0 forces positional column names
    # The Excel header row (row skip_rows+1) is included in the data stream as
    # the first row of each file; it is consumed inside the per-file processor.
    #
    # Explicit raw schema: when dataAddress contains a sheet reference (e.g. "grafik!A5:AU999"),
    # Auto Loader cannot infer the schema (it reads the first sheet, not the target sheet).
    # Providing an explicit schema of _c0…_c(N-1) bypasses inference entirely.
    path_glob = (
        f"*{file_keyword_simplified}*.xls*" if file_keyword_simplified else "*.xls*"
    )
    _n_raw_cols = _raw_excel_col_count(excel_data_address)
    raw_input_schema = StructType(
        [StructField(f"_c{i}", StringType()) for i in range(_n_raw_cols)]
    )
    log.info(
        f"raw_input_schema     : {_n_raw_cols} positional columns (_c0…_c{_n_raw_cols - 1})"
    )

    sdf = (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "excel")
        .option("pathGlobFilter", path_glob)
        .option("headerRows", 0)
        .option("dataAddress", excel_data_address)
        .option("inferSchema", "false")
        .option("cloudFiles.schemaEvolutionMode", "none")
        .schema(raw_input_schema)
        .load(VOLUME_PATH)
    )

    # Surface file metadata as plain columns before groupBy
    sdf = sdf.withColumns(
        {
            "__file_path": f.col("_metadata.file_path"),
            "__file_name": f.col("_metadata.file_name"),
        }
    )

    # Post-load filename filter (file_regex) — drop rows from files that don't match
    if file_regex_pattern:
        sdf = sdf.filter(f.col("__file_name").rlike(file_regex_pattern))
        log.info(f"Applied file_regex filter: {file_regex_pattern}")

    # Group by file -> each group is sent to process_fn as a pandas DataFrame
    sdf_processed = sdf.groupBy("__file_path").applyInPandas(
        lambda df: process_fn(
            df,
            output_cols=output_cols,
            identification_cols=identification_cols_clean,
            column_stop_name=column_stop_name,
            row_stop_name=row_stop_name,
        ),
        schema=schema,
    )

    # _meta_extraction_timestamp: parsed from filename prefix YYYYMMDD_HHmmss or YYYYMMDD_HHmm
    # _meta_ingestion_timestamp: when the pipeline processed the file
    extraction_ts = f.coalesce(
        f.to_timestamp(
            f.regexp_extract(f.col("_meta_file_name"), r"(\d{8}_\d{6})", 1),
            "yyyyMMdd_HHmmss",
        ),
        f.to_timestamp(
            f.regexp_extract(f.col("_meta_file_name"), r"(\d{8}_\d{4})", 1),
            "yyyyMMdd_HHmm",
        ),
    )
    return sdf_processed.withColumn(
        "_meta_extraction_timestamp", extraction_ts
    ).withColumn("_meta_ingestion_timestamp", f.current_timestamp())

# COMMAND ----------

# DBTITLE 1,Stack table — streaming stacked matrix (date or motive)
@dp.table(
    name=f"{LANDINGZONE_CATALOG}.{TARGET_SCHEMA}.{target_table}",
    comment=(
        "Absences data — streaming stack of motive-matrix XLSX files ingested from a volume. "
        "Long format: one row per (employee, motive) pair with occurrence count."
    ),
    table_properties={
        "quality": "landingzone",
        "delta.autoOptimize.optimizeWrite": "true",
        "pipelines.reset.allowed": "true",
    },
    cluster_by=["_meta_extraction_timestamp", "_meta_id"],
)
def create_absence_stack_table():
    # -- Pre-compute cleaned markers (same for every file) ------------------
    identification_cols_clean = [cleanup_column_name(h) for h in IDENTIFICATION_COLS]
    column_stop_name_clean = cleanup_column_name(col_stop_marker)
    row_stop_name_clean = cleanup_column_name(row_stop_marker)

    # MOTIVE MATRIX: identification × absence motives, cell = occurrence count
    # Output: long format — one row per (employee, motive) pair
    motive_schema = StructType(
        [
            StructField("_meta_extraction_timestamp", TimestampType()),
            StructField("_meta_file_mode", StringType()),
            StructField("_meta_file_name", StringType()),
            StructField("_meta_file_path", StringType()),
            StructField("_meta_id", StringType()),
            StructField("_meta_ingestion_timestamp", TimestampType()),
        ]
        + [StructField(c, StringType()) for c in identification_cols_clean]
        + [StructField("motive_name", StringType())]
        + [StructField("occurrence_count", StringType())]
        + [StructField("_meta_validity_check", BooleanType())]
    )
    output_cols = [field.name for field in motive_schema.fields]

    sdf = _build_auto_loader_stream(
        schema=motive_schema,
        output_cols=output_cols,
        identification_cols_clean=identification_cols_clean,
        column_stop_name=column_stop_name_clean,
        row_stop_name=row_stop_name_clean,
        process_fn=process_absence_motive_matrix,
    )

    # Derive year_month from filename pattern using named groups (?<month>...) (?<year>...)
    if day_filename_pattern:
        # We allow the groups to be in different order
        _group_names = [m.group(1) for m in re.finditer(r'\(\?<(\w+)>', day_filename_pattern)]
        _month_idx = _group_names.index("month") + 1
        _year_idx = _group_names.index("year") + 1
        # month name have to be in english for casting to work correctly!
        month_name = f.regexp_extract("_meta_file_name", day_filename_pattern, _month_idx)
        year_str = f.regexp_extract("_meta_file_name", day_filename_pattern, _year_idx)
        year_month_str = f.concat_ws(" ", f.lit("1"), month_name, year_str)
        sdf = sdf.withColumn("year_month", f.to_date(year_month_str, "d MMMM yyyy"))
    else:
        sdf = sdf.withColumn("year_month", f.lit(None).cast("date"))

    return sdf
