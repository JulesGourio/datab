# Databricks notebook source
# MAGIC %md
# MAGIC #Budget Allocation Keys ingestion
# MAGIC Ingestion of budget Allocation Keys tables, for the budget per site/division project. There is one budget table per fiscal year, per scope (ASEU, ASAM, ISEU, ISAM, SPS, etc) and per budget version.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import warnings

warnings.simplefilter(action="ignore", category=FutureWarning)

# COMMAND ----------

import re
from datetime import datetime
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f, Window, Row
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import StructType, StructField, StringType

from leap_utils.common import logger
from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("force_data_asset_computation", "false")
FORCE_DATA_ASSET_COMPUTATION = (
    dbutils.widgets.get("force_data_asset_computation").lower() == "true"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Setup logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "Budget Allocation Keys ingestion"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC Fix root logger

# COMMAND ----------

import logging

logging.getLogger().handlers.clear()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Constants

# COMMAND ----------

INGESTION_SIGMA_FOLDER = f"{PIPELINE_READ_ENV}_bronze.sigma"

TABLENAME_WITH_VALID_REGEX = re.compile(rf"^(budget)\_(allocation_key)(\_.*)?$")

# COMMAND ----------

# MAGIC %md
# MAGIC # Read budget allocation key table from bronze Sigma folder

# COMMAND ----------

tables_df = spark.sql(f"SHOW TABLES IN {INGESTION_SIGMA_FOLDER}")

# Extract only dataset with names matching the regex
list_tables_with_valid_tablename = [
    row.tableName
    for row in tables_df.collect()
    if TABLENAME_WITH_VALID_REGEX.match(row.tableName)
]

if log.level <= logger.LOGGER_MAPPING["debug"]:
    display(list_tables_with_valid_tablename)

# COMMAND ----------

for tbl_name in list_tables_with_valid_tablename:
    full_path = f"{INGESTION_SIGMA_FOLDER}.{tbl_name}"

    # Try to read dataset
    try:
        df = spark.read.table(full_path)
        row_count = df.count()
    except:
        row_count = None

    # Step 1: Compute the latest submit_date per group
    latest_submit_dates = df.groupBy("budget_version", "fiscal_year").agg(
        f.max("submit_date").alias("submit_date")
    )

# COMMAND ----------

# Final list of rows
rows = []
schema = StructType([StructField("fiscal_year", StringType(), True)])
latest_versions_df = spark.createDataFrame([], schema)

for i in range(0, len(list_tables_with_valid_tablename)):
    full_path = f"{INGESTION_SIGMA_FOLDER}.{list_tables_with_valid_tablename[i]}"

    # Try to read dataset
    try:
        df = spark.read.table(full_path)
        row_count = df.count()
    except:
        row_count = None
    # Step 1: Compute the latest submit_date per group
    latest_submit_dates = df.groupBy("budget_version", "fiscal_year").agg(
        f.max("submit_date").alias("submit_date")
    )

    # Step 2: Join with original data to keep all rows matching the latest submit_date
    latest_versions_df = latest_versions_df.unionByName(
        df.join(
            latest_submit_dates,
            on=["budget_version", "fiscal_year", "submit_date"],
            how="inner",
        ),
        allowMissingColumns=True,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stop ingestion if there are no tables to ingest

# COMMAND ----------

tables_to_ingest = len(list_tables_with_valid_tablename) > 0

compute_data_asset = tables_to_ingest | FORCE_DATA_ASSET_COMPUTATION

dbutils.jobs.taskValues.set("compute_data_asset", compute_data_asset)

if not tables_to_ingest:
    dbutils.notebook.exit("No tables to ingest")

# COMMAND ----------

# MAGIC %md
# MAGIC # Add metacolumns

# COMMAND ----------

ingestion_timestamp = datetime.now()

for table in list_tables_with_valid_tablename:
    log.info("Reading table %s at: %s", table, INGESTION_SIGMA_FOLDER)
    display(table)

    # Construct the filename
    filename = f.concat(
        f.date_format(f.col("submit_date"), "yyyyMMdd_HHmmss"),
        f.lit("_budget_"),
        f.lower(f.col("budget_version")),
        f.lit("_allocation_key_"),
        f.col("fiscal_year").cast("string"),
    )
    # filename = f.concat(f.date_format(f.col("submit_date"), "yyyyMMdd_HHmmss"), f.lit("_budget_"))

    metadata_columns = {
        "_meta_filepath": f.lit(f"{INGESTION_SIGMA_FOLDER}.{table}"),
        "_meta_filename": filename,
        "_meta_modification_timestamp": f.to_utc_timestamp(f.col("submit_date"), "UTC"),
        "_meta_ingestion_timestamp": f.to_utc_timestamp(
            f.lit(ingestion_timestamp), "UTC"
        ),
    }

    df_budget_allocation_key = latest_versions_df.withColumns(metadata_columns)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_allocation_key.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #Add or replace ingested tables in a stack table

# COMMAND ----------

try:
    df_budget_allocation_key_old_stack = spark.read.table(
        f"{PIPELINE_READ_ENV}_bronze"
        f".sigma_budget_reporting"
        f".budget_allocation_key_stack"
    )
    df_budget_allocation_key_old_stack.limit(1).collect()

except AnalysisException as e:
    if e.getErrorClass() == "TABLE_OR_VIEW_NOT_FOUND":
        df_budget_allocation_key_old_stack = spark.createDataFrame(
            data=[], schema=df_budget_allocation_key.schema
        )
    else:
        raise AssertionError(
            # TODO change
            "Something went wrong when trying to read "
            "the budget allocation_key stack table."
        ) from e

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_allocation_key_old_stack.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #Remove already ingested tables in old stack

# COMMAND ----------

df_ingested_tablenames = df_budget_allocation_key.select("_meta_filename").distinct()

ingested_tablenames = list(df_ingested_tablenames.toPandas()["_meta_filename"])

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_ingested_tablenames.display()

# COMMAND ----------

df_budget_allocation_key_stack_filtered = df_budget_allocation_key_old_stack.where(
    ~f.col("_meta_filename").isin(*[f.lit(val) for val in ingested_tablenames])
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_allocation_key_stack_filtered.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #Append new ingested tables to stack

# COMMAND ----------

df_budget_allocation_key_new_stack = (
    df_budget_allocation_key_stack_filtered.unionByName(
        df_budget_allocation_key, allowMissingColumns=True
    )
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_allocation_key_new_stack.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #Save new stack

# COMMAND ----------

table_utils.save_table(
    f"{PIPELINE_WRITE_ENV}_bronze"
    f".sigma_budget_reporting"
    f".budget_allocation_key_stack",
    df_budget_allocation_key_new_stack,
    mode="overwrite",
    overwrite_schema=False,
)
