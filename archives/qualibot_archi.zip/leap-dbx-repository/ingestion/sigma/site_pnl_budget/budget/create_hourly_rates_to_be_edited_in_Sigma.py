# Databricks notebook source
# MAGIC %md
# MAGIC #Budget Hourly Rates creation
# MAGIC Dataset to be used in Sigma application

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import warnings
from pyspark.sql import functions as f
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, DateType

from pyspark.sql.utils import AnalysisException

from leap_utils.common import logger
from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

warnings.simplefilter(action="ignore", category=FutureWarning)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("force_data_asset_computation", "false")
FORCE_DATA_ASSET_COMPUTATION = (
    dbutils.widgets.get("force_data_asset_computation").lower() == "true"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Setup logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "Budget workload ingestion"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC Fix root logger

# COMMAND ----------

import logging

logging.getLogger().handlers.clear()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Constants

# COMMAND ----------

BUDGET_AMOUNT_SCHEMA = {
    "division": StringType(),
    "company_code": StringType(),
    "trading_partner_id": StringType(),
    "account_number": StringType(),
    "profit_center": StringType(),
    "material_number": StringType(),
    "plant_assembly": StringType(),
    "plant_production_purchase": StringType(),
    "cost_center": StringType(),
    "WBS_code": StringType(),
    "currency_key": StringType(),
    "fiscal_year": StringType(),
    "amount_01": DoubleType(),
    "amount_02": DoubleType(),
    "amount_03": DoubleType(),
    "amount_04": DoubleType(),
    "amount_05": DoubleType(),
    "amount_06": DoubleType(),
    "amount_07": DoubleType(),
    "amount_08": DoubleType(),
    "amount_09": DoubleType(),
    "amount_10": DoubleType(),
    "amount_11": DoubleType(),
    "amount_12": DoubleType(),
    "_meta_filename": StringType(),
    "_meta_filepath": StringType(),
    "_meta_modification_timestamp": StringType(),
    "_meta_ingestion_timestamp": StringType(),
    "budget_version": StringType(),
    "submit_date": StringType(),
    "template_number": StringType(),
    "submit_user": StringType(),
    "budget_scope": StringType(),
    "conversion_date": DateType(),
    "conversion_rate": DoubleType(),
}

BUDGET_WORKLOAD_SCHEMA = {
    "division": StringType(),
    "company_code": StringType(),
    "trading_partner_id": StringType(),
    "account_number": StringType(),
    "profit_center": StringType(),
    "material_number": StringType(),
    "plant_assembly": StringType(),
    "plant_production_purchase": StringType(),
    "cost_center": StringType(),
    "WBS_code": StringType(),
    "unit": StringType(),
    "fiscal_year": StringType(),
    "quantity_01": DoubleType(),
    "quantity_02": DoubleType(),
    "quantity_03": DoubleType(),
    "quantity_04": DoubleType(),
    "quantity_05": DoubleType(),
    "quantity_06": DoubleType(),
    "quantity_07": DoubleType(),
    "quantity_08": DoubleType(),
    "quantity_09": DoubleType(),
    "quantity_10": DoubleType(),
    "quantity_11": DoubleType(),
    "quantity_12": DoubleType(),
    "_meta_filename": StringType(),
    "_meta_filepath": StringType(),
    "_meta_modification_timestamp": StringType(),
    "_meta_ingestion_timestamp": StringType(),
    "budget_version": StringType(),
    "submit_date": StringType(),
    "submit_user": StringType(),
    "budget_scope": StringType(),
}

amount_schema = StructType(
    [
        StructField(col_name, col_type, True)
        for col_name, col_type in BUDGET_AMOUNT_SCHEMA.items()
    ]
)

workload_schema = StructType(
    [
        StructField(col_name, col_type, True)
        for col_name, col_type in BUDGET_WORKLOAD_SCHEMA.items()
    ]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Import Datasets

# COMMAND ----------

try:
    df_workload = spark.read.table(
        f"{PIPELINE_READ_ENV}_bronze.sigma_budget_reporting.budget_workload_latest_stack"
    )
    df_workload.limit(1).collect()

except AnalysisException as e:
    if e.getErrorClass() == "TABLE_OR_VIEW_NOT_FOUND":
        df_workload = spark.createDataFrame(data=[], schema=workload_schema)
    else:
        raise AssertionError(
            # TODO change
            "Something went wrong when trying to read "
            "the budget FTE stack table."
        ) from e

try:
    df_budget = spark.read.table(
        f"{PIPELINE_READ_ENV}_bronze.sigma_budget_reporting.budget_amount_latest_stack"
    )
    df_budget.limit(1).collect()

except AnalysisException as e:
    if e.getErrorClass() == "TABLE_OR_VIEW_NOT_FOUND":
        df_budget = spark.createDataFrame(data=[], schema=amount_schema)
    else:
        raise AssertionError(
            # TODO change
            "Something went wrong when trying to read "
            "the budget FTE stack table."
        ) from e

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calculate Hourly Rates

# COMMAND ----------

cols_to_groupby = ["budget_version", "fiscal_year", "company_code", "cost_center"]

# COMMAND ----------

amount_aggs = [
    f.sum(f.col(f"amount_{i:02d}")).alias(f"amount_{i:02d}") for i in range(1, 13)
]
quantity_aggs = [
    f.sum(f.col(f"quantity_{i:02d}")).alias(f"quantity_{i:02d}") for i in range(1, 13)
]

df_amount_grouped = df_budget.groupBy(*cols_to_groupby, "currency_key").agg(
    *amount_aggs
)
df_workload_grouped = df_workload.groupBy(*cols_to_groupby, "unit").agg(*quantity_aggs)

# join
df_hourly_rates = df_amount_grouped.join(
    df_workload_grouped, on=cols_to_groupby, how="inner"
)

# add hourly rates
for i in range(1, 13):
    df_hourly_rates = df_hourly_rates.withColumn(
        f"rate_{i:02d}",
        f.try_divide(f.col(f"amount_{i:02d}"), f.col(f"quantity_{i:02d}")),
    )

# Add annual hourly rate, mean of all months (except the null ones)
# Total amount of quantity and of amounts
total_amount = sum(f.col(f"amount_{i:02d}") for i in range(1, 13))
total_quantity = sum(f.col(f"quantity_{i:02d}") for i in range(1, 13))

df_hourly_rates = df_hourly_rates.withColumn(
    "annual_hourly_rate", f.try_divide(total_amount, total_quantity)
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Save table hourly rates

# COMMAND ----------

table_utils.save_table(
    f"{PIPELINE_WRITE_ENV}_bronze"
    f".sigma_budget_reporting"
    f".budget_hourly_rates_to_edit",
    df_hourly_rates,
    mode="overwrite",
    overwrite_schema=False,
)
