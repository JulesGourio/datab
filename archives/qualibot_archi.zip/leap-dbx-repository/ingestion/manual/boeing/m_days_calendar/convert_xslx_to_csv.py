# Databricks notebook source
# MAGIC %md
# MAGIC ## Boeing Manufacturing calendar
# MAGIC
# MAGIC **Description:**
# MAGIC The aim of this notebook is to ingest  xlsx file and convert them to csv while stacking all the already-ingested files in one table:
# MAGIC - Check ingestion format
# MAGIC
# MAGIC **Inputs:**
# MAGIC Files in  f"s3://leap-s3-raw-weeu1-{READ_ENV}/manual/manual_upload/UC22_DEMAND_MANAGEMENT_IS_BOEING/m_calendar_days/"
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - {WRITE_ENV}_bronze.boeing.m_days_calendar_files"
# MAGIC
# MAGIC **Used by:**
# MAGIC
# MAGIC **Triggered by:**
# MAGIC File arrival in s3://leap-s3-weeu1-{READ_ENV}/manual/boeing/m_days_calendar/

# COMMAND ----------

# !pip install  fsspec s3fs openpyxl if local run

# COMMAND ----------

# Imports
import re
from pathlib import Path

import pyspark.pandas as pd
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# Widgets
dbutils.widgets.removeAll()

dbutils.widgets.text("read_env", "dev")
READ_ENV = dbutils.widgets.get("read_env")

dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

# COMMAND ----------

# Global Constants
M_DAYS_CALENDAR_S3 = f"s3://leap-s3-raw-weeu1-{READ_ENV}/manual/manual_upload/UC22_DEMAND_MANAGEMENT_IS_BOEING/m_calendar_days/"
BOEING_BRONZE_DATABASE = (
    f"{WRITE_ENV}_bronze.leap_depot_uc22_demand_management_is_boeing"
)
BOEING_XSLX_TO_CSV_CONVERTED_FILES_TABLE = (
    f"{BOEING_BRONZE_DATABASE}.m_days_calendar_files"
)
BUISNESS_BOEING_COLUMNS = ["Date", "M-Day", "Day Off reason"]
BOEING_COLUMNS = ["Date", "M_Day", "Day_Off_reason"]

# COMMAND ----------

# Read from S3
all_files = dbutils.fs.ls(M_DAYS_CALENDAR_S3)
boeing_s3_xslx_files = spark.createDataFrame(
    [filename for filename in all_files if filename.path.endswith(".xlsx")]
)
boeing_s3_xslx_files = boeing_s3_xslx_files.withColumn(
    "modification_timestamp", f.from_unixtime(f.col("modificationTime") / 1000)
).drop("modificationTime")

# COMMAND ----------

# Compute new files to convert
spark.sql(f"CREATE DATABASE IF NOT EXISTS {BOEING_BRONZE_DATABASE}")

# if table not exist create it
if spark.catalog.tableExists(BOEING_XSLX_TO_CSV_CONVERTED_FILES_TABLE):
    df_boeing_already_converted_files = spark.read.table(
        BOEING_XSLX_TO_CSV_CONVERTED_FILES_TABLE
    )
else:
    df_boeing_already_converted_files = spark.createDataFrame(
        [], boeing_s3_xslx_files.schema
    )
df_updated_boeing_converted_files = boeing_s3_xslx_files
files_to_ingest = boeing_s3_xslx_files.subtract(
    df_boeing_already_converted_files
).select("path")
files_to_ingest_list = list(files_to_ingest.toPandas()["path"])

# COMMAND ----------

# Transform new files to csv
for file_to_ingest in files_to_ingest_list:
    # Filenames
    file_name = Path(file_to_ingest).stem
    converted_file_name = re.sub(" ", "_", file_name) + ".csv"

    # Read excel file and check schema
    pd_excel = pd.read_excel(file_to_ingest, engine="openpyxl", dtype=object)
    if all(pd_excel.columns == BUISNESS_BOEING_COLUMNS) is False:
        raise Exception("The ingestion schema is not respected")
    else:
        print("Correct schema")
    # Rename columns
    pd_excel.columns = BOEING_COLUMNS
    pd_excel.to_csv(
        f"{M_DAYS_CALENDAR_S3}{converted_file_name}", header=True, index=False, sep="|"
    )

    print(f"{converted_file_name}")

# COMMAND ----------

# Show the updated list of files converted to csv
df_updated_boeing_converted_files.show(truncate=False)

# COMMAND ----------

# Save the updated list of files converted to csv
table_utils.save_table(
    dest_table=BOEING_XSLX_TO_CSV_CONVERTED_FILES_TABLE,
    df=df_updated_boeing_converted_files,
    mode="overwrite",
    overwrite_schema=True
)