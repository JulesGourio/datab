# Databricks notebook source
# MAGIC %md
# MAGIC #Boeing Manufacturing calendar
# MAGIC **Description**:
# MAGIC The aim of this notebook is to ingest converted csv file and stack them in the existing table:
# MAGIC
# MAGIC **Inputs**:
# MAGIC
# MAGIC Files in f"s3://leap-s3-raw-weeu1-{READ_ENV}/manual/manual_upload/UC22_DEMAND_MANAGEMENT_IS_BOEING/m_calendar_days/*csv"
# MAGIC
# MAGIC **Output table(s)**:
# MAGIC
# MAGIC {WRITE_ENV}_bronze.boeing.m_days_calendar
# MAGIC
# MAGIC **Triggered by**:
# MAGIC excel-> csv Conversion job

# COMMAND ----------

#  Imports
from databricks.sdk.runtime import dbutils

from leap_utils.config import spark

# COMMAND ----------

# Widgets
dbutils.widgets.removeAll()

dbutils.widgets.text("read_env", "dev")
READ_ENV = dbutils.widgets.get("read_env")

dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

# COMMAND ----------

# Global Constants
boeing_EXTRACT_COLUMN_NUMBER = 3
boeing_EXTRACT_COLUMN_NAME_RANGE = ["Date", "M_Day", "Day_Off_reason"]
boeing_EXTRACT_COLUMN_TYPE_RANGE = ["date", "int", "string"]

S3_boeing_CSV_PATH = f"s3://leap-s3-raw-weeu1-{READ_ENV}/manual/manual_upload/UC22_DEMAND_MANAGEMENT_IS_BOEING/m_calendar_days/"
S3_boeing_CSV_PATH = [
    file.path
    for file in dbutils.fs.ls(S3_boeing_CSV_PATH)
    if file.path.endswith(".csv/")
]

boeing_BRONZE_DATABASE = (
    f"{WRITE_ENV}_bronze.leap_depot_uc22_demand_management_is_boeing"
)
boeing_BRONZE_STACK_TABLE = f"{boeing_BRONZE_DATABASE}.m_days_calendar"

# COMMAND ----------

# Create database if doen't exist
spark.sql(f"CREATE DATABASE IF NOT EXISTS {boeing_BRONZE_DATABASE}")

# COMMAND ----------

# Define stack schema
stack_data_schema = [
    f"{boeing_EXTRACT_COLUMN_NAME_RANGE[i]} string"
    for i in range(boeing_EXTRACT_COLUMN_NUMBER)
]

stack_metadata_schema = [
    "filename string",
    "filepath string",
    "modification_timestamp timestamp",
    "ingestion_timestamp timestamp",
]
stack_schema = ",".join(stack_metadata_schema + stack_data_schema)

# COMMAND ----------

# Create empty stack table
if not spark.catalog.tableExists(boeing_BRONZE_STACK_TABLE):
    spark.sql(
        f"CREATE TABLE IF NOT EXISTS {boeing_BRONZE_STACK_TABLE} ({stack_schema})"
    )

# COMMAND ----------

# Define stack columns selection
select_boeing_data = [
    f"`{column_name}`" for column_name in boeing_EXTRACT_COLUMN_NAME_RANGE
]

select_boeing_metadata = [
    "_metadata.file_name AS filename",
    "_metadata.file_path AS filepath",
    "_metadata.file_modification_time AS modification_timestamp",
    f"now() AS ingestion_timestamp",
]

stack_columns = ", ".join(select_boeing_metadata + select_boeing_data)

# COMMAND ----------

# Copy into stack table
for file in S3_boeing_CSV_PATH:
    # Copy into stack table
    copy_into_result = spark.sql(
        f"""
    COPY INTO {boeing_BRONZE_STACK_TABLE}
    FROM (
        SELECT {stack_columns}
        FROM '{file}'
    )
    FILEFORMAT = CSV
    FORMAT_OPTIONS (
        "header" = "true",
        "delimiter" = "|"
    )
        """
    )

copy_into_result.show()

# COMMAND ----------

spark.read.table(boeing_BRONZE_STACK_TABLE).show(truncate=False)
