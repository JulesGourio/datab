# Databricks notebook source
# MAGIC %md
# MAGIC # Python dependencies needed
# MAGIC `%pip install fsspec s3fs openpyxl`

# COMMAND ----------

# %% Imports
import re

import pandas as pd
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.removeAll()

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.text("read_env", "dev")
READ_ENV = dbutils.widgets.get("read_env")

dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

# COMMAND ----------

# %% Constants
SAGE_S3_XSLX_PATH = f"s3://leap-s3-weeu1-{READ_ENV}/manual/sage/cash_forecast/xlsx/"
SAGE_S3_CSV_PATH = f"s3://leap-s3-weeu1-{READ_ENV}/manual/sage/cash_forecast/gen_csv/"

SAGE_BRONZE_DATABASE = f"{WRITE_ENV}_bronze.sage"
SAGE_XSLX_TO_CSV_CONVERTED_FILES_TABLE = (
    f"{SAGE_BRONZE_DATABASE}.sage_xlsx_to_csv_converted_files"
)

# COMMAND ----------

# %% Read from S3
sage_s3_xslx_files = spark.createDataFrame(dbutils.fs.ls(SAGE_S3_XSLX_PATH))
sage_s3_xslx_files = sage_s3_xslx_files.withColumn(
    "modification_timestamp", f.from_unixtime(f.col("modificationTime") / 1000)
).drop("modificationTime")

if DEBUG:
    sage_s3_xslx_files.show(truncate=False)

# COMMAND ----------

# %% Compute new files to convert
spark.sql(f"CREATE DATABASE IF NOT EXISTS {SAGE_BRONZE_DATABASE}")

if spark.catalog.tableExists(SAGE_XSLX_TO_CSV_CONVERTED_FILES_TABLE):
    df_sage_already_converted_files = spark.read.table(
        SAGE_XSLX_TO_CSV_CONVERTED_FILES_TABLE
    )
else:
    df_sage_already_converted_files = spark.createDataFrame(
        [], sage_s3_xslx_files.schema
    )

df_updated_sage_converted_files = sage_s3_xslx_files
files_to_ingest = sage_s3_xslx_files.subtract(df_sage_already_converted_files).select(
    "path"
)

if DEBUG:
    files_to_ingest.show(truncate=False)

files_to_ingest_list = list(files_to_ingest.toPandas()["path"])

# COMMAND ----------

# %% Transform new files to csv
for file_to_ingest in files_to_ingest_list:
    file_name = file_to_ingest.split("/")[-1].split(".")[0]

    converted_file_name = re.sub(" ", "_", file_name) + ".csv"

    pd_excel = pd.read_excel(file_to_ingest, header=None)
    pd_excel.to_csv(
        f"{SAGE_S3_CSV_PATH}{converted_file_name}", header=False, index=False, sep="|"
    )

    if DEBUG:
        print(f"{converted_file_name=}")

# COMMAND ----------

# %% Show the updated list of files converted to csv
if DEBUG:
    df_updated_sage_converted_files.show(truncate=False)

# COMMAND ----------

# %% Save the updated list of files converted to csv
table_utils.save_table(
    dest_table=SAGE_XSLX_TO_CSV_CONVERTED_FILES_TABLE,
    df=df_updated_sage_converted_files,
    mode="overwrite",
    overwrite_schema=True
)
