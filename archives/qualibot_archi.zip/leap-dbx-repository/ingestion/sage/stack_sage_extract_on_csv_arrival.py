# Databricks notebook source
# %% Imports

from databricks.sdk.runtime import dbutils

from leap_utils.config import spark

# COMMAND ----------

# %% Widgets
dbutils.widgets.removeAll()

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.text("read_env", "dev")
READ_ENV = dbutils.widgets.get("read_env")

dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

# COMMAND ----------

# %% Constants
SAGE_EXTRACT_COLUMN_NUMBER = 23
SAGE_EXTRACT_COLUMN_NAME_RANGE = [
    f"_c{x}" for x in range(0, SAGE_EXTRACT_COLUMN_NUMBER)
]

S3_SAGE_CSV_PATH = f"s3://leap-s3-weeu1-{READ_ENV}/manual/sage/cash_forecast/gen_csv/"

SAGE_BRONZE_DATABASE = f"{WRITE_ENV}_bronze.sage"
SAGE_BRONZE_STACK_TABLE = f"{SAGE_BRONZE_DATABASE}.sage_extract_stack"

# COMMAND ----------

# %% Create database
spark.sql(f"CREATE DATABASE IF NOT EXISTS {SAGE_BRONZE_DATABASE}")

# COMMAND ----------

# %% Define stack schema
stack_data_schema = [
    f"{column_name} string" for column_name in SAGE_EXTRACT_COLUMN_NAME_RANGE
]

stack_metadata_schema = [
    "filename string",
    "filepath string",
    "modification_timestamp timestamp",
    "ingestion_timestamp timestamp",
]
stack_schema = ",".join(stack_metadata_schema + stack_data_schema)

# COMMAND ----------

# %% Create empty stack table
if not spark.catalog.tableExists(SAGE_BRONZE_STACK_TABLE):
    spark.sql(f"CREATE TABLE IF NOT EXISTS {SAGE_BRONZE_STACK_TABLE} ({stack_schema})")

# COMMAND ----------

# %% Define stack columns selection
select_sage_data = [
    f"`{column_name}`" for column_name in SAGE_EXTRACT_COLUMN_NAME_RANGE
]

select_sage_metadata = [
    "_metadata.file_name AS filename",
    "_metadata.file_path AS filepath",
    "_metadata.file_modification_time AS modification_timestamp",
    f"now() AS ingestion_timestamp",
]

stack_columns = ", ".join(select_sage_metadata + select_sage_data)

# COMMAND ----------

# %% Copy into stack table
copy_into_result = spark.sql(
    f"""
COPY INTO {SAGE_BRONZE_STACK_TABLE}
FROM (
    SELECT {stack_columns}
    FROM '{S3_SAGE_CSV_PATH}'
)
FILEFORMAT = CSV
FORMAT_OPTIONS (
    "header" = "false",
    "delimiter" = "|"
)
    """
)

if DEBUG:
    copy_into_result.show()

# COMMAND ----------

# %% Check stack
if DEBUG:
    spark.read.table(SAGE_BRONZE_STACK_TABLE).show(truncate=False)
