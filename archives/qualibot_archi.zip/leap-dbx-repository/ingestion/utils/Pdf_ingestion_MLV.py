# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # MLV PDF ingestion
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC Parse PDF table
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - correct lines drawing with fitz
# MAGIC - extract tables delimited by lines with pdfplumber
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Customs MAROC
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC - {pipeline_read_env}_bronze/customs_maroc/input_mlv_pdfs"
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_zone.domain.table
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_bronze.customs_maroc.mlv_bronze_stack
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Header Definition
# MAGIC ![MLV header](/files/MLV_header.jpg)

# COMMAND ----------

# MAGIC %md
# MAGIC # Item Definition
# MAGIC ![MLV item](/files/MLV_item.jpg)

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

# MAGIC %pip install pdfplumber PyMuPDF

# COMMAND ----------

import pyspark.sql.functions as f
import pandas as pd
import logging
import os
from tempfile import TemporaryDirectory

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.files import pdf_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("run_job_on_latest", "true")  # history/update
RUN_JOB_ON_LATEST = dbutils.widgets.get("run_job_on_latest").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

input_pdfs_path = f"/Volumes/{PIPELINE_READ_ENV}_bronze/customs_maroc/input_mlv_pdfs"

corrected_pdfs = f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.corrected_mlv_pdfs"
corrected_pdfs_path = (
    f"/Volumes/{PIPELINE_WRITE_ENV}_bronze/customs_maroc/corrected_mlv_pdfs"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

archived_pdfs = f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.archived_mlv_pdfs"
archived_pdfs_path = (
    f"/Volumes/{PIPELINE_WRITE_ENV}_bronze/customs_maroc/archived_mlv_pdfs"
)

archived_corrected_pdfs = (
    f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.archived_corrected_mlv_pdfs"
)
archived_corrected_pdfs_path = (
    f"/Volumes/{PIPELINE_WRITE_ENV}_bronze/customs_maroc/archived_corrected_mlv_pdfs"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables

# COMMAND ----------

MLV_BRONZE_STACK_TABLE = f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.mlv_bronze_stack"

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - draw lines

# COMMAND ----------

# Avoid unwanted Warnings
logging.getLogger("pdfminer").setLevel(logging.ERROR)

# COMMAND ----------

# Prepare volume for corrected pdfs
spark.sql(f"CREATE VOLUME IF NOT EXISTS {corrected_pdfs}")

# COMMAND ----------

# Prepare volume for archive source pdfs
spark.sql(f"CREATE VOLUME IF NOT EXISTS {archived_pdfs}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Process again archived pdfs
# MAGIC
# MAGIC Copy archived files to input volume

# COMMAND ----------

if not RUN_JOB_ON_LATEST:
    for pdf_file in os.listdir(archived_pdfs_path):
        archive_pdf = f"{archived_pdfs_path}/{pdf_file}"
        input_pdf = f"{input_pdfs_path}/{pdf_file}"
        dbutils.fs.cp(f"{archive_pdf}", f"{input_pdf}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Process input_pdfs_path
# MAGIC
# MAGIC Clean PDF by drawing border and correct lines

# COMMAND ----------

working_path = input_pdfs_path

with TemporaryDirectory() as tmp_dir:
    for pdf_file in os.listdir(working_path):
        input_pdf = f"{working_path}/{pdf_file}"
        if input_pdf.endswith(".pdf"):
            log.info(f"Source PDF : {input_pdf}")
            output_pdf = f"{corrected_pdfs_path}/{pdf_file}"
            try:
                dbutils.fs.rm(f"{output_pdf}")
                pdf_utils.process_pdf_lines_completion(
                    input_pdf_path=input_pdf,
                    output_pdf_path=output_pdf,
                    temporary_path=tmp_dir,
                    x_completion=5,
                    y_top_completion=13,
                    y_bottom_completion=25,
                    y_len_min=10,
                    connect_disjoint_verticals=False,
                )  # tuned values : x_completion=5, y_top_completion=13, y_bottom_completion=25, y_len_min=10
            except Exception as e:
                log.error(f"Error processing PDF {input_pdf}: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - extract header and table_data
# MAGIC
# MAGIC Parse all MLV PDFs , extract table_data bounded by lines

# COMMAND ----------

# Main document tags
main_balise_aliases = {
    "MINISTERE": "depot",
    "Déposée": "depot",
    "Clôturée": "depot",
    "A ENREGISTREMENT": "enregistrement",
    "1 DECLARATION": "declaration",
    "4 bureau": "bureau",
    "3 Nombre total\ndes articles": "total_item_count",
    "19 Taux de change": "currency_change",
    "23 Valeur totale déclarée": "total_value_declared",
}

# Item tags
item_balise_aliases = {
    "29 N° d'ordre\nde l'art.": "item_number",
    "36 Pays d'origine (Nom et code)": "country_of_origin",
    "31 Valeur déclarée": "value_declared",
    "34 AP ou SP": "ap_sp",
    "designation": "designation",
    "qty": "qty",
    "unit": "unit",
    "30 Code marchandises": "code_march",
}

pdf_list = []

if RUN_JOB_ON_LATEST:
    pdf_names = os.listdir(corrected_pdfs_path)
else:
    pdf_names = os.listdir(corrected_pdfs_path) + os.listdir(
        archived_corrected_pdfs_path
    )

for pdf_name in pdf_names:
    # Filter specific files in DEBUG mode
    if (
        LOG_LEVEL == logging.DEBUG
        and pdf_name != "30002220240011516.pdf"
        and pdf_name != "41102220240009758.pdf"
        and pdf_name != "30002320240008224.pdf"
        and pdf_name != "30102220240003972.pdf"
    ):
        continue

    if pdf_name in os.listdir(corrected_pdfs_path):
        working_pdf_path = os.path.join(corrected_pdfs_path, pdf_name)
    else:
        working_pdf_path = os.path.join(archived_corrected_pdfs_path, pdf_name)

    working_pdf = f"{corrected_pdfs_path}/{pdf_name}"
    log.debug(f"pdf_name : {pdf_name}")

    try:
        table_data = pdf_utils.extract_mlv_main_table(
            pdf_path=working_pdf_path,
            main_balise_aliases=main_balise_aliases,
            item_balise_aliases=item_balise_aliases,
        )
        if table_data:  # Check that it is not None or []
            pdf = pd.DataFrame(table_data)
            pdf_list.append(pdf)

            log.info(f"{pdf_name} → {len(pdf)} rows extracted")
            log.debug(table_data)
        else:
            log.warning(f"No data found in {pdf_name}")

    except Exception as e:
        log.error(f"Error creating DataFrame for {pdf_name} : {e}")

if not pdf_list:
    dbutils.notebook.exit(f"Empty data")  # Exit the notebook without error
pdf_final = pd.concat(pdf_list, ignore_index=True)

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    pdf_final.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 - Post Processing
# MAGIC
# MAGIC Post-Processing of cells
# MAGIC

# COMMAND ----------

df_reordered = pdf_utils.mlv_post_processing(
    df=pdf_final,
)

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    df_reordered.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality checks
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check total amount vs items amount

# COMMAND ----------

# Calculate quality check column "is_valid"
df_checked = spark.createDataFrame(
    pdf_utils.quality_check_customs_pdf_extracted_data(
        df=df_reordered,
        column_to_sum="value_declared",
        column_to_compare_to="total_value_declared",
    )
)

# Keep only valid rows
df_validated = df_checked.filter(f.col("is_valid")).drop("is_valid")

# COMMAND ----------

df_checked.filter(~f.col("is_valid")).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### MLV BRONZE STACK

# COMMAND ----------

if (table_utils.UnityCatalogCheckTableExists(MLV_BRONZE_STACK_TABLE)) and (
    RUN_JOB_ON_LATEST == True
):
    # Merge the source DataFrame into the target table
    table_utils.merge_into(
        df_source=df_validated,
        target_table=MLV_BRONZE_STACK_TABLE,
        list_id_matching_columns=[
            "pdf_name",
            "_meta_extraction_timestamp",
            "sous_dum",
            "code_march",
            "item_number",
        ],
    ).display()
else:
    # Save the table from DataFrame df_validated
    result = table_utils.save_table(
        dest_table=MLV_BRONZE_STACK_TABLE,
        df=df_validated,
        mode="overwrite",
        overwrite_schema=True,
        cluster_cols="_meta_extraction_timestamp,pdf_name,page_number,item_number",
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - File Archiving

# COMMAND ----------

# Prepare volume for archive corrected pdfs
spark.sql(f"CREATE VOLUME IF NOT EXISTS {archived_corrected_pdfs}")

# COMMAND ----------

validated_pdf_names = [
    row["pdf_name"] for row in df_validated.select("pdf_name").distinct().collect()
]

for pdf_file in os.listdir(corrected_pdfs_path):
    if pdf_file in validated_pdf_names:
        # archive files
        try:
            dbutils.fs.mv(
                f"{input_pdfs_path}/{pdf_file}",
                f"{archived_pdfs_path}/{pdf_file}",
            )
            log.info(
                f"Archived file {pdf_file} from {input_pdfs_path} to {archived_pdfs_path}"
            )
        except Exception as e:
            log.error(
                f"Error archiving {input_pdfs_path}/{pdf_file}.\nException is :{e}\n"
            )

        try:
            dbutils.fs.mv(
                f"{corrected_pdfs_path}/{pdf_file}",
                f"{archived_corrected_pdfs_path}/{pdf_file}",
            )
            log.info(
                f"Archived file {pdf_file} from {corrected_pdfs_path} to {archived_corrected_pdfs_path}"
            )
        except Exception as e:
            log.error(
                f"Error archiving {corrected_pdfs_path}/{pdf_file}.\nException is :{e}\n"
            )

# COMMAND ----------

# MAGIC %md
# MAGIC # Exceptions if any detected

# COMMAND ----------

# Detect PDFs with errors
df_exceptions = df_checked.filter(~f.col("is_valid"))

# Final check
if df_exceptions.count() > 0:
    df_exceptions.sort(f.col("pdf_name"), f.col("item_number")).display()
    raise Exception("Some rows did not pass the quality check")

# COMMAND ----------

df_exceptions.select(f.col("pdf_name")).distinct().count()
