# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # ZIP to Files Extractor
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to extract all files from ZIP archives and rename them with a timestamp prefix.
# MAGIC Designed for Airbus LATELEC XML data exchange files.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC ## This Notebook requires a classic cluster (NOT serverless)
# MAGIC - Python zipfile/shutil operations require local filesystem access
# MAGIC - Use job_cluster with policy:
# MAGIC ```yaml
# MAGIC job_clusters:
# MAGIC   - job_cluster_key: job_cluster
# MAGIC     new_cluster:
# MAGIC       policy_id: ${var.job_cluster_policy_id}
# MAGIC       apply_policy_default_values: true
# MAGIC       spark_version: 17.3.x-scala2.13
# MAGIC       node_type_id: r6idn.xlarge
# MAGIC ```
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Airbus XML data ingestion (pre-processing before DLT)
# MAGIC
# MAGIC **Sample Input File**
# MAGIC - s3://leap-s3-raw-weeu1-{reference_read_env}/manual/leapdepot/UC27_AVERAGE_BOM/airbus_bom/YYYYMMDD_HHmmSS_AIRBUS-LATELEC-YYYYMMDD-A320-XML-84ZWJU5L5_01-1-1.ZIP
# MAGIC
# MAGIC **Sample Output Files**
# MAGIC - s3://leap-s3-raw-weeu1-{pipeline_write_env}/apps/airbus_bom/YYYYMMDD_HHmmSS_{PROGRAMME}_{CODE_CHANTIER}-O_ECN-F.xml
# MAGIC - s3://leap-s3-raw-weeu1-{pipeline_write_env}/apps/airbus_bom/YYYYMMDD_HHmmSS_{PROGRAMME}_{CODE_CHANTIER}-L_REL-F.xml
# MAGIC - Example: `20260226_000000_A320_84ZWJU5L5_01-L_REL-F.xml`
# MAGIC
# MAGIC **Temporary Volume**
# MAGIC - /Volumes/{pipeline_write_env}_landingzone/{temp_schema}/{temp_volume}/
# MAGIC
# MAGIC **Naming Convention**
# MAGIC - Input ZIP: `YYYYMMDD_HHmmSS_AIRBUS-LATELEC-YYYYMMDD2-{PROGRAMME}-XML-{CODE_CHANTIER}-1-1.zip`
# MAGIC - Output XML: `YYYYMMDD2_000000_{PROGRAMME}_{CODE_CHANTIER}-{FILENAME}-F.xml`
# MAGIC - Example: `L_REL.xml` from `20260227_121140_AIRBUS-LATELEC-20260226-A320-XML-84ZWJU5L5_01-1-1.zip`
# MAGIC   → `20260226_000000_A320_84ZWJU5L5_01-L_REL-F.xml`
# MAGIC - Note: CODE_CHANTIER (e.g., 84ZWJU5L5_01) identifies the site; multiple sites can exist per aircraft

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import os
import re
import logging
import zipfile
import shutil

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

# Add bundle_root to sys.path for leap_utils imports (when running from Asset Bundle)
import sys

dbutils.widgets.text("bundle_root", "")
bundle_root = dbutils.widgets.get("bundle_root")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

# COMMAND ----------

from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("log_level", "info")
LOG_LEVEL = dbutils.widgets.get("log_level")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text(
    "s3_source_path",
    "s3://leap-s3-raw-weeu1-prod/manual/leapdepot/UC27_AVERAGE_BOM/airbus_bom/",
)
S3_SOURCE_PATH = dbutils.widgets.get("s3_source_path")

dbutils.widgets.text(
    "s3_output_path",
    "s3://leap-s3-raw-weeu1-dev/apps/airbus_bom/",
)
S3_OUTPUT_PATH = dbutils.widgets.get("s3_output_path")

dbutils.widgets.text(
    "s3_archive_path",
    "s3://leap-s3-raw-weeu1-dev/archive/manual/leapdepot/UC27_AVERAGE_BOM/airbus_bom/",
)
S3_ARCHIVE_PATH = dbutils.widgets.get("s3_archive_path")

# Programme identifier (e.g., A320, A350, A380)
dbutils.widgets.text("programme", "A320")
PROGRAMME = dbutils.widgets.get("programme")

# File extension filter (default: xml)
dbutils.widgets.text("file_extension", "xml")
FILE_EXTENSION = dbutils.widgets.get("file_extension").lower()

# Schema name for temporary volume in landingzone (use underscores, not hyphens)
dbutils.widgets.text("temp_schema", "airbus_bom")
TEMP_SCHEMA = dbutils.widgets.get("temp_schema")

# Volume name for temporary files
dbutils.widgets.text("temp_volume", "zip_files")
TEMP_VOLUME = dbutils.widgets.get("temp_volume")

# COMMAND ----------

# MAGIC %md
# MAGIC ### LOG LEVEL
# MAGIC
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue=LOG_LEVEL,
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# Regex pattern to extract timestamp and code chantier from ZIP filename
# Format: YYYYMMDD_HHmmSS_AIRBUS-LATELEC-YYYYMMDD-{PROGRAMME}-XML-{CODE_CHANTIER}-1-1.zip
# Example: 20260227_121140_AIRBUS-LATELEC-20260226-A320-XML-84ZWJU5L5_01-1-1.zip
# The code chantier (e.g., 84ZWJU5L5_01) is crucial as there can be multiple sites per aircraft
ZIP_PATTERN_AIRBUS_1 = re.compile(
    r"^(\d{8})_(\d{6})_AIRBUS-LATELEC-(\d{8})-([A-Z0-9]+)-XML-([A-Z0-9_]+)-\d+-\d+\.zip$",
    re.IGNORECASE,
)

ZIP_PATTERN_AIRBUS_2 = re.compile(
    r"^AIRBUS-LATELEC-(\d{8})-([A-Z0-9]+)-XML-([A-Z0-9_]+)-\d+-\d+\.zip$",
    re.IGNORECASE,
)

# Alternative pattern for simpler naming (fallback to PROGRAMME widget)
ZIP_PATTERN_SIMPLE_WITH_TIMESTAMP = re.compile(
    r"^(\d{8}_\d{6})_.*\.zip$", re.IGNORECASE
)


def parse_zip_filename(filename: str) -> tuple[str, str]:
    """
    Extract timestamp and identifier from ZIP filename.

    Args:
        filename: ZIP filename AIRBUS1 (e.g., 20260227_121140_AIRBUS-LATELEC-20260226-A320-XML-84ZWJU5L5_01-1-1.zip) (-> from LEAPDEPOT)
                  ZIP filename AIRBUS2 (e.g., AIRBUS-LATELEC-20260226-A320-XML-84ZWJU5L5_01-1-1.zip) (-> direct upload in S3)
                  ZIP filename SIMPLE WITH TIMESTAMP (e.g., 20260227_121140_*.zip)

    Returns:
        Tuple of (timestamp, program + "_" + code_chantier) for Airbus pattern,
        or (timestamp, PROGRAMME) for simple pattern fallback
    """
    # Try full Airbus pattern first - extract program + code chantier from file
    match = ZIP_PATTERN_AIRBUS_1.match(filename)
    if match:
        date2 = match.group(3)  # Date from filename (e.g., 20260226)
        program = match.group(4)  # Program from filename (e.g., A320)
        code_chantier = match.group(5)  # Site identifier (e.g., 84ZWJU5L5_01)
        # Use date2 as timestamp base (data creation date)
        timestamp = f"{date2}_000000"
        log.info(f"  Code chantier detected: {code_chantier}")
        return timestamp, program + "_" + code_chantier

    match = ZIP_PATTERN_AIRBUS_2.match(filename)
    if match:
        date2 = match.group(1)  # Date from filename (e.g., 20260226)
        program = match.group(2)  # Program from filename (e.g., A320)
        code_chantier = match.group(3)  # Site identifier (e.g., 84ZWJU5L5_01)
        # Use date2 as timestamp base (data creation date)
        timestamp = f"{date2}_000000"
        log.info(f"  Code chantier detected: {code_chantier}")
        return timestamp, program + "_" + code_chantier

    # Fallback to simple pattern - use PROGRAMME widget
    match_simple = ZIP_PATTERN_SIMPLE_WITH_TIMESTAMP.match(filename)
    if match_simple:
        log.info(f"  Using PROGRAMME widget value: {PROGRAMME}")
        return match_simple.group(1), PROGRAMME

    # If no pattern matches, try to extract at least the timestamp
    timestamp_match = re.match(r"^(\d{8}_\d{6})", filename)
    if timestamp_match:
        log.info(f"  Using PROGRAMME widget value (fallback): {PROGRAMME}")
        return timestamp_match.group(1), PROGRAMME

    raise ValueError(f"Cannot parse timestamp from ZIP filename: {filename}")


def build_output_filename(
    original_filename: str, timestamp: str, identifier: str
) -> str:
    """
    Build output filename with timestamp prefix.

    Args:
        original_filename: Original filename from ZIP (e.g., L_REL.xml)
        timestamp: Timestamp string (e.g., 20260226_000000)
        identifier: Code chantier (e.g., 84ZWJU5L5_01) or programme (e.g., A320)

    Returns:
        New filename (e.g., 20260226_000000_84ZWJU5L5_01-L_REL-F.xml)
    """
    # Remove extension
    name_without_ext = os.path.splitext(original_filename)[0]
    ext = os.path.splitext(original_filename)[1].lower()

    # Build new filename: YYYYMMDD_HHmmSS_{IDENTIFIER}-{NAME}-F.{ext}
    new_filename = f"{timestamp}_{identifier}-{name_without_ext}-F{ext}"

    return new_filename


# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the ZIP files

# COMMAND ----------

log.info(f"S3_SOURCE_PATH is:  {S3_SOURCE_PATH}")
log.info(f"PROGRAMME is:  {PROGRAMME}")
log.info(f"FILE_EXTENSION filter is:  {FILE_EXTENSION}")
log.info(f"TEMP_SCHEMA is:  {TEMP_SCHEMA}")
log.info(f"TEMP_VOLUME is:  {TEMP_VOLUME}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Create output folder if not exists

# COMMAND ----------

log.info(f"S3_OUTPUT_PATH is:  {S3_OUTPUT_PATH}")
dbutils.fs.mkdirs(S3_OUTPUT_PATH)

# COMMAND ----------

log.info(f"S3_ARCHIVE_PATH is:  {S3_ARCHIVE_PATH}")
dbutils.fs.mkdirs(S3_ARCHIVE_PATH)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# Statistics counters
total_zip_processed = 0
total_files_extracted = 0
total_files_skipped = 0
errors_list = []

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - List ZIP Files

# COMMAND ----------

try:
    files = dbutils.fs.ls(S3_SOURCE_PATH)
    if len(files) == 0:
        dbutils.jobs.taskValues.set("compute_dlt", False)
        dbutils.notebook.exit(f"No files in {S3_SOURCE_PATH}")

    zip_files = [f.path for f in files if f.path.lower().endswith(".zip")]
except Exception as e:
    dbutils.jobs.taskValues.set("compute_dlt", False)
    dbutils.notebook.exit(f"Exception reading source path: {S3_SOURCE_PATH}\n{e}")

if len(zip_files) == 0:
    dbutils.jobs.taskValues.set("compute_dlt", False)
    dbutils.notebook.exit(f"No ZIP files in {S3_SOURCE_PATH}")

log.info(f"{len(zip_files)} ZIP files found.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Temp directory in a Volume

# COMMAND ----------

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {PIPELINE_WRITE_ENV}_landingzone.{TEMP_SCHEMA}")

# COMMAND ----------

spark.sql(
    f"CREATE VOLUME IF NOT EXISTS {PIPELINE_WRITE_ENV}_landingzone.{TEMP_SCHEMA}.{TEMP_VOLUME}"
)

# COMMAND ----------

unity_catalog_volume = (
    f"/Volumes/{PIPELINE_WRITE_ENV}_landingzone/{TEMP_SCHEMA}/{TEMP_VOLUME}/"
)

# Ensure temp extraction directory exists
temp_extract_dir = f"{unity_catalog_volume}/extracted/"
os.makedirs(temp_extract_dir, exist_ok=True)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations and output
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------


def extract_and_rename_files(
    zip_path: str, timestamp: str, identifier: str, temp_dir: str
) -> list[tuple[str, str]]:
    """
    Extract files from ZIP and rename them.

    Args:
        zip_path: Path to ZIP file
        timestamp: Timestamp string for output filenames
        identifier: Code chantier or programme identifier for output filenames
        temp_dir: Temporary directory for extraction

    Returns:
        List of tuples (original_name, new_name) for extracted files
    """
    extracted_files = []

    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        # List all files in ZIP
        for file_info in zip_ref.infolist():
            # Skip directories
            if file_info.is_dir():
                continue

            original_name = os.path.basename(file_info.filename)

            # Filter by extension if specified
            if FILE_EXTENSION and not original_name.lower().endswith(
                f".{FILE_EXTENSION}"
            ):
                log.debug(f"Skipping {original_name} (not matching extension filter)")
                continue

            # Build new filename
            new_name = build_output_filename(original_name, timestamp, identifier)

            # Extract file
            zip_ref.extract(file_info, temp_dir)
            extracted_path = os.path.join(temp_dir, file_info.filename)

            # Handle nested directories in ZIP
            if os.path.dirname(file_info.filename):
                # Move file from nested directory to temp_dir root
                final_extracted_path = os.path.join(temp_dir, original_name)
                shutil.move(extracted_path, final_extracted_path)
                extracted_path = final_extracted_path

            extracted_files.append((extracted_path, new_name))

    return extracted_files


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Extract and Rename Files from ZIP
# MAGIC

# COMMAND ----------

for zip_file_path in zip_files:
    zip_file_name = os.path.basename(zip_file_path)
    local_zip_path = f"{unity_catalog_volume}/{zip_file_name}"

    log.info(f"\n{'='*60}")
    log.info(f"Processing ZIP: {zip_file_name}")
    log.info(f"{'='*60}")

    try:
        # Parse timestamp and identifier (code chantier or programme) from ZIP filename
        timestamp, identifier = parse_zip_filename(zip_file_name)
        log.info(f"  Timestamp: {timestamp}")
        log.info(f"  Identifier: {identifier}")

        # Download ZIP file from S3 to local volume
        log.info(f"  Downloading ZIP from S3...")
        dbutils.fs.cp(zip_file_path, local_zip_path)

        # Create temp extraction directory for this ZIP (handle .zip and .ZIP)
        zip_base_name = re.sub(r"\.zip$", "", zip_file_name, flags=re.IGNORECASE)
        zip_temp_dir = f"{temp_extract_dir}/{zip_base_name}/"
        os.makedirs(zip_temp_dir, exist_ok=True)

        # Extract and rename files
        log.info(f"  Extracting files...")
        extracted_files = extract_and_rename_files(
            local_zip_path, timestamp, identifier, zip_temp_dir
        )

        if len(extracted_files) == 0:
            log.warning(f"  No matching files found in ZIP")
            total_files_skipped += 1
            continue

        log.info(f"  Found {len(extracted_files)} files to process")

        # Copy renamed files to S3 output
        for extracted_path, new_name in extracted_files:
            s3_output_file = f"{S3_OUTPUT_PATH}{new_name}"

            # Copy to S3
            dbutils.fs.cp(f"{extracted_path}", s3_output_file)
            log.info(f"  ✓ {os.path.basename(extracted_path)} → {new_name}")

            # Clean up extracted file
            os.remove(extracted_path)
            total_files_extracted += 1

        # Clean up temp extraction directory
        shutil.rmtree(zip_temp_dir, ignore_errors=True)

        # Clean up local ZIP file
        dbutils.fs.rm(local_zip_path)

        total_zip_processed += 1

        # Set job task value to indicate files were processed
        dbutils.jobs.taskValues.set("compute_dlt", True)

    except Exception as e:
        error_msg = f"Error processing {zip_file_name}: {str(e)}"
        log.error(error_msg)
        errors_list.append(error_msg)

        # Clean up on error
        try:
            dbutils.fs.rm(local_zip_path)
        except:
            pass

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation Summary

# COMMAND ----------

log.info(f"\n{'='*60}")
log.info("EXTRACTION SUMMARY")
log.info(f"{'='*60}")
log.info(f"  ZIP files processed: {total_zip_processed}")
log.info(f"  Files extracted: {total_files_extracted}")
log.info(f"  Files skipped: {total_files_skipped}")
log.info(f"  Errors: {len(errors_list)}")

if errors_list:
    log.warning("Errors encountered:")
    for error in errors_list:
        log.warning(f"  - {error}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Archiving

# COMMAND ----------

for zip_file_path in zip_files:
    zip_file_name = os.path.basename(zip_file_path)

    try:
        # Archive ZIP file
        archive_path = f"{S3_ARCHIVE_PATH}{zip_file_name}"
        dbutils.fs.cp(zip_file_path, archive_path)
        dbutils.fs.rm(zip_file_path)  # Remove original after archiving

        log.info(f"Archived: {zip_file_name} → {archive_path}")
    except Exception as e:
        log.error(f"Error archiving {zip_file_name}: {str(e)}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Final Status

# COMMAND ----------

if total_files_extracted == 0:
    dbutils.jobs.taskValues.set("compute_dlt", False)
    log.warning("No files were extracted. DLT pipeline will not be triggered.")
else:
    dbutils.jobs.taskValues.set("compute_dlt", True)
    log.info(
        f"Successfully extracted {total_files_extracted} files. DLT pipeline will be triggered."
    )

# COMMAND ----------

# Raise error if any ZIP failed to process
if errors_list:
    raise Exception(f"Errors occurred during processing:\n" + "\n".join(errors_list))
