# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # SOMMIER PDF ingestion
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC Parse PDF header and tables
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - crop page to the good bounding box
# MAGIC - find table delimited by lines
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Customs MAROC
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC - {pipeline_read_env}_bronze/customs_maroc/input_sommier_pdfs"
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_bronze.customs_maroc.sommier_bronze_stack
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Header Definition
# MAGIC ![Sommier header](/files/SOMMIER_header.jpg)

# COMMAND ----------

# MAGIC %md
# MAGIC # Item Definition page 1
# MAGIC ![Sommier item](/files/SOMMIER_item_page1.jpg)
# MAGIC
# MAGIC # Item Definition last page
# MAGIC ![Sommier item](/files/SOMMIER_item_last_page.jpg)

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

# MAGIC %pip install pdfplumber PyMuPDF

# COMMAND ----------

import pyspark.sql.functions as f
import pandas as pd
import logging
import os
from tempfile import TemporaryDirectory

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.files import pdf_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("run_job_on_latest", "true")  # history/update
RUN_JOB_ON_LATEST = dbutils.widgets.get("run_job_on_latest").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

input_pdfs_path = (
    f"/Volumes/{PIPELINE_READ_ENV}_bronze/customs_maroc/input_sommier_pdfs"
)

corrected_pdfs = f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.corrected_sommier_pdfs"
corrected_pdfs_path = (
    f"/Volumes/{PIPELINE_WRITE_ENV}_bronze/customs_maroc/corrected_sommier_pdfs"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

archived_pdfs = f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.archived_sommier_pdfs"
archived_pdfs_path = (
    f"/Volumes/{PIPELINE_WRITE_ENV}_bronze/customs_maroc/archived_sommier_pdfs"
)

archived_corrected_pdfs = (
    f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.archived_corrected_sommier_pdfs"
)
archived_corrected_pdfs_path = f"/Volumes/{PIPELINE_WRITE_ENV}_bronze/customs_maroc/archived_corrected_sommier_pdfs"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables

# COMMAND ----------

SOMMIER_BRONZE_STACK_TABLE = (
    f"{PIPELINE_WRITE_ENV}_bronze.customs_maroc.sommier_bronze_stack"
)
SOMMIER_GOLD_TABLE = f"{PIPELINE_WRITE_ENV}_gold.customs_maroc.sommier_gold"

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - draw lines
# MAGIC
# MAGIC Clean PDF by drawing border and correct lines

# COMMAND ----------

# Avoid unwanted Warnings
logging.getLogger("pdfminer").setLevel(logging.ERROR)

# COMMAND ----------

# Prepare volume for corrected pdfs
spark.sql(f"CREATE VOLUME IF NOT EXISTS {corrected_pdfs}")

# COMMAND ----------

# Prepare volume for archive source pdfs
spark.sql(f"CREATE VOLUME IF NOT EXISTS {archived_pdfs}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Process again archived pdfs
# MAGIC
# MAGIC Copy archived files to input volume

# COMMAND ----------

if not RUN_JOB_ON_LATEST:
    for pdf_file in os.listdir(archived_pdfs_path):
        archive_pdf = f"{archived_pdfs_path}/{pdf_file}"
        input_pdf = f"{input_pdfs_path}/{pdf_file}"
        dbutils.fs.cp(f"{archive_pdf}", f"{input_pdf}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Process input_pdfs_path
# MAGIC
# MAGIC Clean PDF by drawing border and correct lines

# COMMAND ----------

working_path = input_pdfs_path

with TemporaryDirectory() as tmp_dir:
    for pdf_file in os.listdir(working_path):
        input_pdf = f"{working_path}/{pdf_file}"
        if input_pdf.endswith(".pdf"):
            log.info(f"Source PDF : {input_pdf}")
            output_pdf = f"{corrected_pdfs_path}/{pdf_file}"
            try:
                dbutils.fs.rm(f"{output_pdf}")
                pdf_utils.process_pdf_lines_completion(
                    input_pdf_path=input_pdf,
                    output_pdf_path=output_pdf,
                    temporary_path=tmp_dir,
                    add_border=False,
                    x_completion=5,
                    y_top_completion=5,
                    y_bottom_completion=50,
                    y_len_min=5,
                    connect_disjoint_verticals=True,
                )  # tuned values
            except Exception as e:
                log.error(f"Error processing PDF {input_pdf}: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - extract header and table_data
# MAGIC
# MAGIC Parse all Sommier PDFs , extract header and table_data

# COMMAND ----------

header_columns = [
    "pdf_name",
    "page_number",
    "reference",
    "reference_date",
    "state",
    "echeance_date",
    "demandeur",
    "registre",
    "total_value_declared",
]
table_columns = [
    "nomenclature",
    "item_number",
    "dec_apurement",
    "dec_apurement_2",
    "dec_apurement_3",
    "quantity",
    "unit",
    "rate",
    "quantity_waste",
    "gross_value",
    "account",
    "apu",
    "date",
]

expected_columns = header_columns + table_columns
expected_num_columns = len(expected_columns)

pdf_list = []
no_data_found_list = []
data_found_list = []

if RUN_JOB_ON_LATEST:
    pdf_names = os.listdir(corrected_pdfs_path)
else:
    pdf_names = os.listdir(corrected_pdfs_path) + os.listdir(
        archived_corrected_pdfs_path
    )

for pdf_name in pdf_names:
    if not pdf_name.lower().endswith(".pdf"):
        continue

    # In DEBUG mode, only process some specific files
    if (
        LOG_LEVEL == logging.DEBUG and pdf_name != "sommier - 2025-04-09T200622.869.pdf"
    ):  # and pdf_name != "sommier - 2025-04-09T195357.116.pdf":
        continue

    if pdf_name in os.listdir(corrected_pdfs_path):
        working_pdf_path = os.path.join(corrected_pdfs_path, pdf_name)
    else:
        working_pdf_path = os.path.join(archived_corrected_pdfs_path, pdf_name)

    log.debug(f"pdf_name : {pdf_name}")
    try:
        table_data = pdf_utils.extract_sommier_header_and_main_table(
            pdf_path=working_pdf_path,
            expected_number_of_columns=expected_num_columns,
        )
        if table_data:  # Check that it is not None or []
            pdf = pd.DataFrame(table_data, columns=expected_columns)
            pdf_list.append(pdf)

            log.info(f"{pdf_name} → {len(pdf)} rows extracted")
            data_found_list.append(pdf_name)
        else:
            log.warning(f"No data found in {pdf_name}")
            no_data_found_list.append(pdf_name)

    except Exception as e:
        log.error(f"Error creating DataFrame for {pdf_name} : {e}")

log.info(f"Total number of PDF extracted: {len(data_found_list)}")
log.info(f"Total number of PDF not extracted: {len(no_data_found_list)}")

# COMMAND ----------

if not pdf_list:
    dbutils.notebook.exit(f"Empty data")  # Exit the notebook without error
pdf_final = pd.concat(pdf_list, ignore_index=True)

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    pdf_final.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 - Post Processing
# MAGIC
# MAGIC Post-Processing of cells
# MAGIC

# COMMAND ----------

df_reordered = pdf_utils.sommier_post_processing(
    df=pdf_final,
)

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    df_reordered.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality checks
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check total amount vs items amount

# COMMAND ----------

# Calculate quality check column "is_valid"
df_checked = spark.createDataFrame(
    pdf_utils.quality_check_customs_pdf_extracted_data(
        df=df_reordered,
        column_to_sum="gross_value",
        column_to_compare_to="total_value_declared",
    )
)

# Keep only valid rows
df_validated = df_checked.filter(f.col("is_valid")).drop("is_valid")

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    df_validated.display()

# COMMAND ----------

df_checked.filter(~f.col("is_valid")).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### SOMMIER BRONZE STACK

# COMMAND ----------

if (table_utils.UnityCatalogCheckTableExists(SOMMIER_BRONZE_STACK_TABLE)) and (
    RUN_JOB_ON_LATEST == True
):
    table_utils.merge_into(
        df_source=df_validated,
        target_table=SOMMIER_BRONZE_STACK_TABLE,
        list_id_matching_columns=[
            "pdf_name",
            "_meta_extraction_timestamp",
            "reference",
            "nomenclature",
            "item_number",
        ],
    ).display()
else:
    # Save the latest table from Dataframe df_validated
    table_utils.save_table(
        dest_table=SOMMIER_BRONZE_STACK_TABLE,
        df=df_validated,
        mode="overwrite",
        overwrite_schema=True,
        cluster_cols="_meta_extraction_timestamp,pdf_name,page_number,item_number",
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - File Archiving

# COMMAND ----------

spark.sql(f"CREATE VOLUME IF NOT EXISTS {archived_corrected_pdfs}")

# COMMAND ----------

validated_pdf_names = [
    row["pdf_name"] for row in df_validated.select("pdf_name").distinct().collect()
]

for pdf_file in os.listdir(corrected_pdfs_path):
    if pdf_file in validated_pdf_names:
        # archive files
        try:
            dbutils.fs.mv(
                f"{input_pdfs_path}/{pdf_file}",
                f"{archived_pdfs_path}/{pdf_file}",
            )
            log.info(
                f"Archived file {pdf_file} from {input_pdfs_path} to {archived_pdfs_path}"
            )
        except Exception as e:
            log.error(
                f"Error archiving {input_pdfs_path}/{pdf_file}.\nException is :{e}\n"
            )

        try:
            dbutils.fs.mv(
                f"{corrected_pdfs_path}/{pdf_file}",
                f"{archived_corrected_pdfs_path}/{pdf_file}",
            )
            log.info(
                f"Archived file {pdf_file} from {corrected_pdfs_path} to {archived_corrected_pdfs_path}"
            )
        except Exception as e:
            log.error(
                f"Error archiving {corrected_pdfs_path}/{pdf_file}.\nException is :{e}\n"
            )


# COMMAND ----------

# MAGIC %md
# MAGIC # Exceptions if any detected

# COMMAND ----------

# Detect PDFs with errors
df_exceptions = df_checked.filter(~f.col("is_valid"))

# Final check
if df_exceptions.count() > 0:
    df_exceptions.sort(f.col("pdf_name"), f.col("item_number")).display()
    raise Exception("Some rows did not pass the quality check")

# COMMAND ----------

df_exceptions.select(f.col("pdf_name")).distinct().count()
