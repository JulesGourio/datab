# Databricks notebook source
# MAGIC %md
# MAGIC # This Notebook perform mass conversion of CSV files to Parquet
# MAGIC ## Mandatory parameters:
# MAGIC - source_bucket : type str, default value "leap-s3-weeu1-prod"
# MAGIC - dest_bucket : type str, default value "leap-s3-raw-weeu1-dev"
# MAGIC - Prefix : type str, default value "sap/raw_xx"
# MAGIC - batch_size : type int, default value 100, is the number of files per batch
# MAGIC - nbthreads : type int, default value 4, is the number of parallel threads or the number of parallel files converted
# MAGIC
# MAGIC ## Optional parameters:
# MAGIC - param : is optional parameter to specify
# MAGIC   1. wheter you want to convert entire prefix or subelement like : Tables or Objects
# MAGIC     - Tables : List of str , representing table names to convert files from. default value ""
# MAGIC     - Objects : List of str , representing file names to convert files from. default value ""
# MAGIC   2. wheter you want to "Create" (mean copy and convert source to dest) or to "Delete" (mean clenup the destination)
# MAGIC     - RequestType : type str , representing action, default value "Create", possible value "Delete" for target deletion, any other value is considered as "Create"
# MAGIC   3. default value : ""
# MAGIC - modifiedAfter : is optional parameter to specify wheter to convert only files newer than "YYYYmmDD"
# MAGIC
# MAGIC ### param template :
# MAGIC   1. specifying objects to copy/convert
# MAGIC ```
# MAGIC params = {
# MAGIC   "ResourceProperties": {
# MAGIC     "SourceBucket": "leap-s3-weeu1-prod",
# MAGIC     "DestBucket": "leap-s3-raw-weeu1-dev",
# MAGIC     "Prefix": "sap/raw_co/",
# MAGIC     "Objects": [
# MAGIC        "5022398_SAP-EBAN-F_20230625_083645_0008.dat",
# MAGIC        "2992965_SAP-AFKO-F_20221204_091820_0001.dat"
# MAGIC      ]
# MAGIC   },
# MAGIC   "RequestType": "Create"
# MAGIC }
# MAGIC ```
# MAGIC
# MAGIC   2. specifying tables to copy/convert
# MAGIC ```
# MAGIC params = {
# MAGIC   "ResourceProperties": {
# MAGIC     "SourceBucket": "leap-s3-weeu1-prod",
# MAGIC     "DestBucket": "leap-s3-raw-weeu1-dev",
# MAGIC     "Prefix": "sap/raw_co/",
# MAGIC     "Tables": [
# MAGIC         "COSP",
# MAGIC         "CSKA"
# MAGIC     ]
# MAGIC   },
# MAGIC   "RequestType": "Create"
# MAGIC }
# MAGIC ```
# MAGIC
# MAGIC   3. specifying tables or objects to delete on destination
# MAGIC ```
# MAGIC params = {
# MAGIC   "ResourceProperties": {
# MAGIC     "SourceBucket": "leap-s3-weeu1-prod",
# MAGIC     "DestBucket": "leap-s3-raw-weeu1-dev",
# MAGIC     "Prefix": "sap/raw_co/",
# MAGIC     "Tables": [
# MAGIC         "COSP",
# MAGIC         "CSKA"
# MAGIC     ]
# MAGIC   },
# MAGIC   "RequestType": "Delete"
# MAGIC }
# MAGIC ```

# COMMAND ----------

import json
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
from typing import List, Tuple

# DBTITLE 1,Librairies
import pandas as pd
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.types import StringType, StructField, StructType

spark.conf.set("spark.sql.execution.arrow.enabled", "false")

# COMMAND ----------

# DBTITLE 1,Set up logger
import logging

from pyspark.sql.utils import AnalysisException

from leap_utils.common.logger import get_logger, setup_applevel_logger

setup_applevel_logger(log_level=logging.INFO, file_log_level=logging.INFO)

log = get_logger(module_name=__name__)

# COMMAND ----------

# DBTITLE 1,Widgets
# Get source_bucket environment variable
dbutils.widgets.text("source_bucket", "leap-s3-weeu1-prod")
source_bucket = dbutils.widgets.get("source_bucket")

# Get dest_bucket environment variable
dbutils.widgets.text("dest_bucket", "leap-s3-raw-weeu1-dev")
dest_bucket = dbutils.widgets.get("dest_bucket")

# Get prefix environment variable
dbutils.widgets.text("prefix", "sap/raw_xx")
prefix = dbutils.widgets.get("prefix")

# Get param environment variable
params_json_str = None
params = None
dbutils.widgets.text("params", "")
params_json_str = dbutils.widgets.get("params")
if params_json_str is not None and params_json_str != "" and params_json_str != "{}":
    try:
        params = json.loads(params_json_str)
    except:
        log.warning(
            "params is not correct JSON structure, using only source_bucket, dest_bucket and prefix"
        )
else:
    log.info("params is not provided, using only source_bucket, dest_bucket and prefix")

# Get threads environment variable
dbutils.widgets.text("nbthreads", "4")
NBTHREADS = eval(dbutils.widgets.get("nbthreads"))

# Get batch_size environment variable
dbutils.widgets.text("batch_size", "100")
BATCH_SIZE = eval(dbutils.widgets.get("batch_size"))

# Get modifiedAfter variable (date)
dbutils.widgets.text("modifiedAfter", "")
# modifiedAfter will be "19700101" by default if not provided , the format is 'YYYYmmDD_HHMMSS'
MODIFIED_AFTER = (
    "19700101"
    if dbutils.widgets.get("modifiedAfter") == ""
    else dbutils.widgets.get("modifiedAfter")
)

# Get debug variable (bool)
dbutils.widgets.text("debug", "False")
DEBUG = eval(dbutils.widgets.get("debug"))
if DEBUG:
    setup_applevel_logger(log_level=logging.DEBUG, file_log_level=logging.INFO)
else:
    setup_applevel_logger(log_level=logging.INFO, file_log_level=logging.INFO)

# COMMAND ----------

# DBTITLE 1,Do params parsing
# if params is not None then Interpret options set in params and override other widgets (source_bucket, dest_bucket and prefix)
if params is not None:
    try:
        try:
            source_bucket = params["ResourceProperties"]["SourceBucket"]
        except:
            log.critical("La valeur de source_bucket n'est pas définie dans params")
            raise ValueError()

        try:
            dest_bucket = params["ResourceProperties"]["DestBucket"]
        except:
            log.critical("La valeur de dest_bucket n'est pas définie dans params")
            raise ValueError()
        if not dest_bucket.startswith("leap-s3-raw"):
            log.critical(
                "Erreur: la valeur de dest_bucket ne commence pas par 'leap-s3-raw'"
            )
            raise ValueError()

        try:
            prefix = params["ResourceProperties"]["Prefix"]
        except:
            log.critical("La valeur de prefix n'est pas définie dans params")
            raise ValueError()
        if not prefix.startswith("sap/"):
            log.critical("La valeur de prefix ne commence pas par 'sap/'")
            raise ValueError()

        try:
            objects = params["ResourceProperties"]["Objects"]
        except:
            objects = None
        try:
            tables_list = params["ResourceProperties"]["Tables"]
        except:
            tables_list = None
        try:
            request_type = params["RequestType"]
        except:
            request_type = "Create"

    except Exception as e:
        message = """Bad Parameters ! Below usage examples !

                        Example to Migrate files for some Tables:
                        params = {
                            "ResourceProperties": {
                                "SourceBucket": "leap-s3-weeu1-prod",
                                "DestBucket": "leap-s3-raw-weeu1-dev",
                                "Prefix": "sap/raw_mm/",
                                "Tables": [
                                    "AFKO",
                                    "BKPF"
                                ]    
                            },
                            "RequestType": "Create"
                        }

                        Example to Migrate files based on a list:
                        params = {
                            "ResourceProperties": {
                                "SourceBucket": "leap-s3-weeu1-prod",
                                "DestBucket": "leap-s3-raw-weeu1-dev",
                                "Prefix": "sap/raw_mm/",
                                "Objects": [
                                "5022398_SAP-EBAN-F_20230625_083645_0008.dat",
                                "2985823_SAP-MBEW-F_20221130_101135_0001.dat",
                                "5022398_SAP-EBAN-F_20230625_083645_end.end",
                                "2992965_SAP-AFKO-F_20221204_091820_0001.dat"
                                ]   
                            },
                            "RequestType": "Create"
                        }                    

                        Example to Migrate files on whole prefix:
                        params = {
                            "ResourceProperties": {
                                "SourceBucket": "leap-s3-weeu1-prod",
                                "DestBucket": "leap-s3-raw-weeu1-dev",
                                "Prefix": "sap/raw_mm/"
                            },
                            "RequestType": "Create"
                        }

                        Example to Delete files in destination bucket for some Tables:
                        params = {
                            "ResourceProperties": {
                                "SourceBucket": "leap-s3-weeu1-prod",
                                "DestBucket": "leap-s3-raw-weeu1-dev",
                                "Prefix": "sap/raw_xx/",
                                "Tables": [
                                    "AFKO",
                                    "BKPF"
                                ]    
                            },
                            "RequestType": "Delete"
                        }

                        """
        raise Exception(message)
        logging.error("Exception: %s" % e, exc_info=True)
    log.info(
        f"using following params :\n\nsource_bucket : {source_bucket}\ndest_bucket : {dest_bucket}\nprefix : {prefix}\nrequest_type : {request_type}\nobjects : {objects}\ntables_list : {tables_list}\nBATCH_SIZE : {BATCH_SIZE}\nNBTHREADS : {NBTHREADS}\nMODIFIED_AFTER : {MODIFIED_AFTER}\nDEBUG : {DEBUG}\n"
    )
else:
    request_type = "Create"  # other parameters provided in widgets
    tables_list = None
    objects = None
    log.info(
        f"using following params :\n\nsource_bucket : {source_bucket}\ndest_bucket : {dest_bucket}\nprefix : {prefix}\nrequest_type : {request_type}\nBATCH_SIZE : {BATCH_SIZE}\nNBTHREADS : {NBTHREADS}\nMODIFIED_AFTER : {MODIFIED_AFTER}\nDEBUG : {DEBUG}\n"
    )

# COMMAND ----------

# DBTITLE 1,Globals variables
FILE_HEADER_PATH = f"s3://leap-s3-weeu1-prod/sap/0.parameters/LEAP_entete_table.csv"  # We need the prod entete file

TABLE_CONCAT_INFO_PATH = (
    f"s3://{dest_bucket}/erp/sap_latecoere_ecc6/parameters/table_concat_info.csv"
)

TABLE_DEST_PATTERN = "erp/sap_latecoere_ecc6/tables/{}/active"
TABLE_ARCHIVE_DEST_PATTERN = "archive/erp/sap_latecoere_ecc6/tables/{}/active"

# COMMAND ----------


# DBTITLE 1,Functions
def file_exists_in_s3(s3_path: str) -> bool:
    # receive a s3 path as input
    # return True if file exists else False

    try:
        # check=dbutils.fs.head(s3_path, 1)
        dbutils.fs.ls(s3_path)
    except:
        return False
    else:
        return True


def load_dat_file_from_s3(source_bucket: str, source_key: str) -> SparkDataFrame:
    # Read S3 object and return Spark Dataframe only for files "*.dat" else return None
    source_path = f"s3://{source_bucket}/{source_key}"

    if source_path.endswith(".dat"):
        df_res = spark.read.options(
            inferSchema=False,
            delimiter="|",
            header=False,
            multiline=True,
            ignoreLeadingWhiteSpace=True,
            ignoreTrailingWhiteSpace=True,
            escape='"',
        ).csv(source_path)
        return df_res
    else:
        return None


def list_files_in_s3_bucket_with_prefix(
    source_bucket: str, source_prefix: str
) -> List[str]:
    # List files under s3://{source_bucket}/{source_prefix} and return a list
    # Input : source_bucket -> str
    # Output : List of str
    s3_folder_path = f"s3://{source_bucket}/{source_prefix}"

    # need dbutils
    files = dbutils.fs.ls(s3_folder_path)

    # Create an empty list
    file_names = []

    # For all files append filename to list
    for file in files:
        file_names.append(file.name)

    # Return the list
    return file_names


def extract_table_from_filename(filename: str) -> Tuple[str, str, str]:
    """
    from a filename, return the table_name (as known in the file name), the table_name (as known in the entete file), and the extraction_date
    :param filename: file name without path
    :type filename: str
    :return: table name (table_name, table_name, extraction_date)
    :return type: Tuple[str, str, str]
    """

    # Split the filename based on character "_"
    try:
        parts = filename.split("_")
    except:
        return (None, None)

    if len(parts) >= 2:
        # Prendre le deuxième mot
        second_word = parts[1]

        # Split the 2nd word based on character "-"
        try:
            subparts = second_word.split("-")
        except:
            return (None, None)

        if len(subparts) == 2:
            # Keep the 2nd word of result
            subpart1 = subparts[1]
            table_folder_name = subparts[1]
            table_name_in_header = subparts[1]
            extraction_date = parts[2]
            return (table_folder_name, table_name_in_header, extraction_date)

        elif len(subparts) > 2:
            # Keep the 2nd word of result
            subpart1 = subparts[1]
            if subpart1 == "ZBI":
                table_folder_name = subparts[1] + subparts[2]
                table_name_in_header = subparts[1] + "-" + subparts[2]
            elif subpart1 == "WB2" or subpart1 == "ZQM":
                table_folder_name = subparts[1] + subparts[2] + subparts[3]
                table_name_in_header = (
                    subparts[1] + "-" + subparts[2] + "-" + subparts[3]
                )
            else:
                table_folder_name = subparts[1]
                table_name_in_header = subparts[1]

            extraction_date = parts[2]

            return (table_folder_name, table_name_in_header, extraction_date)

    # If key don't match the expected format return (None, None)
    return (None, None, None)


def transform_key_to_v2_file_naming(filename: str) -> str:
    # Rename filename based on SAP ingestion V2 file naming rule
    #
    # Example :
    # 102607896_SAP-EQUK-F_20221121_155604_0001.dat -> 20221121_155604_SAP-EQUK-F_102607896_0001.parquet
    # 102607896_SAP-EQUK-F_20221121_155604_0001.end -> 20221121_155604_SAP-EQUK-F_102607896_0001.end

    # Split the filename based on character "_"
    try:
        parts = filename.split("_")
    except:
        return None

    if len(parts) >= 4:
        jobid = parts[0]
        table_concat_info = parts[1]
        if table_concat_info in DF_CONCAT_DICT:
            new_table_concat_info = DF_CONCAT_DICT[table_concat_info]
        else:
            logging.warning(
                f" i pattern {table_concat_info} not found in {TABLE_CONCAT_INFO_PATH}"
            )
            new_table_concat_info = table_concat_info

        filedate = parts[2]
        filetime = parts[3]
        fileend = parts[4]

        if fileend.endswith(".dat"):
            # if file ends with ".dat" then replace ".dat" by ".parquet"
            transformed_name = f"{filedate}_{filetime}_{new_table_concat_info}_{jobid}_{fileend[:-4]}.parquet"
        else:
            # else keep the original suffix
            transformed_name = (
                f"{filedate}_{filetime}_{new_table_concat_info}_{jobid}_{fileend}"
            )

        return transformed_name

    # If key don't match the expected format return None
    return None


# COMMAND ----------

# DBTITLE 1,Read entête file
# Entete file is a prerequisite for migrating files : read header aka entete file - and establish a list of known SAP tables
if file_exists_in_s3(FILE_HEADER_PATH) == True:
    DF_HEADER = spark.read.options(header="True", delimiter=";").csv(FILE_HEADER_PATH)
    KNOWN_TABLES = list(
        DF_HEADER.select("query_table").drop_duplicates().toPandas()["query_table"]
    )
    df_header_pandas = DF_HEADER.toPandas()
else:
    log.critical(f"Erreur: le fichier {FILE_HEADER_PATH} n'existe pas.")
    raise Exception()

# COMMAND ----------

# DBTITLE 1,Read table_concat_info
# TABLE_CONCAT_INFO_PATH : this file give the correspondance between old and new table naming
# It's a prerequisite
if file_exists_in_s3(TABLE_CONCAT_INFO_PATH) == True:
    # Prerequisite for migrating files : read new naming rules for tables
    DF_CONCAT = spark.read.options(header="True", delimiter=";").csv(
        TABLE_CONCAT_INFO_PATH
    )
    DF_CONCAT_DICT = {
        row["EXTRACT_NAME"]: row["EXTRACT_NAME_NEW"] for row in DF_CONCAT.collect()
    }
else:
    log.critical(f"Erreur: le fichier {TABLE_CONCAT_INFO_PATH} n'existe pas.")
    raise Exception()

# COMMAND ----------


# DBTITLE 1,Functions to transform and copy objects
def transform_and_copy_single_object(
    source_bucket: str, dest_bucket: str, prefix: str, filename: str
) -> bool:
    # for a given source bucket S3 and a given prefix, copy and transform a single object to destination bucket, object being a filename
    # input : source_bucket , type str
    # input : dest_bucket , type str
    # input : objects , type List[str]
    # output : bool
    #
    # example : source_bucket = "leap-s3-weeu1-prod" , dest_bucket = "leap-s3-raw-weeu1-dev", prefix = "sap/raw_mm",
    #      object = "5022398_SAP-EBAN-F_20230625_083645_0001.dat"
    # Rules:
    #   if file ends in ".dat" then transform and copy file with new name to destination
    #   if file ends in "_end.end" then copy file only (with new name to destination)

    skippedcount = 0
    key = prefix + filename

    source_path = f"s3://{source_bucket}/{key}"
    local_file_path = f"/tmp/{filename}.parquet"

    startTime = time.time()

    # Réaliser la transformation du fichier
    transformed_key = transform_key_to_v2_file_naming(filename)

    # Si la clé ne suit pas le format attendu, retourner une valeur par défaut
    if transformed_key == None:
        log.error(f"*** cannot transform key, file ignored : {filename} !")
        return False

    copy_source = {"Bucket": source_bucket, "Key": key}

    (
        table_folder_name,
        table_name_in_header,
        extraction_date,
    ) = extract_table_from_filename(
        filename
    )  # fonction pour extraire la table (EQUK, etc.)

    if (table_folder_name is None) or (table_name_in_header is None):
        log.error(f"*** cannot catch table name, file ignored : {filename} !")
        return False

    # destination_key = "erp/sap_latecoere_ecc6/tables/{}/active/{}".format(
    #     table_folder_name, transformed_key
    # )
    destination_key = f"{TABLE_DEST_PATTERN}" "/{}".format(
        table_folder_name, transformed_key
    )

    log.debug("===============================")
    log.debug("Processing Source Path: %s" % source_path)
    dest_path = f"s3://{dest_bucket}/{destination_key}"
    log.debug("Destination Path: %s" % dest_path)

    if file_exists_in_s3(dest_path) == False:
        # Traiter selon le type de fichier, si "*.dat" alors conversion, si "*.end" alors copie
        if filename.endswith(".dat"):
            # Catch columns for table name in DF_HEADER or raise exception
            if table_name_in_header in KNOWN_TABLES:
                # column_names_str = DF_HEADER.filter(
                #     DF_HEADER.query_table == table_name_in_header
                # ).toPandas()["fields"][0]
                filtered_header_pandas = df_header_pandas[
                    df_header_pandas["query_table"] == table_name_in_header
                ]
                column_names_str = filtered_header_pandas["fields"].iloc[0]
                column_names_str = (
                    column_names_str.lower().replace(" ", "").replace("/", "_")
                )
                column_names = column_names_str.split(",")

                mode = filtered_header_pandas["mode"].iloc[0]
                if (mode == "full") and (extraction_date < MODIFIED_AFTER):
                    log.debug(f" extraction_date : {extraction_date} !")
                    log.debug(f" i file ignored because too old : {filename} !")
                    return False
            else:
                raise Exception(
                    f"*** Table {table_name_in_header} not in entete file - cannot catch columns !"
                )

            # load dat file from S3 into dataframe
            df = load_dat_file_from_s3(source_bucket, key)

            # Add names to columns
            df = df.toDF(*column_names)

            start_time = time.time()
            # Spark style for conversion to parquet -> commented because produce a folder with many parquet files
            local_dir_path = f"/tmp/{filename}"

            # Remove local_dir_path to avoid reusing existing directory
            dbutils.fs.rm(local_dir_path, True)

            # Write parquet
            df.repartition(1).write.mode("overwrite").option(
                "compression", "gzip"
            ).parquet(local_dir_path)

            # Assume the parquet file is the only file in directory
            temporary_path = os.path.join(
                local_dir_path, dbutils.fs.ls(local_dir_path)[3][1]
            )

            log.debug(
                f"Writing of the local file took : {time.time() - start_time} seconds"
            )

            # Check the size of output file and return False if size < 1Kb
            fileattrs = dbutils.fs.ls(temporary_path)
            for attr in fileattrs:
                if attr.path == f"dbfs:{temporary_path}":
                    filesize_in_bytes = attr.size
                    filesize_in_kb = round(filesize_in_bytes / 1024, 2)
                    if filesize_in_bytes < 1024:  # 1Kb
                        log.error(
                            f"*** Error File size alert for : {filename} , ignoring this file"
                        )
                        log.error(f"*** fileattrs : {fileattrs} ")
                        dbutils.fs.rm(local_dir_path, True)
                        return False
                    break

            # Copy parquet file from {local_dir_path} to S3 destination {dest_path}
            try:
                dbutils.fs.cp(f"dbfs:{temporary_path}", dest_path)
                dbutils.fs.rm(local_dir_path, True)
                log.debug(" + Parquet file uploaded to S3: %s" % dest_path)
            except:
                log.error("*** Error copying parquet file to S3: %s" % dest_path)
                return False
        elif filename.endswith("_end.end"):
            # Copy _end.end file using transformed key
            try:
                dbutils.fs.cp(source_path, dest_path)
                log.debug("===============================")
                log.debug(" + end.end file copied to S3: %s" % dest_path)
            except:
                log.error("*** Error copying _end.end file to S3: %s" % dest_path)
                return False
        else:
            # Any other extension is ignored
            log.warning(f"*** file ignored : {filename} !")
            return False
    else:
        # Already existing is ignored
        log.debug("===============================")
        log.debug(" i Parquet file already exists in S3: %s" % dest_path)

    transformDuration = time.time() - startTime
    log.debug(f"Processing of file took : {transformDuration} seconds")

    return True


def transform_and_copy_objects(
    source_bucket: str,
    dest_bucket: str,
    prefix: str,
    objects: List[str],
    batch_size: int = BATCH_SIZE,
) -> bool:
    # for a given source bucket S3 and a given prefix, copy and transform all files corresponding to objets to destination bucket, objects being a list of filenames
    # input : source_bucket , type str
    # input : dest_bucket , type str
    # input : objects , type List[str]
    # output : bool
    #
    # example : source_bucket = "leap-s3-weeu1-prod" , dest_bucket = "leap-s3-raw-weeu1-dev", prefix = "sap/raw_mm",
    #      objects = ["5022398_SAP-EBAN-F_20230625_083645_0001.dat", "5022398_SAP-EBAN-F_20230625_083645_end.end"]
    # Rules:
    #   if file ends in ".dat" then transform and copy file with new name to destination
    #   if file ends in "_end.end" then copy file only (with new name to destination)

    startTime = time.time()

    # Verrou pour assurer la sécurité d'accès au compteur
    counter_lock = Lock()

    # Compteur pour le nombre total d'éléments traités
    total_processed_elements = 0
    total_processed_elements_previous = 0

    with ThreadPoolExecutor(max_workers=NBTHREADS) as executor:
        # Découper la liste en sous-listes de taille batch_size
        object_batches = [
            objects[i : i + batch_size] for i in range(0, len(objects), batch_size)
        ]

        # Afficher les éléments de chaque sous-liste
        for i, object_batch in enumerate(object_batches, start=1):
            log.debug(f"Batch {i}: {object_batch}")

            # Soumettre les tâches en parallèle pour chaque sous-liste
            futures = [
                executor.submit(
                    transform_and_copy_single_object,
                    source_bucket,
                    dest_bucket,
                    prefix,
                    filename,
                )
                for filename in object_batch
            ]

            # Attendre que toutes les tâches soient complétées
            for completed_future in as_completed(futures):
                try:
                    result = completed_future.result()

                    # Incrémenter le compteur
                    with counter_lock:
                        total_processed_elements += result

                except Exception as e:
                    # Gérer les exceptions
                    log.critical(
                        f"Une erreur s'est produite dans le traitement de la liste : {e}"
                    )

            if (total_processed_elements > 0) and (
                total_processed_elements != total_processed_elements_previous
            ):
                log.info("===============================")
                log.info(f" +++ {total_processed_elements} objects processed.")
                total_processed_elements_previous = total_processed_elements

    globalDuration = time.time() - startTime
    log.info(f" +++ Global duration : {globalDuration} s.")
    return True


def perform_transform_and_copy_for_table_list(
    source_bucket, dest_bucket, prefix, table_list
):
    # for a given source bucket S3 and a given prefix, list copy and transform all files corresponding to each table in table list, to destination bucket
    # how it proceed:
    #   . list files in bucket/prefix
    #   . list tables in table_list
    #   . for each file corresponding to a table in table list perform  "transform and copy" of the file
    # example : source_bucket = "leap-s3-weeu1-prod" , dest_bucket = "leap-s3-raw-weeu1-dev", prefix = "sap/raw_mm", table_list = ["EBAN", "T001W"]

    file_list = list_files_in_s3_bucket_with_prefix(source_bucket, prefix)
    log.info(f"Files for bucket s3://{source_bucket}/{prefix}")

    # Trier la liste des noms de fichiers dans l'ordre alphabétique
    file_list.sort()

    # Dictionnaire pour stocker les listes de fichiers par table
    table_files_dict = {}

    # Parcourir la liste des tables
    for table in tables_list:
        # Créer une liste vide pour stocker les fichiers correspondants à la table
        table_files = []

        # Parcourir la liste des fichiers et ajouter les fichiers correspondants à la table
        for file_name in file_list:
            if f"SAP-{table}-" in file_name:
                table_files.append(file_name)

        # Stocker la liste de fichiers correspondants à la table dans le dictionnaire
        table_files_dict[table] = table_files

    # Afficher les listes de fichiers par table
    for table, files_per_table in table_files_dict.items():
        log.info(f"Files for table {table}:")
        i = 0
        for file_name in files_per_table:
            i = i + 1
            # log.debug(f"{i} : {file_name}")
        log.info(f"{i} Files to Copy/Transform")
        result = transform_and_copy_objects(
            source_bucket, dest_bucket, prefix, files_per_table
        )
        log.info(f"table {table} -> SUCCESS: {result} \n")


def perform_transform_and_copy_all_objects_for_prefix(
    source_bucket, dest_bucket, prefix
):
    # for a given source bucket S3 and a given prefix, list copy and transform ALL files to destination bucket
    # how it proceed:
    #   . list files in bucket/prefix
    #   . for each file perform  "transform and copy" of the file
    # example : source_bucket = "leap-s3-weeu1-prod" , dest_bucket = "leap-s3-raw-weeu1-dev", prefix = "sap/raw_mm"

    file_list = list_files_in_s3_bucket_with_prefix(source_bucket, prefix)

    # Créer une liste vide pour stocker les fichiers correspondants au pattern "_SAP-"
    filtered_file_list = []
    for file_name in file_list:
        if ("_SAP-" in file_name) and (
            file_name.endswith(".dat") or file_name.endswith(".end")
        ):
            filtered_file_list.append(file_name)
    log.info(f"Files for bucket s3://{source_bucket}/{prefix}")

    # Trier la liste des noms de fichiers dans l'ordre alphabétique
    filtered_file_list.sort()

    # Parcourir la liste des fichiers et appeler la fonction
    i = len(filtered_file_list)
    log.info(f"{i} Files to Copy/Transform")
    result = transform_and_copy_objects(
        source_bucket, dest_bucket, prefix, filtered_file_list
    )
    log.info(f"SUCCESS: {result} \n")
    return result


def delete_target_files_for_table_list(dest_bucket, table_list):
    # for a given destination bucket S3, delete all files corresponding to each table in table list
    # how it proceed:
    #   . list tables in table_list
    #   . for each table in table list delete files under prefix "erp/sap_latecoere_ecc6/tables/{table_name}/active/"
    # example : dest_bucket = "leap-s3-raw-weeu1-dev", table_list = ["EBAN", "T001W"]

    # for each table
    result = True
    for table in tables_list:
        # prefix = f"erp/sap_latecoere_ecc6/tables/{table}/active/"
        prefix = f"{TABLE_DEST_PATTERN}/".format(table)
        try:
            file_list = list_files_in_s3_bucket_with_prefix(dest_bucket, prefix)
        except:
            log.error(f"Error getting files for {table} files from {dest_bucket}")
            result = False
            continue

        # for each file delete the file
        i = 0
        for file_name in file_list:
            if f"SAP-{table}-" in file_name:
                i = i + 1
                dest_path = f"s3://{dest_bucket}/{prefix}/{file_name}"
                try:
                    dbutils.fs.rm(dest_path)
                    log.info(f"{i} : {dest_path} removed")
                except:
                    log.error(f"Error removing {dest_path}")
                    result = False
                    continue

        dest_path = f"s3://{dest_bucket}/erp/sap_latecoere_ecc6/tables/{table}/"
        try:
            dbutils.fs.rm(dest_path, True)
            log.info(f"{i} : {dest_path} removed")
        except:
            log.error(f"Error removing {dest_path}")
            result = False
            continue

    return result


# COMMAND ----------

# DBTITLE 1,Main
# Main Function

if not prefix.endswith("/"):
    prefix = f"{prefix}/"

if request_type == "Delete":
    # if tables_list is not None then perform the deletion of all files for each table in tables_list in destination bucket
    if tables_list is not None:
        log.info(f"About removing {tables_list} destination files from {dest_bucket}")
        result = delete_target_files_for_table_list(dest_bucket, tables_list)
        log.info(f"result {result}")
    else:
        message = """To use the "Delete" option, you MUST provide a table list with the "Tables" parameter !
                        Example :
                        params = {
                            "ResourceProperties": {
                                "SourceBucket": "leap-s3-weeu1-prod",
                                "DestBucket": "leap-s3-raw-weeu1-dev",
                                "Prefix": "sap/raw_xx/",
                                "Tables": [
                                    "AFKO",
                                    "BKPF"
                                ]    
                            },
                            "RequestType": "Delete"
                        }
                        """
        raise Exception(message)
else:
    # if tables_list is not None then perform all files for each table in tables_list
    if tables_list is not None:
        log.info(
            f"About Migrating files from {source_bucket} for prefix {prefix} and tables in {tables_list}"
        )
        perform_transform_and_copy_for_table_list(
            source_bucket, dest_bucket, prefix, tables_list
        )
    else:
        # if objects is not None then perform all files for each object in objects
        if objects is not None:
            log.info(
                f"About Migrating files from {source_bucket} for prefix {prefix} and files in provided objects"
            )
            transform_and_copy_objects(source_bucket, dest_bucket, prefix, objects)
        else:
            # if None tables_list nor objects are provided then perform all files for bucket/prefix
            log.info(
                f"About Migrating all files from {source_bucket} for prefix {prefix}"
            )
            perform_transform_and_copy_all_objects_for_prefix(
                source_bucket, dest_bucket, prefix
            )
