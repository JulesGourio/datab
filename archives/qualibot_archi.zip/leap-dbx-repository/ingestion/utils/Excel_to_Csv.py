# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Excel to Csv converter
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to convert all Excel files to Csv in a given path
# MAGIC For each file and each sheet create a dedicated Csv
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC ## This Notebook has been validated on a shared Cluster, job cluster and serverless cluster
# MAGIC
# MAGIC **Storage modes** (controlled by the `storage_type` widget):
# MAGIC - **s3** — reads from S3, stages via a temp UC Volume, writes CSV back to S3
# MAGIC - **volumes** — reads and writes directly from/to Databricks Volumes (no staging needed)
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Database table ingestion 
# MAGIC - Manual files ingestion
# MAGIC
# MAGIC **Sample Input File (S3 mode)**
# MAGIC - s3://leap-s3-raw-weeu1-{reference_read_env}/manual/leapdepot/UCXXX/YYYYMMDD_HHmmSS_*.xlsx
# MAGIC
# MAGIC **Sample Input File (Volumes mode)**
# MAGIC - /Volumes/{reference_read_env}_landingzone/leapdepot/UCXXX/YYYYMMDD_HHmmSS_*.xlsx
# MAGIC
# MAGIC **Sample Output File (S3 mode)**
# MAGIC - s3://leap-s3-raw-weeu1-{pipeline_write_env}/manual/leapdepot/UCXXX/YYYYMMDD_HHmmSS_*_{sheet_name}.csv
# MAGIC
# MAGIC **Sample Output File (Volumes mode)**
# MAGIC - /Volumes/{pipeline_write_env}_landingzone/leapdepot/UCXXX/csv/YYYYMMDD_HHmmSS_*_{sheet_name}.csv

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Restore bundle root in sys.path after Python restart
import sys
_nb_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
_bundle_root = "/Workspace" + "/".join(_nb_path.split("/")[:-3])
if _bundle_root not in sys.path:
    sys.path.insert(0, _bundle_root)

# COMMAND ----------

from pyspark.sql import SparkSession
import pandas as pd
from pathlib import Path
import re
import logging
from datetime import datetime

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("log_level", "info")
LOG_LEVEL = dbutils.widgets.get("log_level")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Set source, outuput and archive paths storage type
dbutils.widgets.dropdown("storage_type", "s3", ["s3", "volumes"])
STORAGE_TYPE = dbutils.widgets.get("storage_type")  # s3 by default

dbutils.widgets.text(
    "s3_source_path", "s3://leap-s3-raw-weeu1-dev/manual/leapdepot/UCXX/"
)
S3_SOURCE_PATH = dbutils.widgets.get("s3_source_path")

dbutils.widgets.text(
    "s3_output_path", "s3://leap-s3-raw-weeu1-dev/manual/leapdepot/UCXX/csv/"
)
S3_OUTPUT_PATH = dbutils.widgets.get("s3_output_path")

dbutils.widgets.text(
    "s3_archive_path", "s3://leap-s3-raw-weeu1-dev/archive/manual/leapdepot/UCXX/"
)
S3_ARCHIVE_PATH = dbutils.widgets.get("s3_archive_path")

dbutils.widgets.dropdown("clean_headers", "false", ["true", "false"])
CLEAN_HEADERS = dbutils.widgets.get("clean_headers") == "true"

dbutils.widgets.text("row_start", "1")
ROW_START = int(dbutils.widgets.get("row_start"))

# How to use SKIP_SHEETS: Provide a comma-separated list of sheet names
# or regex patterns to skip
dbutils.widgets.text("skip_sheets", "") # no pattern by default
SKIP_SHEETS = [
    p.strip() for p in dbutils.widgets.get("skip_sheets").split(",") if p.strip()
]

# This option is to add a timestamp to the csv file name
dbutils.widgets.dropdown("add_timestamp_to_csv_name", "false", ["true", "false"]) # false by default
ADD_TIMESTAMP_TO_CSV_NAME = dbutils.widgets.get("add_timestamp_to_csv_name") == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### LOG LEVEL
# MAGIC
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue=LOG_LEVEL,
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files 

# COMMAND ----------

log.info(f"S3_SOURCE_PATH is:  {S3_SOURCE_PATH}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Create output folder if not exists

# COMMAND ----------

log.info(f"S3_OUTPUT_PATH is:  {S3_OUTPUT_PATH}")
dbutils.fs.mkdirs(S3_OUTPUT_PATH)

# COMMAND ----------

log.info(f"S3_ARCHIVE_PATH is:  {S3_ARCHIVE_PATH}")
dbutils.fs.mkdirs(S3_ARCHIVE_PATH)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# DBTITLE 1,Cell 26
# MAGIC %md
# MAGIC    
# MAGIC    
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation
# MAGIC
# MAGIC ### `clean_headers(df)`
# MAGIC
# MAGIC Sanitizes and deduplicates DataFrame column headers before CSV export:
# MAGIC - Replaces spaces, periods, and slashes with underscores
# MAGIC - Removes control characters
# MAGIC - Keeps only alphanumeric characters and underscores
# MAGIC - Collapses consecutive underscores
# MAGIC - Deduplicates repeated column names by appending `_1`, `_2`, etc.
# MAGIC - Drops columns with empty or `Unnamed` headers
# MAGIC
# MAGIC Controlled by the **`clean_headers`** widget (`true` / `false`).

# COMMAND ----------

def clean_headers(df):
    """Sanitize, deduplicate, and drop empty/unnamed column headers."""

    def _sanitize(col_name):
        name = str(col_name).strip()
        name = re.sub(r'[\s./]+', '_', name)          # spaces, periods, slashes -> _
        name = re.sub(r'[\x00-\x1f\x7f]', '', name)  # remove control characters
        name = re.sub(r'[^A-Za-z0-9_]', '_', name)    # any remaining invalid char -> _
        name = re.sub(r'_+', '_', name)                # collapse multiple underscores
        return name.strip('_')

    original_columns = list(df.columns)
    sanitized = [_sanitize(c) for c in df.columns]

    # Deduplicate: append _1, _2, ... to repeated sanitized names
    seen = {}
    deduped = []
    for name in sanitized:
        if name not in seen:
            seen[name] = 0
            deduped.append(name)
        else:
            seen[name] += 1
            deduped.append(f"{name}_{seen[name]}")
    df.columns = deduped

    renamed = [(orig, new) for orig, new in zip(original_columns, df.columns) if str(orig) != new]
    if renamed:
        log.info(f"Sanitized {len(renamed)} column name(s):")
        for orig, new in renamed:
            log.info(f"  '{orig}' -> '{new}'")
    else:
        log.info("All column names are already compliant.")

    # Drop columns with empty or unnamed headers
    df = df.loc[:, ~df.columns.astype(str).str.match(r'^Unnamed:|^$')]
    df = df.loc[:, df.columns.astype(str).str.strip() != '']

    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Read Excel Files

# COMMAND ----------

try:
    files = dbutils.fs.ls(S3_SOURCE_PATH)
    if len(files) == 0:
        dbutils.jobs.taskValues.set("compute_dlt", False)
        dbutils.notebook.exit(f"No files in {S3_SOURCE_PATH}")

    excel_files = [
        f.path
        for f in files
        if f.path.endswith(".xlsx")
        or f.path.endswith(".xls")
        or f.path.endswith(".xlsm")
    ]
except Exception as e:
    dbutils.jobs.taskValues.set("compute_dlt", False)
    dbutils.notebook.exit(f"Exception reading read path : {S3_SOURCE_PATH} \n{e}")

if len(excel_files) == 0:
  dbutils.jobs.taskValues.set("compute_dlt", False)
  dbutils.notebook.exit(f"No Excel files in {S3_SOURCE_PATH}")

log.info(f"{len(excel_files)} fichiers Excel trouvés.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Temp directory in a Volume (S3 mode only)
# MAGIC
# MAGIC When reading from S3, pandas cannot access S3 paths directly.  
# MAGIC A temporary Unity Catalog Volume is used as staging for the Excel → CSV conversion.  
# MAGIC In **volumes** mode this section is skipped (pandas reads directly from `/Volumes/...`).

# COMMAND ----------

if STORAGE_TYPE == "s3":
    spark.sql(f"create schema if not exists {PIPELINE_WRITE_ENV}_landingzone.leapdepot")
    spark.sql(f"create volume if not exists {PIPELINE_WRITE_ENV}_landingzone.leapdepot.excel_files")
    unity_catalog_volume = f"/Volumes/{PIPELINE_WRITE_ENV}_landingzone/leapdepot/excel_files/"

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations and output
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - convert Excel to Csv
# MAGIC

# COMMAND ----------

for file_path in excel_files:
    file_name = Path(file_path).name
    log.info(f"\nProcessing: {file_path}")

    if STORAGE_TYPE == "s3":
        # S3 mode: stage Excel file to temp volume for pandas access
        local_excel_path = f"{unity_catalog_volume}/{file_name}"
        dbutils.fs.cp(file_path, local_excel_path)
        # dbutils.fs.ls(f"dbfs:{local_excel_path}")
        excel_read_path = local_excel_path
    else:
        # Volumes mode: pandas can read directly from /Volumes/ path
        excel_read_path = file_path.replace("dbfs:", "")

    xls = pd.ExcelFile(excel_read_path)

    for sheet_name in xls.sheet_names:
        # Skip sheets matching any regex pattern in SKIP_SHEETS
        if SKIP_SHEETS and any(
            re.search(pattern, sheet_name, flags=re.IGNORECASE)
            for pattern in SKIP_SHEETS
        ):
            log.info(f"Skipping sheet: '{sheet_name}' (matched skip_sheets pattern)")
            continue

        clean_sheet_name = re.sub(r"\s+", "_", sheet_name.strip())
        log.info(f"Converting sheet: {sheet_name} -> {clean_sheet_name}")

        # Load Excel sheet with Pandas (header on the ROW_START row)
        # Fall back to row 1 if the sheet has fewer rows than ROW_START
        try:
            df = pd.read_excel(xls, sheet_name=sheet_name, header=ROW_START - 1)
            log.info(f"Reading from Excel row {ROW_START} as header")
        except ValueError:
            df = pd.read_excel(xls, sheet_name=sheet_name, header=0)
            log.info(
                f"Sheet '{sheet_name}' has fewer rows than row_start={ROW_START}, "
                "falling back to row 1"
            )

        # Optionally sanitize and clean column headers
        if CLEAN_HEADERS:
            df = clean_headers(df)

        # Define output CSV file name
        csv_file_name = f"{Path(file_name).stem}_{clean_sheet_name}.csv"

        # Add timestamp to name if requested
        if ADD_TIMESTAMP_TO_CSV_NAME:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            csv_file_name = f"{timestamp}_{csv_file_name}"

        print("\nDone.")

        if STORAGE_TYPE == "s3":
            # S3 mode: write CSV to temp volume, then move to S3
            local_csv_path = f"{unity_catalog_volume}/{csv_file_name}"
            df.to_csv(local_csv_path, index=False)
            s3_csv_path = f"{S3_OUTPUT_PATH}{csv_file_name}"
            dbutils.fs.mv(local_csv_path, s3_csv_path)
            log.info(f"CSV file saved: {s3_csv_path}")
        else:
            # Volumes mode: write CSV directly to output path
            output_csv_path = f"{S3_OUTPUT_PATH}{csv_file_name}"
            df.to_csv(output_csv_path, index=False)
            log.info(f"CSV file saved: {output_csv_path}")

    # Clean staged Excel file (S3 mode only)
    if STORAGE_TYPE == "s3":
        dbutils.fs.rm(local_excel_path)

    # Set job task
    dbutils.jobs.taskValues.set("compute_dlt", True)

# COMMAND ----------

# MAGIC %md
# MAGIC # Archiving

# COMMAND ----------

for file_path in excel_files:
    file_name = Path(file_path).name
    if STORAGE_TYPE != "s3":
        file_path = file_path.replace("dbfs:", "")
    # Archive Excel file
    archive_path = f"{S3_ARCHIVE_PATH}{file_name}"
    dbutils.fs.mv(file_path, archive_path)

    log.info(f"Archived {file_name} to: {archive_path}")
