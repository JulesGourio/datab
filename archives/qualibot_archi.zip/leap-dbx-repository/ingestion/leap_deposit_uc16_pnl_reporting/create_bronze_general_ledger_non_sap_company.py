# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Ingestion - P&L Budget
# MAGIC The aim of this notebook is to do the ingestion of the IS budget by CSV files that have been put in S3 by Talend from a shared deposit folder.
# MAGIC The business controllers put a csv file per branch and year in the given deposit folder, following a template pre-defined. In this ingestion script, some quality checks are done in order to avoid/prevent wrong data in the bronze table. As soon the file is ingested, it moves to a folder "Archive" in S3.
# MAGIC
# MAGIC **Inputs:** Files in s3://leap-s3-raw-weeu1-{env}/manual/leapdepot/UC16_PNL_REPORTING/ACTUAL/{file_name}
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - {PIPELINE_WRITE_ENV}_bronze.leap_depot_uc16_pnl_reporting.general_ledger_non_sap
# MAGIC
# MAGIC **Used by:**
# MAGIC
# MAGIC create_silver_general_ledger_non_sap
# MAGIC
# MAGIC **Triggered by:**
# MAGIC
# MAGIC File arrival in s3://leap-s3-raw-weeu1-{env}/manual/leapdepot/UC16_PNL_REPORTING/ACTUAL/

# COMMAND ----------

# MAGIC %md
# MAGIC # Import

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import libraries

# COMMAND ----------

import os
import great_expectations as gx

from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f
from pyspark.sql import DataFrame

from leap_utils.config import spark
from leap_utils.common.validation import gx_validation
from leap_utils.data_asset.table_utils import save_table

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widget

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("re_init_stack", "False")
RE_INIT_STACK = dbutils.widgets.get("re_init_stack").lower() == "true"

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

Fiscal_Year = "Fiscal_Year"
Company_Code = "Company_Code"
Site = "Site"
Profit_Center = "Profit_Center"
Account_number = "Account_number"
Trading_partner = "Company_ID_of_trading_partner"
Currency = "Currency"
Jan = "Jan"
Feb = "Feb"
Mar = "Mar"
Apr = "Apr"
May = "May"
Jun = "Jun"
Jul = "Jul"
Aug = "Aug"
Sept = "Sept"
Oct = "Oct"
Nov = "Nov"
Dec = "Dec"
TOTAL = "TOTAL"

# COMMAND ----------

l_columns_reference = [
    Fiscal_Year,
    Company_Code,
    Site,
    Profit_Center,
    Account_number,
    Trading_partner,
    Currency,
    Jan,
    Feb,
    Mar,
    Apr,
    May,
    Jun,
    Jul,
    Aug,
    Sept,
    Oct,
    Nov,
    Dec,
    TOTAL,
]

l_columns_not_null = [Fiscal_Year, Company_Code, Profit_Center, Account_number]
l_accepted_cny_code = [
    "LSP1",
    "LBE1",
    "LMXC",
    "LCA1",
    "LCA2",
    "LCA3",
    "LUK1",
    "LUS1",
    "LUS2",
]
l_columns_unique = [Fiscal_Year, Company_Code]

stack_ids = [Company_Code, Fiscal_Year]

input_file_path_base = f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC16_PNL_REPORTING/ACTUAL"

dest_table = (
    f"{PIPELINE_WRITE_ENV}_bronze.leap_depot_uc16_pnl_reporting.general_ledger_non_sap"
)

CONFIG = {
    "folder_path": input_file_path_base,
    "dest_table": dest_table,
    "quality_checks": {
        "expected_columns": l_columns_reference,
        "columns_not_null": l_columns_not_null,
        "expected_cny_value": l_accepted_cny_code,
        "unique_column": l_columns_unique,
    },
    "removed_columns_space": True,
    "stack_ids": stack_ids,
}

# COMMAND ----------

# MAGIC %md
# MAGIC # Specific Code for ingestion P&L Budget
# MAGIC
# MAGIC Implemente specific logic for this specific ingestion

# COMMAND ----------


def replace_values_space(df, col_name: str):
    """
    Replace spaces with underscores in the values of the column in the DataFrame.

    :param df: the input DataFrame
    :type df: pyspark.sql.DataFrame
    :param df: name of the column
    :type df: str
    :return: DataFrame with column values replaced
    :rtype: pyspark.sql.DataFrame
    """
    return df.withColumn(col_name, f.regexp_replace(f.trim(f.col(col_name)), " ", "_"))


def remove_extension(file_name: str) -> str:
    """
    Remove file extension from a given file name.

    :param file_name: the file name
    :type file_name: str
    :return: the file name without extension
    :rtype: str
    """
    return os.path.splitext(file_name)[0]


def check_filename_format(filename):
    """
    Check if the given filename matches the format "PNL_budget_{string}_{date}.csv".

    :param filename: filename to check.
    :type file_name: str
    :return: True if file name matches the format
    :rtype: bool
    """
    if filename.endswith(".csv"):
        return True
    else:
        return False


def delete_null_rows(df: DataFrame):
    """
    Delete rows that are null in all columns of the DataFrame.

    :param df: the input DataFrame
    :type df: pyspark.sql.DataFrame
    :param df: name of the column
    :type df: str
    :return: DataFrame without rows with all null values
    :rtype: pyspark.sql.DataFrame
    """
    df_filtered = df.na.drop(how="all")
    return df_filtered


def fill_currency_by_eur(df: DataFrame, col_name: str):
    """
    Replace empty rows of the column Currency by EUR

    :param df: the input DataFrame
    :type df: pyspark.sql.DataFrame
    :param col_name: name of the column
    :type col_name: str
    :return: DataFrame with null currency rows filled by EUR
    :rtype: pyspark.sql.DataFrame
    """
    df_filled = df.withColumn(
        col_name,
        f.when(f.col(col_name).isNull(), f.lit("EUR")).otherwise(f.col(col_name)),
    )
    return df_filled


# COMMAND ----------

# MAGIC %md
# MAGIC # Generic code for ingestion

# COMMAND ----------

# MAGIC %md
# MAGIC ## Utils function

# COMMAND ----------

from leap_utils.data_asset.table_utils import (
    remove_start_and_end_spaces_from_column_names,
    _cleanup_column_name,
)

# COMMAND ----------


def remove_column_space_dataframe(df: DataFrame):
    """
    Clean column names using _cleanup_column_name function.

    :param df: the DataFrame
    :return: DataFrame with column names without spaces
    """
    cleaned_columns = [_cleanup_column_name(col) for col in df.columns]
    return df.select(
        [
            f.col(col).alias(cleaned_col)
            for col, cleaned_col in zip(df.columns, cleaned_columns)
        ]
    )


def archive_file(folder_path: str, file_name: str) -> None:
    """
    Move a file to the 'archive' folder within the same directory.

    :param folder_path: the path of the folder containing the file
    :type folder_path: str
    :param file_name: the name of the file to be archived
    :type file_name: str
    """
    parts = folder_path.split("/")
    parts.insert(3, "archive")
    new_path = "/".join(parts)
    dbutils.fs.mv(f"{folder_path}/{file_name}", f"{new_path}/{file_name}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks

# COMMAND ----------


def quality_checks_on_input_file(df, config: dict[str, any]):
    """
    Perform quality checks on the input DataFrame using Great Expectations.

    :param df: the input DataFrame
    :type df: pyspark.sql.DataFrame
    :param config: configuration dictionary containing quality check parameters
    :type config: dict[str, any]
    """
    # Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
    red_quality_check_results = []

    df_gx = gx.dataset.SparkDFDataset(df, persist=False)
    for quality_check_name, quality_check_parameter in config["quality_checks"].items():
        if quality_check_name == "expected_columns":
            print("Checking the expected columns : " + str(quality_check_parameter))
            red_quality_check_results = []
            for column_ref in quality_check_parameter:
                red_quality_check_results.append(
                    df_gx.expect_column_to_exist(column=column_ref)
                )
            gx_validation.validate_and_log_gx_results(
                quality_check_results=red_quality_check_results,
                validation_level="RED",
                info_message="There's no missing colums ",
                error_message="At least one red quality checks is KO, the job has stopped, check corresponding results",
                pipeline_write_env=PIPELINE_WRITE_ENV,
                table_name="general_ledger_non_sap_bronze",
                log_to_event_table=True,
                log_successes=True,
            )

        if quality_check_name == "columns_not_null":
            print("Checking the not null columns : " + str(quality_check_parameter))
            red_quality_check_results = []
            for column_not_null in quality_check_parameter:
                red_quality_check_results.append(
                    df_gx.expect_column_values_to_not_be_null(column=column_not_null)
                )
            gx_validation.validate_and_log_gx_results(
                quality_check_results=red_quality_check_results,
                validation_level="RED",
                info_message="There's no null colums ",
                error_message="At least one red quality checks is KO, the job has stopped, check corresponding results",
                pipeline_write_env=PIPELINE_WRITE_ENV,
                table_name="general_ledger_non_sap_bronze",
                log_to_event_table=True,
                log_successes=True,
            )

        if quality_check_name == "expected_cny_value":
            print("Checking the cny values : " + str(quality_check_parameter))
            red_quality_check_results = []
            red_quality_check_results.append(
                df_gx.expect_column_values_to_be_in_set(
                    Company_Code, l_accepted_cny_code
                )
            )
            gx_validation.validate_and_log_gx_results(
                quality_check_results=red_quality_check_results,
                validation_level="AMBER",
                info_message="There's no incorrect values ",
                error_message="At least one red quality checks is KO, the job has stopped, check corresponding results",
                pipeline_write_env=PIPELINE_WRITE_ENV,
                table_name="general_ledger_non_sap_bronze",
                log_to_event_table=True,
                log_successes=True,
            )

        if quality_check_name == "unique_column":
            print("Checking unique values : " + str(quality_check_parameter))
            red_quality_check_results = []
            for column_unique in quality_check_parameter:
                red_quality_check_results.append(
                    df_gx.expect_column_unique_value_count_to_be_between(
                        column_unique, 1, 1
                    )
                )
            gx_validation.validate_and_log_gx_results(
                quality_check_results=red_quality_check_results,
                validation_level="RED",
                info_message="There's no duplicate values ",
                error_message="At least one red quality checks is KO, the job has stopped, check corresponding results",
                pipeline_write_env=PIPELINE_WRITE_ENV,
                table_name="general_ledger_non_sap_bronze",
                log_to_event_table=True,
                log_successes=True,
            )


# COMMAND ----------

# MAGIC %md
# MAGIC # Execute Ingestion

# COMMAND ----------

# MAGIC %md
# MAGIC ## Retrieve budget files in s3 bucket

# COMMAND ----------

file_list = dbutils.fs.ls(input_file_path_base)
if not file_list:
    dbutils.notebook.exit("No files found in the input directory.")

# COMMAND ----------

df_s3_files = spark.createDataFrame(file_list)
csv_name_list = [
    row.name
    for row in df_s3_files.select("name")
    .filter(f.col("name").endswith("csv"))
    .collect()
]
if not csv_name_list:
    dbutils.notebook.exit("No CSV files found in the input directory.")

# COMMAND ----------

csv_path_list = []
for name in csv_name_list:
    if not check_filename_format(filename=name):
        dbutils.jobs.taskValues.set("compute_next_task", False)
        raise Exception(f"file name not in right format: {name}")
        dbutils.notebook.exit(f"file name not in right format: {name}")
    else:
        file_name = name
        input_complete_file_path = (
            df_s3_files.filter(f.col("name") == name).select("path").collect()[0][0]
        )
        csv_path_list.append(input_complete_file_path)

print("List of files to process :\n" + "\n".join(csv_path_list))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Main

# COMMAND ----------

# MAGIC %md
# MAGIC ### Read and Process each individual file

# COMMAND ----------

validated_list = []

for file_path in csv_path_list:
    file_name = file_path.split("/")[-1]
    print(f"--\nProcessing file: {file_name} \n")

    df = spark.read.options(header="True", delimiter=";").csv(file_path)

    df = delete_null_rows(df=df)
    df = remove_start_and_end_spaces_from_column_names(df=df)
    df = fill_currency_by_eur(df, "Currency")

    if "removed_columns_space" in CONFIG.keys():
        if CONFIG["removed_columns_space"]:
            df = remove_column_space_dataframe(df=df)

    if "quality_checks" in CONFIG.keys():
        quality_checks_on_input_file(df, config=CONFIG)

    # Add a column with the file name - contains the Talend extraction timestamps
    df_with_file_name = df.withColumn(
        "File_name", f.lit(remove_extension(file_name=file_name))
    )

    validated_list.append(df_with_file_name)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Union All Files

# COMMAND ----------

if validated_list:
    df_all_files = validated_list[0]
    for df in validated_list[1:]:
        df_all_files = df_all_files.unionByName(df)

    df_with_file_name_with_id = df_all_files.withColumn(
        "ID", f.concat_ws("_", *CONFIG["stack_ids"])
    )

    dbutils.jobs.taskValues.set("compute_next_task", True)
else:
    dbutils.notebook.exit("No valid files to process.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save table

# COMMAND ----------

split_dest_table = dest_table.lower().split(".")
catalog = split_dest_table[0]
domain = split_dest_table[1]
table = split_dest_table[2]
CreateSchemaIfNotExists = True

print(f"Saving to {catalog}.{domain}.{table}")

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_with_file_name_with_id,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Archive files in S3
# MAGIC When the file is ingested, the csv in S3 goes to a folver "Archive". Therefore, only new files are ingested, and we keep in S3 a copy of the file upload by the business.

# COMMAND ----------

for file_path in csv_path_list:
    file_name = file_path.split("/")[-1]
    print(f"Archiving file: {file_name}")
    archive_file(folder_path=input_file_path_base, file_name=file_name)
