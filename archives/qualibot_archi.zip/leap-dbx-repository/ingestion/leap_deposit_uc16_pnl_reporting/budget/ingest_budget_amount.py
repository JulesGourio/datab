# Databricks notebook source
# MAGIC %md
# MAGIC # Budget amount ingestion
# MAGIC Ingestion of budget amount files, for the budget per site/division project.
# MAGIC There is one budget file per fiscal year, per scope (AS, IS, SPS, etc) and
# MAGIC per budget version/reforecast number.

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

import warnings

warnings.simplefilter(action="ignore", category=FutureWarning)

# COMMAND ----------

import datetime

import pyspark.pandas as ps
from databricks.sdk.runtime import dbutils
from great_expectations.dataset import SparkDFDataset
from pyspark.sql import functions as f
from pyspark.sql.utils import AnalysisException

from leap_utils.common import logger
from leap_utils.common.validation import gx_validation
from leap_utils.config import spark
from leap_utils.data_asset import table_utils
from leap_utils.ingestion import ingestion_utils

# COMMAND ----------

# MAGIC %md
# MAGIC # Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("force_data_asset_computation", "false")
FORCE_DATA_ASSET_COMPUTATION = (
    dbutils.widgets.get("force_data_asset_computation").lower() == "true"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Setup logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "Budget amount ingestion"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC Fix root logger

# COMMAND ----------

import logging

logging.getLogger().handlers.clear()

# COMMAND ----------

# MAGIC %md
# MAGIC # Constants

# COMMAND ----------

INGESTION_S3_BUCKET = f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/"

BUDGET_AMOUNT_S3_FOLDER_PATH = "manual/leapdepot/UC16_PNL_REPORTING/BUDGET/AMOUNT/"

BUDGET_AMOUNT_S3_BUCKET_PATH = f"{INGESTION_S3_BUCKET}/{BUDGET_AMOUNT_S3_FOLDER_PATH}"

BUDGET_AMOUNT_S3_BUCKET_ARCHIVE_PATH = (
    f"{INGESTION_S3_BUCKET}/archive/{BUDGET_AMOUNT_S3_FOLDER_PATH}"
)

FILENAME_WITH_TIMESTAMP_REGEX = r"^(\d{8}\_\d{6})\_(?:budget\_v(\d{1})|reforecast\_(\d)\_(\d))\_([a-zA-Z0-9]+)\_(amount)(\_.*)?\.xlsx$"

BUDGET_AMOUNT_SCHEMA = {
    "company_code": "string",
    "trading_partner_id": "string",
    "account_number": "string",
    "profit_center": "string",
    "material_number": "string",
    "plant_assembly": "string",
    "plant_production_purchase": "string",
    "cost_center": "string",
    "WBS_code": "string",
    "currency_key": "string",
    "fiscal_year": "int",
    "amount_01": "double",
    "amount_02": "double",
    "amount_03": "double",
    "amount_04": "double",
    "amount_05": "double",
    "amount_06": "double",
    "amount_07": "double",
    "amount_08": "double",
    "amount_09": "double",
    "amount_10": "double",
    "amount_11": "double",
    "amount_12": "double",
}

BUDGET_SCOPE_VALID_VALUES = [
    "AS",
    "IS",
    "SPS",
    "LAC1",
    "LAC2",
    "HQ",
]

# COMMAND ----------

# MAGIC %md
# MAGIC # Read budget amount excel files in LEAP depot S3 bucket

# COMMAND ----------

# MAGIC %md
# MAGIC ## Find files to ingest

# COMMAND ----------

df_file_list = ingestion_utils.create_dbutils_ls_dataframe(BUDGET_AMOUNT_S3_BUCKET_PATH)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_file_list.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Keep only file names that matches leap depot timestamps and excel files

# COMMAND ----------

df_files_with_valid_filename = df_file_list.where(
    f.regexp_like(f.col("name"), f.lit(FILENAME_WITH_TIMESTAMP_REGEX))
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_files_with_valid_filename.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Make sure budget scope are correct

# COMMAND ----------

df_files_with_budget_scope = df_files_with_valid_filename.withColumns(
    {
        "extracted_scope": f.regexp_extract(
            f.col("name"), pattern=FILENAME_WITH_TIMESTAMP_REGEX, idx=5
        ),
        "is_scope_valid": f.col("extracted_scope").isin(
            *[f.lit(val) for val in BUDGET_SCOPE_VALID_VALUES]
        ),
    }
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_files_with_budget_scope.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Red quality check if some files have the wrong scope

# COMMAND ----------

gx_files_with_scope = SparkDFDataset(df_files_with_budget_scope, persist=False)

files_scope_validation = [
    gx_files_with_scope.expect_column_values_to_be_in_set(
        column="is_scope_valid", value_set=[True]
    )
]

# COMMAND ----------

gx_validation.validate_and_log_gx_results(
    quality_check_results=files_scope_validation,
    validation_level="RED",
    info_message="All budget files have valid budget scope values.",
    error_message="Some budget files do not have valid budget scope values.",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="P_L_budget_bronze",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stop ingestion if there is no files to ingest

# COMMAND ----------

df_files_to_ingest = df_files_with_budget_scope

files_to_ingest = df_files_to_ingest.count() > 0

compute_data_asset = files_to_ingest | FORCE_DATA_ASSET_COMPUTATION

dbutils.jobs.taskValues.set("compute_data_asset", compute_data_asset)

if not files_to_ingest:
    dbutils.notebook.exit("No files to ingest")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ingest all files with pandas on spark

# COMMAND ----------

df_budget_amount_ingested_files = spark.createDataFrame(
    data=[],
    schema=(
        "_meta_filepath string, "
        "_meta_filename string, "
        "_meta_modification_timestamp timestamp, "
        "_meta_ingestion_timestamp timestamp, "
        "_meta_leapdepot_timestamp timestamp"
    ),
)

ingestion_timestamp = datetime.datetime.now(tz=datetime.timezone.utc)

for file in df_files_to_ingest.collect():
    log.info("Reading file %s at: %s", file.name, file.path)

    # noinspection PyTypeChecker
    df_budget_amount = (
        ps.read_excel(
            f"{BUDGET_AMOUNT_S3_BUCKET_PATH}/{file.name}",
            sheet_name=0,
            header=0,
            usecols=BUDGET_AMOUNT_SCHEMA.keys(),
            dtype=BUDGET_AMOUNT_SCHEMA,
        )
        .to_spark()
        .alias("df_budget_amount_raw")
    )

    metadata_columns = {
        "_meta_filepath": f.lit(file.path),
        "_meta_filename": f.lit(file.name),
        "_meta_modification_timestamp": f.to_utc_timestamp(
            f.lit(file.modification_timestamp), "UTC"
        ),
        "_meta_ingestion_timestamp": f.to_utc_timestamp(
            f.lit(ingestion_timestamp), "UTC"
        ),
        "_meta_leapdepot_timestamp": f.to_utc_timestamp(
            f.to_timestamp_ntz(
                f.regexp_extract(
                    f.col("_meta_filename"),
                    pattern=FILENAME_WITH_TIMESTAMP_REGEX,
                    idx=1,
                ),
                f.lit("yyyyMMdd_HHmmss"),
            ),
            "Europe/Paris",
        ),
    }

    df_budget_amount = df_budget_amount.withColumns(metadata_columns)

    df_budget_amount = df_budget_amount.select(
        *metadata_columns.keys(), "df_budget_amount_raw.*"
    )

    df_budget_amount_ingested_files = df_budget_amount_ingested_files.unionByName(
        df_budget_amount, allowMissingColumns=True
    )

    log.info("Finished reading file %s\n", file.name)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_amount_ingested_files.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Pre-stack ingestion checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check that all files have only one year of data

# COMMAND ----------

df_ingested_fiscal_year_check = (
    df_budget_amount_ingested_files.groupBy("_meta_filename", "fiscal_year")
    .count()
    .groupBy("_meta_filename")
    .agg(
        f.sum(f.col("count")).alias("count"),
        f.count(f.lit(1)).alias("number_of_fiscal_year_in_file"),
        f.collect_set(f.col("fiscal_year")).alias("fiscal_year_list"),
    )
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_ingested_fiscal_year_check.display()

# COMMAND ----------

df_ingested_files_with_multiple_fiscal_year = df_ingested_fiscal_year_check.where(
    f.col("number_of_fiscal_year_in_file") != f.lit(1)
)

bad_files = list(
    df_ingested_files_with_multiple_fiscal_year.select("_meta_filename").toPandas()[
        "_meta_filename"
    ]
)

# COMMAND ----------

if df_ingested_files_with_multiple_fiscal_year.count() > 0:
    log.critical("Budget files with multiple fiscal year are:\n%s", bad_files)

    if log.level <= logger.LOGGER_MAPPING["critical"]:
        df_ingested_files_with_multiple_fiscal_year.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Red quality check if some files have more than one year of data

# COMMAND ----------

gx_ingested_fiscal_year_check = SparkDFDataset(
    df_ingested_fiscal_year_check, persist=False
)

fiscal_year_validation = [
    gx_ingested_fiscal_year_check.expect_column_values_to_be_between(
        column="number_of_fiscal_year_in_file", min_value=1, max_value=1
    )
]

# COMMAND ----------

gx_validation.validate_and_log_gx_results(
    quality_check_results=fiscal_year_validation,
    validation_level="RED",
    info_message="All budget files have a single fiscal year per file.",
    error_message="Some budget files have more than one fiscal year per file.",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="P_L_budget_bronze",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Add or replace ingested files in a stack table

# COMMAND ----------

try:
    df_budget_amount_old_stack = spark.read.table(
        f"{PIPELINE_READ_ENV}_bronze"
        f".leap_depot_uc16_pnl_reporting"
        f".budget_amount_stack"
    )
    df_budget_amount_old_stack.limit(1).collect()

except AnalysisException as e:
    if e.getErrorClass() == "TABLE_OR_VIEW_NOT_FOUND":
        df_budget_amount_old_stack = spark.createDataFrame(
            data=[], schema=df_budget_amount_ingested_files.schema
        )
    else:
        raise AssertionError(
            # TODO change
            "Something went wrong when trying to read "
            "the budget amount stack table."
        ) from e

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_amount_old_stack.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Remove already ingested files in old stack

# COMMAND ----------

df_ingested_filenames = df_budget_amount_ingested_files.select(
    "_meta_filename"
).distinct()

ingested_filenames = list(df_ingested_filenames.toPandas()["_meta_filename"])

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_ingested_filenames.display()

# COMMAND ----------

df_budget_amount_stack_filtered = df_budget_amount_old_stack.where(
    ~f.col("_meta_filename").isin(*[f.lit(val) for val in ingested_filenames])
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_amount_stack_filtered.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Append new ingested files to stack

# COMMAND ----------

df_budget_amount_new_stack = df_budget_amount_stack_filtered.unionByName(
    df_budget_amount_ingested_files, allowMissingColumns=True
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_amount_new_stack.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Save new stack

# COMMAND ----------

table_utils.save_table(
    f"{PIPELINE_WRITE_ENV}_bronze"
    f".leap_depot_uc16_pnl_reporting"
    f".budget_amount_stack",
    df_budget_amount_new_stack,
    mode="overwrite",
    overwrite_schema=False,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Archive ingested files in the archive folder

# COMMAND ----------

for filename in ingested_filenames:
    dbutils.fs.mv(
        f"{BUDGET_AMOUNT_S3_BUCKET_PATH}/{filename}",
        f"{BUDGET_AMOUNT_S3_BUCKET_ARCHIVE_PATH}/{filename}",
    )
