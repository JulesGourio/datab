# Databricks notebook source
# MAGIC %md
# MAGIC # SAP FC consolidation ingestion
# MAGIC
# MAGIC All statutory financial reports are made through consolidation data from
# MAGIC ViaReport.
# MAGIC As we are not connected yet to ViaReport, the aim of this notebook is to ingest
# MAGIC the data through an extract put in the shared folder leap_depot in the
# MAGIC subfolders UC16_PNL_REPORTING/CONSOLIDATION.
# MAGIC Remark: ViaReport is also called SAP FC.

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

import datetime

import pyspark.pandas as ps
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f
from pyspark.sql.utils import AnalysisException

from leap_utils.common import logger
from leap_utils.config import spark
from leap_utils.data_asset import table_utils
from leap_utils.ingestion import ingestion_utils

# COMMAND ----------

# MAGIC %md
# MAGIC # Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("force_data_asset_computation", "False")
FORCE_DATA_ASSET_COMPUTATION = (
    dbutils.widgets.get("force_data_asset_computation").lower() == "true"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Setup logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup", None):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "SAP FC ingestion"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC # Constants

# COMMAND ----------

INGESTION_S3_BUCKET = f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/"

SAP_FC_CONSOLIDATION_S3_FOLDER_PATH = (
    "manual/leapdepot/UC16_PNL_REPORTING/CONSOLIDATION"
)

SAP_FC_CONSOLIDATION_S3_BUCKET_PATH = (
    f"{INGESTION_S3_BUCKET}/{SAP_FC_CONSOLIDATION_S3_FOLDER_PATH}"
)

SAP_FC_CONSOLIDATION_S3_BUCKET_ARCHIVE_PATH = (
    f"{INGESTION_S3_BUCKET}/archive/{SAP_FC_CONSOLIDATION_S3_FOLDER_PATH}"
)

FILENAME_WITH_TIMESTAMP_REGEX = r"^(\d{8}\_\d{6})\_.*\.xlsx$"

# COMMAND ----------

# MAGIC %md
# MAGIC # Read SAP FC excel files in LEAP depot S3 bucket

# COMMAND ----------

# MAGIC %md
# MAGIC ## Find files to ingest

# COMMAND ----------

df_file_list = ingestion_utils.create_dbutils_ls_dataframe(
    SAP_FC_CONSOLIDATION_S3_BUCKET_PATH
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_file_list.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Keep only file names that matches leap depot timestamps and excel files

# COMMAND ----------

df_files_to_ingest = df_file_list.where(
    f.regexp_like(f.col("name"), f.lit(FILENAME_WITH_TIMESTAMP_REGEX))
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_files_to_ingest.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stop ingestion if there is no files to ingest

# COMMAND ----------

files_to_ingest = df_files_to_ingest.count() > 0

compute_data_asset = files_to_ingest | FORCE_DATA_ASSET_COMPUTATION

dbutils.jobs.taskValues.set("compute_data_asset", compute_data_asset)

if not files_to_ingest:
    dbutils.notebook.exit("No files to ingest")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ingest all files with pandas on spark

# COMMAND ----------

df_SAP_FC_ingested_files = spark.createDataFrame(
    data=[],
    schema=(
        "_meta_filepath string, "
        "_meta_filename string, "
        "_meta_modification_timestamp timestamp, "
        "_meta_ingestion_timestamp timestamp, "
        "_meta_leapdepot_timestamp timestamp"
    ),
)

ingestion_timestamp = datetime.datetime.now(tz=datetime.timezone.utc)

for file in df_files_to_ingest.collect():
    log.info("Reading file %s at: %s", file.name, file.path)

    # noinspection PyTypeChecker
    df_SAP_FC = (
        ps.read_excel(
            f"{SAP_FC_CONSOLIDATION_S3_BUCKET_PATH}/{file.name}",
            sheet_name=0,
            header=None,
            names=["AC", "DP", "RU", "Amt"],
            usecols="A:C,E",
            dtype="object",
            skiprows=[0, 1],
        )
        .to_spark()
        .alias("df_SAP_FC_raw")
    )

    metadata_columns = {
        "_meta_filepath": f.lit(file.path),
        "_meta_filename": f.lit(file.name),
        "_meta_modification_timestamp": f.to_utc_timestamp(
            f.lit(file.modification_timestamp), "UTC"
        ),
        "_meta_ingestion_timestamp": f.to_utc_timestamp(
            f.lit(ingestion_timestamp), "UTC"
        ),
        "_meta_leapdepot_timestamp": f.to_utc_timestamp(
            f.to_timestamp_ntz(
                f.regexp_extract(
                    f.col("_meta_filename"),
                    pattern=FILENAME_WITH_TIMESTAMP_REGEX,
                    idx=1,
                ),
                f.lit("yyyyMMdd_HHmmss"),
            ),
            "Europe/Paris",
        ),
    }

    df_SAP_FC = df_SAP_FC.withColumns(metadata_columns)

    df_SAP_FC = df_SAP_FC.select(*metadata_columns.keys(), "df_SAP_FC_raw.*")

    df_SAP_FC_ingested_files = df_SAP_FC_ingested_files.unionByName(
        df_SAP_FC, allowMissingColumns=True
    )

    log.info("Finished reading file %s\n", file.name)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_SAP_FC_ingested_files.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Add or replace ingested files in a stack table

# COMMAND ----------

try:
    df_SAP_FC_old_stack = spark.read.table(
        f"{PIPELINE_READ_ENV}_bronze"
        f".leap_depot_uc16_pnl_reporting"
        f".sap_fc_consolidation_stack"
    )
    df_SAP_FC_old_stack.limit(1).collect()

except AnalysisException as e:
    if e.getErrorClass() == "TABLE_OR_VIEW_NOT_FOUND":
        df_SAP_FC_old_stack = spark.createDataFrame(
            data=[], schema=df_SAP_FC_ingested_files.schema
        )
    else:
        raise AssertionError(
            "Something went wrong when trying to read "
            "the SAP FC consolidation stack table."
        ) from e

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_SAP_FC_old_stack.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Remove already ingested files in old stack

# COMMAND ----------

df_ingested_filenames = df_SAP_FC_ingested_files.select("_meta_filename").distinct()

ingested_filenames = list(df_ingested_filenames.toPandas()["_meta_filename"])

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_ingested_filenames.display()

# COMMAND ----------

df_SAP_FC_stack_filtered = df_SAP_FC_old_stack.where(
    ~f.col("_meta_filename").isin(*[f.lit(val) for val in ingested_filenames])
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_SAP_FC_stack_filtered.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Append new ingested files to stack

# COMMAND ----------

df_SAP_FC_new_stack = df_SAP_FC_stack_filtered.unionByName(
    df_SAP_FC_ingested_files, allowMissingColumns=True
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_SAP_FC_new_stack.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Save new stack

# COMMAND ----------

table_utils.save_table(
    f"{PIPELINE_WRITE_ENV}_bronze"
    f".leap_depot_uc16_pnl_reporting"
    f".sap_fc_consolidation_stack",
    df_SAP_FC_new_stack,
    mode="overwrite",
    overwrite_schema=False,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Archive ingested files in the archive folder

# COMMAND ----------

for filename in ingested_filenames:
    dbutils.fs.mv(
        f"{SAP_FC_CONSOLIDATION_S3_BUCKET_PATH}/{filename}",
        f"{SAP_FC_CONSOLIDATION_S3_BUCKET_ARCHIVE_PATH}/{filename}",
    )
