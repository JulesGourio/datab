# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Ingestion - P&L Budget
# MAGIC The aim of this notebook is to do the ingestion of the IS budget by CSV files that have been put in S3 by Talend from a shared deposit folder.
# MAGIC The business controllers put a csv file per branch and year in the given deposit folder, following a template pre-defined. In this ingestion script, some quality checks are done in order to avoid/prevent wrong data in the bronze table. As soon the file is ingested, it moves to a folder "Archive" in S3.
# MAGIC
# MAGIC **Inputs:** Files in s3://leap-s3-raw-weeu1-{env}/manual/leapdepot/UC16_PNL_REPORTING/BUDGET/{file_name}
# MAGIC
# MAGIC **Output table(s):**
# MAGIC
# MAGIC {env}_bronze.leap_depot_uc16_pnl_reporting.PNL_Budget
# MAGIC
# MAGIC **Used by:**
# MAGIC
# MAGIC create_silver_PNL_Budget
# MAGIC
# MAGIC **Triggered by:**
# MAGIC
# MAGIC File arrival in s3://leap-s3-raw-weeu1-{env}/manual/leapdepot/UC16_PNL_REPORTING/BUDGET/

# COMMAND ----------

# MAGIC %md
# MAGIC # Import

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import libraries

# COMMAND ----------

import re
import os

from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f
from pyspark.sql import DataFrame

import great_expectations as gx
from leap_utils.config import spark
from leap_utils.common.validation import gx_validation
from leap_utils.data_asset.table_utils import save_table

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widget

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")

dbutils.widgets.text("re_init_stack", "False")
RE_INIT_STACK = dbutils.widgets.get("re_init_stack").lower() == "true"

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC # User config for ingestion
# MAGIC
# MAGIC **Goal of a user config:**
# MAGIC - Dev speed: Dev only have to fill configuration, then every steps is done automatically
# MAGIC - maintainable: Factorize code ease up code maintanability
# MAGIC - standardise process:
# MAGIC
# MAGIC ### **Config options:**
# MAGIC
# MAGIC **Obligatory parameters:**
# MAGIC - folder_path: absolute path of folder
# MAGIC - file_name: name of the file
# MAGIC - dest_table: Destination path in Unity Catalog format: Catalog.Schema.table
# MAGIC
# MAGIC **Optionnal parameters:**
# MAGIC - quality_checks: Enumeration of all the quality checks that the dev wants to test on input dataframe.
# MAGIC     - Exhaustive list of possible quality checks:
# MAGIC         - expected columns:
# MAGIC         - null values in columns:
# MAGIC - removed_columns_space: Automatically removes space of columns names and change it by "_"
# MAGIC - stack_ids: Create ID columns from the concatenation of the columns gives in the list

# COMMAND ----------

Company = "Company"
Business_Unit = "Business_Unit"
PC_code = "PC_code"
CC_Code = "CC_Code"
Account_number = "Account_number"
Accounts_Name = "Accounts_Name"
Jan = "Jan"
Feb = "Feb"
Mar = "Mar"
Apr = "Apr"
May = "May"
Jun = "Jun"
Jul = "Jul"
Aug = "Aug"
Sept = "Sept"
Oct = "Oct"
Nov = "Nov"
Dec = "Dec"
TOTAL = "TOTAL"

# COMMAND ----------

l_columns_reference = [
    Company,
    Business_Unit,
    PC_code,
    CC_Code,
    Account_number,
    Accounts_Name,
    Jan,
    Feb,
    Mar,
    Apr,
    May,
    Jun,
    Jul,
    Aug,
    Sept,
    Oct,
    Nov,
    Dec,
    TOTAL,
]

l_columns_not_null = [Company, PC_code, Account_number]

stack_ids = [Company, PC_code, "Year"]

input_file_path_base = (
    f"s3://leap-s3-raw-weeu1-{env}/manual/leapdepot/UC16_PNL_REPORTING/BUDGET"
)

dest_table = f"{env}_bronze.leap_depot_uc16_pnl_reporting.pnl_budget"

CONFIG = {
    "folder_path": input_file_path_base,
    "dest_table": dest_table,
    "quality_checks": {
        "expected_columns": l_columns_reference,
        "columns_not_null": l_columns_not_null,
    },
    "removed_columns_space": True,
    "stack_ids": stack_ids,
}

# COMMAND ----------

# MAGIC %md
# MAGIC # Specific Code for ingestion P&L Budget
# MAGIC
# MAGIC Implemente specific logic for this specific ingestion

# COMMAND ----------


def replace_values_space(df, col_name: str):
    """
    Replace spaces with underscores in the values of the column in the DataFrame.

    :param df: the input DataFrame
    :type df: pyspark.sql.DataFrame
    :param df: name of the column
    :type df: str
    :return: DataFrame with column values replaced
    :rtype: pyspark.sql.DataFrame
    """
    return df.withColumn(col_name, f.regexp_replace(f.trim(f.col(col_name)), " ", "_"))


def extract_branch_and_date(filename):
    """
    Extracts the branch, year, and extraction date from a filename in the format "{extraction_date in format YYYYmmdd}_{hour_minute_second}_PNL_budget_{Branch}_{year}.csv".

    :param filename: The filename containing branch, year, and extraction date information.
    :type filename: str
    :return: A tuple containing the extracted branch, year, and extraction date.
    :rtype: tuple
    """
    pattern = r"(\d{8})_(\d{6})_PNL_budget_(.*?)_(\d{4})\.csv"

    match = re.match(pattern, filename)

    if match:
        extraction_date = match.group(1)
        branch = match.group(3)
        year = match.group(4)
        return extraction_date, branch, year
    else:
        return None, None, None


def remove_extension(file_name: str) -> str:
    """
    Remove file extension from a given file name.

    :param file_name: the file name
    :type file_name: str
    :return: the file name without extension
    :rtype: str
    """
    return os.path.splitext(file_name)[0]


def check_filename_format(filename):
    """
    Check if the given filename matches the format "PNL_budget_{string}_{date}.csv".

    :param filename: filename to check.
    :type file_name: str
    :return: True if file name matches the format
    :rtype: bool
    """
    pattern = r"(\d{8})_(\d{6})_PNL_budget_(.*?)_(\d{4})\.csv"
    return bool(re.match(pattern, filename))


def delete_null_rows(df: DataFrame):
    """
    Delete rows that are null in all columns of the DataFrame.

    :param df: the input DataFrame
    :type df: pyspark.sql.DataFrame
    :param df: name of the column
    :type df: str
    :return: DataFrame without rows with all null values
    :rtype: pyspark.sql.DataFrame
    """
    df_filtered = df.na.drop(how="all")
    return df_filtered


# COMMAND ----------

# MAGIC %md
# MAGIC # Generic code for ingestion

# COMMAND ----------

# MAGIC %md
# MAGIC ## Utils function

# COMMAND ----------

from leap_utils.data_asset.table_utils import (
    UnityCatalogCheckTableExists,
    remove_start_and_end_spaces_from_column_names,
    _cleanup_column_name,
)

# COMMAND ----------


def remove_column_space_dataframe(df: DataFrame):
    """
    Clean column names using _cleanup_column_name function.

    :param df: the DataFrame
    :return: DataFrame with column names without spaces
    """
    cleaned_columns = [_cleanup_column_name(col) for col in df.columns]
    return df.select(
        [
            f.col(col).alias(cleaned_col)
            for col, cleaned_col in zip(df.columns, cleaned_columns)
        ]
    )


def archive_file(folder_path: str, file_name: str) -> None:
    """
    Move a file to the 'archive' folder within the same directory.

    :param folder_path: the path of the folder containing the file
    :type folder_path: str
    :param file_name: the name of the file to be archived
    :type file_name: str
    """
    parts = folder_path.split("/")
    parts.insert(3, "archive")
    new_path = "/".join(parts)
    dbutils.fs.mv(f"{folder_path}/{file_name}", f"{new_path}/{file_name}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks

# COMMAND ----------


def quality_checks_on_input_file(df, config: dict[str, any]):
    """
    Perform quality checks on the input DataFrame using Great Expectations.

    :param df: the input DataFrame
    :type df: pyspark.sql.DataFrame
    :param config: configuration dictionary containing quality check parameters
    :type config: dict[str, any]
    """
    # Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
    red_quality_check_results = []

    df_gx = gx.dataset.SparkDFDataset(df, persist=False)
    for quality_check_name, quality_check_parameter in config["quality_checks"].items():
        if quality_check_name == "expected_columns":
            for column_ref in quality_check_parameter:
                red_quality_check_results.append(
                    df_gx.expect_column_to_exist(column=column_ref)
                )
            red_quality_check_results.append(
                df_gx.expect_table_column_count_to_be_between(
                    min_value=len(quality_check_parameter),
                    max_value=len(quality_check_parameter),
                )
            )

        if quality_check_name == "columns_not_null":
            for column_not_null in quality_check_parameter:
                red_quality_check_results.append(
                    df_gx.expect_column_values_to_not_be_null(column=column_not_null)
                )

    # Validate all red quality checks, if at least one fails the job stops
    gx_validation.validate_and_log_gx_results(
        quality_check_results=red_quality_check_results,
        validation_level="RED",
        info_message="There's no duplicated rows and col_a doesn't have any null value",
        error_message="At least one red quality checks is KO, the job has stopped, check corresponding results",
        pipeline_write_env=env,
        table_name="P_L_budget_bronze",
        log_to_event_table=True,
        log_successes=True,
    )


# COMMAND ----------

# MAGIC %md
# MAGIC # Execute Ingestion

# COMMAND ----------

# MAGIC %md
# MAGIC ## Retrieve budget file in s3 bucket

# COMMAND ----------

df_s3_files = spark.createDataFrame(dbutils.fs.ls(f"{input_file_path_base}/"))

name_list = [
    row.name
    for row in df_s3_files.select("name")
    .filter(f.col("name").endswith("csv"))
    .collect()
]
for name in name_list:
    if not check_filename_format(filename=name):
        raise Exception(f"file name not in right format: {name}")
        dbutils.notebook.exit(f"file name not in right format: {name}")
    else:
        pattern = r"(\d{8})_(\d{6})_PNL_budget_(.*?)_(\d{4})\.csv"
        match = re.match(pattern, name)
        if match.group(3) == "IS":
            file_name = name
            input_complete_file_path = (
                df_s3_files.filter(f.col("name") == name).select("path").collect()[0][0]
            )
        else:
            input_complete_file_path = None

if not input_complete_file_path:
    raise Exception("Not IS budget file in folder")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Main

# COMMAND ----------

df = spark.read.options(header="True", delimiter=";").csv(input_complete_file_path)

df = delete_null_rows(df=df)
df = replace_values_space(df, "Company")
df = remove_start_and_end_spaces_from_column_names(df=df)

if "removed_columns_space" in CONFIG.keys():
    if CONFIG["removed_columns_space"]:
        df = remove_column_space_dataframe(df=df)

if "quality_checks" in CONFIG.keys():
    quality_checks_on_input_file(df, config=CONFIG)

# Add a column with the file name - contains the Talend extraction timestamps
df_with_file_name = df.withColumn(
    "File_name", f.lit(remove_extension(file_name=file_name))
)
# Read, if exists, the bronze stack/history table
extraction_date, branch, year = extract_branch_and_date(file_name)
df_with_file_name = (
    df_with_file_name.withColumn("Branch", f.lit(branch))
    .withColumn("Year", f.lit(year))
    .withColumn("Extraction_date", f.lit(extraction_date))
)
df_fin = df_with_file_name.withColumn("ID", f.concat_ws("_", *CONFIG["stack_ids"]))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save latest table

# COMMAND ----------

split_dest_table = dest_table.lower().split(".")
catalog = split_dest_table[0]
domain = split_dest_table[1]
table = split_dest_table[2]

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

save_table(
    dest_table=f"{catalog}.{domain}.{table}_latest",
    df=df_fin,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Append History

# COMMAND ----------

if UnityCatalogCheckTableExists(f"{dest_table}_history"):
    df_stack = spark.read.table(f"{dest_table}_history")
    df_stack_id = df_stack.withColumn("ID", f.concat_ws("_", *CONFIG["stack_ids"]))

    df_with_file_name_with_id = df_with_file_name.withColumn(
        "ID", f.concat_ws("_", *CONFIG["stack_ids"])
    )
    ID = df_with_file_name_with_id.select("ID").dropDuplicates().collect()[0]["ID"]
    df_stack_id_new = df_stack_id.filter(f.col("ID") != ID)

    df_stack_f = df_stack_id_new.unionByName(
        df_with_file_name_with_id, allowMissingColumns=RE_INIT_STACK
    )
else:
    df_stack_f = df_with_file_name.withColumn(
        "ID", f.concat_ws("_", *CONFIG["stack_ids"])
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save table

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

save_table(
    dest_table=f"{catalog}.{domain}.{table}_history",
    df=df_stack_f,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Archive files in S3
# MAGIC When the file is ingested, the csv in S3 goes to a folver "Archive". Therefore, only new files are ingested, and we keep in S3 a copy of the file upload by the business.

# COMMAND ----------

archive_file(folder_path=input_file_path_base, file_name=file_name)

# COMMAND ----------
