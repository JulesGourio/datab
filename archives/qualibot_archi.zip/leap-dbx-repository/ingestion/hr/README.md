# HR Ingestion - Custom LEAP Notebooks

This folder contains the ingestion notebooks for the **HR (Human Resources)** data domain. These are custom LEAP notebooks (not generic DLT/SDP) that ingest CSV and Parquet files from S3 into the landingzone and bronze layers, with schema evolution handling and file archiving.

> **Note:** These notebooks currently run as Databricks Jobs (not yet bundled as a Databricks Asset Bundle). A bundle will be created to integrate them.

## Architecture

```mermaid
flowchart LR
    subgraph S3["S3 Source"]
        DEPOT["leapdepot S3<br/>UC33_HR/ABSENTEISM/"]
        HR["hr S3<br/>apps/hr/"]
    end

    subgraph JOBS["Databricks Jobs"]
        direction TB
        T0["hr_copy_leapdepot_files<br/>(move ABS files)"]
        T1["hr_ref_ingestion_to_bronze<br/>(ingest CSV/PARQUET)"]
        T0 --> T1
    end

    subgraph UC["Unity Catalog"]
        LZ["sd_{env}_landingzone.hr<br/>*_stack (Tables)"]
        BZ["sd_{env}_bronze.hr<br/>*_latest (Views)"]
    end

    DEPOT --> T0
    T0 --> HR
    HR --> T1
    T1 --> LZ
    LZ --> BZ

    style DEPOT fill:#fff9c4,stroke:#f57f17,color:#1a1a1a
    style HR fill:#fff9c4,stroke:#f57f17,color:#1a1a1a
    style T0 fill:#f3e5f5,stroke:#7b1fa2,color:#1a1a1a
    style T1 fill:#f3e5f5,stroke:#7b1fa2,color:#1a1a1a
    style LZ fill:#e1f5fe,stroke:#01579b,color:#1a1a1a
    style BZ fill:#c8e6c9,stroke:#2e7d32,color:#1a1a1a
```

## Workflow

```mermaid
sequenceDiagram
    participant LD as leapdepot S3
    participant S3 as hr S3
    participant Job as Databricks Job
    participant UC as Unity Catalog

    Note over LD,S3: Step 1: File Copy (ABS only)
    Job->>LD: hr_copy_leapdepot_files
    LD-->>S3: Move ABS CSV files<br/>(cleanup double timestamps)
    Note over Job,S3: Only ABS files pass through leapdepot<br/>REF files arrive directly in hr S3

    Note over S3,UC: Step 2: Ingestion to Bronze
    Job->>S3: hr_ref_ingestion_to_bronze
    S3-->>Job: List & read CSV/PARQUET files
    Note over Job: For each file type:<br/>1. Detect schema changes<br/>2. Create stack table (new schema → new table)<br/>3. Add metadata columns<br/>4. Quality checks (not null, uniqueness)<br/>5. Create latest view (deduplicated)
    Job->>UC: Write stack tables (landingzone)
    Job->>UC: Create latest views (bronze)
    Job->>S3: Archive processed files
```

## Data Flow

```mermaid
flowchart TB
    subgraph PIPELINE[" "]
        direction TB
        subgraph SOURCE["S3 SOURCE"]
            f1[("REPORT_RH_LEAP.csv<br/>or .parquet<br/>(Workforce Referential)")]
            f2[("ABS.csv<br/>(Absenteism)")]
        end
        s0{{"hr_copy_leapdepot_files<br/>(move ABS from leapdepot)"}}
        s1{{"hr_ref_ingestion_to_bronze<br/>(custom ingestion)"}}
        subgraph LANDINGZONE["LANDINGZONE"]
            st1[("sd_{env}_landingzone.hr<br/>.v_report_rh_leap_stack")]
            st2[("sd_{env}_landingzone.hr<br/>.t_absenteism_rh_leap_stack")]
        end
        subgraph BRONZE["BRONZE"]
            lt1[/"sd_{env}_bronze.hr<br/>.v_report_rh_leap_latest"/]
            lt2[/"sd_{env}_bronze.hr<br/>.t_absenteism_rh_leap_latest"/]
        end
        f2 -.-> s0
        s0 --> f2
        f1 --> s1
        f2 --> s1
        s1 --> st1
        s1 --> st2
        st1 --> lt1
        st2 --> lt2
    end

    subgraph ARCHIVE["ARCHIVE"]
        ar[("S3 archive/apps/hr/<br/>SCHEMA_{n}/")]
    end

    s1 -.-> ar

    classDef source fill:#fff9c4,stroke:#f57f17,stroke-width:2px,color:#1a1a1a
    classDef script fill:#f3e5f5,stroke:#7b1fa2,stroke-width:2px,color:#1a1a1a
    classDef dataTable fill:#e1f5fe,stroke:#01579b,stroke-width:2px,color:#1a1a1a
    classDef dataView fill:#fff3e0,stroke:#e65100,stroke-width:2px,stroke-dasharray: 5 5,color:#1a1a1a
    classDef enrichment fill:#c8e6c9,stroke:#2e7d32,stroke-width:1px,color:#1a1a1a

    class f1,f2 source
    class s0,s1 script
    class st1,st2 dataTable
    class lt1,lt2 dataView
    class ar enrichment
```

**Legend:**
- **Cylinders** `[( )]` = DATA (Tables)
- **Parallelograms** `[/ /]` = DATA (Views)
- **Hexagons** `{{ }}` = SCRIPTS (Transformations)
- **Solid arrows** `-->` = Direct pipeline data flow
- **Dashed arrows** `-.->` = File movement / archiving

## Source Files

### S3 Locations

| Property | Value |
|----------|-------|
| **Source Bucket (ABS copy)** | `s3://leap-s3-raw-weeu1-{env}/manual/leapdepot/UC33_HR/ABSENTEISM/` |
| **Destination / Main Bucket** | `s3://leap-s3-raw-sd-lat-{env}/apps/hr/` |
| **Archive Bucket** | `s3://leap-s3-raw-sd-lat-{env}/archive/apps/hr/SCHEMA_{n}/` |

> **Note:** The `sd` prefix in the S3 bucket name (`leap-s3-raw-sd-lat-{env}`) indicates sensitive data (PII). These buckets have restricted access.

### File Naming Convention

```
YYYYMMDD_HHMMSS_REPORT_RH_LEAP.csv
YYYYMMDD_HHMMSS_REPORT_RH_LEAP.parquet
YYYYMMDD_HHMMSS_ABS.csv
```

### Source Files Configuration

| Table Name | File Regex | Format | Mode | Delimiter | Primary Key |
|-----------|-----------|--------|------|-----------|-------------|
| `v_report_rh_leap` | `^(\d{8})_(\d{6})_REPORT_RH_LEAP.csv` | CSV | FULL | `;` | `User_ID` |
| `v_report_rh_leap` | `^(\d{8})_(\d{6})_REPORT_RH_LEAP.parquet` | PARQUET | FULL | - | `User_ID` |
| `t_absenteism_rh_leap` | `^(\d{8})_(\d{6})_ABS.csv` | CSV | DELTA | `;` | `Year,Month,Country,Workplace` |

- **FULL mode**: Each file contains the complete dataset; latest view keeps most recent extraction per PK
- **DELTA mode**: Incremental files; latest view deduplicates by PK keeping most recent timestamp

## Notebooks

### 1. `hr_copy_leapdepot_files.py`

Copies ABS (absenteism) CSV files from the leapdepot S3 bucket to the hr destination bucket.

**Purpose:** The ABS files are initially deposited by an external process into a shared `leapdepot` bucket. This notebook moves them to the HR-specific S3 path where the ingestion notebook expects them.

**Key Logic:**
- Source: `s3://leap-s3-raw-weeu1-{env}/manual/leapdepot/UC33_HR/ABSENTEISM/`
- Destination: `s3://leap-s3-raw-sd-lat-{env}/apps/hr/`
- Handles double-timestamp filename cleanup (regex `^\d{8}_\d{6}_(\d{8}_\d{6}_ABS\.csv)$`)
- Uses `dbutils.fs.mv()` (move, not copy) — files are removed from source after transfer

**Widgets:**
| Widget | Default | Description |
|--------|---------|-------------|
| `PIPELINE_WRITE_ENV` | `dev` | Target environment |
| `REFERENCE_READ_ENV` | `dev` | Source environment |

### 2. `hr_ref_ingestion_to_bronze.py`

Custom ingestion notebook that reads CSV and Parquet files from S3 and writes to landingzone (stack tables) and bronze (latest views).

**Key Features:**
- **Schema evolution handling**: Detects column changes between files and existing stack tables. If schema differs, creates a new stack table with suffix `_SCHEMA_{n}` and a new union view
- **File archiving**: After successful ingestion, files are moved to `archive/apps/hr/SCHEMA_{n}/`
- **Metadata enrichment**: Adds `_meta_ID`, `_meta_extraction_timestamp`, `_meta_ingestion_timestamp`, `_meta_file_name`, `_meta_file_mode`, `_meta_file_path`, `_meta_validity_check`
- **Quality checks**: Great Expectations `gx_check_compound_uniqueness` (RED) and `gx_check_not_null` (RED) on primary keys
- **Latest view**: Creates a deduplicated view per PK showing the most recent extraction

**Widgets:**
| Widget | Default | Description |
|--------|---------|-------------|
| `PIPELINE_READ_ENV` | `dev` | Read environment |
| `PIPELINE_WRITE_ENV` | `dev` | Write environment |
| `REFERENCE_READ_ENV` | `dev` | Reference environment |
| `force_reinitialization` | `False` | Drop and recreate tables |
| `force_new_schema` | `False` | Force new schema version |

**Catalogs Used (special `sd_` prefix):**
| Layer | Catalog Pattern |
|-------|----------------|
| Landingzone | `sd_{env}_landingzone.hr` |
| Bronze | `sd_{env}_bronze.hr` |

## Tables Produced

### Landingzone (Stack Tables)

| Table | Description |
|-------|-------------|
| `sd_{env}_landingzone.hr.v_report_rh_leap_stack` | All ingested workforce referential rows (full history) |
| `sd_{env}_landingzone.hr.t_absenteism_rh_leap_stack` | All ingested absenteism rows (incremental history) |

### Bronze (Latest Views)

| View | Description |
|------|-------------|
| `sd_{env}_bronze.hr.v_report_rh_leap_latest` | Deduplicated workforce data (latest per `User_ID`) |
| `sd_{env}_bronze.hr.t_absenteism_rh_leap_latest` | Deduplicated absenteism data (latest per `Year,Month,Country,Workplace`) |

> **Schema evolution:** If the source file schema changes, a new stack table is created (e.g., `v_report_rh_leap_stack_SCHEMA_2`) and the `_stack` / `_latest` views are updated to union all schema versions.

### Metadata Columns (added by pipeline)

| Column | Type | Description |
|--------|------|-------------|
| `_meta_stack_row_id` | BIGINT | Auto-generated identity column |
| `_meta_ID` | STRING | Composite key from primary key columns |
| `_meta_extraction_timestamp` | TIMESTAMP | Extracted from filename (`YYYYMMDD_HHMMSS`) |
| `_meta_ingestion_timestamp` | TIMESTAMP | Pipeline execution time |
| `_meta_file_name` | STRING | Source file name |
| `_meta_file_mode` | STRING | `FULL` or `DELTA` |
| `_meta_file_path` | STRING | Full S3 path |
| `_meta_validity_check` | BOOLEAN | Column presence validation |

## LEAP Modules Used

```python
from leap_utils.table import table_utils        # Table operations, schema management
from leap_utils.files import files_utils         # S3 file listing and operations
from leap_utils.quality import gx_validation     # Great Expectations quality checks
from leap_utils.log import log                   # Structured logging
```

## Troubleshooting

### Common Issues

1. **Double-timestamp filenames in ABS files**
   - **Cause:** External process deposits files with double timestamps (`20260310_080000_20260310_080000_ABS.csv`)
   - **Fix:** `hr_copy_leapdepot_files.py` automatically strips the outer timestamp

2. **Schema mismatch — new stack table created unexpectedly**
   - **Cause:** Source CSV/Parquet has new or renamed columns
   - **Fix:** Check the new schema version. If intentional, the pipeline handles it. If not, fix the source export

3. **Quality check failure (RED)**
   - **Cause:** Duplicate primary keys or NULL values in PK columns
   - **Fix:** Check the source file for data quality issues

4. **Files not detected**
   - **Cause:** Files not matching regex pattern or in wrong S3 path
   - **Fix:** Verify files are in `s3://leap-s3-raw-sd-lat-{env}/apps/hr/` with correct naming

5. **Empty tables after ingestion**
   - **Cause:** `_meta_validity_check` filtering removed all rows
   - **Fix:** Check if expected columns are present in the source file

### Useful Queries

```sql
-- Check latest ingested files (workforce)
SELECT _meta_file_name, _meta_extraction_timestamp, _meta_ingestion_timestamp, count(*) as rows
FROM sd_{env}_landingzone.hr.v_report_rh_leap_stack
GROUP BY 1, 2, 3
ORDER BY _meta_ingestion_timestamp DESC;

-- Check latest ingested files (absenteism)
SELECT _meta_file_name, _meta_extraction_timestamp, _meta_ingestion_timestamp, count(*) as rows
FROM sd_{env}_landingzone.hr.t_absenteism_rh_leap_stack
GROUP BY 1, 2, 3
ORDER BY _meta_ingestion_timestamp DESC;

-- Check latest deduplicated workforce data
SELECT User_ID, Status, First_name, Last_name, _meta_extraction_timestamp
FROM sd_{env}_bronze.hr.v_report_rh_leap_latest
ORDER BY User_ID
LIMIT 100;

-- Check latest deduplicated absenteism data
SELECT Year, Month, Country, Workplace, Total_Work_days, Total_abs
FROM sd_{env}_bronze.hr.t_absenteism_rh_leap_latest
ORDER BY Year DESC, Month DESC;

-- Check schema versions
SHOW TABLES IN sd_{env}_landingzone.hr LIKE '*stack*';
```

## Folder Structure

```
ingestion/hr/
├── hr_copy_leapdepot_files.py          # Move ABS files from leapdepot to hr S3
├── hr_ref_ingestion_to_bronze.py       # Custom ingestion: S3 → landingzone → bronze
└── README.md
```

## Related Documentation

- **Data Asset Notebooks:** `data_asset/hr/README.md` (Silver, Gold, Proj transformations)
- **LEAP Table Utils:** `leap_utils/table/table_utils.py`
- **LEAP File Utils:** `leap_utils/files/files_utils.py`
- **GX Validation:** `leap_utils/quality/gx_validation.py`
