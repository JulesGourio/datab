# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # HR RAW FILES INGESTION
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to ingest tables from S3 CSV files and PARQUET files
# MAGIC
# MAGIC HR referential is provided in PARQUET by TALEND
# MAGIC
# MAGIC HR referential history files are provided in CSV format manually by HR people
# MAGIC
# MAGIC HR absenteism is provided in CSV format manually by HR people
# MAGIC
# MAGIC The files are extracted from HR oracle Referential.
# MAGIC - 1st STEP : CSV/PARQUET to landingzone stack table
# MAGIC - For Each file definition
# MAGIC > - Find all files corresponding to definition
# MAGIC > - Ingest all files who have same schema than stack table and archive
# MAGIC > - Ingest all files who have a new schema in a new landingzone stack table and archive
# MAGIC - 2nd STEP : create a bronze view of stack doing the union of all stack tables
# MAGIC - 3rd STEP : create a bronze latest table
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - The Notebook may appear a bit complicated but it is enough flexible :
# MAGIC > - to ingest several kind of files to several destination tables
# MAGIC > - to ingest CSV as well as PARQUET FILES
# MAGIC > - to handle schema changes
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - hr ingestion.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC - s3://leap-s3-raw-sd-lat-{reference_read_env}/apps/hr/YYYYmmDD_HHMMSS_REPORT_RH_LEAP.csv
# MAGIC - s3://leap-s3-raw-sd-lat-{reference_read_env}/apps/hr/YYYYmmDD_HHMMSS_REPORT_RH_LEAP.parquet
# MAGIC - s3://leap-s3-raw-sd-lat-{reference_read_env}/apps/hr/YYYYmmDD_HHMMSS_ABS.csv
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC N/A
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - sd_{pipeline_write_env}_landingzone.hr.v_report_rh_leap_stack
# MAGIC - sd_{pipeline_write_env}_bronze.hr.v_report_rh_leap_latest
# MAGIC - sd_{pipeline_write_env}_landingzone.hr.t_absenteism_rh_leap
# MAGIC - sd_{pipeline_write_env}_bronze.hr.t_absenteism_rh_leap
# MAGIC
# MAGIC **Output Files Pipeline**
# MAGIC - s3://leap-s3-raw-sd-lat-{reference_read_env}/archive/apps/hr/SCHEMA_{n}/
# MAGIC
# MAGIC   ***schema number is incremental and starts from 0***
# MAGIC
# MAGIC **CSV structure of known files**
# MAGIC ```
# MAGIC ```
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
import re
import os
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame
from typing import List, Tuple, Optional

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.validation import gx_validation
from leap_utils.common.files import files_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("force_new_schema", "False")
FORCE_NEW_SCHEMA = dbutils.widgets.get("force_new_schema").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ### force_reinitialization Boolean
# MAGIC
# MAGIC force_reinitialization -> Used for force ingestion of all S3 files.

# COMMAND ----------

# If force_reinitialization is True then the stack table will be reinitialized
dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = dbutils.widgets.get("force_reinitialization").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

# Global variables
BUCKET_NAME = f"leap-s3-raw-sd-lat-{REFERENCE_READ_ENV}"
ROOT_DIR_PREFIX = "apps/hr/"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

# regex describing filenames for inventorylevel
V_REPORT_RH_FILENAME_REGEX_CSV = r"^(\d{8})_(\d{6})_REPORT_RH_LEAP.csv"
V_REPORT_RH_FILENAME_REGEX_PARQUET = r"^(\d{8})_(\d{6})_REPORT_RH_LEAP.parquet"
T_ABSENTEISM_FILENAME_REGEX_CSV = r"^(\d{8})_(\d{6})_ABS.csv"


# List of dictionaries, each one describing attributes of an expected category of file
FILES_ATTRS_DICT = [
    {
        "table_name": "v_report_rh_leap",
        "file_regex": V_REPORT_RH_FILENAME_REGEX_CSV,
        "dir_prefix": "apps/hr/",
        "file_mode": "FULL",
        "file_type": "CSV",
        "csv_field_delimiter": ";",
        "file_expected_cols": [
            "User_ID",
            "Status",
            "First_name",
            "Last_name",
        ],
        "primary_key": "User_ID",
        "notnull_cols": "User_ID,First_name,Last_name",
    },
    {
        "table_name": "v_report_rh_leap",
        "file_regex": V_REPORT_RH_FILENAME_REGEX_PARQUET,
        "dir_prefix": "apps/hr/",
        "file_mode": "FULL",
        "file_type": "PARQUET",
        "csv_field_delimiter": "",
        "file_expected_cols": [
            "User_ID",
            "Status",
            "First_name",
            "Last_name",
        ],
        "primary_key": "User_ID",
        "notnull_cols": "User_ID,First_name,Last_name",
    },
    {
        "table_name": "t_absenteism_rh_leap",
        "file_regex": T_ABSENTEISM_FILENAME_REGEX_CSV,
        "dir_prefix": "apps/hr/",
        "file_mode": "DELTA",
        "file_type": "CSV",
        "csv_field_delimiter": ";",
        "file_expected_cols": [
            "Year",
            "Month",
            "Country",
            "Workplace",
            "Total_Work_days",
            "Total_abs",
        ],
        "primary_key": "Year,Month,Country,Workplace",
        "notnull_cols": "Year,Month,Country,Workplace",
    },
]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

ARCHIVE_BUCKET_NAME = (
    f"leap-s3-raw-sd-lat-{PIPELINE_WRITE_ENV}"  # Same ENV as output tables
)
ROOT_ARCHIVE_DIR_PREFIX = "archive/apps/hr/"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

LANDING_ZONE_CATALOG = f"sd_{PIPELINE_WRITE_ENV}_landingzone"
LANDING_ZONE_SCHEMA = "hr"
BRONZE_CATALOG = f"sd_{PIPELINE_WRITE_ENV}_bronze"
BRONZE_SCHEMA = "hr"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

TABLE_STACK_FIRST_COLS = {
    "_meta_stack_row_id": "BIGINT GENERATED ALWAYS AS IDENTITY COMMENT 'STACK UNIQUE ID GENERATED ALWAYS AS IDENTITY'",
    "_meta_ID": "STRING",
    "_meta_extraction_timestamp": "TIMESTAMP",
    "_meta_ingestion_timestamp": "TIMESTAMP",
    "_meta_file_name": "STRING",
    "_meta_file_mode": "STRING",
    "_meta_file_path": "STRING",
    # "User_ID": "STRING",
}

TABLE_LATEST_FIRST_COLS = {
    "_meta_stack_row_id": "BIGINT COMMENT 'STACK UNIQUE ID GENERATED ALWAYS AS IDENTITY'",
    "_meta_ID": "STRING",
    "_meta_extraction_timestamp": "TIMESTAMP",
    "_meta_ingestion_timestamp": "TIMESTAMP",
    "_meta_file_name": "STRING",
    "_meta_file_mode": "STRING",
    "_meta_file_path": "STRING",
    # "User_ID": "STRING",
}

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

THE_ORIGIN = "1970-01-01"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"BUCKET_NAME is:  {BUCKET_NAME}")
log.info(f"ROOT_DIR_PREFIX is:  {ROOT_DIR_PREFIX}")
log.info(f"ARCHIVE_BUCKET_NAME is:  {ARCHIVE_BUCKET_NAME}")
log.info(f"ROOT_ARCHIVE_DIR_PREFIX is:  {ROOT_ARCHIVE_DIR_PREFIX}")
log.info(f"FORCE_REINITIALIZATION is:  {FORCE_REINITIALIZATION}")
log.info(f"LANDING_ZONE_CATALOG is:  {LANDING_ZONE_CATALOG}")
log.info(f"LANDING_ZONE_SCHEMA is:  {LANDING_ZONE_SCHEMA}")
log.info(f"BRONZE_CATALOG is:  {BRONZE_CATALOG}")
log.info(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.info(f"FORCE_NEW_SCHEMA is:  {FORCE_NEW_SCHEMA}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------


def is_same_schema(
    old_schema: List[str], new_schema: List[str], metadata_info: List[Tuple[str, str]]
) -> bool:
    """
    Check if two schema are the same after cleaning elements of the second schema.

    :param old_schema: List of column names in the old schema
    :type old_schema: List[str]
    :param new_schema: List of column names in the new schema
    :type new_schema: List[str]
    :param metadata_info: A list of tuples where the first element of each tuple specifies substrings
                          to be removed from `old_schema` for comparison purposes.
                          The second element of the tuple can provide additional metadata but is not used.
    :type metadata_info: List[Tuple[str, str]]
    :return: Whether the schemas are the same or not
    :rtype: bool
    """
    strings_to_remove = [item[0] for item in metadata_info]
    cleaned_new_schema = sorted(
        [table_utils._cleanup_column_name(item) for item in new_schema]
    )
    cleaned_old_schema = sorted(
        [item for item in old_schema if item not in strings_to_remove]
    )
    return cleaned_old_schema == cleaned_new_schema


# COMMAND ----------


def create_or_replace_initial_stack_table(table_name: str) -> Optional[str]:
    """
    Create a stack table in Unity Catalog if it does not exist, or reinitialize it if the reinitialization flag is set.

    This function checks if a stack table with the given name exists in the Unity Catalog. If it does not exist,
    or if the reinitialization flag is set (`FORCE_REINITIALIZATION`), the function will create the table.
    If the table already exists and reinitialization is not requested, the function will simply return the
    full table path.

    :param table_name: The short name of the table to create or replace. The table name should not include
                       the catalog or schema (e.g., "my_table").
    :type table_name: str

    :return: The full path of the table in the Unity Catalog if the table is created or already exists;
             `None` if an error occurs during table creation.
    :rtype: Optional[str]

    :raises AnalysisException: If there is an error while creating the Unity Catalog table.

    :example:
        >>> create_or_replace_initial_stack_table("my_stack_table")
        'LANDING_ZONE_CATALOG.LANDING_ZONE_SCHEMA.my_stack_table'

    """
    output_table_path = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}"
    if (not table_utils.UnityCatalogCheckTableExists(output_table_path)) or (
        FORCE_REINITIALIZATION
    ):
        # Create unity catalog table if it does not exist, or reinitialize table if param set to True
        try:
            table_utils.create_unity_catalog_table(
                catalog=LANDING_ZONE_CATALOG,
                domain=LANDING_ZONE_SCHEMA,
                table=table_name,
                force_reinitialization=FORCE_REINITIALIZATION,
                cluster_cols=None,
                partition_col="_meta_extraction_timestamp",
                columns=TABLE_STACK_FIRST_COLS,
                force_drop=True,
            )
            return output_table_path
        except AnalysisException as e:
            log.error(
                f"Table {output_table_path} has not been created, an error occured during creation.\nException is :{e}\n"
            )
            return None
    else:
        return output_table_path


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : search_for_files
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to search for files on certain criteria.
# MAGIC
# MAGIC **How to call:**
# MAGIC file_list = search_for_files(BUCKET_NAME, PREFIX, FILES_ATTRS_DICT[0] )
# MAGIC
# MAGIC **Output:**
# MAGIC List of dicts, each dict having following keys : "filename","filepath","fileprefix","filemode","tablename","timestamp"
# MAGIC

# COMMAND ----------


def search_for_files(
    bucket: str, dir_prefix: str, search_attributes: dict
) -> List[dict]:
    """
    Search for files in an S3 bucket with a specific directory prefix that match the given search attributes.

    This function will search for files within the S3 bucket specified by `bucket` and the directory prefix
    `dir_prefix` that match the search criteria provided in `search_attributes`. The search criteria include
    a table name, a file regex pattern, and a file mode (either 'FULL' or 'DELTA').

    :param bucket: The name of the S3 bucket where files are stored.
    :type bucket: str

    :param dir_prefix: The directory prefix within the S3 bucket to limit the search to.
    :type dir_prefix: str

    :param search_attributes: A dictionary containing the search criteria. It should have the following keys:
        - "table_name" (str): The name of the table associated with the files.
        - "file_regex" (str): A regular expression pattern used to match file names.
        - "file_mode" (str): The mode of the file, either 'FULL' or 'DELTA', which defines whether the file is a complete dataset or an incremental update.
    :type search_attributes: dict

    :return: A list of dictionaries containing information about each file that matches the search criteria.
        Each dictionary contains the following keys:
        - "filename" (str): The name of the file (e.g., '20240910_150600_REPORT_RH_LEAP.csv').
        - "filepath" (str): The full S3 path to the file (e.g., 's3://bucket_name/apps/hr/20240910_150600_REPORT_RH_LEAP.csv').
        - "fileprefix" (str): The prefix associated with the file (e.g., 'v_report_rh_leap').
        - "filekey" (str): The S3 key for the file (e.g., 'apps/hr/20240910_150600_REPORT_RH_LEAP.csv').
        - "dirprefix" (str): The directory prefix (e.g., 'apps/hr/').
        - "filemode" (str): The mode of the file ('FULL' or 'DELTA').
        - "tablename" (str): The name of the bronze table the file corresponds to (e.g., 'v_report_rh_leap').
        - "timestamp" (str): The timestamp associated with the file (e.g., '2024-02-22T10:16:20Z').

    :rtype: List[dict]

    :example:
        >>> search_for_files(
                bucket='my-bucket',
                dir_prefix='apps/hr/',
                search_attributes={
                    "table_name": "v_report_rh_leap",
                    "file_regex": ".*_REPORT_RH_LEAP.csv",
                    "file_mode": "FULL"
                }
            )
        [
            {
                "filename": "20240910_150600_REPORT_RH_LEAP.csv",
                "filepath": "s3://my-bucket/apps/hr/20240910_150600_REPORT_RH_LEAP.csv",
                "fileprefix": "v_report_rh_leap",
                "filekey": "apps/hr/20240910_150600_REPORT_RH_LEAP.csv",
                "dirprefix": "apps/hr/",
                "filemode": "FULL",
                "tablename": "v_report_rh_leap",
                "timestamp": "2024-09-10T15:06:00Z"
            },
            {
                "filename": "20240911_150600_REPORT_RH_LEAP.csv",
                "filepath": "s3://my-bucket/apps/hr/20240911_150600_REPORT_RH_LEAP.csv",
                "fileprefix": "v_report_rh_leap",
                "filekey": "apps/hr/20240911_150600_REPORT_RH_LEAP.csv",
                "dirprefix": "apps/hr/",
                "filemode": "DELTA",
                "tablename": "v_report_rh_leap",
                "timestamp": "2024-09-11T15:06:00Z"
            }
        ]

    """
    log.debug(f"search_for_files(): search_attributes : {search_attributes}")
    # Get the list of all objects in the bucket and prefix
    file_list = files_utils.list_files_in_s3_bucket_with_prefix(
        bucket, dir_prefix, recursive=True
    )

    # Filter file_list
    file_list = [
        file
        for file in file_list
        if re.match(search_attributes["file_regex"], os.path.basename(file))
    ]

    # Returned file list
    output_file_list = []

    for item in file_list:
        filename = os.path.basename(item)
        protocol, s3_path_rest = item.split("://", 1)
        bucket_name, filekey = s3_path_rest.split("/", 1)
        dirprefix = filekey.rsplit("/", 1)[0]

        match = re.match(search_attributes["file_regex"], filename)
        if match:
            date = match.group(1)
            timestamp = match.group(2)
            base_filename = os.path.splitext(filename)[0]
            fileprefix = base_filename.split("_", 2)[-1].split("-")[0]
            log.debug(f"search_for_files(): Found file to process : {filename}")
            try:
                filemode = base_filename.split("_", 2)[-1].split("-")[1]
                if filemode == "F":
                    filemode = "FULL"
                else:
                    filemode = "DELTA"
            except:
                filemode = search_attributes["file_mode"]
            print(filemode)

            # convert strings from format "YYYYMMDD" and "HHmmss" to timestamp
            last_modified_datetime = time.strptime(
                f"{date} {timestamp}", "%Y%m%d %H%M%S"
            )
            # convert timestamp to string
            last_modified_string = (
                time.strftime("%Y-%m-%dT%H:%M:%S", last_modified_datetime) + "Z"
            )
            log.debug(f"search_for_files(): Found file to process : {filename}.\n--")
            output_file_list.append(
                {
                    "filename": filename,
                    "filepath": item,
                    "fileprefix": fileprefix,
                    "filekey": filekey,
                    "dirprefix": dirprefix,
                    "filemode": filemode,
                    "tablename": search_attributes["table_name"],
                    "timestamp": last_modified_string,
                }
            )
        else:
            log.info(f"File ignored {filename} , bad format !!!\n--")

    return output_file_list


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : process_one_csv_file
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to load one CSV file, write stack table and add primary key.
# MAGIC
# MAGIC **How to call:**
# MAGIC process_one_csv_file(files_dict_list, file_expected_cols, input_table_name, input_table_primary_key_columns, input_table_notnull_columns, file_csv_field_delimiter )
# MAGIC
# MAGIC **Output:**
# MAGIC - file_name if OK
# MAGIC - None if ERROR

# COMMAND ----------


def process_one_csv_file(
    file_dict: dict,
    file_expected_cols: List[str],
    input_table_primary_key_columns: str,
    input_table_notnull_columns: str,
    file_csv_field_delimiter: str,
    sql_id_generator: str,
    output_table_path: str,
    schema_version_number: str,
):
    """
    Process one CSV file at a time: read the CSV file, transform it, write to a table, and archive the CSV.

    :param file_dict: A dictionary containing information about the CSV file. Expected keys include:
        - "filename" (str): The name of the CSV file.
        - "filepath" (str): The full path to the CSV file.
        - "fileprefix" (str): The prefix of the file.
        - "filekey" (str): The key for the file in the storage system.
        - "filemode" (str): Indicates whether the file is processed as 'FULL' or 'DELTA'.
        - "tablename" (str): The destination table name for writing data.
        - "timestamp" (str): The timestamp for the file extraction.
    :type file_dict: dict

    :param file_expected_cols: A list of columns that are expected to be present in the CSV file.
    :type file_expected_cols: List[str]

    :param input_table_primary_key_columns: A string containing the primary key columns for the table,
        which must uniquely identify a row.
    :type input_table_primary_key_columns: str

    :param input_table_notnull_columns: A string containing the columns that must not be null in the table.
    :type input_table_notnull_columns: str

    :param file_csv_field_delimiter: The field delimiter used in the CSV file (e.g., ',' or ';').
    :type file_csv_field_delimiter: str

    :param sql_id_generator: An expression used to generate the ID column "_meta_ID".
    :type sql_id_generator: str

    :param output_table_path: The path where the transformed table should be written.
    :type output_table_path: str

    :param schema_version_number: The schema version number for the destination table.
    :type schema_version_number: str

    :return: None
    :rtype: None
    """

    global is_error_detected
    global file_error_list
    global table_error_list

    startTime = time.time()

    # Get file attributes from dict
    file_name = file_dict["filename"].strip()
    file_path = file_dict["filepath"].strip()
    file_mode = file_dict["filemode"].strip()
    file_modification_timestamp = file_dict["timestamp"]
    dirprefix = file_dict["dirprefix"].strip()
    dirprefix = f"{dirprefix}/"
    archive_file_dir = dirprefix.replace(BUCKET_NAME, ARCHIVE_BUCKET_NAME).replace(
        "/active/", "/"
    )
    archive_file_dir = f"archive/{archive_file_dir}SCHEMA_{schema_version_number}/"

    log.info(f"--------\nProcessing file {file_name}.\n--------\n")
    log.debug(f"--------\ndirprefix {dirprefix}.\n--------\n")
    log.debug(f"--------\narchive_file_dir {archive_file_dir}.\n--------\n")
    log.debug(f"--------\nsql_id_generator {sql_id_generator}.\n--------\n")
    log.debug(f"--------\nschema_version_number {schema_version_number}.\n--------\n")

    # Read CSV file
    df_raw = (
        spark.read.option("multiLine", "true")
        .option("delimiter", file_csv_field_delimiter)
        .option("header", True)
        .option("escape", '"')
        .option("inferSchema", "false")
        .option("nullValue", "")
        .csv(file_path)
    )

    # Cleanup column names
    columns = df_raw.columns
    for column in columns:
        df_raw = df_raw.withColumnRenamed(
            column, table_utils._cleanup_column_name(column)
        )

    # Convert _meta_extraction_timestamp to format `TimestampType`
    df_raw_ets = df_raw.withColumn(
        "_meta_extraction_timestamp",
        f.to_timestamp(f.lit(file_modification_timestamp), "yyyy-MM-dd'T'HH:mm:ss'Z'"),
    )

    # Add _meta_ingestion_timestamp metadata
    df_raw_its = df_raw_ets.withColumn(
        "_meta_ingestion_timestamp", f.current_timestamp()
    )

    # Add _meta_file_name metadata
    df_raw_fnam = df_raw_its.withColumn("_meta_file_name", f.lit(file_name))

    # Add _meta_file_mode metadata
    df_raw_fmod = df_raw_fnam.withColumn("_meta_file_mode", f.lit(file_mode))

    # Add _meta_file_path metadata
    df_raw_fpath = df_raw_fmod.withColumn("_meta_file_path", f.lit(file_path))

    # Prepare metadatas columns for reordering
    metadatas = []
    if "Id" in df_raw_fpath.columns:
        metadatas.append("Id")
    else:
        if sql_id_generator is not None:
            df_raw_fpath = df_raw_fpath.withColumn("_meta_ID", f.expr(sql_id_generator))
        else:
            df_raw_fpath = df_raw_fpath.withColumn("_meta_ID", f.lit(None))
        metadatas.append("_meta_ID")

    metadatas.extend(
        [
            "_meta_extraction_timestamp",
            "_meta_ingestion_timestamp",
            "_meta_file_name",
            "_meta_file_mode",
            "_meta_file_path",
        ]
    )
    # Prepare datas columns for reordering
    datas = [col for col in df_raw_fpath.columns if col not in metadatas]

    # Reorder columns
    df_reordered = df_raw_fpath.select(*(metadatas + datas))

    # Convert all columns containing timestamps, from type string to type to timestamp
    date_cols = [
        cname
        for cname, dtype in df_reordered.dtypes
        if dtype == "string" and ("_date" in cname.lower())
    ]
    for cname in date_cols:
        df_reordered = df_reordered.withColumn(
            cname,
            f.when(
                f.length(cname) == 8, f.to_date(cname, "yyyyMMdd")
            )  # Format yyyymmdd
            .when(
                (f.length(cname) == 10) & (f.col(cname).contains("-")),
                f.to_date(cname, "yyyy-MM-dd"),
            )  # Format yyyy-MM-dd
            .when(
                (f.length(cname) == 10) & (f.col(cname).contains("/")),
                f.to_date(cname, "dd/MM/yyyy"),
            )  # Format dd/MM/yyyy
            .when(f.length(cname) >= 19, f.to_date(cname, "yyyy-MM-dd HH:mm:ss.SSSSSS"))
            .otherwise(f.lit(None)),  # Optionnel : pour gérer les cas inattendus
        )

    # Convert all columns containing timestamps, from type string to type to timestamp
    timestamp_cols = [
        cname
        for cname, dtype in df_reordered.dtypes
        if dtype == "string"
        and (
            "_time" in cname.lower()
            or "timestamp" in cname.lower()
            or cname in ("Created", "Modified", "Creation", "Modification")
        )
    ]
    for cname in timestamp_cols:
        df_reordered = df_reordered.withColumn(
            cname,
            f.when(
                f.length(cname) == 8, f.to_timestamp(cname, "yyyyMMdd")
            )  # Format yyyyMMdd
            .when(
                f.length(cname) == 10, f.to_timestamp(cname, "yyyy-MM-dd")
            )  # Format yyyy-MM-dd
            .when(
                f.length(cname) == 20, f.to_timestamp(cname, "yyyy-MM-dd'T'HH:mm:ss'Z'")
            )  # Format ISO 8601
            .otherwise(f.lit(None)),  # Other cases
        )

    # Convert all columns empty to null
    string_cols = [cname for cname, dtype in df_reordered.dtypes if dtype == "string"]
    for cname in string_cols:
        df_reordered = df_reordered.withColumn(
            cname,
            f.when(f.trim(f.col(cname)) == "", None).otherwise(f.col(cname)),
        )

    # Convert all primary key columns to string type
    primary_key_columns_list = input_table_primary_key_columns.split(",")
    for cname in primary_key_columns_list:
        df_reordered = df_reordered.withColumn(cname, f.col(cname).cast("string"))

    # Check requested columns
    all_req_columns = all(col in df_reordered.columns for col in file_expected_cols)
    if all_req_columns:
        log.info(f"Expected columns all OK : {file_expected_cols}")
    else:
        missing_cols = [
            col for col in file_expected_cols if col not in df_reordered.columns
        ]
        log.error(
            f"Table {table_name} has not expected columns: \n missing columns : {missing_cols} \n actual columns : {df_reordered.columns}"
        )
        file_error_list.append(file_path)
        is_error_detected = True
        return None

    # Quality checks with great_expectations : uniqueness for input_table_primary_key_columns and notnull for input_table_notnull_columns
    # Raise an Exception if not pass the checks
    if (input_table_primary_key_columns) and (input_table_primary_key_columns != ""):
        gx_validation.gx_check_compound_uniqueness(
            df=df_raw,
            cols=input_table_primary_key_columns,
            validation_level="RED",
            pipeline_write_env=PIPELINE_WRITE_ENV,
            table_name="hr_referential_bronze",
        )

    notnull_columns = input_table_notnull_columns.split(",")
    for one_col in notnull_columns:
        gx_validation.gx_check_not_null(
            df=df_raw,
            col=one_col.strip(),
            validation_level="RED",
            pipeline_write_env=PIPELINE_WRITE_ENV,
            table_name="hr_referential_bronze",
        )

    # Check if _meta_extraction_timestamp already exists to avoid duplicates and if yes delete previous _meta_extraction_timestamp
    try:
        df_table_stack = spark.read.table(output_table_path)
        is_extraction_timestamp_existing = df_table_stack.filter(
            f.col("_meta_extraction_timestamp") == f.lit(file_modification_timestamp)
        ).first()
        if is_extraction_timestamp_existing:
            spark.sql(
                f"""DELETE FROM {output_table_path} WHERE _meta_extraction_timestamp = '{file_modification_timestamp}' """
            )
    except AnalysisException as e:
        log.error(
            f"Table {output_table_path} has not been created, an error occured during deletion of an already existing timestamp {file_modification_timestamp}."
        )
        file_error_list.append(file_path)
        is_error_detected = True
        return None

    # write csv to table
    # Append the stack table with Dataframe df_reordered
    try:
        result = table_utils.save_table(
            dest_table=output_table_path,
            df=df_reordered,
            mode="append",
            overwrite_schema=False,
            partition_col="_meta_extraction_timestamp",
            merge_schema=True,
        )
    except AnalysisException as e:
        log.error(
            f"Table {output_table_path} has not been saved, an error occured during creation.\nException is :{e}\n"
        )
        file_error_list.append(file_path)
        is_error_detected = True
        return None

    duration = time.time() - startTime
    log.info(
        f"--------\nData from file {file_name} has been written to Delta Lake table {output_table_path} in {duration} seconds.\n--------\n"
    )

    status = files_utils.archive_file(
        BUCKET_NAME,
        dirprefix,
        ARCHIVE_BUCKET_NAME,
        archive_file_dir,
        file_name,
    )


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : process_one_parquet_file
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to load one parquet file, write stack table and add primary key.
# MAGIC
# MAGIC **How to call:**
# MAGIC process_one_parquet_file(files_dict, file_expected_cols, input_table_primary_key_columns, input_table_notnull_columns, sql_id_generator, output_table_path, schema_version_number )
# MAGIC
# MAGIC **Output:**
# MAGIC - file_name if OK
# MAGIC - None if ERROR

# COMMAND ----------


def process_one_parquet_file(
    file_dict: dict,
    file_expected_cols: List[str],
    input_table_primary_key_columns: str,
    input_table_notnull_columns: str,
    sql_id_generator: str,
    output_table_path: str,
    schema_version_number: str,
):
    """
    Process one Parquet file at a time: read the file, transform it, write to a table, and archive the file.

    :param file_dict: A dictionary containing information about the file. Expected keys include:
        - "filename" (str): The name of the file.
        - "filepath" (str): The full path to the file.
        - "fileprefix" (str): The prefix of the file.
        - "filekey" (str): The key for the file in the storage system.
        - "filemode" (str): Indicates whether the file is processed as 'FULL' or 'DELTA'.
        - "tablename" (str): The destination table name for writing data.
        - "timestamp" (str): The timestamp for the file extraction.
    :type file_dict: dict

    :param file_expected_cols: A list of columns that are expected to be present in the file.
    :type file_expected_cols: List[str]

    :param input_table_primary_key_columns: A string containing the primary key columns for the table,
        which must uniquely identify a row.
    :type input_table_primary_key_columns: str

    :param input_table_notnull_columns: A string containing the columns that must not be null in the table.
    :type input_table_notnull_columns: str

    :param sql_id_generator: An expression used to generate the ID column "_meta_ID".
    :type sql_id_generator: str

    :param output_table_path: The path where the transformed table should be written.
    :type output_table_path: str

    :param schema_version_number: The schema version number for the destination table.
    :type schema_version_number: str

    :return: None
    :rtype: None
    """

    global is_error_detected
    global file_error_list
    global table_error_list

    startTime = time.time()

    # Get file attributes from dict
    file_name = file_dict["filename"].strip()
    file_path = file_dict["filepath"].strip()
    file_mode = file_dict["filemode"].strip()
    file_modification_timestamp = file_dict["timestamp"]
    dirprefix = file_dict["dirprefix"].strip()
    dirprefix = f"{dirprefix}/"
    archive_file_dir = dirprefix.replace(BUCKET_NAME, ARCHIVE_BUCKET_NAME).replace(
        "/active/", "/"
    )
    archive_file_dir = f"archive/{archive_file_dir}SCHEMA_{schema_version_number}/"

    log.info(f"--------\nProcessing file {file_name}.\n--------\n")
    log.debug(f"--------\ndirprefix {dirprefix}.\n--------\n")
    log.debug(f"--------\narchive_file_dir {archive_file_dir}.\n--------\n")
    log.debug(f"--------\nsql_id_generator {sql_id_generator}.\n--------\n")
    log.debug(f"--------\nschema_version_number {schema_version_number}.\n--------\n")

    # Read PARQUET file
    df_raw = spark.read.option("inferSchema", "false").parquet(file_path)

    # Cleanup column names
    columns = df_raw.columns
    for column in columns:
        df_raw = df_raw.withColumnRenamed(
            column, table_utils._cleanup_column_name(column)
        )

    # Convert _meta_extraction_timestamp to format `TimestampType`
    df_raw_ets = df_raw.withColumn(
        "_meta_extraction_timestamp",
        f.to_timestamp(f.lit(file_modification_timestamp), "yyyy-MM-dd'T'HH:mm:ss'Z'"),
    )

    # Add _meta_ingestion_timestamp metadata
    df_raw_its = df_raw_ets.withColumn(
        "_meta_ingestion_timestamp", f.current_timestamp()
    )

    # Add _meta_file_name metadata
    df_raw_fnam = df_raw_its.withColumn("_meta_file_name", f.lit(file_name))

    # Add _meta_file_mode metadata
    df_raw_fmod = df_raw_fnam.withColumn("_meta_file_mode", f.lit(file_mode))

    # Add _meta_file_path metadata
    df_raw_fpath = df_raw_fmod.withColumn("_meta_file_path", f.lit(file_path))

    # Prepare metadatas columns for reordering
    metadatas = []
    if "Id" in df_raw_fpath.columns:
        metadatas.append("Id")
    else:
        if sql_id_generator is not None:
            df_raw_fpath = df_raw_fpath.withColumn("_meta_ID", f.expr(sql_id_generator))
        else:
            df_raw_fpath = df_raw_fpath.withColumn("_meta_ID", f.lit(None))
        metadatas.append("_meta_ID")

    metadatas.extend(
        [
            "_meta_extraction_timestamp",
            "_meta_ingestion_timestamp",
            "_meta_file_name",
            "_meta_file_mode",
            "_meta_file_path",
        ]
    )
    # Prepare datas columns for reordering
    datas = [col for col in df_raw_fpath.columns if col not in metadatas]

    # Reorder columns
    df_reordered = df_raw_fpath.select(*(metadatas + datas))

    # Convert all columns containing timestamps, from type string to type to timestamp
    date_cols = [
        cname
        for cname, dtype in df_reordered.dtypes
        if dtype == "string" and ("_date" in cname.lower())
    ]
    for cname in date_cols:
        df_reordered = df_reordered.withColumn(
            cname,
            f.when(
                f.length(cname) == 8, f.to_date(cname, "yyyyMMdd")
            )  # Format yyyymmdd
            .when(f.length(cname) == 10, f.to_date(cname, "yyyy-MM-dd"))
            .when(f.length(cname) >= 19, f.to_date(cname, "yyyy-MM-dd HH:mm:ss.SSSSSS"))
            .otherwise(f.lit(None)),  # Optionnel : pour gérer les cas inattendus
        )

    # Convert all columns containing timestamps, from type string to type to timestamp
    timestamp_cols = [
        cname
        for cname, dtype in df_reordered.dtypes
        if dtype == "string"
        and (
            "_time" in cname.lower()
            or "timestamp" in cname.lower()
            or cname in ("Created", "Modified", "Creation", "Modification")
        )
    ]
    for cname in timestamp_cols:
        df_reordered = df_reordered.withColumn(
            cname,
            f.when(
                f.length(cname) == 8, f.to_timestamp(cname, "yyyyMMdd")
            )  # Format yyyyMMdd
            .when(
                f.length(cname) == 10, f.to_timestamp(cname, "yyyy-MM-dd")
            )  # Format yyyy-MM-dd
            .when(
                f.length(cname) == 20, f.to_timestamp(cname, "yyyy-MM-dd'T'HH:mm:ss'Z'")
            )  # Format ISO 8601
            .otherwise(f.lit(None)),  # Optionnel : pour gérer les cas inattendus
        )

    # Convert all columns empty to null
    string_cols = [cname for cname, dtype in df_reordered.dtypes if dtype == "string"]
    for cname in string_cols:
        df_reordered = df_reordered.withColumn(
            cname,
            f.when(f.trim(f.col(cname)) == "", None).otherwise(f.col(cname)),
        )

    # Convert all primary key columns to string type
    primary_key_columns_list = input_table_primary_key_columns.split(",")
    for cname in primary_key_columns_list:
        df_reordered = df_reordered.withColumn(cname, f.col(cname).cast("string"))

    # Check requested columns
    all_req_columns = all(col in df_reordered.columns for col in file_expected_cols)
    if all_req_columns:
        log.info(f"Expected columns all OK : {file_expected_cols}")
    else:
        missing_cols = [
            col for col in file_expected_cols if col not in df_reordered.columns
        ]
        log.error(
            f"Table {table_name} has not expected columns: \n missing columns : {missing_cols} \n actual columns : {df_reordered.columns}"
        )
        df_reordered.printSchema()
        file_error_list.append(file_path)
        is_error_detected = True
        return None

    # Quality checks with great_expectations : uniqueness for input_table_primary_key_columns and notnull for input_table_notnull_columns
    # Raise an Exception if not pass the checks
    if (input_table_primary_key_columns) and (input_table_primary_key_columns != ""):
        gx_validation.gx_check_compound_uniqueness(
            df=df_raw,
            cols=input_table_primary_key_columns,
            validation_level="RED",
            pipeline_write_env=PIPELINE_WRITE_ENV,
            table_name="hr_referential_bronze",
        )

    notnull_columns = input_table_notnull_columns.split(",")
    for one_col in notnull_columns:
        gx_validation.gx_check_not_null(
            df=df_raw,
            col=one_col.strip(),
            validation_level="RED",
            pipeline_write_env=PIPELINE_WRITE_ENV,
            table_name="hr_referential_bronze",
        )

    # Check if _meta_extraction_timestamp already exists to avoid duplicates and if yes delete previous _meta_extraction_timestamp
    try:
        df_table_stack = spark.read.table(output_table_path)
        is_extraction_timestamp_existing = df_table_stack.filter(
            f.col("_meta_extraction_timestamp") == f.lit(file_modification_timestamp)
        ).first()
        if is_extraction_timestamp_existing:
            spark.sql(
                f"""DELETE FROM {output_table_path} WHERE _meta_extraction_timestamp = '{file_modification_timestamp}' """
            )
    except AnalysisException as e:
        log.error(
            f"Table {output_table_path} has not been created, an error occured during deletion of an already existing timestamp {file_modification_timestamp}."
        )
        file_error_list.append(file_path)
        is_error_detected = True
        return None

    # write parquet file to table
    # Append the stack table with Dataframe df_reordered
    try:
        result = table_utils.save_table(
            dest_table=output_table_path,
            df=df_reordered,
            mode="append",
            overwrite_schema=False,
            partition_col="_meta_extraction_timestamp",
            merge_schema=True,
        )
    except AnalysisException as e:
        log.error(
            f"Table {output_table_path} has not been saved, an error occured during creation.\nException is :{e}\n"
        )
        file_error_list.append(file_path)
        is_error_detected = True
        return None

    duration = time.time() - startTime
    log.info(
        f"--------\nData from file {file_name} has been written to Delta Lake table {output_table_path} in {duration} seconds.\n--------\n"
    )

    status = files_utils.archive_file(
        BUCKET_NAME,
        dirprefix,
        ARCHIVE_BUCKET_NAME,
        archive_file_dir,
        file_name,
    )

    return file_name


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : process_all_csv_files_for_one_table
# MAGIC
# MAGIC **Description:**
# MAGIC - The aim is to load all CSV files in files_dict_list, write stack tables and add primary key.
# MAGIC - For each file check if schema has changed, if no ingest file and archive, if yes rename stack table, create new stack table, ingest file and archive
# MAGIC
# MAGIC **How to call:**
# MAGIC process_all_csv_files_for_one_table(files_dict_list, file_expected_cols, input_table_name, input_table_primary_key_columns, input_table_notnull_columns, file_csv_field_delimiter )
# MAGIC
# MAGIC **Output:**
# MAGIC - None
# MAGIC
# MAGIC **Globals**
# MAGIC - is_error_detected
# MAGIC - file_error_list
# MAGIC - table_error_list

# COMMAND ----------


def process_all_csv_files_for_one_table(
    files_dict_list: List[dict],
    file_expected_cols: List[str],
    input_table_name: str,
    input_table_primary_key_columns: str,
    input_table_notnull_columns: str,
    file_csv_field_delimiter: str,
):
    """
    Process each file in the list of dictionaries, reading CSV files and writing them to corresponding delta tables.

    :param files_dict_list: A list of dictionaries where each dictionary contains the following expected keys:
        - "filename" (str): The name of the file (e.g., '20240910_150600_REPORT_RH_LEAP.csv').
        - "filepath" (str): The path to the file (e.g., 's3://leap-s3-raw-sd-lat-dev/apps/hr/20240910_150600_REPORT_RH_LEAP.csv').
        - "fileprefix" (str): The prefix of the file (e.g., 'v_report_rh_leap').
        - "filekey" (str): The key of the file in the storage (e.g., 'apps/hr/20240910_150600_REPORT_RH_LEAP.csv').
        - "dirprefix" (str): The directory prefix (e.g., 'apps/hr/').
        - "filemode" (str): Either 'FULL' or 'DELTA'.
        - "tablename" (str): The name of the bronze table (e.g., 'v_report_rh_leap').
        - "timestamp" (str): The extraction timestamp (e.g., '2024-02-22T10:16:20Z').
    :type files_dict_list: List[dict]

    :param file_expected_cols: A list of column names expected in the file.
    :type file_expected_cols: List[str]

    :param input_table_name: The name of the table to process.
    :type input_table_name: str

    :param input_table_primary_key_columns: A string containing the primary key columns for the table.
    :type input_table_primary_key_columns: str

    :param input_table_notnull_columns: A string containing the columns that should not contain null values.
    :type input_table_notnull_columns: str

    :param file_csv_field_delimiter: The field delimiter used in the CSV file.
    :type file_csv_field_delimiter: str

    :return: None
    :rtype: None
    """

    global is_error_detected
    global file_error_list
    global table_error_list

    spark.conf.set("spark.sql.legacy.parseDoublesAsDecimal", False)
    spark.conf.set("spark.sql.legacy.multiLine", True)
    spark.conf.set("spark.sql.legacy.wholeFile", True)
    log.info(f"--------\nProcessing table {input_table_name}.\n--------\n")

    table_name = input_table_name + "_stack"
    # output table in Databricks Unity Catalog
    output_table_path = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}"
    output_table_path = output_table_path.strip().lower()

    # Generate "ID" field by joining 'table_keys' columns with '-'.
    if (input_table_primary_key_columns) and (input_table_primary_key_columns != ""):
        id_columns = ", ".join(
            f"IF(coalesce(rtrim(`{column}`),'')='', NULL, rtrim(`{column}`))"
            for column in input_table_primary_key_columns.replace(" ", "").split(",")
        )
        sql_id_generator = f"concat_ws('-', {id_columns})"
    else:
        sql_id_generator = None

    # Generate metadata statement for COPY INTO wrapper
    if (input_table_primary_key_columns) and (input_table_primary_key_columns != ""):
        metadata_statement = [
            (f"{sql_id_generator} AS _meta_ID", "STRING"),
        ]
    else:
        metadata_statement = [
            ("lit(None) AS _meta_ID", "STRING"),
        ]
    metadata_statement = metadata_statement + [
        (
            "to_timestamp(concat(split_part(_metadata.file_name, '_', 1), split_part(_metadata.file_name, '_', 2)), 'yyyyMMddHHmmss') AS _meta_extraction_timestamp",
            "TIMESTAMP",
        ),
        ("current_timestamp() AS _meta_ingestion_timestamp", "TIMESTAMP"),
        ("_metadata.file_name AS _meta_file_name", "STRING"),
        (
            "CASE WHEN split_part(split_part(_metadata.file_name, '_', 3), '-', 2) = 'F' THEN 'FULL' ELSE 'DELTA' END AS _meta_file_mode",
            "STRING",
        ),
        ("_metadata.file_path AS _meta_file_path", "STRING"),
    ]
    metadata_info = [
        (f"{entry.split(' AS ')[1]}", f"{data_type}")
        for entry, data_type in metadata_statement
    ]

    format_options = {
        "header": "True",
        "delimiter": ";",
        "mode": "PERMISSIVE",
        "escape": '"',
        "quote": '"',
    }

    # If table already exists, catch the schema of the existing table, except fields _meta* and name it old_schema
    if table_utils.UnityCatalogCheckTableExists(output_table_path):
        old_schema = spark.read.table(output_table_path).columns
        old_schema = [col for col in old_schema if not col.startswith("_meta")]
    else:
        old_schema = None

    # For all new files catch the schema and append it to new_schemas, separate files in 2 lists :  files_dict_list_same_schema and files_dict_list_new_schema
    files_dict_list_same_schema = []
    files_dict_list_new_schema = []
    reference_schema = old_schema
    for file_dict in files_dict_list:
        s3_path_base = file_dict["filepath"].strip()
        s3_file_name = file_dict["filename"].strip()
        try:
            new_schema = spark.read.csv(
                s3_path_base, header=True, sep=file_csv_field_delimiter
            ).columns
            log.debug(f"Schema for {s3_path_base} is {new_schema}")
            if reference_schema:
                if is_same_schema(
                    old_schema=reference_schema,
                    new_schema=new_schema,
                    metadata_info=metadata_info,
                ):
                    files_dict_list_same_schema.append(file_dict)
                    lets_continue = True
                    log.info(
                        f"{s3_file_name} : is same schema, will ingest new file as current schema."
                    )
                else:
                    files_dict_list_new_schema.append(file_dict)
                    lets_continue = True
                    log.info(
                        f"{s3_file_name} : is different schema, will process new file separately."
                    )
            else:
                lets_continue = True  # Table does not exists, create it
                reference_schema = new_schema
                files_dict_list_same_schema.append(file_dict)
                log.info(
                    f"{s3_file_name} : old schema is empty, will ingest new file as new schema."
                )

        except Exception as e:
            log.error(f"Error reading file {s3_path_base}: {e}")
            files_dict_list_new_schema.append(file_info)

    # Get last schema number based on last archived folder
    path_base = files_dict_list[0]["dirprefix"]
    archive_file_dir = f"s3://{ARCHIVE_BUCKET_NAME}/archive/{path_base}/"
    archive_file_dir = archive_file_dir.replace("/active/", "/")
    schema_version_number = files_utils.get_last_schema_version(archive_file_dir)

    # If table does not exists or force_reinitialization is True, create it with first columns specially for the _meta_stack_row_id
    if not create_or_replace_initial_stack_table(table_name):
        table_error_list.append(table_name)
        is_error_detected = True
        return None

    # Loop through the files with same schema than stack table and ingest, then archive
    for file_dict in files_dict_list_same_schema:
        s3_file_name = file_dict["filename"].strip()
        log.info(f"Ingesting file {s3_file_name}.")
        process_one_csv_file(
            file_dict=file_dict,
            file_expected_cols=file_expected_cols,
            input_table_primary_key_columns=input_table_primary_key_columns,
            input_table_notnull_columns=input_table_notnull_columns,
            file_csv_field_delimiter=file_csv_field_delimiter,
            sql_id_generator=sql_id_generator,
            output_table_path=output_table_path,
            schema_version_number=schema_version_number,
        )

    # Loop through the files with new schema, rename current stack table, create new table, ingest and archive
    # Process other files checking each time if it is new schema different from previous one
    for file_dict in files_dict_list_new_schema:
        s3_path_base = file_dict["filepath"].strip()
        s3_file_name = file_dict["filename"].strip()
        new_schema = spark.read.csv(
            s3_path_base, header=True, sep=file_csv_field_delimiter
        ).columns
        log.debug(f"Schema for {s3_file_name} is {new_schema}")
        if not is_same_schema(
            old_schema=reference_schema,
            new_schema=new_schema,
            metadata_info=metadata_info,
        ):
            if FORCE_NEW_SCHEMA:
                lets_continue = True
                log.info(f"Ingesting file {s3_file_name}.")
                log.info(
                    "Old and New schemas are different and FORCE_NEW_SCHEMA is True, ingesting new file as a new schema. "
                )
                try:
                    # move stack to stack_{n} in landing_zone
                    spark.sql(
                        f"ALTER TABLE {output_table_path} RENAME TO {output_table_path}_{schema_version_number}"
                    )
                except:
                    log.error(
                        f"Table {output_table_path} has not been renamed to {output_table_path}_{schema_version_number}, an error occured."
                    )
                    table_error_list.append(table_name)
                    is_error_detected = True
                    return None
                else:
                    log.info(
                        f"Table {output_table_path} has been renamed to {output_table_path}_{schema_version_number}, cause new schema detected."
                    )
                    schema_version_number = schema_version_number + 1
            else:  # raise an exception with detail on differences
                strings_to_remove = {item[0] for item in metadata_info}
                new_schema_cleaned = [
                    table_utils._cleanup_column_name(item) for item in new_schema
                ]
                removed_items = set(reference_schema).difference(
                    strings_to_remove
                ) - set(new_schema_cleaned)
                added_items = set(new_schema_cleaned) - set(
                    reference_schema
                ).difference(strings_to_remove)
                raise AssertionError(
                    f"""
        Schema are not the same, here is the list of different column : \n
        Columns removed in new schema : {removed_items}  \n
        Columns added in new schema : {added_items} 
                                """
                )

        # If table does not exists, create it with first columns specially for the _meta_stack_row_id
        if not create_or_replace_initial_stack_table(table_name):
            table_error_list.append(table_name)
            is_error_detected = True
            return None

        process_one_csv_file(
            file_dict=file_dict,
            file_expected_cols=file_expected_cols,
            input_table_primary_key_columns=input_table_primary_key_columns,
            input_table_notnull_columns=input_table_notnull_columns,
            file_csv_field_delimiter=file_csv_field_delimiter,
            sql_id_generator=sql_id_generator,
            output_table_path=output_table_path,
            schema_version_number=schema_version_number,
        )
        reference_schema = spark.read.table(output_table_path).columns
        reference_schema = [
            col for col in reference_schema if not col.startswith("_meta")
        ]


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : process_all_parquet_files_for_one_table
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to load parquet files, write stack tables and add primary key.
# MAGIC
# MAGIC **How to call:**
# MAGIC process_all_parquet_files_for_one_table(files_dict_list, file_expected_cols, input_table_name, input_table_primary_key_columns, input_table_notnull_columns )
# MAGIC
# MAGIC **Output:**
# MAGIC - None
# MAGIC
# MAGIC **Globals**
# MAGIC - is_error_detected
# MAGIC - file_error_list
# MAGIC - table_error_list

# COMMAND ----------


def process_all_parquet_files_for_one_table(
    files_dict_list: List[dict],
    file_expected_cols: List[str],
    input_table_name: str,
    input_table_primary_key_columns: str,
    input_table_notnull_columns: str,
):
    """
    Process each file in the list of dictionaries, reading parquet files and writing them to corresponding delta tables.

    :param files_dict_list: A list of dictionaries where each dictionary contains the following expected keys:
        - "filename" (str): The name of the file (e.g., '20240910_150600_REPORT_RH_LEAP.parquet').
        - "filepath" (str): The path to the file (e.g., 's3://leap-s3-raw-sd-lat-dev/apps/hr/20240910_150600_REPORT_RH_LEAP.parquet').
        - "fileprefix" (str): The prefix of the file (e.g., 'v_report_rh_leap').
        - "filekey" (str): The key of the file in the storage (e.g., 'apps/hr/20240910_150600_REPORT_RH_LEAP.parquet').
        - "dirprefix" (str): The directory prefix (e.g., 'apps/hr/').
        - "filemode" (str): Either 'FULL' or 'DELTA'.
        - "tablename" (str): The name of the bronze table (e.g., 'v_report_rh_leap').
        - "timestamp" (str): The extraction timestamp (e.g., '2024-02-22T10:16:20Z').
    :type files_dict_list: List[dict]

    :param file_expected_cols: A list of column names expected in the file.
    :type file_expected_cols: List[str]

    :param input_table_name: The name of the table to process.
    :type input_table_name: str

    :param input_table_primary_key_columns: A string containing the primary key columns for the table.
    :type input_table_primary_key_columns: str

    :param input_table_notnull_columns: A string containing the columns that should not contain null values.
    :type input_table_notnull_columns: str

    :return: None
    :rtype: None
    """

    global is_error_detected
    global file_error_list
    global table_error_list

    spark.conf.set("spark.sql.legacy.parseDoublesAsDecimal", False)
    spark.conf.set("spark.sql.legacy.multiLine", True)
    spark.conf.set("spark.sql.legacy.wholeFile", True)
    log.info(f"--------\nProcessing table {input_table_name}.\n--------\n")

    table_name = input_table_name + "_stack"
    # output table in Databricks Unity Catalog
    output_table_path = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}"
    output_table_path = output_table_path.strip().lower()

    # Generate "ID" field by joining 'table_keys' columns with '-'.
    if (input_table_primary_key_columns) and (input_table_primary_key_columns != ""):
        id_columns = ", ".join(
            f"IF(coalesce(rtrim(`{column}`),'')='', NULL, rtrim(`{column}`))"
            for column in input_table_primary_key_columns.replace(" ", "").split(",")
        )
        sql_id_generator = f"concat_ws('-', {id_columns})"
    else:
        sql_id_generator = None

    # Generate metadata statement for COPY INTO wrapper
    if (input_table_primary_key_columns) and (input_table_primary_key_columns != ""):
        metadata_statement = [
            (f"{sql_id_generator} AS _meta_ID", "STRING"),
        ]
    else:
        metadata_statement = [
            ("lit(None) AS _meta_ID", "STRING"),
        ]
    metadata_statement = metadata_statement + [
        (
            "to_timestamp(concat(split_part(_metadata.file_name, '_', 1), split_part(_metadata.file_name, '_', 2)), 'yyyyMMddHHmmss') AS _meta_extraction_timestamp",
            "TIMESTAMP",
        ),
        ("current_timestamp() AS _meta_ingestion_timestamp", "TIMESTAMP"),
        ("_metadata.file_name AS _meta_file_name", "STRING"),
        (
            "CASE WHEN split_part(split_part(_metadata.file_name, '_', 3), '-', 2) = 'F' THEN 'FULL' ELSE 'DELTA' END AS _meta_file_mode",
            "STRING",
        ),
        ("_metadata.file_path AS _meta_file_path", "STRING"),
    ]
    metadata_info = [
        (f"{entry.split(' AS ')[1]}", f"{data_type}")
        for entry, data_type in metadata_statement
    ]

    format_options = {
        "header": "True",
        "delimiter": ";",
        "mode": "PERMISSIVE",
        "escape": '"',
        "quote": '"',
    }

    # If table already exists, catch the schema of the existing table, except fields _meta* and name it old_schema
    if table_utils.UnityCatalogCheckTableExists(output_table_path):
        old_schema = spark.read.table(output_table_path).columns
        old_schema = [col for col in old_schema if not col.startswith("_meta")]
    else:
        old_schema = None

    # For all new files catch the schema and append it to new_schemas, separate files in 2 lists :  files_dict_list_same_schema and files_dict_list_new_schema
    files_dict_list_same_schema = []
    files_dict_list_new_schema = []
    reference_schema = old_schema
    for file_dict in files_dict_list:
        s3_path_base = file_dict["filepath"].strip()
        s3_file_name = file_dict["filename"].strip()
        try:
            new_schema = spark.read.parquet(s3_path_base).columns
            log.debug(f"Schema for {s3_path_base} is {new_schema}")
            if reference_schema:
                if is_same_schema(
                    old_schema=reference_schema,
                    new_schema=new_schema,
                    metadata_info=metadata_info,
                ):
                    files_dict_list_same_schema.append(file_dict)
                    lets_continue = True
                    log.info(
                        f"{s3_file_name} : is same schema, will ingest new file as current schema."
                    )
                else:
                    files_dict_list_new_schema.append(file_dict)
                    lets_continue = True
                    log.info(
                        f"{s3_file_name} : is different schema, will process new file separately."
                    )
            else:
                lets_continue = True  # Table does not exists, create it
                log.info(
                    f"{s3_file_name} : old schema is empty, will ingest new file as new schema."
                )

        except Exception as e:
            log.error(f"Error reading file {s3_path_base}: {e}")
            files_dict_list_new_schema.append(file_info)

    # Get last schema number based on last archived folder
    path_base = files_dict_list[0]["dirprefix"]
    archive_file_dir = f"s3://{ARCHIVE_BUCKET_NAME}/archive/{path_base}/"
    archive_file_dir = archive_file_dir.replace("/active/", "/")
    schema_version_number = files_utils.get_last_schema_version(archive_file_dir)

    # If table does not exists or force_reinitialization is True, create it with first columns specially for the _meta_stack_row_id
    if not create_or_replace_initial_stack_table(table_name):
        table_error_list.append(table_name)
        is_error_detected = True
        return None

    # Loop through the files with same schema than stack table and ingest, then archive
    for file_dict in files_dict_list_same_schema:
        s3_file_name = file_dict["filename"].strip()
        log.info(f"Ingesting file {s3_file_name}.")
        process_one_parquet_file(
            file_dict=file_dict,
            file_expected_cols=file_expected_cols,
            input_table_primary_key_columns=input_table_primary_key_columns,
            input_table_notnull_columns=input_table_notnull_columns,
            sql_id_generator=sql_id_generator,
            output_table_path=output_table_path,
            schema_version_number=schema_version_number,
        )

    # Loop through the files with new schema, rename current stack table, create new table, ingest and archive
    # Process other files checking each time if it is new schema different from previous one
    for file_dict in files_dict_list_new_schema:
        s3_path_base = file_dict["filepath"].strip()
        s3_file_name = file_dict["filename"].strip()
        new_schema = spark.read.parquet(s3_path_base).columns
        log.debug(f"Schema for {s3_file_name} is {new_schema}")
        if not is_same_schema(
            old_schema=reference_schema,
            new_schema=new_schema,
            metadata_info=metadata_info,
        ):
            if FORCE_NEW_SCHEMA:
                lets_continue = True
                log.info(f"Ingesting file {s3_file_name}.")
                log.info(
                    "Old and New schemas are different and FORCE_NEW_SCHEMA is True, ingesting new file as a new schema. "
                )
                try:
                    # move stack to stack_{n} in landing_zone
                    spark.sql(
                        f"ALTER TABLE {output_table_path} RENAME TO {output_table_path}_{schema_version_number}"
                    )
                except:
                    log.error(
                        f"Table {output_table_path} has not been renamed to {output_table_path}_{schema_version_number}, an error occured."
                    )
                    table_error_list.append(table_name)
                    is_error_detected = True
                    return None
                else:
                    log.info(
                        f"Table {output_table_path} has been renamed to {output_table_path}_{schema_version_number}, cause new schema detected."
                    )
                    schema_version_number = schema_version_number + 1
            else:  # raise an exception with detail on differences
                strings_to_remove = {item[0] for item in metadata_info}
                new_schema_cleaned = [
                    table_utils._cleanup_column_name(item) for item in new_schema
                ]
                removed_items = set(reference_schema).difference(
                    strings_to_remove
                ) - set(new_schema_cleaned)
                added_items = set(new_schema_cleaned) - set(
                    reference_schema
                ).difference(strings_to_remove)
                raise AssertionError(
                    f"""
        Schema are not the same, here is the list of different column : \n
        Columns removed in new schema : {removed_items}  \n
        Columns added in new schema : {added_items} 
                                """
                )

        # If table does not exists, create it with first columns specially for the _meta_stack_row_id
        if not create_or_replace_initial_stack_table(table_name):
            table_error_list.append(table_name)
            is_error_detected = True
            return None

        process_one_parquet_file(
            file_dict=file_dict,
            file_expected_cols=file_expected_cols,
            input_table_primary_key_columns=input_table_primary_key_columns,
            input_table_notnull_columns=input_table_notnull_columns,
            sql_id_generator=sql_id_generator,
            output_table_path=output_table_path,
            schema_version_number=schema_version_number,
        )

        reference_schema = spark.read.table(output_table_path).columns
        reference_schema = [
            col for col in reference_schema if not col.startswith("_meta")
        ]


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : process_view_for_stack_table
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to provide a view giving union of all stack tables.
# MAGIC
# MAGIC **How to call:**
# MAGIC process_view_for_stack_table(input_table_name)
# MAGIC
# MAGIC **Output:**
# MAGIC - None
# MAGIC
# MAGIC **Globals**
# MAGIC -  is_error_detected
# MAGIC -  table_error_list

# COMMAND ----------


def process_view_for_stack_table(
    input_table_name: str,
):
    """
    Create a bronze view of stack tables by performing a union of all stack tables.

    :param input_table_name: The name of the input table to process.
    :type input_table_name: str
    :return: None
    :rtype: None
    """
    global is_error_detected
    global table_error_list

    table_name = input_table_name + "_stack"

    # output table in Databricks Unity Catalog
    output_table_path = f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_name}"
    output_table_path = output_table_path.strip().lower()
    output_view_path = f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}"
    output_view_path = output_view_path.strip().lower()

    # Get table names from the source schema
    df_table_names = spark.sql(
        f"SHOW TABLES IN {LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}"
    )
    table_names = [
        row.tableName
        for row in df_table_names.collect()
        if row.tableName.startswith(table_name)
    ]
    if len(table_names) == 0:
        log.warning(
            f"View {output_view_path} not created, no stack table named : {input_table_name}"
        )
        return None

    if len(table_names) == 1:
        log.info(f"Creating view {output_view_path} for table : {table_names[0]}")
        select_query = f"SELECT * FROM {LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table_names[0]}"
    else:
        log.info(f"Creating view {output_view_path} for tables : {table_names}")

        # get biggest schema
        all_table_schemas = {}
        for table in table_names:
            all_table_schemas[table] = spark.table(
                f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table}"
            ).schema
        sorted_schemas = sorted(
            all_table_schemas.values(), key=lambda x: len(x), reverse=True
        )
        biggest_schema = sorted_schemas[0]

        # Generate SQL to select data from each table with adjusted schemas
        select_queries = []
        for idx, table in enumerate(table_names):
            table_schema = spark.table(
                f"{LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table}"
            ).schema
            adjusted_cols = []
            for f in biggest_schema:
                if f.name not in [col.name for col in table_schema]:
                    adjusted_cols.append(f"NULL AS {f.name}")
                elif f.name == "_meta_stack_row_id":
                    # Add unique value to _meta_stack_row_id based on table index
                    adjusted_cols.append(
                        f"concat('{idx}_', cast(_meta_stack_row_id as string)) AS _meta_stack_row_id"
                    )
                else:
                    adjusted_cols.append(f.name)
            select_query = f"SELECT {', '.join(adjusted_cols)} FROM {LANDING_ZONE_CATALOG}.{LANDING_ZONE_SCHEMA}.{table}"
            select_queries.append(select_query)

        # Concatenate select queries with UNION
        select_query = " UNION ".join(select_queries)

    # Create the database if it doesn't exist for hosting the view
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {BRONZE_CATALOG}.{BRONZE_SCHEMA}")

    # Create or replace the view using SQL in the destination schema
    try:
        # Create the table view in bronze
        view_query = f"CREATE OR REPLACE VIEW {BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name} AS {select_query}"
        spark.sql(view_query)
    except AnalysisException as e:
        log.error(
            f"View {output_view_path} has not been created, an error occured during creation.\nException is :{e}\n"
        )
        is_error_detected = True
        table_error_list.append(table_name)
        return None


# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks - Functions

# COMMAND ----------

# Defined in leap_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Files Read
# MAGIC - Build the stack tables
# MAGIC - Files Archiving

# COMMAND ----------

# MAGIC %md
# MAGIC ### MAIN1 - Stack tables Processing
# MAGIC - Read files
# MAGIC - Build the stack tables from files

# COMMAND ----------

Found = False
is_error_detected = False
file_error_list = []
table_error_list = []

# For each kind of file, search for files and process
for attr_dict in FILES_ATTRS_DICT:
    # Search in S3 for files corresponding to those prefixes {FILE_PREFIX_LIST} and build a list of files to ingest
    table_name = attr_dict["table_name"]
    dir_prefix = attr_dict["dir_prefix"]
    file_type = attr_dict["file_type"]
    log.info(f"Searching files for table {table_name}")
    discovered_file_list_dict = search_for_files(BUCKET_NAME, dir_prefix, attr_dict)
    primary_key = attr_dict["primary_key"]
    notnull_cols = attr_dict["notnull_cols"]

    if len(discovered_file_list_dict) != 0:
        file_expected_cols = attr_dict["file_expected_cols"]
        Found = True
        if file_type == "CSV":
            csv_field_delimiter = attr_dict["csv_field_delimiter"]
            # Process the ingestion of files from the list
            log.info(f"Processing CSV files for table {table_name}")
            process_all_csv_files_for_one_table(
                files_dict_list=discovered_file_list_dict,
                file_expected_cols=file_expected_cols,
                input_table_name=table_name,
                input_table_primary_key_columns=primary_key,
                input_table_notnull_columns=notnull_cols,
                file_csv_field_delimiter=csv_field_delimiter,
            )
        elif file_type == "PARQUET":
            log.info(f"Processing PARQUET files for table {table_name}")
            process_all_parquet_files_for_one_table(
                files_dict_list=discovered_file_list_dict,
                file_expected_cols=file_expected_cols,
                input_table_name=table_name,
                input_table_primary_key_columns=primary_key,
                input_table_notnull_columns=notnull_cols,
            )
        else:
            raise AssertionError(f"File type {file_type} not supported")

    # Even if no file is ingested, it's better to refresh the bronze view of stack
    process_view_for_stack_table(input_table_name=table_name)

if not Found:
    log.info(f"No file to process !!!")
    log.info(f"bronze views are refreshed\n--------\n")

if is_error_detected:
    error_list = set(table_error_list + file_error_list)
    log.critical(
        f"An error has been detected for at least one table(s) in : {error_list} see above !"
    )
    raise AssertionError()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1
# MAGIC
# MAGIC No specific preparation identified

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

## Quality Checks - Common Functions defined in leap_utils

#### validate_and_log_gx_results()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - Uniqueness
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Quality checks are done in file ingestion above
# in the section ## Inputs Processing

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 2 - Not null expectation
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Quality checks are done in file ingestion above
# in the section ## Inputs Processing

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Function : process_single_latest_table
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is compute latest from stack.
# MAGIC
# MAGIC **How to call:**
# MAGIC process_single_latest_table(table_name, input_table_path, primary_key_columns, output_table_path )
# MAGIC
# MAGIC **Output:**
# MAGIC - output_table_path if OK
# MAGIC - None if ERROR
# MAGIC
# MAGIC **Output:**
# MAGIC - None
# MAGIC
# MAGIC **Globals**
# MAGIC - is_error_detected
# MAGIC - table_error_list
# MAGIC - FORCE_REINITIALIZATION

# COMMAND ----------


def process_single_latest_table(
    table_name: str,
    input_table_path: str,
    primary_key_columns: str,
    output_table_path: str,
) -> SparkDataFrame:
    """
    Process a single latest table from a stack table.

    :param table_name: The name of the table to process.
    :type table_name: str
    :param input_table_path: The path to the stack table to read from.
    :type input_table_path: str
    :param primary_key_columns: A string containing the list of columns that define the primary key.
                                 These columns must uniquely identify each row.
    :type primary_key_columns: str
    :param output_table_path: The path to the output location where the latest table will be saved.
    :type output_table_path: str
    :return: A Spark DataFrame representing the latest table if the process is successful, or None if an error occurs.
    :rtype: SparkDataFrame
    """

    global is_error_detected
    global table_error_list
    global FORCE_REINITIALIZATION
    startTime = time.time()

    # Read stack table and catch the schema as new_schema
    try:
        df_table_stack = spark.read.table(input_table_path)
        new_schema = df_table_stack.columns

        # get the last_existing_timestamp_of_extraction
        last_existing_timestamp_of_extraction = df_table_stack.select(
            f.max("_meta_extraction_timestamp")
        ).first()["max(_meta_extraction_timestamp)"]
        log.info(
            f"the last timestamp in Stack table is : {last_existing_timestamp_of_extraction}"
        )
    except Exception as e:
        log.error(f"Error reading able {input_table_path}.")
        is_error_detected = True
        table_error_list.append(table_name)
        return None

    # If latest table already exists, catch the schema as old_schema
    output_table_name = f"{table_name.lower()}_latest"
    output_table_path = f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{output_table_name}"
    if table_utils.UnityCatalogCheckTableExists(output_table_path):
        old_schema = spark.read.table(output_table_path).columns
    else:
        old_schema = None
        FORCE_REINITIALIZATION = True  # Don't MERGE if table does not exists

    # Get the mode of extraction in the stack and check it is Unique
    df_filtered = df_table_stack.filter(
        df_table_stack._meta_extraction_timestamp
        == last_existing_timestamp_of_extraction
    )
    df_mode = df_filtered.select("_meta_file_mode").drop_duplicates()
    if df_mode.count() > 1:
        log.critical(
            f"Different SAP modes of extraction appears on table : {table_name}"
        )
        is_error_detected = True
        table_error_list.append(table_name)
        return None

    # Set Delta table clustered by "_meta_ID" if and only if there is a primary key
    if (primary_key_columns) and (primary_key_columns != ""):
        cluster_cols = "_meta_ID"
        cluster_cols = None
        primary_key_columns = "_meta_ID"
    else:
        cluster_cols = None
        primary_key_columns = None
        FORCE_REINITIALIZATION = True  # Don't MERGE if no primary key - Cannot process DELTA if no primary key

    if (old_schema is not None) and (
        not is_same_schema(
            old_schema=old_schema, new_schema=new_schema, metadata_info=[]
        )
    ):
        FORCE_REINITIALIZATION = True  # Don't MERGE if schema has changed

    # if df_mode[0][0] == "FULL" then  latest_table = latest_extraction_timestamp in stack
    if df_mode.collect()[0][0] == "FULL":
        log.info(f"Stack table is in FULL mode")
        df_latest = df_filtered  # Dataframe to save
    else:
        log.info(f"Stack table is in DELTA mode")

        if primary_key_columns is None:
            log.critical(
                f"Cannot process LATEST on table : {table_name} without identified primary key"
            )
            is_error_detected = True
            table_error_list.append(table_name)
            return None

        # if latest_table already exists and not FORCE_REINITIALIZATION then latest_table processed with MERGE INTO method
        # else latest_table processed with legacy method
        if not FORCE_REINITIALIZATION:
            log.info(f"Using MERGE INTO method")

            # Read latest table
            df_table_latest = spark.read.table(output_table_path)

            # get the last_existing_timestamp in latest table
            last_existing_timestamp_in_latest = df_table_latest.select(
                f.max("_meta_extraction_timestamp")
            ).first()["max(_meta_extraction_timestamp)"]

            if last_existing_timestamp_in_latest is None:
                last_existing_timestamp_in_latest = THE_ORIGIN

            log.info(
                f"the last timestamp in {output_table_name} is : {last_existing_timestamp_in_latest}"
            )

            df_from_last_run_to_current_date = df_table_stack.filter(
                (
                    df_table_stack._meta_extraction_timestamp
                    > last_existing_timestamp_in_latest
                )
            )

            # For each ID in Dataframe keep the latest _meta_extraction_timestamp
            df_from_last_run_to_current_date_filtered = (
                table_utils.get_latest_version_for_each_id_column(
                    df_from_last_run_to_current_date,
                    primary_key_columns,
                    "_meta_extraction_timestamp",
                )
            )  # Dataframe to MERGE
            log.info(
                f"{df_from_last_run_to_current_date_filtered.count()} rows to merge"
            )

            # MERGE INTO latest table - UPSERT MODE
            try:
                table_utils.merge_into(
                    df_from_last_run_to_current_date_filtered,
                    output_table_path,
                    [primary_key_columns],
                ).display()
            except Exception as e:
                log.error(
                    f"Table {output_table_path} has not been created, an error occured during MERGE INTO."
                )
                all_target_cols = [
                    x[0]
                    for x in spark.sql(f"DESCRIBE {output_table_path}")
                    .select("col_name")
                    .collect()
                ]
                log.error(
                    f"Dataframe cols : {df_from_last_run_to_current_date_filtered.columns}\n----\n"
                )
                log.error(f"Tables cols : {all_target_cols}\n----\n")
                is_error_detected = True
                table_error_list.append(table_name)
                return None
            else:
                duration = time.time() - startTime
                log.info(f"Table {output_table_path} merged in {duration} seconds.")
                return f"{output_table_path}"
        else:
            # get the lastest existing_timestamp where mode == FULL mode in the stack table
            max_date_full = (
                df_table_stack.filter(df_table_stack._meta_file_mode == "FULL")
                .select(f.max("_meta_extraction_timestamp"))
                .first()["max(_meta_extraction_timestamp)"]
            )
            if max_date_full:
                df_from_last_full_to_current_date = df_table_stack.filter(
                    (df_table_stack._meta_extraction_timestamp >= max_date_full)
                )
            else:
                df_from_last_full_to_current_date = df_table_stack

            # For each ID in Dataframe keep the latest _meta_extraction_timestamp
            df_latest = table_utils.get_latest_version_for_each_id_column(
                df_from_last_full_to_current_date,
                primary_key_columns,
                "_meta_extraction_timestamp",
            )  # Dataframe to save

    # Save the latest table from Dataframe df_latest
    try:
        result = table_utils.save_table(
            dest_table=output_table_path,
            df=df_latest,
            mode="overwrite",
            overwrite_schema=True,
            cluster_cols=cluster_cols,
        )
    except Exception as e:
        log.error(
            f"Table {output_table_path} has not been created, an error occured during creation.\nException is :{e}\n"
        )
        is_error_detected = True
        table_error_list.append(table_name)
        return None
    else:
        duration = time.time() - startTime
        log.info(f"Table {output_table_path} created in {duration} seconds.")

    # set PK
    if primary_key_columns is not None:
        # Add Primary Key if not exists and if defined for this table
        catalog, schema, table = output_table_path.split(".")
        pk_name = f"{output_table_name}_pk"
        nb_cons = spark.sql(
            f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
        ).first()[0]
        if nb_cons == 0:
            try:
                # Before adding Primary Key, need to set columns NOT NULL
                primary_key_columns_list = primary_key_columns.replace(" ", "").split(
                    ","
                )
                for col in primary_key_columns_list:
                    table_utils.set_table_column_not_null(
                        table_path=f"{output_table_path}", column=col.strip()
                    )
                # add_table_primary_key
                table_utils.add_table_primary_key(
                    table_path=f"{output_table_path}",
                    pk_name=f"{pk_name}",
                    columns=primary_key_columns,
                )
            except Exception as e:
                log.error(
                    f"Error adding PRIMARY KEY to table {output_table_path}.\nException is :{e}\n"
                )
                return None

    return f"{output_table_path}"


# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### MAIN2 - Latest tables Processing
# MAGIC - Read stack tables
# MAGIC - Build the latest tables from stack
# MAGIC

# COMMAND ----------

is_error_detected = False
table_error_list = []
processed_tables = set()

# For each kind of file, create the latest table
for attr_dict in FILES_ATTRS_DICT:
    # Process each table
    table_name = attr_dict["table_name"]
    primary_key = attr_dict["primary_key"]
    notnull_cols = attr_dict["notnull_cols"]

    if table_name in processed_tables:
        continue  # Continue to next dictionary

    processed_tables.add(table_name)
    log.debug(
        f"--------\ntable_name = '{table_name}', primary_key = '{primary_key}', notnull_cols = '{notnull_cols}'"
    )

    # input / output table in Databricks Unity Catalog
    # input table is view of the stack table
    input_table_Path = f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_stack"
    input_table_Path = input_table_Path.strip().lower()
    output_table_Path = f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}_latest"
    output_table_Path = output_table_Path.strip().lower()

    log.info(f"Processing input table : {input_table_Path}.")

    # Process stack table to latest table
    repeat = True
    while repeat:
        output_table_path = process_single_latest_table(
            table_name, input_table_Path, primary_key, output_table_Path
        )
        if output_table_path is not None:
            log.info(
                f"Processed successfully {table_name} , to {output_table_path}\n--------\n"
            )
            repeat = False
        else:
            if not FORCE_REINITIALIZATION:
                FORCE_REINITIALIZATION = True
                log.error(
                    f"Processed unsuccessfully {table_name} , to {output_table_path} -> Retrying with reinitialization of the table\n--------\n"
                )
            else:
                log.error(
                    f"Processed unsuccessfully {table_name} , to {output_table_path} -> Aborting\n--------\n"
                )
                is_error_detected = True
                table_error_list.append(table_name)
                repeat = False

if is_error_detected:
    error_list = set(table_error_list)
    log.critical(
        f"An error has been detected for at least one table(s) in : {error_list} see above !"
    )
    raise AssertionError()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
