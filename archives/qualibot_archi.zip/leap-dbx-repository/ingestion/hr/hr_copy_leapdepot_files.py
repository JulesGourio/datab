# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # HR COPY LEAPDEPOT FILES
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim of this dirty notebook is to copy leapdepot files to destination for ingestion
# MAGIC
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC - s3://leap-s3-raw-weeu1-{reference_read_env}/manual/leapdepot/UC33_HR/ABSENTEISM/YYYYmmDD_HHMMSS_ABS.csv
# MAGIC
# MAGIC **Output Files Pipeline**
# MAGIC - s3://leap-s3-raw-sd-lat-{reference_read_env}/apps/hr/YYYYmmDD_HHMMSS_ABS.csv
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import logging
import re
from typing import List

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

RADICAL = ".*_ABS.csv"
PREFIX = "manual/leapdepot/UC33_HR/ABSENTEISM/"
SOURCE_BUCKET = f"leap-s3-raw-weeu1-{REFERENCE_READ_ENV}"
OVERWRITE = True

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

DEST_PREFIX = "apps/hr/"
DEST_BUCKET = f"leap-s3-raw-sd-lat-{PIPELINE_WRITE_ENV}"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"SOURCE_BUCKET is:  {SOURCE_BUCKET}")
log.info(f"PREFIX is:  {PREFIX}")
log.info(f"DEST_BUCKET is:  {DEST_BUCKET}")
log.info(f"DEST_PREFIX is:  {DEST_PREFIX}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------


def list_files_in_s3_bucket_with_prefix(
    source_bucket: str, source_prefix: str, recursive: bool = False
) -> List[str]:
    # List files under s3://{source_bucket}/{source_prefix} and return a list
    # Input : source_bucket -> str
    #         source_prefix -> str
    #         recursive -> bool (optional, defaults to False)
    # Output : List of str with name if not recursive, with path if recursive

    if not source_prefix.endswith("/"):
        source_prefix = f"{source_prefix}/"

    s3_folder_path = f"s3://{source_bucket}/{source_prefix}"

    # need dbutils
    files = dbutils.fs.ls(s3_folder_path)

    # Create an empty list
    file_names = []

    # If recursive is True, generate the list of all files
    if recursive:
        for file in files:
            if file.isDir():
                new_files = dbutils.fs.ls(file.path)
                for new_file in new_files:
                    if not new_file.isDir():
                        file_names.append(new_file.path)
            else:
                file_names.append(file.path)
    else:
        for file in files:
            if not file.isDir():
                file_names.append(file.name)

    # Return the list
    return file_names


# COMMAND ----------

# MAGIC %md
# MAGIC ### MAIN

# COMMAND ----------

print("Existing Files in Source...")
if not PREFIX.endswith("/"):
    PREFIX = f"{PREFIX}/"

try:
    file_list = list_files_in_s3_bucket_with_prefix(SOURCE_BUCKET, PREFIX, False)
    file_list_filtered = []
except:
    print("No files")
else:
    for filename in file_list:
        if re.search(f"^.*{RADICAL}.*", filename):
            print(f"s3://{SOURCE_BUCKET}/{PREFIX}{filename}")
            file_list_filtered.append(f"s3://{SOURCE_BUCKET}/{PREFIX}{filename}")
    print(len(file_list_filtered))

# COMMAND ----------

print("Existing Files in Destination...")

try:
    file_list_dest = list_files_in_s3_bucket_with_prefix(
        DEST_BUCKET, DEST_PREFIX, False
    )
    file_list_dest_filtered = []
except:
    print("No files")
else:
    for filename in file_list_dest:
        if re.search(f"^.*{RADICAL}.*", filename):
            print(f"s3://{DEST_BUCKET}/{DEST_PREFIX}{filename}")
            file_list_dest_filtered.append(
                f"s3://{DEST_BUCKET}/{DEST_PREFIX}{filename}"
            )
    print(len(file_list_dest_filtered))

# COMMAND ----------

print("Copying Files to Destination...")

dest_dir = f"s3://{DEST_BUCKET}/{DEST_PREFIX}"
dbutils.fs.mkdirs(dest_dir)

dest_files = [file.name for file in dbutils.fs.ls(dest_dir)]

# Expression régulière pour détecter les fichiers avec double timestamp
regex_with_prefix = re.compile(r"^\d{8}_\d{6}_(\d{8}_\d{6}_ABS\.csv)$")

for filename in file_list:
    if re.search(f"^.*{RADICAL}.*", filename):
        source_path = f"s3://{SOURCE_BUCKET}/{PREFIX}{filename}"

        # Vérifier si le fichier correspond au format avec double timestamp
        match = regex_with_prefix.match(filename)
        if match:
            # Extraire le nom sans le premier timestamp
            new_filename = match.group(1)
        else:
            # Garde le nom tel quel
            new_filename = filename

        dest_path = f"s3://{DEST_BUCKET}/{DEST_PREFIX}{new_filename}"

        dest_exists = new_filename in dest_files

        if OVERWRITE or not dest_exists:
            print(f"Copying: {source_path} to {dest_path}")
            dbutils.fs.mv(source_path, dest_path)
        else:
            print(f"Skipped: {dest_path} already exists and OVERWRITE is set to False")
