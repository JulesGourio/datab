# Databricks notebook source
# MAGIC %md
# MAGIC # Commitment AS/IS ingestion
# MAGIC Ingestion of commitment files, for the commitment per profit center. There is one commitment file per fiscal year for IS and AS scope.

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

import warnings

warnings.simplefilter(action="ignore", category=FutureWarning)

# COMMAND ----------

import datetime
import re
from typing import List

import pyspark.pandas as ps
from databricks.sdk.runtime import dbutils
from great_expectations.dataset import SparkDFDataset
from pyspark.sql import DataFrame
from pyspark.sql.types import DoubleType
from pyspark.sql import functions as f
from pyspark.sql.utils import AnalysisException

from leap_utils.common import logger
from leap_utils.common.validation import gx_validation
from leap_utils.config import spark
from leap_utils.data_asset import table_utils
from leap_utils.ingestion import ingestion_utils

# COMMAND ----------

# MAGIC %md
# MAGIC # Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Setup Logger

# COMMAND ----------

if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "AS & IS commitments ingestion"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Fix root logger

# COMMAND ----------

import logging

logging.getLogger().handlers.clear()

# COMMAND ----------

# MAGIC %md
# MAGIC # Constants

# COMMAND ----------

INGESTION_S3_BUCKET = f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/"

COMMITMENT_S3_FOLDER_PATH = "manual/leapdepot/UC28_OPERATIONS_REVENUE_MANAGEMENT/"

COMMITMENT_S3_BUCKET_PATH = f"{INGESTION_S3_BUCKET}/{COMMITMENT_S3_FOLDER_PATH}"

COMMITMENT_S3_BUCKET_ARCHIVE_PATH = (
    f"{INGESTION_S3_BUCKET}/archive/{COMMITMENT_S3_FOLDER_PATH}"
)

FILENAME_WITH_TIMESTAMP_REGEX = r"^(\d{8}_\d{6})_(IS|AS)?_?(commitment)(?:_(\d{4}))?\.xlsx$"

# COMMAND ----------

# MAGIC %md
# MAGIC # Read budget amount excel files in LEAP depot S3 bucket

# COMMAND ----------

# MAGIC %md
# MAGIC ## Find files to ingest

# COMMAND ----------

df_file_list = ingestion_utils.create_dbutils_ls_dataframe(COMMITMENT_S3_BUCKET_PATH)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_file_list.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Keep only file names that matches leap depot timestamps and excel files

# COMMAND ----------

def archive_files(filenames: List[str]):
    for filename in filenames:
        dbutils.fs.mv(
            f"{COMMITMENT_S3_BUCKET_PATH}/{filename}",
            f"{COMMITMENT_S3_BUCKET_ARCHIVE_PATH}/{filename}",
        )

# COMMAND ----------

df_files_with_valid_filename = df_file_list.where(
    f.regexp_like(f.col("name"), f.lit(FILENAME_WITH_TIMESTAMP_REGEX))
)
df_files_with_invalid_filename = df_file_list.where(
    ~f.regexp_like(f.col("name"), f.lit(FILENAME_WITH_TIMESTAMP_REGEX))
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_files_with_valid_filename.display()
    df_files_with_invalid_filename.display()

# COMMAND ----------

if df_files_with_invalid_filename.count() > 0:
    invalid_filenames = list(df_files_with_invalid_filename.toPandas().name)
    log.error(f"Found files with invalid filename: {invalid_filenames}")
    log.info(f"Archiving files with invalid filename: {invalid_filenames}")
    archive_files(invalid_filenames)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stop ingestion if there is no files to ingest

# COMMAND ----------

df_files_to_ingest = df_files_with_valid_filename

files_to_ingest = df_files_to_ingest.count() > 0

if not files_to_ingest:
    dbutils.notebook.exit("No files to ingest")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ingest all files with pandas on spark

# COMMAND ----------

def unpivot_commitments(df: DataFrame) -> DataFrame:
    """
    Unpivots commitment week columns into long format with columns:
    - 'commitment_date_name': original column name (e.g. '2025-W01-M01')
    - 'commitment_value': value from that column

    If the expected schema is not met, the function returns None. 
    The weekly commitment column name is expected to be in the format 'YYYY-Wxx-Mxx'.
    The function also checks for the existence of the expected columns.

    Args:
        df (DataFrame): Input wide-format DataFrame with commitment columns

    Returns:
        DataFrame: Unpivoted long-format DataFrame
    
    """
    static_cols = [
        "commitment_type", "material_number", "profit_center_code",
        "currency", "unit_price"
    ]
    # Identify week columns (e.g. '2025-W01-M01')
    commitment_cols = [c for c in df.columns if re.match(r"2\d{3}-W\d{2}-M\d{2}", c)]
    # Missing columns
    missing_cols = [c for c in static_cols if c not in df.columns]
    # Unexpected columns 
    unexpected_cols = [c for c in df.columns if c not in static_cols + commitment_cols]

    if len(commitment_cols) == 0 :
        log.error("No week-based commitment columns found (format: 'YYYY-Wxx-Mxx')")
        return None
    if len(missing_cols) > 0:
        log.error(f"Missing columns: {missing_cols}")
        return None
    if len(unexpected_cols) > 0:
        log.error(f"Unexpected columns found: {unexpected_cols}")
        return None

    # Unpivot commitment week columns
    df_unpivoted = df.unpivot(
        ids = static_cols,
        values = commitment_cols,
        variableColumnName = "commitment_date_name",
        valueColumnName = "commitment_value"
    )

    return df_unpivoted.select(
        *static_cols,
        "commitment_date_name",
        "commitment_value",
    )


# COMMAND ----------

df_commitment_ingested_files = spark.createDataFrame(
    data=[],
    schema=(
        "_meta_filepath string, "
        "_meta_filename string, "
        "_meta_modification_timestamp timestamp, "
        "_meta_ingestion_timestamp timestamp, "
        "_meta_leapdepot_timestamp timestamp"
    ),
)

ingestion_timestamp = datetime.datetime.now(tz=datetime.timezone.utc)

# COMMAND ----------

file_years_dct = {}
for file in df_files_to_ingest.collect():
    log.info("Reading file %s at: %s", file.name, file.path)

    df_commitment = (
        ps.read_excel(
            f"{COMMITMENT_S3_BUCKET_PATH}/{file.name}",
            sheet_name=0,
            header=0,
            dtype=str,
        )
        .to_spark()
        .alias("df_commitment_raw")
    )
    df_commitment = unpivot_commitments(df_commitment)
    if df_commitment is None:
        log.error(f"Skipping ingestion of {file.name} due to schema mismatch.")
        log.info(f"Archiving {file.name} due to schema mismatch.")
        archive_files([file.name])
    else:
        metadata_columns = {
            "_meta_filepath": f.lit(file.path),
            "_meta_filename": f.lit(file.name),
            "_meta_modification_timestamp": f.to_utc_timestamp(
                f.lit(file.modification_timestamp), "UTC"
            ),
            "_meta_ingestion_timestamp": f.to_utc_timestamp(
                f.lit(ingestion_timestamp), "UTC"
            ),
            "_meta_leapdepot_timestamp": f.to_utc_timestamp(
                f.to_timestamp_ntz(
                    f.regexp_extract(
                        f.col("_meta_filename"),
                        pattern=FILENAME_WITH_TIMESTAMP_REGEX,
                        idx=1,
                    ),
                    f.lit("yyyyMMdd_HHmmss"),
                ),
                "Europe/Paris",
            ),
        }
        df_commitment = df_commitment.withColumns(metadata_columns)
        df_commitment = df_commitment.select(
            *[f.col(col) for col in metadata_columns.keys()],
            *[f.col(col) for col in df_commitment.columns if col not in metadata_columns.keys()]
        )
        df_commitment_ingested_files = df_commitment_ingested_files.unionByName(
            df_commitment, allowMissingColumns=True
        )

        log.info("Finished reading file %s\n", file.name)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_commitment.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Pre-stack ingestion checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check that all files have only one year of data

# COMMAND ----------

df_ingested_fiscal_year_check = (
    df_commitment_ingested_files.withColumn(
        "fiscal_year", 
        f.regexp_extract("commitment_date_name", r"(\d{4})", 1)
    )
    .groupBy("_meta_filename", "fiscal_year")
    .count()
    .groupBy("_meta_filename")
    .agg(
        f.sum(f.col("count")).alias("count"),
        f.count(f.lit(1)).alias("number_of_fiscal_year_in_file"),
        f.collect_set(f.col("fiscal_year")).alias("fiscal_year_list"),
    )
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_ingested_fiscal_year_check.display()

# COMMAND ----------

df_ingested_files_with_multiple_fiscal_year = df_ingested_fiscal_year_check.where(
    f.col("number_of_fiscal_year_in_file") != f.lit(1)
)

bad_files = list(
    df_ingested_files_with_multiple_fiscal_year.select("_meta_filename").toPandas()[
        "_meta_filename"
    ]
)

# COMMAND ----------

if df_ingested_files_with_multiple_fiscal_year.count() > 0:
    log.critical("Commitment files with multiple fiscal year are:\n%s", bad_files)

    if log.level <= logger.LOGGER_MAPPING["critical"]:
        df_ingested_files_with_multiple_fiscal_year.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Red quality check if some files have more than one year of data

# COMMAND ----------

gx_ingested_fiscal_year_check = SparkDFDataset(
    df_ingested_fiscal_year_check, persist=False
)

fiscal_year_validation = [
    gx_ingested_fiscal_year_check.expect_column_values_to_be_between(
        column="number_of_fiscal_year_in_file", min_value=1, max_value=1
    )
]

# COMMAND ----------

gx_validation.validate_and_log_gx_results(
    quality_check_results=fiscal_year_validation,
    validation_level="RED",
    info_message="All commitment files have a single fiscal year per file.",
    error_message="Some commitment files have more than one fiscal year per file.",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Add or replace ingested files in a stack table

# COMMAND ----------

try:
    df_commitment_old_stack = spark.read.table(
        f"{PIPELINE_READ_ENV}_bronze"
        f".leap_depot_uc28_operations_revenue_management"
        f".commitment_stack"
    )
    df_commitment_old_stack.limit(1).collect()

except AnalysisException as e:
    if e.getErrorClass() == "TABLE_OR_VIEW_NOT_FOUND":
        df_commitment_old_stack = spark.createDataFrame(
            data=[], schema=df_commitment_ingested_files.schema
        )
    else:
        raise AssertionError(
            "Something went wrong when trying to read "
            "the commitment stack table."
        ) from e

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_commitment_old_stack.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Remove already ingested files in old stack

# COMMAND ----------

df_ingested_filenames = df_commitment_ingested_files.select(
    "_meta_filename"
).distinct()

ingested_filenames = list(df_ingested_filenames.toPandas()["_meta_filename"])

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_ingested_filenames.display()

# COMMAND ----------

df_commitment_stack_filtered = df_commitment_old_stack.where(
    ~f.col("_meta_filename").isin(*[f.lit(val) for val in ingested_filenames])
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_commitment_stack_filtered.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Append new ingested files to stack

# COMMAND ----------

df_commitment_new_stack = df_commitment_stack_filtered.unionByName(
    df_commitment_ingested_files, allowMissingColumns=True
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_commitment_new_stack.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Save new stack

# COMMAND ----------

table_utils.save_table(
    f"{PIPELINE_WRITE_ENV}_bronze"
    f".leap_depot_uc28_operations_revenue_management"
    f".commitment_stack",
    df_commitment_new_stack,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Archive ingested files in the archive folder

# COMMAND ----------

archive_files(ingested_filenames)
