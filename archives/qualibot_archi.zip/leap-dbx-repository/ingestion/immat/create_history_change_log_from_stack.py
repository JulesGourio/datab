# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC
# MAGIC Historize the IMMAT HR referential (`REPORT_RH_LEAP` / `immat_data`), tracking each time a
# MAGIC row changes based on the business column values (SCD Type 2 changelog).
# MAGIC - when a new `user_id` appears
# MAGIC - when any tracked column changes for a `user_id`
# MAGIC
# MAGIC Built on top of `leap_utils.data_asset.history_changelog`
# MAGIC (`initialize_history_changelog` / `calculate_history_changelog_delta_update`),
# MAGIC same engine as the SAP ECC6 ingestion.
# MAGIC
# MAGIC **Input:**
# MAGIC - INIT   : `{PIPELINE_READ_ENV}_bronze_hr.immat.immat_data_stack`  (all snapshots)
# MAGIC - UPDATE : `{PIPELINE_READ_ENV}_bronze_hr.immat.immat_data_latest` (current snapshot, 1 row/id)
# MAGIC
# MAGIC **Output:**
# MAGIC - `{PIPELINE_WRITE_ENV}_bronze_hr.immat.immat_data_history_change_log`
# MAGIC
# MAGIC **How to query the history_change_log table:**
# MAGIC - for a `user_id` at date D, keep the row where `Start_Validity <= D < End_Validity`
# MAGIC - `Start_Validity` : start of the validity interval → use `>=`
# MAGIC - `End_Validity`   : start of the *next* interval     → use `<`
# MAGIC - current rows: `_meta_is_current = true` (End_Validity = 9999-12-31)
# MAGIC
# MAGIC **How it is updated:**
# MAGIC - `force_reinitialization=True` / `force_changelog_reinitialization=True` / table missing
# MAGIC   → full INIT from the whole **stack**.
# MAGIC - otherwise, routed on the number of stack snapshots newer than the changelog watermark
# MAGIC   (`max(_meta_extraction_timestamp)` of the changelog):
# MAGIC     - `0` → already up to date (skip)
# MAGIC     - `1` → DELTA update from the **latest** snapshot (existing changelog + latest)
# MAGIC     - `>1` → full INIT from the **stack** — a delta from LATEST (1 state/id) would skip the
# MAGIC       intermediate SCD2 versions when several snapshots accumulated since the last run.
# MAGIC
# MAGIC **Conventions (FULL mode):**
# MAGIC - first appearance of an id → `Start_Validity = 1900-01-01`
# MAGIC - last appearance still present in latest stack → `End_Validity = 9999-12-31`
# MAGIC - id that disappears (FULL) → `End_Validity = max_extraction_date + 1 day`
# MAGIC - gaps (id absent between two snapshots) → discontinuity row with null business values
# MAGIC
# MAGIC **Known limitations (inherited from the engine):**
# MAGIC - date granularity: at most one change per id per day (intra-day changes collapse).
# MAGIC - change key = concat of tracked columns; check NULL / "_" collisions if values can contain "_".
# MAGIC - persistence: INIT = full overwrite ; UPDATE = **true delta** (`replace_where` on the changed user_ids only).

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings / Config

# COMMAND ----------

# DBTITLE 1,Standard imports
import logging
import time

from pyspark.sql import functions as f
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# DBTITLE 1,Add bundle_root to sys.path (when run from an Asset Bundle)
import sys

dbutils.widgets.text("bundle_root", "")
bundle_root = dbutils.widgets.get("bundle_root")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

# COMMAND ----------

# DBTITLE 1,LEAP imports
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils, history_changelog

# COMMAND ----------

# DBTITLE 1,Widgets
# Read / write environments (dev / uat / prod)
dbutils.widgets.text("pipeline_read_env", "dev")
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# pilotage.yml — source of truth for the table/column tags & comments to mirror onto the
# history_change_log table (same as the stack/latest tables). Empty → tags/comments skipped.
dbutils.widgets.text("pilotage_yaml", "")
dbutils.widgets.text("reference_read_env", "dev")
PILOTAGE_YAML = dbutils.widgets.get("pilotage_yaml")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Two flags trigger a full INIT (rebuild the changelog from the whole stack).
# Parsed case-insensitively so both "true"/"True" (and "false"/"False") work.
#
# force_reinitialization              : wired in the job to {{job.parameters.full_refresh}} —
#                                       a pipeline full refresh (stack/latest rebuilt) also
#                                       rebuilds the changelog.
# force_changelog_reinitialization    : manual knob to rebuild ONLY the changelog (e.g. tracked
#                                       columns changed) without full-refreshing the pipeline.
dbutils.widgets.text("force_reinitialization", "false")
FORCE_REINITIALIZATION = dbutils.widgets.get("force_reinitialization").strip().lower() == "true"

dbutils.widgets.text("force_changelog_reinitialization", "false")
FORCE_CHANGELOG_REINITIALIZATION = (
    dbutils.widgets.get("force_changelog_reinitialization").strip().lower() == "true"
)

dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# COMMAND ----------

# DBTITLE 1,Global variables & logger
SCHEMA = "immat"
READ_CATALOG = f"{PIPELINE_READ_ENV}_bronze_hr"
WRITE_CATALOG = f"{PIPELINE_WRITE_ENV}_bronze_hr"

STACK_TABLE = f"{READ_CATALOG}.{SCHEMA}.immat_data_stack"      # all snapshots — used for INIT
LATEST_TABLE = f"{READ_CATALOG}.{SCHEMA}.immat_data_latest"    # current snapshot (1 row/id) — used for the normal UPDATE
HISTORY_TABLE = f"{WRITE_CATALOG}.{SCHEMA}.immat_data_history_change_log"

# Identity and ordering
ID_COLUMN_LIST = ["user_id"]
SORT_COLUMN = "_meta_extraction_timestamp"

# Columns excluded from change detection (system / metadata + the id itself).
# Everything else is a tracked business column — derived dynamically so the
# changelog auto-adapts when the LEAP SCHEMA_N adds new columns.
NON_TRACKED_COLUMNS = set(ID_COLUMN_LIST) | {
    "_meta_id",
    "_meta_extraction_timestamp",
    "_meta_ingestion_timestamp",
    "_meta_file_name",
    "_meta_file_mode",
    "_meta_file_path",
    "_rescued_data",
    "_meta_validity_check",
    "payroll_sync",  # volatile sync flag — excluded to avoid noise versions in the history
    "custom_manager",  # pipe-separated manager list with UNSTABLE ordering across extractions
                       # (same set reordered daily) — excluded to avoid noise versions
}

DATA_EXTRACTION_MODE = "FULL"      # IMMAT is a full snapshot of the referential
CALCULATE_DISCONTINUITIES = True   # capture an employee leaving then returning

# Liquid clustering on the id → file-level data skipping makes the delta `replace_where
# "user_id IN (...)"` prune efficiently (and co-locates all versions of an employee for reads).
CLUSTER_COLS = "user_id"

log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

log.info(f"STACK_TABLE   = {STACK_TABLE}")
log.info(f"HISTORY_TABLE = {HISTORY_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Main

# COMMAND ----------

start_time = time.time()


def _keep_valid(df):
    # Keep only rows that passed the ingestion validity check (don't pollute the history).
    if "_meta_validity_check" in df.columns:
        return df.filter(f.col("_meta_validity_check") == True)  # noqa: E712
    return df


def _tracked_columns(df):
    # Business columns present in the source (excluding system/metadata + id).
    # Derived dynamically so the changelog auto-adapts when the LEAP SCHEMA_N adds columns.
    return [c for c in df.columns if c not in NON_TRACKED_COLUMNS]


# Max number of changed ids written via scoped replace_where before falling back to a full
# overwrite (a giant IN(...) predicate is counter-productive; mass changes ~ rebuild anyway).
MAX_SCOPED_IDS = 20000

table_exists = table_utils.UnityCatalogCheckTableExists(HISTORY_TABLE)
do_init = FORCE_REINITIALIZATION or FORCE_CHANGELOG_REINITIALIZATION or not table_exists

# --- Guard (robustness to missed runs) ---------------------------------------------------------
# The normal UPDATE path (below) reads only `immat_data_latest` (the current snapshot, 1 row/id),
# so it carries a SINGLE state per user_id. That is correct ONLY when the changelog is exactly ONE
# snapshot behind. If several stack snapshots accumulated since the last run (job not launched for
# a few days, or a full-refresh that re-stacked many snapshots), a delta from LATEST would record
# only the most recent state and SKIP every intermediate SCD2 version (silent history loss).
# So we route on the number of stack snapshots newer than the changelog watermark:
#     0  -> already up to date        (skip)
#     1  -> normal delta from LATEST  (correct: LATEST is the only new snapshot)
#     >1 -> full INIT from the STACK  (rebuild — preserves every intermediate version)
# Watermark = max extraction timestamp already materialised in the changelog.
if not do_init:
    hist_max_ts = (
        spark.read.table(HISTORY_TABLE).agg(f.max(SORT_COLUMN).alias("m")).collect()[0]["m"]
    )
    if hist_max_ts is None:
        log.warning(f"{HISTORY_TABLE} exists but is empty — rebuilding from STACK (INIT).")
        do_init = True
    else:
        new_snapshots = (
            _keep_valid(spark.read.table(STACK_TABLE))
            .filter(f.col(SORT_COLUMN) > f.lit(hist_max_ts))
            .select(SORT_COLUMN)
            .distinct()
            .count()
        )
        log.info(
            f"Changelog watermark = {hist_max_ts} ; {new_snapshots} new stack snapshot(s) since."
        )
        if new_snapshots == 0:
            log.info(
                f"{HISTORY_TABLE} already up to date (no snapshot newer than the changelog) — skipping."
            )
            dbutils.notebook.exit(f"up-to-date:{HISTORY_TABLE}")
        elif new_snapshots > 1:
            log.warning(
                f"{new_snapshots} stack snapshots accumulated since the last changelog run — a delta "
                f"from LATEST would skip intermediate versions. Rebuilding from the STACK (INIT)."
            )
            do_init = True

# Persistence params, overridden by the delta branch for a scoped (true-delta) write.
REPLACE_WHERE = None      # None → full overwrite ; "user_id IN (...)" → scoped write
OVERWRITE_SCHEMA = True   # True on INIT (rebuild) ; False on a scoped delta write

if do_init:
    # ---- INIT : rebuild the whole history from the STACK (all snapshots) ----
    log.info(f"INIT — building full history changelog from STACK {STACK_TABLE}")
    df_src = _keep_valid(spark.read.table(STACK_TABLE))
    tracked_column_list = _tracked_columns(df_src)
    log.info(f"Tracking {len(tracked_column_list)} columns: {tracked_column_list}")

    df_history_final = history_changelog.initialize_history_changelog(
        df=df_src,
        id_column_list=ID_COLUMN_LIST,
        sort_column=SORT_COLUMN,
        tracked_column_list=tracked_column_list,
        data_extraction_mode=DATA_EXTRACTION_MODE,
        calculate_discontinuities=CALCULATE_DISCONTINUITIES,
    )
else:
    # ---- NORMAL : incremental update from the LATEST snapshot (1 row per user_id) ----
    # Reached only when exactly ONE new snapshot exists (see the guard above): LATEST == that
    # snapshot, so there is no intermediate version to miss and the scoped delta below is correct.
    log.info(f"UPDATE — delta update from LATEST {LATEST_TABLE}")
    df_latest = _keep_valid(spark.read.table(LATEST_TABLE))
    df_history = spark.read.table(HISTORY_TABLE)
    tracked_column_list = _tracked_columns(df_latest)

    # --- 1) Find the user_ids whose state actually changed vs the current OPEN changelog row.
    #     change_key = the same concat the engine uses internally on the tracked columns.
    change_key = f.concat_ws("_", *[f.col(c) for c in tracked_column_list])
    df_open = (
        df_history.filter(f.col("_meta_is_current") == True)  # noqa: E712
        .select(*ID_COLUMN_LIST, change_key.alias("_k_hist"))
    )
    df_now = df_latest.select(*ID_COLUMN_LIST, change_key.alias("_k_now"))
    df_affected = (
        df_open.join(df_now, on=ID_COLUMN_LIST, how="fullouter")
        .filter(
            f.col("_k_hist").isNull()                # new id (not yet in the history)
            | f.col("_k_now").isNull()               # id that disappeared from the referential
            | (f.col("_k_hist") != f.col("_k_now"))  # id whose tracked values changed
        )
        .select(*ID_COLUMN_LIST)
        .distinct()
    )
    affected_ids = [r[ID_COLUMN_LIST[0]] for r in df_affected.collect()]
    log.info(f"{len(affected_ids)} user_id(s) changed since last run.")

    if not affected_ids:
        log.info(f"{HISTORY_TABLE} already up to date — skipping.")
        dbutils.notebook.exit(f"up-to-date:{HISTORY_TABLE}")

    # --- 2) Recompute ONLY the affected ids.
    #     The existing history is restricted to those ids (cheap), but the FULL latest is fed
    #     so the engine still derives the correct global max timestamp it uses to close the
    #     ids that disappeared from the referential. Non-affected latest ids are recomputed as
    #     throwaway single rows and dropped at step 3 — harmless, latest is tiny (1 row/id).
    df_history_subset = df_history.filter(f.col(ID_COLUMN_LIST[0]).isin(affected_ids))
    df_recompute = history_changelog.calculate_history_changelog_delta_update(
        df=df_latest,
        df_existing_history_changelog=df_history_subset,
        id_column_list=ID_COLUMN_LIST,
        sort_column=SORT_COLUMN,
        tracked_column_list=tracked_column_list,
        data_extraction_mode=DATA_EXTRACTION_MODE,
        calculate_discontinuities=CALCULATE_DISCONTINUITIES,
    )
    df_history_final = df_recompute.filter(f.col(ID_COLUMN_LIST[0]).isin(affected_ids))

    # --- 3) Persist as TRUE DELTA: rewrite ONLY the affected ids' rows (no full overwrite).
    OVERWRITE_SCHEMA = False
    if len(affected_ids) <= MAX_SCOPED_IDS:
        _ids = ",".join("'" + str(i).replace("'", "''") + "'" for i in affected_ids)
        REPLACE_WHERE = f"{ID_COLUMN_LIST[0]} IN ({_ids})"
    else:
        # Too many changed ids → a scoped IN(...) is counter-productive: recompute everything.
        log.warning(
            f"{len(affected_ids)} changed ids > {MAX_SCOPED_IDS} → full recompute + overwrite."
        )
        df_history_final = history_changelog.calculate_history_changelog_delta_update(
            df=df_latest,
            df_existing_history_changelog=df_history,
            id_column_list=ID_COLUMN_LIST,
            sort_column=SORT_COLUMN,
            tracked_column_list=tracked_column_list,
            data_extraction_mode=DATA_EXTRACTION_MODE,
            calculate_discontinuities=CALCULATE_DISCONTINUITIES,
        )
        REPLACE_WHERE = None
        OVERWRITE_SCHEMA = True

# COMMAND ----------

# DBTITLE 1,Save
# Persistence via table_utils.save_table:
#   - INIT  → REPLACE_WHERE=None  → full overwrite (rebuild the whole changelog).
#   - DELTA → REPLACE_WHERE="user_id IN (...)" → TRUE DELTA: only the affected ids' rows are
#             rewritten (close open row + insert new version + drop collapsed rows), the rest
#             of the (large) changelog is untouched. Liquid clustering on user_id makes the
#             replace_where prune efficiently.
#   save_table also updates the freshness pilot table — now resolved to the HR catalog
#   ({env}_bronze_hr.data_quality.freshness_pilot_table) so the history table is tracked there.
#   TO VALIDATE once via POC: scoped delta result == full rebuild for the affected ids.
try:
    table_utils.save_table(
        dest_table=HISTORY_TABLE,
        df=df_history_final,
        mode="overwrite",
        overwrite_schema=OVERWRITE_SCHEMA,
        replace_where=REPLACE_WHERE,
        cluster_cols=CLUSTER_COLS,
    )
except AnalysisException:
    log.error(f"Table {HISTORY_TABLE} could not be created.")
    raise

duration = time.time() - start_time
log.info(f"Table {HISTORY_TABLE} written in {duration:.1f}s.")

# COMMAND ----------

# DBTITLE 1,Apply the same UC tags & comments as the pilotage tables (stack / latest)
# The history_change_log keeps the full schema (incl. the PII business columns), so it carries
# the SAME column tags & comments as stack/latest. PK/FK are intentionally NOT applied here:
# the grain is (user_id, Start_Validity), not user_id.
#
# Applied ONLY on (re)build (do_init): each ALTER ... SET TAGS / ALTER COLUMN ... COMMENT is a
# separate Delta commit (CHANGE COLUMN). Tags/comments are static (from pilotage) and survive a
# data-only `replace_where` WRITE, so re-applying them on every incremental run just floods the
# Delta history with no-op metadata commits. We set them once, when CREATE OR REPLACE rebuilt the
# (empty) metadata; incremental runs skip the whole block → zero metadata churn.
if PILOTAGE_YAML and do_init:
    from leap_utils.ingestion.ingestion_declarative_pipeline import load_pilotage_from_yaml

    _attrs_dict = load_pilotage_from_yaml(
        yaml_path=PILOTAGE_YAML,
        reference_read_env=REFERENCE_READ_ENV,
        pipeline_write_env=PIPELINE_WRITE_ENV,
    )
    _attrs = next((v for v in _attrs_dict.values() if v.get("table_name") == "immat_data"), None)
    if _attrs is None:
        log.warning("No 'immat_data' entry in pilotage.yml — tags/comments skipped.")
    else:
        _existing = set(spark.table(HISTORY_TABLE).columns)

        # --- tags (same as stack/latest) ---
        table_utils.apply_table_tags_uc(
            full_table_name=HISTORY_TABLE,
            table_tags=_attrs.get("table_tags") or {},
            dry_run=False,
        )
        _col_tags = {c: t for c, t in (_attrs.get("column_tags") or {}).items() if c in _existing}
        # _meta_id = concaténation de la PK (user_id) -> identifiant indirect. Il ne peut pas
        # être déclaré dans pilotage.yml (dédoublement "ambiguous" côté ingestion), donc on le
        # tague ici explicitement, comme sur immat_data_latest/stack (task update_meta_tags).
        if "_meta_id" in _existing:
            _col_tags["_meta_id"] = {"abac_hr_pii_standard": None}
        table_utils.apply_column_tags_uc(
            full_table_name=HISTORY_TABLE, column_tags=_col_tags, dry_run=False
        )

        # --- comments (same as stack/latest + the SCD2 columns) ---
        _col_comments = dict(_attrs.get("column_comments") or {})
        _col_comments.update({
            "Start_Validity": "SCD2 — start of the validity interval (inclusive)",
            "End_Validity": "SCD2 — next interval start ; 9999-12-31 while current (exclusive)",
            "_meta_is_current": "SCD2 — true if this version is currently valid (End_Validity = 9999-12-31)",
            "_meta_is_latest": "SCD2 — true if this is the last known version of the user_id",
        })
        _table_comment = _attrs.get("table_comment") or ""
        if _table_comment:
            spark.sql(
                f"COMMENT ON TABLE {HISTORY_TABLE} IS '{_table_comment.replace(chr(39), chr(39) * 2)}'"
            )
        for _c, _cmt in _col_comments.items():
            if _cmt and _c in _existing:
                spark.sql(
                    f"ALTER TABLE {HISTORY_TABLE} ALTER COLUMN {_c} "
                    f"COMMENT '{_cmt.replace(chr(39), chr(39) * 2)}'"
                )
        log.info("Applied UC tags & comments on the history_change_log table.")
elif not PILOTAGE_YAML:
    log.warning("pilotage_yaml not provided — tags/comments skipped on the history table.")
else:
    log.info(
        "Incremental update — tags/comments already set at last (re)build, skipping to avoid "
        "Delta metadata churn."
    )

dbutils.notebook.exit(f"ok:{HISTORY_TABLE}")
