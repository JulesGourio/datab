printf "\nRunning unit tests with pytest :\n\n"
python -m pytest test/. --cov-report xml:coverage-reports/coverage-report.xml --cov=. # Executes the tests with coverage

printf "\nRunning linting checks on leap_utils folder :\n\n"
python -m ruff check leap_utils # Execute the linting