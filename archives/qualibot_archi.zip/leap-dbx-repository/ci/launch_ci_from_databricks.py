# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook for executing CI checks from Databricks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Run linting checks on "leap_utils" folder
# MAGIC - Prerequisite : ruff library installed
# MAGIC - Ruff rules are defined in the pyproject.toml file
# MAGIC - **WARNING & LIMITATIONS** : Only python files are checked by the linter here, not notebooks ! This is because notebooks are stored in Databricks without the ".py" extension, ruff can only be applied to python files. If you want to run ruff on it, you should do it outside of Databricks (locally).
# MAGIC - For leap_utils it's fine since all files are supposed to be actual python files

# COMMAND ----------

import subprocess

ruff_results = subprocess.run(
    ["ruff", "check", "../leap_utils", "--no-cache"], capture_output=True
).stdout.decode()

print(ruff_results)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Run unit tests on "leap_utils" folder
# MAGIC - **Prerequisite**: pytest library installed

# COMMAND ----------

import sys

import pytest

# Skip writing pyc files on a readonly filesystem.
sys.dont_write_bytecode = True

# Run pytest.
retcode = pytest.main(["../test/", "-v", "-p", "no:cacheprovider"])

# Fail the cell execution if there are any test failures.
assert retcode == 0, "The pytest invocation failed. See the log for details."
