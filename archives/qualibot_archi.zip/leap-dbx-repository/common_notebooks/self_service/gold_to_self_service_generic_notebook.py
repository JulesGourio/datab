# Databricks notebook source
# MAGIC %md
# MAGIC # From gold to self-service generic notebook
# MAGIC
# MAGIC This notebook is used to standardize the publishing of gold data assets
# MAGIC to the self-service catalog.

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

import re

from databricks.sdk.runtime import dbutils
from pyspark import StorageLevel
from pyspark.sql import DataFrame, functions as f

from leap_utils.common import logger
from leap_utils.common.validation import validation_utils
from leap_utils.config import spark
from leap_utils.data_asset import table_utils
from leap_utils.databricks import dbutils_helper

# COMMAND ----------

# MAGIC %md
# MAGIC # Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ## Log level and read/write env

# COMMAND ----------

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold tables and column prefixes
# MAGIC
# MAGIC `GOLD_TABLES`: A list of gold tables to publish to the self-service catalog.
# MAGIC Provide the full table path, excluding the read environment part.
# MAGIC
# MAGIC Type: `list[str]`
# MAGIC
# MAGIC Example: `["gold.production.workcenter", "gold.production.routing"]`
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC `COLUMN_PREFIXES`: A nested list of technical column prefixes.
# MAGIC These prefixes are used to filter out columns that start with any of these
# MAGIC prefixes for the self-service column exposition.
# MAGIC Each sublist corresponds to a gold table, as there can be multiple prefixes
# MAGIC per gold table.
# MAGIC
# MAGIC Type: `list[list[str]]`
# MAGIC
# MAGIC Example: `[["CHRD_", "TC24_"], ["PLKO_", "PLPO_"]]`

# COMMAND ----------

dbutils.widgets.text("gold_tables", "")
GOLD_TABLES = dbutils_helper.dbutils_get_python_literal("gold_tables", default_value=[])

dbutils.widgets.text("column_prefixes", "")
COLUMN_PREFIXES = dbutils_helper.dbutils_get_python_literal(
    "column_prefixes", default_value=[]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Constants
# MAGIC `GOLD_TABLE_PATHS`: A list of full paths to the gold tables,
# MAGIC constructed using the pipeline's read environment and table names.

# COMMAND ----------

GOLD_TABLE_PATHS = [f"{PIPELINE_READ_ENV}_{table_name}" for table_name in GOLD_TABLES]

# COMMAND ----------

# MAGIC %md
# MAGIC # Functions

# COMMAND ----------


def is_column_starting_with_any_prefix(column_name: str, column_prefixes: list[str]):
    """
    Check if a column name starts with any of the given prefixes (case-insensitive).

    :param column_name: The name of the column to check.
    :type column_name: str
    :param column_prefixes: A list of prefixes to check against the column name.
    :type column_prefixes: list[str]
    :return: True if the column name starts with any of the prefixes, False otherwise.
    :rtype: bool
    """
    return any(
        [
            re.match(f"(?i)^{column_prefix}.*$", column_name)
            for column_prefix in column_prefixes
        ]
    )


def column_list_to_expose(columns: list[str], column_prefixes: list[str]):
    """
    Filter out columns that start with any of the given prefixes.

    :param columns: A list of column names to filter.
    :type columns: list[str]
    :param column_prefixes: A list of prefixes to filter out from the column names.
    :type column_prefixes: list[str]
    :return: A list of column names that do not start with any of the given prefixes.
    :rtype: list[str]
    """
    return [
        column_name
        for column_name in columns
        if not is_column_starting_with_any_prefix(column_name, column_prefixes)
    ]


# COMMAND ----------

# MAGIC %md
# MAGIC # Logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Setup logger

# COMMAND ----------

if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "gold_to_self_service"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Fix root logger

# COMMAND ----------

# TODO this logger fix should be done with the logger refactoring.
# This fix the root logger that prints log messages when another app logger is already setup.

import logging

logging.getLogger().handlers.clear()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Log widgets

# COMMAND ----------

log.debug(f"{GOLD_TABLE_PATHS=}")
log.debug(f"{COLUMN_PREFIXES=}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Self service standards quality checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## No empty columns (columns with only null values)

# COMMAND ----------


def find_null_proportion(df: DataFrame) -> DataFrame:
    """
    Find the null proportion of all columns of a dataframe.

    :param df: The dataframe to use to find the null proportion of all its columns.
    :return: A dataframe that contains the null proportion for all columns in the input dataframe.

    Example:

    >>> df = spark.createDataFrame(
    ...     data=[
    ...         ("Hello", "Bonjour"),
    ...         ("Bye", None),
    ...         ("See you", None),
    ...         (None, "Bon appétit"),
    ...     ],
    ...     schema="english string, french string",
    ... )
    >>> find_null_proportion(df).show()
    +------------+-----------+------------+-----------+
    |_column_name|_null_count|_total_count|_proportion|
    +------------+-----------+------------+-----------+
    |     english|          1|           4|       0.25|
    |      french|          2|           4|        0.5|
    +------------+-----------+------------+-----------+
    """
    df_nulls = df.agg(
        *[
            f.count(f.when(f.col(col).isNull(), f.lit(1))).alias(col)
            for col in df.columns
        ]
    )

    df_nulls_with_proportion = df_nulls.unpivot(
        ids=[],
        values=df.columns,
        variableColumnName="_column_name",
        valueColumnName="_null_count",
    ).withColumns(
        {
            "_total_count": f.lit(df.count()),
            "_proportion": f.col("_null_count") / f.col("_total_count"),
        }
    )

    return df_nulls_with_proportion


# COMMAND ----------


def check_null_proportion(df: DataFrame, **kwargs) -> None:
    """
    Check the null proportion of all columns in a dataframe and apply validation logic.

    :param df: The dataframe to check for null proportions.
    :param kwargs: Additional keyword arguments that will be passed to the
        `validation_utils.red_amber_logic` function, including 'table_name' for message
        prefix.
    :return: None

    This function calculates the proportion of null values for each column in the dataframe.
    It applies validation logic to ensure no columns have more than 90% null values (AMBER level)
    and no columns have only null values (RED level). Validation results are displayed using
    the `validation_utils.red_amber_logic` function.
    """
    df_null_proportion = find_null_proportion(df).persist(StorageLevel.DISK_ONLY)

    amber_null_proportion = df_null_proportion.where(f.col("_proportion") >= f.lit(0.9))

    kwargs["message_prefix"] = kwargs.pop("table_name")

    validation_utils.red_amber_validation_logic(
        check=amber_null_proportion.count() == 0,
        on_success_message="No columns have more than 90% of null values",
        on_success_action=None,
        on_error_message="Some columns have more than 90% of null values",
        on_error_action=amber_null_proportion.display,
        on_error_validation_level="AMBER",
        **kwargs,
    )

    red_null_proportion = df_null_proportion.where(f.col("_proportion") == f.lit(1.0))

    validation_utils.red_amber_validation_logic(
        check=red_null_proportion.count() == 0,
        on_success_message="No columns have only null values",
        on_success_action=None,
        on_error_message="Some columns have only null values",
        on_error_action=red_null_proportion.display,
        on_error_validation_level="RED",
        **kwargs,
    )


# COMMAND ----------

# MAGIC %md
# MAGIC ## All boolean columns should start with "is_"

# COMMAND ----------


def is_invalid_boolean_column(data_type_tuple: tuple) -> bool:
    """
    Check if a column is an invalid boolean column.

    A column is considered invalid if it starts with 'is_' but is not of boolean type,
    or if it is of boolean type but does not start with 'is_'.

    :param data_type_tuple: A tuple containing the column name and its data type.
    :type data_type_tuple: tuple
    :return: True if the column is invalid, False otherwise.
    :rtype: bool
    """
    (column_name, data_type) = data_type_tuple

    return (column_name.startswith("is_") and data_type != "boolean") or (
        not column_name.startswith("is_") and data_type == "boolean"
    )


def check_boolean_columns(df: DataFrame, **kwargs) -> None:
    """
    Check the validity of boolean columns in a dataframe.

    This function ensures that:
    1. All boolean columns start with 'is_'.
    2. All columns starting with 'is_' are of boolean type.

    :param df: The dataframe to check for boolean column validity.
    :type df: DataFrame
    :param kwargs: Additional keyword arguments that will be passed to the
        `validation_utils.red_amber_logic` function, including 'table_name' for
        message prefix.
    :return: None

    Validation logic is applied to ensure there are no invalid boolean columns (RED level).
    Results are displayed using the `validation_utils.red_amber_logic` function.
    """
    bad_boolean_columns = list(filter(is_invalid_boolean_column, df.dtypes))

    kwargs["message_prefix"] = kwargs.pop("table_name")

    validation_utils.red_amber_validation_logic(
        check=len(bad_boolean_columns) == 0,
        on_success_message=(
            "All boolean columns start with 'is_' "
            "and columns starting with 'is_' are boolean columns."
        ),
        on_success_action=None,
        on_error_message=(
            "Some boolean columns do not start with 'is_' "
            f"or columns starting with 'is_' are not boolean columns ({bad_boolean_columns=})."
        ),
        on_error_action=None,
        on_error_validation_level="RED",
        **kwargs,
    )


# COMMAND ----------

# MAGIC %md
# MAGIC ## Each table must have a single column finishing by "_ID" and its values must be unique

# COMMAND ----------


def check_ID_column(df: DataFrame, **kwargs) -> None:
    """
    Check the ID column in a dataframe for validity.

    This function performs the following checks:
    1. Ensures there is exactly one column ending with '_ID'.
    2. Validates that the ID column has unique values.

    :param df: The dataframe to check for ID column validity.
    :type df: DataFrame
    :param kwargs: Additional keyword arguments that will be passed to the
        `validation_utils.red_amber_logic` function, including 'table_name' for
        message prefix.
    :return: None

    Validation logic is applied to ensure there is one ID column (AMBER level) and that
    the ID values are unique (RED level). Results are displayed using the
    `validation_utils.red_amber_logic` function.
    """
    ID_columns = [col_name for col_name in df.columns if col_name.endswith("_ID")]

    kwargs["message_prefix"] = kwargs.pop("table_name")

    has_one_ID_column = len(ID_columns) == 1

    validation_utils.red_amber_validation_logic(
        check=has_one_ID_column,
        on_success_message="The table has one column ending with '_ID'.",
        on_success_action=None,
        on_error_message=(
            f"The table has no columns or "
            f"multiple columns ending with '_ID' ({ID_columns=})."
        ),
        on_error_action=None,
        on_error_validation_level="AMBER",
        **kwargs,
    )

    if has_one_ID_column:
        ID_column = ID_columns[0]

        df_distinct_ID = df.select(ID_column).distinct()

        df_count_duplicate_ID = (
            df.groupBy(ID_column)
            .count()
            .where(f.col("count") >= f.lit(2))
            .persist(StorageLevel.DISK_ONLY)
        )

        validation_utils.red_amber_validation_logic(
            check=df_distinct_ID.count() == df.count(),
            on_success_message="The table has unique ID values.",
            on_success_action=None,
            on_error_message=f"The values in the ID column ({ID_column!r}) are not unique.",
            on_error_action=df_count_duplicate_ID.display,
            on_error_validation_level="RED",
            **kwargs,
        )


# COMMAND ----------

# MAGIC %md
# MAGIC # Main

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks

# COMMAND ----------

quality_checks = [check_null_proportion, check_boolean_columns, check_ID_column]

errors = []
for gold_table, column_prefix_list in zip(GOLD_TABLE_PATHS, COLUMN_PREFIXES):
    log.info("=" * 50)
    log.info(f"Self service standards quality check for table {gold_table!r}:")

    df = spark.read.table(gold_table)
    df_exposed = df.select(*column_list_to_expose(df.columns, column_prefix_list))

    for quality_check in quality_checks:
        try:
            quality_check(df_exposed, table_name=gold_table)
        except AssertionError as e:
            errors.append(e)
            continue

if errors:
    log.info("=" * 50)
    log.critical("Summary of all self service standards quality check errors found:")
    for error in errors:
        log.critical(error)

    raise AssertionError("There are some errors.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Select columns and save tables to self-service catalog as tables

# COMMAND ----------

for gold_table, column_prefix_list in zip(GOLD_TABLE_PATHS, COLUMN_PREFIXES):
    self_service_table = gold_table.replace(
        f"{PIPELINE_READ_ENV}_gold", f"{PIPELINE_WRITE_ENV}_selfservice"
    )

    df = spark.read.table(gold_table)
    df_exposed = df.select(*column_list_to_expose(df.columns, column_prefix_list))

    table_utils.save_table(
        dest_table=self_service_table,
        df=df_exposed,
        mode="overwrite",
        overwrite_schema=True,
    )

    log.info(
        f"Created the self-service table {self_service_table!r} using table {gold_table!r}."
    )
