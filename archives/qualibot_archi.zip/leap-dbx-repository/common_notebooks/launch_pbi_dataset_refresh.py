# Databricks notebook source
# MAGIC %md
# MAGIC # POWER BI Refresh from Databricks
# MAGIC The aim of this notebook is to refresh one Power BI dataset from its dataset_id and workspace_id
# MAGIC
# MAGIC You can retrieve these information from Power BI dataset URL. When clicking on the dataset from the PowerBI workspace, the URL format is : ```https://app.powerbi.com/groups/<workspace_id>/datasets/<dataset_id>```
# MAGIC
# MAGIC This notebook uses the PowerBI API to make a "POST" request to refresh the desired dataset.
# MAGIC
# MAGIC **Prerequisite on PowerBI side** :
# MAGIC - The "Access-APP-PBI-API" group should be added as a member of the PowerBI workspace in order to get the grants for refreshing the dataset.
# MAGIC
# MAGIC **Library prerequisite** : 
# MAGIC - Install **msal** library

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Package Imports
# MAGIC **External library requirement** : msal

# COMMAND ----------

import msal
import requests
import pandas as pd

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task Environment Variables
# MAGIC
# MAGIC - **WORKSPACE_ID** -> Used for specifying the ID of the Power BI workspace
# MAGIC - **DATASET_ID** -> Used for specifying the ID of the Power BI dataset to refresh

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("workspace_id", "")
WORKSPACE_ID = dbutils.widgets.get("workspace_id")

dbutils.widgets.text("dataset_id", "")
DATASET_ID = dbutils.widgets.get("dataset_id")

# COMMAND ----------

# MAGIC %md
# MAGIC ## PowerBI API configuration

# COMMAND ----------

client_id = dbutils.secrets.get(scope="power-bi-api", key="client_id")
client_secret = dbutils.secrets.get(scope="power-bi-api", key="client_secret") 
tenant_id = dbutils.secrets.get(scope="power-bi-api", key="tenant_id")

authority_url = "https://login.microsoftonline.com/" + tenant_id
scope = ["https://analysis.windows.net/powerbi/api/.default"]
url = "https://api.powerbi.com/v1.0/myorg/groups/" + WORKSPACE_ID +"/datasets/" + DATASET_ID + "/refreshes"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Launch the dataset refresh

# COMMAND ----------

# Generate an access token
app = msal.ConfidentialClientApplication(client_id, authority=authority_url, client_credential=client_secret)
result = app.acquire_token_for_client(scopes=scope)

# Use a POST request for refreshing the corresponding dataset
access_token = result['access_token']
header = {'Content-Type':'application/json', 'Authorization':f'Bearer {access_token}'}

# Refresh the power BI dataset
api_call = requests.post(url=url, headers=header)

# Raise an HTTPError if the request returned an unsuccessful status code.
api_call.raise_for_status()
    
