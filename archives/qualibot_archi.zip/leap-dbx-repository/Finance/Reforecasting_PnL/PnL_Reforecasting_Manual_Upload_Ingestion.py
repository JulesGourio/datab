# Databricks notebook source
# MAGIC %md
# MAGIC # P&L BUDGET REFORECASTING MANUAL FILE INGESTION 
# MAGIC
# MAGIC ADAPTED FROM SAP FC CONSO INGESTION

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

import datetime

import pyspark.pandas as ps
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f
from pyspark.sql.utils import AnalysisException

from leap_utils.common import logger
from leap_utils.config import spark
from leap_utils.data_asset import table_utils
from leap_utils.ingestion import ingestion_utils

# COMMAND ----------

# MAGIC %md
# MAGIC # Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "uat")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("overwrite_schema", "False")
OVERWRITE_SCHEMA = dbutils.widgets.get("overwrite_schema")


dbutils.widgets.text("force_data_asset_computation", "False")
FORCE_DATA_ASSET_COMPUTATION = (
    dbutils.widgets.get("force_data_asset_computation").lower() == "true"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Setup logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup", None):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "Reforcasting Manual Ingestion"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC # Constants

# COMMAND ----------

INGESTION_S3_BUCKET = f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/"

INGESTION_S3_FOLDER_PATH = "manual/leapdepot/UC16_PNL_REPORTING/REFORECAST/"

INGESTION_S3_BUCKET_PATH = f"{INGESTION_S3_BUCKET}/{INGESTION_S3_FOLDER_PATH}"

INGESTION_S3_BUCKET_ARCHIVE_PATH = (
    f"{INGESTION_S3_BUCKET}/archive/{INGESTION_S3_FOLDER_PATH}"
)
# FILENAME = r".*\.(xlsx|xlsm)$"
FILENAME_WITH_TIMESTAMP_REGEX = r"^(\d{8}\_\d{6})\_.*\.(xlsx|xlsm)$"

# COMMAND ----------

# TODO - PARAMETERISE WITH WRITE ENVS AND MOVE TO GOOD CATALOGUE
TARGET_TABLE_DICTIONARY = {
    "REFORECAST": f"{PIPELINE_WRITE_ENV}_proj.profit_and_loss.site_pnl_reforecast",
}

# COMMAND ----------

# MAGIC %md
# MAGIC # Read SAP FC excel files from leapdepot

# COMMAND ----------

# MAGIC %md
# MAGIC ## Find files to ingest

# COMMAND ----------

df_file_list = ingestion_utils.create_dbutils_ls_dataframe(INGESTION_S3_BUCKET_PATH)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_file_list.display()

# COMMAND ----------

df_file_list.toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Keep only file names that matches leap depot timestamps and excel files

# COMMAND ----------

# OVERWRITE DURING TESTING AS NON TIMESTAMP
# FILENAME_WITH_TIMESTAMP_REGEX = r".*\.xlsx$"

df_files_to_ingest = df_file_list.where(f.regexp_like(f.col("name"), f.lit(FILENAME_WITH_TIMESTAMP_REGEX)))


if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_files_to_ingest.display()

# COMMAND ----------

df_files_to_ingest.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stop ingestion if there is no files to ingest

# COMMAND ----------

files_to_ingest = df_files_to_ingest.count() > 0

compute_data_asset = files_to_ingest | FORCE_DATA_ASSET_COMPUTATION

dbutils.jobs.taskValues.set("compute_data_asset", compute_data_asset)

if not files_to_ingest:
    dbutils.notebook.exit("No files to ingest")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ingest all files with pandas on spark

# COMMAND ----------

def ExcelSheetToDataframeStack(sheet_i, df_files_to_ingest):
    df_ingested_files = spark.createDataFrame(
        data=[],
        schema=(
            "_meta_filepath string, "
            "_meta_filename string, "
            "_meta_modification_timestamp timestamp, "
            "_meta_ingestion_timestamp timestamp, "
            "_meta_leapdepot_timestamp timestamp"
        ),
    )

    ingestion_timestamp = datetime.datetime.now(tz=datetime.timezone.utc)

    for file in df_files_to_ingest.collect():
        log.info("Reading file %s at: %s", file.name, file.path)
        # noinspection PyTypeChecker
        df_sheet_i = (
            ps.read_excel(
                file.path,
                sheet_name=sheet_i,
                # header=None,
                # names=["AC", "DP", "RU", "Amt"],
                # usecols="A:C,E",
                # dtype="object",
                # skiprows=[0, 1],
                keep_default_na=False,
                na_values=[],
                dtype=str,
            )
        ).to_spark()

        metadata_columns = {
            "_meta_filepath": f.lit(file.path),
            "_meta_filename": f.lit(file.name),
            "_meta_modification_timestamp": f.to_utc_timestamp(
                f.lit(file.modification_timestamp), "UTC"
            ),
            "_meta_ingestion_timestamp": f.to_utc_timestamp(
                f.lit(ingestion_timestamp), "UTC"
            ),
            "_meta_leapdepot_timestamp": f.to_utc_timestamp(
                f.to_timestamp_ntz(
                    f.regexp_extract(
                        f.col("_meta_filename"),
                        pattern=FILENAME_WITH_TIMESTAMP_REGEX,
                        idx=1,
                    ),
                    f.lit("yyyyMMdd_HHmmss"),
                ),
                "Europe/Paris",
            ),
        }

        df_sheet_i = df_sheet_i.withColumns(metadata_columns).withColumn(
            "reforecast_year_type",
            f.concat(
                f.concat(
                    f.col("fiscal_year"),
                    f.lit("_Reforecast")),
                f.regexp_replace(
                    f.regexp_extract(f.col("budget_version"), "[0-9]{1,2}-[0-9]{1,2}", 0),
                    "-",
                    "_"
                ),
            )
        )

        df_ingested_files = df_ingested_files.unionByName(
            df_sheet_i, allowMissingColumns=True
        )

        log.info("Finished reading file %s\n", file.name)

    return df_ingested_files

# COMMAND ----------

# Extractions across all files per sheet. Creates a dictionary of dataframes per sheet across all files to be ingested.

extraction_dict = {
    "REFORECAST": ExcelSheetToDataframeStack("Reforecast_Matrix", df_files_to_ingest),
}

# COMMAND ----------

# MAGIC %md
# MAGIC # Add or replace ingested files in a stack table

# COMMAND ----------

TARGET_TABLE_DICTIONARY

# COMMAND ----------

# CreateOrGetOldStack
def CreateStackWithPreviousData(sheet_i, df_ingested_files):
    ## Get Previous Stack if Exists If not empty df with good schema
    try:
        df_sheet_i_old_stack = spark.read.table(TARGET_TABLE_DICTIONARY[sheet_i])
        df_sheet_i_old_stack.limit(1).collect()

    except AnalysisException as e:
        if e.getErrorClass() == "TABLE_OR_VIEW_NOT_FOUND":
            df_sheet_i_old_stack = spark.createDataFrame(
                data=[], schema=df_ingested_files.schema
            )
        else:
            raise AssertionError(
                "Something went wrong when trying to read "
                "the SAP FC consolidation stack table."
            ) from e

    if log.level <= logger.LOGGER_MAPPING["debug"]:
        df_sheet_i_old_stack.display()

    ## Remove already ingested files in old stack (i.e. to replace them)
    df_ingested_filetypes = df_ingested_files.select("reforecast_year_type").distinct()

    ingested_filenames_to_replace = list(df_ingested_filetypes.toPandas()["reforecast_year_type"])

    if log.level <= logger.LOGGER_MAPPING["debug"]:
        df_ingested_filetypes.display()

    df_sheet_i_stack_filtered = df_sheet_i_old_stack.where(
        ~f.col("reforecast_year_type").isin(*[val for val in ingested_filenames_to_replace])
    )

    if log.level <= logger.LOGGER_MAPPING["debug"]:
        df_sheet_i_stack_filtered.display()

    # Append on to old stack to create New Stack to save

    df_sheet_i_new_stack = df_sheet_i_stack_filtered.unionByName(
        df_ingested_files, allowMissingColumns=True
    )

    if log.level <= logger.LOGGER_MAPPING["debug"]:
        df_sheet_i_new_stack.display()

    ## Assign Filenames to list
    df_ingested_filetypes_names = df_ingested_files.select("_meta_filename").distinct()

    ingested_filenames = list(df_ingested_filetypes_names.toPandas()["_meta_filename"])

    return df_sheet_i_new_stack, ingested_filenames

# COMMAND ----------

df_head = extraction_dict["REFORECAST"]

# COMMAND ----------

extraction_stack_dict = {}
ingested_file_names = []

for sheet_i, df_ingested_files in extraction_dict.items():
    df_i, ingested_filenames_i = CreateStackWithPreviousData(sheet_i, df_ingested_files)
    extraction_stack_dict.update({sheet_i: df_i})
    ingested_file_names += ingested_filenames_i

ingested_file_names = list(set(ingested_file_names))

# COMMAND ----------

# display(ingested_file_names)

# COMMAND ----------

# MAGIC %md
# MAGIC # Save new stack

# COMMAND ----------

for sheet_i, df_sheet_i_new_stack in extraction_stack_dict.items():
    display(TARGET_TABLE_DICTIONARY[sheet_i], df_sheet_i_new_stack)

# COMMAND ----------

## Save each table

for sheet_i, df_sheet_i_new_stack in extraction_stack_dict.items():
    table_utils.save_table(
        TARGET_TABLE_DICTIONARY[sheet_i],
        df_sheet_i_new_stack,
        mode="overwrite",
        overwrite_schema=OVERWRITE_SCHEMA,
    )

# COMMAND ----------

TARGET_TABLE_DICTIONARY

# COMMAND ----------

# MAGIC %md
# MAGIC # Archive ingested files in the archive folder

# COMMAND ----------

for filename in ingested_file_names:
    dbutils.fs.mv(
        f"{INGESTION_S3_BUCKET_PATH}/{filename}",
        f"{INGESTION_S3_BUCKET_ARCHIVE_PATH}/{filename}",
    )
    display(filename)
