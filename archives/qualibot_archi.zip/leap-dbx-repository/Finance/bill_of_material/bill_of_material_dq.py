# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC WORK IN PROGRESS - not used  
# MAGIC Data Quality tests  
# MAGIC Based on the parameter value that indicates what kind of tests to perform ("on_load", "daily", "weekly", "monthly"), run some data quality tests on the table and store results in the Data Quality Service Level Indicators (DQ_SLIs) table.  
# MAGIC So Data Quality can be shared widely, the DQ_SLIs table must not include any sensitive data. So include only normalized indicators (between O and 1, 1 meaning Good) and do not include any sensitive information in the details.  
# MAGIC Inserts data to the output tables  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC control.DQ_SLIs  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC gold_finance_as.bill_of_material  
# MAGIC 
# MAGIC **Triggers:**    
# MAGIC DQfunctions notebook  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC bill_of_material notebook  
# MAGIC 
# MAGIC **TODO:**  
# MAGIC Complete this notebook  
# MAGIC Add a Data Quality cell at the end of bill_of_material notebook to run this notebook on each bill_of_material notebook run

# COMMAND ----------

# MAGIC %md
# MAGIC # Initialize

# COMMAND ----------

# MAGIC %run /Utils/includes/DQfunctions

# COMMAND ----------

# Dataset characteristics, that will be included in SQL strings

domain    = 'gold_finance_as'
subdomain = 'bill_of_material' 
product   = 'bill_of_material'
functional_key = 'phase, product, month, divi, material'

# To adapt when the naming is set
full_table_name = domain + '.' + product

# COMMAND ----------

# MAGIC %md
# MAGIC # Perform standard tests

# COMMAND ----------

dfSLIs = get_SLIs_dataframe()

if dbutils.widgets.get("tests_to_perform") in ('on_load'): 
    
    dfSLIs = check_no_duplicates_in_functional_key(full_table_name, functional_key, dfSLIs)
    dfSLIs = check_no_nulls_in_functional_key(full_table_name, functional_key, dfSLIs)

# COMMAND ----------

# MAGIC %md
# MAGIC # Perform specific tests

# COMMAND ----------

# Here is a template

# sli_df = sli_df.union(spark.sql(f"""

#      With tmp as
#     ( select count(1) CountTotal
#            , sum(case when isnull(concat({key})) then 1 else 0 end) countKO
#       from {table}
#     )
#     select 'PK_CheckNoNullValues' name
#          , 1 - ( countKO / CountTotal ) value
#          , concat(countKO, ' null value(s) found in dataset logical PK.') details
#     from tmp
#     """))
    

# COMMAND ----------

# MAGIC %md
# MAGIC # Write tests results 

# COMMAND ----------

write_tests_results_to_SLIs_table(dfSLIs)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC delete from  control.DQ_LOGs where lower(domain) = 'finance' and lower(subdomain) = 'budget' and lower(product) ='cost_in_bom_internal'

# COMMAND ----------

# When the notebook is called with "recreate_SLOs", it runs this cell and recreates the entries for the Service Level Objectives

if dbutils.widgets.get("tests_to_perform") in ("recreate_SLOs"): 
    spark.sql(f"delete from control.DQ_SLOs where domain = '{domain}' and subdomain = '{subdomain}' and product ='{product}'")

    spark.sql(f"""insert into control.DQ_SLOs (domain,     subdomain,     product,     slo_name,                      slo_description,                                     sli_name,             slo_threshold, slo_start_date,  
                                           slo_end_date)
                                       select '{domain}', '{subdomain}', '{product}', 'No duplicates in functional PK', 'Inspect logical PK and verify no duplicate exists', 'PK_CheckNoDuplicates', 1,             to_date('01/01/2020', 'MM/dd/yyyy'), 
                                           to_date('31/12/2100', 'dd/MM/yyyy')""")

    spark.sql(f"""insert into control.DQ_SLOs (domain,     subdomain,     product,     slo_name,                      slo_description,                                     sli_name,             slo_threshold, slo_start_date,  
                                           slo_end_date)
                                       select '{domain}', '{subdomain}', '{product}', 'No null values in functional PK', 'Inspect logical PK and verify no null values exist', 'PK_CheckNoNullValues', 1,             to_date('01/01/2020', 'MM/dd/yyyy'), 
                                           to_date('31/12/2100', 'dd/MM/yyyy')""")

    spark.sql(f"""insert into control.DQ_SLOs (domain,     subdomain,     product,    slo_name,                 slo_description,                  sli_name,               slo_threshold, slo_start_date,  
                                           slo_end_date)
                                       select '{domain}', '{subdomain}', '{product}', 'Dataset_refresh_daily', 'Verify dataset is updated daily', 'No corresponding SLI', null,          to_date('01/01/2020', 'MM/dd/yyyy'), 
                                           to_date('31/12/2100', 'dd/MM/yyyy')""")

# COMMAND ----------

# Commands used to create or remove the widget
# Recreate_SLOs will recreate all SLOs

# dbutils.widgets.remove("tests_to_perform")
# dbutils.widgets.dropdown("tests_to_perform", "on_load", ["on_load", "daily", "weekly", "monthly", "recreate_SLOs"])
