# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Selects most recent rows for each ingested BOM  
# MAGIC Builds bill_of_material table adding fields from BOM filename and material characteristics fields, and duplicating rows from budget (annual) BOMs (vs. actual monthly BOMs) over each month of a BOM year  
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC gold_finance_as.bill_of_material
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC brnz_sap.co_msp_noec  
# MAGIC slvr_finance_as.ref_product  
# MAGIC slvr_finance_as.ref_material_characteristics  
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %md
# MAGIC # Process

# COMMAND ----------

# MAGIC %md
# MAGIC ## Fields from filename
# MAGIC product_id, actual_budget, validity_date_yyyymm

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Add fields from BOM filename (product_id, actual_budget, validity_date_yyyymm)
# MAGIC CREATE OR REPLACE TEMPORARY VIEW boms_tmp
# MAGIC AS
# MAGIC WITH ranked_boms AS (  -- Selects most recent rows for each ingested BOM
# MAGIC   SELECT *
# MAGIC     , dense_rank() OVER (PARTITION BY lower(filename) ORDER BY ingestion_timestamp DESC) ingestion_rank
# MAGIC   FROM brnz_sap.co_msp_noec
# MAGIC )
# MAGIC SELECT
# MAGIC   filename
# MAGIC   , CASE
# MAGIC         WHEN initcap(element_at(split(filename, "_"), 5)) = "Budget" THEN NULL
# MAGIC         WHEN length(element_at(split(filename, "_"), 5)) = 1 THEN concat(element_at(split(filename, "_"), 4), "0", element_at(split(filename, "_"), 5))
# MAGIC         ELSE concat(element_at(split(filename, "_"), 4), element_at(split(filename, "_"), 5))
# MAGIC       END validity_date_yyyymm
# MAGIC   , CASE WHEN initcap(element_at(split(filename, "_"), 5)) = "Budget" THEN "budget" ELSE "actual" END actual_budget
# MAGIC   , p.product_id
# MAGIC   , divi plant
# MAGIC   , ltrim("0", material) part_number
# MAGIC   , designation part_number_description
# MAGIC   , bom_quantity
# MAGIC   , uni unit
# MAGIC   , std_price
# MAGIC   , flow_cha
# MAGIC   , mat_chara material_characteristics
# MAGIC   , mrp_c mrp_controller
# MAGIC   , purcha
# MAGIC   , prod_st
# MAGIC   , supply
# MAGIC   , ext_su
# MAGIC   , plant_s
# MAGIC   , takt_t
# MAGIC   , specia
# MAGIC   , backflus
# MAGIC   , i_c
# MAGIC   , scheduli
# MAGIC   , procu procurement_type
# MAGIC   , class
# MAGIC   , lev bom_level
# MAGIC   , rank
# MAGIC   , rtg_ind
# MAGIC   , use
# MAGIC   , mrp
# MAGIC   , lot_siz
# MAGIC   , lot_size
# MAGIC   , round
# MAGIC   , bom_sto
# MAGIC   , bulk
# MAGIC   , need
# MAGIC   , predecessor
# MAGIC   , receipt_time
# MAGIC   , safety_time
# MAGIC   , opening_period
# MAGIC   , float_after_p
# MAGIC   , float_befo
# MAGIC   , posit_delay
# MAGIC   , oper_lt_offset
# MAGIC   , oper_lt_offset_unit
# MAGIC   , distribution_key
# MAGIC   , phantom_item
# MAGIC   , explosion_type
# MAGIC   , special_procurement
# MAGIC   , father_operation_nbr
# MAGIC   , kanban_supply_area
# MAGIC   , ingestion_timestamp
# MAGIC FROM ranked_boms r
# MAGIC INNER JOIN slvr_finance_as.ref_product p ON lower(p.product_id) = lower(element_at(split(r.filename, "_"), 3))  -- to keep only products in trusted.products
# MAGIC WHERE ingestion_rank = 1  -- select the most recent file ingested for each BOM from raw
# MAGIC ;
# MAGIC 
# MAGIC -- SELECT * FROM boms_tmp

# COMMAND ----------

# MAGIC %md
# MAGIC ## Material characteristics
# MAGIC skill, manufacturing_process, assembly_level raw_material, size, class_std, family_std

# COMMAND ----------

# MAGIC %md
# MAGIC ### 9 characters
# MAGIC skill, manufacturing_process, assembly_level raw_material, size

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Add material characteristics fields (skill, manufacturing_process, assembly_level raw_material, size) for rows with material_characteristics on 9 characters
# MAGIC CREATE OR REPLACE TEMPORARY VIEW nine_mat_char_tmp
# MAGIC AS
# MAGIC WITH skill AS (
# MAGIC   SELECT val_char skill_id, desc_char skill
# MAGIC   FROM slvr_finance_as.ref_material_characteristics
# MAGIC   WHERE field = "Skill"
# MAGIC ),
# MAGIC manufacturing_process AS (
# MAGIC   SELECT val_char manufacturing_process_id, desc_char manufacturing_process
# MAGIC   FROM slvr_finance_as.ref_material_characteristics
# MAGIC   WHERE field = "Manufacturing process"
# MAGIC ),
# MAGIC assembly_level AS (
# MAGIC   SELECT val_char assembly_level_id, desc_char assembly_level
# MAGIC   FROM slvr_finance_as.ref_material_characteristics
# MAGIC   WHERE field = "Assembly Level"
# MAGIC ),
# MAGIC raw_material AS (
# MAGIC   SELECT val_char raw_material_id, desc_char raw_material
# MAGIC   FROM slvr_finance_as.ref_material_characteristics
# MAGIC   WHERE field = "Raw Material"
# MAGIC ),
# MAGIC size AS (
# MAGIC   SELECT val_char size_id, desc_char size
# MAGIC   FROM slvr_finance_as.ref_material_characteristics
# MAGIC   WHERE field = "Size"
# MAGIC )
# MAGIC SELECT
# MAGIC   b.filename
# MAGIC   , b.validity_date_yyyymm
# MAGIC --   , b.item_id
# MAGIC   , b.actual_budget
# MAGIC   , b.product_id
# MAGIC   , b.plant
# MAGIC   , b.part_number
# MAGIC   , b.part_number_description
# MAGIC   , b.bom_quantity
# MAGIC   , b.unit
# MAGIC   , b.std_price
# MAGIC   , b.flow_cha
# MAGIC   , b.material_characteristics
# MAGIC   , s.skill
# MAGIC   , m.manufacturing_process
# MAGIC   , a.assembly_level
# MAGIC   , r.raw_material
# MAGIC   , si.size
# MAGIC   , null class_std
# MAGIC   , null family_std
# MAGIC   , b.mrp_controller
# MAGIC   , b.purcha
# MAGIC   , b.prod_st
# MAGIC   , b.supply
# MAGIC   , b.ext_su
# MAGIC   , b.plant_s
# MAGIC   , b.takt_t
# MAGIC   , b.specia
# MAGIC   , b.backflus
# MAGIC   , b.i_c
# MAGIC   , b.scheduli
# MAGIC   , b.procurement_type
# MAGIC   , b.class
# MAGIC   , b.bom_level
# MAGIC   , b.rank
# MAGIC   , b.rtg_ind
# MAGIC   , b.use
# MAGIC   , b.mrp
# MAGIC   , b.lot_siz
# MAGIC   , b.lot_size
# MAGIC   , b.round
# MAGIC   , b.bom_sto
# MAGIC   , b.bulk
# MAGIC   , b.need
# MAGIC   , b.predecessor
# MAGIC   , b.receipt_time
# MAGIC   , b.safety_time
# MAGIC   , b.opening_period
# MAGIC   , b.float_after_p
# MAGIC   , b.float_befo
# MAGIC   , b.posit_delay
# MAGIC   , b.oper_lt_offset
# MAGIC   , b.oper_lt_offset_unit
# MAGIC   , b.distribution_key
# MAGIC   , b.phantom_item
# MAGIC   , b.explosion_type
# MAGIC   , b.special_procurement
# MAGIC   , b.father_operation_nbr
# MAGIC   , b.kanban_supply_area
# MAGIC FROM boms_tmp b
# MAGIC LEFT JOIN skill s ON s.skill_id = substring(b.material_characteristics, 1, 1)
# MAGIC LEFT JOIN manufacturing_process m ON m.manufacturing_process_id = substring(b.material_characteristics, 2, 2)
# MAGIC LEFT JOIN assembly_level a ON a.assembly_level_id = substring(b.material_characteristics, 4, 2)
# MAGIC LEFT JOIN raw_material r ON r.raw_material_id = substring(b.material_characteristics, 6, 2)
# MAGIC LEFT JOIN size si ON si.size_id = substring(b.material_characteristics, 8, 2)
# MAGIC WHERE LENGTH(b.material_characteristics) = 9
# MAGIC ;
# MAGIC 
# MAGIC -- SELECT * FROM nine_mat_char_tmp

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4 characters
# MAGIC class_std, family_std

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Add material characteristics fields (class_std, family_std) for rows with material_characteristics on 4 characters
# MAGIC CREATE OR REPLACE TEMPORARY VIEW four_mat_char_tmp
# MAGIC AS
# MAGIC WITH class_std AS (
# MAGIC   SELECT val_char class_std_id, desc_char class_std
# MAGIC   FROM slvr_finance_as.ref_material_characteristics
# MAGIC   WHERE field = "Class -STD"
# MAGIC ),
# MAGIC family_std AS (
# MAGIC   SELECT val_char family_std_id, desc_char family_std
# MAGIC   FROM slvr_finance_as.ref_material_characteristics
# MAGIC   WHERE field = "Family -STD"
# MAGIC )
# MAGIC SELECT
# MAGIC   b.filename
# MAGIC   , b.validity_date_yyyymm
# MAGIC --   , b.item_id
# MAGIC   , b.actual_budget
# MAGIC   , b.product_id
# MAGIC   , b.plant
# MAGIC   , b.part_number
# MAGIC   , b.part_number_description
# MAGIC   , b.bom_quantity
# MAGIC   , b.unit
# MAGIC   , b.std_price
# MAGIC   , b.flow_cha
# MAGIC   , b.material_characteristics
# MAGIC   , null skill
# MAGIC   , null manufacturing_process
# MAGIC   , null assembly_level
# MAGIC   , null raw_material
# MAGIC   , null size
# MAGIC   , c.class_std
# MAGIC   , f.family_std
# MAGIC   , b.mrp_controller
# MAGIC   , b.purcha
# MAGIC   , b.prod_st
# MAGIC   , b.supply
# MAGIC   , b.ext_su
# MAGIC   , b.plant_s
# MAGIC   , b.takt_t
# MAGIC   , b.specia
# MAGIC   , b.backflus
# MAGIC   , b.i_c
# MAGIC   , b.scheduli
# MAGIC   , b.procurement_type
# MAGIC   , b.class
# MAGIC   , b.bom_level
# MAGIC   , b.rank
# MAGIC   , b.rtg_ind
# MAGIC   , b.use
# MAGIC   , b.mrp
# MAGIC   , b.lot_siz
# MAGIC   , b.lot_size
# MAGIC   , b.round
# MAGIC   , b.bom_sto
# MAGIC   , b.bulk
# MAGIC   , b.need
# MAGIC   , b.predecessor
# MAGIC   , b.receipt_time
# MAGIC   , b.safety_time
# MAGIC   , b.opening_period
# MAGIC   , b.float_after_p
# MAGIC   , b.float_befo
# MAGIC   , b.posit_delay
# MAGIC   , b.oper_lt_offset
# MAGIC   , b.oper_lt_offset_unit
# MAGIC   , b.distribution_key
# MAGIC   , b.phantom_item
# MAGIC   , b.explosion_type
# MAGIC   , b.special_procurement
# MAGIC   , b.father_operation_nbr
# MAGIC   , b.kanban_supply_area
# MAGIC FROM boms_tmp b
# MAGIC LEFT JOIN class_std c ON c.class_std_id = substring(b.material_characteristics, 1, 2)
# MAGIC LEFT JOIN family_std f ON f.family_std_id = substring(b.material_characteristics, 3, 2)
# MAGIC WHERE LENGTH(b.material_characteristics) = 4
# MAGIC ;
# MAGIC 
# MAGIC -- SELECT * FROM four_mat_char_tmp

# COMMAND ----------

# MAGIC %md
# MAGIC ### Union all

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW boms_mat_char_tmp
# MAGIC AS
# MAGIC WITH other_mat_char_tmp AS (
# MAGIC   SELECT
# MAGIC     filename
# MAGIC     , validity_date_yyyymm
# MAGIC --     , item_id
# MAGIC     , actual_budget
# MAGIC     , product_id
# MAGIC     , plant
# MAGIC     , part_number
# MAGIC     , part_number_description
# MAGIC     , bom_quantity
# MAGIC     , unit
# MAGIC     , std_price
# MAGIC     , flow_cha
# MAGIC     , material_characteristics
# MAGIC     , null skill
# MAGIC     , null manufacturing_process
# MAGIC     , null assembly_level
# MAGIC     , null raw_material
# MAGIC     , null size
# MAGIC     , null class_std
# MAGIC     , null family_std
# MAGIC     , mrp_controller
# MAGIC     , purcha
# MAGIC     , prod_st
# MAGIC     , supply
# MAGIC     , ext_su
# MAGIC     , plant_s
# MAGIC     , takt_t
# MAGIC     , specia
# MAGIC     , backflus
# MAGIC     , i_c
# MAGIC     , scheduli
# MAGIC     , procurement_type
# MAGIC     , class
# MAGIC     , bom_level
# MAGIC     , rank
# MAGIC     , rtg_ind
# MAGIC     , use
# MAGIC     , mrp
# MAGIC     , lot_siz
# MAGIC     , lot_size
# MAGIC     , round
# MAGIC     , bom_sto
# MAGIC     , bulk
# MAGIC     , need
# MAGIC     , predecessor
# MAGIC     , receipt_time
# MAGIC     , safety_time
# MAGIC     , opening_period
# MAGIC     , float_after_p
# MAGIC     , float_befo
# MAGIC     , posit_delay
# MAGIC     , oper_lt_offset
# MAGIC     , oper_lt_offset_unit
# MAGIC     , distribution_key
# MAGIC     , phantom_item
# MAGIC     , explosion_type
# MAGIC     , special_procurement
# MAGIC     , father_operation_nbr
# MAGIC     , kanban_supply_area
# MAGIC   FROM boms_tmp
# MAGIC   WHERE LENGTH(material_characteristics) != 4 AND LENGTH(material_characteristics) != 9
# MAGIC )
# MAGIC SELECT * FROM nine_mat_char_tmp
# MAGIC UNION ALL
# MAGIC SELECT * FROM four_mat_char_tmp
# MAGIC UNION ALL
# MAGIC SELECT * FROM other_mat_char_tmp
# MAGIC ;
# MAGIC 
# MAGIC -- SELECT * FROM boms_mat_char_tmp

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add budget rows

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW boms_actual_tmp
# MAGIC AS
# MAGIC select *
# MAGIC from boms_mat_char_tmp
# MAGIC where actual_budget = "actual";
# MAGIC 
# MAGIC -- select * from boms_actual_tmp

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Duplicate rows from budget (annual) BOMs (vs. actual monthly BOMs) over each month of a BOM year
# MAGIC CREATE OR REPLACE TEMPORARY VIEW boms_budget_tmp
# MAGIC AS
# MAGIC select
# MAGIC     filename
# MAGIC     , m.validity_date_yyyymm
# MAGIC --     , item_id
# MAGIC     , actual_budget
# MAGIC     , product_id
# MAGIC     , plant
# MAGIC     , part_number
# MAGIC     , part_number_description
# MAGIC     , bom_quantity
# MAGIC     , unit
# MAGIC     , std_price
# MAGIC     , flow_cha
# MAGIC     , material_characteristics
# MAGIC     , skill
# MAGIC     , manufacturing_process
# MAGIC     , assembly_level
# MAGIC     , raw_material
# MAGIC     , size
# MAGIC     , class_std
# MAGIC     , family_std
# MAGIC     , mrp_controller
# MAGIC     , purcha
# MAGIC     , prod_st
# MAGIC     , supply
# MAGIC     , ext_su
# MAGIC     , plant_s
# MAGIC     , takt_t
# MAGIC     , specia
# MAGIC     , backflus
# MAGIC     , i_c
# MAGIC     , scheduli
# MAGIC     , procurement_type
# MAGIC     , class
# MAGIC     , bom_level
# MAGIC     , rank
# MAGIC     , rtg_ind
# MAGIC     , use
# MAGIC     , mrp
# MAGIC     , lot_siz
# MAGIC     , lot_size
# MAGIC     , round
# MAGIC     , bom_sto
# MAGIC     , bulk
# MAGIC     , need
# MAGIC     , predecessor
# MAGIC     , receipt_time
# MAGIC     , safety_time
# MAGIC     , opening_period
# MAGIC     , float_after_p
# MAGIC     , float_befo
# MAGIC     , posit_delay
# MAGIC     , oper_lt_offset
# MAGIC     , oper_lt_offset_unit
# MAGIC     , distribution_key
# MAGIC     , phantom_item
# MAGIC     , explosion_type
# MAGIC     , special_procurement
# MAGIC     , father_operation_nbr
# MAGIC     , kanban_supply_area
# MAGIC from boms_mat_char_tmp b
# MAGIC inner join ( -- take all months in the table that exist for actual and add a budget for that month
# MAGIC   select distinct validity_date_yyyymm 
# MAGIC   from boms_mat_char_tmp
# MAGIC   where actual_budget = "actual") m on LEFT(m.validity_date_yyyymm, 4) = element_at(split(b.filename, "_"), 4)
# MAGIC where b.actual_budget = "budget";

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW bill_of_material_tmp
# MAGIC AS
# MAGIC WITH complete_boms AS (
# MAGIC   SELECT * FROM boms_actual_tmp
# MAGIC   UNION ALL
# MAGIC   SELECT * FROM boms_budget_tmp
# MAGIC )
# MAGIC SELECT actual_budget phase, product_id product, validity_date_yyyymm month, plant divi, part_number material
# MAGIC      , max(part_number_description) designation
# MAGIC      , sum(bom_quantity) bom_quantity
# MAGIC      , max(unit) uni
# MAGIC      , max(material_characteristics) mat_chara
# MAGIC      , max(mrp_controller) mrp_c
# MAGIC      , max(specia) specia
# MAGIC      , max(procurement_type) procu
# MAGIC      , max(bom_level) lev
# MAGIC      , max(rank) rank
# MAGIC      , max(lot_size) lot_size
# MAGIC      , max(bulk) bulk
# MAGIC      , max(skill) skill
# MAGIC      , max(manufacturing_process) manufacturing_process
# MAGIC      , max(assembly_level) assembly_level
# MAGIC      , max(raw_material) raw_material
# MAGIC      , max(size) size
# MAGIC      , max(class_std) class_std
# MAGIC      , max(family_std) family_std
# MAGIC FROM complete_boms
# MAGIC group by actual_budget, product_id, validity_date_yyyymm, plant, part_number;

# COMMAND ----------

# MAGIC %md
# MAGIC # Write

# COMMAND ----------

table_zone = "gold_finance_as"
table_name = "bill_of_material"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC # Test

# COMMAND ----------

# %sql
# -- select count(*)
# select *
# from gold_finance_as.bill_of_material

# COMMAND ----------

# %sql

# WITH ranked_boms AS (  -- Select most recent rows for each filename from raw.boms
#   SELECT *
#     , dense_rank() OVER (PARTITION BY lower(filename) ORDER BY ingestion_timestamp DESC) ingestion_rank
#   FROM brnz_sap.co_msp_noec
# )
# select distinct filename from ranked_boms where ingestion_rank = 1
