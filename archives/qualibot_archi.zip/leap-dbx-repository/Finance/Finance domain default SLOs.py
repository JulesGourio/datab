# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Adds default values for some Service Level Objectives for Finance domain  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC control.DQ_SLOs  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC 
# MAGIC **Triggers:**    
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

domain    = 'finance'
subdomain = 'all subdomains' 
product   = 'all products'

# COMMAND ----------

# Insert, only once, SLOs for the SLIs

# spark.sql(f"delete from control.DQ_SLOs where domain = '{domain}' and subdomain = '{subdomain}' and product ='{product}'")

# spark.sql(f"""insert into control.DQ_SLOs (domain,     subdomain,     product,    slo_name,                   slo_description,                    sli_name,               slo_threshold, slo_start_date,  
#                                        slo_end_date)
#                                    select '{domain}', '{subdomain}', '{product}', 'Dataset_refresh_weekly', 'Verify dataset is updated weekly', 'No corresponding SLI', null,             to_date('01/01/2020', 'MM/dd/yyyy'), 
#                                        to_date('31/12/2100', 'MM/dd/yyyy')""")


# COMMAND ----------


