# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Aggregates budget values from SAP tables for Direct & Indirect costs of the BOM  
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC gold_finance_as.budgets_in_bom  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC slvr_sap.co_ckis  
# MAGIC slvr_sap.co_keko  
# MAGIC slvr_sap.pp_marc  
# MAGIC slvr_finance_as.currency_exchange_rates_budget    
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE FUNCTION rnegative_to_double(col STRING)
# MAGIC   RETURNS DOUBLE
# MAGIC   COMMENT 'Returns "-1.5" double if col is a string like "1.5-"'
# MAGIC   RETURN double(
# MAGIC         IF(
# MAGIC           RIGHT(col, 1) = '-'
# MAGIC           , concat('-', LEFT(col, length(col) - 1))
# MAGIC           , col
# MAGIC           )
# MAGIC       );

# COMMAND ----------

# MAGIC %md
# MAGIC # Process

# COMMAND ----------

# MAGIC %sql 
# MAGIC 
# MAGIC -- TODO ArL: Why is broadcasting not working (stats not positioned?)
# MAGIC set spark.sql.autoBroadcastJoinThreshold=-1 

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- As a first step, get the rows we need from the SAP tables. 
# MAGIC -- with adequate joins and filters to get data that will be reusable. 
# MAGIC 
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW RawCosts AS
# MAGIC select ltrim("0", k.MATNR) PartNumber
# MAGIC      , CASE WHEN m.SOBSL = '30' AND ltrim("0", c.KSTAR) = '71335101' THEN '60535101' ELSE ltrim("0", c.KSTAR) END CostElement
# MAGIC      , k.WERKS Plant
# MAGIC      , case when left(c.KSTAR, 1) = '9' then 'Internal' else c.LIFNR end Supplier
# MAGIC      , left(k.FREIDAT, 4) UnitCostYear
# MAGIC      , k.FREIDAT UnitCostDate
# MAGIC      , c.FWAER TransactionCurrency
# MAGIC      , max(k.LOSGR) CostQuantity        -- k is the header, we take max rather than sum
# MAGIC      , sum(rnegative_to_double(c.WRTFW_POS)) CostValue       -- c is the detail, so we take the sum
# MAGIC      , sum(case c.MEEHT when 'H' THEN rnegative_to_double(c.MENGE) when 'HRS' THEN rnegative_to_double(c.MENGE) when 'MIN' THEN rnegative_to_double(c.MENGE) /60 else null end) CostHours
# MAGIC from slvr_sap.co_ckis c
# MAGIC left join slvr_sap.co_keko k on k.MANDT = c.MANDT  -- akh: switched to left join to avoid losing rows not associated to part numbers (ex. RNREBE)
# MAGIC                  and k.BZOBJ = c.BZOBJ
# MAGIC                  and k.KALNR = c.KALNR
# MAGIC                  and k.KALKA = c.KALKA
# MAGIC                  and k.KADKY = c.KADKY
# MAGIC                  and k.TVERS = c.TVERS
# MAGIC                  and k.BWVAR = c.BWVAR
# MAGIC --                  and k.KKZMA = c.KKZMA  -- only null values so the join failed with this field
# MAGIC -- left join slvr_sap.pp_marc m on m.MANDT = c.MANDT   -- akh: switched to left join to avoid losing rows not associated to part numbers (ex. RNREBE)
# MAGIC --                  and m.MATNR = k.MATNR
# MAGIC --                  and m.WERKS = k.WERKS
# MAGIC left join slvr_sap.pp_marc m on m.MATNR = k.MATNR   -- akh: switched to left join to avoid losing rows not associated to part numbers (ex. RNREBE)
# MAGIC                  and m.WERKS = k.WERKS
# MAGIC where k.FREIDAT <> '00000000'
# MAGIC   and (   ((m.SOBSL is null or m.SOBSL = '52') and (left(ltrim("0", c.KSTAR), 1) in ('9', 'R')
# MAGIC                                                     or left(ltrim("0", c.KSTAR), 3) in ('61A', '68A')
# MAGIC                                                     or left(ltrim("0", c.KSTAR), 4) in ('6051', '6052'))) -- Limit for part numbers to be valorized with these special procurement (see spec)
# MAGIC        or (m.SOBSL in ('10', '20', '22') and not(left(ltrim("0", c.KSTAR), 1) in ('9', 'R')
# MAGIC                                                or left(ltrim("0", c.KSTAR), 3) in ('61A', '68A')
# MAGIC                                                or left(ltrim("0", c.KSTAR), 4) in ('6051', '6052')))
# MAGIC        or (m.SOBSL in ('30') and right(ltrim("0", c.KSTAR), 2) not in ('07'))
# MAGIC        or (left(ltrim("0", c.KSTAR), 6) = 'RNREBE')
# MAGIC       )  
# MAGIC group by PartNumber
# MAGIC      , CostElement
# MAGIC      , k.WERKS 
# MAGIC      , case when left(KSTAR, 1) = '9' then 'Internal' else c.LIFNR end 
# MAGIC      , left(k.FREIDAT, 4) 
# MAGIC      , k.FREIDAT 
# MAGIC      , c.FWAER

# COMMAND ----------

# MAGIC %sql
# MAGIC -- As a second step, keep the latest unit_price for each PartNumber/costElement/plant/supplier/year
# MAGIC -- and onvert the value to EUR
# MAGIC CREATE OR REPLACE TEMPORARY VIEW budgets_in_bom_tmp AS
# MAGIC with CostsWithRank as (
# MAGIC   select  PartNumber
# MAGIC        , CostElement
# MAGIC        , Plant
# MAGIC        , Supplier
# MAGIC        , UnitCostYear
# MAGIC        , TransactionCurrency
# MAGIC        , UnitCostDate
# MAGIC        , CostQuantity
# MAGIC        , CostValue
# MAGIC        , CostHours
# MAGIC        , RANK() OVER (PARTITION BY PartNumber, Plant, UnitCostYear ORDER BY UnitCostDate DESC) AS RankInYear
# MAGIC   from RawCosts
# MAGIC )
# MAGIC , currency_exchange_rates_tmp AS (
# MAGIC   SELECT year, source_currency, target_currency, rate
# MAGIC   FROM slvr_finance_as.currency_exchange_rates_budget
# MAGIC   WHERE target_currency = "EUR"
# MAGIC )
# MAGIC select c.PartNumber part_number
# MAGIC      , c.CostElement cost_element_id
# MAGIC      , c.Plant plant
# MAGIC      , c.Supplier supplier_id
# MAGIC      , c.UnitCostYear year
# MAGIC      , c.TransactionCurrency company_currency
# MAGIC      , c.UnitCostDate validity_date
# MAGIC      , c.CostQuantity lot_size
# MAGIC      , c.CostValue lot_size_cost
# MAGIC      , c.CostHours lot_size_hours
# MAGIC      , c.CostValue / curr.rate lot_size_cost_eur
# MAGIC from CostsWithRank c
# MAGIC inner join currency_exchange_rates_tmp curr on curr.source_currency = c.TransactionCurrency and curr.year = c.UnitCostYear
# MAGIC where RankInYear = 1 -- keep the latest standard price of the year 

# COMMAND ----------

# MAGIC %md
# MAGIC # Write

# COMMAND ----------

table_zone = "gold_finance_as"
table_name = "budgets_in_bom"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md 
# MAGIC # Test

# COMMAND ----------

# %sql
# -- select count(*)
# select *
# from gold_finance_as.budgets_in_bom
# WHERE year = 2022
#   and part_number = "F7XC544120301A3"
