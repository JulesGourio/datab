# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Aggregates budget values from budget manual file for Direct costs of the BOM exceptions (not managed with standard price in SAP)   
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC gold_finance_as.budgets_in_bom_exceptions  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC brnz_finance_as.budgets  
# MAGIC slvr_finance_as.currency_exchange_rates_budget  
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %md
# MAGIC # Process

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW budgets_in_bom_exceptions_tmp
# MAGIC AS
# MAGIC WITH ranked_budgets AS (  -- Select most recent rows for each key from budgets data ingested from manual file
# MAGIC   SELECT standard_price_date, product_id, ltrim("0", cost_element_id) cost_element_id, year, plant, mrp_controller, supplier_id, ltrim("0", part_number) part_number, currency, amount, quantity
# MAGIC     , DENSE_RANK() OVER(PARTITION BY standard_price_date, product_id, cost_element_id, year, plant, mrp_controller, supplier_id, part_number, currency ORDER BY ingestion_timestamp DESC) budget_rank
# MAGIC   FROM brnz_finance_as.budgets
# MAGIC )
# MAGIC , currency_exchange_rates_tmp AS ( -- select budget currency exchange rates to convert in euro
# MAGIC   SELECT year, source_currency, target_currency, rate
# MAGIC   FROM slvr_finance_as.currency_exchange_rates_budget
# MAGIC   WHERE target_currency = "EUR"
# MAGIC )
# MAGIC SELECT r.product_id :: string product_id
# MAGIC   , r.part_number :: string part_number
# MAGIC   , r.cost_element_id :: string cost_element_id
# MAGIC   , r.plant :: string plant
# MAGIC   , r.mrp_controller :: string mrp_controller
# MAGIC   , r.supplier_id :: string supplier_id
# MAGIC   , r.year :: int year
# MAGIC   , r.currency :: string company_currency
# MAGIC   , r.standard_price_date :: int validity_date
# MAGIC   , r.quantity :: double cost_quantity_per_product
# MAGIC   , r.amount :: double cost_value_per_product
# MAGIC   , r.amount / c.rate :: double cost_value_per_product_eur
# MAGIC FROM ranked_budgets r
# MAGIC left join currency_exchange_rates_tmp c on c.source_currency = r.currency and c.year = r.year
# MAGIC WHERE budget_rank = 1
# MAGIC   AND LEFT(r.cost_element_id, 9) NOT IN ("RNREBE091", "RNREBE092", "RNREBE093") -- to select only budgets_in_bom_exceptions rows and exclude budgets_out_of_bom rows
# MAGIC ;
# MAGIC 
# MAGIC -- SELECT * FROM budgets_in_bom_exceptions_tmp

# COMMAND ----------

# MAGIC %md
# MAGIC # Write

# COMMAND ----------

table_zone = "gold_finance_as"
table_name = "budgets_in_bom_exceptions"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC # Test

# COMMAND ----------

# %sql
# select *
# from gold_finance_as.budgets_in_bom_exceptions
# where product_id = "A3T"
# --   AND cost_element_id = "60580000"
