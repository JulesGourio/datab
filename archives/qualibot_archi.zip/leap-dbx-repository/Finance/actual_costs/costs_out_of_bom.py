# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Aggregates actual values from SAP tables for Direct & Indirect costs out of the BOM  
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC gold_finance_as.costs_out_of_bom  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC slvr_finance_as.currency_exchange_rates_actual  
# MAGIC slvr_sap.co_unpivoted_coss_cosp  
# MAGIC slvr_sap.pp_aufk  
# MAGIC slvr_sap.co_prps  
# MAGIC slvr_sap.pp_afpo  
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- select actual currency exchange rates to convert in euro
# MAGIC CREATE OR REPLACE TEMPORARY VIEW currency_exchange_rates_tmp
# MAGIC AS
# MAGIC SELECT validity_date_yyyymm, source_currency, target_currency, rate
# MAGIC FROM slvr_finance_as.currency_exchange_rates_actual
# MAGIC WHERE target_currency = "EUR"

# COMMAND ----------

# MAGIC %md
# MAGIC # Other direct & indirect costs not in the BOM
# MAGIC 1.5.4.3 Direct costs not included in the BOM Other  
# MAGIC 1.5.4.4 Direct & Indirect costs not included in the BOM RNREBE092x + RNREBE093x

# COMMAND ----------

# MAGIC %md
# MAGIC ## Process

# COMMAND ----------

# MAGIC %sql 
# MAGIC 
# MAGIC -- OTP (projects) costs of the month in € related to the product and cost element parameter
# MAGIC CREATE OR REPLACE TEMPORARY VIEW costs_not_in_the_bom
# MAGIC AS
# MAGIC select u.mandt
# MAGIC     , u.lednr
# MAGIC     , u.objnr
# MAGIC     , u.gjahr
# MAGIC     , u.wrttp
# MAGIC     , u.versn
# MAGIC     , u.kstar
# MAGIC     , u.vrgng
# MAGIC     , u.beknz
# MAGIC     , u.twaer
# MAGIC     , u.perbl
# MAGIC     , u.meinh
# MAGIC     , CASE
# MAGIC         WHEN LEFT(u.objnr, 2) = "OR" THEN aufk.BUKRS
# MAGIC         WHEN LEFT(u.objnr, 2) = "PR" THEN prps.PBUKR
# MAGIC       END company -- COSS/COSP.BUKRS is null sometimes, so we have to use aufk.BUKRS (for Work Orders) and prps.PBUKR (for Projects)
# MAGIC     , CASE
# MAGIC         WHEN LEFT(u.objnr, 2) = "OR" THEN
# MAGIC           CASE WHEN aufk.BUKRS IN ('LLVS', 'LLVA') THEN 'CZK' ELSE 'EUR' END
# MAGIC         WHEN LEFT(u.objnr, 2) = "PR" THEN
# MAGIC           CASE WHEN prps.PBUKR IN ('LLVS', 'LLVA') THEN 'CZK' ELSE 'EUR' END
# MAGIC       END currency -- Ignore TWAER as Currency, take the currency with a join to AUFK instead, LLVA and LLVS are the only companies in CZK and this is the only exception so we can hard-code it
# MAGIC     , CONCAT(u.gjahr, RIGHT(u.amtType, 2)) MONTH_ID
# MAGIC     , case when LEFT(u.amtType, 3) == 'wkg' then u.amt end valueInControllingAreaCurrency
# MAGIC     , case when LEFT(u.amtType, 3) == 'meg' and u.meinh in('H', 'HRS', 'MIN') then u.amt end totalQuantity    -- totalQuantity has to be null if MEINH is not in 'H', 'HRS', 'MIN'
# MAGIC FROM slvr_sap.co_unpivoted_coss_cosp u
# MAGIC LEFT JOIN slvr_sap.pp_aufk aufk on aufk.OBJNR = u.objnr AND aufk.MANDT = u.mandt
# MAGIC LEFT JOIN slvr_sap.co_prps prps on prps.OBJNR = u.objnr AND prps.MANDT = u.mandt
# MAGIC WHERE LEFT(u.objnr, 2) = "PR"
# MAGIC   AND u.versn = "000"
# MAGIC   AND u.wrttp = "04"
# MAGIC   AND (
# MAGIC     (u.beknz IN ("S", "H") AND u.vrgng IN ("COIN", "RKU3", "RKL", "KAMV", "KZPI", "RKLN"))
# MAGIC     OR (u.beknz = "S" AND u.vrgng IN ("RKIB", "RKIU"))
# MAGIC     )

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- WBS (projects) costs of the month not linked to production to be included in the product cost
# MAGIC CREATE OR REPLACE TEMPORARY VIEW other_direct_and_indirect_costs_not_in_the_bom_tmp
# MAGIC AS
# MAGIC SELECT prps.PRCTR product_id
# MAGIC     , LTRIM("0", prps.USR01) cost_element_id
# MAGIC     , c.MONTH_ID validity_date_yyyymm
# MAGIC     , prps.WERKS plant
# MAGIC     , c.company company
# MAGIC     , c.OBJNR wbs_technical_number
# MAGIC --     , COUNT(c.OBJNR) WorkOrderCount
# MAGIC --     , null WorkOrderQuantity -- quantity of material produced in the OBJNR (project), in this case useless because = 0
# MAGIC     , ROUND(SUM(c.valueInControllingAreaCurrency / curr.rate), 2) cost_eur -- to be devided by slvr_finance_as.quantity_delivered.actual after a join on product month_id when ingested in pltm_prodcosts.costs_analysis
# MAGIC     , ROUND(SUM(CASE c.MEINH WHEN 'H' then c.totalQuantity WHEN 'HRS' then c.totalQuantity when 'MIN' then c.totalQuantity / 60 else null end), 2) cost_hours -- to be devided by slvr_finance_as.quantity_delivered.actual after a join on product month_id when ingested in pltm_prodcosts.costs_analysis
# MAGIC FROM costs_not_in_the_bom c
# MAGIC LEFT JOIN slvr_sap.co_prps prps ON prps.OBJNR = c.OBJNR
# MAGIC INNER JOIN currency_exchange_rates_tmp curr on curr.source_currency = c.currency and curr.validity_date_yyyymm = c.MONTH_ID
# MAGIC WHERE LEFT(prps.USR01, 9) IN ("RNREBE092", "RNREBE093")
# MAGIC GROUP BY prps.PRCTR
# MAGIC     , prps.USR01
# MAGIC     , c.MONTH_ID
# MAGIC     , prps.WERKS
# MAGIC     , c.company
# MAGIC     , c.OBJNR

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test

# COMMAND ----------

# %sql
# SELECT * FROM other_direct_and_indirect_costs_not_in_the_bom_tmp

# COMMAND ----------

# MAGIC %md
# MAGIC # Direct costs on WO production problems
# MAGIC 1.5.4.5 Direct costs on WO production problems

# COMMAND ----------

# MAGIC %md
# MAGIC ## Process

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- (query 1/2) work order costs of the month in € not linked to material number but additionnal costs to the final product
# MAGIC CREATE OR REPLACE TEMPORARY VIEW costs_on_wo_production_problems
# MAGIC AS
# MAGIC select u.mandt
# MAGIC     , u.lednr
# MAGIC     , u.objnr
# MAGIC     , u.gjahr
# MAGIC     , u.wrttp
# MAGIC     , u.versn
# MAGIC     , u.kstar
# MAGIC     , u.vrgng
# MAGIC     , u.beknz
# MAGIC     , u.twaer
# MAGIC     , u.perbl
# MAGIC     , u.meinh
# MAGIC     , CASE
# MAGIC         WHEN LEFT(u.objnr, 2) = "OR" THEN aufk.BUKRS
# MAGIC         WHEN LEFT(u.objnr, 2) = "PR" THEN prps.PBUKR
# MAGIC       END company -- COSS/COSP.BUKRS is null sometimes, so we have to use aufk.BUKRS (for Work Orders) and prps.PBUKR (for Projects)
# MAGIC     , CASE
# MAGIC         WHEN LEFT(u.objnr, 2) = "OR" THEN
# MAGIC           CASE WHEN aufk.BUKRS IN ('LLVS', 'LLVA') THEN 'CZK' ELSE 'EUR' END
# MAGIC         WHEN LEFT(u.objnr, 2) = "PR" THEN
# MAGIC           CASE WHEN prps.PBUKR IN ('LLVS', 'LLVA') THEN 'CZK' ELSE 'EUR' END
# MAGIC       END currency -- Ignore TWAER as Currency, take the currency with a join to AUFK instead, LLVA and LLVS are the only companies in CZK and this is the only exception so we can hard-code it
# MAGIC     , CONCAT(u.gjahr, RIGHT(u.amtType, 2)) MONTH_ID
# MAGIC     , case when LEFT(u.amtType, 3) == 'wkg' then u.amt end valueInControllingAreaCurrency
# MAGIC     , case when LEFT(u.amtType, 3) == 'meg' and u.meinh in('H', 'HRS', 'MIN') then u.amt end totalQuantity    -- totalQuantity has to be null if MEINH is not in 'H', 'HRS', 'MIN'
# MAGIC FROM slvr_sap.co_unpivoted_coss_cosp u
# MAGIC LEFT JOIN slvr_sap.pp_aufk aufk on aufk.OBJNR = u.OBJNR AND aufk.MANDT = u.MANDT
# MAGIC LEFT JOIN slvr_sap.co_prps prps on prps.OBJNR = u.OBJNR AND prps.MANDT = u.MANDT
# MAGIC WHERE LEFT(u.OBJNR, 2) = "OR"
# MAGIC   AND u.VERSN = "000"
# MAGIC   AND u.WRTTP = "04"
# MAGIC   AND u.BEKNZ IN ("S", "H")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- (query 2/2) work order costs of the month in € not linked to material number but additionnal costs to the final product
# MAGIC CREATE OR REPLACE TEMPORARY VIEW direct_costs_on_wo_production_problems_tmp
# MAGIC AS
# MAGIC SELECT aufk.PRCTR product_id
# MAGIC     , LTRIM("0", prps.USR01) cost_element_id
# MAGIC     , c.MONTH_ID validity_date_yyyymm
# MAGIC     , aufk.WERKS plant
# MAGIC     , c.company company
# MAGIC     , c.OBJNR wbs_technical_number
# MAGIC --     , COUNT(c.OBJNR) WorkOrderCount
# MAGIC --     , null WorkOrderQuantity -- quantity of material produced in the OBJNR (project), in this case useless because = 0
# MAGIC     , ROUND(SUM(c.valueInControllingAreaCurrency / curr.rate), 2) cost_eur -- -- to be devided by slvr_finance_as.quantity_delivered.actual after a join on product month_id when ingested in pltm_prodcosts.costs_analysis
# MAGIC     , ROUND(SUM(CASE c.MEINH WHEN 'H' then c.totalQuantity WHEN 'HRS' then c.totalQuantity when 'MIN' then c.totalQuantity / 60 else null end), 2) cost_hours -- -- to be devided by slvr_finance_as.quantity_delivered.actual after a join on product month_id when ingested in pltm_prodcosts.costs_analysis
# MAGIC FROM costs_on_wo_production_problems c
# MAGIC LEFT JOIN slvr_sap.pp_aufk aufk ON aufk.OBJNR = c.OBJNR AND aufk.MANDT = c.MANDT
# MAGIC LEFT JOIN slvr_sap.pp_afpo afpo ON CONCAT("OR", afpo.AUFNR) = c.OBJNR
# MAGIC LEFT JOIN slvr_sap.co_prps prps ON LTRIM("0", prps.PSPNR) = LTRIM("0", afpo.PROJN)
# MAGIC INNER JOIN currency_exchange_rates_tmp curr ON curr.source_currency = c.currency AND curr.validity_date_yyyymm = c.MONTH_ID
# MAGIC WHERE aufk.AUART in ("ZP09", "ZP11", "ZP19", "ZP21")  -- Filter on specific Work Order Types
# MAGIC   AND LEFT(prps.USR01, 9) = "RNREBE091"
# MAGIC GROUP BY aufk.PRCTR
# MAGIC     , prps.USR01
# MAGIC     , c.MONTH_ID
# MAGIC     , aufk.WERKS
# MAGIC     , company
# MAGIC     , c.OBJNR

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test

# COMMAND ----------

# %sql
# SELECT * FROM direct_costs_on_wo_production_problems_tmp

# COMMAND ----------

# MAGIC %md
# MAGIC # Union All

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW costs_out_of_bom_tmp
# MAGIC AS
# MAGIC 
# MAGIC SELECT product_id
# MAGIC     , cost_element_id
# MAGIC     , validity_date_yyyymm
# MAGIC     , plant
# MAGIC     , company
# MAGIC     , wbs_technical_number
# MAGIC     , cost_eur -- to be devided by slvr_finance_as.quantity_delivered.actual after a join on product month_id when ingested in pltm_prodcosts.costs_analysis
# MAGIC     , cost_hours -- to be devided by slvr_finance_as.quantity_delivered.actual after a join on product month_id when ingested in pltm_prodcosts.costs_analysis
# MAGIC FROM other_direct_and_indirect_costs_not_in_the_bom_tmp
# MAGIC 
# MAGIC UNION ALL
# MAGIC 
# MAGIC SELECT product_id
# MAGIC     , cost_element_id
# MAGIC     , validity_date_yyyymm
# MAGIC     , plant
# MAGIC     , company
# MAGIC     , wbs_technical_number
# MAGIC     , cost_eur -- to be devided by slvr_finance_as.quantity_delivered.actual after a join on product month_id when ingested in pltm_prodcosts.costs_analysis
# MAGIC     , cost_hours -- to be devided by slvr_finance_as.quantity_delivered.actual after a join on product month_id when ingested in pltm_prodcosts.costs_analysis
# MAGIC FROM direct_costs_on_wo_production_problems_tmp;
# MAGIC 
# MAGIC -- SELECT * FROM other_costs_tmp

# COMMAND ----------

# MAGIC %md
# MAGIC # Write

# COMMAND ----------

# MAGIC %sql 
# MAGIC 
# MAGIC -- TODO ArL: Why is broadcasting not working (stats not positioned?)
# MAGIC set spark.sql.autoBroadcastJoinThreshold=-1 

# COMMAND ----------

table_zone = "gold_finance_as"
table_name = "costs_out_of_bom"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC # Test

# COMMAND ----------

# %sql
# select count(*) from gold_finance_as.costs_out_of_bom
