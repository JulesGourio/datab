# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Aggregates actual values from SAP tables for Direct & Indirect costs of the BOM - external purchases  
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC gold_finance_as.costs_in_bom_external  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC slvr_finance_as.currency_exchange_rates_actual  
# MAGIC gold_finance_as.bill_of_material  
# MAGIC slvr_sap.fi_bkpf  
# MAGIC slvr_sap.fi_bseg  
# MAGIC slvr_sap.fi_suppliers  
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC costs_in_bom_external_dq notebook  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %md
# MAGIC # Process

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- select actual currency exchange rates to convert in euro
# MAGIC CREATE OR REPLACE TEMPORARY VIEW currency_exchange_rates_tmp
# MAGIC AS
# MAGIC SELECT validity_date_yyyymm, source_currency, target_currency, rate
# MAGIC FROM slvr_finance_as.currency_exchange_rates_actual
# MAGIC WHERE target_currency = "EUR";

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC 
# MAGIC -- select all part_number costs coming from external sources and convert into € with monthly FX rates
# MAGIC CREATE OR REPLACE TEMPORARY VIEW costs_tmp
# MAGIC AS
# MAGIC WITH meta_cost_elements AS (
# MAGIC -- A standard price of a part number contains all cost of routing and BOM to build this part number
# MAGIC -- In a complete BOM valuation, we must only take into account the added value of the part number
# MAGIC -- To do so, cost element id is based on the fields procu and specia from the BOM
# MAGIC   SELECT divi
# MAGIC     , material
# MAGIC     , procu
# MAGIC     , specia
# MAGIC     , mat_chara
# MAGIC     , CASE
# MAGIC         WHEN procu = "F" AND specia = "20" AND LENGTH(mat_chara) = 4 THEN '60331101'
# MAGIC         WHEN procu = "F" AND specia = "20" AND LENGTH(mat_chara) = 9 THEN '71335101'
# MAGIC         WHEN procu = "F" AND specia = "30" THEN '60535101'
# MAGIC         WHEN procu IN ("X", "E") AND specia IS NULL THEN '71335101'
# MAGIC         ELSE NULL
# MAGIC       END cost_element_id
# MAGIC   FROM gold_finance_as.bill_of_material
# MAGIC   GROUP BY divi
# MAGIC     , material
# MAGIC     , procu
# MAGIC     , specia
# MAGIC     , mat_chara
# MAGIC )
# MAGIC SELECT bkpf.BLART document_type
# MAGIC   , bkpf.GJAHR document_accounting_year
# MAGIC   , LEFT(bkpf.BUDAT, 6) validity_date_yyyymm
# MAGIC   , bkpf.BUDAT accounting_date
# MAGIC   , bkpf.BUKRS company_name
# MAGIC   , bkpf.BELNR accounting_document_number
# MAGIC   , bkpf.WAERS transaction_currency
# MAGIC   , bkpf.HWAER company_currency
# MAGIC   , bseg.SHKZG debit_credit
# MAGIC   , bseg.WRBTR * CASE WHEN bseg.SHKZG == "S" THEN -1 ELSE 1 END cost_transaction_currency
# MAGIC   , bseg.DMBTR * CASE WHEN bseg.SHKZG == "S" THEN -1 ELSE 1 END cost_company_currency
# MAGIC   , round(bseg.WRBTR * CASE WHEN bseg.SHKZG == "S" THEN -1 ELSE 1 END / ct.rate, 3) cost_euro_from_transaction_currency
# MAGIC   , round(bseg.DMBTR * CASE WHEN bseg.SHKZG == "S" THEN -1 ELSE 1 END / cc.rate, 3) cost_euro_from_company_currency
# MAGIC   , bseg.HKONT general_account
# MAGIC   , bseg.LIFNR supplier_id
# MAGIC   , bseg.WERKS plant
# MAGIC   , LTRIM("0", bseg.MATNR) part_number
# MAGIC   , bseg.MENGE * CASE WHEN bseg.SHKZG == "S" THEN -1 ELSE 1 END quantity_received
# MAGIC   , bseg.MEINS unit_of_quantity
# MAGIC   , bseg.EBELN purchase_order
# MAGIC   , bseg.EBELP purchase_order_item
# MAGIC   , bseg.PRCTR profit_center_associated_to_part_number
# MAGIC   , bseg.VBUND trading_partner
# MAGIC   , m.procu procurement_type
# MAGIC   , m.specia special_procurement
# MAGIC   , m.mat_chara material_characteristics
# MAGIC   , m.cost_element_id cost_element_id
# MAGIC   , CASE
# MAGIC       WHEN s.trading_partner IN ("000800", "001000", "01010", "001300", "A700", "A900")
# MAGIC         AND bseg.WERKS IN ("1000", "3000", "3100", "4000", "4010", "5000")
# MAGIC         THEN True
# MAGIC       WHEN s.trading_partner IN ("I001", "I002", "I003", "I007", "I200", "I210", "I900")
# MAGIC         AND bseg.WERKS IN ("2000", "2010", "2020", "2030", "2040", "2100", "2110", "2200", "2300", "2310", "2320", "2400", "2500", "2600")
# MAGIC         THEN True
# MAGIC       ELSE False
# MAGIC     END is_intra_branch
# MAGIC FROM slvr_sap.fi_bkpf bkpf
# MAGIC INNER JOIN slvr_sap.fi_bseg bseg ON bkpf.MANDT = bseg.MANDT AND bkpf.BUKRS = bseg.BUKRS AND bkpf.BELNR = bseg.BELNR AND bkpf.GJAHR = bseg.GJAHR
# MAGIC LEFT JOIN slvr_sap.fi_suppliers s ON s.client = bseg.MANDT AND s.supplier = bseg.LIFNR
# MAGIC LEFT JOIN currency_exchange_rates_tmp ct ON ct.source_currency = bkpf.WAERS AND ct.validity_date_yyyymm = LEFT(bkpf.BUDAT, 6)
# MAGIC LEFT JOIN currency_exchange_rates_tmp cc ON cc.source_currency = bkpf.HWAER AND cc.validity_date_yyyymm = LEFT(bkpf.BUDAT, 6)
# MAGIC INNER JOIN meta_cost_elements m ON m.divi = bseg.WERKS AND m.material = ltrim("0", bseg.MATNR)   -- join cost elements from BOM on WERKS + MATNR 
# MAGIC WHERE bkpf.BLART = "WE"
# MAGIC   AND bseg.HKONT IN ("0040812000", "0040812100", "0040812200")
# MAGIC   AND bseg.MATNR != ""
# MAGIC   AND m.cost_element_id IS NOT NULL

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- calculate the month quantity received
# MAGIC CREATE OR REPLACE TEMPORARY VIEW quantities_tmp
# MAGIC AS
# MAGIC SELECT
# MAGIC   part_number
# MAGIC   , procurement_type
# MAGIC   , special_procurement
# MAGIC   , material_characteristics
# MAGIC   , cost_element_id
# MAGIC   , validity_date_yyyymm
# MAGIC   , plant
# MAGIC   , is_intra_branch
# MAGIC   , sum(round(quantity_received, 3)) quantity_received
# MAGIC FROM costs_tmp
# MAGIC GROUP BY
# MAGIC   part_number
# MAGIC   , procurement_type
# MAGIC   , special_procurement
# MAGIC   , material_characteristics
# MAGIC   , cost_element_id
# MAGIC   , validity_date_yyyymm
# MAGIC   , plant
# MAGIC   , is_intra_branch

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Calculate unit average costs of the month
# MAGIC CREATE OR REPLACE TEMPORARY VIEW costs_in_bom_external_tmp
# MAGIC AS
# MAGIC SELECT c.part_number                            part_number
# MAGIC   , c.procurement_type                          procurement_type
# MAGIC   , c.special_procurement                       special_procurement
# MAGIC   , c.material_characteristics                  material_characteristics
# MAGIC   , c.cost_element_id                           cost_element_id
# MAGIC   , c.validity_date_yyyymm                      validity_date_yyyymm
# MAGIC   , c.plant                                     plant
# MAGIC   , c.supplier_id                               supplier_id
# MAGIC   , c.is_intra_branch                           is_intra_branch
# MAGIC   , c.transaction_currency                      transaction_currency
# MAGIC   , c.company_currency                          company_currency
# MAGIC   , c.accounting_document_number                accounting_document_number
# MAGIC   , count(c.accounting_document_number)         accounting_document_number_count
# MAGIC --   , SUM(q.quantity_received)                    quantity_received
# MAGIC   , MAX(round(q.quantity_received, 3))          quantity_received -- to get the average unit price when there are several rows
# MAGIC   , SUM(c.cost_transaction_currency)            cost_transaction_currency
# MAGIC   , SUM(c.cost_company_currency)                cost_company_currency
# MAGIC   , SUM(c.cost_euro_from_transaction_currency)  cost_euro_from_transaction_currency
# MAGIC   , SUM(c.cost_euro_from_company_currency)      cost_euro_from_company_currency
# MAGIC --   , SUM(c.cost_euro_from_transaction_currency / q.quantity_received) unit_cost_eur_from_transaction_currency  -- this field is useless
# MAGIC   , SUM(c.cost_euro_from_company_currency / round(q.quantity_received, 3)) unit_cost_eur_from_company_currency     -- part number average cost
# MAGIC FROM costs_tmp c
# MAGIC LEFT JOIN quantities_tmp q
# MAGIC ON q.part_number = c.part_number
# MAGIC   AND q.procurement_type = c.procurement_type
# MAGIC   AND q.special_procurement = c.special_procurement
# MAGIC   AND q.material_characteristics = c.material_characteristics
# MAGIC   AND q.cost_element_id = c.cost_element_id
# MAGIC   AND q.validity_date_yyyymm = c.validity_date_yyyymm
# MAGIC   AND q.plant = c.plant
# MAGIC   AND q.is_intra_branch = c.is_intra_branch
# MAGIC GROUP BY c.part_number
# MAGIC   , c.procurement_type
# MAGIC   , c.special_procurement
# MAGIC   , c.material_characteristics
# MAGIC   , c.cost_element_id
# MAGIC   , c.validity_date_yyyymm
# MAGIC   , c.plant
# MAGIC   , c.supplier_id
# MAGIC   , c.is_intra_branch
# MAGIC   , c.transaction_currency
# MAGIC   , c.company_currency
# MAGIC   , c.accounting_document_number

# COMMAND ----------

# MAGIC %md
# MAGIC # Write

# COMMAND ----------

table_zone = "gold_finance_as"
table_name = "costs_in_bom_external"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Data Quality

# COMMAND ----------

# Execute the Data Quality notebook, with a 5-minute timeout

dbutils.notebook.run("costs_in_bom_external_dq", 300, {"tests_to_perform": "on_load"}) 

# COMMAND ----------

# MAGIC %md
# MAGIC # Test

# COMMAND ----------

# %sql
# select count(*) from gold_finance_as.costs_in_bom_external
