# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Aggregates actual values from SAP tables for Direct & Indirect costs of the BOM – internal production  
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC gold_finance_as.costs_in_bom_internal  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC slvr_finance_as.currency_exchange_rates_actual  
# MAGIC slvr_sap.co_unpivoted_coss_cosp  
# MAGIC slvr_sap.pp_aufk  
# MAGIC slvr_sap.pp_afko  
# MAGIC slvr_sap.pp_jcds  
# MAGIC 
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC costs_in_bom_internal_dq notebook  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %md
# MAGIC # Process

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- All unpivoted_coss_cosp costs per work order (producing material number) in € (based on aufk.BUKRS currency) associated with plant (aufk.WERKS)
# MAGIC CREATE OR REPLACE TEMPORARY VIEW costs_tmp
# MAGIC AS
# MAGIC WITH currency_exchange_rates_tmp AS (
# MAGIC   SELECT validity_date_yyyymm, source_currency, target_currency, rate
# MAGIC   FROM slvr_finance_as.currency_exchange_rates_actual
# MAGIC   WHERE target_currency = "EUR"
# MAGIC )
# MAGIC SELECT
# MAGIC   u.mandt                            mandt
# MAGIC   , ltrim("0", u.kstar)              kstar
# MAGIC   , aufk.WERKS                       werks
# MAGIC   , u.objnr                          objnr                                             -- work_order_number without "OR" at the beginning
# MAGIC   , aufk.AUFNR                       aufnr                                             -- usefull field for users
# MAGIC   , sum(CASE WHEN LEFT(u.amtType, 3) = 'wkg' THEN u.amt END / curr.rate) cost_eur      -- valueInControllingAreaCurrency / eur_rate
# MAGIC   , sum(CASE
# MAGIC           WHEN LEFT(u.amtType, 3) == 'meg' AND u.meinh IN('H', 'HRS') THEN u.amt
# MAGIC           WHEN LEFT(u.amtType, 3) == 'meg' AND u.meinh = 'MIN' THEN u.amt / 60
# MAGIC           ELSE null
# MAGIC         END) cost_hours                                                                -- cost_hours has to be null if MEINH is not in 'H', 'HRS', 'MIN'
# MAGIC FROM slvr_sap.co_unpivoted_coss_cosp u
# MAGIC INNER JOIN slvr_sap.pp_aufk aufk
# MAGIC   ON aufk.OBJNR = u.objnr
# MAGIC   AND aufk.MANDT = u.mandt
# MAGIC INNER JOIN currency_exchange_rates_tmp curr
# MAGIC   ON curr.source_currency = CASE WHEN aufk.BUKRS IN ('LLVS', 'LLVA') THEN 'CZK' ELSE 'EUR' END -- currency from aufk = CASE WHEN aufk.BUKRS IN ('LLVS', 'LLVA') THEN 'CZK' ELSE 'EUR' END
# MAGIC   AND curr.validity_date_yyyymm = concat(u.gjahr, RIGHT(u.amtType, 2))                         -- validity_date_yyyymm from unpivoted_coss_cosp = concat(u.gjahr, RIGHT(u.amtType, 2))
# MAGIC WHERE LEFT(u.objnr, 2) = "OR"                                                                  -- Filter on Work Orders only
# MAGIC   AND u.versn = "000"
# MAGIC   AND u.wrttp = "04"
# MAGIC   AND u.beknz IN ("S", "H")
# MAGIC   AND aufk.AUART in ('YP03', 'YP04', 'YP23', 'YP24', 'ZP01', 'ZP02', 'ZP03', 'ZP04', 'ZP05')   -- Filter on specific Work Order Types
# MAGIC GROUP BY u.mandt
# MAGIC   , ltrim("0", u.kstar)
# MAGIC   , aufk.WERKS
# MAGIC   , u.objnr
# MAGIC   , aufk.AUFNR;
# MAGIC 
# MAGIC -- cost_eur FOR EACH cost_element_id, work_order_number
# MAGIC CREATE OR REPLACE TEMPORARY VIEW costs_global_eur_tmp
# MAGIC AS
# MAGIC WITH global_costs AS (
# MAGIC   SELECT kstar
# MAGIC     , objnr
# MAGIC     , sum(cost_eur) globalCostEUR
# MAGIC     , sum(cost_hours) globalCostHours
# MAGIC   FROM costs_tmp
# MAGIC   GROUP BY kstar
# MAGIC     , objnr
# MAGIC )
# MAGIC -- part number total costs of the month for the closed work orders
# MAGIC SELECT
# MAGIC   c.mandt                                           mandt
# MAGIC   , ltrim("0", afko.PLNBEZ)                         part_number
# MAGIC   , c.kstar                                         cost_element_id
# MAGIC   , LEFT(jcds.UDATE, 6)                             validity_date_yyyymm
# MAGIC   , c.werks                                         plant
# MAGIC   , c.objnr                                         object_number                -- work_order_number without "OR" at the beginning
# MAGIC   , c.aufnr                                         work_order_number
# MAGIC   , sum(gc.globalCostEUR)                           cost_eur                     -- valueInControllingAreaCurrency / eur_rate
# MAGIC   , sum(gc.globalCostHours)                         cost_hours                   -- PartNumber average cost
# MAGIC FROM costs_tmp c
# MAGIC INNER JOIN global_costs gc
# MAGIC   ON gc.kstar = c.kstar
# MAGIC   AND gc.objnr = c.objnr
# MAGIC INNER JOIN slvr_sap.pp_afko afko
# MAGIC   ON afko.MANDT = c.mandt
# MAGIC   AND afko.AUFNR = c.aufnr
# MAGIC INNER JOIN slvr_sap.pp_jcds jcds
# MAGIC   ON jcds.MANDT = c.mandt
# MAGIC   AND jcds.OBJNR = c.objnr
# MAGIC WHERE jcds.STAT = "E0007"  -- select only work order closed
# MAGIC   AND jcds.INACT IS null
# MAGIC GROUP BY c.mandt
# MAGIC   , ltrim("0", afko.PLNBEZ)
# MAGIC   , c.kstar
# MAGIC   , LEFT(jcds.UDATE, 6)
# MAGIC   , c.werks
# MAGIC   , c.objnr
# MAGIC   , c.aufnr;
# MAGIC 
# MAGIC -- month_quantity_delivered FOR EACH part_number, validity_date_yyyymm, plant
# MAGIC CREATE OR REPLACE TEMPORARY VIEW month_quantity_delivered_tmp
# MAGIC AS
# MAGIC SELECT
# MAGIC   afko.MANDT                                        mandt
# MAGIC   , ltrim("0", afko.PLNBEZ)                         part_number
# MAGIC   , LEFT(jcds.UDATE, 6)                             validity_date_yyyymm
# MAGIC   , aufk.werks                                      plant
# MAGIC   , sum(afko.IGMNG)                                 month_quantity_delivered
# MAGIC FROM slvr_sap.pp_afko afko
# MAGIC INNER JOIN slvr_sap.pp_jcds jcds
# MAGIC   ON jcds.MANDT = afko.mandt
# MAGIC   AND jcds.OBJNR = concat("OR", afko.AUFNR)
# MAGIC INNER JOIN slvr_sap.pp_aufk aufk
# MAGIC   ON aufk.MANDT = jcds.mandt
# MAGIC   AND aufk.OBJNR = concat("OR", afko.AUFNR)
# MAGIC WHERE jcds.STAT = "E0007"
# MAGIC   AND jcds.INACT IS null
# MAGIC   AND aufk.AUART in ('YP03', 'YP04', 'YP23', 'YP24', 'ZP01', 'ZP02', 'ZP03', 'ZP04', 'ZP05')   -- Filter on specific Work Order Types
# MAGIC GROUP BY afko.MANDT
# MAGIC   , ltrim("0", afko.PLNBEZ)
# MAGIC   , LEFT(jcds.UDATE, 6)
# MAGIC   , aufk.werks;
# MAGIC 
# MAGIC -- final table with cost_eur and month_quantity_delivered to calculate the average cost of the month
# MAGIC CREATE OR REPLACE TEMPORARY VIEW costs_in_bom_internal_tmp
# MAGIC AS
# MAGIC SELECT
# MAGIC   c.part_number                                                 part_number
# MAGIC   , c.cost_element_id                                           cost_element_id
# MAGIC   , c.validity_date_yyyymm                                      validity_date_yyyymm
# MAGIC   , c.plant                                                     plant
# MAGIC --   , c.object_number                                                                           -- work_order_number without "OR" at the beginning
# MAGIC   , c.work_order_number                                         work_order_number
# MAGIC   , count(c.work_order_number)                                  work_order_count                 -- usefull field for users
# MAGIC   , max(m.month_quantity_delivered)                             month_quantity_delivered
# MAGIC   , sum(cost_eur)                                               cost_eur
# MAGIC   , sum(cost_eur) / max(m.month_quantity_delivered)             unit_cost_eur
# MAGIC   , sum(c.cost_hours)                                           cost_hours                       -- PartNumber average cost
# MAGIC   , sum(c.cost_hours) / max(m.month_quantity_delivered)         unit_cost_hours
# MAGIC FROM costs_global_eur_tmp c
# MAGIC INNER JOIN month_quantity_delivered_tmp m
# MAGIC   ON m.mandt = c.mandt
# MAGIC   AND m.part_number = c.part_number
# MAGIC   AND m.validity_date_yyyymm = c.validity_date_yyyymm
# MAGIC   AND m.plant = c.plant
# MAGIC GROUP BY c.part_number
# MAGIC   , c.cost_element_id
# MAGIC   , c.validity_date_yyyymm
# MAGIC   , c.plant
# MAGIC   , c.work_order_number
# MAGIC ;

# COMMAND ----------

# MAGIC %md
# MAGIC # Write

# COMMAND ----------

# MAGIC %sql 
# MAGIC 
# MAGIC -- TODO ArL: Why is broadcasting not working (stats not positioned?)
# MAGIC set spark.sql.autoBroadcastJoinThreshold=-1 

# COMMAND ----------

table_zone = "gold_finance_as"
table_name = "costs_in_bom_internal"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Quality

# COMMAND ----------

# Execute the Data Quality notebook, with a 5-minute timeout

dbutils.notebook.run("costs_in_bom_internal_dq", 300, {"tests_to_perform": "on_load"}) 

# COMMAND ----------

# MAGIC %md
# MAGIC # Test

# COMMAND ----------

# %sql
# select *
# from gold_finance_as.costs_in_bom_internal
