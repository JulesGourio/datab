# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Unpivots and aggregates data from COSS and COSP SAP tables  
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC slvr_sap.co_unpivoted_coss_cosp  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC slvr_sap.co_coss  
# MAGIC slvr_sap.co_cosp  
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE FUNCTION rnegative_to_double(col STRING)
# MAGIC   RETURNS DOUBLE
# MAGIC   COMMENT 'Returns "-1.5" double if col is a string like "1.5-"'
# MAGIC   RETURN double(
# MAGIC         IF(
# MAGIC           RIGHT(col, 1) = '-'
# MAGIC           , concat('-', LEFT(col, length(col) - 1))
# MAGIC           , col
# MAGIC           )
# MAGIC       );

# COMMAND ----------

# MAGIC %md
# MAGIC # Unpivoted_COSS_COSP

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Unpivots and aggregates data from COSS and COSP SAP tables
# MAGIC CREATE OR REPLACE TEMPORARY VIEW co_unpivoted_coss_cosp_tmp
# MAGIC AS
# MAGIC with coss as (
# MAGIC   select mandt, lednr, objnr, gjahr, wrttp, versn, kstar, vrgng, beknz, twaer, perbl, meinh, bukrs
# MAGIC     , rnegative_to_double(wkg001) wkg001, rnegative_to_double(wkg002) wkg002, rnegative_to_double(wkg003) wkg003, rnegative_to_double(wkg004) wkg004, rnegative_to_double(wkg005) wkg005
# MAGIC     , rnegative_to_double(wkg006) wkg006, rnegative_to_double(wkg007) wkg007, rnegative_to_double(wkg008) wkg008, rnegative_to_double(wkg009) wkg009, rnegative_to_double(wkg010) wkg010
# MAGIC     , rnegative_to_double(wkg011) wkg011, rnegative_to_double(wkg012) wkg012
# MAGIC     , rnegative_to_double(meg001) meg001, rnegative_to_double(meg002) meg002, rnegative_to_double(meg003) meg003, rnegative_to_double(meg004) meg004, rnegative_to_double(meg005) meg005
# MAGIC     , rnegative_to_double(meg006) meg006, rnegative_to_double(meg007) meg007, rnegative_to_double(meg008) meg008, rnegative_to_double(meg009) meg009, rnegative_to_double(meg010) meg010
# MAGIC     , rnegative_to_double(meg011) meg011, rnegative_to_double(meg012) meg012
# MAGIC   from slvr_sap.co_coss
# MAGIC )
# MAGIC , cosp as (
# MAGIC   select mandt, lednr, objnr, gjahr, wrttp, versn, kstar, vrgng, beknz, twaer, perbl, meinh, bukrs
# MAGIC     , rnegative_to_double(wkg001) wkg001, rnegative_to_double(wkg002) wkg002, rnegative_to_double(wkg003) wkg003, rnegative_to_double(wkg004) wkg004, rnegative_to_double(wkg005) wkg005
# MAGIC     , rnegative_to_double(wkg006) wkg006, rnegative_to_double(wkg007) wkg007, rnegative_to_double(wkg008) wkg008, rnegative_to_double(wkg009) wkg009, rnegative_to_double(wkg010) wkg010
# MAGIC     , rnegative_to_double(wkg011) wkg011, rnegative_to_double(wkg012) wkg012
# MAGIC     , rnegative_to_double(meg001) meg001, rnegative_to_double(meg002) meg002, rnegative_to_double(meg003) meg003, rnegative_to_double(meg004) meg004, rnegative_to_double(meg005) meg005
# MAGIC     , rnegative_to_double(meg006) meg006, rnegative_to_double(meg007) meg007, rnegative_to_double(meg008) meg008, rnegative_to_double(meg009) meg009, rnegative_to_double(meg010) meg010
# MAGIC     , rnegative_to_double(meg011) meg011, rnegative_to_double(meg012) meg012
# MAGIC   from slvr_sap.co_cosp
# MAGIC )
# MAGIC select
# MAGIC   mandt
# MAGIC   , lednr
# MAGIC   , objnr
# MAGIC   , gjahr
# MAGIC   , wrttp
# MAGIC   , versn
# MAGIC   , kstar
# MAGIC   , vrgng
# MAGIC   , beknz
# MAGIC   , twaer
# MAGIC   , perbl
# MAGIC   , meinh
# MAGIC   , bukrs
# MAGIC   , stack(24, 'wkg001', wkg001, 'wkg002', wkg002, 'wkg003', wkg003, 'wkg004', wkg004, 'wkg005', wkg005, 'wkg006', wkg006
# MAGIC             , 'wkg007', wkg007, 'wkg008', wkg008, 'wkg009', wkg009, 'wkg010', wkg010, 'wkg011', wkg011, 'wkg012', wkg012
# MAGIC             , 'meg001', meg001, 'meg002', meg002, 'meg003', meg003, 'meg004', meg004, 'meg005', meg005, 'meg006', meg006
# MAGIC             , 'meg007', meg007, 'meg008', meg008, 'meg009', meg009, 'meg010', meg010, 'meg011', meg011, 'meg012', meg012) as (amtType, amt)
# MAGIC from coss
# MAGIC 
# MAGIC union all
# MAGIC select
# MAGIC   mandt
# MAGIC   , lednr
# MAGIC   , objnr
# MAGIC   , gjahr
# MAGIC   , wrttp
# MAGIC   , versn
# MAGIC   , kstar
# MAGIC   , vrgng
# MAGIC   , beknz
# MAGIC   , twaer
# MAGIC   , perbl
# MAGIC   , meinh
# MAGIC   , bukrs
# MAGIC   , stack(24, 'wkg001', wkg001, 'wkg002', wkg002, 'wkg003', wkg003, 'wkg004', wkg004, 'wkg005', wkg005, 'wkg006', wkg006
# MAGIC             , 'wkg007', wkg007, 'wkg008', wkg008, 'wkg009', wkg009, 'wkg010', wkg010, 'wkg011', wkg011, 'wkg012', wkg012
# MAGIC             , 'meg001', meg001, 'meg002', meg002, 'meg003', meg003, 'meg004', meg004, 'meg005', meg005, 'meg006', meg006
# MAGIC             , 'meg007', meg007, 'meg008', meg008, 'meg009', meg009, 'meg010', meg010, 'meg011', meg011, 'meg012', meg012) as (amtType, amt)
# MAGIC from cosp;
# MAGIC 
# MAGIC -- SELECT * FROM unpivoted_coss_cosp_tmp

# COMMAND ----------

# MAGIC %sql 
# MAGIC 
# MAGIC -- TODO: Why is broadcasting not working (stats not positioned?)
# MAGIC set spark.sql.autoBroadcastJoinThreshold=-1 

# COMMAND ----------

table_zone = "slvr_sap"
table_name = "co_unpivoted_coss_cosp"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC # Test

# COMMAND ----------

# %sql
# select count(*)
# from slvr_sap.co_unpivoted_coss_cosp
# -- where amt like "%-"
