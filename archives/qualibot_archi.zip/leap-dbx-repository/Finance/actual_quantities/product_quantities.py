# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Selects the most recent product_quantities data received  
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC slvr_finance_as.product_quantities  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC brnz_finance_as.product_quantities  
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %md
# MAGIC # Process

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Selects the most recent product_quantities data received
# MAGIC CREATE OR REPLACE TEMPORARY VIEW product_quantities_tmp
# MAGIC AS
# MAGIC WITH ranked_product_quantities AS (
# MAGIC   SELECT product_id, legal_entity, currency_code, account_number, validity_date_yyyymm, budget, actual
# MAGIC     , DENSE_RANK() OVER(PARTITION BY product_id, legal_entity, currency_code, account_number, validity_date_yyyymm ORDER BY ingestion_timestamp DESC) product_quantities_rank
# MAGIC   FROM brnz_finance_as.product_quantities
# MAGIC )
# MAGIC SELECT product_id, legal_entity, currency_code, account_number, validity_date_yyyymm, budget, actual
# MAGIC FROM ranked_product_quantities
# MAGIC WHERE product_quantities_rank == 1
# MAGIC ;
# MAGIC 
# MAGIC -- SELECT * FROM product_quantities_tmp

# COMMAND ----------

# MAGIC %md
# MAGIC # Write

# COMMAND ----------

table_zone = "slvr_finance_as"
table_name = "product_quantities"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC # Test

# COMMAND ----------

# %sql
# SELECT * FROM slvr_finance_as.product_quantities
