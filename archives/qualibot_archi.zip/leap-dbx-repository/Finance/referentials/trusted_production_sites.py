# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Selects the most recent production_sites data received  
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC slvr_finance_as.production_sites  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC brnz_finance_as.production_sites  
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %md
# MAGIC # Process

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW production_sites_tmp
# MAGIC AS
# MAGIC WITH ranked_production_sites AS (
# MAGIC   SELECT company, plant, mrp_c, site_reporting, description
# MAGIC     , DENSE_RANK() OVER(PARTITION BY company, plant, mrp_c ORDER BY ingestion_timestamp DESC) production_sites_rank
# MAGIC   FROM brnz_finance_as.production_sites
# MAGIC )
# MAGIC SELECT company, plant, mrp_c, site_reporting, description
# MAGIC FROM ranked_production_sites
# MAGIC WHERE production_sites_rank == 1
# MAGIC ;
# MAGIC 
# MAGIC SELECT * FROM production_sites_tmp

# COMMAND ----------

# MAGIC %md
# MAGIC # Write

# COMMAND ----------

table_zone = "slvr_finance_as"
table_name = "production_sites"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC # Tests

# COMMAND ----------

# %sql
# SELECT * FROM slvr_finance_as.production_sites

# COMMAND ----------


