# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Selects the most recent material_characteristics data received  
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC slvr_finance_as.ref_material_characteristics  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC brnz_finance_as.material_characteristics  
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %md
# MAGIC # Process

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW ref_material_characteristics_tmp
# MAGIC AS
# MAGIC WITH ranked_material_characteristics AS (
# MAGIC   SELECT n_char, pos_char, field, val_char, desc_char
# MAGIC     , DENSE_RANK() OVER(PARTITION BY n_char, pos_char, field, val_char ORDER BY ingestion_timestamp DESC) material_characteristics_rank
# MAGIC   FROM brnz_finance_as.material_characteristics
# MAGIC )
# MAGIC SELECT n_char, pos_char, field, val_char, desc_char
# MAGIC FROM ranked_material_characteristics
# MAGIC WHERE material_characteristics_rank == 1
# MAGIC ;
# MAGIC 
# MAGIC -- SELECT * FROM material_characteristics_tmp

# COMMAND ----------

# MAGIC %md
# MAGIC # Write

# COMMAND ----------

table_zone = "slvr_finance_as"
table_name = "ref_material_characteristics"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC # Test

# COMMAND ----------

# %sql
# SELECT * FROM slvr_finance_as.ref_material_characteristics

# COMMAND ----------


