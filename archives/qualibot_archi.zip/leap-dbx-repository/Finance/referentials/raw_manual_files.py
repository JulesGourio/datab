# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC For each output table, reads data from the raw files, and ingests it into bronze output tables by adding the filename and ingestion_timestamp fields  
# MAGIC Inserts data to the output tables  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC brnz_finance_as.budgets  
# MAGIC brnz_finance_as.product_quantities  
# MAGIC brnz_sap.co_msp_noec  
# MAGIC brnz_finance_as.material_characteristics  
# MAGIC brnz_finance_as.production_sites  
# MAGIC brnz_finance_as.products_ref  
# MAGIC brnz_finance_as.currency_exchange_rates_actual  
# MAGIC brnz_finance_as.currency_exchange_rates_budget  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC raw files into s3://leap-s3-weeu1-{env}/sap/raw_co/  
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *

def trim_df(df):
    df = df.select([trim(col(c)).alias(c) for c in df.columns])
    return df

# COMMAND ----------

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %md
# MAGIC # Budgets

# COMMAND ----------

table_zone = "brnz_finance_as"
table_name = "budgets"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"
table_schema = "(filename string, ingestion_timestamp timestamp, standard_price_date string, product_id string, cost_element_id string, year int, plant string, mrp_controller string, supplier_id string, part_number string, currency string, amount double, quantity double)"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {table_zone}")

spark.sql(f"CREATE TABLE IF NOT EXISTS {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")
# spark.sql(f"CREATE OR REPLACE TABLE {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")

paths = list(spark.createDataFrame(dbutils.fs.ls(f"s3://leap-s3-weeu1-{env}/sap/raw_co/")).filter(col("name").contains("budget.csv")).select("path").toPandas()["path"])

if len(paths) == 0:
    print(f"No input path detectetd for {table_zone}.{table_name}")
    
else:
    path = paths[0]
    print(f"Input path: {path}")
    
    schema = StructType([
        StructField("standard_price_date", StringType()),
        StructField("product_id", StringType()),
        StructField("cost_element_id", StringType()),
        StructField("year", IntegerType()),
        StructField("plant", StringType()),
        StructField("mrp_controller", StringType()),
        StructField("supplier_id", StringType()),
        StructField("part_number", StringType()),
        StructField("currency", StringType()),
        StructField("amount", StringType()),
        StructField("quantity", StringType()),
    ])
    
    df = (
        spark.read
        .format("csv")
        .option("header", True)
        .option("sep", ";")
        .schema(schema)
        .load(path)
        .withColumn("ingestion_timestamp", current_timestamp())
        .withColumn("filename", split(input_file_name(), '/').getItem(5))
        .withColumn("standard_price_date", date_format(to_date("standard_price_date", "dd/MM/yyyy"), "yyyyMMdd"))
        .withColumn("amount", regexp_replace(col('amount'), ',', '.').cast(DoubleType()))
        .withColumn("quantity", regexp_replace(col('quantity'), ',', '.').cast(DoubleType()))
        .select("filename", "ingestion_timestamp", "standard_price_date", "product_id", "cost_element_id", "year", "plant", "mrp_controller", "supplier_id", "part_number", "currency", "amount", "quantity")
    )
    
    df.createOrReplaceTempView(f"{table_name}_tmp")
    # display(df)
    
    spark.sql(f"INSERT INTO {table_zone}.{table_name} SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# %sql
# select * from brnz_finance_as.budgets

# COMMAND ----------

# MAGIC %md
# MAGIC # Product quantities

# COMMAND ----------

table_zone = "brnz_finance_as"
table_name = "product_quantities"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"
table_schema = "(filename string, ingestion_timestamp timestamp, product_id string, legal_entity string, currency_code string, account_number string, validity_date_yyyymm int, budget double, actual double)"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {table_zone}")

spark.sql(f"CREATE TABLE IF NOT EXISTS {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")
# spark.sql(f"CREATE OR REPLACE TABLE {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")

paths = list(spark.createDataFrame(dbutils.fs.ls(f"s3://leap-s3-weeu1-{env}/sap/raw_co/")).filter(col("name").contains("product_quantities.csv")).select("path").toPandas()["path"])

if len(paths) == 0:
    print(f"No input path detectetd for {table_zone}.{table_name}")
    
else:
    path = paths[0]
    print(f"Input path: {path}")
    
    schema = StructType([
        StructField("product_id", StringType()),
        StructField("legal_entity", StringType()),
        StructField("currency_code", StringType()),
        StructField("account_number", StringType()),
        StructField("validity_date_yyyymm", IntegerType()),
        StructField("budget", StringType()),
        StructField("actual", StringType()),
    ])

    df = (
        spark.read
        .format("csv")
        .option("header", True)
        .option("sep", ";")
        .schema(schema)
        .load(path)
        .withColumn("ingestion_timestamp", current_timestamp())
        .withColumn("filename", split(input_file_name(), '/').getItem(5))
        .withColumn("budget", regexp_replace(col('budget'), ',', '.').cast(DoubleType()))
        .withColumn("actual", regexp_replace(col('actual'), ',', '.').cast(DoubleType()))
        .select("filename", "ingestion_timestamp", "product_id", "legal_entity", "currency_code", "account_number", "validity_date_yyyymm", "budget", "actual")
    )

    df.createOrReplaceTempView(f"{table_name}_tmp")
#     display(df)

    spark.sql(f"INSERT INTO {table_zone}.{table_name} SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# %sql
# select * from brnz_finance_as.product_quantities

# COMMAND ----------

# MAGIC %md
# MAGIC # BOMs (MSP NOEC)

# COMMAND ----------

table_zone = "brnz_sap"
table_name = "co_msp_noec"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"
table_schema = "(filename string, ingestion_timestamp timestamp, id string, material string, designation string, divi string, bom_quantity double, uni string, std_price string, flow_cha string, mat_chara string, mrp_c string, purcha string, prod_st string, supply string, ext_su string, plant_s string, takt_t string, specia string, backflus string, i_c string, scheduli string, procu string, class string, lev string, rank string, rtg_ind string, use string, mrp string, lot_siz string, lot_size double, round double, bom_sto string, bulk string, need date, predecessor string, receipt_time string, safety_time string, opening_period string, float_after_p string, float_befo string, posit_delay string, oper_lt_offset string, oper_lt_offset_unit string, distribution_key string, phantom_item string, explosion_type string, special_procurement string, father_operation_nbr string, kanban_supply_area string)"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {table_zone}")

spark.sql(f"CREATE TABLE IF NOT EXISTS {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")
# spark.sql(f"CREATE OR REPLACE TABLE {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")

paths = list(spark.createDataFrame(dbutils.fs.ls(f"s3://leap-s3-weeu1-{env}/sap/raw_co/")).filter(col("name").contains("MSP_NOEC_")).select("path").toPandas()["path"])
print(f"Input paths:")
for path in paths: print(path)

schema = StructType([
    StructField("id", StringType()),
    StructField("material", StringType()),
    StructField("designation", StringType()),
    StructField("divi", StringType()),
    StructField("bom_quantity", StringType()),
    StructField("uni", StringType()),
    StructField("std_price", StringType()),
    StructField("flow_cha", StringType()),
    StructField("mat_chara", StringType()),
    StructField("mrp_c", StringType()),
    StructField("purcha", StringType()),
    StructField("prod_st", StringType()),
    StructField("supply", StringType()),
    StructField("ext_su", StringType()),
    StructField("plant_s", StringType()),
    StructField("takt_t", StringType()),
    StructField("specia", StringType()),
    StructField("backflus", StringType()),
    StructField("i_c", StringType()),
    StructField("scheduli", StringType()),
    StructField("procu", StringType()),
    StructField("class", StringType()),
    StructField("lev", StringType()),
    StructField("rank", StringType()),
    StructField("rtg_ind", StringType()),
    StructField("use", StringType()),
    StructField("mrp", StringType()),
    StructField("lot_siz", StringType()),
    StructField("lot_size", StringType()),
    StructField("round", StringType()),
    StructField("bom_sto", StringType()),
    StructField("bulk", StringType()),
    StructField("need", StringType()),
    StructField("predecessor", StringType()),
    StructField("receipt_time", StringType()),
    StructField("safety_time", StringType()),
    StructField("opening_period", StringType()),
    StructField("float_after_p", StringType()),
    StructField("float_befo", StringType()),
    StructField("posit_delay", StringType()),
    StructField("oper_lt_offset", StringType()),
    StructField("oper_lt_offset_unit", StringType()),
    StructField("distribution_key", StringType()),
    StructField("phantom_item", StringType()),
    StructField("explosion_type", StringType()),
    StructField("special_procurement", StringType()),
    StructField("father_operation_nbr", StringType()),
    StructField("kanban_supply_area", StringType()),
])
    
df = (
    spark.read
    .format("csv")
    .option("header", True)
    .option("sep", ";")
    .schema(schema)
    .option("ignoreTrailingWhiteSpace", True)
    .load(paths)
    .withColumn("ingestion_timestamp", current_timestamp())
    .withColumn("filename", regexp_replace(split(input_file_name(), '/').getItem(5), ".txt", ""))
    .withColumn("bom_quantity", regexp_replace("bom_quantity", ",", ".").cast(DoubleType()))
    .withColumn("lot_size", regexp_replace("lot_size", ",", ".").cast(DoubleType()))
    .withColumn("round", regexp_replace("round", ",", ".").cast(DoubleType()))
    .withColumn("need", to_date("need", "dd/MM/yyyy"))
    .filter(col("material") != "Material") # filter out potential headers in data
    .select("filename", "ingestion_timestamp", "id", "material", "designation", "divi", "bom_quantity", "uni", "std_price", "flow_cha", "mat_chara", "mrp_c", "purcha", "prod_st", "supply", "ext_su", "plant_s", "takt_t", "specia", "backflus", "i_c", "scheduli", "procu", "class", "lev", "rank", "rtg_ind", "use", "mrp", "lot_siz", "lot_size", "round", "bom_sto", "bulk", "need", "predecessor", "receipt_time", "safety_time", "opening_period", "float_after_p", "float_befo", "posit_delay", "oper_lt_offset", "oper_lt_offset_unit", "distribution_key", "phantom_item", "explosion_type", "special_procurement", "father_operation_nbr", "kanban_supply_area")
)
        
df.createOrReplaceTempView(f"{table_name}_tmp")
# display(df)

spark.sql(f"INSERT INTO {table_zone}.{table_name} SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# %sql
# select * from brnz_sap.co_msp_noec
# where material = "D5211045920000"
# and divi = "1000"

# COMMAND ----------

# MAGIC %md
# MAGIC # Material characteristics

# COMMAND ----------

table_zone = "brnz_finance_as"
table_name = "material_characteristics"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"
table_schema = "(filename string, ingestion_timestamp timestamp, n_char string, pos_char string, field string, val_char string, desc_char string)"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {table_zone}")

spark.sql(f"CREATE TABLE IF NOT EXISTS {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")
# spark.sql(f"CREATE OR REPLACE TABLE {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")

paths = list(spark.createDataFrame(dbutils.fs.ls(f"s3://leap-s3-weeu1-{env}/sap/raw_co/")).filter(col("name").contains("mat_char.csv")).select("path").toPandas()["path"])

if len(paths) == 0:
    print(f"No input path detectetd for {table_zone}.{table_name}")
    
else:
    path = paths[0]
    print(f"Input path: {path}")
    
    schema = StructType([
        StructField("n_char", StringType()),
        StructField("pos_char", StringType()),
        StructField("field", StringType()),
        StructField("val_char", StringType()),
        StructField("desc_char", StringType()),
    ])

    df = (
        spark.read
        .format("csv")
        .option("header", True)
        .schema(schema)
        .load(path)
        .withColumn("ingestion_timestamp", current_timestamp())
        .withColumn("filename", split(input_file_name(), '/').getItem(5))
        .select("filename", "ingestion_timestamp", "n_char", "pos_char", "field", "val_char", "desc_char")
    )

    df.createOrReplaceTempView(f"{table_name}_tmp")
    # display(df)

    spark.sql(f"INSERT INTO {table_zone}.{table_name} SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# %sql
# select * from brnz_finance_as.material_characteristics

# COMMAND ----------

# MAGIC %md
# MAGIC # Production sites

# COMMAND ----------

table_zone = "brnz_finance_as"
table_name = "production_sites"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"
table_schema = "(filename string, ingestion_timestamp timestamp, company string, plant string, mrp_c string, site_reporting string, description string)"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {table_zone}")

spark.sql(f"CREATE TABLE IF NOT EXISTS {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")
# spark.sql(f"CREATE OR REPLACE TABLE {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")

paths = list(spark.createDataFrame(dbutils.fs.ls(f"s3://leap-s3-weeu1-{env}/sap/raw_co/")).filter(col("name").contains("prod_site.csv")).select("path").toPandas()["path"])

if len(paths) == 0:
    print(f"No input path detectetd for {table_zone}.{table_name}")
    
else:
    path = paths[0]
    print(f"Input path: {path}")
    
    schema = StructType([
        StructField("company", StringType()),
        StructField("plant", StringType()),
        StructField("mrp_c", StringType()),
        StructField("site_reporting", StringType()),
        StructField("description", StringType())
    ])

    df = (
        spark.read
        .format("csv")
        .option("header", True)
        .option("sep", ";")
        .schema(schema)
        .load(path)
        .withColumn("ingestion_timestamp", current_timestamp())
        .withColumn("filename", split(input_file_name(), '/').getItem(5))
        .select("filename", "ingestion_timestamp", "company", "plant", "mrp_c", "site_reporting", "description")
    )

    df.createOrReplaceTempView(f"{table_name}_tmp")
    # display(df)

    spark.sql(f"INSERT INTO {table_zone}.{table_name} SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# %sql
# select * from brnz_finance_as.production_sites

# COMMAND ----------

# MAGIC %md
# MAGIC # Products

# COMMAND ----------

table_zone = "brnz_finance_as"
table_name = "products_ref"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"
table_schema = "(filename string, ingestion_timestamp timestamp, product_id string, description string)"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {table_zone}")

spark.sql(f"CREATE TABLE IF NOT EXISTS {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")
# spark.sql(f"CREATE OR REPLACE TABLE {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")

paths = list(spark.createDataFrame(dbutils.fs.ls(f"s3://leap-s3-weeu1-{env}/sap/raw_co/")).filter(col("name").contains("products.csv")).select("path").toPandas()["path"])

if len(paths) == 0:
    print(f"No input path detectetd for {table_zone}.{table_name}")
    
else:
    path = paths[0]
    print(f"Input path: {path}")
    
    schema = StructType([
        StructField("product_id", StringType()),
        StructField("description", StringType())
    ])

    df = (
        spark.read
        .format("csv")
        .option("header", True)
        .option("sep", ";")
        .schema(schema)
        .load(path)
        .withColumn("ingestion_timestamp", current_timestamp())
        .withColumn("filename", split(input_file_name(), '/').getItem(5))
        .select("filename", "ingestion_timestamp", "product_id", "description")
    )

    df.createOrReplaceTempView(f"{table_name}_tmp")
    # display(df)

    spark.sql(f"INSERT INTO {table_zone}.{table_name} SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# %sql
# select * from brnz_finance_as.products_ref

# COMMAND ----------

# MAGIC %md
# MAGIC # Actual currency exchange rates

# COMMAND ----------

table_zone = "brnz_finance_as"
table_name = "currency_exchange_rates_actual"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"
table_schema = "(filename string, ingestion_timestamp timestamp, validity_date_yyyymm int, source_currency string, target_currency string, rate double)"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {table_zone}")

spark.sql(f"CREATE TABLE IF NOT EXISTS {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")
# spark.sql(f"CREATE OR REPLACE TABLE {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")

paths = list(spark.createDataFrame(dbutils.fs.ls(f"s3://leap-s3-weeu1-{env}/sap/raw_co/")).filter(col("name").contains("actual_currency_exchange_rates.csv")).select("path").toPandas()["path"])

if len(paths) == 0:
    print(f"No input path detectetd for {table_zone}.{table_name}")
    
else:
    path = paths[0]
    print(f"Input path: {path}")
    
    schema = StructType([
        StructField("validity_date_yyyymm", IntegerType()),
        StructField("source_currency", StringType()),
        StructField("target_currency", StringType()),
        StructField("rate", StringType()),
    ])

    df = (
        spark.read
        .format("csv")
        .option("header", True)
        .option("sep", ";")
        .schema(schema)
        .load(path)
        .withColumn("rate", regexp_replace(col('rate'), ',', '.').cast(DoubleType()))
        .withColumn("ingestion_timestamp", current_timestamp())
        .withColumn("filename", split(input_file_name(), '/').getItem(5))
        .select("filename", "ingestion_timestamp", "validity_date_yyyymm", "source_currency", "target_currency", "rate")
    )

    df.createOrReplaceTempView(f"{table_name}_tmp")
#     display(df)

    spark.sql(f"INSERT INTO {table_zone}.{table_name} SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# %sql
# select * from brnz_finance_as.currency_exchange_rates_actual

# COMMAND ----------

# MAGIC %md
# MAGIC # Budget currency exchange rates

# COMMAND ----------

table_zone = "brnz_finance_as"
table_name = "currency_exchange_rates_budget"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"
table_schema = "(filename string, ingestion_timestamp timestamp, year int, source_currency string, target_currency string, rate double)"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {table_zone}")

spark.sql(f"CREATE TABLE IF NOT EXISTS {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")
# spark.sql(f"CREATE OR REPLACE TABLE {table_zone}.{table_name} {table_schema} USING DELTA LOCATION '{table_location}'")

paths = list(spark.createDataFrame(dbutils.fs.ls(f"s3://leap-s3-weeu1-{env}/sap/raw_co/")).filter(col("name").contains("budget_currency_exchange_rates.csv")).select("path").toPandas()["path"])

if len(paths) == 0:
    print(f"No input path detectetd for {table_zone}.{table_name}")
    
else:
    path = paths[0]
    print(f"Input path: {path}")
    
    schema = StructType([
        StructField("year", IntegerType()),
        StructField("source_currency", StringType()),
        StructField("target_currency", StringType()),
        StructField("rate", StringType()),
    ])

    df = (
        spark.read
        .format("csv")
        .option("header", True)
        .option("sep", ";")
        .schema(schema)
        .load(path)
        .withColumn("rate", regexp_replace(col('rate'), ',', '.').cast(DoubleType()))
        .withColumn("ingestion_timestamp", current_timestamp())
        .withColumn("filename", split(input_file_name(), '/').getItem(5))
        .select("filename", "ingestion_timestamp", "year", "source_currency", "target_currency", "rate")
    )

    df.createOrReplaceTempView(f"{table_name}_tmp")
    # display(df)

    spark.sql(f"INSERT INTO {table_zone}.{table_name} SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# %sql
# select * from brnz_finance_as.currency_exchange_rates_budget
