# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Selects the most recent actual and budget exchange rates data received  
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC slvr_finance_as.currency_exchange_rates_actual  
# MAGIC slvr_finance_as.currency_exchange_rates_budget  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC brnz_finance_as.currency_exchange_rates_actual  
# MAGIC brnz_finance_as.currency_exchange_rates_budget  
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %md 
# MAGIC # Actual currency exchange rates

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW currency_exchange_rates_actual_tmp
# MAGIC AS
# MAGIC WITH ranked_currency_exchange_rates_actual AS (
# MAGIC   SELECT *
# MAGIC     , dense_rank() OVER (PARTITION BY validity_date_yyyymm, source_currency, target_currency ORDER BY ingestion_timestamp DESC) ingestion_rank
# MAGIC   FROM brnz_finance_as.currency_exchange_rates_actual
# MAGIC )
# MAGIC SELECT validity_date_yyyymm, source_currency, target_currency, rate
# MAGIC FROM ranked_currency_exchange_rates_actual
# MAGIC WHERE ingestion_rank = 1;
# MAGIC 
# MAGIC -- SELECT * FROM currency_exchange_rates_actual_tmp

# COMMAND ----------

table_zone = "slvr_finance_as"
table_name = "currency_exchange_rates_actual"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# %sql
# SELECT * FROM slvr_finance_as.currency_exchange_rates_actual

# COMMAND ----------

# MAGIC %md 
# MAGIC # Budget currency exchange rates

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW currency_exchange_rates_budget_tmp
# MAGIC AS
# MAGIC WITH ranked_currency_exchange_rates_budget AS (
# MAGIC   SELECT *
# MAGIC     , dense_rank() OVER (PARTITION BY year, source_currency, target_currency ORDER BY ingestion_timestamp DESC) ingestion_rank
# MAGIC   FROM brnz_finance_as.currency_exchange_rates_budget
# MAGIC )
# MAGIC SELECT year, source_currency, target_currency, rate
# MAGIC FROM ranked_currency_exchange_rates_budget
# MAGIC WHERE ingestion_rank = 1;
# MAGIC 
# MAGIC -- SELECT * FROM currency_exchange_rates_budget_tmp

# COMMAND ----------

table_zone = "slvr_finance_as"
table_name = "currency_exchange_rates_budget"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# %sql
# SELECT * FROM slvr_finance_as.currency_exchange_rates_budget
