# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Selects and renames some fields from LFA1 SAP table  
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC slvr_sap.fi_suppliers  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC slvr_sap.fi_lfa1  
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  
# MAGIC Check the real usefulness of this table for the users.  
# MAGIC If it is not useful, delete it and replace it with slvr_sap.fi_lfa1 and its fields in the notebooks that use it (costs_in_bom_external, suppliers, rfd_fact_cost_analysis)  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %md
# MAGIC # Process

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW fi_suppliers_tmp
# MAGIC AS
# MAGIC SELECT MANDT client
# MAGIC   , LIFNR supplier
# MAGIC   , LAND1 country
# MAGIC   , NAME1 supplier_name
# MAGIC   , VBUND trading_partner
# MAGIC FROM slvr_sap.fi_lfa1;

# COMMAND ----------

# MAGIC %md
# MAGIC # Write

# COMMAND ----------

table_zone = "slvr_sap"
table_name = "fi_suppliers"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC # Test

# COMMAND ----------

# %sql
# SELECT count(*) FROM slvr_sap.fi_suppliers
# where trading_partner is null
