# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC Builds a cost element hierarchy from SAP tables  
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC gold_finance_as.cost_elements_hierarchy  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC slvr_sap.co_csku  
# MAGIC slvr_sap.co_setleaf  
# MAGIC slvr_sap.co_setheadert  
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

from pyspark.sql.functions import *
import json

def trim_df(df):
    df = df.select([trim(col(c)).alias(c) for c in df.columns])
    return df
  
# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %md
# MAGIC # Process
# MAGIC Build cost elements hierarchy from SAP tables:
# MAGIC * [CSKU](https://www.se80.co.uk/saptables/c/csku/csku.htm)
# MAGIC * [SETLEAF](https://www.se80.co.uk/saptables/s/setl/setleaf.htm)
# MAGIC * [SETHEADERT](https://www.se80.co.uk/saptables/s/seth/setheadert.htm)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cost elements
# MAGIC Gets cost elements and there associated texts from SAP table:
# MAGIC * [CSKU](https://www.se80.co.uk/saptables/c/csku/csku.htm)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Read
# MAGIC Reads data from Azure Blob Storage

# COMMAND ----------

cskuDF = spark.read.table('slvr_sap.co_csku')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Process

# COMMAND ----------

cskuDF = trim_df(cskuDF)

cskuDF = cskuDF.filter(col("SPRAS") == "E") # Filter on english language
cskuDF = cskuDF["KSTAR", "KTEXT", "LTEXT", "MCTXT"]

costElementsDF = cskuDF["KSTAR", "KTEXT", "LTEXT", "MCTXT"].distinct()

# display(costElementsDF)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Grouped cost elements
# MAGIC Cost elements & SETLEAF

# COMMAND ----------

# MAGIC %md
# MAGIC ### Read

# COMMAND ----------

setleafDF = spark.read.table('slvr_sap.co_setleaf')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Process

# COMMAND ----------

setleafDF = trim_df(setleafDF)

costElementGroupsDF = (
    setleafDF
    .filter(
        (col("SETCLASS") == "0109")
        & (col("SUBCLASS") == "CAFR")
        & (col("SETNAME").startswith("Z-")))
    .select("SETNAME", "VALFROM")
)

# COMMAND ----------

groupedCostElementsDF = costElementGroupsDF.join(costElementsDF, costElementGroupsDF.VALFROM == costElementsDF.KSTAR, "left")
# display(groupedCostElementsDF)

# COMMAND ----------

groupedHierarchivedCostElementsDF = (
    groupedCostElementsDF
    .withColumn("cost_element_hierarchy_lvl1_id",
                when(length(col("SETNAME")) == 10, col("SETNAME"))
                .otherwise(None))
    .withColumn("cost_element_hierarchy_lvl2_id",
                when(length(col("SETNAME")) == 9, col("SETNAME"))
                .when(length(col("SETNAME")) > 9, substring(col("SETNAME"), 0, 9))
                .otherwise(None))
    .withColumn("cost_element_hierarchy_lvl3_id",
                when(length(col("SETNAME")) == 7, col("SETNAME"))
                .when(length(col("SETNAME")) > 7, substring(col("SETNAME"), 0, 7))
                .otherwise(None))
    .withColumn("cost_element_hierarchy_lvl4_id",
                when(length(col("SETNAME")) == 5, col("SETNAME"))
                .when(length(col("SETNAME")) > 5, substring(col("SETNAME"), 0, 5))
                .otherwise(None))
    .withColumn("cost_element_hierarchy_lvl5_id",
                when(length(col("SETNAME")) == 3, col("SETNAME"))
                .when(length(col("SETNAME")) > 3, substring(col("SETNAME"), 0, 3))
                .otherwise(None))
)

# COMMAND ----------

# display(groupedHierarchivedCostElementsDF)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Grouped & hierarchized cost elements

# COMMAND ----------

# MAGIC %md
# MAGIC ### Read

# COMMAND ----------

setheadertDF = spark.read.table('slvr_sap.co_setheadert')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Process

# COMMAND ----------

setheadertDF = trim_df(setheadertDF)

costElementGroupsDescriptionDF = (
    setheadertDF
    .filter(
        (col("SETCLASS") == "0109")
        & (col("SUBCLASS") == "CAFR")
        & (col("SETNAME").startswith("Z-"))
        & (col("LANGU") == "E"))
    .select("SETNAME", "DESCRIPT")
)

# COMMAND ----------

l1DescriptionDF = (
    groupedHierarchivedCostElementsDF.select("cost_element_hierarchy_lvl1_id")
    .join(costElementGroupsDescriptionDF, groupedHierarchivedCostElementsDF.cost_element_hierarchy_lvl1_id == costElementGroupsDescriptionDF.SETNAME)
    .withColumnRenamed("DESCRIPT", "cost_element_hierarchy_lvl1_desc")
    .drop("SETNAME")
)
l2DescriptionDF = (
    groupedHierarchivedCostElementsDF.select("cost_element_hierarchy_lvl2_id")
    .join(costElementGroupsDescriptionDF, groupedHierarchivedCostElementsDF.cost_element_hierarchy_lvl2_id == costElementGroupsDescriptionDF.SETNAME)
    .withColumnRenamed("DESCRIPT", "cost_element_hierarchy_lvl2_desc")
    .drop("SETNAME")
)
l3DescriptionDF = (
    groupedHierarchivedCostElementsDF.select("cost_element_hierarchy_lvl3_id")
    .join(costElementGroupsDescriptionDF, groupedHierarchivedCostElementsDF.cost_element_hierarchy_lvl3_id == costElementGroupsDescriptionDF.SETNAME)
    .withColumnRenamed("DESCRIPT", "cost_element_hierarchy_lvl3_desc")
    .drop("SETNAME")
)
l4DescriptionDF = (
    groupedHierarchivedCostElementsDF.select("cost_element_hierarchy_lvl4_id")
    .join(costElementGroupsDescriptionDF, groupedHierarchivedCostElementsDF.cost_element_hierarchy_lvl4_id == costElementGroupsDescriptionDF.SETNAME)
    .withColumnRenamed("DESCRIPT", "cost_element_hierarchy_lvl4_desc")
    .drop("SETNAME")
)
l5DescriptionDF = (
    groupedHierarchivedCostElementsDF.select("cost_element_hierarchy_lvl5_id")
    .join(costElementGroupsDescriptionDF, groupedHierarchivedCostElementsDF.cost_element_hierarchy_lvl5_id == costElementGroupsDescriptionDF.SETNAME)
    .withColumnRenamed("DESCRIPT", "cost_element_hierarchy_lvl5_desc")
    .drop("SETNAME")
)

groupedHierarchivedCostElementsDF = (
    groupedHierarchivedCostElementsDF
    .join(l1DescriptionDF, "cost_element_hierarchy_lvl1_id", "left")
    .join(l2DescriptionDF, "cost_element_hierarchy_lvl2_id", "left")
    .join(l3DescriptionDF, "cost_element_hierarchy_lvl3_id", "left")
    .join(l4DescriptionDF, "cost_element_hierarchy_lvl4_id", "left")
    .join(l5DescriptionDF, "cost_element_hierarchy_lvl5_id", "left")
#     .withColumnRenamed("KSTAR", "cost_element_id")
    .withColumnRenamed("VALFROM", "cost_element_id")
    .withColumnRenamed("LTEXT", "cost_element_desc")
    .withColumn("cost_element_id", regexp_replace("cost_element_id", r"^[0]*", ""))
    .select(
        "cost_element_id",
        "cost_element_desc",
        "cost_element_hierarchy_lvl1_id",
        "cost_element_hierarchy_lvl1_desc",
        "cost_element_hierarchy_lvl2_id",
        "cost_element_hierarchy_lvl2_desc",
        "cost_element_hierarchy_lvl3_id",
        "cost_element_hierarchy_lvl3_desc",
        "cost_element_hierarchy_lvl4_id",
        "cost_element_hierarchy_lvl4_desc",
        "cost_element_hierarchy_lvl5_id",
        "cost_element_hierarchy_lvl5_desc")
    .distinct()
)

# COMMAND ----------

# display(groupedHierarchivedCostElementsDF)

# COMMAND ----------

# MAGIC %md
# MAGIC # Write

# COMMAND ----------

table_zone = "gold_finance_as"
table_name = "cost_elements_hierarchy"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
groupedHierarchivedCostElementsDF.createOrReplaceTempView(f"{table_name}_tmp")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC # Test

# COMMAND ----------

# %sql
# select * from gold_finance_as.cost_elements_hierarchy
# where cost_element_id = "60331201"
