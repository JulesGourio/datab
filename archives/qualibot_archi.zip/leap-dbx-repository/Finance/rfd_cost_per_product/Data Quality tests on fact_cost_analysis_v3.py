# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC TODO:
# MAGIC * Test(s) budget 7, 11, 12
# MAGIC * Test(s) actual 7

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

# MAGIC %run "../../unity_catalog/Utils/Common Functions"

# COMMAND ----------

env = get_env_variables()
read_env = env["read_env"]
write_env = env["write_env"]
print(env)

# COMMAND ----------

# Each test in the test table is defined by a combination of its "data" and "success_condition" fields, which allows users to re-run the exact same tests

schema = "(label STRING, data STRING, success_conditions STRING, value STRING, success BOOLEAN, comments STRING, datetime STRING)"
zone = "proj"
domain = "prodcosts"
table = "tests"
schema = "(label STRING, data STRING, success_conditions STRING, value STRING, success BOOLEAN, comments STRING, datetime STRING)"
create_leap_table_if_not_exists(write_env, zone, domain, table, schema)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ${read_env}_proj.prodcosts.tests

# COMMAND ----------

# MAGIC %md
# MAGIC # Budget

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## 1. Budget amount on an article that is bought

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Budget amount on an article that is bought" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where product = 'A2P' and reporting_month = 201901 and part_number = 'D5211062520000'" data
# MAGIC   , "sum(budget_yearly) = 13.12" success_conditions
# MAGIC   , round(sum(budget_yearly), 2) value
# MAGIC   , case when sum(budget_yearly) = 13.12 then True else False end success
# MAGIC   , "" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = 'D5211062520000';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Budget hours on an article that is built

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- On devrait trouver dans CKIS 0.85 heures (une ligne à 0,1h pour 150 pièces, une ligne à 0,75h pour 150 pièces, et des lignes à 0) qu'on divise par 150 pièces et qu'on multiplie par 8,36, d'où le 0.474 hours.
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Budget hours on an article that is built" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where product = 'A2P' and reporting_month = 201901 and part_number = 'D5211030220001' and cost_element_id = '92AZ4410'" data
# MAGIC   , "round(sum(budget_quantity), 3) = 0.047" success_conditions
# MAGIC   , round(sum(budget_quantity), 3) value
# MAGIC   , case when round(sum(budget_quantity), 3) = 0.047 then True else False end success
# MAGIC   , "On devrait trouver dans CKIS 0.85 heures (une ligne à 0,1h pour 150 pièces, une ligne à 0,75h pour 150 pièces, et des lignes à 0) qu'on divise par 150 pièces et qu'on multiplie par 8,36, d'où le 0.47 hours." comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = 'D5211030220001'
# MAGIC   and cost_element_id = '92AZ4410';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Budget amount on an article that is bought (SOBSL 30, achat matière confiée)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Budget amount on an article that is bought (SOBSL 30, achat matière confiée)" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where product = 'A2P' and reporting_month = 201901 and part_number = 'D5211184220000A00' and cost_element_id = '60535101'" data
# MAGIC   , "sum(budget_yearly) = 60.08" success_conditions
# MAGIC   , round(sum(budget_yearly), 2) value
# MAGIC   , case when sum(budget_yearly) = 60.08 then True else False end success
# MAGIC   , "" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = 'D5211184220000A00'
# MAGIC   and cost_element_id = '60535101';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Budget amount on part number D5211543520000

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Budget amount on part number D5211543520000" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where product = 'A2P' and reporting_month = 201901 and part_number = 'D5211543520000' and cost_element_id = '92AF4810'" data
# MAGIC   , "round(sum(budget_yearly), 3) = 18.796" success_conditions
# MAGIC   , round(sum(budget_yearly), 3) value
# MAGIC   , case when round(sum(budget_yearly), 3) = 18.796 then True else False end success
# MAGIC   , "budget_yearly = 18.796 (total cout budgetté = 225,55 / taille de lot = 12 * bom_qty = 1)" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = 'D5211543520000'
# MAGIC   and cost_element_id = '92AF4810';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Budget: null values for part_number like 1NNNNNN (where N is a numeric character)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Budget: null values for part_number like 1NNNNNN (where N is a numeric character)" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where phase = 'budget' and part_number = '1047373' and plant = '1000' and product = 'A3T'" data
# MAGIC   , "count(*) = 12" success_conditions
# MAGIC   , count(*) value
# MAGIC   , case when count(*) = 12 then True else False end success
# MAGIC   , "Pour les part_number qui commencent par 1 (par exemple 1047373), lorsqu'on a des valeurs null pour le budget, on veut quand meme voir apparaitre les lignes lorsqu'elles sont dans le BOM" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where phase = "budget"
# MAGIC   and part_number = "1047373"
# MAGIC   and plant = "1000"
# MAGIC   and product = "A3T";
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Budget: validation on SAP inconsistency

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Budget: validation on SAP inconsistency" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where product = 'A2P' and reporting_month = 201901 and part_number = 'D5211401620000' and plant = '1000'" data
# MAGIC   , "count(*) = 1" success_conditions
# MAGIC   , count(*) value
# MAGIC   , case when count(*) = 1 then True else False end success
# MAGIC   , "On ne doit pas avoir de ligne, car il y a une incohérence entre la BOM budget et le calcul du budget : il est prévu comme acheté avec matière confiée dans le prix standard, alors qu'il apparait comme fabriqué en interne dans le BOM" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where phase = "budget"
# MAGIC   and product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = 'D5211401620000'
# MAGIC   and plant = '1000';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## 7. Valeur de YTD
# MAGIC TODO : Confirmer le succès du test le cas échéant

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Find a cost element to dig
# MAGIC -- select * 
# MAGIC -- from trusted.cost_elements_hierarchy
# MAGIC -- where cost_element_desc = 'Sheet-metal Production'
# MAGIC -- 92AZ4810
# MAGIC 
# MAGIC -- select reporting_month, sum(actual_month_amount) actual_month_amount, sum(actual_ytd_amount) actual_ytd_amount 
# MAGIC -- from refined.fact_cost_analysis_v2
# MAGIC -- where cost_element_id = '92AZ4810'
# MAGIC --   and reporting_month in (201901, 201902)
# MAGIC --   and product = 'A2P'
# MAGIC -- group by reporting_month
# MAGIC -- order by 1
# MAGIC 
# MAGIC -- reporting_month,actual_month_amount,actual_ytd_amount
# MAGIC --          201901,                 66,               66
# MAGIC --          201902,                410,              414
# MAGIC 
# MAGIC -- Comment un month de 66 en janvier puis 410 en février peut amener un YTD de février à 414 ? 
# MAGIC 
# MAGIC -- select *
# MAGIC -- from refined.fact_cost_analysis_v2
# MAGIC -- where cost_element_id = '92AZ4810'
# MAGIC --   and reporting_month in (201901, 201902)
# MAGIC --   and product = 'A2P'
# MAGIC --   and actual_ytd_amount > actual_month_amount
# MAGIC -- order by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
# MAGIC 
# MAGIC -- select sum(budget_yearly) budget_yearly, sum(actual_month_amount) actual_month_amount, sum(actual_ytd_amount) actual_ytd_amount 
# MAGIC -- from refined.fact_cost_analysis_v2
# MAGIC -- where cost_element_id = '92AZ4810'
# MAGIC --   and reporting_month in (201902)
# MAGIC --   and product = 'A2P'
# MAGIC --   and part_number = 'A5227022520200'
# MAGIC 
# MAGIC -- No problem here: 
# MAGIC -- select *
# MAGIC -- from refined.fact_cost_analysis_v2
# MAGIC -- where cost_element_id = '92AZ4810'
# MAGIC --   and reporting_month in (201901, 201902)
# MAGIC --   and product = 'A2P'
# MAGIC --   and part_number = 'A5227022520200'
# MAGIC -- order by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
# MAGIC 
# MAGIC --  select part_number, reporting_month, actual_ytd_amount, actual_month_amount, *
# MAGIC -- from refined.fact_cost_analysis_v2
# MAGIC -- where part_number = 'A5227022520200'
# MAGIC --   and reporting_month in (201901, 201902)
# MAGIC --   and product = 'A2P'
# MAGIC --   and actual_ytd_amount > actual_month_amount
# MAGIC -- order by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
# MAGIC 
# MAGIC --select reporting_month, sum(actual_month_amount) actual_month_amount, sum(actual_ytd_amount) actual_ytd_amount 
# MAGIC 
# MAGIC -- select part_number, reporting_month, actual_month_amount, actual_ytd_amount
# MAGIC -- from refined.fact_cost_analysis_v2
# MAGIC -- where cost_element_id = '92AZ4810'
# MAGIC --   and reporting_month in (201901, 201902)
# MAGIC --   --and reporting_month = 201901
# MAGIC --  -- and actual_month_amount is not null
# MAGIC --   and product = 'A2P'
# MAGIC -- order by 1, 2, 3
# MAGIC 
# MAGIC 
# MAGIC select part_number, reporting_month, actual_month_amount, actual_ytd_amount, *
# MAGIC from refined.fact_cost_analysis_v2
# MAGIC where cost_element_id = '92AZ4810'
# MAGIC   and reporting_month in (201901, 201902)
# MAGIC   --and reporting_month = 201901
# MAGIC  -- and actual_month_amount is not null
# MAGIC   and product = 'A2P'
# MAGIC order by 1, 2, 3

# COMMAND ----------

# MAGIC %sql
# MAGIC select reporting_month, sum(actual_month_amount), sum(actual_ytd_amount)
# MAGIC from refined.fact_cost_analysis_v2
# MAGIC where cost_element_id = '92AZ4810'
# MAGIC   and reporting_month in (201901, 201902)
# MAGIC   and product = 'A2P'
# MAGIC group by reporting_month
# MAGIC order by 1, 2, 3

# COMMAND ----------

# MAGIC %sql 
# MAGIC 
# MAGIC select sum(budget_yearly) budget_yearly, sum(actual_month_amount) actual_month_amount, sum(actual_ytd_amount) actual_ytd_amount 
# MAGIC from refined.fact_cost_analysis_v2
# MAGIC where cost_element_id = '92AZ4810'
# MAGIC   and reporting_month in (201902)
# MAGIC   and product = 'A2P'
# MAGIC   and part_number = 'A5227022520200'

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select reporting_month, actual_month_amount, actual_ytd_amount, *
# MAGIC from refined.fact_cost_analysis_v2
# MAGIC where cost_element_id = '0071335101'
# MAGIC   and reporting_month in (201901, 201902)
# MAGIC   and product = 'A2P'
# MAGIC   --and part_number = 'KOSTKA33'
# MAGIC order by 1

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## 8. Budget amount on part number 1006252
# MAGIC * SOLUTION : prendre le + récent par année, part number, plant (indépendant du cost element) - Fait le 26/07

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Budget amount on part number 1006252" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where product = 'A2P' and reporting_month = 201901 and part_number = '1006252' and cost_element_id = '60331101'" data
# MAGIC   , "round(sum(budget_yearly), 2) = 586.08" success_conditions
# MAGIC   , round(sum(budget_yearly), 2) value
# MAGIC   , case when round(sum(budget_yearly), 2) = 586.08 then True else False end success
# MAGIC   , "" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = '1006252'
# MAGIC   and cost_element_id = '60331101';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## 9. Budget amount on part number 1012552
# MAGIC * SOLUTION : changer le taux de change à 1,24 pour le dollars - Fait le 26/07

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Budget amount on part number 1012552" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where product = 'A2P' and plant = '1000' and reporting_month = 201901 and part_number = '1012552' and cost_element_id = '60331101'" data
# MAGIC   , "round(sum(budget_yearly), 2) = 4.29" success_conditions
# MAGIC   , round(sum(budget_yearly), 2) value
# MAGIC   , case when round(sum(budget_yearly), 2) = 4.29 then True else False end success
# MAGIC   , "" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where product = 'A2P'
# MAGIC   and plant = '1000'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = '1012552'
# MAGIC   and cost_element_id = '60331101';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## 10. Budget amount for indirect costs on part_number D5211549000001
# MAGIC * SOLUTION 1 : Appliquer les nouveaux filtres sur MARC.SOBSL et CKIS.KSTAR - Fait le 26/07
# MAGIC * SOLUTION 2 : k.LOSGR est un champ qui vient de l'entête KEKO de CKIS et n'est donc pas à sommer mais à prendre en max() - Fait le 26/07

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Budget amount for indirect costs on part_number D5211549000001 and cost_element_id 61AWKSHO" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where product = 'A2P' and reporting_month = 201901 and part_number = 'D5211549000001' and cost_element_id = '61AWKSHO'" data
# MAGIC   , "round(sum(budget_yearly), 2) = 24.75" success_conditions
# MAGIC   , round(sum(budget_yearly), 2) value
# MAGIC   , case when round(sum(budget_yearly), 2) = 24.75 then True else False end success
# MAGIC   , "" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = 'D5211549000001'
# MAGIC   and cost_element_id = '61AWKSHO';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Budget amount for indirect costs on part_number D5211549000001 and cost_element_id 68AWKSHO" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where product = 'A2P' and reporting_month = 201901 and part_number = 'D5211549000001' and cost_element_id = '68AWKSHO'" data
# MAGIC   , "round(sum(budget_yearly), 2) = 16.28" success_conditions
# MAGIC   , round(sum(budget_yearly), 2) value
# MAGIC   , case when round(sum(budget_yearly), 2) = 16.28 then True else False end success
# MAGIC   , "" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = 'D5211549000001'
# MAGIC   and cost_element_id = '68AWKSHO';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Budget amount for indirect costs on part_number D5211549000001 and cost_element_id 92AG4110" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where product = 'A2P' and reporting_month = 201901 and part_number = 'D5211549000001' and cost_element_id = '92AG4110'" data
# MAGIC   , "round(sum(budget_yearly), 2) = 121.63" success_conditions
# MAGIC   , round(sum(budget_yearly), 2) value
# MAGIC   , case when round(sum(budget_yearly), 2) = 121.63 then True else False end success
# MAGIC   , "" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = 'D5211549000001'
# MAGIC   and cost_element_id = '92AG4110';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %sql
# MAGIC     
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Budget amount for indirect costs on part_number D5211549000001 and cost_element_id 92AG5150" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysisfrom refined.fact_cost_analysis_v3 where product = 'A2P' and reporting_month = 201901 and part_number = 'D5211549000001' and cost_element_id = '92AG5150'" data
# MAGIC   , "round(sum(budget_yearly), 2) = 4.53" success_conditions
# MAGIC   , round(sum(budget_yearly), 2) value
# MAGIC   , case when round(sum(budget_yearly), 2) = 4.53 then True else False end success
# MAGIC   , "" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = 'D5211549000001'
# MAGIC   and cost_element_id = '92AG5150';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## 11. Budget amount for cost of bom budget exceptions

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- doit avoir les valeurs issues de budgets_in_bom_exceptions
# MAGIC 
# MAGIC select *
# MAGIC from refined.fact_cost_analysis_v3
# MAGIC where phase = "budget"
# MAGIC   and part_number = "1045002"
# MAGIC   and plant = "1000"
# MAGIC   and product = "A3T";

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- doit avoir les valeurs issues de budgets_in_bom_exceptions
# MAGIC 
# MAGIC select *
# MAGIC from refined.fact_cost_analysis_v3
# MAGIC where phase = "budget"
# MAGIC   and part_number = "F5331080400000-STH"
# MAGIC   and plant = "1000"
# MAGIC   and product = "A3T";

# COMMAND ----------

# MAGIC %md
# MAGIC ## 12

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT phase, product, reporting_month, plant, part_number, cost_element_id, supplier, bom_quantity, budget_quantity_for_control, budget_hours_for_control, budget_value_for_control, budget_quantity, budget_yearly, *
# MAGIC FROM refined.fact_cost_analysis_v3
# MAGIC WHERE phase = "budget"
# MAGIC   AND product = "A2P"
# MAGIC   AND reporting_month = 201909
# MAGIC   AND plant = 1000
# MAGIC   AND cost_element_id = "RNREBE0711"
# MAGIC -- ORDER BY budget_yearly DESC

# COMMAND ----------

# MAGIC %md
# MAGIC # Actual

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## 1. Actual amount on an article that is bought

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Actual amount on an article that is bought" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysisfrom refined.fact_cost_analysis_v3 where product = 'A2P' and reporting_month = 201901 and part_number = 'D5211062520000'" data
# MAGIC   , "round(sum(actual_month_amount), 2) = -13.12" success_conditions
# MAGIC   , round(sum(actual_month_amount), 2) value
# MAGIC   , case when round(sum(actual_month_amount), 2) = -13.12 then True else False end success
# MAGIC   , "C'est un article acheté, donc il n'y a pas de quantity en heures (actual_month_quantity)" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = 'D5211062520000';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Actual quantity on an article that is built

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Actual quantity on an article that is built" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where product = 'A2P' and reporting_month = 201901 and part_number = 'D5211030220001' and cost_element_id = '92AZ4410'" data
# MAGIC   , "round(sum(actual_month_quantity), 3) = 0.030" success_conditions
# MAGIC   , round(sum(actual_month_quantity), 3) value
# MAGIC   , case when round(sum(actual_month_quantity), 3) = 0.030 then True else False end success
# MAGIC   , "Pour ce cas en particulier, l'actual en heures est seulement le quart du budget, les données sont valides" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = 'D5211030220001'
# MAGIC   and cost_element_id = '92AZ4410';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Actual: Validation on part number D5211030220001 and cost_element_id 0060510000

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Already false
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Actual: Validation on part number D5211030220001 and cost_element_id 0060510000" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where product = 'A2P' and reporting_month = 201901 and part_number = 'D5211030220001' and cost_element_id = '60510000'" data
# MAGIC   , "count(*) = 0" success_conditions
# MAGIC   , count(*) value
# MAGIC   , case when count(*) = 0 then True else False end success
# MAGIC   , "On ne devrait avoir aucune ligne pour cette requête" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = 'D5211030220001'
# MAGIC   and cost_element_id = '60510000';
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- le montant de la ligne avec supplier = internal est bon
# MAGIC -- le montant de l'autre ligne actual est créé par le remplacement des valeur actual null par les valeurs budget car supplier est dans la clé de jointure, et est à enlever
# MAGIC select *
# MAGIC from refined.fact_cost_analysis_v3
# MAGIC where product = 'A2P'
# MAGIC   and reporting_month = 201901
# MAGIC   and part_number = 'D5211030220001'
# MAGIC   and cost_element_id = '60510000';

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from trusted.costs_in_bom_internal
# MAGIC where validity_date_yyyymm = 201901
# MAGIC   and part_number = 'D5211030220001'
# MAGIC   and cost_element_id = '60510000';

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from trusted.costs_out_of_bom
# MAGIC where validity_date_yyyymm = 201901
# MAGIC   and product_id = 'A2P'
# MAGIC   and cost_element_id = '60510000';

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from trusted.costs_in_bom_external
# MAGIC where validity_date_yyyymm = 201901
# MAGIC   and part_number = 'D5211030220001'
# MAGIC   and cost_element_id = '60510000';

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Intercompany elimination

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC with test as
# MAGIC (
# MAGIC   select *
# MAGIC   from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC   where product = 'A2P'
# MAGIC     and reporting_month = 201901
# MAGIC     and part_number = 'A5211140120000'
# MAGIC     and cost_element_id = '71335101'
# MAGIC )
# MAGIC select "Intercompany elimination" label
# MAGIC   , "with test as ( select * from ${read_env}_proj.prodcosts.costs_analysis where product = 'A2P' and reporting_month = 201901 and part_number = 'A5211140120000' and cost_element_id = '71335101' ) from test" data
# MAGIC   , "round(sum(actual_month_amount), 2) = -17.68 and round(sum(budget_yearly), 2) = 26.52 and (select bom_quantity from test where phase = 'actual') = 4 and (select bom_quantity from test where phase = 'budget') = 6" success_conditions
# MAGIC   , concat(
# MAGIC     "round(sum(actual_month_amount), 2) = ", round(sum(actual_month_amount), 2),
# MAGIC     " and round(sum(budget_yearly), 2) = ", round(sum(budget_yearly), 2),
# MAGIC     " and (select bom_quantity from test where phase = 'actual') = ",  (select bom_quantity from test where phase = 'actual'),
# MAGIC     " and (select bom_quantity from test where phase = 'budget') = ", (select bom_quantity from test where phase = 'budget')) value
# MAGIC   , case
# MAGIC       when round(sum(actual_month_amount), 2) = -17.68
# MAGIC         and round(sum(budget_yearly), 2) = 26.52
# MAGIC         and (select bom_quantity from test where phase = 'actual') = 4
# MAGIC         and (select bom_quantity from test where phase = 'budget') = 6
# MAGIC       then True
# MAGIC       else False
# MAGIC     end success
# MAGIC   , "Ce cas particulier élimine bien les interco, et gère aussi la différence entre la bom_quantity de janvier et la bom_quantity budget" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from test;
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Actual: null values for part_number like 1NNNNNN (where N is a numeric character)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Actual: null values for part_number like 1NNNNNN (where N is a numeric character)" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where phase = 'actual' and plant = '1000' and site = 'LATE - Gimont' and product = 'A3T' and part_number = '1047373' and LEFT(reporting_month, 4) = '2019'" data
# MAGIC   , "count(*) = 12" success_conditions
# MAGIC   , count(*) value
# MAGIC   , case when count(*) = 12 then True else False end success
# MAGIC   , "Pour les part_number qui commencent par 1 (par exemple 1047373), lorsqu'on a des valeurs null pour actual, on veut quand meme voir apparaitre les lignes lorsqu'elles sont dans le BOM" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where phase = "actual"
# MAGIC   and plant = "1000"
# MAGIC   and site = "LATE - Gimont"
# MAGIC   and product = "A3T"
# MAGIC   and part_number = "1047373"
# MAGIC   and LEFT(reporting_month, 4) = "2019";
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Actual amount on part number A5211020020000

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- 3 work order doivent être utilisés pour cette valeur de actual : 000003291350, 000003291351 et 000003298107.
# MAGIC -- Seul le work order 000003298107 est pris en compte aujourd'hui lorsqu'on regarde les tables intermédiaires de actual_internal_costs_v2.
# MAGIC -- 28/07 : le problème vient du fait que les 2 autres OBJNR pour ce KSTAR sont avec un COSS/COSP.GJAHR = 2018 ; à ce jour on filtre sur GJAHR = 2019 pour COSS/COSP ;
# MAGIC -- lors de l'ingestion d'un historique plus large pour COSS/COSP, nos valeurs devraient s'actualiser correctement, et faire passer le résultat de ce test à False.  
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW test_tmp
# MAGIC AS
# MAGIC select "Actual amount on part number A5211020020000" label
# MAGIC   , "from ${read_env}_proj.prodcosts.costs_analysis where part_number = 'A5211020020000' and cost_element_id = '60520000' and reporting_month = 201901" data
# MAGIC   , "round(sum(actual_month_amount), 3) = 31.332" success_conditions
# MAGIC   , round(sum(actual_month_amount), 3) value
# MAGIC   , case when round(sum(actual_month_amount), 3) = 31.332 then True else False end success
# MAGIC   , "" comments
# MAGIC   , date_format(from_utc_timestamp(current_timestamp(), 'Europe/Paris'), 'yyyy-MM-dd HH:mm:ss') datetime
# MAGIC from ${read_env}_proj.prodcosts.costs_analysis
# MAGIC where part_number = "A5211020020000"
# MAGIC   and cost_element_id = "60520000"
# MAGIC   and reporting_month = 201901;
# MAGIC   
# MAGIC INSERT INTO ${write_env}_proj.prodcosts.tests TABLE test_tmp;
# MAGIC 
# MAGIC SELECT success_conditions, value, success FROM test_tmp;

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT phase, product, reporting_month, plant, part_number, cost_element_id, supplier, bom_quantity, actual_month_quantity, actual_month_amount, actual_value_for_control, actual_hours_for_control, actual_quantity_for_control, *
# MAGIC FROM refined.fact_cost_analysis_v3
# MAGIC WHERE phase = "actual"
# MAGIC   AND product = "A2P"
# MAGIC   AND reporting_month = 201901
# MAGIC   AND plant = 3000
# MAGIC   AND cost_element_id = "RNREBE0928"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8.
# MAGIC Partie 1542 External costs  
# MAGIC part_number = 1012605  
# MAGIC bseg.BELNR /accounting_document_number = 3000005117  
# MAGIC On devrait avoir des valeurs, on n'en a pas

# COMMAND ----------

bkpfDF = spark.read.format("parquet").option("ignoreTrailingWhiteSpace", True).load("/mnt/blobdatajourneyfrint/raw/sap/BKPF.parquet")
bsegDF = spark.read.format("parquet").option("ignoreTrailingWhiteSpace", True).load("/mnt/blobdatajourneyfrint/raw/sap/BSEG.parquet")
suppDF = spark.read.format("delta").option("ignoreTrailingWhiteSpace", True).load("/mnt/blobdatajourneyfrint/trusted/delta/suppliers")
currencyDF = spark.read.format("delta").load("/mnt/blobdatajourneyfrint/raw/delta/currency_exchange_rate")

bkpfDF = trim_df(bkpfDF)
bsegDF = trim_df(bsegDF)

bkpfDF.createOrReplaceTempView("BKPF")
bsegDF.createOrReplaceTempView("BSEG")
suppDF.createOrReplaceTempView("suppliers")
currencyDF.createOrReplaceTempView("currency")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM BSEG
# MAGIC WHERE BELNR = 3000005117

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM trusted.costs_in_bom_external
# MAGIC WHERE part_number = 1012605
# MAGIC   AND accounting_document_number = 3000005117

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM refined.fact_cost_analysis_v3
# MAGIC WHERE phase = "actual"
# MAGIC   AND part_number = 1012605
# MAGIC   AND reporting_month = 201901
# MAGIC   AND cost_element_id = "60331101"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9.
# MAGIC Partie 1541 Internal costs  
# MAGIC part_number = D5211543620100  
# MAGIC On doit avoir des work order pour le mois de février

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM trusted.costs_in_bom_internal
# MAGIC WHERE validity_date_yyyymm = 201902
# MAGIC   AND part_number = "D5211543620100"

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SELECT cost_element_id, actual_month_amount, *
# MAGIC FROM refined.fact_cost_analysis_v3
# MAGIC where part_number = "D5211543620100"
# MAGIC   and reporting_month = 201902
# MAGIC   and phase = "actual"
# MAGIC   
# MAGIC -- On devrait avoir un coût pour le cost_element_id 60520000

# COMMAND ----------

# MAGIC %md
# MAGIC ## 10.
# MAGIC Partie 1541 Internal costs  
# MAGIC SELECT cost_element_id, actual_month_amount
# MAGIC FROM refined.fact_cost_analysis_v3
# MAGIC where part_number = "D5211543620100"
# MAGIC   and reporting_month = 201902
# MAGIC   and phase = "actual"  
# MAGIC On devrait avoir un coût pour le cost_element_id 60520000

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SELECT cost_element_id, actual_month_amount, *
# MAGIC FROM refined.fact_cost_analysis_v3
# MAGIC where part_number = "D5211543620100"
# MAGIC   and reporting_month = 201902
# MAGIC   and phase = "actual"
# MAGIC   
# MAGIC -- On devrait avoir un coût pour le cost_element_id 60520000

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SELECT *
# MAGIC FROM trusted.costs_in_bom_internal
# MAGIC where part_number = "D5211543620100"
# MAGIC   and validity_date_yyyymm = 201902

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SELECT *
# MAGIC FROM trusted.cost_elements_hierarchy
# MAGIC where cost_element_id = "60520000"

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW costs_in_bom_internal_tmp
# MAGIC AS
# MAGIC WITH prod_site AS (
# MAGIC   SELECT plant, site_reporting
# MAGIC   FROM raw.prod_site_param_v2
# MAGIC   WHERE plant IS NOT NULL
# MAGIC     AND mrp_c IS NULL
# MAGIC ),
# MAGIC costs AS (
# MAGIC   SELECT part_number, cost_element_id, validity_date_yyyymm, plant, sum(work_order_quantity) work_order_quantity, sum(cost_eur) cost_eur, sum(cost_hours) cost_hours
# MAGIC   FROM trusted.costs_in_bom_internal
# MAGIC   GROUP BY part_number, cost_element_id, validity_date_yyyymm, plant
# MAGIC )
# MAGIC SELECT
# MAGIC   'actual' phase
# MAGIC   , v.plant plant
# MAGIC   , CASE
# MAGIC       WHEN bom.divi = "1000" AND LEFT(bom.mrp_c, 1) = "O" THEN "LATE - Montredon"
# MAGIC       WHEN bom.divi = "1000" AND LEFT(bom.mrp_c, 1) != "O" THEN "LATE - Gimont"
# MAGIC       ELSE p.site_reporting
# MAGIC     END site
# MAGIC   , bom.product product
# MAGIC   , v.validity_date_yyyymm month_id
# MAGIC   , v.part_number part_number
# MAGIC   , 'Internal' supplier
# MAGIC   , 'Internal' supplier_name
# MAGIC   , bom.procu procu
# MAGIC   , v.cost_element_id cost_element_id
# MAGIC 
# MAGIC   , max(elem.cost_element_desc) cost_element_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_id) cost_element_hierarchy_lvl1_id                           -- should we keep these as separate dimensions brought into power BI? 
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_desc) cost_element_hierarchy_lvl1_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_id) cost_element_hierarchy_lvl2_id
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_desc) cost_element_hierarchy_lvl2_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_id) cost_element_hierarchy_lvl3_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_desc) cost_element_hierarchy_lvl3_desc  
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_id) cost_element_hierarchy_lvl4_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_desc) cost_element_hierarchy_lvl4_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_id) cost_element_hierarchy_lvl5_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_desc) cost_element_hierarchy_lvl5_desc 
# MAGIC 
# MAGIC   , max(bom.skill) skill
# MAGIC   , max(bom.raw_material) raw_material
# MAGIC   , max(bom.manufacturing_process) manufacturing_process
# MAGIC   , max(bom.size) size
# MAGIC   , max(bom.class_std) class_std
# MAGIC   , max(bom.family_std) family_std
# MAGIC   , max(bom.assembly_level) assembly_level
# MAGIC   , max(bom.bom_quantity) bom_quantity
# MAGIC   
# MAGIC   , null budget_hours_for_control
# MAGIC   , null budget_value_for_control
# MAGIC   , sum(v.cost_hours) actual_hours_for_control
# MAGIC   , sum(v.cost_eur) actual_value_for_control
# MAGIC   
# MAGIC   , null budget_quantity_for_control
# MAGIC   , sum(v.work_order_quantity) actual_quantity_for_control
# MAGIC   
# MAGIC   , null budget_quantity
# MAGIC   , null budget_yearly   
# MAGIC   , sum(v.cost_hours / v.work_order_quantity * bom.bom_quantity) as actual_month_quantity
# MAGIC   , sum(v.cost_eur / v.work_order_quantity * bom.bom_quantity) as actual_month_amount
# MAGIC 
# MAGIC FROM trusted.bill_of_material bom
# MAGIC INNER JOIN costs v ON 'actual' = bom.phase AND v.part_number = bom.material AND v.plant = bom.divi AND v.validity_date_yyyymm = bom.month
# MAGIC LEFT JOIN prod_site p ON p.plant = bom.divi
# MAGIC LEFT JOIN trusted.cost_elements_hierarchy elem ON elem.cost_element_id = v.cost_element_id
# MAGIC -- WHERE NOT(bom.procu = "E" AND elem.cost_element_hierarchy_lvl2_id = "Z-2-1-1-1")      -- MhB 25/07 : Pour prise en compte uniquement de la valeur ajoutée pour les internal costs
# MAGIC GROUP BY v.plant, site, bom.product, v.validity_date_yyyymm, v.part_number, bom.procu, v.cost_element_id

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Filtered out by:
# MAGIC -- WHERE NOT(bom.procu = "E" AND elem.cost_element_hierarchy_lvl2_id = "Z-2-1-1-1")      -- MhB 25/07 : Pour prise en compte uniquement de la valeur ajoutée pour les internal costs
# MAGIC 
# MAGIC SELECT phase, month_id, part_number, cost_element_id, procu, cost_element_hierarchy_lvl2_id, *
# MAGIC FROM costs_in_bom_internal_tmp
# MAGIC where part_number = "D5211543620100"
# MAGIC   and month_id = 201902
# MAGIC   and phase = "actual"
# MAGIC   and cost_element_id = "60520000"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 11.
# MAGIC Partie 1542 External costs  
# MAGIC part_number = "D5211542220100"
# MAGIC reporting_month = 201902
# MAGIC phase = "actual"  
# MAGIC On devrait avoir cost_element_id = 71335101

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM refined.fact_cost_analysis_v3
# MAGIC where part_number = "D5211542220100"
# MAGIC   and reporting_month = 201902
# MAGIC   and phase = "actual"

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM trusted.costs_in_bom_external
# MAGIC WHERE part_number = "D5211542220100"
# MAGIC --   AND cost_element_id LIKE "%71335101"
# MAGIC 
# MAGIC -- Règle pour costs_in_bom_external.cost_element_id
# MAGIC -- WHEN m.procu = "F" AND m.specia = "20" AND LENGTH(m.mat_chara) = 9 THEN '71335101'

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM trusted.costs_in_bom_external
# MAGIC WHERE part_number = "D5211542220100"
# MAGIC --   AND cost_element_id LIKE "%71335101"
# MAGIC 
# MAGIC -- WHEN m.procu = "F" AND m.specia = "20" AND LENGTH(m.mat_chara) = 4 THEN '60331101'
# MAGIC -- WHEN m.procu = "F" AND m.specia = "20" AND LENGTH(m.mat_chara) = 9 THEN '71335101'
# MAGIC -- WHEN m.procu = "F" AND m.specia = "30" THEN '60520000'
# MAGIC -- WHEN m.procu IN ("X", "E") AND m.specia = "" THEN '71335101'

# COMMAND ----------

# MAGIC %md
# MAGIC ## 12. Amount with empty cost_element_id and part_number

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC -- SELECT sum(actual_month_amount)
# MAGIC FROM refined.fact_cost_analysis_v3
# MAGIC where phase = "actual"
# MAGIC   and reporting_month = 201901
# MAGIC   and product = "A2P"
# MAGIC   and cost_element_id is null
# MAGIC   and actual_month_amount is not null

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from trusted.costs_in_bom_external
# MAGIC where validity_date_yyyymm = 201901
# MAGIC   and cost_element_id is null
# MAGIC   and is_intra_branch = False
# MAGIC   
# MAGIC -- WHEN m.procu = "F" AND m.specia = "20" AND LENGTH(m.mat_chara) = 4 THEN '60331101'
# MAGIC -- WHEN m.procu = "F" AND m.specia = "20" AND LENGTH(m.mat_chara) = 9 THEN '71335101'
# MAGIC -- WHEN m.procu = "F" AND m.specia = "30" THEN '60520000'
# MAGIC -- WHEN m.procu IN ("X", "E") AND m.specia = "" THEN '71335101'

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct specia from trusted.bill_of_material

# COMMAND ----------

# MAGIC %md
# MAGIC ## 13.

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- prix total 294155,27 / quantity 24 = Prix unitaire CZK 12256,47
# MAGIC 
# MAGIC -- 1542 External cost
# MAGIC -- corriger la conversion en prenant en compte bkpf.HWAER et bseg.DMBTR
# MAGIC --     , bkpf.HWAER currency_of_company
# MAGIC --     , bseg.DMBTR * CASE WHEN bseg.SHKZG == "H" THEN -1 ELSE 1 END amount_in_the_company_currency
# MAGIC 
# MAGIC -- conserver transaction_currency (WAERS)
# MAGIC -- ajouter company_currency (HWAER)
# MAGIC -- renommer cost en cost_transaction_currency
# MAGIC -- ajouter si possible cost_company_currency
# MAGIC 
# MAGIC -- pour les calcul en refined :
# MAGIC -- cost_transaction_currency à convertir en € dans unit_cost_eur / quantity_received qui nous donne cost_eur
# MAGIC 
# MAGIC -- table de currency actuelle en budget par an
# MAGIC -- ajouter une table de currency pour les actual ?
# MAGIC 
# MAGIC select *
# MAGIC from trusted.costs_in_bom_external
# MAGIC where part_number = "1008937"
# MAGIC   and validity_date_yyyymm = 201901

# COMMAND ----------

# MAGIC %md
# MAGIC ## 14.
# MAGIC internal costs avec de la sous-traitance

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from refined.fact_cost_analysis_v3
# MAGIC where phase = "actual"
# MAGIC   and reporting_month = 201905
# MAGIC   and product = "A2P"
# MAGIC   and cost_element_id = "60510000"
# MAGIC   and part_number = "D5211422120000"
# MAGIC 
# MAGIC -- actual_month_amount doit etre = -1.0037080548806068

# COMMAND ----------

# MAGIC %md
# MAGIC ## 15.
# MAGIC internal costs avec des travaux internes

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from refined.fact_cost_analysis_v3
# MAGIC where phase = "actual"
# MAGIC   and reporting_month = 201905
# MAGIC   and product = "A2P"
# MAGIC   and cost_element_id = "92AZ4321"
# MAGIC   and part_number = "D5211422120000"
# MAGIC 
# MAGIC -- actual_month_amount doit etre = 32.85

# COMMAND ----------

# MAGIC %md
# MAGIC ## 16.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM refined.fact_cost_analysis_v3
# MAGIC where cost_element_id = 60331201
# MAGIC   and part_number = "1002654"

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- atendu : pas de résultat
# MAGIC 
# MAGIC SELECT * FROM trusted.costs_in_bom_external
# MAGIC where cost_element_id = "60331101"
# MAGIC   and part_number = "1002654"
# MAGIC   and validity_date_yyyymm in (201910, 201911, 201912)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 17.

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from trusted.budgets_in_bom
# MAGIC where part_number = "D5211045920000"
# MAGIC and plant = "1000"

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from refined.fact_cost_analysis_v3
# MAGIC where part_number = "D5211045920000"
# MAGIC and plant = "1000"
# MAGIC and phase = "budget"
# MAGIC 
# MAGIC -- on devrait avoir des lignes

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC -- from budgets_in_bom_tmp
# MAGIC from trusted.bill_of_material
# MAGIC -- where part_number = "D5211045920000"
# MAGIC -- and plant = "1000"
# MAGIC -- and phase = "budget"
# MAGIC where material = "D5211045920000"
# MAGIC and divi = "1000"
# MAGIC and phase = "budget"
# MAGIC 
# MAGIC -- on devrait avoir des lignes

# COMMAND ----------

# MAGIC %md
# MAGIC # Other

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Bom rows conservation
# MAGIC All keys from trusted.bill_of_material had to be into refined.fact_cost_analysis_v3, even with null budget and actual values

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC with bom_control as (
# MAGIC   SELECT phase, divi, product, month, material
# MAGIC   FROM trusted.bill_of_material
# MAGIC   GROUP BY phase, divi, product, month, material
# MAGIC )
# MAGIC , fact_cost_analysis_control as (
# MAGIC   SELECT phase, plant, product, reporting_month, part_number
# MAGIC   FROM refined.fact_cost_analysis_v3
# MAGIC   GROUP BY phase, plant, product, reporting_month, part_number
# MAGIC )
# MAGIC SELECT
# MAGIC   (
# MAGIC       select count(*)
# MAGIC       from bom_control bom
# MAGIC       left join fact_cost_analysis_control f on f.phase = bom.phase and f.plant = bom.divi and f.product = bom.product and f.reporting_month = bom.month and f.part_number = bom.material
# MAGIC       where f.phase is null
# MAGIC       ) missing_count

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Bom matching ratio

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC with bom_control as (
# MAGIC   SELECT phase, divi, product, month, material
# MAGIC   FROM trusted.bill_of_material
# MAGIC   GROUP BY phase, divi, product, month, material
# MAGIC )
# MAGIC , fact_cost_analysis_control as (
# MAGIC   SELECT phase, plant, product, reporting_month, part_number, sum(budget_yearly) budget_yearly, sum(actual_month_amount) actual_month_amount
# MAGIC   FROM refined.fact_cost_analysis_v3
# MAGIC   GROUP BY phase, plant, product, reporting_month, part_number
# MAGIC )
# MAGIC SELECT
# MAGIC   (select count(*) from bom_control) bom_count
# MAGIC   , (
# MAGIC       select count(*)
# MAGIC       from bom_control bom
# MAGIC       left join fact_cost_analysis_control f on f.phase = bom.phase and f.plant = bom.divi and f.product = bom.product and f.reporting_month = bom.month and f.part_number = bom.material
# MAGIC       where f.budget_yearly is null and actual_month_amount is null
# MAGIC       ) empty_count
# MAGIC   , (
# MAGIC       select count(*)
# MAGIC       from bom_control bom
# MAGIC       left join fact_cost_analysis_control f on f.phase = bom.phase and f.plant = bom.divi and f.product = bom.product and f.reporting_month = bom.month and f.part_number = bom.material
# MAGIC       where f.budget_yearly is not null or actual_month_amount is not null
# MAGIC       ) matched_count
# MAGIC   , round(
# MAGIC       (
# MAGIC       select count(*)
# MAGIC       from bom_control bom
# MAGIC       left join fact_cost_analysis_control f on f.phase = bom.phase and f.plant = bom.divi and f.product = bom.product and f.reporting_month = bom.month and f.part_number = bom.material
# MAGIC       where f.budget_yearly is not null or actual_month_amount is not null
# MAGIC       )
# MAGIC       /
# MAGIC       (select count(*) from bom_control)
# MAGIC       , 2)
# MAGIC       matching_ratio
# MAGIC   , (
# MAGIC       select count(*)
# MAGIC       from bom_control bom
# MAGIC       left join fact_cost_analysis_control f on f.phase = bom.phase and f.plant = bom.divi and f.product = bom.product and f.reporting_month = bom.month and f.part_number = bom.material
# MAGIC       where f.budget_yearly is null and actual_month_amount is null
# MAGIC       )
# MAGIC     +
# MAGIC     (
# MAGIC       select count(*)
# MAGIC       from bom_control bom
# MAGIC       left join fact_cost_analysis_control f on f.phase = bom.phase and f.plant = bom.divi and f.product = bom.product and f.reporting_month = bom.month and f.part_number = bom.material
# MAGIC       where f.budget_yearly is not null or actual_month_amount is not null
# MAGIC       ) validity_check
