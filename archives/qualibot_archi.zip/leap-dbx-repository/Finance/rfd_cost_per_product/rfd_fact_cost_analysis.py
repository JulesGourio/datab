# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # Purpose
# MAGIC 
# MAGIC **Description:**  
# MAGIC pltm_prodcosts.costs_analysis:  
# MAGIC Consolidates and aggregates data to build costs_analysis dataset  
# MAGIC When there is no actual_month_amount for each combination of plant, production_site, product, month_id, part_number, cost_element_id, it takes the budget_yearly value  
# MAGIC Calculates Year-To-Date and Last-Closed-Quarter  
# MAGIC Overwrites the entire output table  
# MAGIC   
# MAGIC pltm_prodcosts.missing_cost_elements:  
# MAGIC Identifies all ingested cost_element_id that are not in gold_finance_as.cost_elements_hierarchy, allowing users to add these cost_element_id to the CSKU SETLEAF SETHEADERT SAP tables, in order to extract these SAP tables and update gold_finance_as.cost_elements_hierarchy  
# MAGIC Overwrites the entire output table  
# MAGIC 
# MAGIC **Output table(s):**  
# MAGIC pltm_prodcosts.costs_analysis  
# MAGIC pltm_prodcosts.missing_cost_elements  
# MAGIC 
# MAGIC **Intput table(s):**  
# MAGIC gold_finance_as.bill_of_material  
# MAGIC gold_finance_as.cost_elements_hierarchy  
# MAGIC gold_finance_as.costs_in_bom_internal  
# MAGIC gold_finance_as.costs_in_bom_external  
# MAGIC gold_finance_as.costs_out_of_bom  
# MAGIC gold_finance_as.budgets_in_bom  
# MAGIC gold_finance_as.budgets_in_bom_exceptions  
# MAGIC gold_finance_as.budgets_out_of_bom  
# MAGIC slvr_finance_as.production_sites  
# MAGIC slvr_finance_as.product_quantities  
# MAGIC slvr_finance_as.months_ytm  
# MAGIC slvr_finance_as.months_lcq  
# MAGIC slvr_sap.fi_suppliers  
# MAGIC 
# MAGIC **Triggers:**  
# MAGIC 
# MAGIC **Triggered by:**  
# MAGIC Finance Monthly job  
# MAGIC 
# MAGIC **TODO:**  

# COMMAND ----------

# MAGIC %md
# MAGIC # Settings

# COMMAND ----------

# MAGIC %sql 
# MAGIC 
# MAGIC -- TODO ArL: Why is broadcasting not working (stats not positioned?)
# MAGIC set spark.sql.autoBroadcastJoinThreshold=-1 

# COMMAND ----------

# Get environment variable (dev / uat / prod)
dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")
env

# COMMAND ----------

# MAGIC %md
# MAGIC # Consolidation
# MAGIC Consolidate all budgets & costs with BOM, cost element hierarchy, suppliers and production site

# COMMAND ----------

# MAGIC %md
# MAGIC ## costs_in_bom_internal

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW costs_in_bom_internal_tmp
# MAGIC AS
# MAGIC WITH prod_site AS (
# MAGIC   SELECT plant, site_reporting
# MAGIC   FROM slvr_finance_as.production_sites
# MAGIC   WHERE plant IS NOT NULL
# MAGIC     AND mrp_c IS NULL
# MAGIC ),
# MAGIC costs AS (
# MAGIC   SELECT part_number, cost_element_id, validity_date_yyyymm, plant
# MAGIC     , max(round(month_quantity_delivered, 3)) month_quantity_delivered
# MAGIC     , sum(round(cost_eur, 3)) cost_eur
# MAGIC     , sum(round(cost_hours, 3)) cost_hours
# MAGIC   FROM gold_finance_as.costs_in_bom_internal
# MAGIC   GROUP BY part_number, cost_element_id, validity_date_yyyymm, plant
# MAGIC )
# MAGIC SELECT
# MAGIC   'actual' phase
# MAGIC   , v.plant plant
# MAGIC   , CASE
# MAGIC       WHEN bom.divi = "1000" AND LEFT(bom.mrp_c, 1) = "O" THEN "LATE - Montredon"
# MAGIC       WHEN bom.divi = "1000" AND LEFT(bom.mrp_c, 1) != "O" THEN "LATE - Gimont"
# MAGIC       ELSE p.site_reporting
# MAGIC     END site
# MAGIC   , bom.product product
# MAGIC   , v.validity_date_yyyymm month_id
# MAGIC   , v.part_number part_number
# MAGIC   , 'Internal' supplier
# MAGIC   , 'Internal' supplier_name
# MAGIC   , v.cost_element_id cost_element_id
# MAGIC 
# MAGIC   , max(elem.cost_element_desc) cost_element_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_id) cost_element_hierarchy_lvl1_id                           -- should we keep these as separate dimensions brought into power BI? 
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_desc) cost_element_hierarchy_lvl1_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_id) cost_element_hierarchy_lvl2_id
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_desc) cost_element_hierarchy_lvl2_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_id) cost_element_hierarchy_lvl3_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_desc) cost_element_hierarchy_lvl3_desc  
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_id) cost_element_hierarchy_lvl4_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_desc) cost_element_hierarchy_lvl4_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_id) cost_element_hierarchy_lvl5_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_desc) cost_element_hierarchy_lvl5_desc 
# MAGIC 
# MAGIC   , max(bom.skill) skill
# MAGIC   , max(bom.raw_material) raw_material
# MAGIC   , max(bom.manufacturing_process) manufacturing_process
# MAGIC   , max(bom.size) size
# MAGIC   , max(bom.class_std) class_std
# MAGIC   , max(bom.family_std) family_std
# MAGIC   , max(bom.assembly_level) assembly_level
# MAGIC   , max(bom.specia) special_procurement
# MAGIC   , max(bom.procu) procurement_type
# MAGIC   , max(bom.bom_quantity) bom_quantity
# MAGIC   
# MAGIC   , null budget_hours_for_control
# MAGIC   , null budget_value_for_control
# MAGIC   , sum(v.cost_hours) actual_hours_for_control
# MAGIC   , sum(v.cost_eur) actual_value_for_control
# MAGIC   
# MAGIC   , null budget_quantity_for_control
# MAGIC   , sum(v.month_quantity_delivered) actual_quantity_for_control
# MAGIC   
# MAGIC   , null budget_quantity
# MAGIC   , null budget_yearly   
# MAGIC   , sum(v.cost_hours / v.month_quantity_delivered * bom.bom_quantity) as actual_month_quantity
# MAGIC   , sum(v.cost_eur / v.month_quantity_delivered * bom.bom_quantity) as actual_month_amount
# MAGIC 
# MAGIC FROM gold_finance_as.bill_of_material bom
# MAGIC INNER JOIN costs v ON 'actual' = bom.phase AND v.part_number = bom.material AND v.plant = bom.divi AND v.validity_date_yyyymm = bom.month
# MAGIC LEFT JOIN prod_site p ON p.plant = bom.divi
# MAGIC LEFT JOIN gold_finance_as.cost_elements_hierarchy elem ON elem.cost_element_id = v.cost_element_id
# MAGIC -- WHERE NOT(bom.procu = "E" AND elem.cost_element_hierarchy_lvl2_id = "Z-2-1-1-1")      -- MhB 25/07 : Pour prise en compte uniquement de la valeur ajoutée pour les internal costs
# MAGIC WHERE                                                                                    -- MhB 23/09 : Pour prise en compte uniquement de la valeur ajoutée pour les internal costs
# MAGIC   ((bom.specia IS NULL OR bom.specia = '52')
# MAGIC        AND (LEFT(v.cost_element_id, 1) IN ('9', 'R')
# MAGIC             OR LEFT(v.cost_element_id, 3) IN ('61A', '68A')
# MAGIC             OR LEFT(v.cost_element_id, 4) IN ('6051', '6052')))
# MAGIC   OR
# MAGIC   (bom.specia IN ('10', '20', '22')
# MAGIC        AND NOT(LEFT(v.cost_element_id, 1) IN ('9', 'R')
# MAGIC                OR LEFT(v.cost_element_id, 3) IN ('61A', '68A')
# MAGIC                OR LEFT(v.cost_element_id, 4) IN ('6051', '6052')))
# MAGIC   OR
# MAGIC   (bom.specia = '30' AND RIGHT(v.cost_element_id, 2) NOT IN ('07'))  
# MAGIC GROUP BY v.plant, site, bom.product, v.validity_date_yyyymm, v.part_number, v.cost_element_id

# COMMAND ----------

# MAGIC %md
# MAGIC ## costs_in_bom_external

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW costs_in_bom_external_tmp
# MAGIC AS
# MAGIC WITH prod_site AS (
# MAGIC   SELECT plant, site_reporting
# MAGIC   FROM slvr_finance_as.production_sites
# MAGIC   WHERE plant IS NOT NULL
# MAGIC     AND mrp_c IS NULL
# MAGIC ),
# MAGIC costs AS (
# MAGIC   SELECT part_number, cost_element_id, validity_date_yyyymm, plant, supplier_id
# MAGIC     , max(round(quantity_received, 3)) quantity_received
# MAGIC     , sum(round(cost_euro_from_company_currency, 3)) cost_eur
# MAGIC   FROM gold_finance_as.costs_in_bom_external
# MAGIC   WHERE is_intra_branch = False                                 -- MhB : 1.5.6. Intercompany elimination
# MAGIC   GROUP BY part_number, cost_element_id, validity_date_yyyymm, plant, supplier_id
# MAGIC )
# MAGIC SELECT
# MAGIC   'actual' phase
# MAGIC   , v.plant plant
# MAGIC   , CASE
# MAGIC       WHEN bom.divi = "1000" AND LEFT(bom.mrp_c, 1) = "O" THEN "LATE - Montredon"
# MAGIC       WHEN bom.divi = "1000" AND LEFT(bom.mrp_c, 1) != "O" THEN "LATE - Gimont"
# MAGIC       ELSE p.site_reporting
# MAGIC     END site
# MAGIC   , bom.product product
# MAGIC   , v.validity_date_yyyymm month_id
# MAGIC   , v.part_number part_number
# MAGIC   , v.supplier_id supplier
# MAGIC   , s.supplier_name supplier_name
# MAGIC   , v.cost_element_id cost_element_id
# MAGIC 
# MAGIC   , max(elem.cost_element_desc) cost_element_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_id) cost_element_hierarchy_lvl1_id                           -- should we keep these as separate dimensions brought into power BI? 
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_desc) cost_element_hierarchy_lvl1_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_id) cost_element_hierarchy_lvl2_id
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_desc) cost_element_hierarchy_lvl2_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_id) cost_element_hierarchy_lvl3_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_desc) cost_element_hierarchy_lvl3_desc  
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_id) cost_element_hierarchy_lvl4_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_desc) cost_element_hierarchy_lvl4_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_id) cost_element_hierarchy_lvl5_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_desc) cost_element_hierarchy_lvl5_desc 
# MAGIC 
# MAGIC   , max(bom.skill) skill
# MAGIC   , max(bom.raw_material) raw_material
# MAGIC   , max(bom.manufacturing_process) manufacturing_process
# MAGIC   , max(bom.size) size
# MAGIC   , max(bom.class_std) class_std
# MAGIC   , max(bom.family_std) family_std
# MAGIC   , max(bom.assembly_level) assembly_level
# MAGIC   , max(bom.specia) special_procurement
# MAGIC   , max(bom.procu) procurement_type
# MAGIC   , max(bom.bom_quantity) bom_quantity
# MAGIC   
# MAGIC   , null budget_hours_for_control
# MAGIC   , null budget_value_for_control
# MAGIC   , null actual_hours_for_control
# MAGIC   , sum(v.cost_eur) actual_value_for_control
# MAGIC   
# MAGIC   , null budget_quantity_for_control
# MAGIC   , sum(v.quantity_received) actual_quantity_for_control
# MAGIC   
# MAGIC   , null budget_quantity
# MAGIC   , null budget_yearly   
# MAGIC   , null actual_month_quantity
# MAGIC   , sum(v.cost_eur / v.quantity_received * bom.bom_quantity) as actual_month_amount
# MAGIC 
# MAGIC FROM gold_finance_as.bill_of_material bom
# MAGIC INNER JOIN costs v ON 'actual' = bom.phase AND v.part_number = bom.material AND v.plant = bom.divi AND v.validity_date_yyyymm = bom.month
# MAGIC LEFT JOIN gold_finance_as.cost_elements_hierarchy elem ON elem.cost_element_id = v.cost_element_id
# MAGIC LEFT JOIN prod_site p ON p.plant = bom.divi
# MAGIC LEFT JOIN slvr_sap.fi_suppliers s ON s.supplier = v.supplier_id
# MAGIC GROUP BY v.plant, site, bom.product, v.validity_date_yyyymm, v.part_number, v.supplier_id, s.supplier_name, v.cost_element_id

# COMMAND ----------

# MAGIC %md
# MAGIC ## costs_out_of_bom

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW costs_out_of_bom_tmp
# MAGIC AS
# MAGIC WITH prod_site AS (
# MAGIC   SELECT company, site_reporting
# MAGIC   FROM slvr_finance_as.production_sites
# MAGIC   WHERE plant IS NULL
# MAGIC )
# MAGIC , bom AS (
# MAGIC   SELECT phase, product, month, divi
# MAGIC   FROM gold_finance_as.bill_of_material
# MAGIC   GROUP BY phase, product, month, divi
# MAGIC )
# MAGIC , costs AS (
# MAGIC   SELECT 'actual' phase, product_id, cost_element_id, validity_date_yyyymm, plant, company
# MAGIC     , sum(round(cost_eur, 3)) cost_eur
# MAGIC     , sum(round(cost_hours, 3)) cost_hours
# MAGIC   FROM gold_finance_as.costs_out_of_bom
# MAGIC   GROUP BY phase, product_id, cost_element_id, validity_date_yyyymm, plant, company
# MAGIC )
# MAGIC SELECT
# MAGIC   bom.phase phase
# MAGIC   , v.plant plant
# MAGIC   , p.site_reporting site
# MAGIC   , bom.product product
# MAGIC   , v.validity_date_yyyymm month_id
# MAGIC   , 'Internal' part_number
# MAGIC   , 'Internal' supplier
# MAGIC   , 'Internal' supplier_name
# MAGIC   , v.cost_element_id cost_element_id
# MAGIC 
# MAGIC   , max(elem.cost_element_desc) cost_element_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_id) cost_element_hierarchy_lvl1_id                           -- should we keep these as separate dimensions brought into power BI? 
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_desc) cost_element_hierarchy_lvl1_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_id) cost_element_hierarchy_lvl2_id
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_desc) cost_element_hierarchy_lvl2_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_id) cost_element_hierarchy_lvl3_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_desc) cost_element_hierarchy_lvl3_desc  
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_id) cost_element_hierarchy_lvl4_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_desc) cost_element_hierarchy_lvl4_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_id) cost_element_hierarchy_lvl5_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_desc) cost_element_hierarchy_lvl5_desc 
# MAGIC 
# MAGIC   , null skill
# MAGIC   , null raw_material
# MAGIC   , null manufacturing_process
# MAGIC   , null size
# MAGIC   , null class_std
# MAGIC   , null family_std
# MAGIC   , null assembly_level
# MAGIC   , null special_procurement
# MAGIC   , null procurement_type
# MAGIC   , null bom_quantity
# MAGIC   
# MAGIC   , null budget_hours_for_control
# MAGIC   , null budget_value_for_control
# MAGIC   , sum(v.cost_hours) actual_hours_for_control
# MAGIC   , sum(v.cost_eur) actual_value_for_control
# MAGIC   
# MAGIC   , null budget_quantity_for_control
# MAGIC   , sum(q.actual) actual_quantity_for_control
# MAGIC   
# MAGIC   , null budget_quantity
# MAGIC   , null budget_yearly   
# MAGIC   , sum(v.cost_hours / q.actual) as actual_month_quantity
# MAGIC   , sum(v.cost_eur / q.actual) as actual_month_amount
# MAGIC 
# MAGIC FROM bom
# MAGIC INNER JOIN costs v ON v.phase = bom.phase AND v.product_id = bom.product AND v.plant = bom.divi AND v.validity_date_yyyymm = bom.month
# MAGIC LEFT JOIN gold_finance_as.cost_elements_hierarchy elem ON elem.cost_element_id = v.cost_element_id
# MAGIC LEFT JOIN slvr_finance_as.product_quantities q ON q.product_id = bom.product AND q.validity_date_yyyymm = bom.month
# MAGIC LEFT JOIN prod_site p ON p.company = v.company
# MAGIC GROUP BY bom.phase, v.plant, site, bom.product, v.validity_date_yyyymm, v.cost_element_id

# COMMAND ----------

# MAGIC %md
# MAGIC ## budgets_in_bom

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW budgets_in_bom_tmp
# MAGIC AS
# MAGIC WITH prod_site AS (
# MAGIC   SELECT plant, site_reporting
# MAGIC   FROM slvr_finance_as.production_sites
# MAGIC   WHERE plant IS NOT NULL
# MAGIC     AND mrp_c IS NULL
# MAGIC )
# MAGIC SELECT
# MAGIC   'budget' phase
# MAGIC   , v.plant plant
# MAGIC   , CASE
# MAGIC       WHEN bom.divi = "1000" AND LEFT(bom.mrp_c, 1) = "O" THEN "LATE - Montredon"
# MAGIC       WHEN bom.divi = "1000" AND LEFT(bom.mrp_c, 1) != "O" THEN "LATE - Gimont"
# MAGIC       ELSE p.site_reporting
# MAGIC     END site
# MAGIC   , bom.product product
# MAGIC   , bom.month month_id
# MAGIC   , v.part_number part_number
# MAGIC   , v.supplier_id supplier
# MAGIC   , s.supplier_name supplier_name
# MAGIC   , v.cost_element_id cost_element_id
# MAGIC 
# MAGIC   , max(elem.cost_element_desc) cost_element_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_id) cost_element_hierarchy_lvl1_id                           -- should we keep these as separate dimensions brought into power BI? 
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_desc) cost_element_hierarchy_lvl1_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_id) cost_element_hierarchy_lvl2_id
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_desc) cost_element_hierarchy_lvl2_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_id) cost_element_hierarchy_lvl3_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_desc) cost_element_hierarchy_lvl3_desc  
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_id) cost_element_hierarchy_lvl4_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_desc) cost_element_hierarchy_lvl4_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_id) cost_element_hierarchy_lvl5_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_desc) cost_element_hierarchy_lvl5_desc 
# MAGIC 
# MAGIC   , max(bom.skill) skill
# MAGIC   , max(bom.raw_material) raw_material
# MAGIC   , max(bom.manufacturing_process) manufacturing_process
# MAGIC   , max(bom.size) size
# MAGIC   , max(bom.class_std) class_std
# MAGIC   , max(bom.family_std) family_std
# MAGIC   , max(bom.assembly_level) assembly_level
# MAGIC   , max(bom.specia) special_procurement
# MAGIC   , max(bom.procu) procurement_type
# MAGIC   , max(bom.bom_quantity) bom_quantity
# MAGIC   
# MAGIC   , sum(v.lot_size_hours) budget_hours_for_control
# MAGIC   , sum(v.lot_size_cost_eur) budget_value_for_control
# MAGIC   , null actual_hours_for_control
# MAGIC   , null actual_value_for_control
# MAGIC   
# MAGIC   , sum(v.lot_size) budget_quantity_for_control
# MAGIC   , null actual_quantity_for_control
# MAGIC   
# MAGIC   , sum(v.lot_size_hours / v.lot_size * bom.bom_quantity) budget_quantity
# MAGIC   -- case when part number is null then value, else formula below
# MAGIC   -- remove division by v.cost_quantity_per_product, as budgets are already on unit values
# MAGIC   -- sum(v.cost_value_per_product_eur / v.cost_quantity_per_product * bom.bom_quantity) budget_yearly  
# MAGIC     , sum(v.lot_size_cost_eur / v.lot_size * bom.bom_quantity) budget_yearly   
# MAGIC       --sum(v.cost_value_per_product_eur / v.cost_quantity_per_product * bom.bom_quantity) budget_yearly  
# MAGIC   --, case when v.part_number is not null then sum(v.cost_value_per_product_eur * bom.bom_quantity) else  sum(v.cost_value_per_product_eur) end as budget_yearly   
# MAGIC   , null actual_month_quantity
# MAGIC   , null actual_month_amount
# MAGIC 
# MAGIC FROM gold_finance_as.bill_of_material bom
# MAGIC INNER JOIN gold_finance_as.budgets_in_bom v ON 'budget' = bom.phase AND v.part_number = bom.material AND v.plant = bom.divi AND v.year = LEFT(bom.month, 4)
# MAGIC LEFT JOIN gold_finance_as.cost_elements_hierarchy elem ON elem.cost_element_id = v.cost_element_id
# MAGIC LEFT JOIN slvr_sap.fi_suppliers s ON s.supplier = v.supplier_id
# MAGIC LEFT JOIN prod_site p ON p.plant = bom.divi
# MAGIC GROUP BY v.plant, site, bom.product, bom.month, v.part_number, v.supplier_id, s.supplier_name, v.cost_element_id

# COMMAND ----------

# %sql
# -- SELECT *
# -- from budgets_in_bom_tmp

# select 'budget' phase
#   , v.plant plant
# --   , CASE
# --       WHEN bom.divi = "1000" AND LEFT(bom.mrp_c, 1) = "O" THEN "LATE - Montredon"
# --       WHEN bom.divi = "1000" AND LEFT(bom.mrp_c, 1) != "O" THEN "LATE - Gimont"
# --       ELSE p.site_reporting
# --     END site
#   , bom.product product
#   , bom.month month_id
#   , v.part_number part_number
#   , v.supplier_id supplier
# --   , s.supplier_name supplier_name
#   , v.cost_element_id cost_element_id
  
#   , v.lot_size_hours budget_hours_for_control
#   , v.lot_size_cost_eur budget_value_for_control
  
#   , v.lot_size budget_quantity_for_control
  
#   , v.lot_size_hours / v.lot_size * bom.bom_quantity budget_quantity
#   , v.lot_size_cost_eur / v.lot_size * bom.bom_quantity budget_yearly   

# FROM gold_finance_as.bill_of_material bom
# INNER JOIN gold_finance_as.budgets_in_bom v ON 'budget' = bom.phase AND v.part_number = bom.material AND v.plant = bom.divi AND v.year = LEFT(bom.month, 4)
# LEFT JOIN gold_finance_as.cost_elements_hierarchy elem ON elem.cost_element_id = v.cost_element_id
# WHERE bom.product = "DNT"
#   and bom.month = 202207
#   and v.part_number = "F7XC544120301A3"

# COMMAND ----------

# %sql
# select * from gold_finance_as.cost_elements_hierarchy
# WHERE cost_element_id = "60535101"

# COMMAND ----------

# MAGIC %md
# MAGIC ## budgets_in_bom_exceptions

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW budgets_in_bom_exceptions_tmp
# MAGIC AS
# MAGIC 
# MAGIC WITH prod_site AS (
# MAGIC   SELECT plant, site_reporting
# MAGIC   FROM slvr_finance_as.production_sites
# MAGIC   WHERE plant IS NOT NULL
# MAGIC     AND mrp_c IS NULL
# MAGIC )
# MAGIC SELECT
# MAGIC   'budget' phase
# MAGIC   , v.plant plant
# MAGIC   , CASE
# MAGIC       WHEN bom.divi = "1000" AND LEFT(v.mrp_controller, 1) = "O" THEN "LATE - Montredon"
# MAGIC       WHEN bom.divi = "1000" AND LEFT(v.mrp_controller, 1) != "O" THEN "LATE - Gimont"
# MAGIC       ELSE p.site_reporting
# MAGIC     END site
# MAGIC   , bom.product product
# MAGIC   , bom.month month_id
# MAGIC   , v.part_number part_number
# MAGIC   , v.supplier_id supplier
# MAGIC   , s.supplier_name supplier_name
# MAGIC   , v.cost_element_id cost_element_id
# MAGIC 
# MAGIC   , max(elem.cost_element_desc) cost_element_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_id) cost_element_hierarchy_lvl1_id                           -- should we keep these as separate dimensions brought into power BI? 
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_desc) cost_element_hierarchy_lvl1_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_id) cost_element_hierarchy_lvl2_id
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_desc) cost_element_hierarchy_lvl2_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_id) cost_element_hierarchy_lvl3_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_desc) cost_element_hierarchy_lvl3_desc  
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_id) cost_element_hierarchy_lvl4_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_desc) cost_element_hierarchy_lvl4_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_id) cost_element_hierarchy_lvl5_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_desc) cost_element_hierarchy_lvl5_desc 
# MAGIC 
# MAGIC   , max(bom.skill) skill
# MAGIC   , max(bom.raw_material) raw_material
# MAGIC   , max(bom.manufacturing_process) manufacturing_process
# MAGIC   , max(bom.size) size
# MAGIC   , max(bom.class_std) class_std
# MAGIC   , max(bom.family_std) family_std
# MAGIC   , max(bom.assembly_level) assembly_level
# MAGIC   , max(bom.specia) special_procurement
# MAGIC   , max(bom.procu) procurement_type
# MAGIC   , max(bom.bom_quantity) bom_quantity
# MAGIC   
# MAGIC   , null budget_hours_for_control
# MAGIC   , sum(v.cost_value_per_product_eur) budget_value_for_control
# MAGIC   , null actual_hours_for_control
# MAGIC   , null actual_value_for_control
# MAGIC   
# MAGIC   , sum(v.cost_quantity_per_product) budget_quantity_for_control
# MAGIC   , null actual_quantity_for_control
# MAGIC   
# MAGIC   , null budget_quantity
# MAGIC   -- case when part number is null then value, else formula below
# MAGIC   -- remove division by v.cost_quantity_per_product, as budgets are already on unit values
# MAGIC   , case when v.part_number is not null then sum(v.cost_value_per_product_eur * bom.bom_quantity) else  sum(v.cost_value_per_product_eur) end as budget_yearly   
# MAGIC   , null actual_month_quantity
# MAGIC   , null actual_month_amount
# MAGIC 
# MAGIC FROM gold_finance_as.bill_of_material bom
# MAGIC INNER JOIN gold_finance_as.budgets_in_bom_exceptions v ON 'budget' = bom.phase AND v.part_number = bom.material AND v.plant = bom.divi AND v.year = LEFT(bom.month, 4)
# MAGIC -- RIGHT JOIN gold_finance_as.budgets_in_bom_exceptions v ON 'budget' = bom.phase AND v.part_number = bom.material AND v.plant = bom.divi AND v.year = LEFT(bom.month, 4) -- switch to RIGHT join, to get budgets without associated part number ex. cost elements like RNREBE%
# MAGIC LEFT JOIN gold_finance_as.cost_elements_hierarchy elem ON elem.cost_element_id = v.cost_element_id
# MAGIC LEFT JOIN slvr_sap.fi_suppliers s ON s.supplier = v.supplier_id
# MAGIC LEFT JOIN prod_site p ON p.plant = bom.divi
# MAGIC WHERE v.part_number IS NOT NULL
# MAGIC GROUP BY v.plant, site, bom.product, bom.month, v.part_number, v.supplier_id, s.supplier_name, v.cost_element_id
# MAGIC 
# MAGIC UNION ALL
# MAGIC 
# MAGIC SELECT
# MAGIC   'budget' phase
# MAGIC   , v.plant plant
# MAGIC   , CASE
# MAGIC       WHEN bom.divi = "1000" AND LEFT(v.mrp_controller, 1) = "O" THEN "LATE - Montredon"
# MAGIC       WHEN bom.divi = "1000" AND LEFT(v.mrp_controller, 1) != "O" THEN "LATE - Gimont"
# MAGIC       ELSE p.site_reporting
# MAGIC     END site
# MAGIC   , bom.product product
# MAGIC   , bom.month month_id
# MAGIC   , null part_number
# MAGIC   , v.supplier_id supplier
# MAGIC   , CASE v.supplier_id WHEN 'Internal' THEN 'Internal' ELSE s.supplier_name END supplier_name
# MAGIC   , v.cost_element_id cost_element_id
# MAGIC 
# MAGIC   , max(elem.cost_element_desc) cost_element_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_id) cost_element_hierarchy_lvl1_id                           -- should we keep these as separate dimensions brought into power BI? 
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_desc) cost_element_hierarchy_lvl1_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_id) cost_element_hierarchy_lvl2_id
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_desc) cost_element_hierarchy_lvl2_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_id) cost_element_hierarchy_lvl3_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_desc) cost_element_hierarchy_lvl3_desc  
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_id) cost_element_hierarchy_lvl4_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_desc) cost_element_hierarchy_lvl4_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_id) cost_element_hierarchy_lvl5_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_desc) cost_element_hierarchy_lvl5_desc 
# MAGIC 
# MAGIC   , null skill
# MAGIC   , null raw_material
# MAGIC   , null manufacturing_process
# MAGIC   , null size
# MAGIC   , null class_std
# MAGIC   , null family_std
# MAGIC   , null assembly_level
# MAGIC   , null special_procurement
# MAGIC   , null procurement_type
# MAGIC   , null bom_quantity
# MAGIC   
# MAGIC   , sum(v.cost_quantity_per_product) budget_hours_for_control
# MAGIC   , sum(v.cost_value_per_product_eur) budget_value_for_control
# MAGIC   , null actual_hours_for_control
# MAGIC   , null actual_value_for_control
# MAGIC   
# MAGIC   , null budget_quantity_for_control
# MAGIC   , null actual_quantity_for_control
# MAGIC   
# MAGIC   , sum(v.cost_quantity_per_product) budget_quantity
# MAGIC   , sum(v.cost_value_per_product_eur) budget_yearly   
# MAGIC   , null actual_month_quantity
# MAGIC   , null actual_month_amount
# MAGIC 
# MAGIC FROM (
# MAGIC   SELECT phase, product, month, divi
# MAGIC   FROM gold_finance_as.bill_of_material
# MAGIC   GROUP BY phase, product, month, divi
# MAGIC ) bom
# MAGIC INNER JOIN gold_finance_as.budgets_in_bom_exceptions v ON 'budget' = bom.phase AND v.product_id = bom.product AND v.plant = bom.divi AND v.year = LEFT(bom.month, 4)
# MAGIC LEFT JOIN gold_finance_as.cost_elements_hierarchy elem ON elem.cost_element_id = v.cost_element_id
# MAGIC LEFT JOIN slvr_sap.fi_suppliers s ON s.supplier = v.supplier_id
# MAGIC LEFT JOIN prod_site p ON p.plant = bom.divi
# MAGIC WHERE v.part_number IS NULL
# MAGIC GROUP BY v.plant, site, bom.product, bom.month, v.supplier_id, s.supplier_name, v.cost_element_id

# COMMAND ----------

# MAGIC %md
# MAGIC ## budgets_out_of_bom

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW budgets_out_of_bom_tmp
# MAGIC AS
# MAGIC WITH prod_site AS (
# MAGIC   SELECT plant, site_reporting
# MAGIC   FROM slvr_finance_as.production_sites
# MAGIC   WHERE plant IS NOT NULL
# MAGIC     AND mrp_c IS NULL
# MAGIC )
# MAGIC , bom AS (
# MAGIC   SELECT phase, product, month, divi
# MAGIC   FROM gold_finance_as.bill_of_material
# MAGIC   GROUP BY phase, product, month, divi
# MAGIC )
# MAGIC SELECT
# MAGIC   bom.phase phase
# MAGIC   , v.plant plant
# MAGIC   , CASE
# MAGIC       WHEN bom.divi = "1000" AND LEFT(v.mrp_controller, 1) = "O" THEN "LATE - Montredon"
# MAGIC       WHEN bom.divi = "1000" AND LEFT(v.mrp_controller, 1) != "O" THEN "LATE - Gimont"
# MAGIC       ELSE p.site_reporting
# MAGIC     END site
# MAGIC   , bom.product product
# MAGIC   , bom.month month_id
# MAGIC   , null part_number
# MAGIC   , v.supplier_id supplier
# MAGIC   , CASE v.supplier_id WHEN 'Internal' THEN 'Internal' ELSE s.supplier_name END supplier_name
# MAGIC   , v.cost_element_id cost_element_id
# MAGIC 
# MAGIC   , max(elem.cost_element_desc) cost_element_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_id) cost_element_hierarchy_lvl1_id                           -- should we keep these as separate dimensions brought into power BI? 
# MAGIC   , max(elem.cost_element_hierarchy_lvl1_desc) cost_element_hierarchy_lvl1_desc
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_id) cost_element_hierarchy_lvl2_id
# MAGIC   , max(elem.cost_element_hierarchy_lvl2_desc) cost_element_hierarchy_lvl2_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_id) cost_element_hierarchy_lvl3_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl3_desc) cost_element_hierarchy_lvl3_desc  
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_id) cost_element_hierarchy_lvl4_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl4_desc) cost_element_hierarchy_lvl4_desc 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_id) cost_element_hierarchy_lvl5_id 
# MAGIC   , max(elem.cost_element_hierarchy_lvl5_desc) cost_element_hierarchy_lvl5_desc 
# MAGIC 
# MAGIC   , null skill
# MAGIC   , null raw_material
# MAGIC   , null manufacturing_process
# MAGIC   , null size
# MAGIC   , null class_std
# MAGIC   , null family_std
# MAGIC   , null assembly_level
# MAGIC   , null special_procurement
# MAGIC   , null procurement_type
# MAGIC   , null bom_quantity
# MAGIC   
# MAGIC   , null budget_hours_for_control
# MAGIC   , sum(v.cost_value_per_product_eur) budget_value_for_control
# MAGIC   , null actual_hours_for_control
# MAGIC   , null actual_value_for_control
# MAGIC   
# MAGIC   , sum(v.cost_quantity_per_product) budget_quantity_for_control
# MAGIC   , null actual_quantity_for_control
# MAGIC   
# MAGIC   , null budget_quantity
# MAGIC   , sum(v.cost_value_per_product_eur) as budget_yearly   
# MAGIC   , null actual_month_quantity
# MAGIC   , null actual_month_amount
# MAGIC 
# MAGIC FROM bom
# MAGIC INNER JOIN gold_finance_as.budgets_out_of_bom v ON 'budget' = bom.phase AND v.product_id = bom.product AND v.plant = bom.divi AND v.year = LEFT(bom.month, 4)
# MAGIC -- RIGHT JOIN gold_finance_as.budgets_out_of_bom v ON 'budget' = bom.phase AND v.product_id = bom.product AND v.plant = bom.divi AND v.year = LEFT(bom.month, 4)
# MAGIC LEFT JOIN gold_finance_as.cost_elements_hierarchy elem ON elem.cost_element_id = v.cost_element_id
# MAGIC LEFT JOIN slvr_sap.fi_suppliers s ON s.supplier = v.supplier_id
# MAGIC LEFT JOIN prod_site p ON p.plant = bom.divi
# MAGIC GROUP BY bom.phase, v.plant, site, bom.product, bom.month, v.supplier_id, s.supplier_name, v.cost_element_id

# COMMAND ----------

# MAGIC %md
# MAGIC ## Union All

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW consolidation_tmp
# MAGIC AS
# MAGIC WITH consolidation AS (
# MAGIC   SELECT * FROM costs_in_bom_internal_tmp
# MAGIC   UNION ALL
# MAGIC   SELECT * FROM costs_in_bom_external_tmp
# MAGIC   UNION ALL
# MAGIC   SELECT * FROM costs_out_of_bom_tmp
# MAGIC   UNION ALL
# MAGIC   SELECT * FROM budgets_in_bom_tmp
# MAGIC   UNION ALL
# MAGIC   SELECT * FROM budgets_in_bom_exceptions_tmp
# MAGIC   UNION ALL
# MAGIC   SELECT * FROM budgets_out_of_bom_tmp
# MAGIC )
# MAGIC SELECT 
# MAGIC   phase, plant, site, product, month_id, part_number, supplier, supplier_name
# MAGIC   , CASE
# MAGIC       WHEN cost_element_id IS NULL OR cost_element_id = "" THEN "Unknown"
# MAGIC       WHEN LEFT(cost_element_id, 5) = "60331" THEN "60331101"
# MAGIC       ELSE cost_element_id
# MAGIC     END cost_element_id
# MAGIC   , cost_element_desc, cost_element_hierarchy_lvl1_id, cost_element_hierarchy_lvl1_desc, cost_element_hierarchy_lvl2_id, cost_element_hierarchy_lvl2_desc, cost_element_hierarchy_lvl3_id, cost_element_hierarchy_lvl3_desc, cost_element_hierarchy_lvl4_id, cost_element_hierarchy_lvl4_desc, cost_element_hierarchy_lvl5_id, cost_element_hierarchy_lvl5_desc 
# MAGIC   , skill, raw_material, manufacturing_process, size, class_std, family_std, assembly_level, special_procurement, procurement_type, bom_quantity
# MAGIC   , budget_hours_for_control, budget_value_for_control, actual_hours_for_control, actual_value_for_control
# MAGIC   , budget_quantity_for_control, actual_quantity_for_control
# MAGIC   , budget_quantity, budget_yearly, actual_month_quantity, actual_month_amount
# MAGIC FROM consolidation

# COMMAND ----------

# MAGIC %md
# MAGIC # Replace null actual values by budget values
# MAGIC Objectif : Remplacer les valeurs actual_month_quantity et actual_month_amount à null par les valeurs de budget_quantity et budget_yearly  
# MAGIC   
# MAGIC Pour chaque clé (plant, production_site, product, month_id, part_number, cost_element_id) les valeurs sont à null dans 2 cas :  
# MAGIC * les lignes actual existent mais les valeurs actual_month_quantity et actual_month_amount sont à null
# MAGIC * les lignes actual n'existent pas  
# MAGIC   
# MAGIC A l'aide des lignes budget, modifier les lignes actual à null et créer les lignes actual manquantes

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Récupération de toutes les lignes budget
# MAGIC -- Utilisée pour la modification des lignes actual à null ET la création des lignes actual manquantes
# MAGIC CREATE OR REPLACE TEMPORARY VIEW budget_consolidation_tmp
# MAGIC AS
# MAGIC SELECT * FROM consolidation_tmp
# MAGIC WHERE phase = 'budget'
# MAGIC   AND LEFT(cost_element_id, 6) != "RNREBE"  -- for these cost elements, when actual values are null, we have to keep it as null
# MAGIC ;
# MAGIC 
# MAGIC -- Récupération de toutes les lignes actual
# MAGIC -- Utilisée pour la modification des lignes actual à null ET la création des lignes actual manquantes
# MAGIC CREATE OR REPLACE TEMPORARY VIEW actual_consolidation_tmp
# MAGIC AS
# MAGIC SELECT * FROM consolidation_tmp
# MAGIC WHERE phase = 'actual'
# MAGIC   AND LEFT(cost_element_id, 6) != "RNREBE"  -- for these cost elements, when actual values are null, we have to keep it as null
# MAGIC ;

# COMMAND ----------

# MAGIC %md
# MAGIC ### Modification des lignes actual à null

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Jointure entre les lignes actual et les lignes budget en ne conservant que les lignes actual existantes
# MAGIC -- Modification des lignes actual existantes
# MAGIC CREATE OR REPLACE TEMPORARY VIEW actual_consolidation_coalesce_tmp
# MAGIC AS
# MAGIC WITH budgets AS (
# MAGIC   SELECT product, plant, site, month_id, part_number, cost_element_id
# MAGIC     , sum(round(budget_quantity, 3)) budget_quantity
# MAGIC     , sum(round(budget_yearly, 3)) budget_yearly
# MAGIC   FROM budget_consolidation_tmp
# MAGIC   GROUP BY product, plant, site, month_id, part_number, cost_element_id
# MAGIC )
# MAGIC SELECT
# MAGIC   a.phase, a.plant, a.site, a.product, a.month_id, a.part_number, a.supplier, a.supplier_name, a.cost_element_id
# MAGIC   , a.cost_element_desc, a.cost_element_hierarchy_lvl1_id, a.cost_element_hierarchy_lvl1_desc, a.cost_element_hierarchy_lvl2_id, a.cost_element_hierarchy_lvl2_desc, a.cost_element_hierarchy_lvl3_id, a.cost_element_hierarchy_lvl3_desc, a.cost_element_hierarchy_lvl4_id, a.cost_element_hierarchy_lvl4_desc, a.cost_element_hierarchy_lvl5_id, a.cost_element_hierarchy_lvl5_desc
# MAGIC   , a.skill, a.raw_material, a.manufacturing_process, a.size, a.class_std, a.family_std
# MAGIC   , a.assembly_level, a.special_procurement, a.procurement_type, a.bom_quantity
# MAGIC   , a.budget_hours_for_control, a.budget_value_for_control, a.actual_hours_for_control, a.actual_value_for_control, a.budget_quantity_for_control, a.actual_quantity_for_control
# MAGIC   , a.budget_quantity, a.budget_yearly
# MAGIC   , coalesce(a.actual_month_quantity, b.budget_quantity) actual_month_quantity            -- Modification des lignes actual existantes
# MAGIC   , coalesce(a.actual_month_amount, b.budget_yearly) actual_month_amount                  -- Modification des lignes actual existantes
# MAGIC   , CASE WHEN a.actual_month_amount IS NULL THEN True ELSE False END actual_from_budget   -- field identifying whether actual value comes from budget value or not
# MAGIC FROM actual_consolidation_tmp a
# MAGIC LEFT JOIN budgets b    -- Jointure entre les lignes actual et les lignes budget en ne conservant que les lignes actual existantes
# MAGIC ON b.plant = a.plant
# MAGIC   AND b.site = a.site
# MAGIC   AND b.product = a.product
# MAGIC   AND b.month_id = a.month_id
# MAGIC   AND b.part_number = a.part_number
# MAGIC --   AND b.supplier = a.supplier
# MAGIC   AND b.cost_element_id = a.cost_element_id
# MAGIC ;

# COMMAND ----------

# MAGIC %md
# MAGIC ### Création des lignes actual manquantes

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Jointure entre les lignes actual et les lignes budget en ne conservant que les lignes actual inexistantes
# MAGIC -- Modification des lignes actual inexistantes
# MAGIC CREATE OR REPLACE TEMPORARY VIEW actual_consolidation_creation_tmp
# MAGIC AS
# MAGIC SELECT
# MAGIC   'actual' phase, b.plant, b.site, b.product, b.month_id, b.part_number, b.supplier, b.supplier_name, b.cost_element_id
# MAGIC   , b.cost_element_desc, b.cost_element_hierarchy_lvl1_id, b.cost_element_hierarchy_lvl1_desc, b.cost_element_hierarchy_lvl2_id, b.cost_element_hierarchy_lvl2_desc, b.cost_element_hierarchy_lvl3_id, b.cost_element_hierarchy_lvl3_desc, b.cost_element_hierarchy_lvl4_id, b.cost_element_hierarchy_lvl4_desc, b.cost_element_hierarchy_lvl5_id, b.cost_element_hierarchy_lvl5_desc
# MAGIC   , b.skill, b.raw_material, b.manufacturing_process, b.size, b.class_std, b.family_std
# MAGIC   , b.assembly_level, b.special_procurement, b.procurement_type, b.bom_quantity
# MAGIC   , null budget_hours_for_control                                 -- Modification des lignes actual inexistantes
# MAGIC   , null budget_value_for_control                                 -- Modification des lignes actual inexistantes
# MAGIC   , b.budget_hours_for_control actual_hours_for_control           -- Modification des lignes actual inexistantes
# MAGIC   , b.budget_value_for_control actual_value_for_control           -- Modification des lignes actual inexistantes
# MAGIC   , null budget_quantity_for_control                              -- Modification des lignes actual inexistantes
# MAGIC   , b.budget_quantity_for_control actual_quantity_for_control     -- Modification des lignes actual inexistantes
# MAGIC   , null budget_quantity                                          -- Modification des lignes actual inexistantes
# MAGIC   , null budget_yearly                                            -- Modification des lignes actual inexistantes
# MAGIC   , b.budget_quantity actual_month_quantity                       -- Modification des lignes actual inexistantes
# MAGIC   , b.budget_yearly actual_month_amount                           -- Modification des lignes actual inexistantes
# MAGIC   , True actual_from_budget                                       -- field identifying whether actual value comes from budget value or not
# MAGIC FROM budget_consolidation_tmp b
# MAGIC LEFT JOIN actual_consolidation_tmp a    -- Jointure entre les lignes actual et les lignes budget en ne conservant que les lignes actual inexistantes
# MAGIC ON a.plant = b.plant
# MAGIC   AND a.site = b.site
# MAGIC   AND a.product = b.product
# MAGIC   AND a.month_id = b.month_id
# MAGIC   AND a.part_number = b.part_number
# MAGIC --   AND a.supplier = b.supplier
# MAGIC   AND a.cost_element_id = b.cost_element_id
# MAGIC WHERE a.plant IS NULL
# MAGIC   AND a.site IS NULL
# MAGIC   AND a.product IS NULL
# MAGIC   AND a.month_id IS NULL
# MAGIC   AND a.part_number IS NULL
# MAGIC --   AND a.supplier IS NULL
# MAGIC   AND a.cost_element_id IS NULL
# MAGIC ;

# COMMAND ----------

# MAGIC %md
# MAGIC ### Union All

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW actual_consolidation_approche1_tmp
# MAGIC AS
# MAGIC SELECT * FROM actual_consolidation_coalesce_tmp
# MAGIC UNION ALL
# MAGIC SELECT * FROM actual_consolidation_creation_tmp
# MAGIC ;
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW consolidation_completed_tmp
# MAGIC AS
# MAGIC SELECT * FROM actual_consolidation_approche1_tmp
# MAGIC UNION ALL
# MAGIC SELECT *, False actual_from_budget FROM budget_consolidation_tmp
# MAGIC UNION ALL
# MAGIC SELECT *, False actual_from_budget FROM consolidation_tmp WHERE LEFT(cost_element_id, 6) = "RNREBE"  -- cost elements with actual null values

# COMMAND ----------

# MAGIC %md
# MAGIC # Other BOM rows
# MAGIC Select also rows from trusted.bill_of_materials not matched with trusted.costs_in_bom_internal, trusted.costs_in_bom_external, trusted.costs_out_of_bom, trusted.budgets_in_bom, trusted.budgets_in_bom_exceptions, trusted.budgets_out_of_bom

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW other_bom_rows_tmp
# MAGIC AS
# MAGIC WITH prod_site AS (
# MAGIC   SELECT plant, site_reporting
# MAGIC   FROM slvr_finance_as.production_sites
# MAGIC   WHERE plant IS NOT NULL
# MAGIC     AND mrp_c IS NULL
# MAGIC )
# MAGIC , consolidation as (
# MAGIC   SELECT phase, plant, product, month_id, part_number
# MAGIC   FROM consolidation_completed_tmp
# MAGIC   GROUP BY phase, plant, product, month_id, part_number
# MAGIC )
# MAGIC SELECT
# MAGIC   bom.phase phase
# MAGIC   , bom.divi plant
# MAGIC   , CASE
# MAGIC       WHEN bom.divi = "1000" AND LEFT(bom.mrp_c, 1) = "O" THEN "LATE - Montredon"
# MAGIC       WHEN bom.divi = "1000" AND LEFT(bom.mrp_c, 1) != "O" THEN "LATE - Gimont"
# MAGIC       ELSE p.site_reporting
# MAGIC     END site
# MAGIC   , bom.product product
# MAGIC   , bom.month month_id
# MAGIC   , bom.material part_number
# MAGIC   , null supplier
# MAGIC   , null supplier_name
# MAGIC   , null cost_element_id
# MAGIC 
# MAGIC   , null cost_element_desc
# MAGIC   , null cost_element_hierarchy_lvl1_id                           -- should we keep these as separate dimensions brought into power BI? 
# MAGIC   , null cost_element_hierarchy_lvl1_desc
# MAGIC   , null cost_element_hierarchy_lvl2_id
# MAGIC   , null cost_element_hierarchy_lvl2_desc 
# MAGIC   , null cost_element_hierarchy_lvl3_id 
# MAGIC   , null cost_element_hierarchy_lvl3_desc  
# MAGIC   , null cost_element_hierarchy_lvl4_id 
# MAGIC   , null cost_element_hierarchy_lvl4_desc 
# MAGIC   , null cost_element_hierarchy_lvl5_id 
# MAGIC   , null cost_element_hierarchy_lvl5_desc 
# MAGIC 
# MAGIC   , max(bom.skill) skill
# MAGIC   , max(bom.raw_material) raw_material
# MAGIC   , max(bom.manufacturing_process) manufacturing_process
# MAGIC   , max(bom.size) size
# MAGIC   , max(bom.class_std) class_std
# MAGIC   , max(bom.family_std) family_std
# MAGIC   , max(bom.assembly_level) assembly_level
# MAGIC   , max(bom.specia) special_procurement
# MAGIC   , max(bom.procu) procurement_type
# MAGIC   , max(bom.bom_quantity) bom_quantity
# MAGIC   
# MAGIC   , null budget_hours_for_control
# MAGIC   , null budget_value_for_control
# MAGIC   , null actual_hours_for_control
# MAGIC   , null actual_value_for_control
# MAGIC   
# MAGIC   , null budget_quantity_for_control
# MAGIC   , null actual_quantity_for_control
# MAGIC   
# MAGIC   , null budget_quantity
# MAGIC   , null budget_yearly   
# MAGIC   , null actual_month_quantity
# MAGIC   , null actual_month_amount
# MAGIC 
# MAGIC FROM gold_finance_as.bill_of_material bom
# MAGIC LEFT JOIN prod_site p ON p.plant = bom.divi
# MAGIC LEFT JOIN consolidation c ON c.phase = bom.phase AND c.plant = bom.divi AND c.product = bom.product AND c.month_id = bom.month AND c.part_number = bom.material
# MAGIC WHERE c.phase IS NULL
# MAGIC GROUP BY bom.phase, bom.divi, site, bom.product, bom.month, bom.material

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW consolidation_approche1_tmp
# MAGIC AS
# MAGIC WITH costs AS (
# MAGIC   SELECT * FROM consolidation_completed_tmp
# MAGIC   UNION ALL
# MAGIC   SELECT *, False actual_from_budget FROM other_bom_rows_tmp
# MAGIC )
# MAGIC SELECT
# MAGIC   phase, plant, site, product, month_id, actual_from_budget
# MAGIC   , CASE WHEN part_number IS NULL OR part_number = "" THEN "Unknown" ELSE part_number END part_number
# MAGIC   , CASE WHEN supplier IS NULL OR supplier = "" THEN "Unknown" ELSE supplier END supplier
# MAGIC   , CASE WHEN supplier_name IS NULL OR supplier_name = "" THEN "Unknown" ELSE supplier_name END supplier_name
# MAGIC   , CASE WHEN cost_element_id IS NULL OR cost_element_id = "" THEN "Unknown" ELSE cost_element_id END cost_element_id
# MAGIC   
# MAGIC   , max(cost_element_desc) cost_element_desc
# MAGIC   , max(cost_element_hierarchy_lvl1_id) cost_element_hierarchy_lvl1_id, max(cost_element_hierarchy_lvl1_desc) cost_element_hierarchy_lvl1_desc
# MAGIC   , max(cost_element_hierarchy_lvl2_id) cost_element_hierarchy_lvl2_id, max(cost_element_hierarchy_lvl2_desc) cost_element_hierarchy_lvl2_desc
# MAGIC   , max(cost_element_hierarchy_lvl3_id) cost_element_hierarchy_lvl3_id, max(cost_element_hierarchy_lvl3_desc) cost_element_hierarchy_lvl3_desc
# MAGIC   , max(cost_element_hierarchy_lvl4_id) cost_element_hierarchy_lvl4_id, max(cost_element_hierarchy_lvl4_desc) cost_element_hierarchy_lvl4_desc
# MAGIC   , max(cost_element_hierarchy_lvl5_id) cost_element_hierarchy_lvl5_id, max(cost_element_hierarchy_lvl5_desc) cost_element_hierarchy_lvl5_desc
# MAGIC   
# MAGIC   , max(skill) skill, max(raw_material) raw_material, max(manufacturing_process) manufacturing_process, max(size) size, max(class_std) class_std, max(family_std) family_std
# MAGIC   
# MAGIC   , max(assembly_level) assembly_level, max(special_procurement) special_procurement, max(procurement_type) procurement_type, max(bom_quantity) bom_quantity
# MAGIC   
# MAGIC   , sum(budget_hours_for_control) budget_hours_for_control, sum(budget_value_for_control) budget_value_for_control
# MAGIC   , sum(actual_hours_for_control) actual_hours_for_control, sum(actual_value_for_control) actual_value_for_control
# MAGIC   , sum(budget_quantity_for_control) budget_quantity_for_control, sum(actual_quantity_for_control) actual_quantity_for_control
# MAGIC   
# MAGIC   , sum(budget_quantity) budget_quantity, sum(budget_yearly) budget_yearly
# MAGIC   , sum(actual_month_quantity) actual_month_quantity, sum(actual_month_amount) actual_month_amount
# MAGIC FROM costs c
# MAGIC GROUP BY phase, supplier, supplier_name, plant, site, product, month_id, actual_from_budget, part_number, cost_element_id
# MAGIC ;

# COMMAND ----------

# MAGIC %md
# MAGIC # YtD & Actual Quarter
# MAGIC Year to date & Actual quarter calculation

# COMMAND ----------

# MAGIC %md
# MAGIC ## YTD

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- For each phase, plant, site, product, month_id, part_number, cost_element_id, associate each YTD months with:
# MAGIC -- - the ranking number inside the YTD period (month_ytd_order) that will be used to pivot the table
# MAGIC -- - the quantity of delivered products (qty_actual_month)
# MAGIC -- - actual_month_amount
# MAGIC -- - actual_month_quantity
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW ytd_raw_costs_tmp
# MAGIC AS
# MAGIC with months_ytd as (
# MAGIC   select *
# MAGIC     , dense_rank() OVER (PARTITION BY month_id ORDER BY month_ytm_id) month_ytd_order
# MAGIC   from slvr_finance_as.months_ytm
# MAGIC )
# MAGIC select ca.phase, ca.plant, ca.site, ca.product, ca.month_id, ca.actual_from_budget, ca.part_number, ca.cost_element_id, ca2.month_id month_id_ytd, mytd.month_ytd_order
# MAGIC   , pq.actual qty_actual_month
# MAGIC   , ca2.actual_month_amount actual_month_amount
# MAGIC   , ca2.actual_month_quantity actual_month_quantity
# MAGIC from consolidation_approche1_tmp ca  
# MAGIC left join months_ytd mytd
# MAGIC on mytd.month_id = ca.month_id
# MAGIC left join consolidation_approche1_tmp ca2
# MAGIC on ca2.phase = ca.phase
# MAGIC   and ca2.plant = ca.plant
# MAGIC   and ca2.site = ca.site
# MAGIC   and ca2.product = ca.product
# MAGIC   and ca2.month_id = mytd.month_ytm_id
# MAGIC   and ca2.actual_from_budget = ca.actual_from_budget
# MAGIC   and ca2.part_number = ca.part_number
# MAGIC   and ca2.cost_element_id = ca.cost_element_id
# MAGIC left join slvr_finance_as.product_quantities pq
# MAGIC on pq.product_id = ca.product
# MAGIC   and pq.validity_date_yyyymm = ca2.month_id
# MAGIC order by month_id, mytd.month_ytd_order
# MAGIC ;
# MAGIC 
# MAGIC -- SELECT * FROM ytd_raw_costs_tmp
# MAGIC -- WHERE phase = "actual"
# MAGIC --   AND plant = 1000
# MAGIC --   AND product = "A2P"
# MAGIC --   AND part_number = "D5211547920000"
# MAGIC --   AND cost_element_id = "92AF5300"

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- pivot the table to perform YTD calculation
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW ytd_costs_pivot_tmp
# MAGIC AS
# MAGIC with pivot as (
# MAGIC   select phase, plant, site, product, month_id, actual_from_budget, part_number, cost_element_id
# MAGIC 
# MAGIC     , sum(qty_actual_month) filter(WHERE month_ytd_order = 1) qty_actual_month_m1
# MAGIC     , sum(actual_month_amount) filter(WHERE month_ytd_order = 1) actual_month_amount_m1
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_ytd_order = 1) actual_month_quantity_m1
# MAGIC 
# MAGIC     , sum(qty_actual_month) filter(WHERE month_ytd_order = 2) qty_actual_month_m2
# MAGIC     , sum(actual_month_amount) filter(WHERE month_ytd_order = 2) actual_month_amount_m2
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_ytd_order = 2) actual_month_quantity_m2
# MAGIC 
# MAGIC     , sum(qty_actual_month) filter(WHERE month_ytd_order = 3) qty_actual_month_m3
# MAGIC     , sum(actual_month_amount) filter(WHERE month_ytd_order = 3) actual_month_amount_m3
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_ytd_order = 3) actual_month_quantity_m3
# MAGIC     
# MAGIC     , sum(qty_actual_month) filter(WHERE month_ytd_order = 4) qty_actual_month_m4
# MAGIC     , sum(actual_month_amount) filter(WHERE month_ytd_order = 4) actual_month_amount_m4
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_ytd_order = 4) actual_month_quantity_m4
# MAGIC     
# MAGIC     , sum(qty_actual_month) filter(WHERE month_ytd_order = 5) qty_actual_month_m5
# MAGIC     , sum(actual_month_amount) filter(WHERE month_ytd_order = 5) actual_month_amount_m5
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_ytd_order = 5) actual_month_quantity_m5
# MAGIC     
# MAGIC     , sum(qty_actual_month) filter(WHERE month_ytd_order = 6) qty_actual_month_m6
# MAGIC     , sum(actual_month_amount) filter(WHERE month_ytd_order = 6) actual_month_amount_m6
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_ytd_order = 6) actual_month_quantity_m6
# MAGIC     
# MAGIC     , sum(qty_actual_month) filter(WHERE month_ytd_order = 7) qty_actual_month_m7
# MAGIC     , sum(actual_month_amount) filter(WHERE month_ytd_order = 7) actual_month_amount_m7
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_ytd_order = 7) actual_month_quantity_m7
# MAGIC     
# MAGIC     , sum(qty_actual_month) filter(WHERE month_ytd_order = 8) qty_actual_month_m8
# MAGIC     , sum(actual_month_amount) filter(WHERE month_ytd_order = 8) actual_month_amount_m8
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_ytd_order = 8) actual_month_quantity_m8
# MAGIC     
# MAGIC     , sum(qty_actual_month) filter(WHERE month_ytd_order = 9) qty_actual_month_m9
# MAGIC     , sum(actual_month_amount) filter(WHERE month_ytd_order = 9) actual_month_amount_m9
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_ytd_order = 9) actual_month_quantity_m9
# MAGIC     
# MAGIC     , sum(qty_actual_month) filter(WHERE month_ytd_order = 10) qty_actual_month_m10
# MAGIC     , sum(actual_month_amount) filter(WHERE month_ytd_order = 10) actual_month_amount_m10
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_ytd_order = 10) actual_month_quantity_m10
# MAGIC     
# MAGIC     , sum(qty_actual_month) filter(WHERE month_ytd_order = 11) qty_actual_month_m11
# MAGIC     , sum(actual_month_amount) filter(WHERE month_ytd_order = 11) actual_month_amount_m11
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_ytd_order = 11) actual_month_quantity_m11
# MAGIC     
# MAGIC     , sum(qty_actual_month) filter(WHERE month_ytd_order = 12) qty_actual_month_m12
# MAGIC     , sum(actual_month_amount) filter(WHERE month_ytd_order = 12) actual_month_amount_m12
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_ytd_order = 12) actual_month_quantity_m12
# MAGIC 
# MAGIC   from ytd_raw_costs_tmp
# MAGIC   group by phase, plant, site, product, month_id, actual_from_budget, part_number, cost_element_id
# MAGIC   order by month_id
# MAGIC )
# MAGIC SELECT phase, plant, site, product, month_id, actual_from_budget, part_number, cost_element_id
# MAGIC   , ifnull(qty_actual_month_m1, 0)        qty_actual_month_m1
# MAGIC   , ifnull(actual_month_amount_m1, 0)     actual_month_amount_m1
# MAGIC   , ifnull(actual_month_quantity_m1, 0)   actual_month_quantity_m1
# MAGIC   , ifnull(qty_actual_month_m2, 0)        qty_actual_month_m2
# MAGIC   , ifnull(actual_month_amount_m2, 0)     actual_month_amount_m2
# MAGIC   , ifnull(actual_month_quantity_m2, 0)   actual_month_quantity_m2
# MAGIC   , ifnull(qty_actual_month_m3, 0)        qty_actual_month_m3
# MAGIC   , ifnull(actual_month_amount_m3, 0)     actual_month_amount_m3
# MAGIC   , ifnull(actual_month_quantity_m3, 0)   actual_month_quantity_m3
# MAGIC   , ifnull(qty_actual_month_m4, 0)        qty_actual_month_m4
# MAGIC   , ifnull(actual_month_amount_m4, 0)     actual_month_amount_m4
# MAGIC   , ifnull(actual_month_quantity_m4, 0)   actual_month_quantity_m4
# MAGIC   , ifnull(qty_actual_month_m5, 0)        qty_actual_month_m5
# MAGIC   , ifnull(actual_month_amount_m5, 0)     actual_month_amount_m5
# MAGIC   , ifnull(actual_month_quantity_m5, 0)   actual_month_quantity_m5
# MAGIC   , ifnull(qty_actual_month_m6, 0)        qty_actual_month_m6
# MAGIC   , ifnull(actual_month_amount_m6, 0)     actual_month_amount_m6
# MAGIC   , ifnull(actual_month_quantity_m6, 0)   actual_month_quantity_m6
# MAGIC   , ifnull(qty_actual_month_m7, 0)        qty_actual_month_m7
# MAGIC   , ifnull(actual_month_amount_m7, 0)     actual_month_amount_m7
# MAGIC   , ifnull(actual_month_quantity_m7, 0)   actual_month_quantity_m7
# MAGIC   , ifnull(qty_actual_month_m8, 0)        qty_actual_month_m8
# MAGIC   , ifnull(actual_month_amount_m8, 0)     actual_month_amount_m8
# MAGIC   , ifnull(actual_month_quantity_m8, 0)   actual_month_quantity_m8
# MAGIC   , ifnull(qty_actual_month_m9, 0)        qty_actual_month_m9
# MAGIC   , ifnull(actual_month_amount_m9, 0)     actual_month_amount_m9
# MAGIC   , ifnull(actual_month_quantity_m9, 0)   actual_month_quantity_m9
# MAGIC   , ifnull(qty_actual_month_m10, 0)       qty_actual_month_m10
# MAGIC   , ifnull(actual_month_amount_m10, 0)    actual_month_amount_m10
# MAGIC   , ifnull(actual_month_quantity_m10, 0)  actual_month_quantity_m10
# MAGIC   , ifnull(qty_actual_month_m11, 0)       qty_actual_month_m11
# MAGIC   , ifnull(actual_month_amount_m11, 0)    actual_month_amount_m11
# MAGIC   , ifnull(actual_month_quantity_m11, 0)  actual_month_quantity_m11
# MAGIC   , ifnull(qty_actual_month_m12, 0)       qty_actual_month_m12
# MAGIC   , ifnull(actual_month_amount_m12, 0)    actual_month_amount_m12
# MAGIC   , ifnull(actual_month_quantity_m12, 0)  actual_month_quantity_m12
# MAGIC FROM pivot
# MAGIC ;
# MAGIC 
# MAGIC -- SELECT * FROM ytd_costs_pivot_tmp
# MAGIC -- WHERE phase = "actual"
# MAGIC --   AND plant = 1000
# MAGIC --   AND product = "A2P"
# MAGIC --   AND part_number = "D5211547920000"
# MAGIC --   AND cost_element_id = "92AF5300"

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- perform YTD calculation
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW ytd_costs_tmp
# MAGIC AS
# MAGIC SELECT phase, plant, site, product, month_id, actual_from_budget, part_number, cost_element_id
# MAGIC   , qty_actual_month_m1, actual_month_amount_m1, actual_month_quantity_m1
# MAGIC   , qty_actual_month_m2, actual_month_amount_m2, actual_month_quantity_m2
# MAGIC   , qty_actual_month_m3, actual_month_amount_m3, actual_month_quantity_m3
# MAGIC   , qty_actual_month_m4, actual_month_amount_m4, actual_month_quantity_m4
# MAGIC   , qty_actual_month_m5, actual_month_amount_m5, actual_month_quantity_m5
# MAGIC   , qty_actual_month_m6, actual_month_amount_m6, actual_month_quantity_m6
# MAGIC   , qty_actual_month_m7, actual_month_amount_m7, actual_month_quantity_m7
# MAGIC   , qty_actual_month_m8, actual_month_amount_m8, actual_month_quantity_m8
# MAGIC   , qty_actual_month_m9, actual_month_amount_m9, actual_month_quantity_m9
# MAGIC   , qty_actual_month_m10, actual_month_amount_m10, actual_month_quantity_m10
# MAGIC   , qty_actual_month_m11, actual_month_amount_m11, actual_month_quantity_m11
# MAGIC   , qty_actual_month_m12, actual_month_amount_m12, actual_month_quantity_m12
# MAGIC   , round(
# MAGIC       (
# MAGIC         (actual_month_amount_m1 * qty_actual_month_m1)
# MAGIC         + (actual_month_amount_m2 * qty_actual_month_m2)
# MAGIC         + (actual_month_amount_m3 * qty_actual_month_m3)
# MAGIC         + (actual_month_amount_m4 * qty_actual_month_m4)
# MAGIC         + (actual_month_amount_m5 * qty_actual_month_m5)
# MAGIC         + (actual_month_amount_m6 * qty_actual_month_m6)
# MAGIC         + (actual_month_amount_m7 * qty_actual_month_m7)
# MAGIC         + (actual_month_amount_m8 * qty_actual_month_m8)
# MAGIC         + (actual_month_amount_m9 * qty_actual_month_m9)
# MAGIC         + (actual_month_amount_m10 * qty_actual_month_m10)
# MAGIC         + (actual_month_amount_m11 * qty_actual_month_m11)
# MAGIC         + (actual_month_amount_m12 * qty_actual_month_m12)
# MAGIC       )
# MAGIC       / (qty_actual_month_m1 + qty_actual_month_m2 + qty_actual_month_m3 + qty_actual_month_m4 + qty_actual_month_m5 + qty_actual_month_m6
# MAGIC          + qty_actual_month_m7 + qty_actual_month_m8 + qty_actual_month_m9 + qty_actual_month_m10 + qty_actual_month_m11 + qty_actual_month_m12)
# MAGIC       , 3) ytd_amount
# MAGIC   , round(
# MAGIC       (
# MAGIC         (actual_month_quantity_m1 * qty_actual_month_m1)
# MAGIC         + (actual_month_quantity_m2 * qty_actual_month_m2)
# MAGIC         + (actual_month_quantity_m3 * qty_actual_month_m3)
# MAGIC         + (actual_month_quantity_m4 * qty_actual_month_m4)
# MAGIC         + (actual_month_quantity_m5 * qty_actual_month_m5)
# MAGIC         + (actual_month_quantity_m6 * qty_actual_month_m6)
# MAGIC         + (actual_month_quantity_m7 * qty_actual_month_m7)
# MAGIC         + (actual_month_quantity_m8 * qty_actual_month_m8)
# MAGIC         + (actual_month_quantity_m9 * qty_actual_month_m9)
# MAGIC         + (actual_month_quantity_m10 * qty_actual_month_m10)
# MAGIC         + (actual_month_quantity_m11 * qty_actual_month_m11)
# MAGIC         + (actual_month_quantity_m12 * qty_actual_month_m12)
# MAGIC       )
# MAGIC       / (qty_actual_month_m1 + qty_actual_month_m2 + qty_actual_month_m3 + qty_actual_month_m4 + qty_actual_month_m5 + qty_actual_month_m6
# MAGIC          + qty_actual_month_m7 + qty_actual_month_m8 + qty_actual_month_m9 + qty_actual_month_m10 + qty_actual_month_m11 + qty_actual_month_m12)
# MAGIC       , 3) ytd_quantity 
# MAGIC FROM ytd_costs_pivot_tmp
# MAGIC ;
# MAGIC 
# MAGIC -- SELECT * FROM ytd_costs_tmp
# MAGIC -- WHERE phase = "actual"
# MAGIC --   AND plant = 1000
# MAGIC --   AND product = "A2P"
# MAGIC --   AND part_number = "D5211547920000"
# MAGIC --   AND cost_element_id = "92AF5300"

# COMMAND ----------

# MAGIC %md
# MAGIC ## LCQ

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- For each phase, plant, site, product, month_id, part_number, cost_element_id, associate each 3 LCQ months with:
# MAGIC -- - the ranking number inside the quarter (month_lcq_order) that will be used to pivot the table
# MAGIC -- - the quantity of delivered products (qty_actual_month)
# MAGIC -- - actual_month_amount
# MAGIC -- - actual_month_quantity
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW lcq_raw_costs_tmp
# MAGIC AS
# MAGIC with months_lcq as (
# MAGIC   select *
# MAGIC     , dense_rank() OVER (PARTITION BY month_id ORDER BY month_lcq_id) month_lcq_order
# MAGIC   from slvr_finance_as.months_lcq
# MAGIC )
# MAGIC select ca.phase, ca.plant, ca.site, ca.product, ca.month_id, ca.actual_from_budget, ca.part_number, ca.cost_element_id, ca2.month_id month_id_lcq, mlcq.month_lcq_order
# MAGIC   , pq.actual qty_actual_month
# MAGIC   , ca2.actual_month_amount actual_month_amount
# MAGIC   , ca2.actual_month_quantity actual_month_quantity
# MAGIC from consolidation_approche1_tmp ca  
# MAGIC left join months_lcq mlcq
# MAGIC on mlcq.month_id = ca.month_id
# MAGIC left join consolidation_approche1_tmp ca2
# MAGIC on ca2.phase = ca.phase
# MAGIC   and ca2.plant = ca.plant
# MAGIC   and ca2.site = ca.site
# MAGIC   and ca2.product = ca.product
# MAGIC   and ca2.month_id = mlcq.month_lcq_id
# MAGIC   and ca2.actual_from_budget = ca.actual_from_budget
# MAGIC   and ca2.part_number = ca.part_number
# MAGIC   and ca2.cost_element_id = ca.cost_element_id
# MAGIC left join slvr_finance_as.product_quantities pq
# MAGIC on pq.product_id = ca.product
# MAGIC   and pq.validity_date_yyyymm = ca2.month_id
# MAGIC order by month_id, mlcq.month_lcq_order
# MAGIC ;
# MAGIC 
# MAGIC -- SELECT * FROM lcq_raw_costs_tmp
# MAGIC -- WHERE phase = "actual"
# MAGIC --   AND plant = 1000
# MAGIC --   AND product = "A2P"
# MAGIC --   AND part_number = "D5211547920000"
# MAGIC --   AND cost_element_id = "92AF5300"

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- pivot the table to perform LCQ calculation
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW lcq_costs_pivot_tmp
# MAGIC AS
# MAGIC with pivot as (
# MAGIC   select phase, plant, site, product, month_id, actual_from_budget, part_number, cost_element_id
# MAGIC 
# MAGIC     , sum(qty_actual_month) filter(WHERE month_lcq_order = 1) qty_actual_month_q1
# MAGIC     , sum(actual_month_amount) filter(WHERE month_lcq_order = 1) actual_month_amount_q1
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_lcq_order = 1) actual_month_quantity_q1
# MAGIC 
# MAGIC     , sum(qty_actual_month) filter(WHERE month_lcq_order = 2) qty_actual_month_q2
# MAGIC     , sum(actual_month_amount) filter(WHERE month_lcq_order = 2) actual_month_amount_q2
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_lcq_order = 2) actual_month_quantity_q2
# MAGIC 
# MAGIC     , sum(qty_actual_month) filter(WHERE month_lcq_order = 3) qty_actual_month_q3
# MAGIC     , sum(actual_month_amount) filter(WHERE month_lcq_order = 3) actual_month_amount_q3
# MAGIC     , sum(actual_month_quantity) filter(WHERE month_lcq_order = 3) actual_month_quantity_q3
# MAGIC 
# MAGIC   from lcq_raw_costs_tmp
# MAGIC   group by phase, plant, site, product, month_id, actual_from_budget, part_number, cost_element_id
# MAGIC   order by month_id
# MAGIC )
# MAGIC SELECT phase, plant, site, product, month_id, actual_from_budget, part_number, cost_element_id
# MAGIC   , ifnull(qty_actual_month_q1, 0)        qty_actual_month_q1
# MAGIC   , ifnull(actual_month_amount_q1, 0)     actual_month_amount_q1
# MAGIC   , ifnull(actual_month_quantity_q1, 0)   actual_month_quantity_q1
# MAGIC   , ifnull(qty_actual_month_q2, 0)        qty_actual_month_q2
# MAGIC   , ifnull(actual_month_amount_q2, 0)     actual_month_amount_q2
# MAGIC   , ifnull(actual_month_quantity_q2, 0)   actual_month_quantity_q2
# MAGIC   , ifnull(qty_actual_month_q3, 0)        qty_actual_month_q3
# MAGIC   , ifnull(actual_month_amount_q3, 0)     actual_month_amount_q3
# MAGIC   , ifnull(actual_month_quantity_q3, 0)   actual_month_quantity_q3
# MAGIC FROM pivot
# MAGIC ;
# MAGIC 
# MAGIC -- SELECT * FROM lcq_costs_pivot_tmp
# MAGIC -- WHERE phase = "actual"
# MAGIC --   AND plant = 1000
# MAGIC --   AND product = "A2P"
# MAGIC --   AND part_number = "D5211547920000"
# MAGIC --   AND cost_element_id = "92AF5300"

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- perform LCQ calculation
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW lcq_costs_tmp
# MAGIC AS
# MAGIC SELECT phase, plant, site, product, month_id, actual_from_budget, part_number, cost_element_id
# MAGIC   , qty_actual_month_q1
# MAGIC   , actual_month_amount_q1
# MAGIC   , actual_month_quantity_q1
# MAGIC   , qty_actual_month_q2
# MAGIC   , actual_month_amount_q2
# MAGIC   , actual_month_quantity_q2
# MAGIC   , qty_actual_month_q3
# MAGIC   , actual_month_amount_q3
# MAGIC   , actual_month_quantity_q3
# MAGIC   
# MAGIC   , round(
# MAGIC       (
# MAGIC         (actual_month_amount_q1 * qty_actual_month_q1)
# MAGIC         + (actual_month_amount_q2 * qty_actual_month_q2)
# MAGIC         + (actual_month_amount_q3 * qty_actual_month_q3)
# MAGIC       )
# MAGIC       / (qty_actual_month_q1 + qty_actual_month_q2 + qty_actual_month_q3)
# MAGIC       , 3) lcq_amount
# MAGIC   , round(
# MAGIC       (
# MAGIC         (actual_month_quantity_q1 * qty_actual_month_q1)
# MAGIC         + (actual_month_quantity_q2 * qty_actual_month_q2)
# MAGIC         + (actual_month_quantity_q3 * qty_actual_month_q3)
# MAGIC       )
# MAGIC       / (qty_actual_month_q1 + qty_actual_month_q2 + qty_actual_month_q3)
# MAGIC       , 3) lcq_quantity
# MAGIC   
# MAGIC FROM lcq_costs_pivot_tmp
# MAGIC ;
# MAGIC 
# MAGIC -- SELECT * FROM lcq_costs_tmp
# MAGIC -- WHERE phase = "actual"
# MAGIC --   AND plant = 1000
# MAGIC --   AND product = "A2P"
# MAGIC --   AND part_number = "D5211547920000"
# MAGIC --   AND cost_element_id = "92AF5300"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join to final dataset

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW costs_analysis_tmp
# MAGIC AS
# MAGIC with costs as
# MAGIC (
# MAGIC select ca.phase, ca.supplier, ca.supplier_name, ca.plant, ca.site, ca.product, ca.month_id reporting_month, ca.actual_from_budget, ca.part_number, ca.cost_element_id
# MAGIC   , cost_element_desc, cost_element_hierarchy_lvl1_id, cost_element_hierarchy_lvl1_desc, cost_element_hierarchy_lvl2_id, cost_element_hierarchy_lvl2_desc, cost_element_hierarchy_lvl3_id, cost_element_hierarchy_lvl3_desc, cost_element_hierarchy_lvl4_id, cost_element_hierarchy_lvl4_desc, cost_element_hierarchy_lvl5_id, cost_element_hierarchy_lvl5_desc 
# MAGIC   , skill, raw_material, manufacturing_process, size, class_std, family_std, assembly_level, special_procurement, procurement_type, bom_quantity
# MAGIC   , budget_hours_for_control, budget_value_for_control, actual_hours_for_control, actual_value_for_control, budget_quantity_for_control, actual_quantity_for_control
# MAGIC   
# MAGIC   , budget_quantity
# MAGIC   , budget_yearly   
# MAGIC   , actual_month_quantity
# MAGIC   , actual_month_amount
# MAGIC   
# MAGIC   , CASE WHEN ytdc.ytd_quantity = 0 THEN null ELSE ytdc.ytd_quantity END actual_ytd_quantity
# MAGIC   , CASE WHEN ytdc.ytd_amount = 0 THEN null ELSE ytdc.ytd_amount END actual_ytd_amount
# MAGIC   
# MAGIC   , CASE WHEN lcqc.lcq_quantity = 0 THEN null ELSE lcqc.lcq_quantity END actual_quarter_quantity
# MAGIC   , CASE WHEN lcqc.lcq_amount = 0 THEN null ELSE lcqc.lcq_amount END actual_quarter_amount
# MAGIC -- from consolidation_tmp
# MAGIC from consolidation_approche1_tmp ca
# MAGIC left join ytd_costs_tmp ytdc
# MAGIC on ytdc.phase = ca.phase
# MAGIC   and ytdc.plant = ca.plant
# MAGIC   and ytdc.site = ca.site
# MAGIC   and ytdc.product = ca.product
# MAGIC   and ytdc.month_id = ca.month_id
# MAGIC   and ytdc.actual_from_budget = ca.actual_from_budget
# MAGIC   and ytdc.part_number = ca.part_number
# MAGIC   and ytdc.cost_element_id = ca.cost_element_id
# MAGIC left join lcq_costs_tmp lcqc
# MAGIC on lcqc.phase = ca.phase
# MAGIC   and lcqc.plant = ca.plant
# MAGIC   and lcqc.site = ca.site
# MAGIC   and lcqc.product = ca.product
# MAGIC   and lcqc.month_id = ca.month_id
# MAGIC   and lcqc.actual_from_budget = ca.actual_from_budget
# MAGIC   and lcqc.part_number = ca.part_number
# MAGIC   and lcqc.cost_element_id = ca.cost_element_id
# MAGIC ) 
# MAGIC select phase, supplier, supplier_name, plant, site, product, reporting_month, actual_from_budget, part_number, cost_element_id
# MAGIC     , max(cost_element_desc) cost_element_desc, max(cost_element_hierarchy_lvl1_id) cost_element_hierarchy_lvl1_id, max(cost_element_hierarchy_lvl1_desc) cost_element_hierarchy_lvl1_desc, max(cost_element_hierarchy_lvl2_id) cost_element_hierarchy_lvl2_id, max(cost_element_hierarchy_lvl2_desc) cost_element_hierarchy_lvl2_desc, max(cost_element_hierarchy_lvl3_id) cost_element_hierarchy_lvl3_id, max(cost_element_hierarchy_lvl3_desc) cost_element_hierarchy_lvl3_desc, max(cost_element_hierarchy_lvl4_id) cost_element_hierarchy_lvl4_id, max(cost_element_hierarchy_lvl4_desc) cost_element_hierarchy_lvl4_desc, max(cost_element_hierarchy_lvl5_id) cost_element_hierarchy_lvl5_id, max(cost_element_hierarchy_lvl5_desc) cost_element_hierarchy_lvl5_desc
# MAGIC     , max(skill) skill, max(raw_material) raw_material, max(manufacturing_process) manufacturing_process, max(size) size, max(class_std) class_std, max(family_std) family_std, max(assembly_level) assembly_level, max(special_procurement) special_procurement, max(procurement_type) procurement_type, max(bom_quantity) bom_quantity
# MAGIC     , sum(budget_hours_for_control) budget_hours_for_control, sum(budget_value_for_control) budget_value_for_control, sum(actual_hours_for_control) actual_hours_for_control, sum(actual_value_for_control) actual_value_for_control, sum(budget_quantity_for_control) budget_quantity_for_control, sum(actual_quantity_for_control) actual_quantity_for_control
# MAGIC     
# MAGIC     , sum(round(budget_quantity, 3)) budget_quantity
# MAGIC     , sum(round(budget_yearly, 3)) budget_yearly
# MAGIC     , sum(round(actual_month_quantity, 3)) actual_month_quantity
# MAGIC     , sum(round(actual_month_amount, 3)) actual_month_amount
# MAGIC     
# MAGIC     , sum(round(actual_ytd_quantity, 3)) actual_ytd_quantity
# MAGIC     , sum(round(actual_ytd_amount, 3)) actual_ytd_amount
# MAGIC     
# MAGIC     , sum(round(actual_quarter_quantity, 3)) actual_quarter_quantity 
# MAGIC     , sum(round(actual_quarter_amount, 3)) actual_quarter_amount
# MAGIC from costs
# MAGIC group by phase, supplier, supplier_name, plant, site, product, reporting_month, actual_from_budget, part_number, cost_element_id

# COMMAND ----------

# MAGIC %md
# MAGIC # Write cost analysis dataset

# COMMAND ----------

table_zone = "pltm_prodcosts"
table_name = "costs_analysis"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC # Missing cost elements from cost_elements_hierarchy  
# MAGIC Identifies all ingested cost_element_id that are not in gold_finance_as.cost_elements_hierarchy, allowing users to add these cost_element_id to the CSKU SETLEAF SETHEADERT SAP tables, in order to extract these SAP tables and update gold_finance_as.cost_elements_hierarchy  
# MAGIC Overwrites the entire output table  

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW missing_cost_elements_tmp
# MAGIC AS
# MAGIC WITH cost_elements AS (
# MAGIC   SELECT DISTINCT cost_element_id, "budgets_in_bom" from_table FROM gold_finance_as.budgets_in_bom
# MAGIC   UNION
# MAGIC   SELECT DISTINCT cost_element_id, "budgets_in_bom_exceptions" from_table FROM gold_finance_as.budgets_in_bom_exceptions
# MAGIC   UNION
# MAGIC   SELECT DISTINCT cost_element_id, "budgets_out_of_bom" from_table FROM gold_finance_as.budgets_out_of_bom
# MAGIC   UNION
# MAGIC   SELECT DISTINCT cost_element_id, "costs_in_bom_external" from_table FROM gold_finance_as.costs_in_bom_external
# MAGIC   UNION
# MAGIC   SELECT DISTINCT cost_element_id, "costs_in_bom_internal" from_table FROM gold_finance_as.costs_in_bom_internal
# MAGIC   UNION
# MAGIC   SELECT DISTINCT cost_element_id, "costs_out_of_bom" from_table FROM gold_finance_as.costs_out_of_bom
# MAGIC )
# MAGIC SELECT ce.*
# MAGIC FROM cost_elements ce
# MAGIC LEFT JOIN gold_finance_as.cost_elements_hierarchy ceh ON ceh.cost_element_id = ce.cost_element_id
# MAGIC WHERE ceh.cost_element_id IS NULL;
# MAGIC 
# MAGIC -- select * from missing_cost_elements_tmp

# COMMAND ----------

table_zone = "pltm_prodcosts"
table_name = "missing_cost_elements"
table_location = f"s3://leap-s3-weeu1-{env}/leap/{table_zone}/{table_name}.delta"

# Create the delta table
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {table_zone}")
spark.sql("CREATE OR REPLACE TABLE " + f"{table_zone}.{table_name}" + " USING DELTA LOCATION " + f"'{table_location}'" + f" AS SELECT * FROM {table_name}_tmp")

# COMMAND ----------

# MAGIC %md
# MAGIC # Tests

# COMMAND ----------

# %sql

# -- Lignes actual matchant avec les lignes budget
# CREATE OR REPLACE TEMPORARY VIEW actual_with_budget_consolidation_tmp
# AS
# SELECT a.*
# FROM actual_consolidation_tmp a
# INNER JOIN budget_consolidation_tmp b
# ON b.plant = a.plant
#   AND b.site = a.site
#   AND b.product = a.product
#   AND b.month_id = a.month_id
#   AND b.part_number = a.part_number
# --   AND b.supplier = a.supplier
#   AND b.cost_element_id = a.cost_element_id
# ;

# -- Lignes actual ne matchant avec aucune ligne budget
# CREATE OR REPLACE TEMPORARY VIEW actual_without_budget_consolidation_tmp
# AS
# SELECT a.*
# FROM actual_consolidation_tmp a
# LEFT JOIN budget_consolidation_tmp b
# ON b.plant = a.plant
#   AND b.site = a.site
#   AND b.product = a.product
#   AND b.month_id = a.month_id
#   AND b.part_number = a.part_number
# --   AND b.supplier = a.supplier
#   AND b.cost_element_id = a.cost_element_id
# WHERE b.plant IS NULL
#   AND b.site IS NULL
#   AND b.product IS NULL
#   AND b.month_id IS NULL
#   AND b.part_number IS NULL
# --   AND b.supplier IS NULL
#   AND b.cost_element_id IS NULL
# ;

# -- Lignes budget ne matchant avec aucune ligne actual
# CREATE OR REPLACE TEMPORARY VIEW budget_without_actual_consolidation_tmp
# AS
# SELECT b.*
# FROM budget_consolidation_tmp b
# LEFT JOIN actual_consolidation_tmp a
# ON a.plant = b.plant
#   AND a.site = b.site
#   AND a.product = b.product
#   AND a.month_id = b.month_id
#   AND a.part_number = b.part_number
# --   AND a.supplier = b.supplier
#   AND a.cost_element_id = b.cost_element_id
# WHERE a.plant IS NULL
#   AND a.site IS NULL
#   AND a.product IS NULL
#   AND a.month_id IS NULL
#   AND a.part_number IS NULL
# --   AND a.supplier IS NULL
#   AND a.cost_element_id IS NULL
# ;

# SELECT
#   (select count(*) from consolidation_tmp)                           consolidation_tmp
#   , (select count(*) from actual_consolidation_tmp)                  actual_consolidation_tmp
#   , (select count(*) from budget_consolidation_tmp)                  budget_consolidation_tmp
#   , (select count(*) from actual_without_budget_consolidation_tmp)   actual_without_budget_consolidation_tmp
#   , (select count(*) from budget_without_actual_consolidation_tmp)   budget_without_actual_consolidation_tmp
#   , (select count(*) from actual_with_budget_consolidation_tmp)      actual_with_budget_consolidation_tmp

# COMMAND ----------

# MAGIC %md
# MAGIC data quality

# COMMAND ----------

# %sql

# -- other_bom_rows_tmp / trusted.bill_of_materials
# -- Ratio de lignes des BOM pour lesquelles on n'a aucune valeur

# WITH counts as (
#   SELECT
#     ROUND((SELECT COUNT(*) FROM other_bom_rows_tmp), 4) other_bom_rows_count
#     , ROUND((SELECT COUNT(*) FROM gold_finance.bill_of_material), 4) bill_of_material_count
# )
# SELECT
#   "pltm_prodcosts" domain
#   , current_date() sli_date
#   , ROUND(1 - (other_bom_rows_count / bill_of_material_count), 4) sli_value
#   , other_bom_rows_count || " over " || bill_of_material_count || " rows from gold_finance.bill_of_material don't match with any cost nor budget." sli_details
#   , current_timestamp() sli_timestamp
# FROM counts

# COMMAND ----------

# %sql
# -- select count(*)
# -- from pltm_prodcosts.costs_analysis

# COMMAND ----------

# %sql
# SELECT *
# from pltm_prodcosts.costs_analysis
# WHERE product = "DNT"
#   and reporting_month = 202207
#   and part_number = "F7XC544120301A3"
  
  
# -- Procu = F
# -- special procu = 30
# -- product = DNT
# -- reporting_month = 202207
# -- part_number = F7XC544120301A3

# COMMAND ----------

# %sql
# SELECT *
# from pltm_prodcosts.costs_analysis
# WHERE product = "DNT"
#   and reporting_month = 202207
#   and part_number = "F7XC544120301A3"

# -- Procu = F
# -- special procu = 30
# -- product = DNT
# -- reporting_month = 202207
# -- part_number = F7XC544120301A3
