# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # [WIP ASSY - Work In Progress on WBS elements]
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim of this notebook is to create a data asset for WIP on Assembly parts
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - N/A   
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Build for Use Case 2 - Inventory  
# MAGIC
# MAGIC **Input Tables Pipeline**  
# MAGIC - {REFERENCE_READ_ENV}_gold.finance.currency_exchange  
# MAGIC - {REFERENCE_READ_ENV}_bronze.manual_input.plant_description_V2  
# MAGIC - {REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region  
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed  
# MAGIC - {REFERENCE_READ_ENV}_bronze.manual_input.uc2_profit_center_affectation 
# MAGIC - {PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_wipassy_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cosp_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cosp_stack  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.prps_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.prps_stack  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.covp_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.covp_stack
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.aufk_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.aufk_stack  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afpo_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afpo_stack 
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.jcds_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.jcds_stack
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - N/A  
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.inventory_valued.wip_assy_latest  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.inventory_valued.wip_assy_weekly_history  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.inventory_valued.wip_assy_monthly_history  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import DataFrame, functions as f, Window
from databricks.sdk.runtime import dbutils
from typing import Tuple
from datetime import datetime

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports  
# MAGIC   
# MAGIC - **add_prefix_to_columns** required for creation header Business  
# MAGIC - **create_corrected_amounts** required for currency correction (due to SAP mistake on specific currency)
# MAGIC - **convert_currency** required for currency conversion  
# MAGIC - **Save_Table** required for saving Table on DBX
# MAGIC - **add_monthly_evol_dates** required for creation of Monthly historisation key  
# MAGIC - **add_weekly_evol_dates** required for creation of Weekly historisation key  

# COMMAND ----------

from leap_utils.data_asset.table_utils import add_prefix_to_columns, convert_currency
from leap_utils.data_asset.amount_correction import create_corrected_amounts
from leap_utils.data_asset.table_utils import get_latest_version_for_each_id_column
from leap_utils.data_asset.table_utils import transform_float_column, save_table

from leap_utils.data_asset.historisation import (
    add_monthly_evol_dates,
    add_weekly_evol_dates,
    partition_monthly,
    partition_weekly,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).
# MAGIC - PERIOD -> Used for specifying period (weekly or monthly) on the notebook run 

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("period", "weekly")
PERIOD = dbutils.widgets.get("period").lower()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Min Date to consider parameter

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Currency Exchange from LEAP
# MAGIC
# MAGIC **df_Currency_Exchange** : Gold Table From LEAP - Currency Exchange

# COMMAND ----------

df_Currency_Exchange = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.currency_exchange"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Plant Master Data from LEAP
# MAGIC
# MAGIC **df_Plant_Master** : Gold Table From LEAP - Plant Master Data

# COMMAND ----------

df_Plant_Master = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.plant_description_V2"
).select(f.col("Plant_Div").alias("Plant"), f.col("Plant_Description_new"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Material Master Data from LEAP
# MAGIC
# MAGIC **df_Material_Master** : Gold Table From LEAP - Material Master Data by Plant

# COMMAND ----------

if PERIOD == "weekly":
    df_Material_Master = spark.read.table(
        f"{REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed"
    )
if PERIOD == "monthly":
    table_master = f"{REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant"
    today = datetime.today()
    if today.month == 1:
        prev_month = 12
    else:
        prev_month = today.month - 1

    WRITING_OPERATIONS = (
        "WRITE",
        "REPLACE TABLE AS SELECT",
        "COPY INTO",
        "MERGE",
        "CREATE OR REPLACE TABLE AS SELECT",
    )
    # We take the last version of previous month
    # To be sure we are not including Standard price modification
    # (Performed each 1st of the month)
    version = spark.sql(
        f"select version from (describe history {table_master}) where month(timestamp) == {prev_month} and operation IN {WRITING_OPERATIONS} limit 1 "
    ).collect()[0][0]

    df_Material_Master = spark.read.table(f"{table_master}@v{version}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Work in Progress ASSY from AVCORP 
# MAGIC
# MAGIC **df_wipassy_avcorp** : Gold Table From LEAP - WIP ASSY AVCORP

# COMMAND ----------

if PERIOD == "weekly":
    df_wipassy_avcorp = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_wipassy_latest"
    )
if PERIOD == "monthly":
    df_wipassy_avcorp = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_wipassy_monthly"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Profit Center affectation 
# MAGIC
# MAGIC **df_UC2ProfitCenterAffectation** : Manual Bronze Table From LEAP - Profit Center affectation

# COMMAND ----------

df_UC2ProfitCenterAffectation = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.uc2_profit_center_affectation"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Bronze Manual Mapping division site  
# MAGIC **df_bronze_site** Mapping site-division-region  

# COMMAND ----------

df_bronze_site = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region"
)
#----------------------------------------------------------------------------------
df_bronze_site = df_bronze_site.withColumnRenamed("site", "production_site").withColumn(
    "production_site", f.translate("production_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
).distinct()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - COSP from SAP
# MAGIC
# MAGIC df_cosp : Bronze Table From SAP - Cost Totals for External Postings  
# MAGIC For **Weekly** run, we take Latest Version  
# MAGIC For **Monthly** we take last version of previous month  
# MAGIC Table in Delta Mode, we need to create Full Stack for monthly

# COMMAND ----------

if PERIOD == "weekly":
    df_cosp = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cosp_latest"
    )
if PERIOD == "monthly":
    df_cosp = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cosp_stack"
    )
    df_cosp1 = df_cosp.filter(f.col("file_name").contains("~4-01"))
    df_cosp1 = df_cosp1.withColumn(
        "Date_Ref", f.to_timestamp(f.trunc(f.current_timestamp(), "month"))
    )
    df_cosp1 = df_cosp1.withColumn(
        "Gap_Date", f.abs(f.col("extraction_timestamp") - f.col("Date_Ref"))
    )

    closest_date = df_cosp1.orderBy("Gap_Date").select("extraction_timestamp").head()[0]
    df_cosp1 = df_cosp1.filter(f.col("extraction_timestamp") <= closest_date).drop(
        "Date_Ref", "Gap_Date"
    )

    # get the lastest existing_timestamp where mode == FULL mode in the stack table
    max_date_full = (
        df_cosp1.filter(df_cosp1.file_mode == "FULL")
        .select(f.max("extraction_timestamp"))
        .first()["max(extraction_timestamp)"]
    )
    if max_date_full:
        df_from_last_full_to_current_date = df_cosp1.filter(
            (df_cosp1.extraction_timestamp >= max_date_full)
        )
    else:
        df_from_last_full_to_current_date = df_cosp1

    # For each ID in Dataframe keep the latest extraction_timestamp
    df_cosp1 = get_latest_version_for_each_id_column(
        df_from_last_full_to_current_date, "ID", "extraction_timestamp"
    )

    df_cosp4 = df_cosp.filter(f.col("file_name").contains("~4-04"))
    df_cosp4 = df_cosp4.withColumn(
        "Date_Ref", f.to_timestamp(f.trunc(f.current_timestamp(), "month"))
    )
    df_cosp4 = df_cosp4.withColumn(
        "Gap_Date", f.abs(f.col("extraction_timestamp") - f.col("Date_Ref"))
    )

    closest_date = df_cosp4.orderBy("Gap_Date").select("extraction_timestamp").head()[0]
    df_cosp4 = df_cosp4.filter(f.col("extraction_timestamp") <= closest_date).drop(
        "Date_Ref", "Gap_Date"
    )
    # get the lastest existing_timestamp where mode == FULL mode in the stack table
    max_date_full = (
        df_cosp4.filter(df_cosp4.file_mode == "FULL")
        .select(f.max("extraction_timestamp"))
        .first()["max(extraction_timestamp)"]
    )
    if max_date_full:
        df_from_last_full_to_current_date = df_cosp4.filter(
            (df_cosp4.extraction_timestamp >= max_date_full)
        )
    else:
        df_from_last_full_to_current_date = df_cosp4

    # For each ID in Dataframe keep the latest extraction_timestamp
    df_cosp4 = get_latest_version_for_each_id_column(
        df_from_last_full_to_current_date, "ID", "extraction_timestamp"
    )
    df_cosp = df_cosp1.unionByName(df_cosp4)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - PRPS from SAP
# MAGIC
# MAGIC **df_prps** : Bronze Table From SAP - WBS (Work Breakdown Structure) Element Master Data  
# MAGIC For **Weekly** run, we take Latest Version  
# MAGIC For **Monthly** we take last version of previous month  
# MAGIC Table managed on FULL mode, we keep only last stack

# COMMAND ----------

if PERIOD == "weekly":
    df_prps = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.prps_latest"
    )
if PERIOD == "monthly":
    df_prps = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.prps_stack"
    )
    df_prps = df_prps.withColumn(
        "Date_Ref", f.to_timestamp(f.trunc(f.current_timestamp(), "month"))
    )
    df_prps = df_prps.withColumn(
        "Gap_Date", f.abs(f.col("extraction_timestamp") - f.col("Date_Ref"))
    )
    closest_date = df_prps.orderBy("Gap_Date").select("extraction_timestamp").head()[0]
    df_prps = df_prps.filter(f.col("extraction_timestamp") == closest_date).drop(
        "Date_Ref", "Gap_Date"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - COVP from SAP
# MAGIC
# MAGIC **df_covp** : Bronze Table From SAP -  Overhead Cost Controlling General  
# MAGIC For **Weekly** run, we take Latest Version  
# MAGIC For **Monthly** we take last version of previous month  
# MAGIC Table in Delta Mode, we need to create Full Stack for monthly

# COMMAND ----------

if PERIOD == "weekly":
    df_covp = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.covp_latest"
    )
if PERIOD == "monthly":
    df_covp = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.covp_stack"
    )
    df_covp = df_covp.withColumn(
        "Date_Ref", f.to_timestamp(f.trunc(f.current_timestamp(), "month"))
    )
    df_covp = df_covp.withColumn(
        "Gap_Date", f.abs(f.col("extraction_timestamp") - f.col("Date_Ref"))
    )

    closest_date = df_covp.orderBy("Gap_Date").select("extraction_timestamp").head()[0]
    df_covp = df_covp.filter(f.col("extraction_timestamp") <= closest_date).drop(
        "Date_Ref", "Gap_Date"
    )

    # get the lastest existing_timestamp where mode == FULL mode in the stack table
    max_date_full = (
        df_covp.filter(df_covp.file_mode == "FULL")
        .select(f.max("extraction_timestamp"))
        .first()["max(extraction_timestamp)"]
    )
    if max_date_full:
        df_from_last_full_to_current_date = df_covp.filter(
            (df_covp.extraction_timestamp >= max_date_full)
        )
    else:
        df_from_last_full_to_current_date = df_covp

    # For each ID in Dataframe keep the latest extraction_timestamp
    df_covp = get_latest_version_for_each_id_column(
        df_from_last_full_to_current_date, "ID", "extraction_timestamp"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - AUFK from SAP
# MAGIC
# MAGIC **df_aufk** : Bronze Table From SAP -  Work Order master data  
# MAGIC For **Weekly** run, we take Latest Version  
# MAGIC For **Monthly** we take last version of previous month  
# MAGIC Table managed on FULL mode, we keep only last stack

# COMMAND ----------

if PERIOD == "weekly":
    df_aufk = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.aufk_latest"
    )
if PERIOD == "monthly":
    df_aufk = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.aufk_stack"
    )
    df_aufk = df_aufk.withColumn(
        "Date_Ref", f.to_timestamp(f.trunc(f.current_timestamp(), "month"))
    )
    df_aufk = df_aufk.withColumn(
        "Gap_Date", f.abs(f.col("extraction_timestamp") - f.col("Date_Ref"))
    )
    closest_date = df_aufk.orderBy("Gap_Date").select("extraction_timestamp").head()[0]
    df_aufk = df_aufk.filter(f.col("extraction_timestamp") == closest_date).drop(
        "Date_Ref", "Gap_Date"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - AFPO from SAP
# MAGIC
# MAGIC **df_afpo** : Bronze Table From SAP -  Work Order item  
# MAGIC For **Weekly** run, we take Latest Version  
# MAGIC For **Monthly** we take last version of previous month  
# MAGIC Table managed on FULL mode, we keep only last stack

# COMMAND ----------

if PERIOD == "weekly":
    df_afpo = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afpo_latest"
    )
if PERIOD == "monthly":
    df_afpo = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afpo_stack"
    )
    df_afpo = df_afpo.withColumn(
        "Date_Ref", f.to_timestamp(f.trunc(f.current_timestamp(), "month"))
    )
    df_afpo = df_afpo.withColumn(
        "Gap_Date", f.abs(f.col("extraction_timestamp") - f.col("Date_Ref"))
    )
    closest_date = df_afpo.orderBy("Gap_Date").select("extraction_timestamp").head()[0]
    df_afpo = df_afpo.filter(f.col("extraction_timestamp") == closest_date).drop(
        "Date_Ref", "Gap_Date"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - JCDS from SAP
# MAGIC
# MAGIC **df_jcds** : Bronze Table From SAP -  Change Documents for System/User Statuses  
# MAGIC For **Weekly** run, we take Latest Version  
# MAGIC For **Monthly** we take last version of previous month  
# MAGIC Table in Delta Mode, we need to create Full Stack for monthly

# COMMAND ----------

if PERIOD == "weekly":
    df_jcds = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.jcds_latest"
    )
if PERIOD == "monthly":
    df_jcds = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.jcds_stack"
    )
    # Exclusion JCDS extraction for QM
    df_jcds = df_jcds.filter(~f.col("ID").contains("QM"))
    df_jcds = df_jcds.withColumn(
        "Date_Ref", f.to_timestamp(f.trunc(f.current_timestamp(), "month"))
    )
    df_jcds = df_jcds.withColumn(
        "Gap_Date", f.abs(f.col("extraction_timestamp") - f.col("Date_Ref"))
    )

    closest_date = df_jcds.orderBy("Gap_Date").select("extraction_timestamp").head()[0]
    df_jcds = df_jcds.filter(f.col("extraction_timestamp") <= closest_date).drop(
        "Date_Ref", "Gap_Date"
    )
    # get the lastest existing_timestamp where mode == FULL mode in the stack table
    max_date_full = (
        df_jcds.filter(df_jcds.file_mode == "FULL")
        .select(f.max("extraction_timestamp"))
        .first()["max(extraction_timestamp)"]
    )
    if max_date_full:
        df_from_last_full_to_current_date = df_jcds.filter(
            (df_jcds.extraction_timestamp >= max_date_full)
        )
    else:
        df_from_last_full_to_current_date = df_jcds

    # For each ID in Dataframe keep the latest extraction_timestamp
    df_jcds = get_latest_version_for_each_id_column(
        df_from_last_full_to_current_date, "ID", "extraction_timestamp"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - External Avcorp

# COMMAND ----------

df_wipassy_avcorp = (
    df_wipassy_avcorp.withColumn("Division", f.lit("ASAM"))
    .withColumn("Region", f.lit("AMERICAS"))
    .withColumn(("Production_Site"), f.lit("LAC1 - Delta"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation Material Master Data by Plant

# COMMAND ----------

if df_Material_Master is None:
    raise ValueError(f"Material_Master is None!")
# Selection Columns
df_material_master_end = df_Material_Master.select(
    [
        f.col("Branch"),
        f.col("Description"),
        f.col("Material_Type"),
        f.col("Supplier_Code"),
        f.col("Supplier_Name"),
        f.col("MRP_Controller"),
        f.col("Plant"),
        f.col("Material_Number"),
    ]
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation COSP - Cost Totals for External Postings

# COMMAND ----------

# Selection & Renaming Columns
df_cosp_selected = df_cosp.select(
    [
        f.col("objnr").alias("COSP_OBJNR"),
        f.col("twaer").alias("COSP_TWAER"),
        f.col("versn").alias("COSP_VERSN"),
        f.col("kstar").alias("COSP_KSTAR"),
        f.col("wrttp").alias("COSP_WRTTP"),
        f.col("wtg001").alias("COSP_WTG001"),
        f.col("wtg002").alias("COSP_WTG002"),
        f.col("wtg003").alias("COSP_WTG003"),
        f.col("wtg004").alias("COSP_WTG004"),
        f.col("wtg005").alias("COSP_WTG005"),
        f.col("wtg006").alias("COSP_WTG006"),
        f.col("wtg007").alias("COSP_WTG007"),
        f.col("wtg008").alias("COSP_WTG008"),
        f.col("wtg009").alias("COSP_WTG009"),
        f.col("wtg010").alias("COSP_WTG010"),
        f.col("wtg011").alias("COSP_WTG011"),
        f.col("wtg012").alias("COSP_WTG012"),
    ]
)
# -----------------------------------------------------------------------
# Casting Columns & Management Negative value
columns_to_cast = [
    "COSP_WTG001",
    "COSP_WTG002",
    "COSP_WTG003",
    "COSP_WTG004",
    "COSP_WTG005",
    "COSP_WTG006",
    "COSP_WTG007",
    "COSP_WTG008",
    "COSP_WTG009",
    "COSP_WTG010",
    "COSP_WTG011",
    "COSP_WTG012",
]
for column in columns_to_cast:
    df_cosp_selected = df_cosp_selected.withColumn(
        column,
        f.when(
            f.col(column).endswith("-"),
            -f.regexp_replace(f.col(column), "-", "").cast("double"),
        ).otherwise(f.col(column).cast("double")),
    )
# -----------------------------------------------------------------------
# Filter COSP on active Version, on specific account for WIP ASSY calcul
df_cosp_clean = df_cosp_selected.filter(
    (f.col("COSP_VERSN") == "000")
    & (f.col("COSP_KSTAR").startswith("0070"))
    & (f.col("COSP_WRTTP") == "01")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation AFPO - Work Order item

# COMMAND ----------

# Selection & Renaming Columns
df_afpo_end = df_afpo.select(
    [
        f.col("aufnr").alias("AFPO_AUFNR"),
        f.col("matnr").alias("AFPO_MATNR"),
        f.col("projn"),
    ]
)
df_afpo_end.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation AUFK - Work Order master data

# COMMAND ----------

# Selection & Renaming Columns for specific join on PRPS
df_aufk_end = df_aufk.select(
    [
        f.col("aufnr").alias("AUFK_AUFNR"),
        f.col("pspel").alias("AUFK_PSPEL"),
        f.col("objnr").alias("AUFK_OBJNR"),
        f.col("werks").alias("AUFK_WERKS"),
        f.col("idat2").alias("AUFK_IDAT2"),
        f.col("loekz").alias("AUFK_LOEKZ"),
    ]
)
df_aufk_end = df_aufk_end.fillna("", ["AUFK_LOEKZ"])
# -----------------------------------------------------------------------
# Selection & Renaming Columns for cost determination
df_aufk_for_costs = df_aufk.select(
    [
        f.col("aufnr").alias("AUFK_AUFNR"),
        f.col("objnr").alias("AUFK_OBJNR"),
        f.col("werks").alias("AUFK_WERKS"),
        f.col("idat2").alias("AUFK_IDAT2"),
        f.col("loekz").alias("AUFK_LOEKZ"),
        f.col("prctr").alias("AUFK_PRCTR"),
    ]
)
df_aufk_for_costs = df_aufk_for_costs.fillna("", ["AUFK_LOEKZ"])
# -----------------------------------------------------------------------
# Patch for IS - Sometimes WBS is not managed on header AUFK
# We need to take this information from AFPO - item
df_aufk_afpo = df_aufk_end.join(
    df_afpo_end, df_aufk_end.AUFK_AUFNR == df_afpo_end.AFPO_AUFNR, "left"
)
df_aufk_end = df_aufk_afpo.withColumn(
    "AUFK_PSPEL",
    f.when(f.col("AUFK_PSPEL") == "00000000", f.col("projn")).otherwise(
        f.col("AUFK_PSPEL")
    ),
).drop("projn", "AFPO_MATNR", "AFPO_AUFNR", "AUFK_AUFNR")
df_aufk_end.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation PRPS - WBS (Work Breakdown Structure) Element Master Data

# COMMAND ----------

# If weekly, input dataframe should be latest table, if monthly History table
# This method keeps only latest information from given table and adapts
# it for building wip assy

# Management of WBS internal SAP Key
df_prps_wbs = df_prps.withColumn("posid", f.trim(f.col("posid"))).withColumn(
    "posid",
    f.when(
        f.length("posid") == 12,
        f.concat(
            f.substring("posid", 1, 2),
            f.lit("-"),
            f.substring("posid", 3, 8),
            f.lit("-"),
            f.substring("posid", 11, 2),
        ),
    ).otherwise(
        f.concat(
            f.substring("posid", 1, 2),
            f.lit("-"),
            f.substring("posid", 3, 8),
            f.lit("-"),
            f.substring("posid", 11, 2),
            f.lit("-"),
            f.substring("posid", 13, 2),
        )
    ),
)
# ---------------------------------------------------------------------
# Selection & Renaming Columns for standard Process
df_prps_clean = df_prps_wbs.select(
    [
        f.col("pspnr").alias("PRPS_PSPNR"),
        f.col("objnr").alias("PRPS_OBJNR"),
        f.col("tadat").alias("PRPS_TADAT"),
        f.col("posid").alias("PRPS_POSID"),
        f.col("werks").alias("PRPS_WERKS"),
        f.col("prctr").alias("PRPS_PRCTR"),
        f.col("loevm").alias("PRPS_LOEVM"),
    ]
)
# ---------------------------------------------------------------------
# Create a DataFrame for Checking WBS Invoiced for IS Branch
List_Branch_IS = [
    "LFR1",
    "LDE1",
    "LCA1",
    "LFR2",
    "LIN1",
    "LIN2",
    "LMA1",
    "LMXI",
    "LTN1",
]
df_prps_invoiced_selected = df_prps_wbs.select(
    [
        f.col("objnr").alias("PRPS_OBJNR"),
        f.col("posid").alias("PRPS_POSID"),
        f.col("loevm").alias("PRPS_LOEVM"),
        f.col("pbukr").alias("PRPS_PBUKR"),
        f.col("psphi").alias("PRPS_PSPHI"),
    ]
)
df_prps_wbs = df_prps_invoiced_selected.filter(
    (f.col("PRPS_LOEVM").isNull()) & (f.col("PRPS_PBUKR").isin(List_Branch_IS))
)
df_prps_clean = df_prps_clean.fillna("", ["PRPS_LOEVM"])
df_prps_clean.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation COVP - Overhead Cost Controlling General

# COMMAND ----------

# Management Negative sign from SAP + Cast Double
df_covp_cast = df_covp.withColumn(
    "wogbtr",
    f.when(
        f.col("wogbtr").endswith("-"),
        -f.regexp_replace(f.col("wogbtr"), "-", "").cast("double"),
    ).otherwise(f.col("wogbtr").cast("double")),
)
# Call Function for Correction Ammount
df_covp_end = (
    create_corrected_amounts(
        df=df_covp_cast,
        amount_col="wogbtr",
        currency_col="owaer",
    )
    .drop("wogbtr")
    .withColumnRenamed("wogbtr_corrected", "wogbtr")
)
# --------------------------------------------------------------------
# Selection & Renaming Columns for direct costs
df_covp_for_direct_costs = df_covp_end.select(
    [
        f.col("wogbtr").alias("COVP_WOGBTR"),
        f.col("owaer").alias("COVP_OWAER"),
        f.col("versn").alias("COVP_VERSN"),
        f.col("beknz").alias("COVP_BEKNZ"),
        f.col("objnr").alias("COVP_OBJNR"),
    ]
)
# --------------------------------------------------------------------
# Selection & Renaming Columns for indirect costs
df_covp_for_indirect_costs = df_covp_end.select(
    [
        f.col("wogbtr").alias("COVP_WOGBTR"),
        f.col("owaer").alias("COVP_OWAER"),
        f.col("versn").alias("COVP_VERSN"),
        f.col("beknz").alias("COVP_BEKNZ"),
        f.col("matnr").alias("COVP_MATNR"),
        f.col("kstar").alias("COVP_KSTAR"),
        f.col("parob").alias("COVP_PAROB"),
        f.col("objnr").alias("COVP_OBJNR"),
    ]
)
df_covp_for_indirect_costs = df_covp_for_indirect_costs.fillna("", "COVP_PAROB")

# --------------------------------------------------------------------
# Selection & Renaming Columns for Revenue on WBS
df_covp_for_revenue = df_covp_end.select(
    [
        f.col("wogbtr").alias("COVP_WOGBTR"),
        f.col("versn").alias("COVP_VERSN"),
        f.col("kstar").alias("COVP_KSTAR"),
        f.col("objnr").alias("COVP_OBJNR"),
        f.col("vbund").alias("COVP_VBUND"),
    ]
)
# Keep only rows for revenu on WBS
df_covp_for_revenue = df_covp_for_revenue.filter(
    (f.col("COVP_KSTAR").startswith("0070"))
    & (f.col("COVP_OBJNR").startswith("PR"))
    & (f.col("COVP_VERSN") == ("000"))
    & ((f.col("COVP_VBUND").isNull()) | (f.col("COVP_VBUND") == ("X000")))
)
df_covp_for_revenue = df_covp_for_revenue.groupBy(f.col("COVP_OBJNR")).agg(
    f.sum(f.col("COVP_WOGBTR")).alias("Revenue")
)
df_covp_for_revenue = df_covp_for_revenue.filter(f.col("Revenue").isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation JCDS - Change Documents for System/User Statuses

# COMMAND ----------

# Filter JCDS table to get all product references useful for wip assy

df_jcds_date = df_jcds.withColumn(
    "full_date", f.concat(f.col("udate"), f.col("utime"))
).withColumn(
    "full_date_formatted",
    f.to_timestamp(f.col("full_date"), "yyyyMMddHHmmss"),
)
# -------------------------------------------------------------------------
# Selection & Renaming Columns for direct costs
# Filter only on WBS ELement (start with PR)
df_jcds_filtered = (
    df_jcds_date.filter(f.col("objnr").startswith("PR"))
    .select(
        [
            f.col("full_date_formatted"),
            f.col("objnr").alias("JCDS_OBJNR"),
            f.col("stat").alias("JCDS_STAT"),
            f.col("inact").alias("JCDS_INACT"),
        ]
    )
    .cache()
)
# -------------------------------------------------------------------
# Determination of Max date by statut
df_flag_OBJNR_max_date = (
    df_jcds_filtered.groupBy(["JCDS_OBJNR", "JCDS_STAT"])
    .agg(f.max("full_date_formatted").alias("full_date_formatted"))
    .withColumn("is_max_date_OBJNR", f.lit(1))
)
df_JCDS_date_filtered_and_date_flagged = (
    df_jcds_filtered.join(
        df_flag_OBJNR_max_date,
        on=["JCDS_OBJNR", "full_date_formatted", "JCDS_STAT"],
        how="left",
    )
    .filter(f.col("is_max_date_OBJNR") == 1)
    .distinct()
    .cache()
)
# -------------------------------------------------------------------
# Check statut Invoiced on JCDS is true and active (I0097)
df_OBJNR_from_JCDS_equal_to_I0097 = (
    df_JCDS_date_filtered_and_date_flagged.filter(f.col("JCDS_STAT") == "I0097")
    .select("JCDS_OBJNR")
    .distinct()
    .withColumn("is_I0097_found", f.lit(1))
)
# Check statut Invoiced on JCDS is true and inactive (I0097)
df_OBJNR_from_JCDS_equal_to_I0097_and_inact = (
    df_JCDS_date_filtered_and_date_flagged.filter(
        (f.col("JCDS_STAT") == "I0097") & (f.col("JCDS_INACT") == "X")
    )
    .select("JCDS_OBJNR")
    .distinct()
    .withColumn("is_I0097_found_and_inact", f.lit(1))
)
# Join JCDS with active and non active Invoiced statut
df_JCDS_date_filtered_and_date_objnr_flagged = (
    df_JCDS_date_filtered_and_date_flagged.select(
        ["full_date_formatted", "JCDS_OBJNR", "JCDS_STAT", "JCDS_INACT"]
    )
    .join(
        df_OBJNR_from_JCDS_equal_to_I0097.select(["JCDS_OBJNR", "is_I0097_found"]),
        on=["JCDS_OBJNR"],
        how="left",
    )
    .join(
        df_OBJNR_from_JCDS_equal_to_I0097_and_inact.select(
            ["JCDS_OBJNR", "is_I0097_found_and_inact"]
        ),
        on=["JCDS_OBJNR"],
        how="left",
    )
    .cache()
)
# -------------------------------------------------------------------------------------------
# We keep Only WBS with Statut Invoiced(I00097) inactive or not found
df_OBJNR_with_I0097_and_inact = df_JCDS_date_filtered_and_date_objnr_flagged.filter(
    f.col("is_I0097_found_and_inact") == 1
).select("JCDS_OBJNR")

df_OBJNR_with_no_I0097 = df_JCDS_date_filtered_and_date_objnr_flagged.filter(
    f.col("is_I0097_found").isNull()
).select("JCDS_OBJNR")

df_jcds_end = df_OBJNR_with_I0097_and_inact.unionByName(
    df_OBJNR_with_no_I0097
).distinct()
# -------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 1 - Management of WBS in Progress

# COMMAND ----------

# We need to Clean WBS IS side with Dataframe df_prps_wbs
# If we found one Revenue on WBS Project, we consider that the WBS is closed
df_join_prps_revenu = df_prps_wbs.join(
    df_covp_for_revenue,
    df_prps_wbs.PRPS_OBJNR == df_covp_for_revenue.COVP_OBJNR,
    "left",
)
df_prps_wbs = df_prps_wbs.withColumn(
    "PRPS_POSID_short",
    f.concat(
        f.substring(f.col("PRPS_POSID"), 4, 8), f.substring(f.col("PRPS_POSID"), 16, 2)
    ),
)

df_join_prps_revenu = df_join_prps_revenu.withColumn(
    "PRPS_POSID_temp",
    f.concat(
        f.substring(f.col("PRPS_POSID"), 4, 8), f.substring(f.col("PRPS_POSID"), 16, 2)
    ),
)

df_revenu_end = df_join_prps_revenu.groupBy(f.col("PRPS_POSID_temp")).agg(
    f.sum("Revenue").alias("Revenue")
)
df_last_revenue = df_prps_wbs.join(
    df_revenu_end, df_prps_wbs.PRPS_POSID_short == df_revenu_end.PRPS_POSID_temp, "left"
)
df_last_revenue = df_last_revenue.withColumn(
    "Test_Wbs", f.regexp_extract(f.col("PRPS_POSID"), "(.{7})([a-zA-Z])(.*)", 2) != ""
)


df_WBS_to_exclude = df_last_revenue.filter(f.col("Revenue").isNotNull()).drop(
    "PRPS_LOEVM", "PRPS_PBUKR", "PRPS_POSID_temp", "PRPS_POSID_short", "PRPS_PSPHI"
)
df_jcds_clean = df_jcds_end.join(
    df_WBS_to_exclude, df_jcds_end.JCDS_OBJNR == df_WBS_to_exclude.PRPS_OBJNR, "left"
)
df_jcds_clean = df_jcds_clean.filter(f.col("Revenue").isNull()).drop(
    "PRPS_OBJNR", "Revenue", "PRPS_POSID", "Test_Wbs"
)
df_jcds_clean.count()

# COMMAND ----------

# Filter PRPS table to get all product references useful for wip assy
# Join Work Order with WBS Element and keep only entries with WBS
df_AUFK_PRPS = df_aufk_end.join(
    df_prps_clean, df_aufk_end.AUFK_PSPEL == df_prps_clean.PRPS_PSPNR, how="inner"
)
# Join Work Order With Statut // Exclusion WorkOrder Invoiced
df_AUFK_PRPS_JCDS_temp = df_AUFK_PRPS.join(
    df_jcds_clean.select("JCDS_OBJNR"),
    df_AUFK_PRPS.PRPS_OBJNR == df_jcds_clean.JCDS_OBJNR,
    how="inner",
)
df_AUFK_PRPS_JCDS_temp.count()

# COMMAND ----------

# --------------------------------------------------------------
# Filter on result - keep only
# Work order not closed(IDAT2) and not cancelled (LOEKZ)
# And WBS not Closed (TADAT) and not cancelled (LOEVM)

# AS Management by NetWork ("NP")
df_AUFK_PRPS_JCDS_filtered_AS = df_AUFK_PRPS_JCDS_temp.filter(
    (f.col("AUFK_OBJNR").startswith("NP"))
    & (f.col("AUFK_IDAT2") == "00000000")
    & (f.col("AUFK_LOEKZ") != "X")
    & (f.col("PRPS_TADAT") == "00000000")
    & (f.col("PRPS_LOEVM") != "X")
    & (~f.col("PRPS_WERKS").startswith("2"))
)
# IS Management Without NetWork ("NP")
df_AUFK_PRPS_JCDS_filtered_IS = df_AUFK_PRPS_JCDS_temp.filter(
    (f.col("AUFK_OBJNR").startswith("OR"))
    & (f.col("AUFK_IDAT2") == "00000000")
    & (f.col("AUFK_LOEKZ") != "X")
    & (f.col("PRPS_TADAT") == "00000000")
    & (f.col("PRPS_LOEVM") != "X")
    & (f.col("PRPS_WERKS").startswith("2"))
)
# Union AS & IS
df_AUFK_PRPS_JCDS_filtered = df_AUFK_PRPS_JCDS_filtered_AS.unionByName(
    df_AUFK_PRPS_JCDS_filtered_IS
)
# --------------------------------------------------------------

df_PRPS_temp = (
    df_AUFK_PRPS_JCDS_filtered.select(
        [
            "PRPS_PSPNR",
            "PRPS_POSID",
            "PRPS_OBJNR",
            "PRPS_WERKS",
            "PRPS_PRCTR",
            "AUFK_WERKS",
        ]
    )
    .join(
        df_Plant_Master.select("Plant").distinct(),
        df_Plant_Master.Plant == df_AUFK_PRPS_JCDS_filtered.AUFK_WERKS,
        how="inner",
    )
    .drop("AUFK_WERKS")
)

df_PRPS_filtered = df_PRPS_temp.distinct()
# df_AUFK_PRPS_JCDS_filtered_AS.count() (Implies a Spark action)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 2 - Creation DataFrame for Direct Costs

# COMMAND ----------

#  Calculate wip assy direct costs
# Keep only entries where WBS is still in progress
df_PRPS_temp_AFPO = df_PRPS_filtered.select(
    ["PRPS_PSPNR", "PRPS_POSID", "PRPS_PRCTR", "PRPS_OBJNR"]
).join(df_afpo_end, df_PRPS_filtered.PRPS_PSPNR == df_afpo_end.projn, how="inner")

# Add information from Work Order headers
df_PRPS_temp_AFPO_AUFK = df_PRPS_temp_AFPO.join(
    df_aufk_for_costs,
    df_PRPS_temp_AFPO.AFPO_AUFNR == df_aufk_for_costs.AUFK_AUFNR,
    how="left",
)

# Keep only entries where value is found in COVP
df_PRPS_temp_AFPO_AUFK_COVP = df_PRPS_temp_AFPO_AUFK.join(
    df_covp_for_direct_costs,
    df_PRPS_temp_AFPO_AUFK.AUFK_OBJNR == df_covp_for_direct_costs.COVP_OBJNR,
    how="inner",
)
# Filter Active version with Object Work order (OR%)
df_PRPS_temp_AFPO_AUFK_COVP_filtered = df_PRPS_temp_AFPO_AUFK_COVP.filter(
    (f.col("COVP_VERSN") == "000")
    & (f.col("COVP_BEKNZ").isin("S", "H"))
    & (f.col("AUFK_OBJNR").startswith("OR"))
)

# Keep one dataframe with detail on Work order number
df_direct_costs_detail = df_PRPS_temp_AFPO_AUFK_COVP_filtered.join(
    df_Plant_Master.select("Plant"),
    f.col("AUFK_WERKS") == f.col("Plant"),
    how="inner",
)

# Keep one dataframe with agg on WBS element
df_direct_costs = df_direct_costs_detail.groupBy(
    [
        "PRPS_PSPNR",
        "PRPS_POSID",
        "AUFK_WERKS",
        "AUFK_AUFNR",
        "PRPS_PRCTR",
        "AFPO_MATNR",
        "COVP_OWAER",
    ]
).agg(f.sum("COVP_WOGBTR").alias("COVP_WOGBTR"))
# -------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 3 - Creation DataFrame for Indirect Costs

# COMMAND ----------

# Calculate wip assy indirect costs
# Filter on active version and no link with Work Order
df_covp_for_indirect_costs_tmp = df_covp_for_indirect_costs.filter(
    (f.col("COVP_VERSN") == "000")
    & (f.col("COVP_BEKNZ").isin("S", "H"))
    & (f.col("COVP_PAROB") != "OR")
    & (~f.col("COVP_KSTAR").startswith("0070"))
)
# -------------------------------------------------------------------------
# Keep only entries where WBS is active
indirect_costs = df_PRPS_filtered.join(
    df_covp_for_indirect_costs_tmp,
    df_PRPS_filtered.PRPS_OBJNR == df_covp_for_indirect_costs_tmp.COVP_OBJNR,
    how="inner",
)
# -------------------------------------------------------------------------
# Keep one dataframe with agg on WBS element
df_indirect_costs = indirect_costs.groupBy(
    [
        "PRPS_PSPNR",
        "PRPS_POSID",
        "PRPS_WERKS",
        "PRPS_PRCTR",
        "COVP_OWAER",
        "COVP_MATNR",
        "COVP_KSTAR",
    ]
).agg(f.sum("COVP_WOGBTR").alias("COVP_WOGBTR"))
# -------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 4 - Join Dataframe Direct and Indirect Costs

# COMMAND ----------

# Calculate wip assy direct and indirect costs

df_direct_costs = (
    df_direct_costs.withColumnsRenamed({"AUFK_WERKS": "WERKS", "PRPS_PRCTR": "PRCTR"})
    .withColumn("COVP_MATNR", f.lit(None).cast("string"))
    .withColumn("COVP_KSTAR", f.lit(""))
)

df_indirect_costs = (
    df_indirect_costs.withColumnsRenamed({"PRPS_WERKS": "WERKS", "PRPS_PRCTR": "PRCTR"})
    .withColumn("AUFK_AUFNR", f.lit(None).cast("string"))
    .withColumn("AFPO_MATNR", f.lit(None).cast("string"))
)
# Join direct and indirect costs
df_joined_costs = df_direct_costs.unionByName(df_indirect_costs).withColumn(
    "Current_Date", f.date_add(f.current_date(), -2)
)
# ---------------------------------------------------------------------------
# Conversion Ammount in EUR currency
df_converted_costs = convert_currency(
    df_base=df_joined_costs,
    df_currency=df_Currency_Exchange,
    df_base_source_currency_column_name="COVP_OWAER",
    target_currency_value="EUR",
    df_currency_conversion_rate_type_exp_value="Budget",
    df_base_conversion_date_column_name="Current_Date",
    conversion_output_column_name="Rate",
)
# ---------------------------------------------------------------------------
# Management of Plant Allocation
df_site_param_for_wip_assy = (
    df_Plant_Master.select(["Plant", "Plant_Description_new"])
    .filter(f.col("Plant") != 1000)
    .withColumnRenamed("Plant", "WERKS")
)
df_gimont_programs = df_UC2ProfitCenterAffectation.select(
    ["Site", "Profit_Center"]
).withColumnRenamed("Profit_Center", "PRCTR")

df_costs_allocated = df_converted_costs.join(
    df_site_param_for_wip_assy,
    on=["WERKS"],
    how="left",
).join(
    df_gimont_programs,
    on=["PRCTR"],
    how="left",
)
# .withColumn("AUFK_AUFNR", df_converted_costs.AUFK_AUFNR.cast("int"))
df_costs_allocated = df_costs_allocated.withColumn(
    "site",
    f.coalesce(
        df_costs_allocated.Plant_Description_new,
        df_costs_allocated.Site,
        f.lit("LATE - Gabardie"),
    ),
)
# ---------------------------------------------------------------------------
# Add calculated wip assy column
# Specific Rules for AS Side on BEP Program & LDB  DrawBack System
df_costs_all = df_costs_allocated.withColumn(
    "wip_assy",
    f.when(
        (f.col("WERKS") == "1000") & (f.col("PRCTR") == "BEP"),
        f.lit(0),
    )
    .when(
        (f.col("WERKS") == "1000")
        & (f.col("PRCTR") == "E71")
        & (f.col("COVP_KSTAR") == "0060580000"),
        f.lit(0),
    )
    .when(
        (f.col("WERKS") == "1000")
        & (f.col("PRCTR") == "E73")
        & (f.col("COVP_KSTAR") == "0060580000"),
        f.lit(0),
    )
    .otherwise(f.col("COVP_WOGBTR") * f.col("Rate")),
)
# ---------------------------------------------------------------------------
# Keep only entries greater than 0 and with currency determinated
df_direct_and_indirect_costs = df_costs_all.select(
    [
        "PRPS_POSID",
        "WERKS",
        "site",
        "PRCTR",
        "wip_assy",
        "COVP_MATNR",
        "AUFK_AUFNR",
        "AFPO_MATNR",
    ]
).filter((f.col("wip_assy") != 0) & (f.col("COVP_OWAER").isNotNull()))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 5 - Calcul of actual Sales Revenue

# COMMAND ----------

# Calculate actual Sales Revenue
# We need to calculate actual revenue in order to calculate P&L
# by WBS (ie -> All costs upper revenue will push in P&L)

# We keep only entries where WBS is active
df_PRPS_temp_COSP = (
    df_PRPS_filtered.select(["PRPS_OBJNR", "PRPS_PSPNR", "PRPS_POSID"])
    .join(
        df_cosp_clean,
        f.col("PRPS_OBJNR") == f.col("COSP_OBJNR"),
        how="inner",
    )
    .dropDuplicates()
)
# ----------------------------------------------------------------------------
# Calcul of global amount of revenue
df_PRPS_COSP_calc = df_PRPS_temp_COSP.withColumn(
    "WTGEND",
    f.col("COSP_WTG001")
    + f.col("COSP_WTG002")
    + f.col("COSP_WTG003")
    + f.col("COSP_WTG004")
    + f.col("COSP_WTG005")
    + f.col("COSP_WTG006")
    + f.col("COSP_WTG007")
    + f.col("COSP_WTG008")
    + f.col("COSP_WTG009")
    + f.col("COSP_WTG010")
    + f.col("COSP_WTG011")
    + f.col("COSP_WTG012"),
)

df_PRPS_temp_COSP_treatment = (
    df_PRPS_COSP_calc.groupBy(
        [
            "PRPS_OBJNR",
            "PRPS_PSPNR",
            "PRPS_POSID",
            "COSP_TWAER",
            "COSP_VERSN",
            "COSP_KSTAR",
            "COSP_WRTTP",
        ]
    )
    .agg(f.sum(f.col("WTGEND")).alias("WTGEND"))
    .withColumn("Current_Date", f.date_add(f.current_date(), -1))
)
# ----------------------------------------------------------------------------
# Conversion of amount in EUR Currency on actual Spot rate
df_temporary_CA = convert_currency(
    df_base=df_PRPS_temp_COSP_treatment,
    df_currency=df_Currency_Exchange,
    df_base_source_currency_column_name="COSP_TWAER",
    target_currency_value="EUR",
    df_currency_conversion_rate_type_exp_value="Budget",
    df_base_conversion_date_column_name="Current_Date",
    conversion_output_column_name="Rate",
)
df_temporary_CA = df_temporary_CA.withColumn(
    "sales_value",
    f.col("WTGEND") * f.col("Rate"),
)
# ----------------------------------------------------------------------------
df_CA_end = (
    df_temporary_CA.groupBy(["PRPS_OBJNR", "PRPS_PSPNR", "PRPS_POSID"])
    .agg(f.sum("sales_value").alias("sales_value"))
    .distinct()
)
df_CA_end = df_CA_end.select(["sales_value", "PRPS_POSID"]).dropDuplicates()
# ---------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 6 - Calcul WIP Assy basics

# COMMAND ----------

# Calcul of WIP ASSY by Plant, Site, Profit Center, WBS
df_aggregated_wip_assy = (
    df_direct_and_indirect_costs.groupby(["PRPS_POSID", "site", "WERKS", "PRCTR"])
    .agg(f.sum("wip_assy").alias("wip_assy"))
    .dropDuplicates()
)
# ----------------------------------------------------------------------------
# Add Revenu on WIP ASSY
df_aggregated_wip_assy_with_ca = df_aggregated_wip_assy.join(
    df_CA_end,
    on=["PRPS_POSID"],
    how="left",
)
# ----------------------------------------------------------------------------
# Calcul P&L for each WBS element
wip_assy_base_tmp = df_aggregated_wip_assy_with_ca.withColumn(
    "p_n_lost",
    f.when(f.col("WERKS") == "1010", f.lit(0))
    .when(
        (f.col("WERKS") != "1010") & (f.col("sales_value") > 0),
        f.col("wip_assy") * (-1),
    )
    .when(
        (f.col("WERKS") != "1010")
        & (f.col("sales_value") <= 0)
        & (f.col("sales_value") + f.col("wip_assy") > 0),
        (f.col("sales_value") + f.col("wip_assy")) * (-1),
    )
    .when(
        (f.col("WERKS") != "1010")
        & (f.col("sales_value") <= 0)
        & (f.col("sales_value") + f.col("wip_assy") <= 0),
        f.lit(0),
    )
    .otherwise(0),
)
# ----------------------------------------------------------------------------
# Calcul Final Wip Assy P&L Included
wip_assy_base_end = (
    wip_assy_base_tmp.withColumnsRenamed(
        {"WERKS": "plant", "PRPS_POSID": "wbs", "PRCTR": "program"}
    )
    .fillna(0, ["wip_assy", "p_n_lost", "sales_value"])
    .withColumn("total_wip_assy", f.col("wip_assy") + f.col("p_n_lost"))
)
# ----------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 7 - Calcul WIP Assy details

# COMMAND ----------

# Calculate wip assy detail
# Select & Rename Wip assy details costs
df_wip_assy_with_selected = (
    df_direct_and_indirect_costs.select(
        [
            "PRPS_POSID",
            "site",
            "WERKS",
            "PRCTR",
            "wip_assy",
            "AUFK_AUFNR",
            "COVP_MATNR",
            "AFPO_MATNR",
        ]
    )
    .withColumnsRenamed({"PRPS_POSID": "wbs", "WERKS": "plant", "PRCTR": "program"})
    .fillna("", "COVP_MATNR")
)
# ----------------------------------------------------------------------------
# Add material master data information
# All Work Order starting by "5" are Rush Order
df_wip_assy_with_material = df_wip_assy_with_selected.withColumn(
    "material",
    f.when(f.col("AUFK_AUFNR").like("5%"), "R.U")
    .when(
        (f.col("AUFK_AUFNR").isNotNull()),
        f.col("AFPO_MATNR"),
    )
    .when(
        (f.col("AUFK_AUFNR").isNull()) & (f.col("COVP_MATNR").isNull()),
        "WBS",
    )
    .otherwise(f.col("COVP_MATNR")),
)
# ----------------------------------------------------------------------------
# Add order number information if existing
df_wip_assy_with_order = df_wip_assy_with_material.withColumn(
    "order",
    f.when(
        f.col("AUFK_AUFNR").isNotNull(),
        f.col("AUFK_AUFNR"),
    )
    .when(
        (f.col("AUFK_AUFNR").isNull()) & (f.col("COVP_MATNR").isNull()),
        "WBS",
    )
    .otherwise("ART"),
).drop("AUFK_AUFNR", "COVP_MATNR", "AFPO_MATNR")
# ----------------------------------------------------------------------------
# Add P&L on WIP assy Details
df_pnl_tmp = (
    wip_assy_base_end.filter(f.col("p_n_lost") != 0)
    .select(["wbs", "site", "plant", "program", "p_n_lost"])
    .withColumn("material", f.lit("P&L Lost"))
    .withColumn("order", f.lit("P&L Lost"))
    .withColumnRenamed("p_n_lost", "wip_assy")
)
# ----------------------------------------------------------------------------
# Final dataframe for Wip Assy Details
df_wip_assy_detail_tmp = (
    df_wip_assy_with_order.unionByName(df_pnl_tmp)
    .withColumn(
        "program",
        f.regexp_replace(f.col("program"), "^0+", ""),
    )
    .withColumn(
        "material",
        f.regexp_replace(f.col("material"), "^0+", ""),
    )
).withColumnsRenamed(
    {
        "site": "Production_Site",
        "plant": "Plant",
        "material": "Material_Number",
        "program": "Profit_Center",
        "order": "Work_Order",
    }
)
# ----------------------------------------------------------------------------
# Add Material Master Data columns
df_wip_assy_detail_materials = df_wip_assy_detail_tmp.join(
    df_material_master_end, on=["Plant", "Material_Number"], how="left"
)
# ----------------------------------------------------------------------------
# Add Business rules for Supplier Management
df_wipassy_full = (
    df_wip_assy_detail_materials.fillna("", "Description")
    .fillna("ND", "Material_Type")
    .fillna("XXX", "MRP_Controller")
    .withColumn("MRP_Unit", f.col("Plant"))
    .withColumn("INT/EXT", f.lit("Internal"))
    .withColumn(
        "Supplier_Code",
        f.coalesce(f.col("Supplier_Code"), f.concat(f.lit("INT_"), f.col("Plant"))),
    )
    .withColumn(
        "Supplier_Name",
        f.coalesce(
            f.col("Supplier_Name"),
            f.concat(f.lit("Internal_"), f.col("Plant")),
        ),
    )
)
# ----------------------------------------------------------------------------
# DES Management
df_wipassy_full = df_wipassy_full.withColumn(
    "Production_Site",
    f.when(
        (f.col("Plant") == "1000")
        & (
            (f.col("MRP_Controller") == "DET")
            | (f.col("Profit_Center").isin(["BCL", "HAP", "297", "298", "299", "DEW"]))
            | (f.col("Profit_Center").startswith("V"))
        ),
        f.lit("LATE-LFR1 - Labege Systems"),
    ).otherwise(f.col("Production_Site")),
)
# ----------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Tr. 8 - Add Division : Region

# COMMAND ----------

df_wipassy_full = df_wipassy_full.join(df_bronze_site, ["Production_Site"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 9 - Add External Work In progress Assy (out SAP)

# COMMAND ----------

# Add AVCORP WIP Details Parts
df_wipassy_full_end = df_wipassy_full.unionByName(
    df_wipassy_avcorp, allowMissingColumns=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 10 - Management Historisation WIP ASSY

# COMMAND ----------

# Calculate latest wip assy (both base and detail) and their weekly or
# monthly evolution depending on run period
if PERIOD == "weekly":
    df_wipassy_weekly = add_weekly_evol_dates(df_wipassy_full_end)
    df_wipassy_weekly = df_wipassy_weekly.drop(
        "observation_date_related_sunday", "load_date"
    )

    df_history_w = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued.wip_assy_weekly_history"
    )
    id_w = df_wipassy_weekly.select("observation_week").collect()[0][0]
    df_history_w_filter = df_history_w.filter(f.col("observation_week") != id_w)
    df_wipassy_weekly_end = df_history_w_filter.unionByName(
        df_wipassy_weekly, allowMissingColumns=True
    )
    # Creation ranking for PBI
    w0 = Window.orderBy(f.desc(f.col("observation_week")))
    df_wipassy_weekly_end = df_wipassy_weekly_end.withColumn(
        "observation_week_rank", f.dense_rank().over(w0)
    )
# ----------------------------------------------------------------------------
if PERIOD == "monthly":
    df_wipassy_monthly = add_monthly_evol_dates(df_wipassy_full_end)
    df_wipassy_monthly = df_wipassy_monthly.drop("load_date")

    df_history_m = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued.wip_assy_monthly_history"
    )
    id_m = df_wipassy_monthly.select("observation_month").collect()[0][0]
    df_history_m_filter = df_history_m.filter(f.col("observation_month") != id_m)
    df_wipassy_monthly_end = df_history_m_filter.unionByName(
        df_wipassy_monthly, allowMissingColumns=True
    )
    # Creation ranking or PBI
    w1 = Window.orderBy(f.desc(f.col("observation_month")))
    df_wipassy_monthly_end = df_wipassy_monthly_end.withColumn(
        "observation_month_rank", f.dense_rank().over(w1)
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold Stock On Hand by storage location
# MAGIC
# MAGIC Saving of Gold Global Stock Valued- This represents the enriched LATECOERE SAP ECC6 Global WiP ASSY Latest /Weekly / Monthly.    

# COMMAND ----------

Wipassy_Latest_path = (
    f"{PIPELINE_WRITE_ENV}_gold.inventory_valued.wip_assy_weekly_latest"
)
save_table(dest_table=Wipassy_Latest_path, df=df_wipassy_full_end, mode="overwrite")
# -----------------------------------------------------------------------------------------------------
# Saving weekly historisation
if PERIOD == "weekly":
    Wipassy_Weekly_path = (
        f"{PIPELINE_WRITE_ENV}_gold.inventory_valued.wip_assy_weekly_history"
    )
    save_table(
        dest_table=Wipassy_Weekly_path, df=df_wipassy_weekly_end, mode="overwrite"
    )
# -----------------------------------------------------------------------------------------------------
# Saving Monthly historisation
if PERIOD == "monthly":
    Wipassy_Monthly_path = (
        f"{PIPELINE_WRITE_ENV}_gold.inventory_valued.wip_assy_monthly_history"
    )
    save_table(
        dest_table=Wipassy_Monthly_path, df=df_wipassy_monthly_end, mode="overwrite"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
