# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table for provision Inventory in SAP
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.inventory_valued.sap_provision_latest
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02-Inventory/Provisions/Provisions_AS.xlsm"  
# MAGIC   - f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02-Inventory/Provisions/Provisions_IS.xlsx"  
# MAGIC   
# MAGIC **Triggered by:**  
# MAGIC   - File available on S3
# MAGIC
# MAGIC **Performed in this notebook:** 
# MAGIC   - Extract Sheets 'Result'  
# MAGIC   - Calcul Provision  
# MAGIC   - Save Gold Table

# COMMAND ----------

# MAGIC %md
# MAGIC **Python dependencies needed**
# MAGIC
# MAGIC `%pip install fsspec s3fs openpyxl`

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pandas as pd
import re
import pyspark.sql.functions as f
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("init_latest", "false")
INIT_LATEST = dbutils.widgets.get("init_latest").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC The inputs of this notebook are excel files that are in S3 manual/leapdepot/UC02_INVENTORY. Only files that contain "Provisions_AS" or "Provisions_IS" are acceptable. \
# MAGIC Warning: This notebook needs to work if only one branch put a file. 

# COMMAND ----------

if (
    len(
        dbutils.fs.ls(
            f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02_INVENTORY/Provisions/"
        )
    )
    == 0
):
    dbutils.notebook.exit("No files in leapdepot/UC02_INVENTORY/Provisions/")

# COMMAND ----------

df = spark.createDataFrame(
    dbutils.fs.ls(
        f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02_INVENTORY/Provisions/"
    )
)

if df.count() > 2:
    raise Exception("More than 2 files in the folder, check and come back")

list_branch_files = []

if df.filter(f.col("name").contains("Provisions_AS")).count() > 0:
    list_branch_files.append("AS")

if df.filter(f.col("name").contains("Provisions_IS")).count() > 0:
    list_branch_files.append("IS")

list_branch_files

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# Upload Material Master Data
# The goal is to valued qty of provision on standard and average price
df_material = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed"
).select(
    "Material_Number",
    "MRP_Unit",
    "Profit_Center",
    "Standard_Price_EUR_Budget",
    "Average_Price_EUR_Budget",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 - AS provisions

# COMMAND ----------

if "AS" in list_branch_files:
    path_to_reference_file_as = list(
        spark.createDataFrame(
            dbutils.fs.ls(
                f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02_INVENTORY/Provisions/"
            )
        )
        .filter(f.col("name").contains("Provisions_AS"))
        .select("path")
        .toPandas()["path"]
    )[0]

    # Create DataFrame according AS Excel Files
    sheet_name = "Result"
    # We read the database saved in the corresponding sheet_name
    df_prov_as = pd.read_excel(
        path_to_reference_file_as, sheet_name=sheet_name, dtype="string"
    )
    ## Keep solution where we used Header from Excel Files
    # Rename column headers and replace invalid characters
    df_prov_as.columns = [re.sub("\W+", "_", col.strip()) for col in df_prov_as.columns]

    # # We create the schema header basing on the columns of the file loaded
    df_prov_schema_headers_as = StructType(
        [
            StructField(field_name, StringType(), True)
            for field_name in df_prov_as.columns
        ]
    )
    df_stk_prov_as = spark.createDataFrame(
        pd.DataFrame(df_prov_as), schema=df_prov_schema_headers_as
    )
    ################################################################
    # CALCUL PROVISIONS
    # LATECOERE AS BUSINESS RULES
    ################################################################
    # Select Only Columns need for Provision Calculation
    df_stk_prov_as_calc = df_stk_prov_as.select(
        "Division", "Référence_article", "Excess_Net", "Q_Neut_"
    )
    # ----------------------------------------------------------------
    # Cast columns Quantity
    df_stk_prov_as_cast = df_stk_prov_as_calc.withColumn(
        "Excess_Net", f.col("Excess_Net").cast("double")
    ).withColumn("Q_Neut_", f.col("Q_Neut_").cast("double"))
    # ----------------------------------------------------------------
    # Renaming Headers
    df_stk_prov_as_renamed = df_stk_prov_as_cast.withColumnRenamed(
        "Division", "MRP_Unit"
    ).withColumnRenamed("Référence_article", "Material_Number")
    # ----------------------------------------------------------------
    # Join With Material Master Data
    df_join_as = df_stk_prov_as_renamed.join(
        df_material, ["Material_Number", "MRP_Unit"], "left"
    )
    # ----------------------------------------------------------------
    # Management of null values
    df_stk_prov_as_null = df_join_as.withColumn(
        "Excess_Net", f.coalesce(f.col("Excess_Net"), f.lit(0))
    ).withColumn("Q_Neut_", f.coalesce(f.col("Q_Neut_"), f.lit(0)))
    # ----------------------------------------------------------------
    # Renaming Headers 2
    df_stk_prov_as_renamed2 = df_stk_prov_as_null.withColumnRenamed("MRP_Unit", "Plant")
    # ----------------------------------------------------------------
    # Calcul Quantity in provisions
    # Sometimes Excess net is erase partially or totally by business according column Q_Neut
    df_stk_prov_as_qty = df_stk_prov_as_renamed2.withColumn(
        "Quantity_Prov",
        f.when(
            f.col("Excess_Net") - f.col("Q_Neut_") > 0,
            f.col("Excess_Net") - f.col("Q_Neut_"),
        ).otherwise(0),
    )
    # Group by Plant Material and Profit Center
    df_stk_prov_end_as = df_stk_prov_as_qty.groupBy(
        "Plant",
        "Material_Number",
        "Profit_Center",
        "Standard_Price_EUR_Budget",
        "Average_Price_EUR_Budget",
    ).agg(f.sum("Quantity_Prov").alias("Qty_Prov"))
    # ----------------------------------------------------------------
    # Keep only entries upper 0
    df_stk_prov_end_as = df_stk_prov_end_as.filter(f.col("Qty_Prov") > 0)
    df_stk_prov_end_as = df_stk_prov_end_as.fillna(0)
    # ----------------------------------------------------------------
    # Calcul Provision in Standard price and Average Price
    df_stk_prov_end_as = (
        df_stk_prov_end_as.withColumn(
            "Standard_Price_Provision",
            -f.col("Qty_Prov") * f.col("Standard_Price_EUR_Budget"),
        )
        .withColumn(
            "Average_Price_Provision",
            -f.col("Qty_Prov") * f.col("Average_Price_EUR_Budget"),
        )
        .drop("Standard_Price_EUR_Budget", "Average_Price_EUR_Budget")
    )
    # ----------------------------------------------------------------
    # Add branch information
    df_stk_prov_end_as = df_stk_prov_end_as.withColumn("Branch", f.lit("AS"))
    # ----------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2 - IS provisions

# COMMAND ----------

if "IS" in list_branch_files:
    path_to_reference_file_is = list(
        spark.createDataFrame(
            dbutils.fs.ls(
                f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02_INVENTORY/Provisions/"
            )
        )
        .filter(f.col("name").contains("Provisions_IS"))
        .select("path")
        .toPandas()["path"]
    )[0]

    # Create DataFrame according IS Excel Files
    sheet_name = "Global"
    # We read the database saved in the corresponding sheet_name
    df_prov_is = pd.read_excel(
        path_to_reference_file_is, sheet_name=sheet_name, dtype="string"
    )
    ## Keep solution where we used Header from Excel Files
    # Rename column headers and replace invalid characters
    df_prov_is.columns = [re.sub("\W+", "_", col.strip()) for col in df_prov_is.columns]

    # # We create the schema header basing on the columns of the file loaded
    df_prov_schema_headers_is = StructType(
        [
            StructField(field_name, StringType(), True)
            for field_name in df_prov_is.columns
        ]
    )
    df_stk_prov_is = spark.createDataFrame(
        pd.DataFrame(df_prov_is), schema=df_prov_schema_headers_is
    )
    ################################################################
    # CALCUL PROVISIONS
    # LATECOERE IS BUSINESS RULES
    ################################################################
    # Select Only Columns need for Provision Calculation
    df_stk_prov_is_calc = df_stk_prov_is.select(
        "Division",
        "Article",
        "OVERSTOCK_REVERSAL_PROVISION_",
        "DEAD_STOCK_REVERSAL_PROVISION_",
    )
    # ----------------------------------------------------------------
    # Cast Columns Quantity
    df_stk_prov_is_cast = df_stk_prov_is_calc.withColumn(
        "OVERSTOCK_REVERSAL_PROVISION_",
        f.col("OVERSTOCK_REVERSAL_PROVISION_").cast("double"),
    ).withColumn(
        "DEAD_STOCK_REVERSAL_PROVISION_",
        f.col("DEAD_STOCK_REVERSAL_PROVISION_").cast("double"),
    )
    # ----------------------------------------------------------------
    # Renaming Headers
    df_stk_prov_is_renamed = df_stk_prov_is_cast.withColumnRenamed(
        "Division", "MRP_unit"
    ).withColumnRenamed("Article", "Material_Number")
    # ----------------------------------------------------------------
    # Management of Specific MRP_Unit - Cleaning Excel Files
    df_stk_prov_is_mrp = df_stk_prov_is_renamed.withColumn(
        "MRP_unit",
        f.when(f.col("MRP_unit") == "FTWZ", f.lit("2000-FTWZ"))
        .when(f.col("MRP_unit") == "2091", f.lit("2000-2091"))
        .when(f.col("MRP_unit") == "2092", f.lit("2000-2092"))
        .otherwise(f.col("MRP_unit")),
    )
    # ----------------------------------------------------------------
    # # Join With Material Master Data
    df_join_is = df_stk_prov_is_mrp.join(
        df_material, ["Material_Number", "MRP_unit"], "left"
    )
    # ----------------------------------------------------------------
    # Management of null values
    df_stk_prov_is_calc = df_join_is.withColumn(
        "OVERSTOCK_REVERSAL_PROVISION_",
        f.coalesce(f.col("OVERSTOCK_REVERSAL_PROVISION_"), f.lit(0)),
    ).withColumn(
        "DEAD_STOCK_REVERSAL_PROVISION_",
        f.coalesce(f.col("DEAD_STOCK_REVERSAL_PROVISION_"), f.lit(0)),
    )
    # ----------------------------------------------------------------
    # Renaming Headers 2
    df_stk_prov_is_renamed2 = df_stk_prov_is_calc.withColumnRenamed(
        "MRP_unit", "Plant"
    )
    # ----------------------------------------------------------------
    # Provisions on IS side is performed on standard price
    df_stk_prov_is_calc = df_stk_prov_is_renamed2.withColumn(
        "Standard_Price_Provision",
        -f.col("DEAD_STOCK_REVERSAL_PROVISION_")
        - f.col("OVERSTOCK_REVERSAL_PROVISION_"),
    )
    # ----------------------------------------------------------------
    # Goup by Plant Material and Profit Center
    df_stk_prov_end_is = df_stk_prov_is_calc.groupBy(
        "Plant",
        "Material_Number",
        "Profit_Center",
        "Standard_Price_EUR_Budget",
        "Average_Price_EUR_Budget",
    ).agg(f.sum("Standard_Price_Provision").alias("Standard_Price_Provision"))
    # ----------------------------------------------------------------
    # Keep only entries upper 0
    df_stk_prov_end_is = df_stk_prov_end_is.filter(
        f.col("Standard_Price_Provision") < 0
    )
    df_stk_prov_end_is = df_stk_prov_end_is.fillna(0) 
    # ----------------------------------------------------------------  
    # Calcul Quantity & average price
    df_stk_prov_end_is = (
        df_stk_prov_end_is.withColumn(
            "Average_Price_Provision",
            f.col("Average_Price_EUR_Budget")
            * f.col("Standard_Price_Provision")
            / f.col("Standard_Price_EUR_Budget"),
        )
        .withColumn(
            "Qty_Prov",
            -f.col("Standard_Price_Provision") / f.col("Standard_Price_EUR_Budget"),
        )
        .drop("Standard_Price_EUR_Budget", "Average_Price_EUR_Budget")
    )
    # ----------------------------------------------------------------  
    # Add Branch information
    df_stk_prov_end_is = df_stk_prov_end_is.withColumn("Branch", f.lit("IS"))
    # ----------------------------------------------------------------  

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 3 - Union AS / IS

# COMMAND ----------

if ("IS" in list_branch_files) & ("AS" in list_branch_files):
    df_stk_prov = df_stk_prov_end_as.unionByName(df_stk_prov_end_is, False)
if ("IS" in list_branch_files) & ("AS" not in list_branch_files):
    df_stk_prov = df_stk_prov_end_is
if ("AS" in list_branch_files) & ("IS" not in list_branch_files):
    df_stk_prov = df_stk_prov_end_as

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 4 - Cast Result

# COMMAND ----------

df_stk_prov = (
    df_stk_prov.withColumn("Qty_Prov", f.col("Qty_Prov").cast("double"))
    .withColumn(
        "Standard_Price_Provision", f.col("Standard_Price_Provision").cast("double")
    )
    .withColumn(
        "Average_Price_Provision", f.col("Average_Price_Provision").cast("double")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC #Initialisation of the gold table
# MAGIC When INIT_LATEST = True, the new files completely replace the table. 

# COMMAND ----------

# MAGIC %md
# MAGIC ##Update the gold table based on the branch
# MAGIC Initialisation of the gold table: 
# MAGIC When INIT_LATEST = True, the new files completely replace the table. 

# COMMAND ----------

if INIT_LATEST:
    df_final = df_stk_prov

if not INIT_LATEST:
    df_initial = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued.sap_provision_latest"
    )

    for branch in list_branch_files:
        df_initial = df_initial.filter(f.col("Branch") != f"{branch}")

    df_final = df_initial.unionByName(df_stk_prov, False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Save Gold Table Inventory Provision

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "inventory_valued"
table = "sap_provision_latest"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_final,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Archive files in S3

# COMMAND ----------

source_path = (
    f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02_INVENTORY/Provisions/"
)
target_path = f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/archive/manual/leapdepot/UC02_INVENTORY/Provisions/"

# COMMAND ----------

if len(dbutils.fs.ls(f"{source_path}/")) > 0:
    s3_files = spark.createDataFrame(dbutils.fs.ls(f"{source_path}/"))
    # List of all file name to ingest
    name_list = [row.name for row in s3_files.select("name").collect()]

# COMMAND ----------

for i in range(len(name_list)):
    file_path = name_list[i]
    dbutils.fs.mv(f"{source_path}/{file_path}", f"{target_path}/{file_path}")
