# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # [STOCK ON HAND - VALUED]
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim of this notebook is to create a data asset for stock valued by & plant
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - N/A  
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Build for Use Case 2 - Inventory  
# MAGIC
# MAGIC **Input Tables Pipeline**  
# MAGIC - {PIPELINE_READ_ENV}_gold.supply_chain_logistic.stock_by_storage_location 
# MAGIC - {PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_stock_on_hand_valued_latest  
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdlg_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.manual_input.plant_description_V2
# MAGIC
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - N/A  
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.inventory_valued.stock_on_hand_valued 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt

# COMMAND ----------

#N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import DataFrame, functions as f
from databricks.sdk.runtime import dbutils
from datetime import datetime 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports  
# MAGIC
# MAGIC - **Save_Table** required for saving Table on DBX

# COMMAND ----------

from leap_utils.data_asset.table_utils import save_table

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("period", "weekly")
PERIOD = dbutils.widgets.get("period")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location

# COMMAND ----------

#N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Min Date to consider parameter

# COMMAND ----------

#N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Stock by Storage Location from LEAP
# MAGIC
# MAGIC **df_StockStorageLocation** : Gold Table From LEAP - Stock in quantity by Storage Location 

# COMMAND ----------

if PERIOD == "weekly":
    df_StockStorageLocation = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.supply_chain_logistic.stock_by_storage_location_weekly"
    )

if PERIOD == "monthly":
    df_StockStorageLocation = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.supply_chain_logistic.stock_by_storage_location_monthly"
    )   

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Material Master Data by Plant from LEAP
# MAGIC
# MAGIC **df_MasterDataPlant** : Gold Table From LEAP - Material Master Data by Plant

# COMMAND ----------

if PERIOD == "weekly":
    df_MasterDataPlant = spark.read.table(
        f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
    )
if PERIOD == "monthly":
    table = f"{REFERENCE_READ_ENV}_gold.master_data.material_plant"
    today = datetime.today()
    if today.month == 1:
        prev_month = 12
    else:
        prev_month = today.month - 1

    WRITING_OPERATIONS = (
        "WRITE",
        "REPLACE TABLE AS SELECT",
        "COPY INTO",
        "MERGE",
        "CREATE OR REPLACE TABLE AS SELECT",
    )
    # We take the last version of previous month
    # To be sure we are not including Standard price modification
    # (Performed each 1st of the month)
    version = spark.sql(
        f"select version from (describe history {table}) where month(timestamp) == {prev_month} and operation IN {WRITING_OPERATIONS} limit 1 "
    ).collect()[0][0]

    df_MasterDataPlant = spark.read.table(f"{table}@v{version}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Provisions From LEAP
# MAGIC **df_provisions** : Gold Table From LEAP - Provision by Material/Plant

# COMMAND ----------

df_provisions = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.inventory_valued.sap_provision_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - MDLG from SAP
# MAGIC
# MAGIC **df_mdlg** : Bronze Table From SAP - MRP Area Storage Location

# COMMAND ----------

df_mdlg = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdlg_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Plant Description Manual Input from LEAP
# MAGIC
# MAGIC **df_PlantDescription** : Manual Table From LEAP - Description of SAP Plant

# COMMAND ----------

df_PlantDescription = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.plant_description_V2"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Import - Gold Table - Inventory AVCORP  
# MAGIC **df_stk_avcorp** : Gold Table From SAP - Stock on Hand from AVCORP (out SAP)

# COMMAND ----------

if PERIOD == "weekly":
    df_stk_avcorp_on_hand = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_stock_on_hand_valued_latest"
    )
if PERIOD == "monthly":
    df_stk_avcorp_on_hand = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_stock_on_hand_valued_monthly"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

#N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

#N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions

# COMMAND ----------

#N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation Material Master Data by Plant

# COMMAND ----------

# Selection Columns
df_MasterDataPlant = (df_MasterDataPlant.select(
            "standard_price_eur_budget",
            "average_price_eur_budget",
            "material_number",
            "plant",
            "division",
            "region",
            "stock_site",
            "profit_center",
            "material_description",
            "supplier_name",
            "mrp_controller",
            "material_type",
            "supplier_code",
            "procurement_type",
            "mrp_unit",
            "net_needs",
            "total_needs",
    )
    .dropDuplicates()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation MDLG- MRP Area Storage Location

# COMMAND ----------

# Selection Columns & Renaming Headers
df_mdlg_end = df_mdlg.select(
    [
        f.col("werks").alias("plant"),
        f.col("lgort").alias("storage_location"),
        f.col("berid").alias("mrp_unit"),
    ]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation Provisions Files from SAP

# COMMAND ----------

# Selection Columns and renaming
df_provisions_select = df_provisions.groupBy("Plant", "Material_Number").agg(
    f.sum("Qty_Prov").alias("Provision"),
    f.sum("Standard_Price_Provision").alias("Standard_Price_Provision"),
    f.sum("Average_Price_Provision").alias("Average_Price_Provision"),
)

# Casting column Prices
df_provisions_formatted = df_provisions_select.withColumn(
    "Standard_Price_Provision", f.col("Standard_Price_Provision").cast("double")
).withColumn("Average_Price_Provision", f.col("Average_Price_Provision").cast("double"))


# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation Avcorp Stock on hand

# COMMAND ----------

df_stk_avcorp_on_hand = (
    df_stk_avcorp_on_hand.withColumn("division", f.lit("ASAM"))
    .withColumn("region", f.lit("AMERICAS"))
    .drop("Branch")
)
# Manage New naming
df_stk_avcorp_on_hand = df_stk_avcorp_on_hand.withColumn(
    "Stock_Site",
    f.when(f.col("Plant") == "6000", f.lit("LAC1 - Delta"))
    .when(f.col("Plant") == "4020", f.lit("LMXC - Hermosillo"))
    .otherwise(f.col("Stock_Site")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 1 - Enrichement Material Master Data

# COMMAND ----------

# Traduction SAP field for category of Material
df_MasterDataPlant_category = df_MasterDataPlant.withColumn(
    "INT/EXT",
    f.when(f.col("procurement_type") == "F", "External").otherwise("Internal"),
).drop("PF_pourcentage_affectation")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 2 - Creation DataFrame Stock On Hand Valued
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 2.1 - Add MRP_unit data

# COMMAND ----------

# On IS side, MRP_Unit is linked with Storage Location
# we join with MRP Area Storage Location
df_StockStorageLocation_mrp = df_StockStorageLocation.join(
    df_mdlg_end, on=["Plant", "Storage_Location"], how="left"
)
# If Mrp_unit is empty we take the plant as MRP_Unit
df_StockStorageLocation_mrp = df_StockStorageLocation_mrp.withColumn(
    "MRP_Unit", f.coalesce(f.col("MRP_Unit"), f.col("Plant"))
)
# ---------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 2.2 - Calculate Stock On Hand for valorization

# COMMAND ----------

# We need to aggregate Plant/Material Number and MRP Area
df_stock_valued = df_StockStorageLocation_mrp.groupby(
    ["Material_Number", "Plant", "MRP_Unit"]
).agg(
    f.sum("Stock_On_Hand").alias("Stock_On_Hand"),
    f.sum("Transit_Stock").alias("Transit_Stock"),
    f.sum("VMI").alias("VMI"),
    f.sum("Customers_Stock").alias("Customers_Stock"),
)
# ---------------------------------------------------------------------------------
# Like Customers Stock are link with Sales Orders
# Costs already take in account through WIP ASSY
# Moreover we need to dispatch Transit to Stock on Hand
# So we substract these quantity to actual Stock on Hand
df_stock_valued_clean = df_stock_valued.withColumn(
    "Stock_On_Hand", f.col("Stock_On_Hand") - f.col("Customers_Stock") - f.col("Transit_Stock")
).drop("Customers_Stock")

#Management negative value
df_stock_valued_clean = df_stock_valued_clean.withColumn(
    "Stock_On_Hand",
    f.when(f.col("Stock_On_Hand")<0,f.lit(0)).otherwise(f.col("Stock_On_Hand")))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 2.3 - Add Material Master Data

# COMMAND ----------

# Join Dataframe Stock On Hand with Material master Data
df_stock_valued_joined = df_stock_valued_clean.join(
    df_MasterDataPlant_category,
    on=["Plant", "Material_Number", "MRP_Unit"],
    how="left",
)
# Join Description of Plant according manual Input from LEAP
df_stock_valued_plant = df_stock_valued_joined.join(
    df_PlantDescription,
    df_stock_valued_joined.MRP_Unit == df_PlantDescription.Plant_Div,
    "left",
).drop("Plant_Div")

# Management Mrp_Unit as a dedicated Plant
df_stock_valued_mrp = df_stock_valued_plant.withColumn(
    "Temp_maj",
    f.when(f.col("Plant") != f.col("MRP_Unit"), f.lit("X")).otherwise(f.lit(None)),
)
df_stock_valued_mrp = (df_stock_valued_mrp.withColumn(
    "Plant",
    f.when(f.col("Temp_maj") == "X", f.col("MRP_Unit")).otherwise(f.col("Plant")),
).withColumn(
    "Stock_Site",
    f.when(f.col("Temp_maj") == "X", f.col("Plant_Description_new")).otherwise(f.col("Stock_Site")),
).withColumn(
    "Stock_Site",
    f.coalesce(f.col("Stock_Site"),f.col("Plant_Description_new"))
).drop("Temp_maj","Plant_Description_new")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 2.4 - Correction VMI (Specific LDB)

# COMMAND ----------

df_stock_corrected_vmi = df_stock_valued_mrp.withColumn(
    "VMI",
    f.when(
        (f.col("Plant") == "1010")
        & (f.col("MRP_Controller").isin(["BAS", "BST", "BBK", "SKI"])),
        (-1) * (f.col("Stock_On_Hand") + f.col("Transit_Stock")),
    ).otherwise((-1) * f.col("VMI")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 2.5 - Valorization Stock on Average and Standard Price

# COMMAND ----------

# Valorisation Stock On Hand (Average & Standard Price)
df_stock_valuated_on_hand = df_stock_corrected_vmi.withColumn(
    "Standard_Stock_On_Hand_Price",
    f.when(f.col("Stock_On_Hand").isNull(), f.lit(0)).otherwise(
        f.col("Stock_On_Hand") * f.col("Standard_Price_EUR_Budget")
    ),
).withColumn(
    "Average_Stock_On_Hand_Price",
    f.when(f.col("Stock_On_Hand").isNull(), f.lit(0)).otherwise(
        f.col("Stock_On_Hand") * f.col("Average_Price_EUR_Budget")
    ),
)
# ---------------------------------------------------------------------------------
# Valorisation Transit Stock (Average & Standard Price)
df_stock_valuated_transit = df_stock_valuated_on_hand.withColumn(
    "Standard_Transit_Stock_Price",
    f.when(f.col("Transit_Stock").isNull(), f.lit(0)).otherwise(
        f.col("Transit_Stock") * f.col("Standard_Price_EUR_Budget")
    ),
).withColumn(
    "Average_Transit_Stock_Price",
    f.when(f.col("Transit_Stock").isNull(), f.lit(0)).otherwise(
        f.col("Transit_Stock") * f.col("Average_Price_EUR_Budget")
    ),
)
# ---------------------------------------------------------------------------------
# Valorisation VMI(Average & Standard Price)
df_stock_valued_vmi = (
    df_stock_valuated_transit.withColumn(
        "Standard_VMI_Price",
        f.when(f.col("VMI").isNull(), f.lit(0)).otherwise(
            f.col("VMI") * f.col("Standard_Price_EUR_Budget")
        ),
    )
    .withColumn(
        "Average_VMI_Price",
        f.when(f.col("VMI").isNull(), f.lit(0)).otherwise(
            f.col("VMI") * f.col("Average_Price_EUR_Budget")
        ),
    )
    .dropDuplicates()
)
# ---------------------------------------------------------------------------------
# We keep only entries with values greater than 0
df_stock_valued_final = df_stock_valued_vmi.filter(
    (f.col("Average_Stock_On_Hand_Price") != 0)
    | (f.col("Standard_Stock_On_Hand_Price") != 0)
    | (f.col("Standard_Transit_Stock_Price") != 0)
    | (f.col("Average_Transit_Stock_Price") != 0)
    | (f.col("Average_VMI_Price") != 0)
    | (f.col("Standard_VMI_Price") != 0)
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 2.6 - Management Provisions SAP

# COMMAND ----------

#Here we join Provisions to Stock on Hand on SAP
#----------------------------------------------------------------------------------------
# 1st Join between Stock on Hand and Provisions
df_stock_prov = df_stock_valued_final.join(
    df_provisions_formatted,["Plant", "Material_Number"],"left")

# Management Provisions Upper than Stock On Hand value
df_stock_prov_formatted = df_stock_prov.withColumn(
    "Provision",
    f.when(
        (f.col("Provision")) > (f.col("Stock_On_Hand") + f.col("Transit_Stock")),
        (f.col("Stock_On_Hand") + f.col("Transit_Stock")),
    ).otherwise(f.col("Provision")),
)

df_stock_prov_formatted = df_stock_prov_formatted.withColumn(
    "Standard_Price_Provision",
    f.when(
        (-1)*(f.col("Standard_Price_Provision")) > (f.col("Standard_Stock_On_Hand_Price") + f.col("Standard_Transit_Stock_Price")),
        (-1)*((f.col("Standard_Stock_On_Hand_Price") + f.col("Standard_Transit_Stock_Price"))),
    ).otherwise(f.col("Standard_Price_Provision")),
)

df_stock_prov_end = df_stock_prov_formatted.withColumn(
    "Average_Price_Provision",
    f.when(
        (-1)*(f.col("Average_Price_Provision")) > (f.col("Average_Stock_On_Hand_Price") + f.col("Average_Transit_Stock_Price")),
        (-1)*((f.col("Average_Stock_On_Hand_Price") + f.col("Average_Transit_Stock_Price"))),
    ).otherwise(f.col("Average_Price_Provision")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 2.7 - Add Avcorp Stock on Hand

# COMMAND ----------

df_stk_with_avcorp = df_stock_prov_end.unionByName(df_stk_avcorp_on_hand,allowMissingColumns=True)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

#N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

#N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold Stock On Hand by storage location
# MAGIC
# MAGIC Saving of Gold Stock On Hand table - This represents the enriched LATECOERE SAP ECC6 Stock on Hand.  

# COMMAND ----------

if PERIOD == "weekly":
    StockValuedOutput = f"{PIPELINE_WRITE_ENV}_gold.inventory_valued.stock_on_hand_valued"
    save_table(dest_table=StockValuedOutput, df=df_stk_with_avcorp, mode="overwrite")
if PERIOD == "monthly":
    StockValuedOutput = f"{PIPELINE_WRITE_ENV}_gold.inventory_valued.stock_on_hand_valued_monthly"
    save_table(dest_table=StockValuedOutput, df=df_stk_with_avcorp, mode="overwrite")    

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
