# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Production hours costs
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC This script creates the gold table for production hours costs from the general ledger. 
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - SupplyChain_Inventory_valuation_weekly
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {PIPELINE_READ_ENV}_gold.finance.general_ledger_exposed
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed
# MAGIC - {REFERENCE_READ_ENV}_gold.finance.currency_exchange
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.inventory_valued.production_hours_costs_latest
# MAGIC - {PIPELINE_WRITE_ENV}_gold.inventory_valued.production_hours_costs_history
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC     1. [Output][Output - Common Functions] The function UnityCatalogCheckTableExists should be in leap_utils
# MAGIC     2. [Data Preparation][Preparation 1 - Date cleaning] The cleaning of the sap enter date should be done in create_silver_general_ledger

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from datetime import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC - **convert_currency** used to convert currency in euros
# MAGIC - **save_table** to save the gold table as an output of this notebook 

# COMMAND ----------

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### General Ledger 
# MAGIC
# MAGIC **df_GL_raw** is the gold general ledger for LATECOERE Legacy perimeter (SAP ECC6) coming from the data asset general ledger. 

# COMMAND ----------

# DBTITLE 0,ransac
df_GL_raw = spark.read.table(f"{PIPELINE_READ_ENV}_gold.finance.general_ledger_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Company master data table
# MAGIC **df_company_raw** is the company gold table that gives all information relative to each company.  

# COMMAND ----------

df_company_raw = (
    spark.read.table(
        f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
    )
    .select("Company", "Company_Entity")
    .distinct()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Currency exchange rates table
# MAGIC **df_currency_raw** is the gold table with exchange rates and used here to convert amounts in euros.

# COMMAND ----------

df_currency_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.currency_exchange"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Plant master data table
# MAGIC **df_plant_raw** is the plant gold table that gives all information relative to each plant.  

# COMMAND ----------

df_plant_raw = spark.read.table(f'{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed')

# COMMAND ----------

# MAGIC %md
# MAGIC ###Work orders SAP table
# MAGIC **df_afko_raw** is the SAP table for work orders. This table is used only to separate gimont and montredon inside plant 1000. 

# COMMAND ----------

df_afko_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afko_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

list_of_columns_to_select_gl = [
    "Record_nber_of_the_line_item_record",
    "Fiscal_year",
    "Currency_key",
    "Base_Unit_Of_Measure",
    "Posting_period",
    "Accounting_document_number",
    "Company_code",
    "Account_number",
    "Company_ID_of_trading_partner",
    "Transaction_type",
    "sap_enter_date",
    "Posting_document_date",
    "Plant",
    "Cost_center",
    "Order_number",
    "Material_number",
    "WBS_element",
    "extraction_timestamp_glpca",
    "Amount_in_profit_center_local_currency_",
    "Quantity_",
    "Profit_center_short",
    "Group_Name",
    "Accounting_PC_Group",
    "PC_Branch",
    "Short_Description",
    "Plant_Description_new",
    "Company_Description",
    "Company_Currency",
    "Cost_center_adjusted",
    "Cost_Center_short",
    "CCSite",
    "CCBranch",
    "Cost_center_Description",
    "WBS_Code",
    "WBS_Description",
    "WBS_Plant",
    "Amount_in_transaction_currency_",
    "Amount_in_company_code_currency_",
]

# COMMAND ----------

list_of_columns_to_aggregate = ['Fiscal_year',
 'Currency_key',
 'Posting_period',
 'Company_code',
 'Account_number',
 'Company_ID_of_trading_partner',
 'Plant',
 'Order_number',
 'Material_number',
 'WBS_element',
 'extraction_timestamp_glpca',
 'Profit_center_short',
 'Short_Description',
 'Company_Currency',
 'WBS_Code',
 'WBS_Description', 
 'Posting_year_month', 
 'Posting_year_week', 
 'CnyBranch',
 'Site']

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC - Selection of columns to keep useful for the revenue in df_gl_raw
# MAGIC - Modifying the format of the column sap_enter_date \
# MAGIC [TECH DEBT ITEM]: this should be done in the create_silver_general_ledger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - General ledger downselect

# COMMAND ----------

df_GL_prep = df_GL_raw.select(list_of_columns_to_select_gl)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Date cleaning
# MAGIC SAP enter date in date format \
# MAGIC [Technical debt]: should be done in general ledger data asset

# COMMAND ----------

df_GL_prep = df_GL_prep.withColumn(
    "sap_enter_date", f.to_date(f.col("sap_enter_date"), "yyyyMMdd")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Format cleaning
# MAGIC Company_ID_of_trading_partner

# COMMAND ----------

df_GL_prep = df_GL_prep.withColumn(
    "Company_ID_of_trading_partner",
    f.regexp_replace("Company_ID_of_trading_partner", r"^0+(?=\d)", ""),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Amount in transaction currency missing
# MAGIC There are few lines in the general ledger where the columns currency_key and amount_in_transaction_currency are empty. Therefore, in these cases, the currency key takes the company currency and the amount the amount in company currency. 

# COMMAND ----------

df_GL_prep = df_GL_prep.withColumn(
    "Amount_in_transaction_currency_coal",
    f.when(
        f.col("Currency_key").isNull(),
        f.col("Amount_in_company_code_currency_"),
    ).otherwise(f.col("Amount_in_transaction_currency_")),
).withColumn(
    "Currency_key_coal",
    f.when(f.col("Currency_key").isNull(), f.col("Company_currency")).otherwise(
        f.col("Currency_key")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 5 - Work order number cleaning
# MAGIC Remove lead zeros of the column Order_number

# COMMAND ----------

df_GL_prep = df_GL_prep.withColumn(
    "Order_number",
    f.regexp_replace("Order_number", r"^0+(?=\d)", ""),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 6 - Work order sap table cleaning
# MAGIC Remove lead zeros of the column aufnr = order number

# COMMAND ----------

df_afko_prep = df_afko_raw.select("aufnr", "dispo").withColumn(
    "Order_number",
    f.regexp_replace("aufnr", r"^0+(?=\d)", ""),
).drop("aufnr")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 7 - Plant dataframe cleaning 

# COMMAND ----------

df_plant_prep = (
    df_plant_raw.select("Plant", "Plant_Description_new")
    .distinct()
    .withColumnRenamed("Plant", "WBS_Plant")
    .withColumnRenamed("Plant_Description_new", "WBS_Plant_Description")
)

df_plant_prep = df_plant_prep.withColumn(
    "WBS_Plant_Description",
    f.when(f.col("WBS_Plant") == "1000", f.lit("LFR-Gimont")).otherwise(
        f.col("WBS_Plant_Description")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 - Filter on production hours accounts 
# MAGIC Hours costs are gathered in the general ledger in account numbers that start with 92, and only hours on OF are interesting here. 

# COMMAND ----------

df_h_costs = df_GL_prep.filter(
    f.col("Account_number").startswith("92")
) 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2 - Production houurs costs on WO

# COMMAND ----------

df_h_costs_on_wo = df_h_costs.filter(f.col("Plant").isNotNull()).filter(
    ~(f.col("Transaction_type").isin(["KOAL", "KOAO", "RKU1", "RKU2"]))
).filter(f.col('Order_Number').isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 3 - Convert amounts 
# MAGIC Calculated amount: 
# MAGIC - Amount in transaction currency converted to EUR at budget rate

# COMMAND ----------

# Check Posting_document_date not in future
df_h_costs_on_wo = df_h_costs_on_wo.withColumn(
    "Posting_document_date_temp",
    f.when(
        f.col("Posting_document_date") > f.current_date(), f.date_add(f.current_date(),-1)
    ).otherwise(f.col("Posting_document_date")),
)

# COMMAND ----------

# Amount in transaction currency converted to EUR at budget rate conso
df_converted = table_utils.convert_currency(
    df_base=df_h_costs_on_wo,
    df_currency=df_currency_raw,
    df_base_source_currency_column_name="Currency_key_coal",
    target_currency_value="EUR",
    df_currency_conversion_rate_type_exp_value="Budget",
    df_base_conversion_date_column_name="Posting_document_date_temp",
    conversion_output_column_name="Exchange_Rate_budget_curr_to_eur",
)
df_converted = (
    df_converted.withColumn(
        "Amount_transaction_curr_to_eur_budget_rate",
        f.col("Amount_in_transaction_currency_coal")
        * f.col("Exchange_Rate_budget_curr_to_eur"),
    )
    .drop("Exchange_Rate_budget_curr_to_eur")
    .withColumn(
        "Amount_transaction_curr_to_eur_budget_rate",
        f.when(
            f.col("Currency_key") == "EUR",
            f.col("Amount_in_transaction_currency_"),
        ).otherwise(f.col("Amount_transaction_curr_to_eur_budget_rate")),
    )
    .drop("Currency_key_coal", "Amount_in_transaction_currency_coal","Posting_document_date_temp")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 4 - Add date columns
# MAGIC - Add a column YYYY-MM
# MAGIC - Add a column YYYY-W, W: week number

# COMMAND ----------

df_converted = (
    df_converted.withColumn(
        "Posting_year_month", f.date_format(f.col("Posting_document_date"), "yyyy-MM")
    )
    .withColumn(
        "Posting_year_week",
        f.concat(
            f.year(f.col("Posting_document_date")),
            f.lit("-"),
            f.format_string("%02d", f.weekofyear(f.col("Posting_document_date"))),
        ),
    )
    .withColumn(
        "Posting_year_week",
        f.when(
            (f.weekofyear(f.col("Posting_document_date")) == "1")
            & (f.month("Posting_document_date") == "12"),
            f.concat(
                f.year(f.col("Posting_document_date")) + 1,
                f.lit("-"),
                f.lit("01"),
            ),
        ).otherwise(f.col("Posting_year_week")),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 5 - Separate DES and add company branch 

# COMMAND ----------

df_w_cny_branch = (
    df_converted.join(
        df_company_raw, df_converted.Company_code == df_company_raw.Company, how="left"
    )
    .drop("Company")
    .withColumnRenamed("Company_Entity", "CnyBranch")
)

# COMMAND ----------

df_w_cny_branch = df_w_cny_branch.withColumn(
    "Company_adjusted",
    f.when(
        (f.col("PC_Branch") == "IS") & (f.col("CnyBranch") == "AS"), f.lit("LFR-DES")
    )
    .when(f.col("Profit_Center_short") == "DD1", f.lit("LFR-DES"))
    .when(f.col("Profit_Center_short") == "DD3", f.lit("LFR-DES"))
    .otherwise(f.col("Company_code")),
).withColumn(
    "CnyBranch",
    f.when(f.col("Company_adjusted") == "LFR-DES", f.lit("IS")).otherwise(
        f.col("CnyBranch")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 6 - Site definition

# COMMAND ----------

df_transf = df_w_cny_branch.join(df_afko_prep, ["Order_number"], how="left").join(
    df_plant_prep, ["WBS_Plant"], how="left"
)

# COMMAND ----------

df_transf = df_transf.withColumn(
    "Site",
    f.when(
        (f.col("Plant") == "1000") & (f.col("dispo").startswith("O")),
        f.lit("LFR-Montredon"),
    ),
)
df_transf = df_transf.withColumn(
    "Site",
    f.when(
        (f.col("Plant") == "1000") & (f.col("Site").isNull()), f.lit("LFR-Gimont")
    ).otherwise(f.col("Site")),
)

df_transf = df_transf.withColumn(
    "Site",
    f.when((f.col("Site").isNull()), f.col("Plant_description_new")).otherwise(
        f.col("Site")
    ),
)

df_transf = df_transf.withColumn(
    "Site",
    f.when(f.col("Site").isNull(), f.col("WBS_Plant_Description")).otherwise(
        f.col("Site")
    ),
)

df_transf = df_transf.filter(f.col("Site").isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 7 - Data aggregation & renaming

# COMMAND ----------

df_transf = (
    df_transf.groupBy(list_of_columns_to_aggregate)
    .agg(
        f.sum("Amount_in_company_code_currency_").alias(
            "Amount_in_company_code_currency_"
        ),
        f.sum("Amount_transaction_curr_to_eur_budget_rate").alias(
            "Amount_transaction_curr_to_eur_budget_rate"
        ),
    )
    .withColumnRenamed("CnyBranch", "Branch")
    .withColumnRenamed("Profit_center_Short", "Profit_Center")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

if (
    df_transf.filter(
        f.col("Amount_transaction_curr_to_eur_budget_rate").isNull()
    ).count()
    > 0
):
    raise Exception(
        "Warning: there are nulls in Amount_transaction_curr_to_eur_budget_rate column"
    )

# COMMAND ----------

if df_company_raw.count() != df_company_raw.select("Company").distinct().count():
    raise Exception(
        "Warning: the column Company is not unique in the company gold table"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions
# MAGIC [Technical debt] This function should be in leap_utils. 

# COMMAND ----------

def UnityCatalogCheckTableExists(DbxTablePath) -> bool:

    """Check if table Exist or not"""

    PathSplit = DbxTablePath.lower().split(".")
    if len(PathSplit) != 3:
        print("Must have 3 sections [CatalogName].[SchemaName].[TableName]")
        return "ERROR"
    if len(PathSplit) == 3:

        df_tables = spark.read.table(f"{PathSplit[0]}.information_schema.tables")

        true_false = bool(
            df_tables.filter(f.col("table_catalog") == PathSplit[0])
            .filter(f.col("table_schema") == PathSplit[1])
            .filter(f.col("table_name") == PathSplit[2])
            .count()
        )

        return true_false

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold production hours costs on work order

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "inventory_valued"
table = "production_hours_costs_latest"

table_utils.save_table(f"{catalog}.{domain}.{table}", df_transf, "overwrite", True)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold history production hours costs on WIP
# MAGIC The history is made based on the YYYY-WW of the run. 
# MAGIC Hypothesis: Monday is considered first day of week, Sunday is the last day of the week.

# COMMAND ----------

df_latest = df_transf.withColumn(
    "Snapshot_week", f.lit(datetime.today().strftime("%Y-%U"))
)

# COMMAND ----------

table_history = "production_hours_costs_history"
if not UnityCatalogCheckTableExists(f"{catalog}.{domain}.{table_history}"):
    # Save the latest as the history
    CreateSchemaIfNotExists = True

    if CreateSchemaIfNotExists:
        spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

    table_utils.save_table(
        dest_table=f"{catalog}.{domain}.{table}",
        df=df_latest,
        mode="overwrite",
        overwrite_schema=True
    )

# COMMAND ----------

if UnityCatalogCheckTableExists(f"{catalog}.{domain}.{table_history}"):

    df_history = spark.read.table(f"{catalog}.{domain}.{table_history}")

    today_week = today.strftime("%Y-%U")
    df_history_filter = df_history.filter(f.col("Snapshot_week") != today_week)
    df_history_new = df_history.unionByName(df_latest, allow_missing_columns=False)

    table_utils.save_table(f"{catalog}.{domain}.{table_history}", df_history_new, "overwrite", True)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
