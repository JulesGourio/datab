# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # [WIP PE - Work In Progress for Details Parts VALUED]
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim of this notebook is to create a data asset for wip on details parts
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - N/A  
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Build for Use Case 2 - Inventory  
# MAGIC
# MAGIC **Input Tables Pipeline**  
# MAGIC - {PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_wippe_latest     
# MAGIC
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed  
# MAGIC - {REFERENCE_READ_ENV}_bronze.manual_input.plant_description_V2  
# MAGIC - {REFERENCE_READ_ENV}_gold.finance.currency_exchange
# MAGIC - {REFERENCE_READ_ENV}_bronze.supply_chain.wippe_1000 
# MAGIC - {REFERENCE_READ_ENV}_bronze.supply_chain.wippe_3000
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.inventory_valued.wip_pe_weekly_latest
# MAGIC - {PIPELINE_WRITE_ENV}_gold.inventory_valued.wip_pe_weekly_history
# MAGIC - {PIPELINE_WRITE_ENV}_gold.inventory_valued.wip_pe_monthly_history
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql import functions as f
from pyspark.sql.window import Window
from databricks.sdk.runtime import dbutils
from datetime import datetime

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports  
# MAGIC
# MAGIC - **Save_Table** required for saving Table on DBX

# COMMAND ----------

from leap_utils.data_asset.historisation import (
    add_monthly_evol_dates,
    add_weekly_evol_dates,
)
from leap_utils.data_asset.table_utils import (
    transform_float_column,
    cast_sap_float_column,
    add_prefix_to_columns,
    convert_currency,
    save_table,
)
from leap_utils.data_asset.amount_correction import create_corrected_amounts

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).  
# MAGIC - PERIOD -> Used for specifying period (weekly or monthly) on the notebook run.  

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("period", "weekly")
PERIOD = dbutils.widgets.get("period").lower()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Min Date to consider parameter

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Gold Table - Material Master Data
# MAGIC **df_material_master** : Gold Table From LEAP - Material Master data by plant

# COMMAND ----------

df_material_master = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Gold Table - Currency Exchange from LEAP
# MAGIC
# MAGIC **df_Currency_Exchange** : Gold Table From LEAP - Currency Exchange

# COMMAND ----------

df_Currency_Exchange = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.currency_exchange"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Gold Table - Plant Master Data from LEAP
# MAGIC
# MAGIC **df_plant_master_data** : Gold Table From LEAP - Plant Master Data

# COMMAND ----------

df_plant_master_data = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.plant_description_V2"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Gold Table - Work Order Basics from LEAP
# MAGIC
# MAGIC **df_work_orders** : Gold Table From LEAP - work_order_basic 

# COMMAND ----------

df_work_orders = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.production.sap_work_order_basics_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Import - Gold Table - WIP PE from AVCORP  
# MAGIC **df_wippe_avcorp** : Gold Table From SAP - Work In Progress Details Parts from AVCORP (out SAP)

# COMMAND ----------

if PERIOD == "weekly":
    df_wippe_avcorp = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_wippe_latest"
    )
if PERIOD == "monthly":
    df_wippe_avcorp = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_wippe_monthly"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP Transaction

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Bronze Table  - WIP PE For Perimeter Analytics PA01
# MAGIC **df_wippe_pa01** : Gold Table From SAP - Work In Progress Details Parts

# COMMAND ----------

if PERIOD == "weekly":
    df_wippe_pa01 = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.supply_chain.wippe_1000"
    )
if PERIOD == "monthly":
    table_pa01 = f"{REFERENCE_READ_ENV}_bronze.supply_chain.wippe_1000"
    today = datetime.today()
    month = today.month

    WRITING_OPERATIONS = (
        "WRITE",
        "REPLACE TABLE AS SELECT",
        "COPY INTO",
        "MERGE",
        "CREATE OR REPLACE TABLE AS SELECT",
    )
    # For monthly values, extraction is performed each 2 of the month
    # (to be sure that Additionnal costs have been well calculated)
    version = spark.sql(
        f"SELECT version FROM (SELECT * FROM (DESCRIBE HISTORY {table_pa01}) ORDER BY timestamp DESC) WHERE month(timestamp) == {month} AND day(timestamp) != 1 AND operation IN {WRITING_OPERATIONS} LIMIT 1"
    ).collect()[0][0]

    df_wippe_pa01 = spark.read.table(f"{table_pa01}@v{version}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Bronze Table  - WIP PE For Perimeter Analytics PA20
# MAGIC **df_wippe_pa20** : Gold Table From SAP - Work In Progress Details Parts

# COMMAND ----------

if PERIOD == "weekly":
    df_wippe_pa20 = spark.read.table(
        f"{REFERENCE_READ_ENV}_bronze.supply_chain.wippe_3000"
    )
if PERIOD == "monthly":
    table_pa20 = f"{REFERENCE_READ_ENV}_bronze.supply_chain.wippe_3000"
    today = datetime.today()
    month = today.month

    WRITING_OPERATIONS = (
        "WRITE",
        "REPLACE TABLE AS SELECT",
        "COPY INTO",
        "MERGE",
        "CREATE OR REPLACE TABLE AS SELECT",
    )
    # For monthly values, extraction is performed each 2 of the month
    # (to be sure that Additionnal costs have been well calculated)
    version = spark.sql(
        f"SELECT version FROM (SELECT * FROM (DESCRIBE HISTORY {table_pa20}) ORDER BY timestamp DESC) WHERE month(timestamp) == {month} AND day(timestamp) != 1 AND operation IN {WRITING_OPERATIONS} LIMIT 1"
    ).collect()[0][0]

    df_wippe_pa20 = spark.read.table(f"{table_pa20}@v{version}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Bronze Manual Mapping division site  
# MAGIC **df_bronze_site** Mapping site-division-region  

# COMMAND ----------

df_bronze_site = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region"
)
#----------------------------------------------------------------------------------
df_bronze_site = df_bronze_site.withColumnRenamed("site", "production_site").withColumn(
    "production_site", f.translate("production_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
).distinct()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - External Avcorp

# COMMAND ----------

df_wippe_avcorp = (
    df_wippe_avcorp.withColumn("Division", f.lit("ASAM"))
    .withColumn("Region", f.lit("AMERICAS"))
    .withColumn(("Production_Site"), f.lit("LAC1 - Delta"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation Material Master Data

# COMMAND ----------

# Selection Columns & Renaming headers
df_material_master_selected = df_material_master.select(
    [
        f.col("Plant").alias("plant"),
        f.col("Material_Number").alias("material"),
        f.col("Standard_Price_EUR_Budget").alias("unit_price"),
        f.col("Production_Site").alias("site"),
        f.col("Category").alias("categ"),
    ]
).dropDuplicates()
# -------------------------------------------------------------------
# Cleaning of raw data
df_material_master_end = df_material_master_selected.withColumns(
    {
        "site": f.coalesce(f.col("site"), f.lit("Unknown")),
        "category": f.coalesce(f.col("categ"), f.lit("Unknown")),
        "unit_price": f.regexp_replace("unit_price", ",", ".").cast("double"),
    }
)
# -------------------------------------------------------------------
# Format material base for use in final wip pe
df_material_master_end_process = df_material_master.select(
    [
        f.col("Branch"),
        f.col("Material_Type"),
        f.col("Supplier_Code"),
        f.col("Supplier_Name"),
        f.col("Plant"),
        f.col("Material_Number"),
    ]
)
# -------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation Plant Master Data

# COMMAND ----------

df_plant_master_data = df_plant_master_data.select(
    f.col("Plant_Div").alias("Plant_N"), f.col("Plant_Description_new")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation Work Order Basics

# COMMAND ----------

df_work_orders = df_work_orders.select(
    [
        f.col("WO_Number"),
        f.col("Mrp_Controller"),
    ]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation WIP PE For Perimeter Analytics PA01

# COMMAND ----------

# Selection Columns & Renaming headers
df_wippe_pa01_selected = df_wippe_pa01.select(
    [
        f.col("ProfitCenter").alias("program"),
        f.col("Plnt").alias("plant"),
        f.col("CostObject").alias("ord"),
        f.col("Type").alias("type"),
        f.col("Order").alias("order"),
        f.col("Stat").alias("stat"),
        f.col("MaterialNumber").alias("material"),
        f.col("MaterialDescription").alias("description"),
        f.col("PlanQty").alias("quantity"),
        f.col("Crcy").alias("currency"),
        f.col("WIP").alias("value"),
        f.col("WIPchg").alias("value_modif"),
    ]
).dropDuplicates()
# ---------------------------------------------------------------
# Keep only entries non null & NO ZP11 (WIP ASSY)
# zp11 - Work Orders allocated to a WBS - Need to be out on WIP Details Parts
df_wippe_pa01_filtered = df_wippe_pa01_selected.filter(
    (f.col("type") != "")
    & (f.col("type") != "ZP11")
    & (f.col("type") != "Type")
    & (f.col("plant") != "")
)
# ---------------------------------------------------------------
# Casting Columns with Value
df_wippe_pa01_cast = df_wippe_pa01_filtered.withColumn(
    "quantity",
    f.col("quantity").cast("double"),
)
df_wippe_pa01_clean = cast_sap_float_column(df_wippe_pa01_cast, "value")
df_wippe_pa01_end = cast_sap_float_column(df_wippe_pa01_clean, "value_modif")
# ---------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation WIP PE For Perimeter Analytics PA20

# COMMAND ----------

df_wippe_pa20_selected = df_wippe_pa20.select(
    [
        f.col("ExceProfitCenter").alias("program"),
        f.col("Plnt").alias("plant"),
        f.col("CostObject").alias("ord"),
        f.col("Type").alias("type"),
        f.col("Order").alias("order"),
        f.col("Stat").alias("stat"),
        f.col("MaterialNumber").alias("material"),
        f.col("MaterialDescription").alias("description"),
        f.col("PlanQty").alias("quantity"),
        f.col("Crcy").alias("currency"),
        f.col("WIP").alias("value"),
        f.col("WIPchg").alias("value_modif"),
    ]
).dropDuplicates()
# ---------------------------------------------------------------
# Keep only entries non null & NO ZP11 (WIP ASSY)
# zp11 - Work Orders allocated to a WBS - Need to be out on WIP Details Parts
df_wippe_pa20_filtered = df_wippe_pa20_selected.filter(
    (f.col("type") != "")
    & (f.col("type") != "ZP11")
    & (f.col("type") != "Type")
    & (f.col("plant") != "")
)
# ---------------------------------------------------------------
# Casting Columns with Value
df_wippe_pa20_cast = df_wippe_pa20_filtered.withColumn(
    "quantity",
    f.col("quantity").cast("double"),
)
df_wippe_pa20_clean = cast_sap_float_column(df_wippe_pa20_cast, "value")
df_wippe_pa20_end = cast_sap_float_column(df_wippe_pa20_clean, "value_modif")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 1 - Join WIP Detail Parts with Material Master Data
# MAGIC

# COMMAND ----------

# Calculate wip pe
# Join 2 perimeter analytics PA01 & PA20
df_wippe_all = df_wippe_pa01_end.unionAll(df_wippe_pa20_end)
# Add Material Master Data information
df_join_with_material = df_wippe_all.join(
    df_material_master_end,
    on=["material", "plant"],
    how="left",
)
df_wippe_date = df_join_with_material.withColumn(
    "Current_Date", f.date_add(f.current_date(), -1)
)
# ------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 2 - Apply Correction from Master data Plant & Work orders

# COMMAND ----------

# We need to take in account the MRP Controller from
# the work order, not from the material master data and the Naming of Plant from
# Gold Plant Master Data

df_join_with_mrpc = df_wippe_date.join(
    df_work_orders,
    df_wippe_date.order == df_work_orders.WO_Number,
    how="left",
)
# Add plant value
df_join_with_plant = df_join_with_mrpc.join(
    df_plant_master_data,
    df_join_with_mrpc.plant == df_plant_master_data.Plant_N,
    how="left",
).drop("Plant_N", "WO_Number")
# -------------------------------------------------------------------------
# Determination of production Site
df_wippe_site = df_join_with_plant.withColumn(
    "site",
    f.when(f.col("plant") != "1000", f.col("Plant_Description_new"))
    .when(f.col("MRP_Controller").startswith("O"), f.lit("LATE - Montredon"))
    .when(
        (f.col("program").isin(["BCL", "HAP", "297", "298", "299", "DEW"]))
        | (f.col("MRP_Controller") == "DET")
        | (f.col("program").startswith("V")),
        f.lit("LATE-LFR1 - Labege Systems"),
    )
    .otherwise(f.lit("LATE - Gimont")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 3 - Correction Amount and Conversion to EUR

# COMMAND ----------

# Correction Amount from SAP Decimal Mistake
df_wip_pe_amount = (
    create_corrected_amounts(
        df=df_wippe_site,
        amount_col="value",
        currency_col="currency",
    )
    .drop("value")
    .withColumnRenamed("value_corrected", "value")
)
df_wip_pe_amount = (
    create_corrected_amounts(
        df=df_wip_pe_amount,
        amount_col="value_modif",
        currency_col="currency",
    )
    .drop("value_modif")
    .withColumnRenamed("value_modif_corrected", "value_modif")
)
df_wip_pe_amount = (
    create_corrected_amounts(
        df=df_wip_pe_amount,
        amount_col="unit_price",
        currency_col="currency",
    )
    .drop("unit_price")
    .withColumnRenamed("unit_price_corrected", "unit_price")
)
# ------------------------------------------------------------------------------
# Conversion Amount in EUR Currency (Budget Rate)
df_wip_pe_euros_with_rate = convert_currency(
    df_base=df_wip_pe_amount,
    df_currency=df_Currency_Exchange,
    df_base_source_currency_column_name="currency",
    target_currency_value="EUR",
    df_currency_conversion_rate_type_exp_value="Budget",
    df_base_conversion_date_column_name="Current_Date",
    conversion_output_column_name="Rate",
)

df_wip_pe_euros = df_wip_pe_euros_with_rate.withColumn(
    "valo_wippe", f.col("value") * f.col("Rate")
).withColumn("value_mod_s_minus_1", f.col("value_modif") * f.col("Rate"))
# ------------------------------------------------------------------------------
# Calculate Gap Between Theoritical and Real Values
df_wip_pe_tmp = df_wip_pe_euros.withColumn(
    "theo_value",
    f.coalesce(f.col("quantity") * f.col("unit_price"), f.lit(0)),
).withColumn(
    "gap_price",
    f.coalesce(
        f.when(
            f.col("value") != 0,
            f.col("valo_wippe") - (f.col("quantity") * f.col("unit_price")),
        ).otherwise(0),
        f.lit(0),
    ).cast("double"),
)
# ------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 4 - Selection Headers For Final Dataframe

# COMMAND ----------

# Selection Columns for saving
df_wip_pe_end = df_wip_pe_tmp.select(
    [
        f.col("program").alias("Profit_Center"),
        f.col("plant").alias("Plant"),
        f.col("type").alias("Order_Type"),
        f.col("order").alias("Work_Order"),
        f.col("stat"),
        f.col("material").alias("Material_Number"),
        f.col("description").alias("Description"),
        f.col("quantity"),
        f.col("site").alias("Production_Site"),
        f.col("category").alias("Category"),
        f.col("unit_price"),
        f.col("value_mod_s_minus_1"),
        f.col("valo_wippe"),
        f.col("theo_value"),
        f.col("gap_price"),
        f.col("MRP_Controller"),
    ]
).distinct()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 5 - Add Business Rules and cleaning data

# COMMAND ----------

# Add Material Master Data Information
df_join_wippe_material = df_wip_pe_end.join(
    df_material_master_end_process, on=["Plant", "Material_Number"], how="left"
)
# ------------------------------------------------------------------------------
# Enrichment with Business Rules
df_wippe_full_table = (
    df_join_wippe_material.fillna("", "Description")
    .fillna("ND", "Material_Type")
    .withColumn("MRP_Unit", f.col("Plant"))
    .withColumn("INT/EXT", f.lit("Internal"))
    .withColumn(
        "Supplier_Code",
        f.coalesce(f.col("Supplier_Code"), f.concat(f.lit("INT_"), f.col("Plant"))),
    )
    .withColumn(
        "Supplier_Name",
        f.coalesce(
            f.col("Supplier_Name"),
            f.concat(f.lit("Internal_"), f.col("Plant")),
        ),
    )
)
# # Add Branch information
df_wippe_full_table = df_wippe_full_table.join(df_bronze_site, ["Production_Site"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 6 - Add external WIP PE (out  SAP)

# COMMAND ----------

# Add AVCORP WIP Details Parts
df_wippe_full_table_end = df_wippe_full_table.unionByName(
    df_wippe_avcorp, allowMissingColumns=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 7 - Management Historisation Global Stock

# COMMAND ----------

if PERIOD == "weekly":
    df_wippe_weekly = add_weekly_evol_dates(df_wippe_full_table_end)
    df_wippe_weekly = df_wippe_weekly.drop(
        "observation_date_related_sunday", "load_date"
    )

    df_history_w = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued.wip_pe_weekly_history"
    )
    id_w = df_wippe_weekly.select("observation_week").collect()[0][0]
    df_history_w_filter = df_history_w.filter(f.col("observation_week") != id_w)
    df_wippe_weekly_end = df_history_w_filter.unionByName(
        df_wippe_weekly, allowMissingColumns=True
    )
    # Creation ranking for PBI
    w0 = Window.orderBy(f.desc(f.col("observation_week")))
    df_wippe_weekly_end = df_wippe_weekly_end.withColumn(
        "observation_week_rank", f.dense_rank().over(w0)
    )

if PERIOD == "monthly":
    df_wippe_monthly = add_monthly_evol_dates(df_wippe_full_table_end)
    df_wippe_monthly = df_wippe_monthly.drop("load_date")

    df_history_m = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued.wip_pe_monthly_history"
    )
    id_m = df_wippe_monthly.select("observation_month").collect()[0][0]
    df_history_m_filter = df_history_m.filter(f.col("observation_month") != id_m)
    df_wippe_monthly_end = df_history_m_filter.unionByName(
        df_wippe_monthly, allowMissingColumns=True
    )
    # Creation ranking or PBI
    w1 = Window.orderBy(f.desc(f.col("observation_month")))
    df_wippe_monthly_end = df_wippe_monthly_end.withColumn(
        "observation_month_rank", f.dense_rank().over(w1)
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold Table - Work In Progress Details Parts
# MAGIC
# MAGIC Saving of WIPPE Valued- This represents the enriched LATECOERE SAP ECC6 Global WIP PE Latest /Weekly / Monthly.  

# COMMAND ----------

Wippe_Latest_path = f"{PIPELINE_WRITE_ENV}_gold.inventory_valued.wip_pe_weekly_latest"
save_table(
    dest_table=Wippe_Latest_path,
    df=df_wippe_full_table_end,
    mode="overwrite",
    overwrite_schema=True,
)
# -----------------------------------------------------------------------------------------------------
# Saving weekly historisation
if PERIOD == "weekly":
    Wippe_Weekly_path = (
        f"{PIPELINE_WRITE_ENV}_gold.inventory_valued.wip_pe_weekly_history"
    )
    save_table(
        dest_table=Wippe_Weekly_path,
        df=df_wippe_weekly_end,
        mode="overwrite",
        overwrite_schema=True,
    )
# -----------------------------------------------------------------------------------------------------
# Saving Monthly historisation
if PERIOD == "monthly":
    Wippe_Monthly_path = (
        f"{PIPELINE_WRITE_ENV}_gold.inventory_valued.wip_pe_monthly_history"
    )
    save_table(
        dest_table=Wippe_Monthly_path,
        df=df_wippe_monthly_end,
        mode="overwrite",
        overwrite_schema=True,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
