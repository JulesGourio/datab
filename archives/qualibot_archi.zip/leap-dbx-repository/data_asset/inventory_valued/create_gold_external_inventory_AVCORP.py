# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create 3 gold table for External Inventory for company out of SAP specific to AVCORP Company
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_stock_on_hand_valued_latest
# MAGIC   - {PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_wippe_latest
# MAGIC   - {PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_wipassy_latest
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - {PIPELINE_READ_ENV}_bronze.baan_lac.inventorylevel_latest"
# MAGIC   - {PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_provisions_latest 
# MAGIC   
# MAGIC **Triggered by:**  
# MAGIC   - Ingestion
# MAGIC
# MAGIC **Performed in this notebook:** 
# MAGIC   - Extract Sheets 'Inventory'  
# MAGIC   - Calcul ProvInventory out of SAP
# MAGIC   - Save Gold Table

# COMMAND ----------

# MAGIC %md
# MAGIC **Python dependencies needed**
# MAGIC
# MAGIC `%pip install fsspec s3fs openpyxl`

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from leap_utils.data_asset.table_utils import save_table, currency_conversion
from pyspark.sql.window import Window
from leap_utils.data_asset.historisation import (
    add_weekly_evol_dates,add_monthly_evol_dates,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("init_latest", "false")
INIT_LATEST = dbutils.widgets.get("init_latest").lower() == "true"

dbutils.widgets.text("period", "weekly")
PERIOD = dbutils.widgets.get("period").lower()

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze Table AVCORP - Inventory

# COMMAND ----------

if PERIOD == "weekly":
    df_avcorp_read = spark.read.table(
        f"{PIPELINE_READ_ENV}_bronze.baan_lac.inventorylevel_latest"
    )
if PERIOD == "monthly":
    df_avcorp_read = spark.read.table(
        f"{PIPELINE_READ_ENV}_bronze.baan_lac.inventorylevelmonthly_latest"
    )    
# Cleaning Data
df_avcorp_read = df_avcorp_read.withColumn(
    "WAREHOUSE", f.trim(f.col("WAREHOUSE"))
).withColumn("SKU", f.trim(f.col("SKU"))).withColumn("ITEM_NO", f.trim(f.col("ITEM_NO")))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Table AVCORP - Inventory Provisions

# COMMAND ----------

df_avcorp_prov = spark.read.table(f"{PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_provisions_latest")
# Cleaning Data
df_avcorp_prov = df_avcorp_prov.withColumn(
    "WAREHOUSE", f.trim(f.col("WAREHOUSE"))
).withColumn("Material_Number", f.trim(f.col("Material_Number")))

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr 1 - AVCORP - Renaming Headers

# COMMAND ----------

df_avcorp_renamed = df_avcorp_read.withColumnsRenamed(
    {
        "DESCRIPTION": "Description",
        "UOM": "Unit_Base",
        "ITEM_GRP": "Profit_Center",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr 2 - AVCORP - Management Currency Conversion

# COMMAND ----------

# Management WIP and Stock on Hand Value
df_avcorp_clean = df_avcorp_renamed.withColumn(
    "QUANTITY",
    f.when(f.col("WAREHOUSE").contains("ACTIVE"), f.lit(1)).otherwise(
        f.col("QUANTITY")
    ),
)
df_avcorp_clean = df_avcorp_clean.withColumn(
    "AVERAGE_COST",
    f.when(f.col("WAREHOUSE").contains("ACTIVE"), f.col("TOTAL")).otherwise(
        f.col("AVERAGE_COST")
    ),
)
# -------------------------------------------------------------------------------
# Creation Reference day for conversion
df_avcorp_date = df_avcorp_clean.withColumn(
    "Upload_Date", f.date_add(f.current_date(), -1)
)
# Leap Function to convert currency
df_avcorp_conversion_rate = currency_conversion(
    df=df_avcorp_date,
    document_currency_column=f.col("CURRENCY"),
    rate_types=["Budget"],
    rate_dates=[f.col("Upload_Date")],
    target_currency_value="EUR",
    document_amounts=[f.col("AVERAGE_COST")],
)
# -------------------------------------------------------------------------------
# Rename Output Column from function
df_avcorp_conversion = df_avcorp_conversion_rate.withColumnRenamed(
    "AVERAGE_COST_from_CURRENCY_to_EUR_in_Budget_rate_at_Upload_Date",
    "Standard_Price_EUR_Budget",
).drop(
    "CURRENCY_to_EUR_in_Budget_rate_at_Upload_Date", "CURRENCY", "AVERAGE_COST", "TOTAL"
)
# -------------------------------------------------------------------------------
# As we don't received information from AvCorp Average = Standard Price
df_avcorp_price = df_avcorp_conversion.withColumn(
    "Average_Price_EUR_Budget", f.col("Standard_Price_EUR_Budget")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr 3 - AVCORP - Add General Information (Branch,Plant)

# COMMAND ----------

# -------------------------------------------------------------------------------
# Add branch / plant information
# Specific Stock 080 / 099 are deported stock from LMX-C 
df_avcorp_inform = (
    df_avcorp_price.withColumn(
        "Plant",
        f.when(
            (f.col("WAREHOUSE") == "O80") | (f.col("WAREHOUSE") == "O99"),
            f.lit("4020"),
        ).otherwise(f.lit("6000")),
    )
    .withColumn(
        "Stock_Site",
        f.when(
            (f.col("WAREHOUSE") == "O80") | (f.col("WAREHOUSE") == "O99"),
            f.lit("LMX-C"),
        ).otherwise(f.lit("LAC-Delta")),
    )
    .withColumn(
        "MRP_Unit",
        f.when(
            (f.col("WAREHOUSE") == "O80") | (f.col("WAREHOUSE") == "O99"),
            f.lit("4020"),
        ).otherwise(f.lit("6000")),
    )
    .withColumn("Branch", f.lit("AS-AMERICAS"))
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr 4 - AVCORP - Dispatch Stock on Hand, WIP PE and WIP ASSY

# COMMAND ----------

# Specific Rules For Program P24700 & P24710 discount Inventory
# Exclusion Specific programs
prog_spec = ["P24700", "P24710"]
df_avcorp_stock_program = df_avcorp_inform.filter(
    ~f.col("Profit_Center").isin(prog_spec)
)
# Creation Dataframe for Stock on Hand
df_avcorp_stock_on_hand = df_avcorp_stock_program.filter(f.col("SKU")==f.col("ITEM_NO"))
# Creation Dataframe for WIPPE
df_avcorp_wippe = df_avcorp_stock_program.filter(f.col("WAREHOUSE")=="ACTIVE WIP")
# Creation Dataframe for WIPASSY
df_avcorp_wipassy = df_avcorp_stock_program.filter(f.col("WAREHOUSE")=="ACTIVE PRJ WIP")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr 5 - AVCORP - Stock on Hand Valued

# COMMAND ----------

# Group By Material Number
df_avcorp_stk_grouped = df_avcorp_stock_on_hand.groupBy(
    [
        "SKU",
        "Description",
        "Branch",
        "Plant",
        "MRP_Unit",
        "Stock_Site",
        "Average_Price_EUR_Budget",
        "Standard_Price_EUR_Budget",
        "WAREHOUSE",
        "Profit_Center",
    ]
).agg(f.sum(f.col("QUANTITY")).alias("Stock_On_Hand"))
df_avcorp_stk_renamed = df_avcorp_stk_grouped.withColumnRenamed(
    "SKU", "Material_Number"
)
# -------------------------------------------------------------------------------
# Valorisation Stock on Hand
df_avcorp_stk_valued = df_avcorp_stk_renamed.withColumn(
    "Standard_Stock_On_Hand_Price",
    f.col("Stock_On_Hand") * f.col("Standard_Price_EUR_Budget"),
).withColumn(
    "Average_Stock_On_Hand_Price",
    f.col("Stock_On_Hand") * f.col("Average_Price_EUR_Budget"),
)
# -------------------------------------------------------------------------------
# Management provisions
# Join with Provision Stock on hand
df_avcorp_prov_stk = df_avcorp_prov.filter(f.col("Work_Order").isNull())
df_avcorp_prov_selected = df_avcorp_prov_stk.select(
    "Material_Number",
    "WAREHOUSE",
    "Provision",
    "Average_Price_Provision",
    "Standard_Price_Provision",
)
df_join_avcorp = df_avcorp_stk_valued.join(
    df_avcorp_prov_selected, ["Material_Number", "WAREHOUSE"], "left"
)
df_join_avcorp = df_join_avcorp.fillna({"Standard_Price_Provision": 0})
df_join_avcorp = df_join_avcorp.fillna({"Average_Price_Provision": 0})

# Check provision not upper real stock and change sign
df_avcorp_check_prov = df_join_avcorp.withColumn(
    "Average_Price_Provision",
    f.when(
        f.col("Average_Price_Provision") > f.col("Average_Stock_On_Hand_Price"),
        (-1 * f.col("Average_Stock_On_Hand_Price")),
    ).otherwise(-1 * f.col("Average_Price_Provision")),
)

df_avcorp_stock_on_hand_end = df_avcorp_check_prov.withColumn(
    "Standard_Price_Provision",
    f.when(
        f.col("Standard_Price_Provision") > f.col("Standard_Stock_On_Hand_Price"),
        (-1 * f.col("Standard_Stock_On_Hand_Price")),
    ).otherwise(-1 * f.col("Standard_Price_Provision")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr 6 - AVCORP - WIP PE 

# COMMAND ----------

df_avcorp_wippe_renamed = df_avcorp_wippe.withColumnsRenamed(
    {"SKU": "Work_Order", "ITEM_NO": "Material_Number"}
)
# -------------------------------------------------------------------------------
# Valorisation WIP PE
df_wippe_avcorp_valued = df_avcorp_wippe_renamed.withColumn(
    "valo_wippe", f.col("Standard_Price_EUR_Budget")
)
# -------------------------------------------------------------------------------
# Management provisions
# Join with Provision WIPPE
df_avcorp_prov_wip = df_avcorp_prov.filter(f.col("Work_Order").isNotNull())
df_avcorp_prov_selected = df_avcorp_prov_wip.select(
    "Work_Order",
    "Standard_Price_Provision",
)
df_join_wippe_avcorp = df_wippe_avcorp_valued.join(
    df_avcorp_prov_selected, ["Work_Order"], "left"
)
df_join_wippe_avcorp = df_join_wippe_avcorp.fillna({"Standard_Price_Provision": 0})
df_join_wippe_avcorp = df_join_wippe_avcorp.withColumn("Standard_Price_Provision",( f.col("Standard_Price_Provision")*-1 ))

# -------------------------------------------------------------------------------
# Select columns for  
df_wippe_avcorp_end = df_join_wippe_avcorp.select(
    f.col("Work_Order"),
    f.col("Material_Number"),
    f.col("Description"),
    f.col("QUANTITY").alias("quantity"),
    f.col("Profit_Center"),
    f.col("Branch"),
    f.col("Plant"),
    f.col("Stock_Site"),
    f.col("valo_wippe"),
    f.col("Standard_Price_Provision"),
    f.col("MRP_Unit"),
)
# Add Columns for append with WiP PE SAP
df_wippe_avcorp_end = (
    df_wippe_avcorp_end.withColumn("Supplier_Code", f.lit("INT_6000"))
    .withColumn("Supplier_Name", f.lit("INTERNAL_6000"))
    .withColumn("INT/EXT", f.lit("Internal"))
    .withColumn("Category", f.lit("AVCORP_WIP"))
    .withColumn("Production_Site", f.col("Stock_Site"))
).drop("Stock_Site")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr 7 - AVCORP - WIP ASSY 

# COMMAND ----------

# Renamed and Select for append with SAP WIP ASSY
df_wipassy_avcorp_end = df_avcorp_wipassy.select(
    f.col("SKU").alias("wbs"),
    f.col("ITEM_NO").alias("Material_Number"),
    f.col("Description"),
    f.col("Standard_Price_EUR_Budget").alias("wip_assy"),
    f.col("Profit_Center"),
    f.col("Branch"),
    f.col("Plant"),
    f.col("Stock_Site"),
    f.col("MRP_Unit"),
)
# Add Columns for append with Wip Assy SAP
df_wipassy_avcorp_end = (
    df_wipassy_avcorp_end.withColumn("Supplier_Code", f.lit("INT_6000"))
    .withColumn("Supplier_Name", f.lit("INTERNAL_6000"))
    .withColumn("INT/EXT", f.lit("Internal"))
    .withColumn("Category", f.lit("AVCORP_WIP"))
    .withColumn("Production_Site", f.col("Stock_Site"))
).drop("Stock_Site")
# Specific Rules For Program P24700 & P24710 discount Inventory
# Exclusion Specific programs
df_wipassy_avcorp_end = df_wipassy_avcorp_end.filter(
    ~f.col("Profit_Center").isin(prog_spec)
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Save Gold Table AVCORP -STOCK ON HAND

# COMMAND ----------

if PERIOD == "weekly":
    STOCK_PATH = f"{PIPELINE_WRITE_ENV}_gold.inventory_valued_external.avcorp_stock_on_hand_valued_latest"
    save_table(dest_table=STOCK_PATH, df=df_avcorp_stock_on_hand_end, mode="overwrite")

    # Management historisation
    df_avcorp_stock_on_hand_end = add_weekly_evol_dates(df_avcorp_stock_on_hand_end)
    df_avcorp_stock_on_hand_end = df_avcorp_stock_on_hand_end.drop(
        "observation_date_related_sunday", "load_date"
    )
    df_history_w = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_stock_on_hand_valued_history"
    )
    id_w = df_avcorp_stock_on_hand_end.select("observation_week").collect()[0][0]
    df_history_w_filter = df_history_w.filter(f.col("observation_week") != id_w)
    df_avcorp_stock_on_hand_end = df_history_w_filter.unionByName(
        df_avcorp_stock_on_hand_end, allowMissingColumns=True
    )
    # Creation ranking for PBI
    w0 = Window.orderBy(f.desc(f.col("observation_week")))
    df_avcorp_stock_on_hand_end_h = df_avcorp_stock_on_hand_end.withColumn(
        "observation_week_rank", f.dense_rank().over(w0)
    )
    STOCK_PATH_WEEKLY = f"{PIPELINE_WRITE_ENV}_gold.inventory_valued_external.avcorp_stock_on_hand_valued_history"
    save_table(dest_table=STOCK_PATH_WEEKLY, df=df_avcorp_stock_on_hand_end_h, mode="overwrite")

if PERIOD == "monthly":
    STOCK_PATH = f"{PIPELINE_WRITE_ENV}_gold.inventory_valued_external.avcorp_stock_on_hand_valued_monthly"
    save_table(dest_table=STOCK_PATH, df=df_avcorp_stock_on_hand_end, mode="overwrite")

    # Management historisation
    df_avcorp_stock_on_hand_end = add_monthly_evol_dates(df_avcorp_stock_on_hand_end)
    df_avcorp_stock_on_hand_end = df_avcorp_stock_on_hand_end.drop(
        "observation_date_related_sunday", "load_date"
    )
    df_history_w = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_stock_on_hand_valued_monthly_history"
    )
    id_w = df_avcorp_stock_on_hand_end.select("observation_month").collect()[0][0]
    df_history_w_filter = df_history_w.filter(f.col("observation_month") != id_w)
    df_avcorp_stock_on_hand_end = df_history_w_filter.unionByName(
        df_avcorp_stock_on_hand_end, allowMissingColumns=True
    )
    # Creation ranking for PBI
    w0 = Window.orderBy(f.desc(f.col("observation_month")))
    df_avcorp_stock_on_hand_end_h = df_avcorp_stock_on_hand_end.withColumn(
        "observation_month_rank", f.dense_rank().over(w0)
    )
    STOCK_PATH_WEEKLY = f"{PIPELINE_WRITE_ENV}_gold.inventory_valued_external.avcorp_stock_on_hand_valued_monthly_history"
    save_table(dest_table=STOCK_PATH_WEEKLY, df=df_avcorp_stock_on_hand_end_h, mode="overwrite")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Save Gold Table AVCORP - WIP PE

# COMMAND ----------

if PERIOD == "weekly":
    STOCK_PATH_WIPPE= f"{PIPELINE_WRITE_ENV}_gold.inventory_valued_external.avcorp_wippe_latest"
    save_table(dest_table=STOCK_PATH_WIPPE, df=df_wippe_avcorp_end, mode="overwrite")

    # Management historisation
    df_wippe_avcorp_end = add_weekly_evol_dates(df_wippe_avcorp_end)
    df_wippe_avcorp_end = df_wippe_avcorp_end.drop(
        "observation_date_related_sunday", "load_date"
    )
    df_history_w = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_wippe_history"
    )
    id_w = df_wippe_avcorp_end.select("observation_week").collect()[0][0]
    df_history_w_filter = df_history_w.filter(f.col("observation_week") != id_w)
    df_wippe_avcorp_end = df_history_w_filter.unionByName(
        df_wippe_avcorp_end, allowMissingColumns=True
    )
    # Creation ranking for PBI
    w0 = Window.orderBy(f.desc(f.col("observation_week")))
    df_wippe_avcorp_end_h = df_wippe_avcorp_end.withColumn(
        "observation_week_rank", f.dense_rank().over(w0)
    )
    STOCK_PATH_WIPPE_WEEKLY= f"{PIPELINE_WRITE_ENV}_gold.inventory_valued_external.avcorp_wippe_history"
    save_table(dest_table=STOCK_PATH_WIPPE_WEEKLY, df=df_wippe_avcorp_end_h, mode="overwrite")

if PERIOD == "monthly":
    STOCK_PATH_WIPPE= f"{PIPELINE_WRITE_ENV}_gold.inventory_valued_external.avcorp_wippe_monthly"
    save_table(dest_table=STOCK_PATH_WIPPE, df=df_wippe_avcorp_end, mode="overwrite")

    # Management historisation
    df_wippe_avcorp_end = add_monthly_evol_dates(df_wippe_avcorp_end)
    df_wippe_avcorp_end = df_wippe_avcorp_end.drop(
        "observation_date_related_sunday", "load_date"
    )
    df_history_w = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_wippe_monthly_history"
    )
    id_w = df_wippe_avcorp_end.select("observation_month").collect()[0][0]
    df_history_w_filter = df_history_w.filter(f.col("observation_month") != id_w)
    df_wippe_avcorp_end = df_history_w_filter.unionByName(
        df_wippe_avcorp_end, allowMissingColumns=True
    )
    # Creation ranking for PBI
    w0 = Window.orderBy(f.desc(f.col("observation_month")))
    df_wippe_avcorp_end_h = df_wippe_avcorp_end.withColumn(
        "observation_month_rank", f.dense_rank().over(w0)
    )
    STOCK_PATH_WIPPE_WEEKLY= f"{PIPELINE_WRITE_ENV}_gold.inventory_valued_external.avcorp_wippe_monthly_history"
    save_table(dest_table=STOCK_PATH_WIPPE_WEEKLY, df=df_wippe_avcorp_end_h, mode="overwrite")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Save Gold Table AVCORP - WIP ASSY

# COMMAND ----------

if PERIOD == "weekly":   
    STOCK_PATH_WIPASSY = f"{PIPELINE_WRITE_ENV}_gold.inventory_valued_external.avcorp_wipassy_latest"
    save_table(dest_table=STOCK_PATH_WIPASSY, df=df_wipassy_avcorp_end, mode="overwrite")
    # Management historisation
    df_wipassy_avcorp_end = add_weekly_evol_dates(df_wipassy_avcorp_end)
    df_wipassy_avcorp_end = df_wipassy_avcorp_end.drop(
        "observation_date_related_sunday", "load_date"
    )
    df_history_w = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_wipassy_history"
    )
    id_w = df_wipassy_avcorp_end.select("observation_week").collect()[0][0]
    df_history_w_filter = df_history_w.filter(f.col("observation_week") != id_w)
    df_wipassy_avcorp_end = df_history_w_filter.unionByName(
        df_wipassy_avcorp_end, allowMissingColumns=True
    )
    # Creation ranking for PBI
    w0 = Window.orderBy(f.desc(f.col("observation_week")))
    df_wipassy_avcorp_end_h = df_wipassy_avcorp_end.withColumn(
        "observation_week_rank", f.dense_rank().over(w0)
    )
    STOCK_PATH_WIPASSY_WEEKLY = f"{PIPELINE_WRITE_ENV}_gold.inventory_valued_external.avcorp_wipassy_history"
    save_table(dest_table=STOCK_PATH_WIPASSY_WEEKLY, df=df_wipassy_avcorp_end_h, mode="overwrite")

if PERIOD == "monthly":
    STOCK_PATH_WIPASSY = f"{PIPELINE_WRITE_ENV}_gold.inventory_valued_external.avcorp_wipassy_monthly"
    save_table(dest_table=STOCK_PATH_WIPASSY, df=df_wipassy_avcorp_end, mode="overwrite")

    # Management historisation
    df_wipassy_avcorp_end = add_monthly_evol_dates(df_wipassy_avcorp_end)
    df_wipassy_avcorp_end = df_wipassy_avcorp_end.drop(
        "observation_date_related_sunday", "load_date"
    )
    df_history_w = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued_external.avcorp_wipassy_monthly_history"
    )
    id_w = df_wipassy_avcorp_end.select("observation_month").collect()[0][0]
    df_history_w_filter = df_history_w.filter(f.col("observation_month") != id_w)
    df_wipassy_avcorp_end = df_history_w_filter.unionByName(
        df_wipassy_avcorp_end, allowMissingColumns=True
    )
    # Creation ranking for PBI
    w0 = Window.orderBy(f.desc(f.col("observation_month")))
    df_wipassy_avcorp_end_h = df_wipassy_avcorp_end.withColumn(
        "observation_month_rank", f.dense_rank().over(w0)
    )
    STOCK_PATH_WIPASSY_WEEKLY = f"{PIPELINE_WRITE_ENV}_gold.inventory_valued_external.avcorp_wipassy_monthly_history"
    save_table(dest_table=STOCK_PATH_WIPASSY_WEEKLY, df=df_wipassy_avcorp_end_h, mode="overwrite")
