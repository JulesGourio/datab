# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # [GLOBAL STOCK - VALUED]
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim of this notebook is to create a data asset for stock valued by & plant
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - N/A  
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Build for Use Case 2 - Inventory  
# MAGIC
# MAGIC **Input Tables Pipeline**  
# MAGIC - {PIPELINE_READ_ENV}_gold.inventory_valued.stock_on_hand_valued   
# MAGIC - {PIPELINE_READ_ENV}_gold.inventory_valued.sap_provision_latest  
# MAGIC - {PIPELINE_READ_ENV}_gold.inventory_valued.wip_assy_weekly_latest      
# MAGIC - {PIPELINE_READ_ENV}_gold.inventory_valued.wip_pe_weekly_latest   
# MAGIC - {PIPELINE_READ_ENV}_gold.master_data.material_master_data_plant
# MAGIC - {PIPELINE_READ_ENV}_gold.inventory_valued.external_global_stock_valued_latest
# MAGIC
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - N/A  
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.inventory_valued.global_stock_valued_weekly_latest  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.inventory_valued.global_stock_valued_weekly_history  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.inventory_valued.global_stock_valued_monthly_history  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import DataFrame, functions as f
from pyspark.sql.window import Window
from databricks.sdk.runtime import dbutils
from typing import Tuple
from datetime import datetime

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports  
# MAGIC
# MAGIC - **Save_Table** required for saving Table on DBX

# COMMAND ----------

from leap_utils.data_asset.historisation import (
    add_monthly_evol_dates,
    add_weekly_evol_dates,
)
from leap_utils.data_asset.table_utils import save_table

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).
# MAGIC - PERIOD -> Used for specifying period (weekly or monthly) on the notebook run.  
# MAGIC - INIT_WITH_LATEST -> Used for first run of notebook (initialisation)

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("period", "weekly")
PERIOD = dbutils.widgets.get("period").lower()

dbutils.widgets.text("init_with_latest", "false")
INIT_WITH_LATEST = dbutils.widgets.get("init_with_latest").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Min Date to consider parameter

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Gold Table Material
# MAGIC **df_master_material** : Gold Table From LEAP 

# COMMAND ----------

df_master_material = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Gold Table Stock On Hand Valued
# MAGIC **df_stockvalued** : Gold Table From LEAP - Stock On Hand Valued by Material/Plant

# COMMAND ----------

if PERIOD == "weekly":
    df_stockvalued = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued.stock_on_hand_valued"
    )
if PERIOD == "monthly":
    df_stockvalued = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued.stock_on_hand_valued_monthly"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Gold Table WIPPE
# MAGIC
# MAGIC **df_wip_pe** : Gold Table From LEAP - Work In Progress Detail Parts

# COMMAND ----------

if PERIOD == "weekly":
    df_wip_pe = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued.wip_pe_weekly_history"
    )
    df_wip_pe = df_wip_pe.filter(f.col("observation_week_rank") == 1)
if PERIOD == "monthly":
    df_wip_pe = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued.wip_pe_monthly_history"
    )
    df_wip_pe = df_wip_pe.filter(f.col("observation_month_rank") == 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Gold Table WIPASSY
# MAGIC
# MAGIC **df_wip_assy** : Gold Table From LEAP - Work In Progress Assembly Parts

# COMMAND ----------

if PERIOD == "weekly":
    df_wip_assy = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued.wip_assy_weekly_history"
    )
    df_wip_assy = df_wip_assy.filter(f.col("observation_week_rank") == 1)
if PERIOD == "monthly":
    df_wip_assy = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued.wip_assy_monthly_history"
    )
    df_wip_assy = df_wip_assy.filter(f.col("observation_month_rank") == 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - Gold Table External Inventory
# MAGIC
# MAGIC **df_external_sap_inventory** : Gold Table From LEAP - Inventory out of SAP

# COMMAND ----------

df_external_sap_inventory = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.inventory_valued.external_global_stock_valued_latest"
)
df_external_sap_inventory = (
    df_external_sap_inventory.withColumn(
        "Stock_Site",
        f.when(f.col("Stock_Site") == "LATE IS G. GROVES", f.lit("LUS1 - Los Alamitos"))
        .when(f.col("Stock_Site") == "LATE IS REDMOND", f.lit("LUS1 - Redmond"))
        .otherwise(f.col("Stock_Site")),
    )
    .withColumn("division", f.lit("SPS"))
    .withColumn("region", f.lit("SPS"))
    .drop("Branch", "Plant_Description", "Unit_Base")
    .withColumnRenamed("Material_Description", "Description")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 1 - Stock On Hand Treatment
# MAGIC Agreggate value at Material/Plant Level

# COMMAND ----------

group_names = [
    "Plant",
    "Material_Number",
    "MRP_Unit",
    "Standard_Price_EUR_Budget",
    "Average_Price_EUR_Budget",
    "region",
    "division",
    "Stock_Site",
    "Profit_Center",
    "material_description",
    "Supplier_Name",
    "MRP_Controller",
    "Material_Type",
    "Supplier_Code",
    "Procurement_Type",
    "INT/EXT",
    "Net_Needs",
    "Total_Needs",
]
df_stockvalued_grouped = df_stockvalued.groupBy(
    group_names,
).agg(
    f.sum("Stock_On_Hand").alias("Stock_On_Hand"),
    f.sum("Transit_Stock").alias("Transit_Stock"),
    f.sum("VMI").alias("VMI"),
    f.sum("Standard_Stock_On_Hand_Price").alias("Standard_Stock_On_Hand_Price"),
    f.sum("Average_Stock_On_Hand_Price").alias("Average_Stock_On_Hand_Price"),
    f.sum("Standard_Price_Provision").alias("Standard_Price_Provision"),
    f.sum("Average_Price_Provision").alias("Average_Price_Provision"),
    f.sum("Standard_Transit_Stock_Price").alias("Standard_Transit_Stock_Price"),
    f.sum("Average_Transit_Stock_Price").alias("Average_Transit_Stock_Price"),
    f.sum("Standard_VMI_Price").alias("Standard_VMI_Price"),
    f.sum("Average_VMI_Price").alias("Average_VMI_Price"),
    f.sum("Provision").alias("Provision"),
).withColumnRenamed("material_description", "Description")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 2 - WIP ASSY Treatment
# MAGIC Agreggate value at Material/Plant Level

# COMMAND ----------

# Casting Double Wip Assy
df_wip_assy_cast = df_wip_assy.withColumn("wip_assy", f.col("wip_assy").cast("double"))
group_names = [
    "Material_Number",
    "Plant",
    "Production_Site",
    "Profit_Center",
    "region",
    "division"
]
df_wip_assy_grouped = df_wip_assy.groupBy(
    group_names,
).agg(f.sum("wip_assy").alias("wip_assy"))
df_wip_assy_end = df_wip_assy_grouped.join(
    df_wip_assy.dropDuplicates(group_names).drop("wip_assy"),
    on=group_names,
    how="left",
).withColumnRenamed("Production_Site", "Stock_Site")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 3 - WIP PE Treatment
# MAGIC Agreggate value at Material/Plant Level

# COMMAND ----------

# Casting Double Wip PE
df_wip_pe_cast = df_wip_pe.withColumn("valo_wippe", f.col("valo_wippe").cast("double"))
# --------------------------------------------------------------------
group_names = [
    "Material_Number",
    "Plant",
    "Production_Site",
    "Profit_Center",
    "Category",
    "region",
    "division"
]

df_wip_pe_grouped = df_wip_pe.groupBy(
    group_names,
).agg(
    f.sum("valo_wippe").alias("wip_pe"),
    f.sum("Standard_Price_Provision").alias("Standard_Price_Provision_WIP"),
)

df_wip_pe_end = df_wip_pe_grouped.join(
    df_wip_pe.dropDuplicates(group_names), on=group_names, how="left"
).withColumnRenamed("Production_Site", "Stock_Site")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 4 - Join all Stock Table

# COMMAND ----------

# Join : Add WIP PE and WIP ASSY to Global Stock
df_join_wip = df_stockvalued_grouped.join(
    df_wip_pe_end.select(
        ["Material_Number", "Stock_Site", "wip_pe", "Standard_Price_Provision_WIP"]
    ),
    on=["Material_Number", "Stock_Site"],
    how="left",
).join(
    df_wip_assy_end.select(["Material_Number", "Stock_Site", "wip_assy"]),
    on=["Stock_Site", "Material_Number"],
    how="left",
)
# Sum Provision from WIPPE to Stock on Hand
# Provision On wip are only managed in standard price
df_join_wip = df_join_wip.fillna({"Standard_Price_Provision_WIP": 0})
df_join_wip = df_join_wip.withColumn(
    "Standard_Price_Provision",
    f.col("Standard_Price_Provision") + f.col("Standard_Price_Provision_WIP"),
)
df_join_wip = df_join_wip.withColumn(
    "Average_Price_Provision",
    f.col("Average_Price_Provision") + f.col("Standard_Price_Provision_WIP"),
).drop("Standard_Price_Provision_WIP")

# ------------------------------------------------------------------
# Add Rows from WIP ASSY & WIP PE not Found in Stock on Hand dataframe
columns_for_wip_pe = [
    col for col in df_wip_pe_end.columns if col in df_join_wip.columns
]
df_wip_pe_to_stack = df_wip_pe_end.select(columns_for_wip_pe).join(
    df_join_wip.select(["Stock_Site", "Material_Number"]),
    on=["Stock_Site", "Material_Number"],
    how="anti",
)

columns_for_wip_assy = [
    col for col in df_wip_assy_end.columns if col in df_join_wip.columns
]
df_wip_assy_to_stack = df_wip_assy_end.select(columns_for_wip_assy).join(
    df_join_wip.select(["Stock_Site", "Material_Number"]),
    on=["Stock_Site", "Material_Number"],
    how="anti",
)

df_full_table = df_join_wip.unionByName(
    df_wip_pe_to_stack, allowMissingColumns=True
).unionByName(df_wip_assy_to_stack, allowMissingColumns=True)
# ------------------------------------------------------------------

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC ### Tr. 4 - Add Affectation
# MAGIC

# COMMAND ----------

# Pre Traitement data
df_master_material_filtered = (
    df_master_material.select(
        "Material_Number", 
        "Plant", 
        "PF_pourcentage_affectation", 
        "MRP_Unit", 
        "Assy_Final", 
        "Buyer", 
    )
    .withColumnRenamed("Material_Number", "Material_Number_master")
    .withColumnRenamed("Plant", "Plant_master")
    .withColumnRenamed("MRP_Unit", "MRP_Unit_master")
)

# Join Affectation with full_table
df_PF_affectation = df_full_table.join(
    df_master_material_filtered,
    (
        df_full_table["Material_Number"]
        == df_master_material_filtered["Material_Number_master"]
    )
    & (df_full_table["Plant"] == df_master_material_filtered["Plant_master"])
    & (df_full_table["MRP_Unit"] == df_master_material_filtered["MRP_Unit_master"]),
    "left",
).repartition("Material_Number", "Plant", "MRP_Unit")

# Seperate data with stock and without
df_stock_on_hand_null = df_PF_affectation.filter(f.col("Stock_On_Hand").isNull())
df_stock_on_hand = df_PF_affectation.filter(f.col("Stock_On_Hand").isNotNull())

# # Explode dictionnary
df_precise_affectation_explode = df_stock_on_hand.select(
    f.col("*"),
    f.explode_outer(f.col("PF_pourcentage_affectation")).alias(
        "Profit_Center_Affectation", "Profit_Center_Affectation_pourcentage"
    ),
)
df_precise_affectation = df_precise_affectation_explode.withColumn(
    "Profit_Center_Affectation_pourcentage",
    f.when(f.col("Profit_Center_Affectation_pourcentage").isNull(), f.lit(1)).otherwise(
        f.col("Profit_Center_Affectation_pourcentage")
    ),
)

# # Re compute datas with new affectation
columns_to_update = [
    "wip_pe",
    "wip_assy",
    "Stock_On_Hand",
    "Transit_Stock",
    "Provision",
    "Net_Needs",
    "Total_Needs",
    "VMI",
    "Standard_Stock_On_Hand_Price",
    "Average_Stock_On_Hand_Price",
    "Standard_Transit_Stock_Price",
    "Average_Transit_Stock_Price",
    "Standard_VMI_Price",
    "Average_VMI_Price",
    "Standard_Price_Provision",
    "Average_Price_Provision",
]
for column in columns_to_update:
    df_precise_affectation = df_precise_affectation.withColumn(
        column,
        f.when(
            f.col("Profit_Center_Affectation_pourcentage").isNotNull(),
            f.col(column) * f.col("Profit_Center_Affectation_pourcentage"),
        ).otherwise(f.col(column)),
    )

# Handle data without stocks; rules: assign base profit center
df_stock_on_hand_null = df_stock_on_hand_null.withColumn(
    "Profit_Center_Affectation", f.col("Profit_Center")
).withColumn("Profit_Center_Affectation_pourcentage", f.lit(1))

df_precise_affectation = df_precise_affectation.unionByName(df_stock_on_hand_null)

# Define conditions for replacement

allocate_profit_center_base_condition = (
    (f.col("Profit_Center_Affectation") == "Unknown")
    | f.isnull(f.col("Profit_Center_Affectation"))
) & (
    (~f.col("Profit_Center").startswith("92")) | (~f.col("Profit_Center").endswith("W"))
)

allocate_others_condition = (
    (f.col("Profit_Center_Affectation") == "Unknown")
    | (f.isnull(f.col("Profit_Center_Affectation")))
) & ((f.col("Profit_Center").startswith("92")) | (f.col("Profit_Center").endswith("W")))

df_with_replaced_values = df_precise_affectation.withColumn(
    "Profit_Center_Affectation",
    f.when(
        allocate_profit_center_base_condition,
        df_precise_affectation["Profit_Center"],
    )
    .when(
        allocate_others_condition,
        "Others",
    )
    .otherwise(df_precise_affectation["Profit_Center_Affectation"]),
)
df_final = df_with_replaced_values.drop(
    "PF_pourcentage_affectation",
    "Material_Number_master",
    "Plant_master",
    "MRP_Unit_master",
    "rown_num",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 6 - Add Standard & Average Prices
# MAGIC

# COMMAND ----------

# Replace null by 0
df_full_table_clean = df_final.fillna(
    0,
    [
        "Provision",
        "Standard_Price_Provision",
        "Average_Price_Provision",
        "wip_pe",
        "wip_assy",
        "Standard_Stock_On_Hand_Price",
        "Average_Stock_On_Hand_Price",
        "Standard_Transit_Stock_Price",
        "Average_Transit_Stock_Price",
        "Standard_VMI_Price",
        "Average_VMI_Price",
    ],
)
# ------------------------------------------------------------------------
# Add calculated full stock standard price
df_full_table_stdprice = df_full_table_clean.withColumn(
    "Full_Stock_Standard_Price",
    f.col("Standard_Stock_On_Hand_Price")
    + f.col("Standard_Transit_Stock_Price")
    + f.col("Standard_VMI_Price")
    + f.col("Standard_Price_Provision"),
)
# Management negative values
df_full_table_stdprice_clean = df_full_table_stdprice.withColumn(
    "Full_Stock_Standard_Price",
    f.when(f.col("Full_Stock_Standard_Price") < 0, f.lit(0)).otherwise(
        f.col("Full_Stock_Standard_Price")
    ),
)
# ------------------------------------------------------------------------
# Add calculated full stock average price
df_full_table_avgprice = df_full_table_stdprice_clean.withColumn(
    "Full_Stock_Average_Price",
    f.col("Average_Stock_On_Hand_Price")
    + f.col("Average_Transit_Stock_Price")
    + f.col("Average_VMI_Price")
    + f.col("Standard_Price_Provision"),
)
# Management negative values
df_full_table_price = df_full_table_avgprice.withColumn(
    "Full_Stock_Average_Price",
    f.when(f.col("Full_Stock_Average_Price") < 0, f.lit(0)).otherwise(
        f.col("Full_Stock_Average_Price")
    ),
)
# ------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 7 - Add External Inventory

# COMMAND ----------

df_full_table_end = df_full_table_price.unionByName(
    df_external_sap_inventory, allowMissingColumns=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 8 - Add MEKKO Categorisation

# COMMAND ----------

df_master_material_mekko = df_master_material.select(
    "Plant", "Material_Number", "Mekko_classif"
).dropDuplicates()
df_mekko_table = df_full_table_end.join(
    df_master_material_mekko, ["Material_Number", "Plant"], "left"
)
df_full_table_end = df_mekko_table.withColumn(
    "Mekko_classif",
    f.when(f.col("Mekko_classif").isNull(), f.lit("9-OTHERS")).otherwise(
        f.col("Mekko_classif")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 9 - Management Historisation Global Stock

# COMMAND ----------

if PERIOD == "weekly":
    df_stocks_weekly = add_weekly_evol_dates(df_full_table_end)
    df_stocks_weekly = df_stocks_weekly.drop(
        "observation_date_related_sunday", "load_date"
    )
    if not INIT_WITH_LATEST:
        df_history_w = spark.read.table(
            f"{PIPELINE_READ_ENV}_gold.inventory_valued.global_stock_valued_weekly_history"
        )
        id_w = df_stocks_weekly.select("observation_week").collect()[0][0]
        df_history_w_filter = df_history_w.filter(f.col("observation_week") != id_w)
        df_stocks_weekly_end = df_history_w_filter.unionByName(
            df_stocks_weekly, allowMissingColumns=True
        )
    if INIT_WITH_LATEST:
        df_stocks_weekly_end = df_stocks_weekly

    # Creation ranking for PBI
    w0 = Window.orderBy(f.col("observation_week"))
    df_stocks_weekly_end = df_stocks_weekly_end.withColumn(
        "observation_week_rank", f.dense_rank().over(w0)
    )

if PERIOD == "monthly":
    df_stocks_monthly = add_monthly_evol_dates(df_full_table_end)
    df_stocks_monthly = df_stocks_monthly.drop("load_date")

    if not INIT_WITH_LATEST:
        df_history_m = spark.read.table(
            f"{PIPELINE_READ_ENV}_gold.inventory_valued.global_stock_valued_monthly_history"
        )
        id_m = df_stocks_monthly.select("observation_month").collect()[0][0]
        df_history_m_filter = df_history_m.filter(f.col("observation_month") != id_m)
        df_stocks_monthly_end = df_history_m_filter.unionByName(
            df_stocks_monthly, allowMissingColumns=True
        )
    if INIT_WITH_LATEST:
        df_stocks_monthly_end = df_stocks_monthly

    # Creation ranking for PBI
    w1 = Window.orderBy(f.desc(f.col("observation_month")))
    df_stocks_monthly_end = df_stocks_monthly_end.withColumn(
        "observation_month_rank", f.dense_rank().over(w1)
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold Global Stock Valued
# MAGIC
# MAGIC Saving of Gold Global Stock Valued- This represents the enriched LATECOERE SAP ECC6 Global Stock Latest /Weekly / Monthly.  

# COMMAND ----------

Stock_Latest_path = (
    f"{PIPELINE_WRITE_ENV}_gold.inventory_valued.global_stock_valued_weekly_latest"
)
save_table(dest_table=Stock_Latest_path, df=df_full_table_end, mode="overwrite")
# -----------------------------------------------------------------------------------------------------
# Saving weekly historisation
if PERIOD == "weekly":
    Stock_Weekly_path = (
        f"{PIPELINE_WRITE_ENV}_gold.inventory_valued.global_stock_valued_weekly_history"
    )
    save_table(dest_table=Stock_Weekly_path, df=df_stocks_weekly_end, mode="overwrite")
# -----------------------------------------------------------------------------------------------------
# Saving Monthly historisation
if PERIOD == "monthly":
    Stock_Monthly_path = f"{PIPELINE_WRITE_ENV}_gold.inventory_valued.global_stock_valued_monthly_history"
    save_table(
        dest_table=Stock_Monthly_path, df=df_stocks_monthly_end, mode="overwrite"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
