# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table for External Inventory for company out of SAP
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.inventory_valued.external_global_stock_valued_latest
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02-Inventory/External_inventory/INVENTORY_IS_USA.xlsx"  
# MAGIC   - f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02-Inventory/External_inventory/INVENTORY_AS_AVCORP.xlsx"  
# MAGIC   
# MAGIC **Triggered by:**  
# MAGIC   - File available on S3
# MAGIC
# MAGIC **Performed in this notebook:** 
# MAGIC   - Extract Sheets 'Inventory'  
# MAGIC   - Calcul ProvInventory out of SAP
# MAGIC   - Save Gold Table

# COMMAND ----------

# MAGIC %md
# MAGIC **Python dependencies needed**
# MAGIC
# MAGIC `%pip install fsspec s3fs openpyxl`

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pandas as pd
import re
import pyspark.sql.functions as f
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("init_latest", "false")
INIT_LATEST = dbutils.widgets.get("init_latest").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC The inputs of this notebook are excel files that are in S3 manual/leapdepot/UC02_INVENTORY. Only files that contain "INVENTORY_IS_USA" is acceptable. \
# MAGIC Warning: This notebook needs to work if only one branch put a file. 

# COMMAND ----------

if (
    len(
        dbutils.fs.ls(
            f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02_INVENTORY/External_inventory/"
        )
    )
    == 0
):
    dbutils.notebook.exit("No files in leapdepot/UC02_INVENTORY/External_inventory/")

# COMMAND ----------

df = spark.createDataFrame(
    dbutils.fs.ls(
        f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02_INVENTORY/External_inventory/"
    )
)

# if df.count() > 1:
#     raise Exception("More than 1 file in the folder, check and come back")

list_external_files = []

if df.filter(f.col("name").contains("INVENTORY_IS_USA")).count() > 0:
    list_external_files.append("LIS_US")

if df.filter(f.col("name").contains("INVENTORY_AS_AVCORP")).count() > 0:
    list_external_files.append("AVCORP")

list_external_files

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 - LIS Inventory US

# COMMAND ----------

if "LIS_US" in list_external_files:
    path_to_reference_file_as = list(
        spark.createDataFrame(
            dbutils.fs.ls(
                f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02_INVENTORY/External_inventory/"
            )
        )
        .filter(f.col("name").contains("INVENTORY_IS_USA"))
        .select("path")
        .toPandas()["path"]
    )[0]

    # Create DataFrame according AS Excel Files
    sheet_name = "Inventory"
    # We read the database saved in the corresponding sheet_name
    df_stock_is_usa = pd.read_excel(
        path_to_reference_file_as, sheet_name=sheet_name, dtype="string"
    )
    ## Keep solution where we used Header from Excel Files
    # Rename column headers and replace invalid characters
    df_stock_is_usa.columns = [
        re.sub("\W+", "_", col.strip()) for col in df_stock_is_usa.columns
    ]

    # # We create the schema header basing on the columns of the file loaded
    df_stock_schema_headers_is_usa = StructType(
        [
            StructField(field_name, StringType(), True)
            for field_name in df_stock_is_usa.columns
        ]
    )
    df_stock_is_usa = spark.createDataFrame(
        pd.DataFrame(df_stock_is_usa), schema=df_stock_schema_headers_is_usa
    )
    # -----------------------------------------------------------------------------
    # Specific rules of LATECOERE IS INVENTORY
    df_stock_is_usa = (
        df_stock_is_usa.withColumn(
            "Standard_Stock_On_Hand_Price",
            f.col("Standard_Stock_On_Hand_Price").cast("double"),
        )
        .withColumn("wip_assy", f.col("wip_assy").cast("double"))
        .withColumn(
            "Average_Stock_On_Hand_Price",
            f.col("Average_Stock_On_Hand_Price").cast("double"),
        )
    )

    # Add branch information
    df_stock_is_usa_end = df_stock_is_usa.withColumn("Branch", f.lit("IS"))
    # ----------------------------------------------------------------
    df_stock_is_usa_end = df_stock_is_usa_end.withColumn("Plant", f.lit("LIS_US"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2 - AVCORP Inventory

# COMMAND ----------

if "AVCORP" in list_external_files:
    path_to_reference_file_is = list(
        spark.createDataFrame(
            dbutils.fs.ls(
                f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02_INVENTORY/"
            )
        )
        .filter(f.col("name").contains("INVENTORY_AS_AVCORP"))
        .select("path")
        .toPandas()["path"]
    )[0]

    # Create DataFrame according AVCORP Excel Files
    sheet_name = "Inventory"
    # We read the database saved in the corresponding sheet_name
    df_stock_as_avcorp = pd.read_excel(
        path_to_reference_file_is, sheet_name=sheet_name, dtype="string"
    )
    ## Keep solution where we used Header from Excel Files
    # Rename column headers and replace invalid characters
    df_stock_as_avcorp.columns = [re.sub("\W+", "_", col.strip()) for col in df_stock_as_avcorp.columns]

    # # We create the schema header basing on the columns of the file loaded
    df_stock_schema_headers_as_avcorp = StructType(
        [
            StructField(field_name, StringType(), True)
            for field_name in df_stock_as_avcorp.columns
        ]
    )
    df_stock_as_avcorp = spark.createDataFrame(
        pd.DataFrame(df_stock_as_avcorp), schema=df_stock_schema_headers_as_avcorp
    )
    # Add branch information
    df_stock_as_avcorp_end = df_stock_as_avcorp.withColumn("Branch", f.lit("AS"))
    # ----------------------------------------------------------------    
    df_stock_as_avcorp_end = df_stock_as_avcorp.withColumn("Plant", f.lit("AVCORP"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 3 - Union External Inventory

# COMMAND ----------

if ("LIS_US" in list_external_files) & ("AVCORP" in list_external_files):
    df_stk_external = df_stock_is_usa_end.unionByName(df_stock_as_avcorp_end, False)
if ("LIS_US" in list_external_files) & ("AVCORP" not in list_external_files):
    df_stk_external = df_stock_is_usa_end
if ("AVCORP" in list_external_files) & ("LIS_US" not in list_external_files):
    df_stk_external = df_stock_as_avcorp_end

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC #Initialisation of the gold table
# MAGIC When INIT_LATEST = True, the new files completely replace the table. 

# COMMAND ----------

# MAGIC %md
# MAGIC ##Update the gold table based on the branch
# MAGIC Initialisation of the gold table: 
# MAGIC When INIT_LATEST = True, the new files completely replace the table. 

# COMMAND ----------

if INIT_LATEST:
    df_final = df_stk_external

if not INIT_LATEST:
    df_initial = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.inventory_valued.external_global_stock_valued_latest"
    )

    for branch in list_external_files:
        df_initial = df_initial.filter(f.col("Plant") != f"{branch}")

    df_final = df_initial.unionByName(df_stk_external, False)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Save Gold Table Inventory External

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "inventory_valued"
table = "external_global_stock_valued_latest"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_final,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Archive files in S3

# COMMAND ----------

source_path = (
    f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/manual/leapdepot/UC02_INVENTORY/External_inventory/"
)
target_path = f"s3://leap-s3-raw-weeu1-{PIPELINE_READ_ENV}/archive/manual/leapdepot/UC02_INVENTORY/External_inventory/"

# COMMAND ----------

if len(dbutils.fs.ls(f"{source_path}/")) > 0:
    s3_files = spark.createDataFrame(dbutils.fs.ls(f"{source_path}/"))
    # List of all file name to ingest
    name_list = [row.name for row in s3_files.select("name").collect()]

# COMMAND ----------

for i in range(len(name_list)):
    file_path = name_list[i]
    dbutils.fs.mv(f"{source_path}/{file_path}", f"{target_path}/{file_path}")
