# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE SILVER HOURS PER COST CENTER INFORMATION
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the silver table on hours per cost center for productive and improductive hours. 
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - hours per cost center - SAP
# MAGIC
# MAGIC **Input Tables**
# MAGIC - '{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cosl_latest'
# MAGIC - '{PIPELINE_READ_ENV}_bronze.headers_sap.headers_sap_business_cosl'
# MAGIC
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC '{PIPELINE_WRITE_ENV}_silver.finance.hours_per_cost_center'
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Imports

# COMMAND ----------

from pyspark.sql import functions as f

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

df_cosl = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cosl_latest"
)

df_cosl_headers = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze.headers_sap.headers_sap_business_cosl"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Input - Manual Declaration

# COMMAND ----------

lst_cols = [f"cosl_lst{str(i).zfill(3)}" for i in range(1, 17)]
kap_cols = [f"cosl_kap{str(i).zfill(3)}" for i in range(1, 17)]
aus_cols = [f"cosl_aus{str(i).zfill(3)}" for i in range(1, 17)]
dis_cols = [f"cosl_dis{str(i).zfill(3)}" for i in range(1, 17)]
aeq_cols = [f"cosl_aeq{str(i).zfill(3)}" for i in range(1, 17)]

# List all float columns in one
FLOAT_COL = lst_cols + kap_cols + aus_cols + dis_cols

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 : Column renaming

# COMMAND ----------

df_cosl_prep = table_utils.add_prefix_to_columns(df_cosl, "cosl")

df_cosl_prep = table_utils.rename_columns_with_sap_business_header(
    df_cosl_prep, df_cosl_headers
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 : Sign management

# COMMAND ----------

for col_name in FLOAT_COL:
    df_cosl_prep = table_utils.transform_float_column(df_cosl_prep, col_name)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 : Filter on hours type 

# COMMAND ----------

lst_cols = [f"cosl_lst{str(i).zfill(3)}" for i in range(1, 13)]

df_source = df_cosl_prep.filter(f.col("unit_of_measure") == "H").filter(
    f.col("value_type") == "04"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2 : Create columns cost_center

# COMMAND ----------

df_source = df_source.withColumn(
    "cost_center",
    f.regexp_extract(
        f.split(f.col("object_number"), "    ").getItem(0), r"([A-Z]{0,3}\d{3,5})$", 1
    ),
).withColumn("data_type_cc", f.split(f.col("object_number"), "    ").getItem(1))


# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 3 : Rotate the lst column (quantity)

# COMMAND ----------

df_lst = (
    df_source.select(
        "object_number",
        "fiscal_year",
        "unit_of_measure",
        "data_type_cc",
        "cost_center",
        *lst_cols,
    )
    .selectExpr(
        "object_number",
        "fiscal_year",
        "unit_of_measure",
        "data_type_cc",
        "cost_center",
        *[f"`{c}` as {c}" for c in lst_cols],
    )
    .selectExpr(
        "object_number",
        "fiscal_year",
        "unit_of_measure",
        "data_type_cc",
        "cost_center",
        *[
            "stack(12, "
            + ", ".join([f"'{i+1}', `{lst_cols[i]}`" for i in range(12)])
            + ") as (posting_period, quantity)"
        ],
    )
    .withColumn(
        "hour_type",
        f.when(f.col("data_type_cc") == "999", "improductive").otherwise("productive"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 4: Period cleanning 

# COMMAND ----------

df_final = df_lst.withColumn(
    "posting_period", f.format_string("%02d", df_lst.posting_period.cast("int"))
)

# COMMAND ----------

df_final = df_final.withColumn(
    "date", f.concat_ws("-", f.col("fiscal_year"), f.col("posting_period"), f.lit("01"))
)

# COMMAND ----------

df_final=df_final.withColumn("date",f.to_date(df_final.date,"yyyy-MM-dd"))

# COMMAND ----------

df_final=df_final.select("cost_center",
    "hour_type",
    "fiscal_year",
    "unit_of_measure",
    "posting_period",
    "quantity","date")

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

HOUR_COST_CENTER_SILVER_SAP_TABLE= f"{PIPELINE_WRITE_ENV}_silver.finance.hours_cost_center"

# COMMAND ----------

table_utils.save_table(
    dest_table=HOUR_COST_CENTER_SILVER_SAP_TABLE,
    df=df_final,
    overwrite_schema=True,
    mode="overwrite",
)
