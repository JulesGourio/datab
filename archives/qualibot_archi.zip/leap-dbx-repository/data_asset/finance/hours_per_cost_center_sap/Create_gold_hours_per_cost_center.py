# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE GOLD HOURS PER COST CENTER SAP
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the gold table from the silver table of hours per cost center. 
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - hours_per_cost_center
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {PIPELINE_READ_ENV}_silver.production.hours_per_cost_center
# MAGIC - {PIPELINE_READ_ENV}_gold.finance.active_cost_center_exposed
# MAGIC - {REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC
# MAGIC - {pipeline_write_env}_gold.finance.hours_per_cost_center
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Imports

# COMMAND ----------

from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

HOURS_PER_COST_CENTER_GOLD_SAP_TABLE = (
    f"{PIPELINE_WRITE_ENV}_gold.production.hours_per_cost_center"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Input

# COMMAND ----------

df_silver_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.hours_cost_center"
)

# COMMAND ----------

df_cost_center = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.active_cost_center_exposed"
)

# COMMAND ----------

df_site_division_region = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data preparation 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 1 : df_cost_center

# COMMAND ----------

df_cost_center = df_cost_center.select(
    "Cost_Center", "Long_Description", "CC_Department", "CC_Responsible", "site"
).dropDuplicates()

# COMMAND ----------

df_cost_center = df_cost_center.withColumnRenamed("Cost_Center", "cost_center")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 : Join df_cost_center on cost_center

# COMMAND ----------

df_hr_tr = df_silver_raw.join(df_cost_center, on="cost_center", how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2 : Join df_site_region_division on site

# COMMAND ----------

df_final = df_hr_tr.join(df_site_division_region, on="site", how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Quality check

# COMMAND ----------

if df_silver_raw.count() != df_final.count():
    raise Exception("Data duplicated in join")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 3 : create column cost_center_code_description

# COMMAND ----------

df_final = df_final.withColumn(
    "cost_center_code_description",
    f.concat_ws(" ", f.col("cost_center"), f.col("Long_Description")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

HOURS_PER_COST_CENTER_GOLD_SAP_TABLE = (
    f"{PIPELINE_WRITE_ENV}_gold.finance.hours_per_cost_center"
)

# COMMAND ----------

table_utils.save_table(
    dest_table=HOURS_PER_COST_CENTER_GOLD_SAP_TABLE,
    df=df_final,
    overwrite_schema=True,
    mode="overwrite",
)
