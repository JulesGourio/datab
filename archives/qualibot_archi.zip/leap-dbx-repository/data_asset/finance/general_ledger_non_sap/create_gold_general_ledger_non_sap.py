# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # General Ledger - Non SAP companies
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create the gold table of the general ledger for non sap companies. The gold table latest is identical to the silver table at this stage, and is historized based on (Company; Fiscal Year). 
# MAGIC
# MAGIC **Input:**  
# MAGIC   - {PIPELINE_READ_ENV}_silver.finance.general_ledger_non_sap
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.currency_exchange
# MAGIC   
# MAGIC **Output table:**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.finance.general_ledger_non_sap_history
# MAGIC   
# MAGIC **Used by:**  
# MAGIC create_proj_pnl_non_sap

# COMMAND ----------

import pyspark.sql.functions as f

from datetime import timedelta, datetime
from pyspark.sql import DataFrame
from itertools import chain

from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("init_gold_history", "False")
init_gold_history = dbutils.widgets.get("init_gold_history").lower()

# COMMAND ----------

# MAGIC %md
# MAGIC #Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##LEAP tables

# COMMAND ----------

df_silver_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.general_ledger_non_sap"
)

# COMMAND ----------

df_gold_gl_avcorp = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.general_ledger_avcorp"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

# The aim of this mapping dictionnary is to attribute a unique numerical value per company
# Because alerts work only with numerical condition

dict_cny_code_to_num = {
    "LES1": "10",
    "LUS1": "20",
    "LCA1": "30",
    "LUK1": "40",
    "LBE1": "50",
    "LMXC": "60",
    "LAC1": "70",
}

# COMMAND ----------

# MAGIC %md
# MAGIC #Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Avcorp adaptation

# COMMAND ----------

COLUMNS_TO_SELECT_AVCORP = [
    "cost_center",
    "amount_in_company_currency",
    "company_currency",
    "fiscal_year",
    "posting_period",
    "conso_exchange_rate_from_company_currency_to_eur",
    "amount_in_company_currency_to_EUR_in_conso_rate",
    "conso_account",
    "conso_account_description",
    "GL_SAP_account",
    "profit_center",
    "account_group",
    "account_group_description",
    "description_cost_center",
    "Site",
    "profit_center_description",
    "accouting_PC_group",
    "Company_ID_of_trading_partner"
]

# COMMAND ----------

df_gold_gl_avcorp_adapted = (
    df_gold_gl_avcorp.select(COLUMNS_TO_SELECT_AVCORP)
    .withColumnRenamed("GL_SAP_account", "Account_number")
    .withColumn("Company_Code", f.lit("LAC1"))
    .withColumnRenamed("accouting_PC_group", "Accounting_PC_Group")
    .withColumn(
        "Company_ID_of_trading_partner",
        f.coalesce(f.col("Company_ID_of_trading_partner"), f.lit("X000")),
    )
)

# COMMAND ----------

DICT_RENAMING_AVCORP = {
    "GL_SAP_account": "Account_number",
    "amount_in_company_currency": "Amount_in_company_currency",
    "company_currency": "Currency",
    "amount_in_company_currency_to_EUR_in_conso_rate": "Amount_in_EUR",
    "conso_exchange_rate_from_company_currency_to_eur": "Conso_exchange_rates",
    "fiscal_year": "Fiscal_Year",
    "posting_period": "Posting_period",
    "profit_center": "Profit_Center",
    "Profit_center_description": "Profit_center_description",
    "account_group": "Group_Name",
    "conso_account": "Conso_account_group",
}

df_gold_gl_avcorp_adapted = df_gold_gl_avcorp_adapted.withColumnsRenamed(
    DICT_RENAMING_AVCORP
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Transformation 
# MAGIC - Conversion in EUR

# COMMAND ----------

# MAGIC %md
# MAGIC ##Transformation 1 - Conversion

# COMMAND ----------

df_gl_prep = df_silver_raw.withColumn(
    "_temp_conversion_date",
    f.when(
        f.col("Fiscal_year") < f.year(f.current_date()),
        f.to_date(
            f.concat(f.col("Fiscal_Year"), f.lit("12"), f.lit("31")),
            "yyyyMMdd",
        ),
    ).otherwise(f.date_sub(f.current_date(), 2)),
)

# COMMAND ----------

df_gl_transf = (
    table_utils.currency_conversion(
        df=df_gl_prep,
        document_currency_column=df_gl_prep.Currency,
        rate_types=["Consolidation"],
        rate_dates=[df_gl_prep._temp_conversion_date],
        target_currency_value="EUR",
        document_amounts=[df_gl_prep.Amount],
    )
    .withColumnsRenamed(
        {
            "Currency_to_EUR_in_Consolidation_rate_at__temp_conversion_date": "Conso_exchange_rates",
            "Amount_from_Currency_to_EUR_in_Consolidation_rate_at__temp_conversion_date": "Amount_in_EUR",
        }
    )
    .drop("_temp_conversion_date")
)

# COMMAND ----------

# MAGIC %md
# MAGIC Quality check: no conversion rate equal to 1 except for EUR. \
# MAGIC Remark: QC following multiple mistakes with CAD. 

# COMMAND ----------

assert (
    df_gl_transf.filter(
        (f.col("Currency") != "EUR") & (f.col("Conso_exchange_rates") == 1)
    ).count()
    == 0
)

# COMMAND ----------

df_gl_transf = (
    df_gl_transf.withColumnRenamed("Amount", "Amount_in_company_currency")
    .withColumn("cost_center", f.lit(None).cast("string"))
)

# COMMAND ----------

df_gold_gl_avcorp_adapted = df_gold_gl_avcorp_adapted.drop(
    *(set(df_gl_transf.columns) - set(df_gold_gl_avcorp_adapted.columns))
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Output - Latest

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "finance"
table = "general_ledger_non_sap"

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}_latest",
    df=df_gl_transf,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Output - History

# COMMAND ----------

if init_gold_history == "true":
    spark.sql(f"DROP TABLE IF EXISTS {catalog}.{domain}.{table}_history")

# COMMAND ----------

dest_table_history = f"{catalog}.{domain}.{table}_history"

if not table_utils.UnityCatalogCheckTableExists(dest_table_history):
    # Save the latest as the history

    table_utils.save_table(
        dest_table=f"{catalog}.{domain}.{table}_history",
        df=df_gl_transf,
        mode="overwrite",
        overwrite_schema=True,
    )

else:
    df_history = spark.read.table(dest_table_history)
    df_history_cols = df_history.columns

    # Find distinct tuples "Company_code", "Fiscal_Year" in new datas
    df_company_years_latest = df_gl_transf.select(
        "Company_code", "Fiscal_Year"
    ).distinct()

    # take previous history table filtered from the latest tuples "Company_code", "Fiscal_Year"
    df_history_wo_latest = df_history.join(
        df_company_years_latest,
        on=["Company_code", "Fiscal_Year"],
        how="leftanti",
    ).filter(f.col("Company_code") != "LAC1")

    # Union history and new datas
    df_history = df_history_wo_latest.unionByName(
        df_gl_transf, allowMissingColumns=True
    ).drop("Conso_exchange_rates", "Amount_in_EUR")

    # Conversion of the new df_history
    df_history = df_history.withColumn(
        "_temp_conversion_date",
        f.when(
            f.col("Fiscal_year") < f.year(f.current_date()),
            f.to_date(
                f.concat(f.col("Fiscal_Year"), f.lit("12"), f.lit("31")),
                "yyyyMMdd",
            ),
        ).otherwise(f.date_sub(f.current_date(), 1)),
    )

    df_history = (
        table_utils.currency_conversion(
            df=df_history,
            document_currency_column=df_history.Currency,
            rate_types=["Consolidation"],
            rate_dates=[df_history._temp_conversion_date],
            target_currency_value="EUR",
            document_amounts=[df_history.Amount_in_company_currency],
        )
        .withColumnsRenamed(
            {
                "Currency_to_EUR_in_Consolidation_rate_at__temp_conversion_date": "Conso_exchange_rates",
                "Amount_in_company_currency_from_Currency_to_EUR_in_Consolidation_rate_at__temp_conversion_date": "Amount_in_EUR",
            }
        )
        .drop("_temp_conversion_date")
    )

    df_history_with_avcorp = df_history.unionByName(
        df_gold_gl_avcorp_adapted, allowMissingColumns=True
    )

    df_history_with_avcorp = df_history_with_avcorp.select(*df_history_cols)

    table_utils.save_table(
        dest_table=dest_table_history,
        df=df_history_with_avcorp,
        mode="overwrite",
        overwrite_schema=True,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ##Output - logs

# COMMAND ----------

df_logs = (
    df_gl_transf.select("ID", "File_name", "Fiscal_Year", "Company_Code")
    .dropDuplicates()
    .withColumn("Deposit_date", f.substring(f.col("File_name"), 0, 8))
)

mapping_expr_cny = f.create_map(
    [f.lit(x) for x in chain(*dict_cny_code_to_num.items())]
)
df_logs = df_logs.withColumn(
    "Company_code_num", mapping_expr_cny[df_logs["Company_Code"]]
)

# COMMAND ----------

dest_table_logs = f"{catalog}.{domain}.{table}_logs"

if not table_utils.UnityCatalogCheckTableExists(dest_table_logs):
    df_final = df_logs
else:
    df_history_logs = spark.read.table(dest_table_logs)
    df_final = df_logs.unionByName(df_history_logs)

df_final = df_final.dropDuplicates()
table_utils.save_table(
    dest_table=dest_table_logs,
    df=df_final,
    mode="overwrite",
    overwrite_schema=True,
)
