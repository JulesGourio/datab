# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # General Ledger - AVCORP - Gold
# MAGIC
# MAGIC **Description:**  
# MAGIC Avcorp is a firm bought by Latecoere which is located in Canada.  
# MAGIC One's software to store and deal with the supply of the firm is differen from SAP.
# MAGIC Having this in mind, we want to create a financial data asset similar to the GL for Avcorp.  
# MAGIC This is what we are doing in this gold notebook
# MAGIC
# MAGIC **Confluence Documentation**
# MAGIC - http://confluence.lat.corp:8090/display/LEAP/General+Ledger+-+Avcorp
# MAGIC
# MAGIC **Job Name**
# MAGIC - `General Ledger non SAP - ingestion/data-asset/proj`
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.finance.general_ledger_avcorp
# MAGIC - {PIPELINE_WRITE_ENV}_bronze.manual_input_avcorp.mappings_avcorp_profit_center
# MAGIC - {PIPELINE_WRITE_ENV}_bronze.manual_input_avcorp.mappings_avcorp_accounts
# MAGIC - {PIPELINE_WRITE_ENV}_bronze.manual_input_avcorp.mappings_avcorp_cost_center
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.finance.general_ledger_avcorp

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import DataFrame
from typing import Literal

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### LOG LEVEL 
# MAGIC `LOG_LEVEL` is used for specifying what log level is defined inside the notebook

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

def encode_nan_literal_values(
    df: DataFrame, undesired_value: Literal["#N/A", "#REF!"]
) -> DataFrame:
    """
    Turn `undesired_value` values into Nan values pyspark format

    :param df: input Spark dataframe
    :type df: pyspark.sql.DataFrame
    :param undesired_value: undesired value to be replaced by Nan
    :type undesired_value: Literal["#N/A", "#REF!"]
    :return: Spark dataframe with nan values replaced
    :rtype: pyspark.sql.DataFrame
    """

    return df.select(
        [
            f.when(f.col(column) == undesired_value, f.lit(None))
            .otherwise(f.col(column))
            .alias(column)
            for column in df.columns
        ]
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC
# MAGIC - Silver GL Avcorp: **``df_silver_gl_avcorp``** silver data asset of avcorp gl
# MAGIC - Mappings between **Avcorp** and **Cost Center**: **``mappings_avcorp_cost_center``** which is a enrichissment table on gl dimension
# MAGIC - Mappings between **Avcorp** and **Profit Center**: **``mappings_avcorp_profit_center``** which is a enrichissment table on gl dimension
# MAGIC - Mappings between **Avcorp** and **Accounts**: **``mappings_avcorp_accounts``** which is a enrichissment table on gl dimension

# COMMAND ----------

df_silver_gl_avcorp = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.general_ledger_avcorp"
)

# Input mappings table
mappings_avcorp_cost_center = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input_avcorp.mappings_avcorp_cost_center"
)
mappings_avcorp_accounts = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input_avcorp.mappings_avcorp_accounts"
)
mappings_avcorp_profit_center = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input_avcorp.mappings_avcorp_profit_center"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC As `mappings_avcorp_cost_center`, `mappings_avcorp_accounts` and `mappings_avcorp_profit_center` are sourced from manual filled excel, we have to operate on and apply some specific cleaning 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation of Mappings Avcorp Cost Center

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 1 - Rename & Drop useless avcorp columns

# COMMAND ----------

mappings_avcorp_cost_center = mappings_avcorp_cost_center.drop("concat T$DIM4 + T$DIM5")

# COMMAND ----------

mappings_avcorp_cost_center_renamed = mappings_avcorp_cost_center.withColumnsRenamed(
    {
        "T$DIM4": "mapping_cost_center",
        "T$DIM5": "mapping_cost_type",
        "test dim 5": "description_cos_type",
        "test dim 4": "description_cost_center",
        "PC SAP": "SAP_profit_center",
        "Ref P&L": "ref_PnL",
        "Associated Pcenter": "associated_profit_center",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 2 - Trim Data & Replace #N/A per nan

# COMMAND ----------

# Trim all the dataframe
mappings_avcorp_cc_prep = table_utils.trim_dataframe(
    mappings_avcorp_cost_center_renamed
)

# Encode #N/A
mappings_avcorp_cc_prep = encode_nan_literal_values(
    df=mappings_avcorp_cc_prep, undesired_value="#N/A"
)

# Encode #REF!
mappings_avcorp_cc_prep = encode_nan_literal_values(
    df=mappings_avcorp_cc_prep, undesired_value="#REF!"
)

# COMMAND ----------

# Delete future duplicated columns
mappings_avcorp_cc_prep = mappings_avcorp_cc_prep.drop("Unknown Column")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation Mappings Avcorp Profit Center

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 3 - Rename & Drop useless GL Accounts columns 

# COMMAND ----------

mappings_avcorp_profit_center_renamed = (
    mappings_avcorp_profit_center.withColumnsRenamed(
        {
            "PC List": "profit_center_list",
            "Desc PC": "profit_center_description",
            "Type": "accouting_PC_group",
            "Site": "site",
        }
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 4 - Trim Data & Delete Data
# MAGIC NB: Trim has to be done before casting (otherwise, it recast data)

# COMMAND ----------

# Trim all the dataframe
mappings_avcorp_profit_center_prep = table_utils.trim_dataframe(
    mappings_avcorp_profit_center_renamed
)

# Encode #N/A
mappings_avcorp_profit_center_prep = encode_nan_literal_values(
    df=mappings_avcorp_profit_center_prep, undesired_value="#N/A"
)

# COMMAND ----------

# Delete future duplicated columns
mappings_avcorp_profit_center_prep = mappings_avcorp_profit_center_prep.drop("site")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation Mappings Avcorp Accounts

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 5 - Rename & Drop useless GL mappings_avcorp_profit_center columns

# COMMAND ----------

mappings_avcorp_accounts_renamed = mappings_avcorp_accounts.withColumnsRenamed(
    {
        "GL_ACCT": "GL_account_number",
        "GL_DESC": "GL_account_description",
        "GL_STATUS": "GL_account_status",
        "Conso Account": "conso_account",
        "Conso Acc + Desc": "conso_account_description",
        "GL SAP Account": "GL_SAP_account",
        "BS-PL": "BS_PL",
        "Sub BSPL": "sub_BSPL",
        "PL Type": "PL_type",
        "Mapping RNREBE": "account_group",
        "Desc Rnrebe": "account_group_description",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 6 - Trim Data & Delete Data

# COMMAND ----------

# Trim all the dataframe
mappings_avcorp_accounts_prep = table_utils.trim_dataframe(
    mappings_avcorp_accounts_renamed
)

# Encode #N/A
mappings_avcorp_accounts_prep = encode_nan_literal_values(
    df=mappings_avcorp_accounts_prep, undesired_value="#N/A"
)

# COMMAND ----------

# Delete unwanted special characters (�) and undesirable spaces
mappings_avcorp_accounts_prep = mappings_avcorp_accounts_prep.withColumn(
    "conso_account_description",
    f.trim(
        f.regexp_replace(
            f.regexp_replace("conso_account_description", r"[^a-zA-Z0-9\s]", ""),
            r"\s+",
            " ",
        )
    ),
)

# COMMAND ----------

# Delete future duplicated columns
mappings_avcorp_accounts_prep = mappings_avcorp_accounts_prep.drop(
    "GL_account_description", "GL_account_status"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation of Silver GL Avcorp

# COMMAND ----------

df_silver_gl_avcorp = df_silver_gl_avcorp.drop(
    "_meta_ID",
    "_meta_stack_row_id",
    "_meta_ingestion_timestamp",
    "_meta_file_name",
    "_meta_file_mode",
    "_meta_file_path",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Conversion in EUR with consolidation rates

# COMMAND ----------

df_gl_avcorp_trans = df_silver_gl_avcorp.withColumn(
    "_temp_actual_date",
    f.when(
        f.col("fiscal_year") < f.year(f.current_date()),
        f.to_date(
            f.concat(f.col("fiscal_year"), f.lit("12"), f.lit("31")),
            "yyyyMMdd",
        ),
    ).otherwise(f.last_day(f.add_months(f.current_date(), -1))),
)

# COMMAND ----------

df_gl_avcorp_trans = (
    table_utils.currency_conversion(
        df=df_gl_avcorp_trans,
        document_currency_column=df_gl_avcorp_trans.company_currency,
        rate_types=["Consolidation"],
        rate_dates=[df_gl_avcorp_trans._temp_actual_date],
        target_currency_value="EUR",
        document_amounts=[df_gl_avcorp_trans.amount_in_company_currency],
    )
    .withColumnsRenamed(
        {
            "company_currency_to_EUR_in_Consolidation_rate_at__temp_actual_date": "conso_exchange_rate_from_company_currency_to_eur",
            "amount_in_company_currency_from_company_currency_to_EUR_in_Consolidation_rate_at__temp_actual_date": "amount_in_company_currency_to_EUR_in_conso_rate",
        }
    )
    .drop("_temp_actual_date")
)

# COMMAND ----------

df_gl_avcorp_trans = df_gl_avcorp_trans.withColumn(
    "amount_in_company_currency", -f.col("amount_in_company_currency")
)
df_gl_avcorp_trans = df_gl_avcorp_trans.withColumn(
    "amount_in_company_currency_to_EUR_in_conso_rate",
    -f.col("amount_in_company_currency_to_EUR_in_conso_rate"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Delete null lines for every data asset & consider null as true value to match for `cost_type`
# MAGIC 1. If there are null lines, we drop it
# MAGIC 2. Null elements on `mappings_avcorp_cc_trans.mapping_cost_type` and `avcorp.cost_type` are not to be considered as null elements but rather elements that have to be matched. As the future merge between `mappings_avcorp_cc_trans` and `avcorp` will be on 2 keys, that's why we check that there are no duplicates fot every couple ("mapping_cost_center", "mapping_cost_type").  
# MAGIC Overall, we do not want that for "mapping_cost_type" null values, there are duplicates `cost_center`

# COMMAND ----------

df_gl_avcorp_trans = df_gl_avcorp_trans.dropna(how="all")
mappings_avcorp_profit_center_trans = mappings_avcorp_profit_center_prep.dropna(
    how="all"
)
mappings_avcorp_accounts_trans = mappings_avcorp_accounts_prep.dropna(how="all")
mappings_avcorp_cc_trans = mappings_avcorp_cc_prep.dropna(how="all")

# COMMAND ----------

check_unicity = (
    mappings_avcorp_cc_trans.filter(f.col("mapping_cost_type").isNull())
    .groupBy("mapping_cost_center")
    .count()
    .filter("count > 1")
)

if check_unicity.count() == 0:
    log.info(
        "No duplicates found in `mappings_avcorp_cc_trans` on couple key `mapping_cost_center` when `mapping_cost_type` IS NULL"
    )

else:
    log.info(
        "No duplicates found in `mappings_avcorp_cc_trans` on couple key `mapping_cost_center` when `mapping_cost_type` IS NULL: the join between avcorp and mapping_cc will result in an error."
    )
    raise TypeError(
        "Duplicates found in `mappings_avcorp_cc_trans` on couple key `mapping_cost_center` when `mapping_cost_type` IS NULL"
    )

# COMMAND ----------

# Turn null values for `mapping_cost_type` into "null" to create a match a the future join with `avcorp`
mappings_avcorp_cc_trans = mappings_avcorp_cc_trans.fillna(
    "null", subset=["mapping_cost_type"]
)

# COMMAND ----------

# Turn null values for `cost_type` into "null" to create a match a the future join with `mappings_avcorp_cc_trans`
df_gl_avcorp_trans = df_gl_avcorp_trans.fillna("null", subset=["cost_type"])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Join Silver avcorp <-- Mappings GL Account <-- Mappings GL CC <-- Mappings GL PC

# COMMAND ----------

df_gl_avcorp_accounts_cc = (
    df_gl_avcorp_trans.alias("avcorp")
    .join(
        other=mappings_avcorp_accounts_trans.alias("mappings_accounts"),
        how="left",
        on=(
            f.col("avcorp.account_number")
            == f.col("mappings_accounts.GL_account_number")
        ),
    )
    .join(
        other=mappings_avcorp_cc_trans.alias("mappings_cc"),
        how="left",
        on=(
            (f.col("avcorp.cost_center") == f.col("mappings_cc.mapping_cost_center"))
            & (f.col("avcorp.cost_type") == f.col("mappings_cc.mapping_cost_type"))
        ),
    )
    .drop("GL_account_number", "mapping_cost_center", "mapping_cost_type")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Create `avcorp.profit_center` from `program` column

# COMMAND ----------

# Turn back "null" string of `cost_type` into None
df_gl_avcorp_accounts_cc = df_gl_avcorp_accounts_cc.withColumn(
    "cost_type",
    f.when(f.col("cost_type") == "null", f.lit(None)).otherwise(f.col("cost_type")),
)

# COMMAND ----------

df_gl_avcorp_accounts_cc_business_rules = df_gl_avcorp_accounts_cc.withColumn(
    "profit_center",
    f.when(
        (f.col("program") == "MISC.") & (f.col("cost_type") == "DIRECT"), f.lit("D01")
    )
    .when((f.col("program") == "MISC.") & (f.col("cost_type") == "MFGOH"), f.lit("G13"))
    .when(
        (f.col("program").isNull())
        & (f.col("cost_center").isNotNull())
        & (f.col("cost_type") == "MFGOH"),
        f.lit("G13"),
    )
    .when(
        (f.col("program").isNotNull())
        & (f.col("cost_center").isNotNull())
        & (f.col("cost_type") == "MFGOH"),
        f.col("program"),
    )
    .when(
        (f.col("cost_center").isNotNull()) & (f.col("cost_type").isNotNull()),
        f.col("associated_profit_center"),
    )
    .when(
        (f.col("program").isNull())
        & (f.col("cost_center").isNull())
        & (f.col("cost_type").isNull()),
        f.lit("G13"),
    )
    .otherwise(f.col("program")),
).drop("program", "associated_profit_center")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 5 - Join avcorp_accounts_cc <-- Mappings GL PC

# COMMAND ----------

df_gl_avcorp_all_join = (
    df_gl_avcorp_accounts_cc_business_rules.join(
        other=mappings_avcorp_profit_center_trans.alias("mappings_profit_center"),
        how="left",
        on=(
            f.col("profit_center") == f.col("mappings_profit_center.profit_center_list")
        ),
    )
    .drop("profit_center_list", "mappings_profit_center")
    .withColumn(
        "accouting_PC_group",
        f.when(f.col("profit_center") == "G13", f.lit("G13_1_RC")).otherwise(
            f.col("accouting_PC_group")
        ),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 6 - Add new column `company_code`

# COMMAND ----------

df_gl_avcorp_all_join = df_gl_avcorp_all_join.withColumn("company_code", f.lit("LAC1"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 7 - Complete/Merge columns after joins

# COMMAND ----------

df_gl_avcorp_all_join.withColumn(
    "description_cost_center",
    f.coalesce("description_cost_center", "GL_description_cost_center"),
).drop("GL_description_cost_center")
df_gl_avcorp_all_join.withColumn(
    "profit_center_description",
    f.coalesce("profit_center_description", "GL_description_profit_center"),
).drop("GL_description_profit_center")
df_gl_avcorp_all_join.withColumn(
    "description_cos_type",
    f.coalesce("description_cos_type", "GL_description_cost_type"),
).drop("GL_description_cost_type")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Transformation 8 - Interco 
# MAGIC In Avcorp way of reporting, intercompany flows are flagged through specific account number.

# COMMAND ----------

LIST_ACCOUNT_INTERCO_LATE = ["2603010"]
LIST_ACCOUNT_INTERCO_LAC2 = ["2603020"]

# COMMAND ----------

df_gl_avcorp_all_w_interco = df_gl_avcorp_all_join.withColumn(
    "Company_ID_of_trading_partner",
    f.when(f.col("account_number").isin(LIST_ACCOUNT_INTERCO_LATE), f.lit("800"))
    .when(f.col("account_number").isin(LIST_ACCOUNT_INTERCO_LAC2), f.lit("LAC2"))
    .otherwise(f.lit("X000")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Gold GL Avcorp

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "finance"
table = "general_ledger_avcorp"
dest_table_latest = f"{catalog}.{domain}.{table}"

table_utils.save_table(
    dest_table=dest_table_latest, df=df_gl_avcorp_all_w_interco, mode="overwrite"
)
