# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # General Ledger - Non SAP companies
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table of the general ledger for non sap company. \
# MAGIC In this notebook, the bronze table is join with the account group gold table and profit center gold table in order to get all information relative to these fields.  
# MAGIC
# MAGIC **Input :**  
# MAGIC   - {PIPELINE_READ_ENV}_bronze.leap_depot_uc16_pnl_reporting.general_ledger_non_sap
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.account_groups_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.profit_center_exposed
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_silver.finance.general_ledger_non_sap
# MAGIC   - {PIPELINE_WRITE_ENV}_silver.finance.temp_general_ledger_non_sap_red_checks
# MAGIC   
# MAGIC **Used by:**  
# MAGIC create_gold_general_ledger_non_sap

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils

from itertools import chain

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - **df_gl_non_sap_raw** is the bronze table ingested from leap_depot
# MAGIC - **df_account_gold_raw** gathers the information of account groups 
# MAGIC - **df_pc_raw** is the gold master data table
# MAGIC - **df_coa_raw** is the chart of accounts of consolidation 

# COMMAND ----------

df_gl_non_sap_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze.leap_depot_uc16_pnl_reporting.general_ledger_non_sap"
)

# COMMAND ----------

df_account_gold_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.account_groups_exposed"
).where(f.col('Hierarchy_Level1') == "HIER-PC")

# COMMAND ----------

df_pc_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed")

# COMMAND ----------

df_coa_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.consolidation_chart_of_accounts_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

l_column_acct_table = ["Group_Name", "Account_number"]

# COMMAND ----------

l_column_pc_table = [
    "Aircraft_platform",
    "Accounting_PC_Group",
    "Customer_Group",
    "Aircraft_product",
    "Short_Description",
    "Profit_center_short",
]

# COMMAND ----------

l_accepted_trading_partner = [
    "I200",
    "I210",
    "I220",
    "I002",
    "I006",
    "I007",
    "I001",
    "I003",
    "I005",
    "I900",
    "A101",
    "A700",
    "A710",
    "A720",
    "A730",
    "A900",
    "800",
    "0800",
    "1000",
    "1010",
    "1300",
    "X000",
]

l_columns_not_null = ["Accounting_PC_Group"]
l_column_acct_number = ["Group_Name"]

# COMMAND ----------

l_column_coa_table = [
    "Account_number",
    "conso_group_account",
    "Revenue_YN",
    "Category",
    "DnA",
    "Type_of_accounts",
]

# COMMAND ----------

l_accepted_site = [
    "LSP1",
    "LUS1",
    "LUS2",
    "LCA1",
    "LUK1",
    "LBE1",
    "LMXC",
    "LAC1",
    "LAC2",
    "LAC3",
]

# COMMAND ----------

dict_cny_code_to_num = {
    "LSP1": "10",
    "LUS1": "20",
    "LCA1": "30",
    "LUK1": "40",
    "LBE1": "50",
    "LMXC": "60",
    "LAC1": "70",
}

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC ##Prep 1 - GL non SAP renaming

# COMMAND ----------

rename_columns = [
    ("Jan", "01"),
    ("Feb", "02"),
    ("Mar", "03"),
    ("Apr", "04"),
    ("May", "05"),
    ("Jun", "06"),
    ("Jul", "07"),
    ("Aug", "08"),
    ("Sept", "09"),
    ("Oct", "10"),
    ("Nov", "11"),
    ("Dec", "12"),
]

for old_name, new_name in rename_columns:
    df_gl_non_sap_raw = df_gl_non_sap_raw.withColumnRenamed(old_name, new_name)

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC ##Prep 2 - Account groups dataframe 

# COMMAND ----------

df_acct_prep = df_account_gold_raw.select(l_column_acct_table).withColumn(
    "Account_number", f.regexp_replace(f.col("Account_number"), "^0+", "")
)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 3 - Profit center dataframe

# COMMAND ----------

df_pc_prep = (
    df_pc_raw.select(l_column_pc_table)
    .withColumnRenamed("Profit_center_short", "Profit_Center")
    .withColumnRenamed("Short_Description", "Profit_center_description")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 4 - Consolidation COA dataframe

# COMMAND ----------

rename_columns_coa = [
    ("conso_group_account", "Conso_account_group"),
    ("Revenue_YN", "Conso_Revenue_Costs_categ"),
    ("Category", "Conso_EBIT_categ"),
    ("DnA", "Conso_DnA_categ"),
    ("Type_of_accounts", "Conso_Type_of_accounts"),
]

df_coa_prep = df_coa_raw.select(l_column_coa_table)

for old_name, new_name in rename_columns_coa:
    df_coa_prep = df_coa_prep.withColumnRenamed(old_name, new_name)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Transformation 1 - Unpivot

# COMMAND ----------

columns_to_unpivot = [
    "01",
    "02",
    "03",
    "04",
    "05",
    "06",
    "07",
    "08",
    "09",
    "10",
    "11",
    "12",
]

list_ids = [
    "Fiscal_Year",
    "Company_Code",
    "Site",
    "Profit_Center",
    "Account_number",
    "Company_ID_of_trading_partner",
    "Currency",
    "File_name",
    "ID",
]

df_unpivot = df_gl_non_sap_raw.unpivot(
    ids=list_ids,
    values=columns_to_unpivot,
    variableColumnName="Posting_period",
    valueColumnName="Amount",
)

df_cast = (
    df_unpivot.withColumn("Fiscal_Year", f.year(f.to_date(f.col("Fiscal_Year"))))
    .withColumn("Amount", f.regexp_replace(f.col("Amount"), " ", ""))
    .withColumn("Amount", f.regexp_replace(f.col("Amount"), ",", ".").cast("double"))
    .filter(f.col("Amount").isNotNull())
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Transformation 2 - Join with accounts

# COMMAND ----------

df_gl_tranf = df_cast.join(df_acct_prep, ["Account_number"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Transformation 3 - Join with profit centers

# COMMAND ----------

df_gl_tranf = df_gl_tranf.join(df_pc_prep, ["Profit_Center"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Transformation 4 - Join with COA consolidation

# COMMAND ----------

df_gl_tranf = df_gl_tranf.join(df_coa_prep, ["Account_number"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Transformation 5 - Sign convention

# COMMAND ----------

REVENUE_ACCOUNTS = f.col("Account_number").startswith("70")

# Calculate the sum(Amount) for revenue accounts
df_gl_tranf = df_gl_tranf.withColumn(
    "Amount_if_revenue",
    f.when(REVENUE_ACCOUNTS, f.col("Amount")).otherwise(f.lit(0))
)
window_spec = Window.partitionBy("File_name")
df_gl_tranf = df_gl_tranf.withColumn(
    "Revenue_sum_per_file",
    f.sum("Amount_if_revenue").over(window_spec)
)

# For each File_name in new datas, if the sum(Amount) is negative, then multiply by -1 all Amount of the file
df_gl_tranf = df_gl_tranf.withColumn(
    "Amount",
    f.when(f.col("Revenue_sum_per_file") < 0, f.col("Amount") * -1)
    .otherwise(f.col("Amount"))
).drop("Revenue_sum_per_file","Amount_if_revenue")

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality checks
# MAGIC Amber checks on the file uploaded 
# MAGIC - Trading partner in the list of trading partner
# MAGIC - All PC in SAP CEPC/CEPCT
# MAGIC - Account numbers starts with 6, 7 and 9 associated to a RNREBE account group
# MAGIC - Lines with RNREBE* have a site
# MAGIC - All account numbers starting with 6 or 7 associated to a consolidation group
# MAGIC - List of accepted sites

# COMMAND ----------

list_red_check = []

# COMMAND ----------

# MAGIC %md
# MAGIC ##QC1 - Trading partner

# COMMAND ----------

if (
    df_gl_tranf.filter(
        ~f.col("Company_ID_of_trading_partner").isin(l_accepted_trading_partner)
    ).count()
    > 0
):
    list_red_check.append("QC_Trading_partner_set")

# COMMAND ----------

# MAGIC %md
# MAGIC ##QC2 - Profit center

# COMMAND ----------

if df_gl_tranf.filter(f.col("Accounting_PC_Group").isNull()).count() > 0:
    list_red_check.append("QC_PC_SAP")

# COMMAND ----------

# MAGIC %md
# MAGIC ##QC3 - Account groups & site - Comptes analytiques

# COMMAND ----------

df_check_analytique = df_gl_tranf.filter(f.col("Account_number").rlike("^[679]"))
if (
    df_check_analytique.filter(
        (~f.col("Group_Name").startswith("RNREBE")) | f.col("Group_Name").isNull()
    ).count()
    > 0
):
    list_red_check.append("QC_RNREBE")

if df_check_analytique.filter(f.col("Site").isNull()).count() > 0:
    list_red_check.append("QC_Site_empty")

if df_check_analytique.filter(~f.col("Site").isin(l_accepted_site)).count() > 0:
    list_red_check.append("QC_Site_code")

# COMMAND ----------

# MAGIC %md
# MAGIC ##QC4 - COA consolidation 
# MAGIC All social account numbers are in the consolidation chart of account

# COMMAND ----------

df_check_social = df_gl_tranf.filter(f.col("Account_number").rlike("^[67]"))
if df_check_social.filter(f.col("Conso_account_group").isNull()).count() > 0:
    list_red_check.append("QC_COA_conso")

# COMMAND ----------

bool_check = len(list_red_check) == 0
df_check = df_gl_tranf.select("ID", "File_name", "Company_Code").distinct()
df_check = (
    df_check.withColumn("Red_checks", f.lit(list_red_check))
    .withColumn("pipeline_timestamps", f.lit(f.current_timestamp()))
    .withColumn("is_check_validated", f.lit(bool_check))
)

# COMMAND ----------

mapping_expr_cny = f.create_map(
    [f.lit(x) for x in chain(*dict_cny_code_to_num.items())]
)
df_check = df_check.withColumn(
    "Company_code_num", mapping_expr_cny[df_check["Company_Code"]]
)

# COMMAND ----------

if not bool_check:
    df_check.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs
# MAGIC If business checks are satisfied: creation of the silver table\
# MAGIC Both cases: union the check dataframe

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "finance"
table_logs = "general_ledger_non_sap_checks_logs"
table = "general_ledger_non_sap"

# COMMAND ----------

bool_log_table_exists = table_utils.UnityCatalogCheckTableExists(
    f"{catalog}.{domain}.{table_logs}"
)

if bool_log_table_exists:
    df_check_init = spark.table(f"{catalog}.{domain}.{table_logs}")
    df_check_final = df_check_init.unionByName(
        df_check, allowMissingColumns=False
    ).orderBy(f.desc("pipeline_timestamps"))
else:
    df_check_final = df_check

df_check_final = table_utils.drop_duplicates_by_order(
    df=df_check_final,
    columns=["ID", "File_name", "Company_Code"],
    order_col="pipeline_timestamps",
    keep="last",
)
table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table_logs}",
    df=df_check_final,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

if bool_check:
    table_utils.save_table(
        dest_table=f"{catalog}.{domain}.{table}",
        df=df_gl_tranf,
        mode="overwrite",
        overwrite_schema=True,
    )

    dbutils.jobs.taskValues.set("compute_data_asset", True)
else:
    dbutils.jobs.taskValues.set("compute_data_asset", False)
