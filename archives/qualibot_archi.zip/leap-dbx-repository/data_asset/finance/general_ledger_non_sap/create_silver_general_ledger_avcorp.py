# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # General Ledger - AVCORP - Silver
# MAGIC
# MAGIC **Description:**  
# MAGIC Avcorp is a firm bought by Latecoere which is located in Canada.  
# MAGIC The "BAAN" ERP to store and deal with the supply of the firm is differen from SAP.
# MAGIC Having this in mind, we want to create a financial data asset similar to the GL for Avcorp.
# MAGIC This is what we are doing in this silver notebook
# MAGIC
# MAGIC **Confluence Documentation**
# MAGIC - http://confluence.lat.corp:8090/display/LEAP/General+Ledger+-+Avcorp
# MAGIC
# MAGIC **Job Name**
# MAGIC - `General Ledger non SAP - ingestion/data-asset/proj`
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {REFERENCE_READ_ENV}_prod_bronze.baan_lac.glpl_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.baan_lac.glaccounts_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.baan_lac.gldimensions_latest
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.finance.general_ledger_avcorp
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### LOG LEVEL 
# MAGIC `LOG_LEVEL` is used for specifying what log level is defined inside the notebook

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "finance"
table = "general_ledger_avcorp"
dest_table_latest = f"{catalog}.{domain}.{table}"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC
# MAGIC - Bronze GL Accounts Latest: **``glaccounts_latest``** which is an enrichissment table on accounts
# MAGIC - Bronze GL Dimensions Latest: **``gldimensions_latest``** which is a enrichissment table on gl dimension
# MAGIC - Avcorp financial data: **`glpl_latest`**

# COMMAND ----------

df_gl_accounts_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.baan_lac.glaccounts_latest"
)
df_gl_dim_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.baan_lac.gldimensions_latest"
)

# Input Avcorp financial data
df_avcorp_financial_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.baan_lac.glpl_latest"
)

# COMMAND ----------

# Load Existing silver avcorp
df_existing_silver_avcorp = (
    spark.read.table(dest_table_latest)
    if table_utils.UnityCatalogCheckTableExists(DbxTablePath=dest_table_latest)
    else None
)

if df_existing_silver_avcorp is None:
    log.info(f"The data table located in {dest_table_latest} does not exist yet")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation Avcorp

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 1 - Rename & Drop useless avcorp columns 
# MAGIC
# MAGIC - NB1: `T$DIM2` column is useless, and is a "null" column, so we delete it
# MAGIC - NB2: `program` is a column that will be used to calculate "profit_center" in the gold notebook
# MAGIC - NB3: `MONTH_END_DATE` is empty so we delete it

# COMMAND ----------

df_avcorp_financial_raw = df_avcorp_financial_raw.drop(
    "TDIM2", "MONTH_END_DATE", "AS_AT"
)

# COMMAND ----------

df_avcorp_renamed = df_avcorp_financial_raw.withColumnsRenamed(
    {
        "_meta_extraction_timestamp": "extraction_timestamp",
        "DATE_GRP": "first_period_date",
        "GL_ACCT": "account_number",
        "TDIM1": "project_code",
        "TDIM3": "program",
        "TDIM4": "cost_center",
        "TDIM5": "cost_type",
        "AMOUNT_HC": "amount_in_company_currency",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 2 - Trim Data

# COMMAND ----------

df_avcorp_prep = table_utils.trim_dataframe(df_avcorp_renamed)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 3 - Cast avcorp columns

# COMMAND ----------

# Cast `first_period_date` in Date format
df_avcorp_prep = df_avcorp_prep.withColumn(
    "first_period_date", f.col("first_period_date").cast("date")
)
df_avcorp_prep = df_avcorp_prep.withColumn(
    "extraction_date", f.col("extraction_timestamp").cast("date")
).drop("extraction_timestamp")

# COMMAND ----------

# Cast in double format financial columns
df_avcorp_prep = df_avcorp_prep.withColumn(
    "amount_in_company_currency", f.col("amount_in_company_currency").cast("double")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation GL Accounts

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 4 - Rename & Drop useless GL Accounts columns 

# COMMAND ----------

df_gl_accounts_renamed = df_gl_accounts_raw.withColumnsRenamed(
    {
        "_meta_extraction_timestamp": "extraction_timestamp",
        "_meta_file_mode": "file_mode",
        "GL_ACCT": "GL_account_number",
        "GL_DESC": "GL_account_description",
        "GL_STATUS": "GL_account_status",
        "CAT_GROUP": "account_group_category",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 5 - Trim Data
# MAGIC NB: Trim has to be done before casting (otherwise, it recast data)

# COMMAND ----------

df_gl_accounts_prep = table_utils.trim_dataframe(df_gl_accounts_renamed)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 6 - Cast account columns

# COMMAND ----------

df_gl_accounts_prep_rename = df_gl_accounts_prep.withColumn(
    "extraction_date",
    f.to_date(f.col("extraction_timestamp"), "dd-MMM-yyyy HH.mm.ss"),
).drop("extraction_timestamp")

df_gl_accounts_prep_rename = df_gl_accounts_prep_rename.withColumn(
    "_meta_ingestion_timestamp",
    f.to_date(f.col("_meta_ingestion_timestamp"), "dd-MMM-yyyy HH.mm.ss"),
)

df_gl_accounts_prep_rename = df_gl_accounts_prep_rename.withColumn(
    "_meta_stack_row_id", f.col("_meta_stack_row_id").cast("long")
)
df_gl_accounts_prep_rename = df_gl_accounts_prep_rename.withColumn(
    "_meta_ID", f.col("_meta_ID").cast("long")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation GL Dimension

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 7 - Rename & Drop useless GL Dimension columns 

# COMMAND ----------

df_gl_dim_renamed = df_gl_dim_raw.withColumnsRenamed(
    {
        "_meta_extraction_timestamp": "extraction_timestamp",
        "_meta_file_mode": "file_mode",
        "DIM_DESC": "GL_description",
        "DIM_STATUS": "GL_status",
        "DIM_TYPE": "GL_type",
        "DIM_CODE": "GL_code",
    }
)

# COMMAND ----------

df_gl_dim_prep = table_utils.trim_dataframe(df_gl_dim_renamed)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 8 - Cast dim columns

# COMMAND ----------

df_gl_dim_prep = df_gl_dim_prep.withColumn(
    "extraction_date",
    f.to_date(f.col("extraction_timestamp"), "dd-MMM-yyyy HH.mm.ss"),
).drop("extraction_timestamp")

df_gl_dim_prep = df_gl_dim_prep.withColumn(
    "_meta_ingestion_timestamp",
    f.to_date(f.col("_meta_ingestion_timestamp"), "dd-MMM-yyyy HH.mm.ss"),
)

df_gl_dim_prep = df_gl_dim_prep.withColumn(
    "_meta_stack_row_id", f.col("_meta_stack_row_id").cast("long")
)
df_gl_dim_prep = df_gl_dim_prep.withColumn("_meta_ID", f.col("_meta_ID").cast("long"))
df_gl_dim_prep = df_gl_dim_prep.withColumn("GL_type", f.col("GL_type").cast("int"))

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Add canadian "CAD" currency & fiscal_year,  column
# MAGIC

# COMMAND ----------

# Create column corresponding to "company currency" which is in dollar
df_avcorp_trans = (
    df_avcorp_prep.withColumn("company_currency", f.lit("CAD"))
    .withColumn("fiscal_year", f.year(f.col("first_period_date")))
    .withColumn("posting_period", f.month(f.col("first_period_date")))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Delete null lines for every data asset

# COMMAND ----------

df_avcorp_trans = df_avcorp_trans.dropna(how="all")
df_gl_accounts_trans = df_gl_accounts_prep_rename.dropna(how="all")
df_gl_dim_trans = df_gl_dim_prep.dropna(how="all")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Join Financial avcorp <-- Dim <-- Accounts

# COMMAND ----------

log.info(
    f'Number of duplicates in GL_accounts: {df_gl_accounts_trans.select(f.col("GL_account_number")).count() - df_gl_accounts_trans.select(f.col("GL_account_number")).distinct().count()}'
)

# COMMAND ----------

gl_account_columns = [
    "GL_account_number",
    "GL_account_description",
    "GL_account_status",
    "account_group_category",
]
df_avcorp_accounts = (
    df_avcorp_trans.alias("avcorp")
    .join(
        other=df_gl_accounts_trans.select(gl_account_columns).alias("gl_account"),
        on=(f.col("gl_account.GL_account_number") == f.col("avcorp.account_number")),
        how="left",
    )
    .drop("GL_account_number")
)

# COMMAND ----------

gl_dim_columns = ["GL_code", "GL_description", "GL_status"]

df_avcorp_accounts_dim_1 = df_avcorp_accounts.join(
    other=df_gl_dim_trans.filter(f.col("GL_type") == 1)
    .select(gl_dim_columns)
    .withColumnsRenamed(
        {
            "GL_description": "GL_description_project_code",
            "GL_status": "GL_status_project_code",
        }
    )
    .alias("gl_dim_1"),
    on=(f.col("gl_dim_1.GL_code") == f.col("avcorp.project_code")),
    how="left",
).drop("GL_code")

df_avcorp_accounts_dim_3 = df_avcorp_accounts_dim_1.join(
    other=df_gl_dim_trans.filter(f.col("GL_type") == 3)
    .select(gl_dim_columns)
    .withColumnsRenamed(
        {
            "GL_description": "GL_description_profit_center",
            "GL_status": "GL_status_profit_center",
        }
    )
    .alias("gl_dim_3"),
    on=(f.col("gl_dim_3.GL_code") == f.col("avcorp.program")),
    how="left",
).drop("GL_code")

df_avcorp_accounts_dim_4 = df_avcorp_accounts_dim_3.join(
    other=df_gl_dim_trans.filter(f.col("GL_type") == 4)
    .select(gl_dim_columns)
    .withColumnsRenamed(
        {
            "GL_description": "GL_description_cost_center",
            "GL_status": "GL_status_cost_center",
        }
    )
    .alias("gl_dim_4"),
    on=(f.col("gl_dim_4.GL_code") == f.col("avcorp.cost_center")),
    how="left",
).drop("GL_code")

df_avcorp_accounts_dim_5 = df_avcorp_accounts_dim_4.join(
    other=df_gl_dim_trans.filter(f.col("GL_type") == 5)
    .select(gl_dim_columns)
    .withColumnsRenamed(
        {
            "GL_description": "GL_description_cost_type",
            "GL_status": "GL_status_cost_type",
        }
    )
    .alias("gl_dim_5"),
    on=(f.col("gl_dim_5.GL_code") == f.col("avcorp.cost_type")),
    how="left",
).drop("GL_code")

# COMMAND ----------

# MAGIC %md
# MAGIC # Take account of data historisation
# MAGIC The bronze will contain data over the 2 last years ; that means we do not want to loose the data accumulated so far.
# MAGIC Thus, we keep the data from the silver that is dated before the the first date of the bronze. 
# MAGIC
# MAGIC Let's take an example:
# MAGIC - "silver.finance.general_ledger_avcorp" contains 2020 and 2021 data
# MAGIC - "prod_bronze.baan_lac.glpl_latest" contains 2021 and 2022  
# MAGIC
# MAGIC --> We want the new silver to contain actual silver_2020 UNION future silver bronze 2021&2022 

# COMMAND ----------

min_date_bronze = df_avcorp_accounts_dim_5.select(f.min("first_period_date")).collect()[
    0
][0]

# COMMAND ----------

if df_existing_silver_avcorp is not None:
    df_existing_silver_avcorp_past = df_existing_silver_avcorp.filter(
        f.col("first_period_date") < min_date_bronze
    )
    df_silver = df_existing_silver_avcorp_past.unionByName(df_avcorp_accounts_dim_5)

else:
    df_silver = df_avcorp_accounts_dim_5

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables - Silver GL Avcorp

# COMMAND ----------

table_utils.save_table(dest_table=dest_table_latest, df=df_silver, mode="overwrite")
