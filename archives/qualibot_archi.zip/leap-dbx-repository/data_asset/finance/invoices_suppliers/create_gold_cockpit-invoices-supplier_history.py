# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table & Gold_Exposed for invoices cockpit history based on silver invoices history table. 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.finance.invoices_cockpit_supplier_history
# MAGIC - {PIPELINE_WRITE_ENV}_gold.finance.invoices_cockpit_supplier_history_exposed
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - {PIPELINE_READ_ENV}_silver.finance.invoices_supplier_cockpit_history_change_log
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.supplier_master_data_latest_exposed
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC NoteBook -> Create_silver_cockpit-invoices_history

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# %pip freeze

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from datetime import datetime, timedelta

from leap_utils.data_asset import payment_term, table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write reference environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table from Invoice Cockpit & Supplier Master Data

# COMMAND ----------

# Upload Invoice silver
df_invoice = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.invoices_supplier_cockpit_history_changelog"
)
# Upload Supplier Master Data
df_supplier_master_data = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed"
)
# Upload Payment terms
df_t052 = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add supplier master data

# COMMAND ----------

df_join_invoice = (
    df_invoice.alias("A")
    .join(
        df_supplier_master_data.alias("B"),
        (f.col("A.Supplier_Code") == f.col("B.Supplier_Code"))
        & (f.col("A.Company_Code") == f.col("B.Company_Code")),
        "left",
    )
    .select(
        f.col("A.*"),
        f.col("B.Supplier_name"),
        f.col("B.Supplier_country"),
        f.col("B.Spend_category"),
        f.col("B.Intercompany_flow"),
        f.col("B.Payment_Term").alias("Supplier_Payment_Term"),
        f.col("B.Incoterm_Code"),
        f.col("B.Incoterm_Detail"),
        f.col("B.Supplier_Category"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Gold Enrichment

# COMMAND ----------

# Remove Leading Zeros from Doc_Number
df_invoice = table_utils.remove_leading_zeros(df_join_invoice, ["Doc_Number"])


# Error Gestion if Payment Term is null
df_invoice = df_invoice.withColumn(
    "Payment_Term",
    f.when(f.col("Payment_Term").isNull(), f.col("Supplier_Payment_Term")).otherwise(
        f.col("Payment_Term")
    ),
)
df_invoice = df_invoice.withColumn(
    "Payment_Term",
    f.when(f.col("Payment_Term").isNull(), f.lit("Z005")).otherwise(
        f.col("Payment_Term")
    ),
)
df_invoice = df_invoice.withColumn(
    "Supplier_Payment_Term",
    f.when(f.col("Supplier_Payment_Term").isNull(), f.col("Payment_Term")).otherwise(
        f.col("Supplier_Payment_Term")
    ),
)
df_invoice = df_invoice.withColumn(
    "Supplier_Payment_Term",
    f.when(f.col("Supplier_Payment_Term").isNull(), f.lit("Z005")).otherwise(
        f.col("Supplier_Payment_Term")
    ),
)
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Determination of Invoice Status
df_invoice = df_invoice.withColumn(
    "Payment_Status",
    f.when(f.col("COCKPIT_status").cast("int") == 13, f.lit("REJECTED")).otherwise(
        f.when(f.col("Clearing_Date").isNotNull(), f.lit("PAID")).otherwise("UNPAID")
    ),
)
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Determination of Workflow Status
df_invoice = df_invoice.withColumn(
    "Workflow_Status",
    f.when((f.col("COCKPIT_status").cast("int") == 6), f.lit("IN PROGRESS")).otherwise(
        f.lit("CLOSED")
    ),
).withColumnRenamed("COCKPIT_status", "Cockpit_status")
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Error Gestion Date in cockpit
df_invoice = df_invoice.withColumn(
    "Invoice_Date", f.substring(f.col("COCKPIT_cr_timestamp"), 0, 8)
)
df_invoice = df_invoice.withColumn(
    "Invoice_Date", f.to_date(f.col("Invoice_Date"), "yyyyMMdd")
)
df_invoice = df_invoice.withColumn(
    "Invoice_Date",
    f.when(f.col("Doc_Date").isNull(), f.col("Invoice_Date")).otherwise(
        f.col("Doc_Date")
    ),
)


# Calcul payment date according Cockpit information
df_invoice = payment_term.calculate_payment_term_due_date(
    df_invoice,
    df_t052,
    df_invoice["Payment_Term"],
    df_invoice.Doc_Date,
    "Payment_Term_Due_Date",
)
# Calcul payment date according Supplier information
df_invoice = payment_term.calculate_payment_term_due_date(
    df_invoice,
    df_t052,
    df_invoice["Supplier_Payment_Term"],
    df_invoice.Doc_Date,
    "Supplier_Payment_Term_Due_Date",
)


df_invoice = df_invoice.withColumn(
    "Gap_BaseDate_DocDate",
    f.when(f.col("Doc_Date") != f.col("Base_Date"), f.lit("Yes")).otherwise(
        f.lit("No")
    ),
)
df_invoice = df_invoice.withColumn(
    "Gap_Payment_Term",
    f.when(
        f.col("Payment_Term") != f.col("Supplier_Payment_Term"), f.lit("Yes")
    ).otherwise(f.lit("No")),
)
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Calculate the number of days of permanence in the worfklow -- STILL NEEDS WORK
df_invoice = (df_invoice
    .withColumn("Workflow_Creation_Date", f.substring(f.col("COCKPIT_cr_timestamp"), 0, 8))
    .withColumn("Workflow_End_Date", f.substring(f.col("Posting_Date"), 0, 8))
    .withColumn("Workflow_Creation_Date", f.to_date(f.col("Workflow_Creation_Date"), "yyyyMMdd"))
    .withColumn("Workflow_End_Date", f.to_date(f.col("Posting_Date"), "yyyyMMdd"))
    # .withColumn("Workflow_End_Date", f.when((f.col("Workflow_End_Date") == datetime.today()) & (f.col("Payment_Status") == "PAID"), f.col("Patme")), f.current_date()
    # .withColumn("Workflow_Permanence", f.datediff(f.col("Workflow_End_Date"), f.col("Workflow_Creation_Date")))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Management wrong values
# MAGIC Delete Values in Doc Date with future or past (Previous to 2000) dates

# COMMAND ----------

df_invoice = df_invoice.withColumn(
    "Document_Date",
    f.when(
        (f.year(f.col("Doc_Date")) > datetime.today().year)
        | (f.year(f.col("Doc_Date")) < 2000),
        f.lit(None),
    ).otherwise(f.col("Doc_Date")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Managment Null value

# COMMAND ----------

# Replace all null value by Unknown
columns_to_replace = [
    "Company_Entity",
    "Incoterm_Code",
    "Incoterm_Detail",
    "Supplier_Code",
    "Supplier_name",
    "Spend_category",
    "Supplier_country",
    "Supplier_Category",
    "Document_Date",
]
replacement_value = "Unknown"
replacement_values = {col_name: replacement_value for col_name in columns_to_replace}
df_invoice = df_invoice.fillna(replacement_values)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save the gold view

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "finance"
table = "invoices_cockpit_supplier_history"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_invoice,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold exposed table

# COMMAND ----------

src_full_tablename = f"{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "COCK"
selected_columns = [col for col in df_invoice.columns if not col.startswith(Begin_By)]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
