# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for invoices based on Bronze table.
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_silver.finance.invoices_supplier_sap
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - {REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cepc_latest  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsak_latest
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsik_latest
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC Bronze ingestion SAP
# MAGIC
# MAGIC **Things to do:** 
# MAGIC
# MAGIC - Join Master Data Company
# MAGIC - Filter BSIK/BSAK on Supplier Invoices
# MAGIC - Renaming Columns
# MAGIC - Clean data
# MAGIC - Create Silver Table

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

## Upload LEAP Utils
from leap_utils.data_asset import table_utils

# Correction Amount for SAP currency with 3 digits
from leap_utils.data_asset.amount_correction import (
    create_corrected_amounts,
)  

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md 
# MAGIC #Functions

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )
# --------------------------------------------------------------------------------------------------------------
# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new
# --------------------------------------------------------------------------------------------------------------
# Rename Columns according with Imput file 'Header Renaming
def rename_sap_column_names(df: DataFrame, df_names: DataFrame) -> DataFrame:
    dfp_names = df_names.toPandas()
    dfp_names["table_field"] = dfp_names["Table_name"] + "_" + dfp_names["Field"]
    for i, r in dfp_names.iterrows():

        df = df.withColumnRenamed(
            r["table_field"], r["Business_name"].replace(" ", "_")
        )
    return df
# --------------------------------------------------------------------------------------------------------------
# Create date format columns when indicated in the headers file
def modificate_format_column(df: DataFrame, df_names: DataFrame) -> DataFrame:
    """
    Create a date column when it is asked in the column name config file
    """
    for col in df.columns:
        if df_names.filter(f.col("Business_name") == col).count() > 0:
            if (
                df_names.filter(f.col("Business_name") == col)
                .select("Format")
                .first()[0]
                == "date"
            ):
                df = df.withColumn(f"{col}", f.to_date(f.col(f"{col}"), "yyyyMMdd"))
            else:
                if (
                    df_names.filter(f.col("Business_name") == col)
                    .select("Format")
                    .first()[0]
                    == "float"
                ):
                    df = df.withColumn(f"{col}", f.col(f"{col}").cast("float"))
    return df
# --------------------------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table fom SAP & Renaming Headers 

# COMMAND ----------

# Stack BSIK / BSAK
df_BSAK_Latest = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsak_latest")
df_BSIK_Latest = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsik_latest")

CommonCols = list(set(df_BSAK_Latest.columns).intersection(df_BSIK_Latest.columns))
df_bsxk = (
    df_BSAK_Latest.select(CommonCols)
    .unionByName(df_BSIK_Latest.select(CommonCols))
    .drop("version_history", "Status", "row_nb", "selectedColumn")
)

# Renaming header starting with BSXK_
df_bsxk = table_utils.add_prefix_to_columns(df_bsxk, "BSXK")

# COMMAND ----------

# Upload Master Data Profit Center
df_cepc = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cepc_latest")
# Upload Gold Company Master Data
df_company = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Add Company Master Data

# COMMAND ----------

# Cancel Space in Company name for join
df_bsxk = df_bsxk.withColumn("BSXK_BUKRS", f.trim(f.col("BSXK_BUKRS")))

df_company = (
    df_company.withColumnRenamed("Currency", "Company_Currency")
    .withColumnRenamed("Country_Code", "Company_Land")
    .withColumnRenamed("Company_Entity", "Company_Entity_")
)

df_company = df_company.select(
    "Company",
    "Company_Description",
    "Company_Currency",
    "Company_Land",
    "Company_Entity_",
)

df_join_invoice = (
    df_bsxk.alias("A").join(
        df_company.alias("B"), (f.col("A.BSXK_BUKRS") == f.col("B.Company")), "left"
    )
).drop("Company")

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter for invoices on BSIK / BSAK

# COMMAND ----------

# Keep only Invoices
# BSCHL 31(32) -> Invoices(cancel) // BSCHL 21(22) -> Credit Note(Cancel) // HKONT start 401 -> Supplier account

df_invoice = df_join_invoice.filter(
    (f.col("BSXK_BSCHL") == "31")
    | (f.col("BSXK_BSCHL") == "21")
    | (f.col("BSXK_BSCHL") == "32")
    | (f.col("BSXK_BSCHL") == "22")
).filter((f.col("BSXK_HKONT").startswith("00401")))

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming Headers according Business entries

# COMMAND ----------

df_name_bsxk = spark.read.table("prod_bronze.headers_sap.headers_sap_business_bsxk")
# Call function Check Header files
check_schema_of_the_file(df_name_bsxk)
# Call Function Delete rows null
df_name_bsxk = delete_null_rows(df_name_bsxk)
# Call Function Rename Columns according header file
df_column_names = rename_sap_column_names(df_invoice, df_name_bsxk)
# Call Funtion Create Columns on Date format
df_invoice = modificate_format_column(df_column_names, df_name_bsxk)

# COMMAND ----------

# MAGIC %md
# MAGIC # Cleaning Data

# COMMAND ----------

# MAGIC %md
# MAGIC ### Trim + Negative Value

# COMMAND ----------

# Managment of negative value for cancellation document
df_invoice = df_invoice.withColumn(
    "Amount_Gross_Company_Currency",
    f.when(
        f.col("Debit_Credit") == "S",
        (f.col("Amount_Gross_Company_Currency") * -1).cast("double"),
    ).otherwise(f.col("Amount_Gross_Company_Currency").cast("double")),
)
df_invoice = df_invoice.withColumn(
    "Amount_Gross_Document_Currency",
    f.when(
        f.col("Debit_Credit") == "S",
        (f.col("Amount_Gross_Document_Currency") * -1).cast("double"),
    ).otherwise(f.col("Amount_Gross_Document_Currency").cast("double")),
)
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Cancel space on data
df_invoice = (
    df_invoice.withColumn("Profit_Center", f.trim(f.col("Profit_Center")))
    .withColumn("Document_Currency", f.trim(f.col("Document_Currency")))
    .withColumn("Company_Currency", f.trim(f.col("Company_Currency")))
    .withColumn("Supplier_Code", f.trim(f.col("Supplier_Code")))
)
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Managment Profit Center

# COMMAND ----------

# Managment Profit Center - Creation Company_Entity
df_invoice = df_invoice.withColumn(
    "Profit_Center",
    f.when(f.col("Profit_Center") == "", f.lit("Unknown")).otherwise(
        f.col("Profit_Center")
    ),
)
df_branch = (
    df_cepc.select("prctr", "ort01")
    .filter(f.col("ort01").isNotNull() == True)
    .dropDuplicates(["prctr"])
)
df_invoice = (
    df_invoice.join(df_branch, df_invoice.Profit_Center == df_branch.prctr, how="left")
    .withColumnRenamed("ort01", "Company_Entity")
    .drop("prctr")
)
df_invoice = df_invoice.withColumn(
    "Company_Entity",
    f.when(f.col("Company_Entity").isNull() == True, f.lit("Unknown")).otherwise(
        f.col("Company_Entity")
    ),
)
df_invoice = df_invoice.withColumn(
    "Company_Entity",
    f.when(f.col("Company_Entity") == "ND", f.lit("Unknown")).otherwise(
        f.col("Company_Entity")
    ),
)
df_invoice = df_invoice.withColumn(
    "Company_Entity",
    f.when(f.col("Company_Entity") == "Unknown", f.col("Company_Entity_")).otherwise(
        f.col("Company_Entity")
    ),
).drop("Company_Entity_")
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC # Management of Wrong SAP decimal for spécific currency (TND, JPY,...)

# COMMAND ----------

df_invoice_corrected = create_corrected_amounts(
    df_invoice, "Amount_Gross_Company_Currency", "Company_Currency"
)
df_invoice_corrected = create_corrected_amounts(
    df_invoice_corrected, "Amount_Gross_Document_Currency", "Document_Currency"
)
df_invoice_corrected = create_corrected_amounts(
    df_invoice_corrected, "Amount_VAT_Doc_Currency", "Document_Currency"
)
df_invoice_corrected = df_invoice_corrected.drop(
    "Amount_Gross_Company_Currency",
    "Amount_Gross_Document_Currency",
    "Amount_VAT_Doc_Currency",
)
df_invoice_corrected = (
    df_invoice_corrected.withColumnRenamed(
        "Amount_Gross_Company_Currency_corrected", "Amount_Gross_Company_Currency"
    )
    .withColumnRenamed(
        "Amount_Gross_Document_Currency_corrected", "Amount_Gross_Document_Currency"
    )
    .withColumnRenamed("Amount_VAT_Doc_Currency_corrected", "Amount_VAT_Doc_Currency")
)

# COMMAND ----------

# MAGIC %md 
# MAGIC # Create Silver Table

# COMMAND ----------

# Save the silver invoices table
catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "finance"
table = "invoices_sap_supplier"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_invoice_corrected,
    mode="overwrite",
    overwrite_schema=True
)
