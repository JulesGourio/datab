# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose GOLD Stack Invoices SAP
# MAGIC
# MAGIC **Description:**  
# MAGIC This data asset has been created to centralize and structure all relevant information related to SAP supplier invoices. The objective is to provide a trusted, historical, and unified view of accounts payable documents that can be reused across multiple analytical and reporting use cases.
# MAGIC
# MAGIC By consolidating data from SILVER LEAP table (invoices) and GOLD LEAP table (Supplier, Material, profit center,...), this dataset enables:
# MAGIC
# MAGIC 📑 A complete view of supplier invoices, regardless of their clearing status.
# MAGIC
# MAGIC 🔎 Tracking invoice lifecycle from posting to payment.
# MAGIC
# MAGIC 📊 Supporting financial and procurement reporting (open vs. cleared invoices, overdue items, payment performance).
# MAGIC
# MAGIC 💰 Facilitating cash flow analysis and supplier spend insights.
# MAGIC
# MAGIC 🔗 Providing a single source of truth for downstream consumers (dashboards, finance teams, audits, data science models).
# MAGIC
# MAGIC This asset is part of the gold layer in the data pipeline, ensuring data is clean, incremental, and historically traceable.  
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.invoices_supplier_all_sap`
# MAGIC
# MAGIC **Input :**  
# MAGIC - `{PIPELINE_READ_ENV}_gold.finance.invoices_supplier_sap_exposed`
# MAGIC - `{PIPELINE_READ_ENV}_gold.finance.invoices_cockpit_supplier_sap_exposed`
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC NoteBook -> create_gold_sap-invoices-supplier  
# MAGIC NoteBook -> create_gold_cockpit-invoices-supplier

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql import Window
import time
from pyspark.sql.utils import AnalysisException
from datetime import datetime, timedelta

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils, payment_term, business_rules

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Gold - Supplier Invoices
# MAGIC **df_gold_invoices** Extraction supplier invoices

# COMMAND ----------

df_gold_invoices = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.finance.invoices_supplier_sap_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Gold - Invoice Supplier Cockpit
# MAGIC **df_gold_invoices_cockpit** Extraction supplier invoices from cockpit

# COMMAND ----------

df_gold_invoices_cockpit = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.finance.invoices_cockpit_supplier_sap_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – Supplier Invoices
# MAGIC Add sources + renaming

# COMMAND ----------

df_gold_invoices_prep = df_gold_invoices.withColumn("datasource", f.lit("SAP"))
df_gold_invoices_prep = df_gold_invoices_prep.withColumnsRenamed(
    {
        "amount_gross_document_currency_item": "amount_gross_document_currency",
        "amount_gross_EUR_currency_item": "amount_gross_EUR_currency",
        "amount_net_document_currency_item": "amount_net_document_currency",
        "amount_net_EUR_currency_item": "amount_net_EUR_currency",
    }
).drop("amount_gross_company_currency")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 – Supplier Invoices Cockpit

# COMMAND ----------

df_gold_invoices_cockpit_prep = (
    df_gold_invoices_cockpit.withColumn("datasource", f.lit("Cockpit"))
    .withColumn("posting_year", f.year(f.col("document_date")))
)

# Keep only invoices in Cockpit not already treated in SAP and not rejected
df_gold_invoices_cockpit_prep = df_gold_invoices_cockpit_prep.filter(
    (f.col("sap_document_number").isNull()) & (f.col("payment_status") != "REJECTED")
).drop("sap_document_number")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 – Union supplier invoices
# MAGIC

# COMMAND ----------

df_stack_invoices = df_gold_invoices_prep.unionByName(
    df_gold_invoices_cockpit_prep, allowMissingColumns=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

# create primary key
df_invoice_end = df_stack_invoices.withColumn(
    "invoice_supplier_sap_all_ID",
    f.coalesce(
        f.col("invoice_supplier_sap_ID"), f.col("invoice_cockpit_supplier_sap_ID")
    ),
).drop("invoice_supplier_sap_ID", "invoice_cockpit_supplier_sap_ID")

df_to_check = df_invoice_end
col_pk = "invoice_supplier_sap_all_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for all invoices supplier table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="invoices_supplier_sap_all_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "finance"
DESTINATION_TABLE = "invoices_supplier_stacked_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_invoice_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_invoice_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_invoices_supplier_all_sap_pk"
TABLE_PK_COLS = "invoice_supplier_sap_all_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
