# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose SILVER Invoices supplier  
# MAGIC
# MAGIC **Description:**  
# MAGIC This data asset has been created to centralize and structure all relevant information related to SAP supplier invoices. The objective is to provide a trusted, historical, and unified view of accounts payable documents that can be reused across multiple analytical and reporting use cases.
# MAGIC
# MAGIC By consolidating data from SAP BSIK (open items), BSAK (cleared items) and RSEG (Invoice link), this dataset enables:
# MAGIC
# MAGIC 📑 A complete view of supplier invoices, regardless of their clearing status.
# MAGIC
# MAGIC 🔎 Tracking invoice lifecycle from posting to payment.
# MAGIC
# MAGIC 📊 Supporting financial and procurement reporting (open vs. cleared invoices, overdue items, payment performance).
# MAGIC
# MAGIC 💰 Facilitating cash flow analysis and supplier spend insights.
# MAGIC
# MAGIC 🔗 Providing a single source of truth for downstream consumers (dashboards, finance teams, audits, data science models).
# MAGIC
# MAGIC This asset is part of the silver layer in the data pipeline, ensuring data is clean, incremental, and historically traceable. 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - `{PIPELINE_WRITE_ENV}_silver.finance.invoices_supplier_sap`
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - `{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed` 
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.rseg_latest`    
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsak_latest`  
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsik_latest`
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC Bronze ingestion SAP
# MAGIC
# MAGIC **Things to do:** 
# MAGIC
# MAGIC - Join Master Data Company
# MAGIC - Filter BSIK/BSAK on Supplier Invoices
# MAGIC - Renaming Columns
# MAGIC - Clean data
# MAGIC - Create Silver Table

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame, Window
import time
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils, amount_correction

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### BSIK – Accounting: Secondary Index for Vendors (Open Items)
# MAGIC
# MAGIC It contains the open items for vendors. That is, all vendor invoices, credit memos, debit/credit notes that are not yet fully settled.

# COMMAND ----------

df_bsik_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsik_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BSAK – Accounting: Secondary Index for Vendors (Cleared Items)
# MAGIC
# MAGIC It contains the cleared (settled) entries for vendors. That is, invoices, credit memos, or debit/credit notes that have already been settled or cleared.

# COMMAND ----------

df_bsak_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsak_latest"
)
df_bsxk_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_bsxk"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### RSEG – Invoice Document Items
# MAGIC
# MAGIC The RSEG table stores the lines of logistics invoices (MIRO) created from goods receipts (GR – Goods Receipt) or purchase orders (PO – Purchase Orders).
# MAGIC
# MAGIC It therefore contains the details of the items of supplier billing documents within the MM → FI logistics chain.

# COMMAND ----------

df_rseg_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.rseg_latest"
)
df_rseg_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_rseg"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Company Master Data  
# MAGIC **df_gold_company**  Extraction Master Data Company 
# MAGIC

# COMMAND ----------

df_gold_company = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – BSXK
# MAGIC
# MAGIC Applies:
# MAGIC - Union BSIK/BSAK
# MAGIC - Column prefixing
# MAGIC - Business-name-based renaming
# MAGIC - Format casting based on SAP header metadata

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 1.1 – Union BSIK/BSAK + Business renaming

# COMMAND ----------

CommonCols = list(set(df_bsak_raw.columns).intersection(df_bsik_raw.columns))
df_bsxk = (
    df_bsak_raw.select(CommonCols)
    .unionByName(df_bsik_raw.select(CommonCols))
    .drop("version_history", "Status", "row_nb", "selectedColumn")
)

df_bsxk = table_utils.add_prefix_to_columns(df_bsxk, "BSXK")
# Call Function Delete rows null
df_name_bsxk = delete_null_rows(df_bsxk_header)
# Call Function Rename Columns according header file
df_column_bsxk = table_utils.rename_columns_with_sap_business_header(
    df_bsxk, df_name_bsxk
)
# Call Funtion Create Columns on Date format
df_bsxk = table_utils.cast_columns_with_sap_business_headers(
    df_column_bsxk, df_name_bsxk
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 1.2 – Filtered Invoices  
# MAGIC We keep only invoices linked to supplier account (HKONT=00401)  
# MAGIC and key account related to supplier   
# MAGIC 21 → Supplier debit (invoice)  
# MAGIC 31 → Supplier credit (invoice)  
# MAGIC 22 → Supplier debit (credit note)  
# MAGIC 32 → Supplier credit (credit note)

# COMMAND ----------

df_invoice_filtered = df_bsxk.filter(
    (f.col("BSXK_BSCHL") == "31")
    | (f.col("BSXK_BSCHL") == "21")
    | (f.col("BSXK_BSCHL") == "32")
    | (f.col("BSXK_BSCHL") == "22")
).filter((f.col("BSXK_HKONT").startswith("00401")))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 1.3 – Remove leading zero

# COMMAND ----------

df_invoice_clean = table_utils.remove_leading_zeros(
    df=df_invoice_filtered,
    column_names=[
        "document_number",
        "document_item_number",
        "account_of_balance_sheet",
        "cost_center",
        "profit_center",
        "payment_term",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 1.4 – Adjustement Quantity according debit_credit indicator

# COMMAND ----------

# Management of negative value for cancellation document
columns_to_adjust = [
    "amount_gross_company_currency",
    "amount_VAT_document_currency",
    "amount_gross_document_currency",
]

for col_name in columns_to_adjust:
    df_invoice_clean = df_invoice_clean.withColumn(
        col_name,
        f.when(f.col("debit_credit") == "S", -f.col(col_name)).otherwise(
            f.col(col_name)
        ),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 – RSEG
# MAGIC
# MAGIC Applies:
# MAGIC - Column prefixing
# MAGIC - Business-name-based renaming
# MAGIC - Format casting based on SAP header metadata

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 2.1 – Business renaming

# COMMAND ----------

df_rseg = table_utils.add_prefix_to_columns(df_rseg_raw, "RSEG")
# Call Function Delete rows null
df_name_rseg = delete_null_rows(df_rseg_header)
# Call Function Rename Columns according header file
df_column_rseg = table_utils.rename_columns_with_sap_business_header(
    df_rseg, df_name_rseg
)
# Call Funtion Create Columns on Date format
df_rseg_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_rseg, df_name_rseg
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 2.2 – Remove leading zero

# COMMAND ----------

df_rseg_clean = table_utils.remove_leading_zeros(
    df=df_rseg_renamed,
    column_names=[
        "document_number",
        "document_item_number",
        "PO_number",
        "PO_item_number",
        "material_number",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 2.3 – Adjustement Quantity according debit_credit indicator

# COMMAND ----------

# Management of negative value for cancellation document
columns_to_adjust = [
    "amount_gross_document_currency",
]

for col_name in columns_to_adjust:
    df_rseg_clean = df_rseg_clean.withColumn(
        col_name,
        f.when(f.col("debit_credit") == "H", -f.col(col_name)).otherwise(
            f.col(col_name)
        ),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 2.4 – Renaming for join with df_invoices

# COMMAND ----------

df_rseg_end = df_rseg_clean.withColumnsRenamed(
    {
        "amount_gross_document_currency": "amount_gross_document_currency_item",
        "document_item_number": "document_item_number_invoice",
    }
).drop("debit_credit")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 – Company
# MAGIC
# MAGIC - Column selection + renaming

# COMMAND ----------

df_gold_company = df_gold_company.select(
    [f.col(col).alias(col.lower()) for col in df_gold_company.columns]
)
df_gold_company = df_gold_company.select(
    f.col("company").alias("company_code"),
    "company_description",
    f.col("currency").alias("company_currency"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 – Add Material and purchase order to invoices

# COMMAND ----------

df_invoices_join = df_invoice_clean.join(
    df_rseg_end, ["document_number", "posting_year", "company_code"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 – Recalculate amount VAT

# COMMAND ----------

# First, as we don't have value of TVA on item details, 
# we calculate VAT rate based on difference between 
    # open/cleared amount w/ VAT (bsxk)
    # item details summed amount w/o VAT (rseg)
# and applied this VAT rate to item details amount
df_rseg_temp = df_rseg_end.groupBy("document_number", "posting_year").agg(
    f.sum("amount_gross_document_currency_item").alias(
        "amount_gross_document_currency_item_temp"
    )
)
df_invoices_join_tva = df_invoices_join.join(
    df_rseg_temp, ["document_number", "posting_year"], "left"
)
df_invoices_join_tva = df_invoices_join_tva.withColumn(
    "TVA_to_add",
    (
        f.col("amount_gross_document_currency")
        - f.col("amount_gross_document_currency_item_temp")
    )
    / f.col("amount_gross_document_currency_item_temp"),
)
df_invoices_join_tva = df_invoices_join_tva.withColumn(
    "amount_gross_document_currency_item_adjusted",
    f.col("amount_gross_document_currency_item")
    + f.col("amount_gross_document_currency_item") * f.col("TVA_to_add"),
)

# COMMAND ----------

# Second, we recalculate absolute amount VAT from difference between 
    # adjusted item details amount w/ VAT
    # item details amount w/o VAT
df_invoices_join_tva = (
    df_invoices_join_tva
    .withColumn(
        "amount_VAT_document_currency",
        f.coalesce(
            f.col("amount_gross_document_currency_item_adjusted") - f.col("amount_gross_document_currency_item"),
            f.lit(0)
        )
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 – Add Company information

# COMMAND ----------

df_invoice_company = df_invoices_join_tva.join(
    df_gold_company, ["company_code"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 4 – Management of Wrong SAP decimal for spécific currency (TND, JPY,...)

# COMMAND ----------

df_invoice_corrected = amount_correction.create_corrected_amounts(
    df_invoice_company, "amount_gross_company_currency", "company_currency"
)
df_invoice_corrected = amount_correction.create_corrected_amounts(
    df_invoice_corrected, "amount_gross_document_currency", "document_currency"
)
df_invoice_corrected = amount_correction.create_corrected_amounts(
    df_invoice_corrected, "amount_gross_document_currency_item", "document_currency"
)
df_invoice_corrected = amount_correction.create_corrected_amounts(
    df_invoice_corrected,
    "amount_gross_document_currency_item_adjusted",
    "document_currency",
)

df_invoice_corrected = amount_correction.create_corrected_amounts(
    df_invoice_corrected, "amount_VAT_document_currency", "document_currency"
)

df_invoice_corrected = df_invoice_corrected.drop(
    "amount_gross_company_currency",
    "amount_gross_document_currency",
    "amount_gross_document_currency_item",
    "amount_gross_document_currency_item_adjusted",
    "amount_VAT_document_currency",
)

df_invoice_corrected = df_invoice_corrected.withColumnsRenamed(
    {
        "amount_gross_company_currency_corrected": "amount_gross_company_currency",
        "amount_gross_document_currency_corrected": "amount_gross_document_currency",
        "amount_gross_document_currency_item_corrected": "amount_gross_document_currency_item",
        "amount_gross_document_currency_item_adjusted_corrected": "amount_gross_document_currency_item_adjusted",
        "amount_VAT_document_currency_corrected": "amount_VAT_document_currency",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 5 – Adjustement Amount according details per items

# COMMAND ----------

df_invoice_adjusted = df_invoice_corrected.withColumn(
    "amount_gross_document_currency_item",
    f.coalesce(
        f.col("amount_gross_document_currency_item_adjusted"),
        f.col("amount_gross_document_currency"),
    ),
).drop(
    "amount_gross_document_currency_item_adjusted",
    "amount_gross_document_currency_item_temp",
)
df_invoice_adjusted = df_invoice_adjusted.withColumn(
    "amount_gross_company_currency_item",
    f.col("amount_gross_document_currency_item")
    * (
        f.col("amount_gross_document_currency") / f.col("amount_gross_company_currency")
    ),
).drop(
    "amount_gross_company_currency",
    "amount_gross_document_currency",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 6 – Business Indicator Flags

# COMMAND ----------

df_invoice_adjusted = df_invoice_adjusted.withColumn(
    "invoice_type",
    f.when(f.col("PO_number").isNull(), f.lit("FI")).otherwise(f.lit("MM")),
).drop("debit_credit", "TVA_to_add")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 7 – Management synchro BSIK / BSAK  
# MAGIC  On SAP when an invoice is paid, rows are erase from BSIK and create in BSAK  
# MAGIC  As we extract data from SAP to our cloud, we could have some errors  
# MAGIC  So if we found entries in BSIK & BSAK, we keep only entries in BSAK

# COMMAND ----------

df_invoice_end = df_invoice_adjusted.withColumn(
    "invoice_supplier_sap_ID",
    f.concat_ws(
        "-",
        f.col("document_number"),
        f.col("posting_year"),
        f.col("document_item_number"),
        f.col("document_item_number_invoice"),
        f.col("company_code"),
    ),
)

window_spec = Window.partitionBy("invoice_supplier_sap_ID").orderBy(
    f.col("BSXK_table_name").asc()
)

df_invoice_final = (
    df_invoice_end.withColumn("row_num", f.row_number().over(window_spec))
    .filter(f.col("row_num") == 1)
    .drop("row_num")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_to_check = df_invoice_final
col_pk = "invoice_supplier_sap_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for invoice supplier table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="invoice_supplier_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "finance"
DESTINATION_TABLE = "invoices_supplier_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_invoice_final,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_invoice_final.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "silver_invoice_supplier_sap_pk"
TABLE_PK_COLS = "invoice_supplier_sap_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
