# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for invoices Cockpit based on Bronze table.
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_silver.finance.invoices_supplier_cockpit
# MAGIC   
# MAGIC **Input :**  
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitthdr_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpittitem_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpittwcs_latest # <-- For Cockpit Workflow Information
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitcwcidt_latest # <-- For Cockpit Reason Description
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitcptypt_latest # <-- For Cockpit Document Type Description
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Bronze ingestion SAP  
# MAGIC   
# MAGIC **Things to do:** 
# MAGIC
# MAGIC - Cleaning data
# MAGIC - Renaming Headers
# MAGIC - Join Company Master Data
# MAGIC - Addo information about Cockpit Workflow

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# %pip freeze

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

## Upload Leap utils
from leap_utils.data_asset import table_utils

# Correction Amount for SAP currency with 3 digits
from leap_utils.data_asset import amount_correction

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write reference environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md 
# MAGIC # Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# --------------------------------------------------------------------------------------------------------------


# Define language priority for description
def language_priority(df: DataFrame, col_partition: str) -> DataFrame:
    """Assign language priorities: 1- English, 2-French, 3-Others"""
    # First we define language priority. 1- English, 2-French, 3-German

    df = df.withColumn(
        "language_priority",
        f.when(f.col("language") == "E", 1)
        .when(f.col("language") == "F", 2)
        .otherwise(3),
    )

    # Create a window to sort descriptions based on language priority
    w = Window.partitionBy(col_partition).orderBy("language_priority")

    # Assign a row number to each row, based on language priority
    df = df.withColumn("row_num", f.row_number().over(w))

    # For each User, take only the language with highest priority (row_num == 1)
    df = df.filter(f.col("row_num") == 1).drop(
        "row_num", "language_priority", "language"
    )
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table fom SAP

# COMMAND ----------

# Invoices Cockpit Header
df_cockpit_hdr = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitthdr_latest"
)
# Invoices Cockpit Item
df_cockpit_item = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpittitem_latest"
)
# Invoices Cockpit Workflow
df_cockpit_wcs = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpittwcs_latest"
)
# Invoices Cockpit Reason Description
df_cp_desc = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitcwcidt_latest"
)
# Invoices Cockpit Document Type Description
df_typ = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitcptypt_latest"
)
# Company Master Data
df_company = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)
# Plant Master Data (to retreive delivered plant descirption)
df_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Prepare Dataset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prepare workflow description Datasets

# COMMAND ----------

# Select relevant columns for Cockpit Reason Description Dataset
df_cp_desc_selected = df_cp_desc.select(
    "wc_id", "language", "wc_name"
).withColumnRenamed("wc_name", "Workflow_Description")

# Add column "Workflow Description" in prioritized language ("English")
df_cp_desc_prepared = language_priority(df_cp_desc_selected, "wc_id")

# Select relevant columns for Cockpit Document Type Description Dataset
df_cp_doc_typ_desc = df_typ.select(
    "cp_doc_type", "language", "description"
).withColumnRenamed("description", "cp_doc_type_Description")

# Add column "cp_doc_type_Description" in prioritized language ("English")
df_cp_doc_typ_desc_prepared = language_priority(df_cp_doc_typ_desc, "cp_doc_type")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prepare dataset Cockpit Item
# MAGIC This dataset is used to add information about the Amount_Without_GR_HT of each invoice and to add to each purchase order the list of the associated purchase items.

# COMMAND ----------

# Add Amount_Without_GR_HT
df_cockpit_item_new = df_cockpit_item.withColumn(
    "item_amount_nb", f.col("item_amount").cast("float")
)
# Remove leading zeros from the column po_item
df_cockpit_item_new = table_utils.remove_leading_zeros(df_cockpit_item_new, ["po_item"])

df_cockpit_item_prepared = df_cockpit_item_new.select(
    "invoice_guid", "po_number", "po_item", "ref_doc", "item_amount_nb"
).drop_duplicates()

# Sum the amounts by invoice_guid
df_sum_amount_by_hdr = (
    df_cockpit_item_prepared.filter(f.col("ref_doc").isNull())
    .select("invoice_guid", "item_amount_nb")
    .drop_duplicates()
    .groupBy("invoice_guid")
    .agg(f.sum("item_amount_nb").alias("Amount_Without_GR_HT"))
)
# List the po_item for each invoice
df_po_items = (
    df_cockpit_item_prepared.select("invoice_guid", "po_number", "po_item")
    .drop_duplicates()
    .groupBy("invoice_guid", "po_number")
    .agg(f.collect_list("po_item").alias("po_item_list"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prepare Plant Dataset

# COMMAND ----------

# Select relevant columns from plant master data
df_plant_selected = (df_plant
    .select("Plant", "Plant_Description_new")
    .withColumnRenamed("Plant_Description_new", "Plant_Description")
    .drop_duplicates()
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Header & Item & Workflow CockPit + Renaming Headers

# COMMAND ----------

# Select relevant columns from cockpit workflow
df_cockpit_wcs_selected = df_cockpit_wcs.select(
    "invoice_guid", "wc_id", "wc_step_id", "wc_user"
)

# Join dataset to retreive info about the amount, the list of po_item and the workflow (user and step)
df_cockpit_hdr_joined = (
    df_cockpit_hdr.join(df_sum_amount_by_hdr, ["invoice_guid"], "left")
    .join(df_po_items, ["invoice_guid", "po_number"], "left")
    .join(df_cockpit_wcs_selected, ["invoice_guid"], "left")
    .join(df_cp_desc_prepared, ["wc_id"], "left")
    .join(df_cp_doc_typ_desc_prepared, ["cp_doc_type"], "left")
)

# Renaming header starting with COCKPIT_
df_cockpit_hdr_prefixed = table_utils.add_prefix_to_columns(
    df_cockpit_hdr_joined, "COCKPIT"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Add Company Master Data

# COMMAND ----------

# Cancel Space in Company name for join
df_cockpit_hdr_trimmed = df_cockpit_hdr_prefixed.withColumn(
    "COCKPIT_comp_code", f.trim(f.col("COCKPIT_comp_code"))
)

df_company_renamed = df_company.withColumnRenamed(
    "Currency", "Company_Currency"
).withColumnRenamed("Country_Code", "Company_Land")

df_company_prepared = df_company_renamed.select(
    "Company",
    "Company_Description",
    "Company_Currency",
    "Company_Land",
    "Company_Entity",
)

df_join_invoice = (
    df_cockpit_hdr_trimmed.alias("A")
    .join(
        df_company_prepared.alias("B"),
        (f.col("A.COCKPIT_comp_code") == f.col("B.Company")),
        "left",
    )
    .drop("Company")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add plant master data

# COMMAND ----------

# Add Plant description column
df_join_plant_data = (
    df_join_invoice.alias("A")
    .join(
        df_plant_selected.alias("B"),
        (f.col("A.COCKPIT_zz_werks") == f.col("B.Plant")),
        "left",
    )
    .drop("COCKPIT_zz_werks")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Cleaning Data

# COMMAND ----------

# Managment of negative value for cancellation document
df_cockpit_hdr_prepared = df_join_plant_data.withColumn(
    "COCKPIT_gross_amount",
    f.when(
        f.col("COCKPIT_cp_doc_type").cast("int") == 7,
        f.lit(-1 * f.col("COCKPIT_gross_amount")),
    ).otherwise(f.lit(f.col("COCKPIT_gross_amount"))),
)
df_cockpit_hdr_prepared = df_cockpit_hdr_prepared.withColumn(
    "COCKPIT_net_amount",
    f.when(
        f.col("COCKPIT_cp_doc_type").cast("int") == 7,
        f.lit(-1 * f.col("COCKPIT_net_amount")),
    ).otherwise(f.lit(f.col("COCKPIT_net_amount"))),
)
df_cockpit_hdr_prepared = df_cockpit_hdr_prepared.withColumn(
    "COCKPIT_Amount_Without_GR_HT",
    f.when(
        f.col("COCKPIT_cp_doc_type").cast("int") == 7,
        f.lit(-1 * f.col("COCKPIT_Amount_Without_GR_HT")),
    ).otherwise(f.lit(f.col("COCKPIT_Amount_Without_GR_HT"))),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Management Profit Center

# COMMAND ----------

# Managment Profit Center are not include in Cockpit
df_cockpit_hdr_prepared = df_cockpit_hdr_prepared.withColumn(
    "Profit_Center", f.lit("Unknown")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming Headers according Business entries

# COMMAND ----------

df_name_cockpit = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_cockpit"
)
# Call function Check Header files
table_utils.check_schema_of_the_header_file(df_name_cockpit)
# Call Function Delete rows null
df_name_cockpit = delete_null_rows(df_name_cockpit)
# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_cockpit_hdr_prepared, df_name_cockpit
)
# Call Funtion Create Columns on Date format
df_cockpit = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_cockpit
)

# Rename Columns coming from cockpittwcs
df_cockpit = (
    df_cockpit.withColumnRenamed("COCKPIT_wc_id", "Workflow_ID")
    .withColumnRenamed("COCKPIT_wc_user", "Workflow_User")
    .withColumnRenamed("COCKPIT_wc_step_id", "Workflow_step_ID")
)

# Rename Relevant Columns

df_cockpit = (
    df_cockpit.withColumnRenamed("COCKPIT_zzlit_qualite", "Invoice_Quality_Dispute")
    .withColumnRenamed("COCKPIT_zzlit_quantite", "Invoice_Quantity_Dispute")
    .withColumnRenamed("COCKPIT_cp_doc_type", "CP_Document_Type")
    .withColumnRenamed(
        "COCKPIT_cp_doc_type_Description", "CP_Document_Type_Description"
    )
    .filter(f.col("CP_Document_Type").isNotNull())
    .withColumnRenamed("COCKPIT_Workflow_Description", "Workflow_Description")
    .withColumnRenamed("COCKPIT_fi_mm_flg", "Document_FI_MM")
    .withColumnRenamed("COCKPIT_po_number", "Purchase_Order_no")
    .withColumnRenamed("COCKPIT_po_item_list", "Purchase_Order_items")
    .withColumnRenamed("COCKPIT_ref_doc_no", "Document_Ref")
    .withColumnRenamed("COCKPIT_lfsnr", "Delivery_Note_no")
)
# Save column to use in create_gold_all-invoices to filter out invoices that are already in SAP
df_cockpit = df_cockpit.withColumnRenamed("COCKPIT_sap_doc_no", "Sap_doc_no")

# COMMAND ----------

# MAGIC %md
# MAGIC # Management of Wrong SAP decimal for spécific currency (TND, JPY,...)

# COMMAND ----------

df_cockpit_corrected = amount_correction.create_corrected_amounts(
    df_cockpit, "Amount_Gross_Document_Currency", "Document_Currency"
)
df_cockpit_corrected = amount_correction.create_corrected_amounts(
    df_cockpit_corrected, "Amount_Net_Document_Currency", "Document_Currency"
)
df_cockpit_corrected = df_cockpit_corrected.drop(
    "Amount_Gross_Document_Currency",
    "Amount_Net_Document_Currency",
)
df_cockpit_corrected = df_cockpit_corrected.withColumnRenamed(
    "Amount_Gross_Document_Currency_corrected", "Amount_Gross_Document_Currency"
).withColumnRenamed(
    "Amount_Net_Document_Currency_corrected", "Amount_Net_Document_Currency"
)

# COMMAND ----------

# MAGIC %md 
# MAGIC # Create Silver Table

# COMMAND ----------

# Save the silver invoices Cockpit table
catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "finance"
table = "invoices_supplier_cockpit"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_cockpit_corrected,
    mode="overwrite",
    overwrite_schema=True,
)
