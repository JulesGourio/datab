# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to stack and match all invoices based on sap invoices & cockpit invoices. 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.finance.invoices_supplier_all
# MAGIC
# MAGIC **Input :**  
# MAGIC - {PIPELINE_READ_ENV}_gold.finance.invoices_sap_supplier_exposed
# MAGIC - {PIPELINE_READ_ENV}_gold.finance.invoices_cockpit_supplier_exposed
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC NoteBook -> create_gold_sap-invoices-supplier 
# MAGIC NoteBook -> create_gold_cockpit-invoices-supplier
# MAGIC
# MAGIC **Things to do:** 
# MAGIC - Add Data Source
# MAGIC - Add Posting year
# MAGIC - Union all invoices
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md 
# MAGIC # Process

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read reference environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get read pipeline environment variable
dbutils.widgets.text("pipeline_read_env", "prod")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md 
# MAGIC #Upload Data invoice / Invoice cockpit

# COMMAND ----------

df_sap_invoices = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.finance.invoices_sap_supplier_exposed"
)
df_sap_invoices = df_sap_invoices.withColumn("DataSource", f.lit("SAP"))

df_cockpit_invoices = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.finance.invoices_cockpit_supplier_exposed"
)
df_cockpit_invoices = df_cockpit_invoices.withColumn(
    "DataSource", f.lit("Cockpit")
).withColumn("Posting_Year", f.year(f.col("Doc_Date")))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cleaning Data from  table

# COMMAND ----------

# Delete cockpit invoices that are already in SAP (this operation before 15.01.2025 was done in create_gold_cockpit-invoice-supplier"
df_cockpit_invoices = df_cockpit_invoices.filter(f.col("Sap_doc_no").isNull()).drop(
    "Sap_doc_no"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Union All Invoices

# COMMAND ----------

df_stack_invoices = df_sap_invoices.unionByName(
    df_cockpit_invoices, allowMissingColumns=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Create Gold Stack & Match Invoices

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "finance"
table = "invoices_supplier_all"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_stack_invoices,
    mode="overwrite",
    overwrite_schema=True,
)
