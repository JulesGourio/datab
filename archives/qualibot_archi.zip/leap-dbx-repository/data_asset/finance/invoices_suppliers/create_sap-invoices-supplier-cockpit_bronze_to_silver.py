# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose SILVER Invoices supplier from Cockpit   
# MAGIC
# MAGIC **Description:**  
# MAGIC This data asset has been created to centralize and structure all relevant information related to SAP supplier invoices from cockpit. The objective is to provide a trusted, historical, and unified view of accounts payable documents that can be reused across multiple analytical and reporting use cases.
# MAGIC
# MAGIC By consolidating data from SAP COCKPIT (THDR,TITEM,TWCS,...) this dataset enables:
# MAGIC
# MAGIC 📑 A complete view of supplier invoices, regardless of their clearing status.
# MAGIC
# MAGIC 🔎 Tracking invoice lifecycle from posting to payment.
# MAGIC
# MAGIC 📊 Supporting financial and procurement reporting (open vs. cleared invoices, overdue items, payment performance).
# MAGIC
# MAGIC 💰 Facilitating cash flow analysis and supplier spend insights.
# MAGIC
# MAGIC 🔗 Providing a single source of truth for downstream consumers (dashboards, finance teams, audits, data science models).
# MAGIC
# MAGIC This asset is part of the silver layer in the data pipeline, ensuring data is clean, incremental, and historically traceable. 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - `{PIPELINE_WRITE_ENV}_silver.finance.invoices_cockpit_supplier_sap`
# MAGIC   
# MAGIC **Input :**  
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitthdr_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpittitem_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpittwcs_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitcwcidt_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitcptypt_latest`
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Bronze ingestion SAP  
# MAGIC   
# MAGIC **Things to do:** 
# MAGIC
# MAGIC - Cleaning data
# MAGIC - Renaming Headers
# MAGIC - Addo information about Cockpit Workflow

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

import time
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils, amount_correction

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# --------------------------------------------------------------------------------------------------------------
# Define language priority for description
def language_priority(df: DataFrame, col_partition: str) -> DataFrame:
    """Assign language priorities: 1- English, 2-French, 3-Others"""
    # First we define language priority. 1- English, 2-French, 3-German

    df = df.withColumn(
        "language_priority",
        f.when(f.col("language") == "E", 1)
        .when(f.col("language") == "F", 2)
        .otherwise(3),
    )

    # Create a window to sort descriptions based on language priority
    w = Window.partitionBy(col_partition).orderBy("language_priority")

    # Assign a row number to each row, based on language priority
    df = df.withColumn("row_num", f.row_number().over(w))

    # For each User, take only the language with highest priority (row_num == 1)
    df = df.filter(f.col("row_num") == 1).drop(
        "row_num", "language_priority", "language"
    )
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### COCKPIT_THDR – Process Director Accounts Payable (items)
# MAGIC
# MAGIC It is a standard (or custom) SAP database table intended to store item-level data associated with cockpit-related processes within a given module (e.g., Process Director, Cockpit framework).

# COMMAND ----------

df_cockpit_hdr = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitthdr_latest"
)
df_cockpit_name = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_cockpit"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### COCKPIT_TITEM – Process Director Accounts Payable (headers)
# MAGIC
# MAGIC it is a standard SAP database table used to store header-level data for applications (such as EDI Cockpit, Web Board, Info Mail) that do not have a directly accessible view in the SAP GUI.

# COMMAND ----------

df_cockpit_item = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpittitem_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### COCKPIT_TWCS – Invoices Cockpit Workflow
# MAGIC
# MAGIC It is a custom SAP database table used within the [Module/Process Name, e.g. Cockpit Workflow or Process Director].
# MAGIC The table stores [item-level data / workflow step details / statuses], and is typically linked to the header table COCKPIT_THDR to represent the header-line relationship

# COMMAND ----------

df_cockpit_wcs = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpittwcs_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### COCKPIT_CWCIDT – Invoices Cockpit Reason Description
# MAGIC It is a custom SAP database stores descritpion of the reason code used in the [Module/Process Name, e.g. Cockpit Workflow or Process Director].

# COMMAND ----------

# Invoices Cockpit Reason Description
df_cockpit_desc = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitcwcidt_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### COCKPIT_CPTYPT – Invoices Cockpit Document Type Description
# MAGIC It is a custom SAP database stores description of the document type code used in the [Module/Process Name, e.g. Cockpit Workflow or Process Director].

# COMMAND ----------

df_cockpit_type = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitcptypt_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – Prepare workflow description

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 1.1 – Cockpit Reason Description

# COMMAND ----------

# Select relevant columns for Cockpit Reason Description Dataset
df_cockpit_desc_selected = df_cockpit_desc.select(
    "wc_id", "language", f.col("wc_name").alias("Workflow_Description")
)

# Add column "Workflow Description" in prioritized language ("English")
df_cockpit_desc_end = language_priority(df_cockpit_desc_selected, "wc_id")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 1.2 – Cockpit Document Type Description

# COMMAND ----------

# Select relevant columns for Cockpit Document Type Description Dataset
df_cockpit_type_desc = df_cockpit_type.select(
    "cp_doc_type", "language", f.col("description").alias("cp_doc_type_Description")
)

# Add column "cp_doc_type_Description" in prioritized language ("English")
df_cockpit_type_end = language_priority(df_cockpit_type_desc, "cp_doc_type")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 - Cockpit Item
# MAGIC This dataset is used to add information about the Amount_Without_GR_HT of each invoice and to add to each purchase order the list of the associated purchase items.

# COMMAND ----------

df_cockpit_item_selected = df_cockpit_item.select(
    "invoice_guid",
    "po_number",
    f.col("po_item").alias("po_item_list"),
    "ref_doc",
    "material",
    f.col("item_amount").cast("double").alias("amount_without_GR_HT"),
).drop_duplicates()

# Remove leading zeros from the column po_item
df_cockpit_item_ldz = table_utils.remove_leading_zeros(
    df_cockpit_item_selected, ["po_number", "po_item_list"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 - Cockpit workflow

# COMMAND ----------

# Select relevant columns from cockpit workflow
df_cockpit_wcs_end = df_cockpit_wcs.select(
    "invoice_guid", "wc_id", "wc_step_id", "wc_user"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 – Join Cockpit tables and renaming headers

# COMMAND ----------

# Join dataset to retreive info about the amount, the list of po_item and the workflow (user and step)
df_cockpit_hdr_joined = (
    df_cockpit_hdr.join(df_cockpit_item_ldz, ["invoice_guid", "PO_number"], "left")
    .join(df_cockpit_wcs_end, ["invoice_guid"], "left")
    .join(df_cockpit_desc_end, ["wc_id"], "left")
    .join(df_cockpit_type_end, ["cp_doc_type"], "left")
)
# Keep only entries where cp_doc_type is not null
df_cockpit_hdr_joined = df_cockpit_hdr_joined.filter(f.col("cp_doc_type").isNotNull())

# Renaming header starting with COCKPIT_
df_cockpit_hdr_prefixed = table_utils.add_prefix_to_columns(
    df_cockpit_hdr_joined, "COCKPIT"
)
df_cockpit_hdr_prefixed = df_cockpit_hdr_prefixed.withColumnRenamed(
    "COCKPIT_material", "material_number"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 – Managment of negative value for cancellation document

# COMMAND ----------

df_cockpit_hdr_corrected = df_cockpit_hdr_prefixed.withColumn(
    "COCKPIT_gross_amount",
    f.when(
        f.col("COCKPIT_cp_doc_type").cast("int") == 7,
        f.lit(-1 * f.col("COCKPIT_gross_amount")),
    ).otherwise(f.lit(f.col("COCKPIT_gross_amount"))),
)
df_cockpit_hdr_corrected = df_cockpit_hdr_corrected.withColumn(
    "COCKPIT_net_amount",
    f.when(
        f.col("COCKPIT_cp_doc_type").cast("int") == 7,
        f.lit(-1 * f.col("COCKPIT_net_amount")),
    ).otherwise(f.lit(f.col("COCKPIT_net_amount"))),
)
df_cockpit_hdr_corrected = df_cockpit_hdr_corrected.withColumn(
    "COCKPIT_amount_without_GR_HT",
    f.when(
        f.col("COCKPIT_cp_doc_type").cast("int") == 7,
        f.lit(-1 * f.col("COCKPIT_amount_without_GR_HT")),
    ).otherwise(f.lit(f.col("COCKPIT_amount_without_GR_HT"))),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 – Renaming Headers according Business entries

# COMMAND ----------

# Call Function Delete rows null
df_cockpit_name = delete_null_rows(df_cockpit_name)
# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_cockpit_hdr_corrected, df_cockpit_name
)
# Call Funtion Create Columns on Date format
df_cockpit_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_cockpit_name
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 4 – Management of Wrong SAP decimal for spécific currency (TND, JPY,...)

# COMMAND ----------

df_cockpit_corrected = amount_correction.create_corrected_amounts(
    df_cockpit_renamed, "amount_gross_document_currency", "document_currency"
)
df_cockpit_corrected = amount_correction.create_corrected_amounts(
    df_cockpit_corrected, "amount_net_document_currency", "document_currency"
)
df_cockpit_corrected = df_cockpit_corrected.drop(
    "amount_gross_document_currency",
    "amount_net_document_currency",
)
df_cockpit_corrected = df_cockpit_corrected.withColumnsRenamed(
    {
        "amount_gross_document_currency_corrected": "amount_gross_document_currency",
        "amount_net_document_currency_corrected": "amount_net_document_currency",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 5 – Cleaning Base

# COMMAND ----------

# Sometimes Workflows could be affected to several users by mistake
# We keep only the first one to be sure that we are not going to duplicate lines
W0 = Window.partitionBy("ckpit_ID").orderBy("workflow_user")

df_cockpit_corrected = (
    df_cockpit_corrected.withColumn("row_num", f.row_number().over(W0))
    .filter(f.col("row_num") == 1)
    .drop("row_num")
)

# Remove Leading Zeros from document_number
df_cockpit_corrected = table_utils.remove_leading_zeros(
    df_cockpit_corrected, ["document_number", "material_number"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

# create primary key
df_invoice_cockpit_end = df_cockpit_corrected.withColumn(
    "invoices_cockpit_supplier_sap_ID",
    f.concat_ws("_", f.col("ckpit_ID"), f.col("cockpit_version")),
)

df_to_check = df_invoice_cockpit_end
col_pk = "invoices_cockpit_supplier_sap_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for invoice supplier cockpit table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="invoices_cockpit_supplier_sap_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "finance"
DESTINATION_TABLE = "invoices_cockpit_supplier_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_invoice_cockpit_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_invoice_cockpit_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "silver_invoices_cockpit_supplier_sap_ID_pk"
TABLE_PK_COLS = "invoices_cockpit_supplier_sap_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
