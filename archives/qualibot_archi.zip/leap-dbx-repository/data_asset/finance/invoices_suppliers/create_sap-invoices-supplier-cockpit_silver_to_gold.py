# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose GOLD Invoices supplier from Cockpit   
# MAGIC
# MAGIC **Description:**  
# MAGIC This data asset has been created to centralize and structure all relevant information related to SAP supplier invoices from cockpit. The objective is to provide a trusted, historical, and unified view of accounts payable documents that can be reused across multiple analytical and reporting use cases.
# MAGIC
# MAGIC By consolidating data from silver LEAP Table (invoice cockpit) and GOLD LEAP Table (Supplier, material, profit center, etc...), this dataset enables:
# MAGIC
# MAGIC 📑 A complete view of supplier invoices, regardless of their clearing status.
# MAGIC
# MAGIC 🔎 Tracking invoice lifecycle from posting to payment.
# MAGIC
# MAGIC 📊 Supporting financial and procurement reporting (open vs. cleared invoices, overdue items, payment performance).
# MAGIC
# MAGIC 💰 Facilitating cash flow analysis and supplier spend insights.
# MAGIC
# MAGIC 🔗 Providing a single source of truth for downstream consumers (dashboards, finance teams, audits, data science models).
# MAGIC
# MAGIC This asset is part of the gold layer in the data pipeline, ensuring data is clean, incremental, and historically traceable. 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.invoices_cockpit_supplier_sap`  
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.invoices_cockpit_supplier_sap_exposed`  
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - `{PIPELINE_READ_ENV}_silver.finance.invoices_supplier_cockpit`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.manual_input.mapping_sites_division_region`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.manual_input.mapping_plant_site`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest`
# MAGIC - `{REFERENCE_READ_ENV}_gold.master_data.supplier_exposed`
# MAGIC - `{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed`
# MAGIC - `{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed` 
# MAGIC - `{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed` 
# MAGIC - `{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from datetime import datetime, timedelta
import time
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils, payment_term, business_rules

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### T052 – Payment Term Condition
# MAGIC

# COMMAND ----------

# Upload Payment terms
df_t052_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - Manual Mapping division site  
# MAGIC **df_bronze_site** Mapping site-division-region  
# MAGIC **df_bronze_site_plant** Mapping site-plant 

# COMMAND ----------

df_bronze_site = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region"
)
df_bronze_site_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_plant_site"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### SILVER - Invoice Supplier Cockpit 
# MAGIC **df_silver_invoice_cockpit**  
# MAGIC

# COMMAND ----------

df_silver_invoice_cockpit = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.invoices_cockpit_supplier_sap"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Supplier Master Data  
# MAGIC **df_gold_supplier**  Extraction Master Data Supplier 

# COMMAND ----------

df_gold_supplier = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.supplier_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Company Master Data  
# MAGIC **df_gold_company**  Extraction Master Data Company

# COMMAND ----------

df_gold_company = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Plant Master Data  
# MAGIC **df_gold_plant**  Extraction Master Data Company

# COMMAND ----------

df_gold_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Profit Center
# MAGIC **df_gold_profitcenter** profit center master data

# COMMAND ----------

df_gold_profitcenter = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Material by plant
# MAGIC **df_gold_material** Extraction master data material

# COMMAND ----------

df_gold_material = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – Supplier master data
# MAGIC
# MAGIC selection & renaming

# COMMAND ----------

df_gold_supplier = df_gold_supplier.select(
    "supplier_code",
    "supplier_name",
    "supplier_country",
    "supplier_city",
    "supplier_category",
    "spend_category",
    f.col("payment_term").alias("supplier_payment_term"),
    "company_code",
    "intercompany_flow",
    "is_supplier_a_distributor",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 – Company master data

# COMMAND ----------

df_gold_company = df_gold_company.toDF(*[c.lower() for c in df_gold_company.columns])

df_gold_company = df_gold_company.select(
    f.col("company").alias("company_code"),
    f.col("company_description"),
    f.col("country").alias("company_country"),
    f.col("currency").alias("company_currency"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 – Plant master data  
# MAGIC We keep only company with only one plant affected

# COMMAND ----------

df_gold_plant = df_gold_plant.toDF(*[c.lower() for c in df_gold_plant.columns])
df_gold_plant_selected = df_gold_plant.select(
    f.col("plant").alias("plant_master"), f.col("company").alias("company_code")
)
df_gold_plant_temp = (
    df_gold_plant_selected.groupBy("company_code")
    .count()
    .filter("count = 1")
    .drop("count")
)
df_gold_plant_end = df_gold_plant_selected.join(
    df_gold_plant_temp, "company_code", "inner"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 4 - Material master data

# COMMAND ----------

window_spec = Window.partitionBy("material_number", "plant").orderBy("mrp_controller")

df_gold_material = (
    df_gold_material.withColumn("row_num", f.row_number().over(window_spec))
    .filter(f.col("row_num") == 1)
    .select(
        "material_number",
        "plant",
        "decopling_point",
        "mrp_controller",
        "profit_center",
        "material_description",
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 5 - Profit Center

# COMMAND ----------

df_gold_profitcenter = df_gold_profitcenter.toDF(
    *[c.lower() for c in df_gold_profitcenter.columns]
)

df_gold_profitcenter_selected = df_gold_profitcenter.select(
    f.col("profit_center_short").alias("profit_center"),
    f.col("short_description").alias("profit_center_description"),
    f.col("customer_group"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 6 - Select and translate Site mapping

# COMMAND ----------

df_bronze_site = (
    df_bronze_site.select(f.col("site").alias("stock_site"), "division", "region")
    .distinct()
    .withColumn(
        "stock_site", f.translate("stock_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
    )
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 – Add plant for invoice without plant in cockpit
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 1.1 – Add plant from plant master data 
# MAGIC Only when we have one plant for one company associated

# COMMAND ----------

df_invoices_plant = df_silver_invoice_cockpit.join(
    df_gold_plant_end, ["company_code"], "left"
)
df_invoices_plant = df_invoices_plant.withColumn(
    "plant", f.coalesce(f.col("plant"), f.col("plant_master"))
).drop("plant_master")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 1.2 – Add plant from supplier master data

# COMMAND ----------

df_invoices_supplier = df_invoices_plant.join(
    df_gold_supplier, ["supplier_code", "company_code"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 1.3 – Add profit center from material master data

# COMMAND ----------

df_invoice_material = df_invoices_supplier.join(
    df_gold_material, ["material_number", "plant"], "left"
)

# COMMAND ----------

# This cell assigns a plant code to each row in df_deposit_supplier based on business rules:
# - For suppliers from Mexico or the US, assigns plant 4000 for company LATE and 2300 for company LFR1.
# - For company LATE, assigns plant 1000.
# - For company LTN1, assigns plant 2110.
# - For companies starting with LFR or equal to LDEV, assigns plant 2000.
# - Otherwise, assigns "TBD".
# The final plant code is set to the original plant if present, otherwise to the calculated value.

list_lmx_country = ["MX", "US"]
# Rules for LATE COMPANY
df_invoices_supplier = df_invoice_material.withColumn(
    "plant_temp",
    f.when(
        (f.col("supplier_country").isin(list_lmx_country))
        & (f.col("company_code") == "LATE"),
        f.lit("4000"),
    )
    .when(
        (f.col("supplier_country").isin(list_lmx_country))
        & (f.col("company_code") == "LFR1"),
        f.lit("2300"),
    )
    .when(f.col("company_code") == "LATE", f.lit("1000"))
    .when(f.col("company_code") == "LTN1", f.lit("2100"))
    .when(f.col("company_code") == "LFR1", f.lit("2000"))
    .otherwise(f.lit("1000")),
)
# ----------------------------------------------------------------------------------
df_invoices_supplier = df_invoices_supplier.withColumn(
    "plant", f.coalesce(f.col("plant"), f.col("plant_temp"))
).drop("plant_temp")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 – Add Company information

# COMMAND ----------

# Management of missing information in cockpit
df_invoice_company = df_invoices_supplier.withColumn(
    "company_code",
    f.when(f.col("company_code").isNull(), f.lit("LATE")).otherwise(
        f.col("company_code")
    ),
)
df_invoice_company = df_invoice_company.join(df_gold_company, ["company_code"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 4 – Division / Region / Site Classification  
# MAGIC Target is to determine Stock_site according case here under
# MAGIC  - Case 1 : Determination with 1:1 Site / plant (only one site is linked to a plant)
# MAGIC  - Case 2 : Determination with Decopling point and MRP Controller
# MAGIC  - Case 3 : Determination with profit center affectation 
# MAGIC The finale affectation is done by respectinf the priority of case(1.2.3).  
# MAGIC If nothing is found "LAT - Mach1" is set by default  

# COMMAND ----------

# ----------------------------------------------------------------------------------
# We keep only in the mapping plant code when there are associated to a unique site
window_plant = Window.partitionBy("plant_code")
df_bronze_site_plant = (
    df_bronze_site_plant.withColumn("_tmp_count", f.count("*").over(window_plant))
    .filter(f.col("_tmp_count") == 1)
    .drop("_tmp_count")
).withColumnsRenamed({"plant_code": "plant", "site": "_tmp_site_case_1"})
# ----------------------------------------------------------------------------------
df_gold_profitcenter = df_gold_profitcenter.select(
    f.col("profit_center_short").alias("profit_center"),
    f.col("pc_attributed_site").alias("_tmp_site_case_3"),
).filter(f.col("_tmp_site_case_3").startswith("LATE"))

# COMMAND ----------

# Determination of Branch
# -----------------------------------------------------------------
# Determination 1:1 relationship
df_material_w_site = df_invoice_company.join(df_bronze_site_plant, ["plant"], "left")
# Determination DES
df_material_w_site = df_material_w_site.join(
    df_gold_profitcenter, ["profit_center"], "left"
)
# Determination dispatch plant 1000 and 2000

df_material_w_site = df_material_w_site.withColumn(
    "_tmp_site_case_2",
    f.when(
        (f.col("plant") == "1000") & (f.col("decopling_point").startswith("MON")),
        f.lit("LATE - Montredon"),
    )
    .when(
        ((f.col("plant") == "1000") | (f.col("plant") == "2000"))
        & (f.col("mrp_controller").startswith("DE")),
        f.lit("LATE-LFR1 - Labege Systems"),
    )
    .when(
        (f.col("plant") == "1000") & (f.col("decopling_point").startswith("GMT")),
        f.lit("LATE - Gimont"),
    )
    .when(
        (f.col("plant") == "1000") & (f.col("decopling_point").startswith("HUB")),
        f.lit("LATE - Gabardie"),
    )
    .when(
        (f.col("plant") == "1000") & (f.col("_tmp_site_case_3").isNull()),
        f.lit("LATE - Mach1"),
    )
    .when(
        (f.col("plant") == "2000") & (f.col("_tmp_site_case_3").isNull()),
        f.lit("LFR1 - Labège"),
    )
    .otherwise(f.lit(None)),
)

df_material_w_site = df_material_w_site.withColumn(
    "stock_site",
    f.coalesce(
        f.col("_tmp_site_case_1"),
        f.col("_tmp_site_case_2"),
        f.col("_tmp_site_case_3"),
        f.lit("LATE - Mach1"),
    ),
)
df_material_w_site = df_material_w_site.select(
    [col for col in df_material_w_site.columns if not col.startswith("_tmp")]
)
# -----------------------------------------------------------------
# Remove all accents in site so as to join correctly
df_material_w_site = df_material_w_site.withColumn(
    "stock_site", f.translate("stock_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
)

df_material_w_site = df_material_w_site.join(
    df_bronze_site, ["stock_site"], "left"
).drop("decopling_point", "mrp_controller")
df_material_w_site = df_material_w_site.withColumnRenamed("stock_site", "site")

# Quality check: all lines must have a site
if df_material_w_site.where(f.col("site").isNull()).count() > 0:
    raise Exception("At least 1 row with blank site")
# -----------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 5 – Add Intercompany Flow

# COMMAND ----------

df_invoice_interco = business_rules.add_intercompany_column(
    df_material_w_site, "company_code", "intercompany_flow"
).drop("intercompany_flow")
# Specific case of LATFI
df_invoice_interco = df_invoice_interco.withColumn(
    "intercompany",
    f.when(f.col("supplier_code") == "F08875", f.lit("Inter-co")).otherwise(
        f.col("intercompany")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 6 – Add Profit Center information

# COMMAND ----------

df_invoice_pf = df_invoice_interco.join(
    df_gold_profitcenter_selected, ["profit_center"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 7 – Managment of Workflow status

# COMMAND ----------

# Determination of Invoice Status
df_invoice_workflow = df_invoice_pf.withColumn(
    "payment_status",
    f.when(f.col("COCKPIT_status").cast("int") == 13, f.lit("REJECTED")).otherwise(
        f.when(f.col("clearing_date").isNotNull(), f.lit("PAID")).otherwise("UNPAID")
    ),
)
# Determination of Workflow Statusf
df_invoice_workflow = df_invoice_workflow.withColumn(
    "workflow_status",
    f.when((f.col("COCKPIT_status").cast("int") == 6), f.lit("IN PROGRESS")).otherwise(
        f.lit("CLOSED")
    ),
)
#

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 8 – Management bad entries in cockpit

# COMMAND ----------

# Error Gestion Date in cockpit
df_invoice_dte = df_invoice_workflow.withColumn(
    "invoice_creation_date",
    f.to_date(f.substring(f.col("COCKPIT_cr_timestamp"), 0, 8), "yyyyMMdd"),
)
df_invoice_dte = df_invoice_dte.withColumn(
    "document_date",
    f.when(
        (f.col("document_date").isNull())
        | (f.col("document_date") == "")
        | (f.year(f.col("document_date")) > datetime.today().year)
        | (f.year(f.col("document_date")) < 2000),
        f.col("invoice_creation_date"),
    ).otherwise(f.col("document_date")),
)
df_invoice_dte = df_invoice_dte.withColumn(
    "base_date",
    f.when(
        (f.year(f.col("base_date")) > datetime.today().year)
        | (f.year(f.col("base_date")) < 2000),
        f.col("invoice_creation_date"),
    ).otherwise(f.col("base_date")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 9 – Add Due date according payment term

# COMMAND ----------

# Error Gestion if Payment Term is null
df_invoice = df_invoice_dte.withColumn(
    "payment_term",
    f.coalesce(f.col("payment_term"), f.col("supplier_payment_term"), f.lit("Z005")),
)

df_invoice = df_invoice.withColumn(
    "supplier_payment_term",
    f.coalesce(f.col("supplier_payment_term"), f.col("payment_term"), f.lit("Z005")),
)

# COMMAND ----------

# Calcul payment due date from Base_Date and the payment term
df_invoice = payment_term.calculate_payment_term_due_date(
    df_invoice,
    df_t052_raw,
    df_invoice["payment_term"],
    df_invoice.base_date,
    "payment_term_due_date",
)
#  Calcul supplier payment due date from Doc_Date and Supplier payment term
df_invoice = payment_term.calculate_payment_term_due_date(
    df_invoice,
    df_t052_raw,
    df_invoice["supplier_payment_term"],
    df_invoice.document_date,
    "supplier_payment_term_due_date",
)

df_invoice = df_invoice.withColumn(
    "is_gap_basedate_documentdate",
    f.when(f.col("document_date") != f.col("base_date"), f.lit(True)).otherwise(
        f.lit(False)
    ),
)
df_invoice = df_invoice.withColumn(
    "is_gap_payment_term",
    f.when(
        f.col("payment_term") != f.col("supplier_payment_term"), f.lit(True)
    ).otherwise(f.lit(False)),
)
# Calcul_due_date
df_invoice = df_invoice.withColumn(
    "due_date",
    f.when(f.col("payment_status") == "PAID", f.col("clearing_date")).otherwise(
        f.col("payment_term_due_date")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 10 – Currency Conversion
# MAGIC
# MAGIC This transformation converts key monetary fields from the document currency to a common target currency (EUR), using the appropriate rate type (`Budget`) and the PO document date as the reference for conversion.

# COMMAND ----------


# Determination of budget_currency_conversion_date
today_str = datetime.today().strftime("%Y-%m-%d")
today = f.lit(today_str)
two_days_ago = f.lit((datetime.today() - timedelta(days=2)).strftime("%Y-%m-%d"))
df_invoice_date = df_invoice.withColumn(
    "spot_currency_conversion_date",
    f.when(f.col("document_date") > today, two_days_ago).otherwise(
        f.col("document_date")
    ),
).withColumn(
    "spot_currency_conversion_date_source",
    f.when(
        f.col("spot_currency_conversion_date") == two_days_ago,
        f.lit("today - 2 days"),
    ).otherwise(f.lit("document_date")),
)

# COMMAND ----------

df_converted_currency = table_utils.currency_conversion(
    df=df_invoice_date,
    document_currency_column=df_invoice_date.document_currency,
    rate_types=["Spot"],
    rate_dates=[df_invoice_date.spot_currency_conversion_date],
    target_currency_value="EUR",
    document_amounts=[
        df_invoice_date.amount_gross_document_currency,
        df_invoice_date.amount_net_document_currency,
    ],
)
# Renaming Columns Price
df_converted_currency_end = df_converted_currency.withColumnsRenamed(
    {
        "amount_gross_document_currency_from_document_currency_to_EUR_in_spot_rate_at_spot_currency_conversion_date": "amount_gross_EUR_currency",
        "amount_net_document_currency_from_document_currency_to_EUR_in_spot_rate_at_spot_currency_conversion_date": "amount_net_EUR_currency",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 11 – Cleaning Base

# COMMAND ----------

df_invoice_cleaned = table_utils.remove_leading_zeros(
    df=df_converted_currency_end,
    column_names=[
        "document_number",
    ],
)
df_invoice_cleaned = df_invoice_cleaned.withColumn(
    "year_due_date", f.year(f.col("due_date"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

# create primary key
df_invoice_end = df_invoice_cleaned.withColumn(
    "invoice_cockpit_supplier_sap_ID",
    f.concat_ws("_", f.col("ckpit_ID"), f.col("cockpit_version")),
)

df_to_check = df_invoice_end
col_pk = "invoice_cockpit_supplier_sap_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for invoice supplier cockpit table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="invoices_cockpit_supplier_sap_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "finance"
DESTINATION_TABLE = "invoices_cockpit_supplier_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_invoice_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_invoice_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_invoices_cockpit_supplier_sap_pk"
TABLE_PK_COLS = "invoice_cockpit_supplier_sap_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – Exposed Table View

# COMMAND ----------

dest_full_tablename = f"{DESTINATION_TABLE_FULL_PATH}_exposed"
Begin_By = [
    "COCKPIT",
]

selected_columns = [
    col
    for col in df_invoice_end.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename,
    select_statement,
    replace_view=True,
)

log.info(f"The table view {dest_full_tablename} has been successfully created")
