# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for invoices Cockpit based on Bronze table.
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_silver.finance.invoices_supplier_cockpit
# MAGIC   
# MAGIC **Input :**  
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitthdr_stack
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpittitem_stack
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpittwcs_stack
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitcwcidt_latest # <-- For Cockpit Reason Description
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitcptypt_latest # <-- For Cockpit Document Type Description
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Bronze ingestion SAP  
# MAGIC   
# MAGIC **Things to do:** 
# MAGIC
# MAGIC - Cleaning data
# MAGIC - Renaming Headers
# MAGIC - Join Company Master Data

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# %pip freeze

# COMMAND ----------

import re
import os
import logging
import time
import datetime
from typing import List, Tuple

import pyspark.sql.functions as f
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from pyspark.sql.types import StructType

from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils, history_changelog
from leap_utils.data_asset import  amount_correction
from leap_utils.ingestion import ingestion_utils
from ingestion.airsupply import airsupply_ingestion_utils

LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write reference environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Changelog variables
# MAGIC new_schema (default: False) -> When new schema is coming for first time, widget needs to be specified to True to recompute FULL history change log.
# MAGIC force_reinitialization (default: False) -> If user wants to force reinitialize, the FULL history change log will be recompute.
# MAGIC skip_task (default: False) -> If user wants to skip task without failing entire job, set skip_task to True

# COMMAND ----------

dbutils.widgets.text("new_schema", "False")
new_schema = dbutils.widgets.get("new_schema").lower() == "true"

dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = dbutils.widgets.get("force_reinitialization").lower() == "true"

dbutils.widgets.text("skip_task", "False")
skip_task = dbutils.widgets.get("skip_task").lower() == "true"

# COMMAND ----------

if skip_task:
    dbutils.notebook.exit("skip task")

# COMMAND ----------

# MAGIC %md 
# MAGIC # Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# --------------------------------------------------------------------------------------------------------------

# Define language priority for description
def language_priority(df: DataFrame, col_partition: str) -> DataFrame:
    """Assign language priorities: 1- English, 2-French, 3-Others"""
    # First we define language priority. 1- English, 2-French, 3-German

    df = (df
        .withColumn("language_priority",
            f.when(f.col("language") == "E", 1)
            .when(f.col("language") == "F", 2)
            .otherwise(3)
        )
    )

    # Create a window to sort descriptions based on language priority
    w = Window.partitionBy(col_partition).orderBy("language_priority")

    # Assign a row number to each row, based on language priority
    df = df.withColumn("row_num", f.row_number().over(w))

    # For each User, take only the language with highest priority (row_num == 1)
    df = df.filter(f.col("row_num") == 1).drop("row_num", "language_priority", "language")
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table fom SAP

# COMMAND ----------

# Invoices Cockpit Header
df_cockpit_hdr = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitthdr_stack"
).withColumn("extraction_date",
        f.to_date(f.col("extraction_timestamp")))

# Invoices Cockpit Item
df_cockpit_item = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpittitem_stack"
)
# Invoices Cockpit Workflow
df_cockpit_wcs = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpittwcs_stack"
)
# Invoices Cockpit Reason Description
df_cp_desc = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitcwcidt_latest"
)
# Invoices Cockpit Document Type Description
df_typ = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cockpitcptypt_latest"
)
# Company Master Data
df_company = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)
# Plant Master Data (to retreive delivered plant descirption)
df_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Prepare Dataset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prepare workflow description datasets

# COMMAND ----------

# Select relevant columns for Cockpit Reason Description Dataset
df_cp_desc_selected = (df_cp_desc
        .select("wc_id", "language", "wc_name")
        .withColumnRenamed("wc_name", "Workflow_Description")
)
# Add column "Workflow Description" in prioritized language ("English")
df_cp_desc_prepared = language_priority(df_cp_desc_selected, "wc_id")

# Select relevant columns for Cockpit Document Type Description Dataset
df_cp_doc_typ_desc = (df_typ
        .select("cp_doc_type", "language", "description")
        .withColumnRenamed("description", "cp_doc_type_Description")
)
# Add column "cp_doc_type_Description" in prioritized language ("English")
df_cp_doc_typ_desc_prepared = language_priority(df_cp_doc_typ_desc, "cp_doc_type")

# COMMAND ----------

# MAGIC %md
# MAGIC ## History Changelog for Cockpit Workflow Info Dataset

# COMMAND ----------

df_cockpit_wcs = df_cockpit_wcs.select("invoice_guid", "wc_user", "wc_id", "wc_step_id", "extraction_timestamp")

df_wcs_changelog = (
    history_changelog.initialize_history_changelog(
            df=df_cockpit_wcs,
            id_column_list=["invoice_guid"],
            sort_column="extraction_timestamp",
            tracked_column_list=[
                "wc_user",
                "wc_id",
                "wc_step_id"
            ],
            data_extraction_mode="DELTA",
            calculate_discontinuities=False,
            allow_duplicate=True,
        )
    .drop("extraction_timestamp")
    .withColumnRenamed("Start_Validity", "wc_start_date")
    .withColumnRenamed("End_Validity", "wc_end_date")
    .withColumnRenamed("invoice_guid", "wc_invoice_guid")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prepare Cockpit Item dataset

# COMMAND ----------

# Add Amount_Without_GR_HT
df_cockpit_item_new = df_cockpit_item.withColumn(
    "item_amount_nb", f.col("item_amount").cast("float")
)
# Remove leading zeros from the column po_item
df_cockpit_item_new = table_utils.remove_leading_zeros(df_cockpit_item_new, ["po_item"])

df_cockpit_item_prepared = (df_cockpit_item_new
    .select("invoice_guid", "po_number", "po_item", "ref_doc", "item_amount_nb")
    .drop_duplicates()
)

# Sum the amounts by invoice_guid and list the po_item for each invoice
df_sum_amount_by_hdr = (df_cockpit_item_prepared
    .filter(f.col("ref_doc").isNull())
    .select("invoice_guid", "item_amount_nb")
    .drop_duplicates()
    .groupBy("invoice_guid")
    .agg(
        f.sum("item_amount_nb").alias("Amount_Without_GR_HT"))
)
df_po_items = (df_cockpit_item_prepared
    .select("invoice_guid", "po_number", "po_item")
    .drop_duplicates()
    .groupBy("invoice_guid", "po_number")
    .agg(
        f.collect_list("po_item").alias("po_item_list"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prepare Dataset to add plant information
# MAGIC It's necessary to add the plant information also to data from the past (before the column "Plant" has been added to the extraction).
# MAGIC To do so, the dataset cockpit thdr will be grouped by "invoice_guid" to assign to each invoice a Plant, based on what we have in the recent data.

# COMMAND ----------

df_cockpit_hdr_cleaned = (
    df_cockpit_hdr
    .withColumn("extraction_date", f.to_date(f.col("extraction_timestamp")))
    .select("invoice_guid", "zz_werks", "extraction_timestamp")
    .withColumnRenamed("zz_werks", "Plant")
    .filter(f.col("Plant").isNotNull())
)

# Define window to consider only the latest value of "Plant"
windowSpec = Window.partitionBy("invoice_guid").orderBy(
    f.col("extraction_timestamp").desc()
)

# Filter only the most recent value of "Plant" for each "COCKPIT_invoice_guid"
df_cockpit_hdr_result = df_cockpit_hdr_cleaned.withColumn(
    "latest_Plant", f.first("Plant").over(windowSpec)
)

# Drop original "Plant" column from df_invoice and rename the new column to "Plant"
df_cockpit_hdr_final = (
    df_cockpit_hdr_result.drop("Plant", "extraction_timestamp")
    .withColumnRenamed("latest_Plant", "Plant")
    .drop_duplicates(["invoice_guid"])
    .withColumnRenamed("invoice_guid", "COCKPIT_invoice_guid")
)

# COMMAND ----------

# Select relevant columns from plant master data
df_plant_selected = (df_plant
    .select("Plant", "Plant_Description_new")
    .drop_duplicates()
    .withColumnRenamed("Plant_Description_new", "Plant_Description")
)

# Join Plant dataset with df_cockpit_hdr datastet
df_cockpit_hdr_plant = df_cockpit_hdr_final.join(df_plant_selected, "Plant", "left")

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Header & Item & Workflow CockPit + Renaming Headers

# COMMAND ----------

# Drop Rows that represent the extraction on the same date
w_drop_duplicates = Window.partitionBy(f.to_date("extraction_timestamp"), "docno", "invoice_guid").orderBy(f.col("extraction_timestamp").desc())

# Add a column with rank for each data based on timestamp
df_cockpit_hdr_with_rank = df_cockpit_hdr.withColumn("rank", f.row_number().over(w_drop_duplicates))

# Keep only rows with rank > 1 (delete minimum timestamp)
df_cockpit_hdr_filtered = df_cockpit_hdr_with_rank.filter(f.col("rank") == 1).drop("rank")


# Join dataset to retreive info about the amount, the list of po_item and the workflow (user and step) 
df_cockpit_hdr_joined = (df_cockpit_hdr_filtered
        .join(df_sum_amount_by_hdr, ["invoice_guid"], "left")
        .join(df_po_items, ["invoice_guid", "po_number"], "left").alias("A")
        .join(df_wcs_changelog.alias("B"), 
              (f.col("A.invoice_guid") == f.col("B.wc_invoice_guid")) &
              (f.col("A.extraction_date") > f.col("B.wc_start_date")) &
              (f.col("A.extraction_date") <= f.col("B.wc_end_date")),
              "left")
        .drop("wc_invoice_guid", "extraction_date")
        .join(df_cp_desc_prepared, ["wc_id"], "left")
        .join(df_cp_doc_typ_desc_prepared, ["cp_doc_type"], "left")
        # .filter(f.col("wc_user") != "COLOMIC")
)

# Renaming header adding prefix COCKPIT_
df_cockpit_hdr_prefixed = table_utils.add_prefix_to_columns(df_cockpit_hdr_joined, "COCKPIT")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Add Company Master Data

# COMMAND ----------

# Cancel Space in Company name for join
df_cockpit_hdr_trimmed = df_cockpit_hdr_prefixed.withColumn(
    "COCKPIT_comp_code", f.trim(f.col("COCKPIT_comp_code"))
)

df_company_renamed = (df_company
        .withColumnRenamed("Currency", "Company_Currency")
        .withColumnRenamed("Country_Code", "Company_Land")
)

df_company_prepared = df_company_renamed.select(
    "Company",
    "Company_Description",
    "Company_Currency",
    "Company_Land",
    "Company_Entity",
)

df_join_invoice = (
    df_cockpit_hdr_trimmed.alias("A")
    .join(
        df_company_prepared.alias("B"),
        (f.col("A.COCKPIT_comp_code") == f.col("B.Company")),
        "left",
    )
    .drop("Company")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Add Plant Master Data

# COMMAND ----------

# Drop from dataset cockpit hdr the column "Plant"
df_join_invoice_drop = df_join_invoice.drop("COCKPIT_zz_werks")

# Join the dataset cockpit_hdr with added information about plants to the invoice dataset
df_join_plant_data = df_join_invoice_drop.join(df_cockpit_hdr_plant, "COCKPIT_invoice_guid", "left")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Cleaning Data

# COMMAND ----------

# Managment of negative value for cancellation document
df_cockpit_hdr_prepared = df_join_plant_data.withColumn(
    "COCKPIT_gross_amount",
    f.when(
        f.col("COCKPIT_cp_doc_type").cast("int") == 7,
        f.lit(-1 * f.col("COCKPIT_gross_amount")),
    ).otherwise(f.lit(f.col("COCKPIT_gross_amount"))),
)
df_cockpit_hdr_prepared = df_cockpit_hdr_prepared.withColumn(
    "COCKPIT_net_amount",
    f.when(
        f.col("COCKPIT_cp_doc_type").cast("int") == 7,
        f.lit(-1 * f.col("COCKPIT_net_amount")),
    ).otherwise(f.lit(f.col("COCKPIT_net_amount"))),
)
df_cockpit_hdr_prepared = df_cockpit_hdr_prepared.withColumn(
    "COCKPIT_Amount_Without_GR_HT",
    f.when(
        f.col("COCKPIT_cp_doc_type").cast("int") == 7,
        f.lit(-1 * f.col("COCKPIT_Amount_Without_GR_HT")),
    ).otherwise(f.lit(f.col("COCKPIT_Amount_Without_GR_HT"))),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Management Profit Center

# COMMAND ----------

# Managment Profit Center are not include in Cockpit
df_cockpit_hdr_prepared = df_cockpit_hdr_prepared.withColumn("Profit_Center", f.lit("Unknown"))

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming Headers according Business entries

# COMMAND ----------

df_name_cockpit = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_cockpit"
)
# Call function Check Header files
table_utils.check_schema_of_the_header_file(df_name_cockpit)
# Call Function Delete rows null
df_name_cockpit = delete_null_rows(df_name_cockpit)
# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(df_cockpit_hdr_prepared, df_name_cockpit)
# Call Funtion Create Columns on Date format
df_cockpit = table_utils.cast_columns_with_sap_business_headers(df_column_names, df_name_cockpit)

# Rename Columns coming from cockpittwcs
df_cockpit = (df_cockpit
    .withColumnRenamed("COCKPIT_wc_id", "Workflow_ID")
    .withColumnRenamed("COCKPIT_wc_user", "Workflow_User")
    .withColumnRenamed("COCKPIT_wc_step_id", "Workflow_step_ID")
)

# Rename Relevant Columns

df_cockpit = (df_cockpit
    .withColumnRenamed("COCKPIT_zzlit_qualite", "Invoice_Quality_Dispute")
    .withColumnRenamed("COCKPIT_zzlit_quantite", "Invoice_Quantity_Dispute")
    .withColumnRenamed("COCKPIT_cp_doc_type", "CP_Document_Type")
    .withColumnRenamed("COCKPIT_cp_doc_type_Description", "CP_Document_Type_Description")
    .filter(f.col("CP_Document_Type").isNotNull())
    .withColumnRenamed("COCKPIT_Workflow_Description", "Workflow_Description")
    .withColumnRenamed("COCKPIT_fi_mm_flg", "Document_FI_MM")
    .withColumnRenamed("COCKPIT_po_number", "Purchase_Order_no")
    .withColumnRenamed("COCKPIT_po_item_list", "Purchase_Order_items")
    .withColumnRenamed("COCKPIT_ref_doc_no", "Document_Ref")
    .withColumnRenamed("COCKPIT_lfsnr", "Delivery_Note_no")
)

df_cockpit = df_cockpit.withColumnRenamed("COCKPIT_sap_doc_no", "Sap_doc_no")

# COMMAND ----------

# MAGIC %md
# MAGIC # Management of Wrong SAP decimal for spécific currency (TND, JPY,...)

# COMMAND ----------

df_cockpit_corrected = amount_correction.create_corrected_amounts(
    df_cockpit, "Amount_Gross_Document_Currency", "Document_Currency"
)
df_cockpit_corrected = amount_correction.create_corrected_amounts(
    df_cockpit_corrected, "Amount_Net_Document_Currency", "Document_Currency"
)
df_cockpit_corrected = df_cockpit_corrected.drop(
    "Amount_Gross_Document_Currency",
    "Amount_Net_Document_Currency",
)
df_cockpit_corrected = (
    df_cockpit_corrected.withColumnRenamed(
        "Amount_Gross_Document_Currency_corrected", "Amount_Gross_Document_Currency"
    )
    .withColumnRenamed(
        "Amount_Net_Document_Currency_corrected", "Amount_Net_Document_Currency"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Create history change log

# COMMAND ----------

def process_table(table_name: str, df_table_stack: DataFrame) -> str:
    """
    process ingestion of a table
    return {output_table_path} if ok, or None if not
    """
    startTime = time.time()

    Unity_Catalog_Table_Name = f"{table_name.lower()}_history_changelog"
    history_change_log_table_path = Unity_Catalog_Table_Name

    # get the first_existing_timestamp_of_extraction
    first_existing_timestamp_of_extraction_in_stack = df_table_stack.select(
        f.min("COCKPIT_extraction_timestamp")
    ).first()["min(COCKPIT_extraction_timestamp)"]
    log.info(
        f"the first timestamp in Stack table is : {first_existing_timestamp_of_extraction_in_stack}"
    )

    # get the last_existing_timestamp_of_extraction
    last_existing_timestamp_of_extraction_in_stack = df_table_stack.select(
        f.max("COCKPIT_extraction_timestamp")
    ).first()["max(COCKPIT_extraction_timestamp)"]
    log.info(
        f"the last timestamp in Stack table is : {last_existing_timestamp_of_extraction_in_stack}"
    )

    # if history_change_log_table already exists and FORCE_REINITIALIZATION == False and FORCE_CHANGELOG_REINITIALIZATION == False then history_change_log_table processed with needed stacks only
    # else history_change_log_table processed with full stack method
    if (
        (table_utils.UnityCatalogCheckTableExists(history_change_log_table_path))
        and (not new_schema)
        and (not FORCE_REINITIALIZATION)
    ):
        log.info(
            f"Computing the DELTA history changelog table {Unity_Catalog_Table_Name}"
        )

        # Read existing history_change_log_table
        df_table_history = spark.read.table(history_change_log_table_path)

        # get the last_existing_timestamp in history_change_log_table
        last_existing_timestamp_in_history_change_log = df_table_history.select(
            f.max("COCKPIT_extraction_timestamp")
        ).first()["max(COCKPIT_extraction_timestamp)"]

        log.info(
            f"the last timestamp in history changelog table is : {last_existing_timestamp_in_history_change_log}"
        )

        # Do processing only if changes are detected in stack
        if (
            last_existing_timestamp_of_extraction_in_stack
            >= last_existing_timestamp_in_history_change_log
        ):

            # Drop last day rows from history
            df_table_history = df_table_history.withColumn(
                "COCKPIT_extraction_timestamp_tmp",
                f.to_date(f.col("COCKPIT_extraction_timestamp")),
            )
            df_table_history = (
                df_table_history.withColumn(
                    "date_to_delete",
                    f.to_date(f.lit(last_existing_timestamp_in_history_change_log)),
                )
                .filter(
                    f.col("COCKPIT_extraction_timestamp_tmp")
                    < f.date_sub(f.col("date_to_delete"), 1)
                )
                .drop("COCKPIT_extraction_timestamp_tmp")
            )
            # Filter stack table with needed extraction_timestamps
            df_table_stack_from_last_run_to_current_date = df_table_stack.filter(
                (
                    df_table_stack.COCKPIT_extraction_timestamp
                    >= last_existing_timestamp_in_history_change_log
                )
            )

            df_history_final = (
                history_changelog.calculate_history_changelog_delta_update(
                    df=df_table_stack_from_last_run_to_current_date,
                    df_existing_history_changelog=df_table_history,
                    id_column_list=["COCKPIT_invoice_guid"],
                    sort_column="COCKPIT_extraction_timestamp",
                    tracked_column_list=[
                        "COCKPIT_status",
                        "Supplier_Code",
                        "Clearing_Date",
                        "Amount_Gross_Document_Currency",
                        "Company_Description",
                        "Workflow_User",
                        "Workflow_step_ID",
                        "Invoice_Quality_Dispute",
                        "Invoice_Quantity_Dispute",
                    ],
                    data_extraction_mode="DELTA",
                    calculate_discontinuities=False,
                    allow_duplicate=True,
                )
            )

        else:
            log.info(f"the table {Unity_Catalog_Table_Name} is already up to date")
            return f"{Unity_Catalog_Table_Name}"

    else:
        # Below the computation of the full history table
        log.info(
            f"Computing the FULL history changelog table {Unity_Catalog_Table_Name}"
        )

        df_history_final = history_changelog.initialize_history_changelog(
            df=df_table_stack,
            id_column_list=["COCKPIT_invoice_guid"],
            sort_column="COCKPIT_extraction_timestamp",
            tracked_column_list=[
                "COCKPIT_status",
                "Supplier_Code",
                "Clearing_Date",
                "Amount_Gross_Document_Currency",
                "Company_Description",
                "Workflow_User",
                "Workflow_step_ID",
                "Invoice_Quality_Dispute",
                "Invoice_Quantity_Dispute",
            ],
            data_extraction_mode="DELTA",
            calculate_discontinuities=False,
            allow_duplicate=True,
        )

    # Save history table
    try:
        result = table_utils.save_table(
            dest_table=history_change_log_table_path,
            df=df_history_final,
            mode="overwrite",
            overwrite_schema=True,
            merge_schema=True,
        )
    except AnalysisException as e:
        log.error(
            f"Table {history_change_log_table_path} has not been created, an error occured during creation."
        )
        return None
    else:
        duration = time.time() - startTime
        log.info(
            f"Table {history_change_log_table_path} created in {duration} seconds."
        )
        return df_history_final

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "finance"
table = "invoices_supplier_cockpit"

table_name = f"{catalog}.{domain}.{table}"
df = process_table(table_name, df_cockpit_corrected)

# COMMAND ----------


