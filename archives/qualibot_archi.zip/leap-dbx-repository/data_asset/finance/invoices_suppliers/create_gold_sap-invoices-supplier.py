# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table & Gold_Exposed for supplier invoices based on silver supplier invoices table. 
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.finance.invoices_sap_supplier
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.finance.invoices_sap_supplier_exposed
# MAGIC
# MAGIC **Input :**  
# MAGIC   - {PIPELINE_READ_ENV}_silver.finance.invoices_sap_supplier
# MAGIC   - {REFERENCE_READ_ENV}_gold.master_data.supplier_master_data_latest_exposed
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> Create_silver_sap-invoices
# MAGIC
# MAGIC **Performed in this notebook:** 
# MAGIC - Cleaning data
# MAGIC - Enrich with supplier master data
# MAGIC - Determination of Invoice Status                                                    
# MAGIC - Calcul Amount_Net_Doc_Currency
# MAGIC - Calcul payment due dates

# COMMAND ----------

# MAGIC %md 
# MAGIC # Process

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from leap_utils.data_asset.table_utils import (
    create_table_view, save_table
)

from leap_utils.data_asset import payment_term

# COMMAND ----------

# MAGIC %md 
# MAGIC #Functions

# COMMAND ----------

dbutils.widgets.removeAll()

# Get read reference environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get read pipeline environment variable
dbutils.widgets.text("pipeline_read_env", "prod")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table from Invoice & Supplier Master Data

# COMMAND ----------

# Upload Invoice silver
df_invoice = spark.read.table(f"{PIPELINE_READ_ENV}_silver.finance.invoices_sap_supplier")
# Upload Supplier Master Data
df_supplier_master_data = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed"
)
# Upload Payment term table 
df_t052_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Add supplier master data

# COMMAND ----------

df_join_invoice = (
    df_invoice.alias("A")
    .join(
        df_supplier_master_data.alias("B"),
        (f.col("A.Supplier_Code") == f.col("B.Supplier_Code"))
        & (f.col("A.Company_Code") == f.col("B.Company_Code")),
        "left",
    )
    .select(
        f.col("A.*"),
        f.col("B.Supplier_name"),
        f.col("B.Supplier_country"),
        f.col("B.Spend_category"),
        f.col("B.Intercompany_flow"),
        f.col("B.Incoterm_Code"),
        f.col("B.Incoterm_Detail"),
        f.col("B.Supplier_Category"),
        f.col("B.Payment_Term").alias("Supplier_Payment_Term"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Gold Enrichment

# COMMAND ----------

# Error Gestion if Payment Term is null
df_invoice = df_join_invoice.withColumn(
    "Payment_Term",
    f.when(
        f.col("Payment_Term").isNull() == True, f.col("Supplier_Payment_Term")
    ).otherwise(f.col("Payment_Term")),
)
df_invoice = df_invoice.withColumn(
    "Payment_Term",
    f.when(f.col("Payment_Term").isNull() == True, f.lit("Z005")).otherwise(
        f.col("Payment_Term")
    ),
)
df_invoice = df_invoice.withColumn(
    "Supplier_Payment_Term",
    f.when(
        f.col("Supplier_Payment_Term").isNull() == True, f.col("Payment_Term")
    ).otherwise(f.col("Supplier_Payment_Term")),
)
df_invoice = df_invoice.withColumn(
    "Supplier_Payment_Term",
    f.when(f.col("Supplier_Payment_Term").isNull() == True, f.lit("Z005")).otherwise(
        f.col("Supplier_Payment_Term")
    ),
)
# ---------------------------------------------------------------------------------------------------------------------------------
# Determination of Invoice Status
df_invoice = df_invoice.withColumn(
    "Payment_Status",
    f.when(f.col("Clearing_Date").isNotNull(), f.lit("PAID")).otherwise("UNPAID"),
)
# ---------------------------------------------------------------------------------------------------------------------------------
# Calcul  Amount_Net_Doc_Currency
df_invoice = df_invoice.withColumn(
    "Amount_Net_Document_Currency",
    f.col("Amount_Gross_Document_Currency") - f.col("Amount_VAT_Doc_Currency"),
)
# ---------------------------------------------------------------------------------------------------------------------------------
# Calcul payment date Base_Date'
df_invoice = df_invoice.withColumn(
    "Base_Date",
    f.when(f.col("Base_Date").isNull() == True, f.col("Doc_Date")).otherwise(
        f.col("Base_Date")
    ),
)
# Calcul payment due date from Base_Date and the payment term
df_invoice = payment_term.calculate_payment_term_due_date(
    df_invoice,
    df_t052_raw,
    df_invoice["Payment_Term"],
    df_invoice.Base_Date,
    "Payment_Term_Due_Date",
)


#  Calcul supplier payment due date from Doc_Date and Supplier payment term
df_invoice = payment_term.calculate_payment_term_due_date(
    df_invoice,
    df_t052_raw,
    df_invoice["Supplier_Payment_Term"],
    df_invoice.Doc_Date,
    "Supplier_Payment_Term_Due_Date",
)

df_invoice = df_invoice.withColumn(
    "Gap_BaseDate_DocDate",
    f.when(f.col("Doc_Date") != f.col("Base_Date"), f.lit("Yes")).otherwise(
        f.lit("No")
    ),
)
df_invoice = df_invoice.withColumn(
    "Gap_Payment_Term",
    f.when(
        f.col("Payment_Term") != f.col("Supplier_Payment_Term"), f.lit("Yes")
    ).otherwise(f.lit("No")),
)
df_invoice = df_invoice.drop("Debit_Credit")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Managment Null value

# COMMAND ----------

# Replace all null value by Unknown
columns_to_replace = [
    "Company_Entity",
    "Incoterm_Code",
    "Incoterm_Detail",
    "Supplier_Code",
    "Supplier_name",
    "Spend_category",
    "Supplier_country",
    "Supplier_Category",
]
replacement_value = "Unknown"
replacement_values = {col_name: replacement_value for col_name in columns_to_replace}
df_invoice = df_invoice.fillna(replacement_values)

# COMMAND ----------

# MAGIC %md
# MAGIC #Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Gold table

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "finance"
table = "invoices_sap_supplier"

save_table(f"{catalog}.{domain}.{table}", df_invoice, "overwrite", True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Gold exposed table

# COMMAND ----------

catalog = "gold"
domain = "finance"
table = "invoices_sap_supplier"
src_full_tablename = f"{PIPELINE_WRITE_ENV}_{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = 'BSX'
selected_columns = [col for col in df_invoice.columns if not col.startswith(Begin_By)]
select_statement = ", ".join(selected_columns)

create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
