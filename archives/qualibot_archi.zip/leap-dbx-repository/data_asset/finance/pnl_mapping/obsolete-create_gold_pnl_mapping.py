# Databricks notebook source
# MAGIC %md
# MAGIC #P&L
# MAGIC The mapping between the general ledger (GL) and a P&L doesn't appear in SAP, thus it is a combination between two manual inputs, one is the mapping to obtain the index p&l, and the other is the description and the parents associated to the index p&l.  
# MAGIC
# MAGIC ## Notebook purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC This notebook loads the silver table, and create the gold table. For the moment, there is not any enrichment.  
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {env}_silver.finance.pnl_mapping
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {env}_gold.finance.pnl_mapping
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC   - P&L

# COMMAND ----------

from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")

# COMMAND ----------

df_silver = spark.read.table(f'{env}_silver.finance.pnl_mapping')

# COMMAND ----------

#Save the gold table of pnl mapping
catalog = f"{env}_gold"
domain = "finance"
table = "pnl_mapping"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_silver,
    mode="overwrite",
    overwrite_schema=True
)
