# Databricks notebook source
# MAGIC %md
# MAGIC #P&L
# MAGIC The mapping between the general ledger (GL) and a P&L doesn't appear in SAP, thus it is a combination between two manual inputs, one is the mapping to obtain the index p&l, and the other is the description and the parents associated to the index p&l.  
# MAGIC
# MAGIC ## Notebook purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC This notebook loads the bronze tables, which are manual input, join on the index p&l and create the silver table. 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {env}_bronze.manual_input.pnl_mapping_index
# MAGIC   - {env}_bronze.manual_input.pnl_index_to_line_item_map
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {env}_silver.finance.pnl_mapping
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC   - create_gold_pnl_mapping

# COMMAND ----------

from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")

# COMMAND ----------

df_index = spark.read.table(f'{env}_bronze.manual_input.pnl_mapping_index')
df_items = spark.read.table(f'{env}_bronze.manual_input.pnl_index_to_line_item_map')

# COMMAND ----------

df_join = df_index.join(df_items, df_index.Index_PnL == df_items.index_code, how='left').drop('index_code')

# COMMAND ----------

#Save the silver table of pnl mapping
catalog = f"{env}_silver"
domain = "finance"
table = "pnl_mapping"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_join,
    mode="overwrite",
    overwrite_schema=True
)
