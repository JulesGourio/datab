# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table for general ledger. In this notebook, enrichments are made on the company, profit center and plant. The gold exposed table is also created.  
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {ENV}_gold.finance.general_ledger
# MAGIC   - {ENV}_gold.finance.general_ledger_exposed
# MAGIC   
# MAGIC **Inputs:**  
# MAGIC   - {ENV}_silver.finance.general_ledger
# MAGIC   - {READ_ENV}_bronze.manual_input.plant_description
# MAGIC   - {READ_ENV}_gold.finance.profit_center_exposed
# MAGIC   - {READ_ENV}_gold.master_data.company_master_data_latest_exposed
# MAGIC   - {READ_ENV}_gold.finance.cost_center_exposed
# MAGIC   - {READ_ENV}_gold.finance.wbs_otp_exposed
# MAGIC
# MAGIC **Used by:**  
# MAGIC P&L projects

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.window import Window

from leap_utils.data_asset.amount_correction import (
    create_corrected_amounts,
)  
from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("env", "dev")
ENV = dbutils.widgets.get("env")

dbutils.widgets.text("read_env", "prod")
READ_ENV = dbutils.widgets.get("read_env")

# COMMAND ----------

df_silver = spark.read.table(f"{ENV}_silver.finance.general_ledger")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

def UnityCatalogCheckTableExists(DbxTablePath) -> bool:
    """Check if table Exist or not"""
    PathSplit = DbxTablePath.lower().split(".")
    if len(PathSplit) != 3:
        print("Must have 3 sections [CatalogName].[SchemaName].[TableName]")
        return False
    if len(PathSplit) == 3:
        df_tables = spark.read.table(f"{PathSplit[0]}.information_schema.tables")
        true_false = bool(
            df_tables.filter(f.col("table_catalog") == PathSplit[0])
            .filter(f.col("table_schema") == PathSplit[1])
            .filter(f.col("table_name") == PathSplit[2])
            .filter(f.col("table_type").isin("MANAGED", "EXTERNAL"))
            .count()
        )
        return true_false

# COMMAND ----------

# MAGIC %md
# MAGIC #Add profit center info
# MAGIC Aim: To obtain all the information related to the profit center.

# COMMAND ----------

df_pc = (
    spark.read.table(f"{READ_ENV}_gold.finance.profit_center_exposed")
    .dropDuplicates()
    .withColumnRenamed("Profit_Center", "Profit_Center_")
    .drop("Profit_Center_short")
)

# COMMAND ----------

if df_pc.select("Profit_Center_").distinct().count() != df_pc.count():
    raise Exception("La table des centres de profit n'a pas un centre de profit unique")

# COMMAND ----------

df_pc_select = (
    df_pc.select(
        "Profit_Center_",
        "Business_Unit",
        "PC_Responsible",
        "Aircraft_platform",
        "PC_Attributed_Site",
        "Accounting_PC_Group",
        "Product_Group",
        "Customer_Group",
        "Branch",
        "Aircraft_product",
        "PC_Hierachy_Std",
        "Short_Description",
        "Long_Description",
        "Match_Code",
    )
    .withColumnRenamed("Branch", "PC_Branch")
    .withColumn("Customer_Group", f.upper("Customer_Group"))
)

# COMMAND ----------

df_w_pc = df_silver.join(
    df_pc_select,
    df_silver.Profit_Center == df_pc_select.Profit_Center_,
    how="left",
)

# COMMAND ----------

#Profit center 0
df_w_pc = df_w_pc.withColumn(
    "Profit_center_short",
    f.when(f.col("Profit_center_clean") == "0000000000", f.lit("0")).otherwise(
        f.col("Profit_center_short")
    ),
).drop("Profit_center_clean")

# COMMAND ----------

# MAGIC %md
# MAGIC #Add plant description
# MAGIC Aim: To have the description associated to the plant code. 

# COMMAND ----------

df_plant_description = spark.read.table(
    f"{READ_ENV}_bronze.manual_input.plant_description"
)

# COMMAND ----------

df_w_plant = df_w_pc.join(
    df_plant_description, df_w_pc.Plant == df_plant_description.Plant_Div, how="left"
).drop("Plant_Div")

# COMMAND ----------

# MAGIC %md
# MAGIC #Add company info 
# MAGIC Aim: Having the description associated to a company code and the currency of the company. 

# COMMAND ----------

df_company = (
    spark.read.table(f"{READ_ENV}_gold.master_data.company_master_data_latest_exposed")
    .select("Company", "Company_Description", "Currency")
    .withColumnRenamed("Currency", "Company_Currency")
    .dropDuplicates(["Company", "Company_Currency"])
)

# COMMAND ----------

#Join with the company master data table
df_gold = df_w_plant.join(
    df_company, df_w_plant.Company_code == df_company.Company, how="left"
).drop("Company")

# COMMAND ----------

# MAGIC %md
# MAGIC #Add cost center info

# COMMAND ----------

#Read the gold cost center table and collect useful information
df_cc = (
    spark.read.table(f"{READ_ENV}_gold.finance.cost_center_exposed")
    .filter(f.col("Is_valid") == "true")
    .withColumnRenamed("Site", "CCSite")
    .withColumnRenamed("Branch", "CCBranch")
    .withColumnRenamed("Short_Description", "Cost_center_Description")
    .select(
        "Cost_Center",
        "Cost_Center_short",
        "CCSite",
        "CCBranch",
        "Cost_center_Description",
        "Company_Code",
    )
    .dropDuplicates()
).withColumnRenamed("Cost_Center", "Cost_Center_")

windowSpec = Window.partitionBy("Cost_Center_")
df_cc_2 = df_cc.withColumn(
    "Unique_cost_center", f.count("Cost_Center_").over(windowSpec)
)
df_cc_3 = (
    df_cc_2.withColumn(
        "tobedeleted",
        f.when(
            (f.col("Unique_cost_center") > 1) & (f.col("Company_Code") == "LLVS"),
            f.lit(1),
        ).otherwise(f.lit(0)),
    )
    .filter(f.col("tobedeleted") == 0)
    .drop("Unique_cost_center", "tobedeleted", "Company_Code")
)

# COMMAND ----------

if df_cc_3.select("Cost_Center_").distinct().count() != df_cc_3.distinct().count():
    raise Exception(
        "The column cost center is not unique in the cost center dataframe to join"
    )

# COMMAND ----------

#Join the main dataframe to the cost center table so as to have the information relative to the cost centers
# For accounts 92* and 93*, the cost center is the last 6 characters of the account numbers
df_w_CC_specific = df_gold.withColumn(
    "Cost_center_adjusted",
    f.when(
        f.col("Account_number").startswith("92") & f.col("Cost_center").isNull(),
        f.substring(df_gold["Account_number"], -6, 6),
    ).otherwise(f.col("Cost_center")),
)
df_w_CC = df_w_CC_specific.withColumn(
    "Cost_center_adjusted",
    f.when(
        f.col("Account_number").startswith("93") & f.col("Cost_center").isNull(),
        f.substring(df_w_CC_specific["Account_number"], -6, 6),
    ).otherwise(f.col("Cost_center_adjusted")),
)

df_w_cc_adj = df_w_CC.withColumn(
    "Cost_center_adjusted",
    f.when(
        f.col("Account_number").startswith("931") & f.col("Cost_center").isNull(),
        f.concat(f.lit("A"), f.substring(df_w_CC_specific["Account_number"], -5, 5)),
    ).otherwise(f.col("Cost_center_adjusted")),
)

# COMMAND ----------

#Join the new column cost_center_adjusted to the cost center table
df_w_CC_f = df_w_cc_adj.join(
    df_cc_3,
    df_w_cc_adj.Cost_center_adjusted == df_cc_3.Cost_Center_,
    how="left",
).drop("Cost_Center_")

# COMMAND ----------

# MAGIC %md
# MAGIC #Add WBS info 
# MAGIC WBS = Work Breakdown Structure = OTP

# COMMAND ----------

df_otp = spark.read.table(f"{READ_ENV}_gold.finance.wbs_otp_exposed").select(
    "WBS_Code_Num", "WBS_Code", "WBS_Description", "WBS_Plant"
)

# COMMAND ----------

if df_otp.select("WBS_Code_Num").distinct().count() != df_otp.count():
    raise Exception("WBS element is not unique in the dataframe joined")

# COMMAND ----------

df_w_wbs_f = df_w_CC_f.join(
    df_otp,
    df_w_CC_f.WBS_element == df_otp.WBS_Code_Num,
    how="left",
).drop("WBS_Code_Num")

# COMMAND ----------

# MAGIC %md
# MAGIC #SAP amount correction

# COMMAND ----------

df_corrected = create_corrected_amounts(
    df_w_wbs_f, "Amount_in_transaction_currency_", "Currency_key"
)
df_corrected = create_corrected_amounts(
    df_corrected, "Amount_in_company_code_currency_", "Company_currency"
)

df_gold_corrected = (
    df_corrected.drop(
        "Amount_in_company_code_currency_", "Amount_in_transaction_currency_"
    )
    .withColumnRenamed(
        "Amount_in_transaction_currency__corrected", "Amount_in_transaction_currency_"
    )
    .withColumnRenamed(
        "Amount_in_company_code_currency__corrected", "Amount_in_company_code_currency_"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality checks

# COMMAND ----------

if df_silver.count() != df_gold_corrected.count():
    raise Exception(
        "Warning: The silver and gold tables don't have the same number of rows"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC #Save 

# COMMAND ----------

catalog = f"{ENV}_gold"
domain = "finance"
table = "general_ledger"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_gold_corrected,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Gold exposed 

# COMMAND ----------

catalog = f"{ENV}_gold"
domain = "finance"
table = "general_ledger"

Begin_By = "glpca"
selected_columns = [col for col in df_gold_corrected.columns if not col.startswith(Begin_By)]
select_statement = ", ".join(selected_columns)

src_full_tablename = f"{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
