# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create the silver table for general ledger. 
# MAGIC - Cleaning of data format
# MAGIC - Join with dimension table 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.glpca_latest
# MAGIC   - {READ_ENV}_bronze.headers_sap.headers_sap_business_glpca
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - {env}_silver.finance.general_ledger
# MAGIC   
# MAGIC **Triggered by:**  
# MAGIC create_gold_general_ledger

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import DataFrame
from pyspark.sql.types import DecimalType
from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("env", "dev")
ENV = dbutils.widgets.get("env")

dbutils.widgets.text("read_env", "prod")
READ_ENV = dbutils.widgets.get("read_env")

# COMMAND ----------

df_glpca = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.glpca_latest")
df_headers = spark.read.table(f"{READ_ENV}_bronze.headers_sap.headers_sap_business_glpca")

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming

# COMMAND ----------

# Renaming Sap Columns // add Table Name in header
def add_table_name(df: DataFrame, table_name: str) -> DataFrame:
    for col in df.columns:
        df = df.withColumnRenamed(f"{col}", f"{table_name}_{col}")
    return df

# --------------------------------------------------------------------------------------------------------------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )

# --------------------------------------------------------------------------------------------------------------

# Rename Columns according with Imput file 'Header Renaming
def rename_sap_column_names(df: DataFrame, df_names: DataFrame) -> DataFrame:
    dfp_names = df_names.toPandas()
    dfp_names["table_field"] = dfp_names["Table_name"] + "_" + dfp_names["Field"]
    for i, r in dfp_names.iterrows():

        df = df.withColumnRenamed(
            r["table_field"], r["Business_name"].replace(" ", "_")
        )
    return df


# --------------------------------------------------------------------------------------------------------------

# Create date format columns when indicated in the headers file
def modificate_format_column(df: DataFrame, df_names: DataFrame) -> DataFrame:
    """
    Create a date column when it is asked in the column name config file
    """
    for col in df.columns:
        if df_names.filter(f.col("Business_name") == col).count() > 0:
            if (
                df_names.filter(f.col("Business_name") == col)
                .select("Format")
                .first()[0]
                == "date"
            ):
                df = df.withColumn(f"{col}", f.to_date(f.col(f"{col}"), "yyyyMMdd"))
            else:
                if (
                    df_names.filter(f.col("Business_name") == col)
                    .select("Format")
                    .first()[0]
                    == "float"
                ):
                    df = df.withColumn(f"{col}", f.col(f"{col}").cast("float"))
    return df

# --------------------------------------------------------------------------------------------------------------

# COMMAND ----------

df_glpca = add_table_name(df_glpca, "glpca")  
check_schema_of_the_file(df_headers)  # <- call function Check Header files
df_renamed = rename_sap_column_names(
    df_glpca, df_headers
)  # <- Call Function Rename Columns according header file
df = modificate_format_column(
    df_renamed, df_headers
)  # <- Call Funtion Create Columns on Date format

# COMMAND ----------

# MAGIC %md
# MAGIC #Negative numbers for amount and quantity
# MAGIC In the raw table (from SAP), the minus '-' is at the end of the number. 
# MAGIC - Put the - at the beginning
# MAGIC - Convert to a decimal type

# COMMAND ----------

list_col = [
    "Amount_in_transaction_currency",
    "Amount_in_company_code_currency",
    "Amount_in_profit_center_local_currency",
    "Quantity"
]

# COMMAND ----------

for colu in list_col:
    df = df.withColumn(
        f"{colu}_",
        f.when(
            f.col(f"{colu}").endswith("-"),
            f.col(f"{colu}").substr(f.lit(0), f.length(f.col(f"{colu}")) - 1),
        ).otherwise(f.col(f"{colu}")),
    )
    df = df.withColumn(
        f"{colu}_",
        f.when(
            f.col(f"{colu}").endswith("-"), f.concat(f.lit("-"), f.col(f"{colu}_"))
        ).otherwise(f.col(f"{colu}_")),
    ).drop(f"{colu}")

# COMMAND ----------

for colu in list_col:
    df = df.withColumn(f"{colu}_", df[f"{colu}_"].cast(DecimalType(38, 18)))

# COMMAND ----------

# MAGIC %md
# MAGIC #Profit center clean
# MAGIC

# COMMAND ----------

df_lasty_pc = (
    df.withColumn(
        "Profit_Center_Clean",
        f.regexp_replace(f.col("Profit_Center"), "\\s+", ""),
    )
    .withColumn(
        "Profit_Center_Clean",
        f.when(
            f.col("Profit_Center_Clean").isNull() == True, f.lit("Unknown")
        ).otherwise(f.col("Profit_Center_Clean")),
    )
    .withColumn("Profit_Center_Clean", f.trim(f.col("Profit_Center_Clean")))
).withColumn(
    "Profit_Center_Clean",
    f.when(f.col("Profit_Center_Clean") == "", f.lit("Unknown")).otherwise(
        f.col("Profit_Center_Clean")
    ),
)

# COMMAND ----------

df_lasty_pc = df_lasty_pc.withColumn("Profit_center_short", f.regexp_replace(f.col('Profit_Center_Clean'), "^0+", ""))

# COMMAND ----------

# MAGIC %md
# MAGIC #Cleaning of account number
# MAGIC Remove the two leading zeros in the account number

# COMMAND ----------

def remove_lead_zero(col, n):
    """
    col: name of the column you want to modify
    n: number of leading 0 you want to remove
    """
    return f.when(
        f.regexp_extract(col, "^0{{{n}}}[^0]".format(n=n), 0) != "",
        f.expr("substring({col}, {n}, length({col}))".format(col=col, n=n + 1)),
    ).otherwise(f.col(col))

# COMMAND ----------

df_clean = df_lasty_pc.withColumn("Account_number", remove_lead_zero('Account_number', 2))

# COMMAND ----------

# MAGIC %md
# MAGIC #Join with account 
# MAGIC The aim here is to obtain the associated account group for each account number. 

# COMMAND ----------

df_account = spark.read.table(f"{READ_ENV}_gold.finance.account_groups_exposed").filter(
    f.col("Hierarchy_Level1") == "HIER-PC"
)

# COMMAND ----------

# Cleaning of account numbers
# The aim of the filter is to delete duplicates account number because of weird groups
df_account_clean = (
    df_account.withColumn("Account_number_", remove_lead_zero("Account_number", 2))
    .drop("Account_number")
    .filter(f.col("Hierarchy_Level1").isNotNull())
)

# COMMAND ----------

df_w_grp = df_clean.join(
    df_account_clean,
    df_clean.Account_number == df_account_clean.Account_number_,
    how="left",
).drop("Account_number_")

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality checks

# COMMAND ----------

# Amount not null 
if df_w_grp.filter(f.col('Amount_in_company_code_currency_').isNull()).count() != 0:
    raise Exception("The column Amount_in_company_code_currency_ has null values")

# COMMAND ----------

# Same number of rows between the bronze and the silver 
## Check if no values are duplicated when joining 
if df_w_grp.count() != df_glpca.count():
    raise Exception("Warning: some GLPCA rows have been duplicated due to a join")

# COMMAND ----------

# MAGIC %md
# MAGIC #Save

# COMMAND ----------

catalog = f"{ENV}_silver"
domain = "finance"
table = "general_ledger"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")
table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_w_grp,
    mode="overwrite",
    overwrite_schema=True
)
