# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to do the quality checks at the end of the pipeline to check the veracity of the data and that all transformations perform well. 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.glpca_latest
# MAGIC   - {PIPELINE_READ_ENV}_silver.finance.general_ledger
# MAGIC   - {PIPELINE_READ_ENV}_gold.finance.general_ledger
# MAGIC   - {PIPELINE_READ_ENV}_proj.profit_and_loss.profit_and_loss
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.profit_center_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.pnl_mapping
# MAGIC   
# MAGIC **Checks:**  
# MAGIC   - Unicity of columns used in joins
# MAGIC   - Unicity of the glpca sap key in silver and gold GL
# MAGIC   - Amount not null in project 
# MAGIC   - Company code not null in project
# MAGIC
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("PIPELINE_READ_ENV", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("PIPELINE_READ_ENV")

dbutils.widgets.text("PIPELINE_WRITE_ENV", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("PIPELINE_WRITE_ENV")

dbutils.widgets.text("REFERENCE_READ_ENV", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("REFERENCE_READ_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

from pyspark.sql import DataFrame


def check_unicity_columns(df: DataFrame, list_of_col):
    if df.count() != df.select(list_of_col).distinct().count():
        raise Exception(f"{list_of_col} not unique in {df}")

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality checks - create_silver
# MAGIC - That the columns amount used in all projects is not null
# MAGIC - That the silver table has the same number of rows than the raw sap table in prod 

# COMMAND ----------

"""Raw table from SAP"""
df_glpca = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.glpca_latest")

# COMMAND ----------

"""Silver table"""
df_silver = spark.read.table(f"{PIPELINE_READ_ENV}_silver.finance.general_ledger")

# COMMAND ----------

# Amount not null
if df_silver.filter(f.col("Amount_in_company_code_currency_").isNull()).count() != 0:
    raise Exception("The column Amount_in_company_code_currency_ has null values")

# COMMAND ----------

# Same number of rows between the bronze and the silver
## Check if no values are duplicated when joining
if df_silver.count() != df_glpca.count():
    raise Exception("Warning: some GLPCA rows have been duplicated due to a join")

# COMMAND ----------

# Unicity of the SAP key
check_unicity_columns(df_silver, ["Record_nber_of_the_line_item_record"])

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality check - create_gold

# COMMAND ----------

df_gold = spark.read.table(f"{PIPELINE_READ_ENV}_gold.finance.general_ledger")

# COMMAND ----------

if df_silver.count() != df_gold.count():
    raise Exception(
        "Warning: silver and gold tables don't have the same number of rows"
    )

# COMMAND ----------

if df_silver.count() != df_gold.count():
    raise Exception(
        "Warning: The silver and gold tables don't have the same number of rows"
    )

# COMMAND ----------

# Unicity of the SAP key
check_unicity_columns(df_gold, ["Record_nber_of_the_line_item_record"])

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality check - create_proj

# COMMAND ----------

df_proj = spark.read.table(f"{PIPELINE_READ_ENV}_proj.profit_and_loss.profit_and_loss")

# COMMAND ----------

if (
    df_proj.filter(
        f.col("Amount_in_cny_curr_in_EUR_last_month_avg_rates").isNull()
    ).count()
    > 0
):
    raise Exception(
        "Warning: there is at least 1 null value in the column Amount_in_cny_curr_in_EUR_last_month_avg_rates"
    )
if df_proj.filter(f.col("Company_code").isNull()).count() > 0:
    raise Exception(
        "Warning: there is at least 1 null value in the column Company_code"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality checks - master tables

# COMMAND ----------

df_profit_center = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)
df_account = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.account_groups_exposed"
)
df_mapping = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.pnl_mapping")

# COMMAND ----------

check_unicity_columns(df_profit_center, ["Profit_center_short"])
check_unicity_columns(df_account, ["Account_Number"])
check_unicity_columns(df_mapping, ["PC_Type", "Nom_de_set"])
