# Databricks notebook source
# MAGIC %md
# MAGIC # Budget hourly rates silver data asset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Description
# MAGIC The aim of this notebook is to create the silver data asset of the budget hourly rates data.
# MAGIC It is based on the budget hourly rates stack of tables we ingested through Sigma.
# MAGIC
# MAGIC ## Highlighted complexities
# MAGIC - We create a "latest" data asset by filtering budget hourly rates files to only keep
# MAGIC   the latest files ingested, for each budget type, version, scope, and fiscal year.
# MAGIC   - Budget type are "budget" or "reforecast" budgets.
# MAGIC   - Budget version is an arbitrary number to differentiate between various budget drafts
# MAGIC   sent by the business.
# MAGIC   - Budget scope indicates on which group of companies does the budget file applies
# MAGIC   (for example ASEU, ASAM, ISEU, ISAM, SPS, etc)
# MAGIC   - Fiscal year is the civil year for which the work quantity is budgetized
# MAGIC   (note: there is only one fiscal year per file).
# MAGIC
# MAGIC ## Intended pipeline
# MAGIC `TODO` (Pipeline to be created)
# MAGIC
# MAGIC ## Pipeline input tables
# MAGIC - `{PIPELINE_READ_ENV}_bronze.sigma_budget_reporting.budget_hourly rates_stack`
# MAGIC
# MAGIC ## Reference input tables
# MAGIC None
# MAGIC
# MAGIC ## Pipeline output tables
# MAGIC - `{PIPELINE_WRITE_ENV}_silver.finance.budget_hourly rates`

# COMMAND ----------

# MAGIC %md
# MAGIC ## Technical debt
# MAGIC None identified yet

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config imports

# COMMAND ----------

from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f, Window

from leap_utils.common import logger
from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "Budget hourly rates silver"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC Fix root logger

# COMMAND ----------

import logging

logging.getLogger().handlers.clear()

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import bronze budget hourly rates stack table
# MAGIC
# MAGIC `df_budget_hourly_rates_stack` is the bronze budget hourly rates stack table ingested through Sigma.

# COMMAND ----------

df_budget_hourly_rates_stack = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze"
    ".sigma_budget_reporting"
    ".budget_hourly_rates_stack"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

FILENAME_WITH_TIMESTAMP_REGEX = r"^\d{8}\_\d{6}\_budget\_v(\d{1})\_([a-zA-Z0-9]+)\_(hourly_rates)(?:\_(.*))?$"

# COMMAND ----------

# MAGIC %md
# MAGIC # Data transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Extract information from filename metadata

# COMMAND ----------

df_budget_hourly_rates_filename_meta_extraction = df_budget_hourly_rates_stack.withColumns(
    {
        col_name: f.regexp_extract(
            f.col("_meta_filename"),
            pattern=FILENAME_WITH_TIMESTAMP_REGEX,
            idx=index + 1,
        ).cast(_type)
        for index, (col_name, _type) in enumerate(
            [
                ("budget_version", "int"),
                ("budget_scope", "string"),
                ("budget_type", "string"),
                ("budget_comment", "string"),
            ]
        )
    }
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_hourly_rates_filename_meta_extraction.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Find latest budget hourly_rates data per version, scope, etc

# COMMAND ----------

df_budget_latest_ranking = df_budget_hourly_rates_filename_meta_extraction.withColumns(
    {
        "rank": f.dense_rank().over(
            Window.partitionBy(
                "fiscal_year",
                "budget_type",
                "budget_version",
                "budget_scope",
            ).orderBy(
                f.col("_meta_ingestion_timestamp").desc(),
                f.col("_meta_modification_timestamp").desc(),
            )
        )
    }
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_latest_ranking.groupBy(
        "fiscal_year",
        "budget_type",
        "budget_version",
        "budget_scope",
    ).agg(
        f.count(f.lit(1)),
        f.collect_set(f.col("rank")).alias("ranks"),
        f.collect_set(f.col("budget_comment")).alias("comments"),
    ).display()

df_budget_hourly_rates_latest = df_budget_latest_ranking.where(
    f.col("rank") == f.lit(1)
).drop("rank")

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_hourly_rates_latest.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Keep input annual rate

# COMMAND ----------

df_budget_hourly_rates_latest = df_budget_hourly_rates_latest.filter(f.col("input_annual_rate").isNotNull())

for i in range(1, 13):
    col_name = f"rate_{i:02d}"
    df_budget_hourly_rates_latest = (
        df_budget_hourly_rates_latest
        .withColumn(col_name, f.col("input_annual_rate"))
    )

df_budget_hourly_rates_latest = df_budget_hourly_rates_latest.drop("input_annual_rate", "calculated_annual_rate")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Pivot quantities

# COMMAND ----------

value_columns = [f"rate_{val+1:02}" for val in range(12)]

id_columns = [
    col_name
    for col_name in df_budget_hourly_rates_latest.columns
    if col_name not in value_columns
]

# COMMAND ----------

df_budget_hourly_rates_unpivot = df_budget_hourly_rates_latest.unpivot(
    ids=id_columns,
    values=value_columns,
    variableColumnName="period",
    valueColumnName="rate",
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_hourly_rates_unpivot.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Clean quantities and parse period

# COMMAND ----------

df_budget_clean = (
    df_budget_hourly_rates_unpivot.fillna(0.0, ["rate"])
    .withColumns(
        {
            "posting_period": f.regexp_extract(
                f.col("period"), pattern=r"^rate\_(\d{2})$", idx=1
            ).cast("int"),
        }
    )
    .drop("period")
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_clean.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Save budget hourly rates silver table

# COMMAND ----------

table_utils.save_table(
    dest_table=(
        f"{PIPELINE_WRITE_ENV}_silver.finance.budget_hourly_rates"
    ),
    df=df_budget_clean,
    mode="overwrite",
    overwrite_schema=True,
)
