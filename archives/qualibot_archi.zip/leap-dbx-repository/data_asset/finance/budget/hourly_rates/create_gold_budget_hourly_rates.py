# Databricks notebook source
# MAGIC %md
# MAGIC # Budget hourly rates gold data asset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Description
# MAGIC The aim of this notebook is to create the gold data asset of the budget hourly rates data.
# MAGIC
# MAGIC ## Highlighted complexities
# MAGIC - For the cost center to profit center mapping, we use the first profit center
# MAGIC   for each cost center, especially when the profit center is different between the
# MAGIC   controlling areas PA01 and PA20.
# MAGIC
# MAGIC ## Intended pipeline
# MAGIC `TODO` (Pipeline to be created)
# MAGIC
# MAGIC ## Pipeline input tables
# MAGIC - `{PIPELINE_READ_ENV}_silver.finance.budget_hourly_rates`
# MAGIC - `{PIPELINE_READ_ENV}_gold.finance.budget_currency_exchange`
# MAGIC
# MAGIC ## Reference input tables
# MAGIC - `{REFERENCE_READ_ENV}_gold.finance.cost_center_exposed`
# MAGIC
# MAGIC ## Pipeline output tables
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.budget_hourly_rates`
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.budget_hourly_rates_exposed` (view)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Technical debt
# MAGIC In [Preparation 1.1 - Clean the cost center data asset]:
# MAGIC - We also need to remove leading zeroes for the profit center column, which should
# MAGIC   be done in the data asset, and we should check the impact of such change.

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config imports

# COMMAND ----------

from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f, Window

from leap_utils.common import logger
from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "Budget hourly rates gold"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC Fix root logger

# COMMAND ----------

import logging

logging.getLogger().handlers.clear()

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import silver budget hourly rates table
# MAGIC
# MAGIC `df_budget_hourly_rates_silver` is the silver budget hourly rates table.

# COMMAND ----------

df_budget_hourly_rates_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.budget_hourly_rates"
)

# COMMAND ----------

df = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.budget_currency_exchange"
)

# COMMAND ----------

df.groupBy("CurrencyPairID", "Validity_Date_DateFormat").count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import gold cost center data asset
# MAGIC
# MAGIC `df_cost_center_gold` is the gold cost center data asset table.

# COMMAND ----------

df_cost_center_gold = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.cost_center_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import gold currency exchange data asset
# MAGIC `df_currency_exchange_gold` is the gold currency exchange rates data asset table.

# COMMAND ----------

df_currency_exchange_gold = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.finance.budget_currency_exchange"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Find the latest budget rate date

# COMMAND ----------

latest_budget_date_available = (
    df_currency_exchange_gold.where(
        f.col("Conversion_rate_Type_exp") == f.lit("Budget")
    )
    .orderBy(f.col("Validity_Date_DateFormat").desc())
    .select("Validity_Date_DateFormat")
    .first()[0]
)

log.debug("Latest budget date: %s", latest_budget_date_available)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Prepare the cost center data asset

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 2.1 - Clean the cost center data asset

# COMMAND ----------

df_cost_center_clean = df_cost_center_gold.where(f.col("Is_valid")).transform(
    table_utils.remove_leading_zeros, ["Profit_Center"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 2.2 - Select columns of the cost center data asset

# COMMAND ----------

df_cost_center_selection = df_cost_center_clean.select(
    "Controlling_Area", "Cost_center_short", "Profit_Center"
).withColumnsRenamed(
    {
        "Controlling_Area": "controlling_area",
        "Cost_center_short": "cost_center",
        "Profit_Center": "profit_center",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 2.3 - Find the first profit center for each cost center

# COMMAND ----------

df_cost_center_profit_center_mapping = (
    df_cost_center_selection.withColumn(
        "profit_center",
        f.first("profit_center").over(
            Window.partitionBy("cost_center").orderBy("controlling_area")
        ),
    )
    .select("cost_center", "profit_center")
    .distinct()
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_cost_center_profit_center_mapping.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Convert all amounts to Euro in budget rate

# COMMAND ----------

df_hourly_rates_amount_converted = table_utils.currency_conversion(
    df=df_budget_hourly_rates_silver.withColumn(
        "conversion_date", f.lit(latest_budget_date_available)
    ),
    df_currency = df_currency_exchange_gold,
    document_currency_column=f.col("currency_key"),
    rate_types=["Budget"],
    # TODO For budget rates, we need to use future conversion dates,
    #  we need to plan an evolution on the currency exchange data asset
    #  (and we should be careful on the impact it might produce on existing code)
    rate_dates=[f.col("conversion_date")],
    target_currency_value="EUR",
    document_amounts=[f.col("rate")],
    reference_read_env=REFERENCE_READ_ENV,
).withColumnsRenamed(
    {
        "currency_key_to_EUR_in_Budget_rate_at_conversion_date": "conversion_rate",
        "rate_from_currency_key_to_EUR_in_Budget_rate_at_conversion_date": "rate_EUR",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Augment budget hourly rates data asset with cost center gold table

# COMMAND ----------

df_budget_hourly_rates_with_cost_center = (
    df_hourly_rates_amount_converted.alias("df_hourly_rates")
    .join(
        df_cost_center_profit_center_mapping.withColumnRenamed(
            "profit_center", "profit_center_of_cost_center"
        ).alias("df_cost_center"),
        on=((f.col("df_hourly_rates.cost_center") == f.col("df_cost_center.cost_center"))),
        how="left",
    )
    .drop(f.col("df_cost_center.cost_center"))
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_hourly_rates_with_cost_center.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output 1 - Save budget hourly rates gold table

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.finance.budget_hourly_rates",
    df=df_budget_hourly_rates_with_cost_center,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output 2 - Save budget hourly rates gold exposed view

# COMMAND ----------

log.debug("All columns are: %s", df_budget_hourly_rates_with_cost_center.columns)

exposed_columns = [
    col
    for col in df_budget_hourly_rates_with_cost_center.columns
    if not col.startswith("_meta_")
]

log.debug("Exposed columns are: %s", exposed_columns)

# COMMAND ----------

table_utils.create_table_view(
    src_full_tablename=(f"{PIPELINE_WRITE_ENV}_gold.finance.budget_hourly_rates"),
    dest_full_tablename=(f"{PIPELINE_WRITE_ENV}_gold.finance.budget_hourly_rates_exposed"),
    select_statement=", ".join(exposed_columns),
    replace_view=True,
)
