# Databricks notebook source
# MAGIC %md
# MAGIC # Budget allocation key gold data asset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Description
# MAGIC The aim of this notebook is to create the gold data asset of the budget allocation key.
# MAGIC It is based on the budget workload stack of tables we ingested through Sigma.
# MAGIC
# MAGIC ## Highlighted complexities
# MAGIC - We create a "latest" data asset by filtering budget allocation key files to only keep
# MAGIC   the latest files ingested, for each budget version and fiscal year.
# MAGIC   - Budget version is an arbitrary number to differentiate between various budget drafts
# MAGIC   sent by the business.
# MAGIC   - Fiscal year is the civil year for which the work quantity is budgetized
# MAGIC   (note: there is only one fiscal year per file).
# MAGIC
# MAGIC ## Intended pipeline
# MAGIC `TODO` (Pipeline to be created)
# MAGIC
# MAGIC ## Pipeline input tables
# MAGIC - `{PIPELINE_READ_ENV}_bronze.sigma_budget_reporting.budget_allocation_key_stack`
# MAGIC
# MAGIC ## Reference input tables
# MAGIC None
# MAGIC
# MAGIC ## Pipeline output tables
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.budget_allocation_key`
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.budget_allocation_key_exposed` (view)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Technical debt
# MAGIC None identified yet

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config imports

# COMMAND ----------

from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f, Window

from leap_utils.common import logger
from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "Budget workload silver"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC Fix root logger

# COMMAND ----------

import logging

logging.getLogger().handlers.clear()

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import bronze budget allocation key stack table
# MAGIC
# MAGIC `df_budget_allocation_key_stack` is the bronze budget allocation key stack table ingested through Sigma.

# COMMAND ----------

df_budget_allocation_key_stack = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze"
    ".sigma_budget_reporting"
    ".budget_allocation_key_stack"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

FILENAME_WITH_TIMESTAMP_REGEX = r"^\d{8}\_\d{6}\_budget\_v(\d{1})\_(allocation_key)(?:\_(.*))?$"

# COMMAND ----------

# MAGIC %md
# MAGIC # Data transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 0 - Drop duplicates

# COMMAND ----------

df_budget_allocation_key_distinct = df_budget_allocation_key_stack.drop_duplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Extract information from filename metadata

# COMMAND ----------

df_budget_allocation_key_filename_meta_extraction = df_budget_allocation_key_distinct.withColumns(
    {
        col_name: f.regexp_extract(
            f.col("_meta_filename"),
            pattern=FILENAME_WITH_TIMESTAMP_REGEX,
            idx=index + 1,
        ).cast(_type)
        for index, (col_name, _type) in enumerate(
            [
                ("budget_version", "int"),
                ("budget_type", "string"),
                ("budget_comment", "string"),
            ]
        )
    }
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_allocation_key_filename_meta_extraction.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Find latest budget workload data per version, scope, etc

# COMMAND ----------

df_budget_latest_ranking = df_budget_allocation_key_filename_meta_extraction.withColumns(
    {
        "rank": f.dense_rank().over(
            Window.partitionBy(
                "fiscal_year",
                "budget_type",
                "budget_version",
            ).orderBy(
                f.col("_meta_ingestion_timestamp").desc(),
                f.col("_meta_modification_timestamp").desc(),
            )
        )
    }
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_latest_ranking.groupBy(
        "fiscal_year",
        "budget_type",
        "budget_version",
    ).agg(
        f.count(f.lit(1)),
        f.collect_set(f.col("rank")).alias("ranks"),
        f.collect_set(f.col("budget_comment")).alias("comments"),
    ).display()

df_budget_allocation_key_latest = df_budget_latest_ranking.where(
    f.col("rank") == f.lit(1)
).drop("rank")

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_allocation_key_latest.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output 1 - Save budget allocation key gold table

# COMMAND ----------

table_utils.save_table(
    dest_table=(
        f"{PIPELINE_WRITE_ENV}_gold.finance.budget_allocation_key"
    ),
    df=df_budget_allocation_key_latest,
    mode="overwrite",
    overwrite_schema=False,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output 2 - Save budget allocation key gold exposed view

# COMMAND ----------

log.debug("All columns are: %s", df_budget_allocation_key_latest.columns)

exposed_columns = [
    col
    for col in df_budget_allocation_key_latest.columns
    if not col.startswith("_meta_")
]

log.debug("Exposed columns are: %s", exposed_columns)

# COMMAND ----------

table_utils.create_table_view(
    src_full_tablename=(f"{PIPELINE_WRITE_ENV}_gold.finance.budget_allocation_key"),
    dest_full_tablename=(f"{PIPELINE_WRITE_ENV}_gold.finance.budget_allocation_key_exposed"),
    select_statement=", ".join(exposed_columns),
    replace_view=True,
)
