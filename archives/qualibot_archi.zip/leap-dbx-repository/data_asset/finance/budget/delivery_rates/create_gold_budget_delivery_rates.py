# Databricks notebook source
# MAGIC %md
# MAGIC # Budget delivery rates gold data asset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Description
# MAGIC The aim of this notebook is to create the gold data asset of the budget delivery rates data.
# MAGIC
# MAGIC ## Intended pipeline
# MAGIC `TODO` (Pipeline to be created)
# MAGIC
# MAGIC ## Pipeline input tables
# MAGIC - `{PIPELINE_READ_ENV}_silver.finance.budget_rates`
# MAGIC
# MAGIC ## Reference input tables
# MAGIC None
# MAGIC
# MAGIC ## Pipeline output tables
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.budget_rates`
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.budget_rates_exposed` (view)

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config imports

# COMMAND ----------

from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f, Window

from leap_utils.common import logger
from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "Budget delivery rates gold"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC Fix root logger

# COMMAND ----------

import logging

logging.getLogger().handlers.clear()

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import silver budget delivery rates table
# MAGIC
# MAGIC `df_budget_rates_silver` is the silver budget delivery rates table.

# COMMAND ----------

df_budget_rates_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.budget_rates"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import gold profit center data asset
# MAGIC
# MAGIC `df_profit_center_gold` is the gold profit center data asset table.

# COMMAND ----------

df_profit_center_gold = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Select columns of the profit center data asset

# COMMAND ----------

df_profit_center_selection = df_profit_center_gold.select(
    "Profit_Center_short", "Long_Description", "Accounting_PC_Group"
).withColumnsRenamed(
    {
        "Profit_Center_short": "profit_center",
        "Long_Description": "profit_center_description",
        "Accounting_PC_Group": "accounting_PC_group",
    }
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_profit_center_selection.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Augment budget delivery rates data asset with profit center data asset

# COMMAND ----------

df_budget_rates_with_PC = (
    df_budget_rates_silver.alias("df_rates")
    .join(
        df_profit_center_selection.alias("df_profit_center"),
        on=(
            (
                f.col("df_rates.profit_center")
                == f.col("df_profit_center.profit_center")
            )
        ),
        how="left",
    )
    .drop(f.col("df_profit_center.profit_center"))
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_rates_with_PC.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output 1 - Save budget delivery rates gold table

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.finance.budget_rates",
    df=df_budget_rates_with_PC,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output 2 - Save budget delivery rates gold exposed view

# COMMAND ----------

log.debug("All columns are: %s", df_budget_rates_with_PC.columns)

exposed_columns = [
    col
    for col in df_budget_rates_with_PC.columns
    if not col.startswith("_meta_")
]

log.debug("Exposed columns are: %s", exposed_columns)

# COMMAND ----------

table_utils.create_table_view(
    src_full_tablename=(f"{PIPELINE_WRITE_ENV}_gold.finance.budget_rates"),
    dest_full_tablename=(f"{PIPELINE_WRITE_ENV}_gold.finance.budget_rates_exposed"),
    select_statement=", ".join(exposed_columns),
    replace_view=True,
)
