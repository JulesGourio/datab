# Databricks notebook source
# MAGIC %md
# MAGIC # Budget workload gold data asset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Description
# MAGIC The aim of this notebook is to create the gold data asset of the budget workload data.
# MAGIC
# MAGIC ## Highlighted complexities
# MAGIC - There are cases where there are two profit center per cost center, depending on the
# MAGIC   controlling area PA01 or PA20, so by default, we choose the one from the controlling area PA01,
# MAGIC   to get the cost center to profit center mapping.
# MAGIC
# MAGIC ## Intended pipeline
# MAGIC `TODO` (Pipeline to be created)
# MAGIC
# MAGIC ## Pipeline input tables
# MAGIC - `{PIPELINE_READ_ENV}_silver.finance.budget_workload`
# MAGIC
# MAGIC ## Reference input tables
# MAGIC None
# MAGIC
# MAGIC ## Pipeline output tables
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.budget_workload`
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.budget_workload_exposed` (view)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Technical debt
# MAGIC In [Preparation 3.1 - Clean the cost center data asset]:
# MAGIC - We have to find `Is_valid` cost centers only, maybe it could be systematic and
# MAGIC   be done in the data asset ?
# MAGIC - We also need to remove leading zeroes for the profit center column, which should
# MAGIC   be done in the data asset, and we should check the impact of such change.

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config imports

# COMMAND ----------

from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f, Window

from leap_utils.common import logger
from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "Budget workload gold"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC Fix root logger

# COMMAND ----------

import logging

logging.getLogger().handlers.clear()

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import silver budget workload table
# MAGIC
# MAGIC `df_budget_workload_silver` is the silver budget workload table.

# COMMAND ----------

df_budget_workload_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.budget_workload"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import gold profit center data asset
# MAGIC
# MAGIC `df_profit_center_gold` is the gold profit center data asset table.

# COMMAND ----------

df_profit_center_gold = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import gold cost center data asset
# MAGIC
# MAGIC `df_cost_center_gold` is the gold cost center data asset table.

# COMMAND ----------

df_cost_center_gold = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.cost_center_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Select columns of the profit center data asset

# COMMAND ----------

df_profit_center_selection = df_profit_center_gold.select(
    "Profit_Center_short", "Long_Description", "Accounting_PC_Group"
).withColumnsRenamed(
    {
        "Profit_Center_short": "profit_center",
        "Long_Description": "profit_center_description",
        "Accounting_PC_Group": "accounting_PC_group",
    }
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_profit_center_selection.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Prepare the cost center data asset

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 2.1 - Clean the cost center data asset

# COMMAND ----------

df_cost_center_clean = df_cost_center_gold.where(f.col("Is_valid")).transform(
    table_utils.remove_leading_zeros, ["Profit_Center"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 2.2 - Select columns of the cost center data asset

# COMMAND ----------

df_cost_center_selection = df_cost_center_clean.select(
    "Controlling_Area", "Cost_center_short", "Profit_Center"
).withColumnsRenamed(
    {
        "Controlling_Area": "controlling_area",
        "Cost_center_short": "cost_center",
        "Profit_Center": "profit_center",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 2.3 - Find the first profit center for each cost center

# COMMAND ----------

df_cost_center_profit_center_mapping = (
    df_cost_center_selection.withColumn(
        "profit_center",
        f.first("profit_center").over(
            Window.partitionBy("cost_center").orderBy("controlling_area")
        ),
    )
    .select("cost_center", "profit_center")
    .distinct()
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_cost_center_profit_center_mapping.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Augment budget workload data asset with other gold tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1.1 - Add profit center data asset

# COMMAND ----------

df_budget_workload_with_PC = (
    df_budget_workload_silver.alias("df_workload")
    .join(
        df_profit_center_selection.alias("df_profit_center"),
        on=(
            (
                f.col("df_workload.profit_center")
                == f.col("df_profit_center.profit_center")
            )
        ),
        how="left",
    )
    .drop(f.col("df_profit_center.profit_center"))
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_workload_with_PC.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1.3 - Add cost center data asset

# COMMAND ----------

df_budget_workload_with_cost_center = (
    df_budget_workload_with_PC.alias("df_workload")
    .join(
        df_cost_center_profit_center_mapping.withColumnRenamed(
            "profit_center", "profit_center_of_cost_center"
        ).alias("df_cost_center"),
        on=((f.col("df_workload.cost_center") == f.col("df_cost_center.cost_center"))),
        how="left",
    )
    .drop(f.col("df_cost_center.cost_center"))
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_workload_with_cost_center.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output 1 - Save budget workload gold table

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.finance.budget_workload",
    df=df_budget_workload_with_cost_center,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output 2 - Save budget workload gold exposed view

# COMMAND ----------

log.debug("All columns are: %s", df_budget_workload_with_cost_center.columns)

exposed_columns = [
    col
    for col in df_budget_workload_with_cost_center.columns
    if not col.startswith("_meta_")
]

log.debug("Exposed columns are: %s", exposed_columns)

# COMMAND ----------

table_utils.create_table_view(
    src_full_tablename=(f"{PIPELINE_WRITE_ENV}_gold.finance.budget_workload"),
    dest_full_tablename=(f"{PIPELINE_WRITE_ENV}_gold.finance.budget_workload_exposed"),
    select_statement=", ".join(exposed_columns),
    replace_view=True,
)
