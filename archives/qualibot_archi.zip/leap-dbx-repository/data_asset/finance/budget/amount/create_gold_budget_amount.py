# Databricks notebook source
# MAGIC %md
# MAGIC # Budget amount gold data asset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Description
# MAGIC The aim of this notebook is to create the gold data asset of the budget amount data.
# MAGIC
# MAGIC ## Highlighted complexities
# MAGIC - For the cost center to profit center mapping, we use the first profit center
# MAGIC   for each cost center, especially when the profit center is different between the
# MAGIC   controlling areas PA01 and PA20.
# MAGIC
# MAGIC ## Intended pipeline
# MAGIC `TODO` (Pipeline to be created)
# MAGIC
# MAGIC ## Pipeline input tables
# MAGIC - `{PIPELINE_READ_ENV}_silver.finance.budget_amount`
# MAGIC - `{PIPELINE_READ_ENV}_gold.finance.budget_currency_exchange`
# MAGIC
# MAGIC ## Reference input tables
# MAGIC - `{REFERENCE_READ_ENV}_gold.finance.account_groups_exposed`
# MAGIC - `{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed`
# MAGIC - `{REFERENCE_READ_ENV}_gold.finance.cost_center_exposed`
# MAGIC
# MAGIC ## Pipeline output tables
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.budget_amount`
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.budget_amount_exposed` (view)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Technical debt
# MAGIC In [Preparation 3.1 - Clean the account groups data asset]:
# MAGIC - We have to remove leading zeroes of the account group column
# MAGIC   in the account groups data asset, it should be refactored in the data asset
# MAGIC   - And we should check impact of other usage of that data asset.
# MAGIC
# MAGIC In [Preparation 4.1 - Clean the cost center data asset]:
# MAGIC - We have to find `Is_valid` cost centers only, maybe it could be systematic and
# MAGIC   be done in the data asset ?
# MAGIC - We also need to remove leading zeroes for the profit center column, which should
# MAGIC   be done in the data asset, and we should check the impact of such change.
# MAGIC
# MAGIC In [Transformation 1 - Convert all amounts to Euro in budget rate]:
# MAGIC - We are using the currency currency exchange data asset,
# MAGIC   but we would prefer to use future rates for budget, the refactoring of the data
# MAGIC   asset in planned for 2025.

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config imports

# COMMAND ----------

from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f, Window

from leap_utils.common import logger
from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "Budget amount gold"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC Fix root logger

# COMMAND ----------

import logging

logging.getLogger().handlers.clear()

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import silver budget amount table
# MAGIC
# MAGIC `df_budget_amount_silver` is the silver budget amount table.

# COMMAND ----------

df_budget_amount_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.budget_amount"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import gold profit center data asset
# MAGIC
# MAGIC `df_profit_center_gold` is the gold profit center data asset table.

# COMMAND ----------

df_profit_center_gold = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import gold account groups data asset
# MAGIC
# MAGIC `df_account_groups_gold` is the gold account groups data asset table.

# COMMAND ----------

df_account_groups_gold = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.account_groups_exposed"
).where(f.col("Hierarchy_Level1") == "HIER-PC")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import gold currency exchange data asset
# MAGIC
# MAGIC `df_currency_exchange_gold` is the gold currency exchange rates data asset table.

# COMMAND ----------

df_currency_exchange_gold = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.finance.budget_currency_exchange"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import gold cost center data asset
# MAGIC
# MAGIC `df_cost_center_gold` is the gold cost center data asset table.

# COMMAND ----------

df_cost_center_gold = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.cost_center_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 0 - Rename profit center input in budget dataset

# COMMAND ----------

df_budget_amount_PC_renamed = df_budget_amount_silver.withColumnRenamed(
    "profit_center", "profit_center_input"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Find the latest budget rate date

# COMMAND ----------

latest_budget_date_available = (
    df_currency_exchange_gold.where(
        f.col("Conversion_rate_Type_exp") == f.lit("Budget")
    )
    .orderBy(f.col("Validity_Date_DateFormat").desc())
    .select("Validity_Date_DateFormat")
    .first()[0]
)

log.debug("Latest budget date: %s", latest_budget_date_available)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Select columns of the profit center data asset

# COMMAND ----------

df_profit_center_selection = df_profit_center_gold.select(
    "Profit_Center_short", "Long_Description", "Accounting_PC_Group"
).withColumnsRenamed(
    {
        "Profit_Center_short": "profit_center",
        "Long_Description": "profit_center_description",
        "Accounting_PC_Group": "accounting_PC_group",
    }
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_profit_center_selection.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Prepare the account groups data asset

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 3.1 - Clean the account groups data asset

# COMMAND ----------

df_account_groups_clean = table_utils.remove_leading_zeros(
    df=df_account_groups_gold, column_names=["Account_Number"]
)

if log.level <= logger.LOGGER_MAPPING["notset"]:
    df_account_groups_clean.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 3.2 - Select columns of the account groups data asset

# COMMAND ----------

df_account_groups_selection = df_account_groups_clean.select(
    "Account_Number", "Group_Name"
).withColumnsRenamed(
    {
        "Account_Number": "account_number",
        "Group_Name": "account_group",
    }
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_account_groups_selection.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Prepare the cost center data asset

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 4.1 - Clean the cost center data asset

# COMMAND ----------

df_cost_center_clean = (
    df_cost_center_gold.where(f.col("Is_valid"))
    .transform(table_utils.remove_leading_zeros, ["Profit_Center"])
    .where(f.col("Profit_Center").isNotNull())
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 4.2 - Select columns of the cost center data asset

# COMMAND ----------

df_cost_center_selection = df_cost_center_clean.select(
    "Controlling_Area", "Cost_center_short", "Profit_Center"
).withColumnsRenamed(
    {
        "Controlling_Area": "controlling_area",
        "Cost_center_short": "cost_center",
        "Profit_Center": "profit_center",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 4.3 - Find the first profit center for each cost center

# COMMAND ----------

df_cost_center_profit_center_mapping = (
    df_cost_center_selection.withColumn(
        "profit_center",
        f.first("profit_center").over(
            Window.partitionBy("cost_center").orderBy("controlling_area")
        ),
    )
    .select("cost_center", "profit_center")
    .distinct()
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_cost_center_profit_center_mapping.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Convert all amounts to Euro in budget rate

# COMMAND ----------

df_budget_amount_converted = table_utils.currency_conversion(
    df=df_budget_amount_PC_renamed.withColumn(
        "conversion_date", f.lit(latest_budget_date_available)
    ),
    df_currency=df_currency_exchange_gold,
    document_currency_column=f.col("currency_key"),
    rate_types=["Budget"],
    # TODO For budget rates, we need to use future conversion dates,
    #  we need to plan an evolution on the currency exchange data asset
    #  (and we should be careful on the impact it might produce on existing code)
    rate_dates=[f.col("conversion_date")],
    target_currency_value="EUR",
    document_amounts=[f.col("amount")],
    reference_read_env=REFERENCE_READ_ENV,
).withColumnsRenamed(
    {
        "currency_key_to_EUR_in_Budget_rate_at_conversion_date": "conversion_rate",
        "amount_from_currency_key_to_EUR_in_Budget_rate_at_conversion_date": "amount_EUR",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Augment budget amount data asset with other gold tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2.1 - Add account group data asset

# COMMAND ----------

df_budget_amount_with_account_group = (
    df_budget_amount_converted.alias("df_budget")
    .join(
        df_account_groups_selection.alias("df_account_groups"),
        on=(
            (
                f.col("df_budget.account_number")
                == f.col("df_account_groups.account_number")
            )
        ),
        how="left",
    )
    .drop(f.col("df_account_groups.account_number"))
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_amount_with_account_group.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2.2 - Add cost center data asset

# COMMAND ----------

df_budget_amount_with_cost_center = (
    df_budget_amount_with_account_group.alias("df_budget")
    .join(
        df_cost_center_profit_center_mapping.alias("df_cost_center"),
        on=((f.col("df_budget.cost_center") == f.col("df_cost_center.cost_center"))),
        how="left",
    )
    .drop(f.col("df_cost_center.cost_center"))
).withColumn("profit_center", f.coalesce("profit_center", "profit_center_input"))

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_amount_with_cost_center.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2.3 - Add profit center data asset

# COMMAND ----------

df_budget_amount_with_PC_of_CC = (
    df_budget_amount_with_cost_center.alias("df_budget")
    .join(
        df_profit_center_selection.alias("df_profit_center"),
        on=(
            (
                f.col("df_budget.profit_center")
                == f.col("df_profit_center.profit_center")
            )
        ),
        how="left",
    )
    .drop(f.col("df_profit_center.profit_center"))
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_budget_amount_with_PC_of_CC.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output 1 - Save budget amount gold table

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.finance.budget_amount",
    df=df_budget_amount_with_PC_of_CC,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output 2 - Save budget amount gold exposed view

# COMMAND ----------

log.debug("All columns are: %s", df_budget_amount_with_PC_of_CC.columns)

exposed_columns = [
    col
    for col in df_budget_amount_with_PC_of_CC.columns
    if not col.startswith("_meta_")
]

log.debug("Exposed columns are: %s", exposed_columns)

# COMMAND ----------

table_utils.create_table_view(
    src_full_tablename=(f"{PIPELINE_WRITE_ENV}_gold.finance.budget_amount"),
    dest_full_tablename=(f"{PIPELINE_WRITE_ENV}_gold.finance.budget_amount_exposed"),
    select_statement=", ".join(exposed_columns),
    replace_view=True,
)
