# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table & Gold_Exposed for cost center groups through silver table. 
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - `{PIPELINE_WRITE_ENV}_gold.finance.cost_center_groups`
# MAGIC   - `{PIPELINE_WRITE_ENV}_gold.finance.cost_center_groups_exposed`
# MAGIC
# MAGIC **Input :** 
# MAGIC   - `{PIPELINE_READ_ENV}_silver.finance.cost_center_groups`
# MAGIC   - `{PIPELINE_READ_ENV}_silver.finance.controlling_objects_groups_hierarchy`
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> 
# MAGIC
# MAGIC **Things done:** 
# MAGIC - version 3 of the feature: add hierarchy columns by joining silver tables cost_center_groups and group_hierarchy, add Cost_Center_Description, add group_description at each hierarchy level                                         
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
from pyspark.sql import DataFrame as DataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

# Get pipeline read environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Get pipeline write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files 

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_SCHEMA = f"{PIPELINE_READ_ENV}_silver.finance"

TABLE_COST_CENTER_GROUPS_SILVER = f"{SILVER_SCHEMA}.cost_center_groups"

TABLE_GROUP_HIERARCHY_SILVER = f"{SILVER_SCHEMA}.controlling_objects_groups_hierarchy"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

GOLD_SCHEMA = f"{PIPELINE_WRITE_ENV}_gold.finance"

TABLE_COST_CENTER_GROUPS_GOLD = f"{GOLD_SCHEMA}.cost_center_groups"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# MAGIC %md
# MAGIC #### Common global variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs 
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"GOLD_SCHEMA is:  {GOLD_SCHEMA}")
log.info(f"TABLE_COST_CENTER_GROUPS_SILVER is:  {TABLE_COST_CENTER_GROUPS_SILVER}")
log.info(f"TABLE_GROUP_HIERARCHY_SILVER is:  {TABLE_GROUP_HIERARCHY_SILVER}")
log.info(f"TABLE_COST_CENTER_GROUPS_GOLD is:  {TABLE_COST_CENTER_GROUPS_GOLD}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Tables Read

# COMMAND ----------

df_cost_center_groups = spark.read.table(
    f"{TABLE_COST_CENTER_GROUPS_SILVER }"
)  # <- Upload co cost center groups silver with Cost_center and Cost_Center_Description

# COMMAND ----------

df_group_hierarchy = spark.read.table(
    f"{TABLE_GROUP_HIERARCHY_SILVER }"
)  # <- Upload co setnode exploded

df_group_hierarchy = df_group_hierarchy.filter(f.col("Group_Category") == "0101")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Management of Null values

# COMMAND ----------

# Replace all null value by Unknown
columns_to_replace = ["Group_Description", "Cost_Center_Description"]
replacement_value = "Unknown"
replacement_values = {col_name: replacement_value for col_name in columns_to_replace}
df_cost_center_groups = df_cost_center_groups.fillna(replacement_values)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Main work
# MAGIC - Add group hierarchy data for Level1 to Levelx by joining tables account_groups and group_hierarchy
# MAGIC

# COMMAND ----------

selected_columns = [f"A.{column}" for column in df_cost_center_groups.columns]
selected_columns += [
    f"B.{column}"
    for column in df_group_hierarchy.columns
    if column.startswith("Hierarchy")
]

# join cost_center_groups and group_hierarchy on fields : mandt, Group_Category, Group_SubCategory, Group_Name -> Hiercharchy_LastLevel
df_cost_center_groups_joined = (
    df_cost_center_groups.alias("A")
    .join(
        df_group_hierarchy.alias("B"),
        (f.col("A.SETHEADER_mandt") == f.col("B.SETNODE_mandt"))
        & (f.col("A.Group_Category") == f.col("B.Group_Category"))
        & (f.col("A.Group_SubCategory") == f.col("B.Group_SubCategory"))
        & (f.col("A.Group_Name") == f.col("B.Hierarchy_LastLevel")),
        "inner",
    )
    .select(selected_columns)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug step

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    df_grouped = (
        df_cost_center_groups_joined.select(
            "Group_Category",
            "Group_SubCategory",
            "Group_Name",
            "Group_Type",
            "Cost_Center",
        )
        .groupBy("Group_Category", "Group_SubCategory", "Cost_Center")
        .agg(f.count("*").alias("count"))
        .filter(f.col("count") > 1)
    )
    # df_grouped.display()
    df_debug = df_cost_center_groups_joined.select(
        "Group_Category",
        "Group_SubCategory",
        "Group_Name",
        "Group_Description",
        "Group_Type",
        "Cost_Center",
        "Cost_Center_Description",
        "Hierarchy_Level1",
        "Hierarchy_Level2",
        "Hierarchy_Level3",
        "Hierarchy_Level4",
        "Hierarchy_Level5",
        "Hierarchy_Level6",
        "Hierarchy_Level7",
        "Hierarchy_Level8",
        "Hierarchy_Level9",
        "Hierarchy_Level1_Description",
        "Hierarchy_Level2_Description",
        "Hierarchy_Level3_Description",
        "Hierarchy_Level4_Description",
        "Hierarchy_Level5_Description",
        "Hierarchy_Level6_Description",
        "Hierarchy_Level7_Description",
        "Hierarchy_Level8_Description",
        "Hierarchy_Level9_Description",
    ).join(df_grouped, ["Group_Category", "Group_SubCategory", "Cost_Center"], "inner")
    df_debug.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Renaming columns Ad'hoc
# MAGIC - Renaming generic group columns to cost_center specific ones
# MAGIC

# COMMAND ----------

dict_to_rename_dataframe_columns = {
    "Group_Name": "Cost_Center_Group",
    "Group_Description": "Cost_Center_Group_Description",
    "Group_Category": "Controlling_Object_Group_Category",
    "Group_SubCategory": "Controlling_Object_Group_SubCategory",
    "Group_Type": "Controlling_Object_Group_Type",
}

df_cost_center_groups_joined = df_cost_center_groups_joined.withColumnsRenamed(
    dict_to_rename_dataframe_columns
)

df_cost_center_groups_joined = table_utils.add_prefix_to_columns_startingwith(
    df=df_cost_center_groups_joined,
    prefix="Cost_Center_Group",
    column_startswith="Hierarchy_",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Gold Table

# COMMAND ----------

log.info(f"Saving {TABLE_COST_CENTER_GROUPS_GOLD}.")
try:
    table_utils.save_table(
        dest_table=TABLE_COST_CENTER_GROUPS_GOLD,
        df=df_cost_center_groups_joined,
        mode="overwrite",
        overwrite_schema=True,
    )
except Exception as e:
    log.error(
        f"Table {TABLE_COST_CENTER_GROUPS_GOLD} has not been created, an error occured during save."
    )
    log.error(f"Error : {e}")
    raise Exception()
else:
    log.info(
        f"Data saved into history count {df_cost_center_groups_joined.count()} rows."
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Gold Exposed View

# COMMAND ----------

src_full_tablename = f"{TABLE_COST_CENTER_GROUPS_GOLD}"
dest_full_tablename = f"{TABLE_COST_CENTER_GROUPS_GOLD}_exposed"
Begin_By = "SETHEADER"

selected_columns = [
    col for col in df_cost_center_groups_joined.columns if not col.startswith(Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
