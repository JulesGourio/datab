# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for hiercharchy explosion of "setnode" table.
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - `{PIPELINE_WRITE_ENV}_silver.finance.controlling_objects_groups_hierarchy`
# MAGIC
# MAGIC **Input :**  
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.setnode_latest`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_setnode`
# MAGIC   - `{PIPELINE_READ_ENV}_silver.finance.controlling_objects_groups`
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> Ingestion raw data SAP
# MAGIC
# MAGIC **Things done:** 
# MAGIC   - explode table setnode to as many columns as hierarchy levels
# MAGIC   - join with silver controlling objects groups table to get the description at each level of the hierarchy

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
from pyspark.sql import DataFrame as DataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

# Get reference read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Get pipeline read environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Get pipeline write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files 

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

BRONZE_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6"
BRONZE_HEADERS_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.headers_sap"
SILVER_SCHEMA = f"{PIPELINE_READ_ENV}_silver.finance"

TABLE_SETNODE_BRONZE = f"{BRONZE_SCHEMA}.setnode_latest"

TABLE_NAME_SETNODE = f"{BRONZE_HEADERS_SCHEMA}.headers_sap_business_setnode"

TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER = f"{SILVER_SCHEMA}.controlling_objects_groups"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

TABLE_GROUP_HIERARCHY_SILVER = f"{PIPELINE_WRITE_ENV}_silver.finance.controlling_objects_groups_hierarchy"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# MAGIC %md
# MAGIC #### Common global variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs 
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"TABLE_SETNODE_BRONZE is:  {TABLE_SETNODE_BRONZE}")
log.info(
    f"TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER is:  {TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER}"
)
log.info(f"TABLE_GROUP_HIERARCHY_SILVER is:  {TABLE_GROUP_HIERARCHY_SILVER}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Tables Read

# COMMAND ----------

df_setnode = spark.read.table(f"{TABLE_SETNODE_BRONZE}")  # <- Upload SAP table setnode

# COMMAND ----------

df_name_setnode = spark.read.table(
    f"{TABLE_NAME_SETNODE}"
)  # <- Upload manual table for headers naming

# COMMAND ----------

df_controlling_objects_groups = spark.read.table(
    TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Filtering SETNODE columns

# COMMAND ----------

df_setnode = df_setnode.select(
    "mandt",
    "setclass",
    "subclass",
    "setname",
    "lineid",
    "subsetcls",
    "subsetscls",
    "subsetname",
    "seqnr",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Filtering controlling objects groups columns

# COMMAND ----------

df_controlling_objects_groups = (
    df_controlling_objects_groups.select(
        "Group_Category",
        "Group_SubCategory",
        "Group_Name",
        "Group_Description",
    )
    .withColumnRenamed("Group_Category", "setclass")
    .withColumnRenamed("Group_SubCategory", "subclass")
    .withColumnRenamed("Group_Name", "setname")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Persist dataframes used many times for performance

# COMMAND ----------

df_setnode.persist()
df_controlling_objects_groups.persist()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Controlling objects groups top of hierarchy

# COMMAND ----------

# Filter df_setnode for groups on top of hierarchy and put it in df_group_top_hierarchy
df_group_top_hierarchy = (
    df_setnode.alias("setnode1")
    .join(
        df_setnode.alias("setnode2"),
        (
            (f.col("setnode1.mandt") == f.col("setnode2.mandt"))
            & (f.col("setnode1.setclass") == f.col("setnode2.subsetcls"))
            & (f.col("setnode1.subclass") == f.col("setnode2.subsetscls"))
            & (f.col("setnode1.setname") == f.col("setnode2.subsetname"))
        ),
        "leftanti",
    )
    .join(
        df_controlling_objects_groups.alias("controlling_objects_groups"),
        on=["setclass", "subclass", "setname"],
        how="left",
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Main work
# MAGIC - recurse join df_setnode to explode parent-child to as many columns as hierarchy levels
# MAGIC

# COMMAND ----------

# initial DataFrame based on df_group_top_hierarchy
df_group_hierarchy = (
    df_group_top_hierarchy.withColumnRenamed("setname", "level_1")
    .withColumnRenamed("subsetname", "level_2")
    .withColumnRenamed("setclass", "joinclass")
    .withColumnRenamed("subclass", "joinsubclass")
    .withColumnRenamed("subsetcls", "original_subsetcls")
    .withColumnRenamed("subsetscls", "original_subsetscls")
    .withColumnRenamed("Group_Description", "level_1_description")
)

# COMMAND ----------

# Loop Through if you dont know recusrsive depth and join with original Dataframe df_setnode
current_level = 2
end_loop = False
while end_loop == False:
    this_level = "level_{}".format(current_level)
    this_level_description = "level_{}_description".format(current_level)
    next_level = "level_{}".format(current_level + 1)
    df_setnode_nextlevel = (
        df_setnode.withColumnRenamed("setname", this_level)
        .withColumnRenamed("subsetname", next_level)
        .withColumnRenamed("subsetcls", "joinclass")
        .withColumnRenamed("subsetscls", "joinsubclass")
    )

    df_controlling_objects_groups_renamed = (
        df_controlling_objects_groups.withColumnRenamed(
            "setname", this_level
        ).withColumnRenamed("Group_Description", this_level_description)
    )

    df_setnode_nextlevel = df_setnode_nextlevel.join(
        df_controlling_objects_groups_renamed.alias("controlling_objects_groups"),
        on=["setclass", "subclass", this_level],
        how="left",
    )

    df_group_hierarchy = df_group_hierarchy.join(
        df_setnode_nextlevel,
        on=[this_level, "mandt", "joinclass", "joinsubclass"],
        how="left",
    )

    df_group_hierarchy = df_group_hierarchy.drop(
        "setclass", "subclass", "lineid", "seqnr"
    )

    # Check if DF is empty. Break loop if empty, Otherwise continue with next level
    if df_group_hierarchy.where(f.col(next_level).isNotNull()).count() == 0:
        end_loop = True
        df_group_hierarchy_endloop = df_group_hierarchy
    else:
        current_level += 1

nb_levels = current_level

# Add column 'NbLevels' to initial value i and 'LastLevel' to column value of {this_level}
df_group_hierarchy_nblevels = df_group_hierarchy_endloop.withColumn(
    "NbLevels", f.lit(nb_levels)
).withColumn("LastLevel", f.col(f"{this_level}"))

# Rename columns to original name
df_group_hierarchy_setclass = df_group_hierarchy_nblevels.withColumnRenamed(
    "joinclass", "setclass"
).withColumnRenamed("joinsubclass", "subclass")

# Update columns NbLevels and LastLevel to exact value for each row
# Update description of lastlevel
for level in range(nb_levels, 1, -1):
    current_level = "level_{}".format(level)
    current_level_description = "level_{}_description".format(level)

    # Join last level with df_controlling_objects_groups_renamed to get description of last level
    df_controlling_objects_groups_renamed = (
        df_controlling_objects_groups.withColumnRenamed(
            "setname", current_level
        ).withColumnRenamed("Group_Description", current_level_description)
    )
    df_group_hierarchy_setclass = df_group_hierarchy_setclass.drop(
        current_level_description
    )
    df_group_hierarchy_setclass = df_group_hierarchy_setclass.join(
        df_controlling_objects_groups_renamed.alias("controlling_objects_groups"),
        on=["setclass", "subclass", current_level],
        how="left",
    )

    upper_level = "level_{}".format(level - 1)
    df_group_hierarchy_setclass = df_group_hierarchy_setclass.withColumn(
        "NbLevels",
        f.when(
            f.col(f"{current_level}").isNull() == True, f.col("NbLevels") - 1
        ).otherwise(f.col("NbLevels")),
    ).withColumn(
        "LastLevel",
        f.when(
            f.col(f"{current_level}").isNull() == True, f.col(f"{upper_level}")
        ).otherwise(f.col("LastLevel")),
    )

# Drop unused levels columns
# df_group_hierarchy_end = df_group_hierarchy_end.drop(
#     this_level, next_level, "original_subsetcls", "original_subsetscls"
# )
df_group_hierarchy_end = df_group_hierarchy_setclass.drop(
    "original_subsetcls", "original_subsetscls"
)

# Sélection et tri des colonnes
selected_columns = (
    ["mandt", "setclass", "subclass"]
    + [f"level_{k}" for k in range(1, nb_levels + 1)]
    + [f"level_{k}_description" for k in range(1, nb_levels + 1)]
    + ["NbLevels", "LastLevel"]
)

df_group_hierarchy_end = df_group_hierarchy_end.select(*selected_columns)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Post Processing
# MAGIC
# MAGIC - Renaming Table columns beginning by SETNODE
# MAGIC
# MAGIC

# COMMAND ----------

df_group_hierarchy_end = table_utils.add_prefix_to_columns(
    df_group_hierarchy_end, "SETNODE"
)

table_utils.check_schema_of_the_header_file(
    df_name_setnode
)  # <- call function Check Header files
df_name_setnode = delete_null_rows(df_name_setnode)  # <- Call Function Delete rows null

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_group_hierarchy_end, df_name_setnode
)
# Call Funtion Create Columns on Date format
df_group_hierarchy_final = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_setnode
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Silver Table

# COMMAND ----------

log.info(f"Saving {TABLE_GROUP_HIERARCHY_SILVER}.")
try:
    table_utils.save_table(
        dest_table=TABLE_GROUP_HIERARCHY_SILVER,
        df=df_group_hierarchy_final,
        mode="overwrite",
        overwrite_schema=True,
    )
except Exception as e:
    log.error(
        f"Table {TABLE_GROUP_HIERARCHY_SILVER} has not been created, an error occured during save."
    )
    log.error(f"Error : {e}")
    raise Exception()
else:
    log.info(f"Data saved into history count {df_group_hierarchy_final.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
