# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for data asset controlling profit center groups.
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - `{PIPELINE_WRITE_ENV}_silver.finance.profit_center_groups`
# MAGIC
# MAGIC **Input :**  
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.setleaf_latest`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_setleaf`
# MAGIC   - `{PIPELINE_READ_ENV}_silver.finance.controlling_objects_groups`
# MAGIC   - `{PIPELINE_READ_ENV}_gold.finance.profit_center`
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> Ingestion raw data SAP
# MAGIC
# MAGIC **Things done:** 
# MAGIC - Renaming Headers
# MAGIC - Cleansing data :
# MAGIC  filter setleaf on setclass "0106"
# MAGIC
# MAGIC **Technical debt:** 
# MAGIC - table header for SETLEAF has a column mapping for subclass which is not suitable for PC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
from pyspark.sql import DataFrame as DataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

# Get reference read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Get pipeline read environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Get pipeline write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files 

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

BRONZE_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6"
BRONZE_HEADERS_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.headers_sap"
SILVER_SCHEMA = f"{PIPELINE_READ_ENV}_silver.finance"
GOLD_SCHEMA = f"{PIPELINE_READ_ENV}_gold.finance"

TABLE_SETLEAF_BRONZE = f"{BRONZE_SCHEMA}.setleaf_latest"

TABLE_NAME_SETLEAF = f"{BRONZE_HEADERS_SCHEMA}.headers_sap_business_setleaf"

TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER = f"{SILVER_SCHEMA}.controlling_objects_groups"

TABLE_PROFIT_CENTER_GOLD = f"{GOLD_SCHEMA}.profit_center"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

TABLE_PROFIT_CENTER_GROUPS_SILVER = (
    f"{PIPELINE_WRITE_ENV}_silver.finance.profit_center_groups"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# MAGIC %md
# MAGIC #### Common global variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs 
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"GOLD_SCHEMA is:  {GOLD_SCHEMA}")
log.info(
    f"TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER is:  {TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER}"
)
log.info(f"TABLE_PROFIT_CENTER_GOLD is:  {TABLE_PROFIT_CENTER_GOLD}")
log.info(f"TABLE_PROFIT_CENTER_GROUPS_SILVER is:  {TABLE_PROFIT_CENTER_GROUPS_SILVER}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Tables Read

# COMMAND ----------

df_setleaf = spark.read.table(f"{TABLE_SETLEAF_BRONZE}")  # <- Upload SAP table setleaf

# COMMAND ----------

df_name_setleaf = spark.read.table(
    f"{TABLE_NAME_SETLEAF}"
)  # <- Upload manual table for headers naming

# COMMAND ----------

df_profit_center = spark.read.table(
    f"{TABLE_PROFIT_CENTER_GOLD}"
)  # <- Upload Gold table table_profit_center

df_profit_center = df_profit_center.withColumnRenamed("CEPC_kokrs", "Controlling_Area")

pc_cols = [
    cname for cname in df_profit_center.columns if not cname.lower().startswith("cepc_")
]
df_profit_center = df_profit_center.select(*pc_cols)

# COMMAND ----------

df_controlling_objects_groups = spark.read.table(
    TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Filtering SETLEAF on setclass=="0106"

# COMMAND ----------

# Filter on df_setleaf.setclass=="0106"
df_setleaf = df_setleaf.filter(df_setleaf.setclass == "0106")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Filtering groups on Group_SubCategory "PA01","PA20"

# COMMAND ----------

df_controlling_objects_groups = df_controlling_objects_groups.filter(
    df_controlling_objects_groups.Group_SubCategory.isin(["PA01", "PA20"])
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Renaming SETLEAF Table columns

# COMMAND ----------

df_setleaf = table_utils.add_prefix_to_columns(
    df_setleaf, "SETLEAF"
)  # <- Renaming starting with SETLEAF_

table_utils.check_schema_of_the_header_file(
    df_name_setleaf
)  # <- call function Check Header files
df_name_setleaf = delete_null_rows(df_name_setleaf)  # <- Call Function Delete rows null

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_setleaf, df_name_setleaf
)
dfleaf = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_setleaf
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Renaming SETLEAF Account_Number to Profit_Center

# COMMAND ----------

# Technical debt because we already have a naming for the columns of SETLEAF
dfleaf = dfleaf.withColumnRenamed("Account_Number", "Profit_Center")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Join tables
# MAGIC

# COMMAND ----------

# join controlling_objects_groups (SETHEADER) to leaf (SETLEAF), then to profit_centers
df_silver_fcg = (
    df_controlling_objects_groups.alias("A")
    .join(
        dfleaf.alias("B"),
        (f.col("A.SETHEADER_mandt") == f.col("B.SETLEAF_mandt"))
        & (f.col("A.Group_Category") == f.col("B.Group_Category"))
        & (f.col("A.Group_SubCategory") == f.col("B.Group_SubCategory"))
        & (f.col("A.Group_Name") == f.col("B.Group_Name")),
        "inner",
    )
    .join(
        df_profit_center.alias("C"),
        (f.col("B.Profit_Center") == f.col("C.Profit_Center"))
        & (f.col("B.Group_SubCategory") == f.col("C.Controlling_Area")),
        "left",
    )
    .select(
        f.col("A.*"),
        f.col("B.Rank_Number").alias("Rank_Number"),
        f.col("C.Profit_Center").alias("Profit_Center"),
        f.col("C.Profit_Center_short").alias("Profit_Center_short"),
        f.col("C.Long_Description").alias("Profit_Center_Description"),
    )
    .filter(f.col("C.Profit_Center").isNotNull())
    .withColumn("Profit_Center",f.col("Profit_Center_short"))
    .drop(f.col("Profit_Center_short"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Silver Table

# COMMAND ----------

log.info(f"Saving {TABLE_PROFIT_CENTER_GROUPS_SILVER}.")
try:
    table_utils.save_table(
        dest_table=TABLE_PROFIT_CENTER_GROUPS_SILVER,
        df=df_silver_fcg,
        mode="overwrite",
        overwrite_schema=True,
    )
except Exception as e:
    log.error(
        f"Table {TABLE_PROFIT_CENTER_GROUPS_SILVER} has not been created, an error occured during save."
    )
    log.error(f"Error : {e}")
    raise Exception()
else:
    log.info(f"Data saved into history count {df_silver_fcg.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug step

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    rows = df_profit_center.count()
    log.debug(f"Dataframe df_profit_center rows count : {rows}")
    rows = dfleaf.count()
    log.debug(f"Dataframe dfleaf rows count : {rows}")
    rows = df_silver_fcg.count()
    log.debug(f"Dataframe df_silver_fcg rows count : {rows}")
    rows = df_silver_fcg.filter("Group_Description is NULL").count()
    log.debug(
        f"Dataframe df_silver_fcg with null Group_Description , rows count : {rows}"
    )
    rows = df_silver_fcg.filter("Profit_Center_Description is NULL").count()
    log.debug(
        f"Dataframe df_silver_fcg with null Profit_Center_Description , rows count : {rows}"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
