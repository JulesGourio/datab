# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table & Gold_Exposed for PNL account groups through silver table. 
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - `{PIPELINE_WRITE_ENV}_gold.finance.account_groups`
# MAGIC   - `{PIPELINE_WRITE_ENV}_gold.finance.account_groups_exposed`
# MAGIC
# MAGIC **Input :** 
# MAGIC   - `{PIPELINE_READ_ENV}_silver.finance.account_groups_numbers_pnl`
# MAGIC   - `{PIPELINE_READ_ENV}_silver.finance.controlling_objects_groups_hierarchy`
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> 
# MAGIC
# MAGIC **Things done:** 
# MAGIC - version 3 of the feature: add hierarchy columns by joining silver tables account_groups and group_hierarchy, add account_description, add group_description at each hierarchy level                                         
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
from pyspark.sql import DataFrame as DataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

# Get pipeline read environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Get pipeline write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files 

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_SCHEMA = f"{PIPELINE_READ_ENV}_silver.finance"

TABLE_ACCOUNT_GROUPS_NUMBERS_SILVER = f"{SILVER_SCHEMA}.account_groups_numbers_pnl"

TABLE_GROUP_HIERARCHY_SILVER = f"{SILVER_SCHEMA}.controlling_objects_groups_hierarchy"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

GOLD_SCHEMA = f"{PIPELINE_WRITE_ENV}_gold.finance"

TABLE_ACCOUNT_GROUPS_NUMBERS_GOLD = f"{GOLD_SCHEMA}.account_groups"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# MAGIC %md
# MAGIC #### Common global variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs 
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"GOLD_SCHEMA is:  {GOLD_SCHEMA}")
log.info(
    f"TABLE_ACCOUNT_GROUPS_NUMBERS_SILVER is:  {TABLE_ACCOUNT_GROUPS_NUMBERS_SILVER}"
)
log.info(f"TABLE_GROUP_HIERARCHY_SILVER is:  {TABLE_GROUP_HIERARCHY_SILVER}")
log.info(f"TABLE_ACCOUNT_GROUPS_NUMBERS_GOLD is:  {TABLE_ACCOUNT_GROUPS_NUMBERS_GOLD}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Tables Read

# COMMAND ----------

df_account_groups = spark.read.table(
    f"{TABLE_ACCOUNT_GROUPS_NUMBERS_SILVER }"
)  # <- Upload co account groups silver with account_number and Account_Description

# COMMAND ----------

df_group_hierarchy = spark.read.table(
    f"{TABLE_GROUP_HIERARCHY_SILVER }"
)  # <- Upload co setnode exploded

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Management of Null values

# COMMAND ----------

# Replace all null value by Unknown
columns_to_replace = ["Group_Description", "Account_Description"]
replacement_value = "Unknown"
replacement_values = {col_name: replacement_value for col_name in columns_to_replace}
df_account_groups = df_account_groups.fillna(replacement_values)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Main work
# MAGIC - Add group hierarchy data for Level1 to Levelx by joining tables account_groups and group_hierarchy
# MAGIC

# COMMAND ----------

selected_columns = [f"A.{column}" for column in df_account_groups.columns]
selected_columns += [
    f"B.{column}"
    for column in df_group_hierarchy.columns
    if column.startswith("Hierarchy")
]

# join account_groups and group_hierarchy on fields : mandt, Group_Category, Group_SubCategory, Group_Name -> Hiercharchy_LastLevel
df_account_groups_joined = (
    df_account_groups.alias("A")
    .join(
        df_group_hierarchy.alias("B"),
        (f.col("A.SETHEADER_mandt") == f.col("B.SETNODE_mandt"))
        & (f.col("A.Group_Category") == f.col("B.Group_Category"))
        & (f.col("A.Group_SubCategory") == f.col("B.Group_SubCategory"))
        & (f.col("A.Group_Name") == f.col("B.Hierarchy_LastLevel")),
        "left",
    )
    .select(selected_columns)
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Gold Table

# COMMAND ----------

log.info(f"Saving {TABLE_ACCOUNT_GROUPS_NUMBERS_GOLD}.")
try:
    table_utils.save_table(
        dest_table=TABLE_ACCOUNT_GROUPS_NUMBERS_GOLD,
        df=df_account_groups_joined,
        mode="overwrite",
        overwrite_schema=True,
    )
except Exception as e:
    log.error(
        f"Table {TABLE_ACCOUNT_GROUPS_NUMBERS_GOLD} has not been created, an error occured during save."
    )
    log.error(f"Error : {e}")
    raise Exception()
else:
    log.info(f"Data saved into history count {df_account_groups_joined.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Gold Exposed View

# COMMAND ----------

src_full_tablename = f"{TABLE_ACCOUNT_GROUPS_NUMBERS_GOLD}"
dest_full_tablename = f"{TABLE_ACCOUNT_GROUPS_NUMBERS_GOLD}_exposed"
Begin_By = "SETHEADER"

selected_columns = [
    col for col in df_account_groups_joined.columns if not col.startswith(Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
