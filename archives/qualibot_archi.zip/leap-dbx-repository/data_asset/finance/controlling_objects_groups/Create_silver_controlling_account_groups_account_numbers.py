# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for data asset controlling account groups.
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - `{PIPELINE_WRITE_ENV}_silver.finance.account_groups_numbers_pnl`
# MAGIC
# MAGIC **Input :**  
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.setleaf_latest`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_setleaf`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.skat_latest`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_skat`
# MAGIC   - `{PIPELINE_READ_ENV}_silver.finance.controlling_objects_groups`
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> Ingestion raw data SAP
# MAGIC
# MAGIC **Things done:** 
# MAGIC - Renaming Headers
# MAGIC - Cleansing data :
# MAGIC  filter setleaf on setclass "0109" and setname start with "RNR*"
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
from pyspark.sql import DataFrame as DataFrame
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

# Get reference read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Get pipeline read environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Get pipeline write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files 

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

BRONZE_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6"
BRONZE_HEADERS_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.headers_sap"
SILVER_SCHEMA = f"{PIPELINE_READ_ENV}_silver.finance"
GOLD_SCHEMA = f"{PIPELINE_READ_ENV}_gold.finance"

TABLE_SETLEAF_BRONZE = f"{BRONZE_SCHEMA}.setleaf_latest"

TABLE_NAME_SETLEAF = f"{BRONZE_HEADERS_SCHEMA}.headers_sap_business_setleaf"

TABLE_SKAT_BRONZE = f"{BRONZE_SCHEMA}.skat_latest"

TABLE_NAME_SKAT = f"{BRONZE_HEADERS_SCHEMA}.headers_sap_business_skat"

TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER = f"{SILVER_SCHEMA}.controlling_objects_groups"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

TABLE_ACCOUNT_GROUPS_NUMBERS_SILVER = (
    f"{PIPELINE_WRITE_ENV}_silver.finance.account_groups_numbers_pnl"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# MAGIC %md
# MAGIC #### Common global variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs 
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"GOLD_SCHEMA is:  {GOLD_SCHEMA}")
log.info(
    f"TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER is:  {TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER}"
)
log.info(
    f"TABLE_ACCOUNT_GROUPS_NUMBERS_SILVER is:  {TABLE_ACCOUNT_GROUPS_NUMBERS_SILVER}"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Tables Read

# COMMAND ----------

df_setleaf = spark.read.table(f"{TABLE_SETLEAF_BRONZE}")  # <- Upload SAP table setleaf

# COMMAND ----------

df_name_setleaf = spark.read.table(
    f"{TABLE_NAME_SETLEAF}"
)  # <- Upload manual table for headers naming

# COMMAND ----------

df_skat = spark.read.table(f"{TABLE_SKAT_BRONZE}")  # <- Upload Bronze table skat

# COMMAND ----------

df_name_skat = spark.read.table(
    f"{TABLE_NAME_SKAT}"
)  # <- Upload manual table for headers naming

# COMMAND ----------

df_controlling_objects_groups = spark.read.table(
    TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Filtering SETLEAF on setclass=="0109" for P&L - on setname startswith "RNR" for P&L or startswith "BAS" for OCF

# COMMAND ----------

# Filter on df_setleaf.setclass=="0109" and df_setleaf.setname.startswith("RNR") - could also add df_setleaf.valoption=="EQ" but not done at this step
df_setleaf = df_setleaf.filter(df_setleaf.setclass == "0109").filter(
    df_setleaf.setname.startswith("RNR") | df_setleaf.setname.startswith("BAS")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Filtering groups on Group_Category "0109"

# COMMAND ----------

df_controlling_objects_groups = df_controlling_objects_groups.filter(
    df_controlling_objects_groups.Group_Category == "0109"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Renaming SETLEAF Table columns

# COMMAND ----------

df_setleaf = table_utils.add_prefix_to_columns(
    df_setleaf, "SETLEAF"
)  # <- Renaming starting with SETLEAF_

table_utils.check_schema_of_the_header_file(
    df_name_setleaf
)  # <- call function Check Header files
df_name_setleaf = delete_null_rows(df_name_setleaf)  # <- Call Function Delete rows null

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_setleaf, df_name_setleaf
)
dfleaf = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_setleaf
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Filtering SKAT on duplicate languages - keeping E only

# COMMAND ----------

# Filtering on SAP fields : partition on "mandt","setclass","subclass","setname" , sorted by "langu" (language) and keeping 1st occurence of language
w = Window.partitionBy("mandt", "ktopl", "saknr").orderBy("spras")
df_skat_before_filtering = df_skat
df_skat = (
    df_skat.filter((df_skat.spras == "E"))
    .withColumn("rn", f.row_number().over(w))
    .filter(f.col("rn") == 1)
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 5 - Renaming SKAT Table columns

# COMMAND ----------

df_skat = table_utils.add_prefix_to_columns(
    df_skat, "SKAT"
)  # <- Renaming starting with SKAT_

table_utils.check_schema_of_the_header_file(
    df_name_skat
)  # <- call function Check Header files
df_name_skat = delete_null_rows(df_name_skat)  # <- Call Function Delete rows null

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_skat, df_name_skat
)
df_skat = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_skat
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Join tables
# MAGIC

# COMMAND ----------

# join controlling_objects_groups (SETHEADER) to leaf (SETLEAF), then to skat
df_silver_ag = (
    df_controlling_objects_groups.alias("A")
    .join(
        dfleaf.alias("B"),
        (f.col("A.SETHEADER_mandt") == f.col("B.SETLEAF_mandt"))
        & (f.col("A.Group_Category") == f.col("B.Group_Category"))
        & (f.col("A.Group_SubCategory") == f.col("B.Group_SubCategory"))
        & (f.col("A.Group_Name") == f.col("B.Group_Name")),
        "inner",
    )
    .join(
        df_skat.alias("C"),
        (f.col("B.SETLEAF_mandt") == f.col("C.SKAT_mandt"))
        & (f.col("B.Account_Number") == f.col("C.Account_Number"))
        & (f.col("B.Group_SubCategory") == f.col("C.Chart_of_Account")),
        "left",
    )
    .select(
        f.col("A.*"),
        f.col("B.Rank_Number").alias("Rank_Number"),
        f.col("B.Account_Number").alias("Account_Number"),
        f.col("C.Account_Description").alias("Account_Description"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Silver Table

# COMMAND ----------

log.info(f"Saving {TABLE_ACCOUNT_GROUPS_NUMBERS_SILVER}.")
try:
    table_utils.save_table(
        dest_table=TABLE_ACCOUNT_GROUPS_NUMBERS_SILVER,
        df=df_silver_ag,
        mode="overwrite",
        overwrite_schema=True,
    )
except Exception as e:
    log.error(
        f"Table {TABLE_ACCOUNT_GROUPS_NUMBERS_SILVER} has not been created, an error occured during save."
    )
    log.error(f"Error : {e}")
    raise Exception()
else:
    log.info(f"Data saved into history count {df_silver_ag.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug step

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    rows = df_skat_before_filtering.count()
    log.debug(f"Dataframe df_skat_before_filtering rows count : {rows}")
    rows = df_skat.count()
    log.debug(f"Dataframe df_skat filtered rows count : {rows}")
    rows = dfleaf.count()
    log.debug(f"Dataframe dfleaf rows count : {rows}")
    rows = df_silver_ag.count()
    log.debug(f"Dataframe df_silver_ag rows count : {rows}")
    rows = df_silver_ag.filter("Group_Description is NULL").count()
    log.debug(
        f"Dataframe df_silver_ag with null Group_Description , rows count : {rows}"
    )
    rows = df_silver_ag.filter("Account_Description is NULL").count()
    log.debug(
        f"Dataframe df_silver_ag with null Account_Description , rows count : {rows}"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
