# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for data asset controlling objects groups with description
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - `{PIPELINE_WRITE_ENV}_silver.finance.controlling_objects_groups`
# MAGIC
# MAGIC **Input :**  
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.setheader_latest`  
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.setheadert_latest`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_setheader`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_setheadert`
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> Ingestion raw data SAP
# MAGIC
# MAGIC **Things done:** 
# MAGIC - Renaming Headers
# MAGIC - Cleansing data :
# MAGIC  filter on setheadert to keep English text if exists, otherwise None.
# MAGIC - Join setheader and setheadert
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
from pyspark.sql import DataFrame as DataFrame
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

# Get reference read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Get pipeline write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files 

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

BRONZE_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6"
BRONZE_HEADERS_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.headers_sap"

TABLE_SETHEADER_BRONZE = f"{BRONZE_SCHEMA}.setheader_latest"

TABLE_NAME_SETHEADER = f"{BRONZE_HEADERS_SCHEMA}.headers_sap_business_setheader"

TABLE_SETHEADERT_BRONZE = f"{BRONZE_SCHEMA}.setheadert_latest"

TABLE_NAME_SETHEADERT = f"{BRONZE_HEADERS_SCHEMA}.headers_sap_business_setheadert"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER = (
    f"{PIPELINE_WRITE_ENV}_silver.finance.controlling_objects_groups"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# MAGIC %md
# MAGIC #### Common global variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs 
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.info(
    f"TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER is:  {TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER}"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Tables Read

# COMMAND ----------

df_setheader = spark.read.table(
    f"{TABLE_SETHEADER_BRONZE}"
)  # <- Upload SAP table setheader

# COMMAND ----------

df_name_setheader = spark.read.table(
    f"{TABLE_NAME_SETHEADER}"
)  # <- Upload manual table for headers naming

# COMMAND ----------

df_setheadert = spark.read.table(
    f"{TABLE_SETHEADERT_BRONZE}"
)  # <- Upload SAP table setheadert

# COMMAND ----------

df_name_setheadert = spark.read.table(
    f"{TABLE_NAME_SETHEADERT}"
)  # <- Upload manual table for headers naming

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Filtering SETHEADERT on duplicate languages - keeping E only

# COMMAND ----------

# Filtering on SAP fields : partition on "mandt","setclass","subclass","setname" , sorted by "langu" (language) and keeping 1st occurence of language
w = Window.partitionBy("mandt", "setclass", "subclass", "setname").orderBy("langu")
df_setheadert_before_filtering = df_setheadert
df_setheadert = (
    df_setheadert.filter((df_setheadert.langu == "E"))
    .withColumn("rn", f.row_number().over(w))
    .filter(f.col("rn") == 1)
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Renaming SETHEADER Table columns

# COMMAND ----------

df_setheader = table_utils.add_prefix_to_columns(df_setheader, "SETHEADER")

table_utils.check_schema_of_the_header_file(
    df_name_setheader
)  # <- call function Check Header files
df_name_setheader = delete_null_rows(
    df_name_setheader
)  # <- Call Function Delete rows null

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_setheader, df_name_setheader
)
# Call Funtion Create Columns on Date format
df_header = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_setheader
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Renaming SETHEADERT Table columns

# COMMAND ----------

df_setheadert = table_utils.add_prefix_to_columns(df_setheadert, "SETHEADERT")

table_utils.check_schema_of_the_header_file(
    df_name_setheadert
)  # <- call function Check Header files
df_name_setheadert = delete_null_rows(
    df_name_setheadert
)  # <- Call Function Delete rows null

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_setheadert, df_name_setheadert
)
# Call Funtion Create Columns on Date format
df_text = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_setheadert
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Join tables
# MAGIC

# COMMAND ----------

# join SETHEADER and SETHEADERT on fields : "mandt","Group_Category"(setclass),"Group_SubCategory"(subclass),"Group_Name"(setname)
df_silver_controlling_objects_groups = (
    df_header.alias("A")
    .join(
        df_text.alias("C"),
        (f.col("A.SETHEADER_mandt") == f.col("C.SETHEADERT_mandt"))
        & (f.col("A.Group_Category") == f.col("C.Group_Category"))
        & (f.col("A.Group_SubCategory") == f.col("C.Group_SubCategory"))
        & (f.col("A.Group_Name") == f.col("C.Group_Name")),
        "left",
    )
    .select(
        f.col("A.*"),
        f.col("C.Group_Description").alias("Group_Description"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Silver Table

# COMMAND ----------

log.info(f"Saving {TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER}.")
try:
    table_utils.save_table(
        dest_table=TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER,
        df=df_silver_controlling_objects_groups,
        mode="overwrite",
        overwrite_schema=True,
    )
except Exception as e:
    log.error(
        f"Table {TABLE_CONTROLLING_OBJECTS_GROUPS_SILVER} has not been created, an error occured during save."
    )
    log.error(f"Error : {e}")
    raise Exception()
else:
    log.info(
        f"Data saved into history count {df_silver_controlling_objects_groups.count()} rows."
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug step

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    rows = df_setheadert_before_filtering.count()
    log.debug(f"Dataframe df_setheadert_before_filtering rows count : {rows}")
    rows = df_setheadert.count()
    log.debug(f"Dataframe df_setheadert filtered rows count : {rows}")
    rows = df_header.count()
    log.debug(f"Dataframe dfheader rows count : {rows}")
    rows = df_silver_controlling_objects_groups.count()
    log.debug(f"Dataframe df_silver_controlling_objects_groups rows count : {rows}")
    rows = df_silver_controlling_objects_groups.filter(
        "Group_Description is NULL"
    ).count()
    log.debug(
        f"Dataframe df_silver_controlling_objects_groups with null Group_Description , rows count : {rows}"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
