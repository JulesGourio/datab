# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC Stack of SAP companies revenue and Avcorp revenue gold tables
# MAGIC
# MAGIC **Highlighted complexities/warning:**  
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {PIPELINE_READ_ENV}_gold.finance.general_ledger_sap
# MAGIC - {PIPELINE_READ_ENV}_gold.finance.general_ledger_avcorp
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.finance.revenue_all
# MAGIC
# MAGIC **Used by:** 
# MAGIC - In supply chain domain: to calculate a turn of a stock
# MAGIC - In finance 

# COMMAND ----------

# MAGIC %md
# MAGIC # Tech Debt
# MAGIC Ideally, there are not multiple revenue tables (sap, avcorp, etc) but only one revenue table plugged on the stack general ledger. However, we're not enough mature to 
# MAGIC 1. include Avcorp in the stacked general ledger 
# MAGIC 2. have a full revenue table with all SAP and non SAP companies

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

df_rev_sap_raw = spark.read.table(f'{PIPELINE_READ_ENV}_gold.finance.revenue_sap')

df_rev_lac_raw = spark.read.table(f'{PIPELINE_READ_ENV}_gold.finance.revenue_avcorp')

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

cols_to_keep = set(map(str.lower, df_rev_sap_raw.columns)) & set(map(str.lower, df_rev_lac_raw.columns))
df_rev_lac_prep = df_rev_lac_raw.select(*[col for col in df_rev_lac_raw.columns if col.lower() in cols_to_keep])


# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Union between the two dataframes

# COMMAND ----------

df_revenue_transf = df_rev_sap_raw.unionByName(df_rev_lac_prep, allowMissingColumns=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Renamed AS branch

# COMMAND ----------

df_revenue_renamed = df_revenue_transf.withColumn(
    "PC_Branch",
        f.when(
            (f.col("Plant").startswith("2"))
            | (f.col("Profit_Center").isin(["BCL", "HAP", "297", "298", "299", "DEW"]))
            | (f.col("Profit_Center").startswith("V")),
            f.lit("IS"),
        )
        .when(
            (f.col("Plant") == "1010") | (f.col("Plant").startswith("4")),
            f.lit("AS-AMERICAS"),
        )
        .when(f.col("Plant")=="6000", f.lit("AS-AMERICAS"))
        .otherwise(f.lit("AS-EUROPE")),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

OUTPUT_PATH_NAME_REVENUE_ALL = f"{PIPELINE_WRITE_ENV}_gold.finance.revenue_all"
table_utils.save_table(
    dest_table=OUTPUT_PATH_NAME_REVENUE_ALL,
    df=df_revenue_renamed,
    mode="overwrite",
)
