# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC This script creates the gold revenue table from the general ledger gold table for SAP companies. The idea is to have a revenue table used accross domains with the same definition, and to do enrichments specific to revenue (like if it is production revenue or not) and select only relevant columns. 
# MAGIC
# MAGIC **Highlighted complexities/warning:**  
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Revenue - Data asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {PIPELINE_READ_ENV}_gold.finance.general_ledger_sap
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_gold.finance.currency_exchange
# MAGIC - {REFERENCE_READ_ENV}_bronze.manual_input.intercompany_config
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.finance.revenue_sap
# MAGIC
# MAGIC **Used by:** 
# MAGIC - In supply chain domain: to calculate a turn of a stock
# MAGIC - In finance 

# COMMAND ----------

# MAGIC %md
# MAGIC # Tech Debt
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC
# MAGIC - **currency_conversion** required for currency conversion of amounts
# MAGIC - **save_table** to save the output table
# MAGIC - **business_rules** for the DES identification function
# MAGIC

# COMMAND ----------

from leap_utils.data_asset.table_utils import (
    save_table,
    currency_conversion,
)
from leap_utils.data_asset import business_rules

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### General Ledger 
# MAGIC
# MAGIC **df_GL_raw** is the gold general ledger for LATECOERE Legacy perimeter (SAP ECC6) coming from the data asset general ledger. 
# MAGIC

# COMMAND ----------

df_GL_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.general_ledger_sap_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Intercompany table
# MAGIC **df_interco_para_raw** is a manual input table that gives the correspondance between company, trading partner and branch. 

# COMMAND ----------

df_intercompany_parameter_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.intercompany_config"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Master data plant
# MAGIC **df_master_plant** TODO: 

# COMMAND ----------

df_master_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest"
).select("Plant_Description", "Plant_Description_new")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

LIST_OTP_REVENUE_SITE = [
    "DV-ZBR/SALE-B2",
    "DV-ZGR/LBGR-A5",
    "DV-ZGR/LBGR-A6",
    "DV-ZGR/LDBR-A5",
    "DV-ZGR/LETO-A5",
]

# COMMAND ----------

LIST_PC_HQ = ["A02", "S05", "S06", "S07", "S08", "F01", "F02", "N02"]

# COMMAND ----------

# Some columns from the General Ledger are not revelant anymore for a revenue table, such as all columns relative to cost centers
COL_TO_DROP = (
    [col for col in df_GL_raw.columns if col.startswith("CC_")]
    + [
        "WBS_Code_Join",
        "WBS_Hierarchy_Level",
        "WBS_Bill_Code",
        "WBS_WIP_Code",
        "WBS_Plant",
        "WBS_Bill_Month",
        "WBS_Object_Type",
        "WBS_Description_Upperc",
        "WBS_Lock_Indicator",
    ]
    + [f"WBS_Group_{i}" for i in range(1, 4)]
    + [col for col in df_GL_raw.columns if col.startswith("PO_")]
    + [col for col in df_GL_raw.columns if col.startswith("sender_")]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC - Preparation of the intercompany parameter

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Intercompany table 

# COMMAND ----------

df_intercompany_parameter_prep = df_intercompany_parameter_raw.withColumnsRenamed(
    {
        "company_code": "trading_partner_company",
        "trading_partner_sap_id": "trading_partner_id",
        "IT_platform_SAP": "trading_IT_platform",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - General ledger table
# MAGIC Drop useless columns for a revenue table

# COMMAND ----------

df_GL_prep = df_GL_raw.drop(*COL_TO_DROP)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 - Filter on revenue accounts
# MAGIC Revenue accounts numbers starts with 70, 907 or C70. These accounts are gathered in the account groups that start with RNREBE00. 

# COMMAND ----------

df_GL_transf = df_GL_prep.filter(f.col("account_group").startswith("RNREBE00"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2 - Convert amounts 

# COMMAND ----------

# MAGIC %md
# MAGIC #### 1- Accounts 907
# MAGIC Accounts that start with 907 are accounts used to have amounts in budget rate. By not taking them, amounts are at spot rate. 

# COMMAND ----------

df_GL_transf = df_GL_transf.filter(~f.col("account_number").startswith("907"))

# COMMAND ----------

# MAGIC %md
# MAGIC #### 2- Conversion
# MAGIC In the GL, we have:
# MAGIC - Amount in doc currency
# MAGIC - Amount in company currency at spot rate 
# MAGIC - Amount in company currency converted in EUR at consolidation rate and at budget rate
# MAGIC
# MAGIC Calculated amounts: 
# MAGIC - Amount in transaction currency converted in EUR at budget rate

# COMMAND ----------

df_GL_transf = df_GL_transf.withColumn(
    "_temp_budget_date",
    f.when(
        f.col("posting_document_date") > f.current_date(),
        f.date_sub(f.current_date(), 1),
    ).otherwise(f.col("posting_document_date")),
)
df_GL_transf = (
    currency_conversion(
        df=df_GL_transf,
        document_currency_column=df_GL_transf.currency_key,
        rate_types=["Budget"],
        rate_dates=[df_GL_transf._temp_budget_date],
        target_currency_value="EUR",
        document_amounts=[df_GL_transf.amount_in_transaction_currency],
    )
    .withColumnsRenamed(
        {
            "amount_in_transaction_currency_to_EUR_in_Budget_rate_at__temp_budget_date": "budget_exchange_rate_from_currency_key_to_eur",
            "amount_in_transaction_currency_from_currency_key_to_EUR_in_Budget_rate_at__temp_budget_date": "amount_in_transaction_currency_to_EUR_in_budget_rate",
        }
    )
    .drop("_temp_budget_date")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 3 - Add activity column
# MAGIC 4 types of activities identified: recurring (RC), non-recurring (NRC), customer services (CS) and R&T. This field is defined based on the profit center (Accounting_PC_group). 

# COMMAND ----------

df_GL_transf = df_GL_transf.withColumn(
    "activity",
    f.when((f.col("Accounting_PC_Group").isin(["1_NRC", "1_SERVICES"])), f.lit("NRC"))
    .when((f.col("Accounting_PC_Group") == "1_CS"), f.lit("CS"))
    .when((f.col("Accounting_PC_Group") == "1_RC"), f.lit("RC"))
    .when(f.col("Accounting_PC_Group") == "2_R_T", f.lit("R&T")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 4 - Add branches information and distinguish DES

# COMMAND ----------

# MAGIC %md
# MAGIC ####1- Trading partner branch
# MAGIC Determination of the branch of the trading partner based on **df_intercompany_parameter_prep**. 

# COMMAND ----------

df_GL_transf = df_GL_transf.join(
    df_intercompany_parameter_prep, ["trading_partner_id"], how="left"
)

# COMMAND ----------

df_GL_transf = df_GL_transf.withColumn(
    "trading_partner_branch",
    f.when(f.col("trading_partner_branch").isNull(), f.lit("Out")).otherwise(
        f.col("trading_partner_branch")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ####2- DES identification
# MAGIC DES is specific non recurring activities, that acts as a company in the P&L management, supported legally by LATE (and sometimes LLVS) but associated to IS in a management point of view. It is identified by profit centers.
# MAGIC

# COMMAND ----------

df_GL_transf = business_rules.identify_DES_activities(
    df=df_GL_transf,
    company_col=f.col("company_code"),
    profit_center_col=f.col("profit_center"),
    output_col_name="mngt_company_code",
    reference_read_env="prod",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ####3- HQ identification 
# MAGIC HQ = Headquarter is identified by a list of profit center. 

# COMMAND ----------

df_GL_transf = df_GL_transf.withColumn(
    "cny_branch_mngt",
    f.when(f.col("profit_center").isin(LIST_PC_HQ), f.lit("HQ"))
    .when(f.col("mngt_company_code") == f.lit("LFR-DES"), f.lit("IS"))
    .otherwise(f.col("Company_Entity")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 5 - Add intercompany parameter
# MAGIC A transaction can be defined as interbranch, intrabranch or out.
# MAGIC - Out: between the company and an other entity not relative to Latecoere 
# MAGIC - Intra: Inside a branch 
# MAGIC - Inter: Between two branches
# MAGIC
# MAGIC
# MAGIC In supply chain, a flow is defined as "Interco" only when it is between two companies of the same branch, and the HQ branch doesn't exist. 

# COMMAND ----------

df_GL_transf = df_GL_transf.withColumn(
    "interbranch",
    f.when(f.col("trading_partner_branch") == f.lit("Out"), f.lit("External"))
    .when(
        f.col("Company_Entity") == f.col("trading_partner_branch"),
        f.lit("Intra-branch"),
    )
    .when(
        f.col("Company_Entity") != f.col("trading_partner_branch"),
        f.lit("Inter-branch"),
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 6 - Reverse amount columns
# MAGIC In SAP, revenue is negative and costs are positives. All columns starts with "Amount" are reversed. 

# COMMAND ----------

LIST_AMOUNT_COLUMNS = [col for col in df_GL_transf.columns if col.startswith("amount")]

# COMMAND ----------

for col in LIST_AMOUNT_COLUMNS:
    df_GL_transf = df_GL_transf.withColumn(
        f"{col}",
        -f.col(f"{col}"),
    )

# COMMAND ----------

# DBTITLE 1,Transformation 6b
# MAGIC %md
# MAGIC ### Transformation 6b - Restore quantities for value-only re-entries
# MAGIC In SAP, a billing cancellation creates two FI documents:
# MAGIC - The **cancellation** reverses both Qty and Amount
# MAGIC - The **re-entry** (récriture) restores the Amount only → Qty stays 0 in the GL
# MAGIC
# MAGIC We recover the original Qty by matching `(reference_doc_number, amount)` with the original delivery line (`qty < 0`). Only applied to production revenue WBS/activity rows.
# MAGIC
# MAGIC Coverage validated: **99% unique match** | 0.7% no-match kept at Qty=0 | 0.03% ambiguous (earliest accounting document taken).

# COMMAND ----------

from pyspark.sql.window import Window

_w_qty = (
    Window
    .partitionBy(
        "reference_doc_number",
        "amount_in_transaction_currency_to_EUR_in_budget_rate",
    )
    .orderBy("accounting_document_number")
)

# Lookup: one row per (reference_doc, amount) → original negative quantity (earliest doc)
_qty_lookup = (
    df_GL_transf
    .filter(f.col("quantity") < 0)
    .withColumn("_rn", f.row_number().over(_w_qty))
    .filter(f.col("_rn") == 1)
    .select(
        "reference_doc_number",
        "amount_in_transaction_currency_to_EUR_in_budget_rate",
        f.col("quantity").alias("_qty_inherited"),
    )
)

# Flag value-only re-entry rows: Qty=0, non-zero amount, production WBS/activity, valid material
_is_reentry = (
    (f.col("quantity") == 0)
    & f.col("material_number").isNotNull()
    & (f.col("amount_in_transaction_currency_to_EUR_in_budget_rate") != 0)
    & (
        f.col("WBS_Code").isin(LIST_OTP_REVENUE_SITE)
        | f.col("activity").isin(["CS", "RC"])
    )
)

# Left-join lookup and inherit quantity only for re-entry rows; all other rows unchanged
df_GL_transf = (
    df_GL_transf
    .join(
        _qty_lookup,
        on=[
            "reference_doc_number",
            "amount_in_transaction_currency_to_EUR_in_budget_rate",
        ],
        how="left",
    )
    .withColumn(
        "quantity",
        f.when(
            _is_reentry & f.col("_qty_inherited").isNotNull(),
            f.col("_qty_inherited"),
        ).otherwise(f.col("quantity")),
    )
    .drop("_qty_inherited")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 7 - Categorisation
# MAGIC The aim here is to flag all lines that are relative to production activities of sites.

# COMMAND ----------

# After Tr6b, re-entry rows have inherited their original quantity (non-zero).
# The standard condition quantity != 0 now correctly captures them.
MATERIAL_AND_NOT_ZERO_QTY = (f.col("quantity") != 0) & (
    f.col("material_number").isNotNull()
)

# COMMAND ----------

df_GL_transf = df_GL_transf.withColumn(
    "Production_revenue_YN",
    f.when(
        ((f.col("activity").isin(["CS", "RC"])) & MATERIAL_AND_NOT_ZERO_QTY),
        f.lit("Yes"),
    )
    .when(
        ((f.col("WBS_Code").isin(LIST_OTP_REVENUE_SITE)) & MATERIAL_AND_NOT_ZERO_QTY),
        f.lit("Yes"),
    )
    .otherwise("No"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 8 - Add plant description Info
# MAGIC Add the new plant formalism to the dataAsset.

# COMMAND ----------

df_GL_transf = df_GL_transf.join(
    df_master_plant,
    on=["Plant_Description"],
    how="left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold revenue

# COMMAND ----------

OUTPUT_PATH_NAME_REVENUE = f"{PIPELINE_WRITE_ENV}_gold.finance.revenue_sap"
save_table(dest_table=OUTPUT_PATH_NAME_REVENUE, df=df_GL_transf, mode="overwrite")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
