# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC This script creates the gold revenue table from avcorp data. The idea is to have a revenue table used accross domains with the same definition, and to do enrichments specific to revenue (like if it is production revenue or not) and select only relevant columns.
# MAGIC
# MAGIC **Highlighted complexities/warning:**  
# MAGIC Revenue - DataAsset
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {PIPELINE_READ_ENV}_gold.finance.general_ledger_avcorp
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_gold.finance.currency_exchange
# MAGIC - {REFERENCE_READ_ENV}_bronze.manual_input.intercompany_config
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.finance.revenue_avcorp
# MAGIC
# MAGIC **Used by:** 
# MAGIC - In supply chain domain: to calculate a turn of a stock
# MAGIC - In finance 

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

df_gl_avcorp_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.general_ledger_avcorp"
)

# COMMAND ----------

df_intercompany_parameter_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.intercompany_config"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

DICT_RENAMING_AVCORP = {
    "GL_SAP_account": "account_number",
    "accouting_PC_group": "Accounting_PC_Group",
    "profit_center_description": "PC_description",
}

# COMMAND ----------

COLUMNS_TO_SELECT_AVCORP = [
    "cost_center",
    "amount_in_company_currency",
    "company_currency",
    "fiscal_year",
    "posting_period",
    "conso_exchange_rate_from_company_currency_to_eur",
    "amount_in_company_currency_to_EUR_in_conso_rate",
    "conso_account",
    "conso_account_description",
    "GL_SAP_account",
    "profit_center",
    "account_group",
    "account_group_description",
    "description_cost_center",
    "Site",
    "profit_center_description",
    "accouting_PC_group",
]

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Avcorp GL table

# COMMAND ----------

df_gl_avcorp_prep = (
    df_gl_avcorp_raw.select(COLUMNS_TO_SELECT_AVCORP)
    .withColumn("company_code", f.lit("LAC1"))
    .withColumn("trading_partner_id", f.lit("X000"))
    .withColumn("plant", f.lit("6000"))
    .withColumn("cost_center_adjusted", f.col("cost_center"))
    .withColumn("mngt_company_code", f.lit("LAC1"))
    .withColumn("cny_branch", f.lit("AS"))
    .withColumn("Company_Entity", f.lit("AS"))
    .withColumn("cny_branch_mngt", f.lit("AS"))
    .withColumn("Production_revenue_YN", f.lit("Yes"))
)

# COMMAND ----------

df_gl_avcorp_prep = df_gl_avcorp_prep.withColumnsRenamed(DICT_RENAMING_AVCORP)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - Intercompany table
# MAGIC Rk: useless today as all flows are external, but the goal is to anticipate futures internal flows 

# COMMAND ----------

df_intercompany_parameter_prep = df_intercompany_parameter_raw.withColumnsRenamed(
    {
        "company_code": "trading_partner_company",
        "trading_partner_sap_id": "trading_partner_id",
        "IT_platform_SAP": "trading_IT_platform",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 - Filter on revenue accounts
# MAGIC Revenue accounts numbers starts with 70, 907 or C70. These accounts are gathered in the account groups that start with RNREBE00. 

# COMMAND ----------

df_rev_avcorp_transf = df_gl_avcorp_prep.filter(
    f.col("conso_account").startswith("R70")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Transformation 2 - Add activity information

# COMMAND ----------

df_rev_avcorp_transf = df_rev_avcorp_transf.withColumn(
    "activity",
    f.when((f.col("Accounting_PC_Group").isin(["1_NRC", "1_SERVICES"])), f.lit("NRC"))
    .when((f.col("Accounting_PC_Group") == "1_CS"), f.lit("CS"))
    .when((f.col("Accounting_PC_Group") == "1_RC"), f.lit("RC"))
    .when(f.col("Accounting_PC_Group") == "2_R_T", f.lit("R&T")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Transformation 3 - Add interbranch information

# COMMAND ----------

df_rev_avcorp_transf = df_rev_avcorp_transf.join(
    df_intercompany_parameter_prep, ["trading_partner_id"], how="left"
)

# COMMAND ----------

df_rev_avcorp_transf = df_rev_avcorp_transf.withColumn(
    "trading_partner_branch",
    f.when(f.col("trading_partner_branch").isNull(), f.lit("Out")).otherwise(
        f.col("trading_partner_branch")
    ),
)

# COMMAND ----------

df_rev_avcorp_transf = df_rev_avcorp_transf.withColumn(
    "interbranch",
    f.when(f.col("trading_partner_branch") == f.lit("Out"), f.lit("External"))
    .when(
        f.col("Company_Entity") == f.col("trading_partner_branch"),
        f.lit("Intra-branch"),
    )
    .when(
        f.col("Company_Entity") != f.col("trading_partner_branch"),
        f.lit("Inter-branch"),
    ),
)

# COMMAND ----------

df_rev_avcorp_transf = df_rev_avcorp_transf.withColumn(
    "Posting_document_date",
    f.to_date(
        f.concat(
            f.col("fiscal_year"), f.lit("-"),
            f.lpad(f.col("posting_period"), 2, "0"), f.lit("-01")
        ), 
        "yyyy-MM-dd"
    )
).withColumn(
    "customer_group", f.lit("LAC1-CustomerGroup")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - convert currency

# COMMAND ----------

df_rev_avcorp_currency = table_utils.currency_conversion(
    df=df_rev_avcorp_transf,
    document_currency_column=f.col("company_currency"),
    rate_types=["Budget"],
    rate_dates=["Posting_document_date"],
    target_currency_value="EUR",
    document_amounts=[f.col("amount_in_company_currency")],
).withColumnsRenamed(
    {
        "amount_in_company_currency_from_company_currency_to_EUR_in_Budget_rate_at_Posting_document_date":"amount_in_transaction_currency_to_EUR_in_budget_rate",
        "company_currency_to_EUR_in_Budget_rate_at_Posting_document_date": "conversion_rate"
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

OUTPUT_PATH_NAME_REVENUE_AVCORP = f"{PIPELINE_WRITE_ENV}_gold.finance.revenue_avcorp"
table_utils.save_table(
    dest_table=OUTPUT_PATH_NAME_REVENUE_AVCORP,
    df=df_rev_avcorp_currency,
    mode="overwrite",
)

# COMMAND ----------


