# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC This script creates the gold revenue table from the general ledger gold table. 
# MAGIC
# MAGIC **Highlighted complexities/warning:**  
# MAGIC Warning: This notebook is highly dependent on currency table. The job with this notebook must run after the currency job. 
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Revenue - Data asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {PIPELINE_READ_ENV}_gold.finance.general_ledger
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_gold.finance.currency_exchange
# MAGIC - {REFERENCE_READ_ENV}_bronze.manual_input.pnl_intercompany_parameter
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.finance.revenue
# MAGIC
# MAGIC **Used by:** 
# MAGIC - In supply chain domain: to calculate a turn of a stock
# MAGIC - In finance 

# COMMAND ----------

# MAGIC %md
# MAGIC # Tech Debt
# MAGIC
# MAGIC     1. SAP enter date: modifying the format -> should be done in create_silver_general_ledger

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC
# MAGIC - **convert_currency** required for currency conversion of amounts
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### General Ledger 
# MAGIC
# MAGIC **df_GL_raw** is the gold general ledger for LATECOERE Legacy perimeter (SAP ECC6) coming from the data asset general ledger. 
# MAGIC

# COMMAND ----------

df_GL_raw = spark.read.table(f"{PIPELINE_READ_ENV}_gold.finance.general_ledger")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Currency exchange rates table
# MAGIC **df_currency_raw** is the gold table with exchange rates and used here to convert amounts in euros. 

# COMMAND ----------

df_currency_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.currency_exchange"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Intercompany table
# MAGIC **df_interco_para_raw** is a manual input table that gives the correspondance between company, trading partner and branch. 

# COMMAND ----------

df_interco_para_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.pnl_intercompany_parameter"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

list_of_columns_to_select_gl = [
    "Record_nber_of_the_line_item_record",
    "Ledger",
    "Record_Type",
    "Fiscal_year",
    "Currency_key",
    "Base_Unit_Of_Measure",
    "Debit_Credit_indicator",
    "Posting_period",
    "Document_Type",
    "Accounting_document_number",
    "Document_Line",
    "Company_code",
    "Profit_Center",
    "Account_number",
    "Company_ID_of_trading_partner",
    "Partner_profit_center_for__elimination_of_internal_business",
    "sap_enter_date",
    "Document_date",
    "Posting_document_date",
    "Reference_doc_number",
    "Plant",
    "Cost_center",
    "Order_number",
    "Material_number",
    "Purchasing_document_number",
    "Item_Number_of_Purchasing_Document",
    "WBS_element",
    "Sales_order_number",
    "Item_number_in_sales_order",
    "Sales_organization",
    "Sales_document",
    "Movement_type",
    "extraction_timestamp_glpca",
    "Amount_in_profit_center_local_currency_",
    "Quantity_",
    "Profit_center_short",
    "Group_Name",
    "Group_Type",
    "Group_Description",
    "Business_Unit",
    "PC_Responsible",
    "Aircraft_platform",
    "PC_Attributed_site",
    "Accounting_PC_Group",
    "Product_Group",
    "Customer_Group",
    "PC_Branch",
    "Aircraft_product",
    "PC_Hierachy_Std",
    "Short_Description",
    "Plant_Description_new",
    "Company_Description",
    "Company_Currency",
    "Cost_center_adjusted",
    "Cost_Center_short",
    "CCSite",
    "CCBranch",
    "Cost_center_Description",
    "WBS_Code",
    "WBS_Description",
    "WBS_Plant",
    "Amount_in_transaction_currency_",
    "Amount_in_company_code_currency_",
]

# COMMAND ----------

list_of_otp_to_take_for_revenue_site = ["DV-ZBR/SALE-B2", "DV-ZGR/LBGR-A5", "DV-ZGR/LBGR-A6", "DV-ZGR/LDBR-A5", "DV-ZGR/LETO-A5"] 

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC - Selection of columns to keep useful for the revenue in df_gl_raw
# MAGIC - Modifying the format of the column sap_enter_date \
# MAGIC [TECH DEBT ITEM]: this should be done in the create_silver_general_ledger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

def remove_lead_zero(col, n):
    """
    col: name of the column you want to modify
    n: number of leading 0 you want to remove
    """
    return f.when(
        f.regexp_extract(col, "^0{{{n}}}[^0]".format(n=n), 0) != "",
        f.expr("substring({col}, {n}, length({col}))".format(col=col, n=n + 1)),
    ).otherwise(f.col(col))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - General ledger Downselect
# MAGIC
# MAGIC Perform selection on the general ledger table useful for a revenue gold table.

# COMMAND ----------

df_GL_raw_selected = df_GL_raw.select(list_of_columns_to_select_gl)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Date cleaning
# MAGIC SAP enter date in date format \
# MAGIC [Technical debt]: should be done in general ledger data asset

# COMMAND ----------

df_GL_with_sap_date_clean = df_GL_raw_selected.withColumn(
    "sap_enter_date", f.to_date(f.col("sap_enter_date"), "yyyyMMdd")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Format cleaning
# MAGIC Company_ID_of_trading_partner

# COMMAND ----------

df_GL_prep = (
    df_GL_with_sap_date_clean.withColumn(
        "Company_ID_of_trading_partner",
        f.trim(f.col("Company_ID_of_trading_partner")),
    )
    .withColumn(
        "Company_ID_of_trading_partner",
        remove_lead_zero("Company_ID_of_trading_partner", 2),
    )
    .withColumn(
        "Company_ID_of_trading_partner",
        remove_lead_zero("Company_ID_of_trading_partner", 3),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 - Filter on revenue accounts
# MAGIC Revenue accounts numbers starts with 70, 907 or C70. These accounts are gathered in the account groups that start with RNREBE00. 

# COMMAND ----------

df_filtered = df_GL_prep.filter(f.col("Group_Name").startswith("RNREBE00"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2 - Convert amounts 

# COMMAND ----------

# MAGIC %md
# MAGIC #### 1- Accounts 907
# MAGIC Accounts that start with 907 are accounts used to have amounts in budget rate. By not taking them, amounts are at spot rate. It has been decided to not taken them and convert everything at spot & budget rate in order to be more consistent. 

# COMMAND ----------

df_filtered = df_filtered.filter(~f.col("Account_number").startswith("907"))

# COMMAND ----------

# MAGIC %md
# MAGIC ####2- Renaming
# MAGIC The column Amount_in_company_code_currency is the amount in transaction currency converted automatically by SAP to the company currency. By not taking 907* accounts, we consider a conversion at spot rate. As said before, 907* accounts are used to compensate the rates difference between budget and spot. 

# COMMAND ----------

df_filtered = df_filtered.withColumnRenamed(
    "Amount_in_company_code_currency_", "Amount_in_company_code_currency_at_spot_rate"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### 3- Conversion
# MAGIC In the GL, we have:
# MAGIC - Amount in doc currency
# MAGIC - Amount in company currency at spot rate 
# MAGIC
# MAGIC Calculated amounts: 
# MAGIC - Amount in company currency at budget rate = Amount in doc currency converted to the company currency at budget rate
# MAGIC - Amount in EUR at spot rate = Amount in company currency at spot rate converted with conso moving avg rates 
# MAGIC - Amount in EUR at budget rate = Amount in company currency at budget rate converted with conso moving avg rates 
# MAGIC - Amount in transaction currency converted to EUR at budget rate conso

# COMMAND ----------

# Amount in company currency at budget rate
df_currency_budget = df_currency_raw.filter(
    f.col("Conversion_rate_Type_exp") == "Budget"
)

df_prep_converted = df_filtered.join(
    df_currency_budget,
    (df_filtered.Company_Currency == df_currency_budget.Currency_Target)
    & (df_filtered.Currency_key == df_currency_budget.Currency_Source)
    & (
        df_filtered.Posting_document_date == df_currency_budget.Validity_Date_DateFormat
    ),
    how="left",
).withColumn(
    "Exchange_Rate",
    f.when(f.col("Exchange_rate").isNull(), f.lit(1)).otherwise(f.col("Exchange_rate")),
)
df_converted = df_prep_converted.withColumn(
    "Amount_in_cny_curr_in_budget_rate",
    f.col("Amount_in_company_code_currency_at_spot_rate") * f.col("Exchange_Rate"),
).drop(
    "Exchange_Rate",
    "Conversion_rate_Type_exp",
    "currencyPairID",
    "Currency_Source",
    "Currency_Target",
    "Validity_Date_DateFormat",
    "Conversion_rate_Type",
)

# Amount in EUR at spot rate conso
latest_currency_date = (
    df_currency_raw.filter(f.col("Conversion_rate_Type_exp") == "Consolidation")
    .agg(f.max("Validity_Date_DateFormat").alias("Latest_currency_date"))
    .collect()[0][0]
)

df_converted = df_converted.withColumn(
    "latest_currency_date", f.lit(f"{latest_currency_date}")
)

df_converted = table_utils.convert_currency(
    df_base=df_converted,
    df_currency=df_currency_raw,
    df_base_source_currency_column_name="Company_Currency",
    target_currency_value="EUR",
    df_currency_conversion_rate_type_exp_value="Consolidation",
    df_base_conversion_date_column_name="latest_currency_date",
    conversion_output_column_name="Exchange_Rate_conso",
)
df_converted = (
    df_converted.withColumn(
        "Amount_at_spot_rate_converted_in_EUR_conso",
        f.col("Amount_in_company_code_currency_at_spot_rate")
        * f.col("Exchange_Rate_conso"),
    )
    .drop("Exchange_Rate")
    .withColumn(
        "Amount_at_spot_rate_converted_in_EUR_conso",
        f.when(
            f.col("Company_Currency") == "EUR",
            f.col("Amount_in_company_code_currency_at_spot_rate"),
        ).otherwise(f.col("Amount_at_spot_rate_converted_in_EUR_conso")),
    )
)

# Amount in EUR at budget rate conso
df_converted = (
    df_converted.withColumn(
        "Amount_at_budget_rate_converted_in_EUR_conso",
        f.col("Amount_in_cny_curr_in_budget_rate") * f.col("Exchange_Rate_conso"),
    )
    .drop(
        "Exchange_Rate_conso",
        "Conversion_rate_Type_exp",
        "currencyPairID",
        "Currency_Source",
        "Currency_Target",
        "Validity_Date_DateFormat",
        "latest_currency_date",
        "Conversion_rate_Type",
    )
    .withColumn(
        "Amount_at_budget_rate_converted_in_EUR_conso",
        f.when(
            f.col("Company_Currency") == "EUR",
            f.col("Amount_in_cny_curr_in_budget_rate"),
        ).otherwise(f.col("Amount_at_budget_rate_converted_in_EUR_conso")),
    )
)

# Amount in transaction currency converted to EUR at budget rate conso
df_converted = table_utils.convert_currency(
    df_base=df_converted,
    df_currency=df_currency_raw,
    df_base_source_currency_column_name="Currency_key",
    target_currency_value="EUR",
    df_currency_conversion_rate_type_exp_value="Budget",
    df_base_conversion_date_column_name="Posting_document_date",
    conversion_output_column_name="Exchange_Rate_budget_curr_to_eur",
)
df_converted = (
    df_converted.withColumn(
        "Amount_transaction_curr_to_eur_budget_rate",
        f.col("Amount_in_transaction_currency_")
        * f.col("Exchange_Rate_budget_curr_to_eur"),
    )
    .drop("Exchange_Rate_budget_curr_to_eur")
    .withColumn(
        "Amount_transaction_curr_to_eur_budget_rate",
        f.when(
            f.col("Currency_key") == "EUR",
            f.col("Amount_in_transaction_currency_"),
        ).otherwise(f.col("Amount_transaction_curr_to_eur_budget_rate")),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 3 - Add activity column
# MAGIC 4 types of activities identified: recurring (RC), non-recurring (NRC), customer services (CS) and R&T. This field is defined based on the profit center (Accounting_PC_group). 

# COMMAND ----------

df_GL_Enriched = df_converted.withColumn(
    "Activity",
    f.when((f.col("Accounting_PC_Group").isin(["1_NRC", "1_SERVICES"])), f.lit("NRC"))
    .when((f.col("Accounting_PC_Group") == "1_CS"), f.lit("CS"))
    .when((f.col("Accounting_PC_Group") == "1_RC"), f.lit("RC"))
    .when(f.col("Accounting_PC_Group") == "2_R_T", f.lit("R&T")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 4 - Add branches information and distinguish DES

# COMMAND ----------

# MAGIC %md
# MAGIC ####1- Company branch
# MAGIC Determination of the branch of the company based on **df_interco_para_raw**. 

# COMMAND ----------

df_GL_Enriched = (
    df_GL_Enriched.join(
        df_interco_para_raw.filter(f.col("SapCny") != "NonSAP")
        .select("SapCny", "Branch", "If_ActivityAS")
        .dropDuplicates(),
        df_GL_Enriched.Company_code == df_interco_para_raw.SapCny,
        how="left",
    )
    .withColumnRenamed("Branch", "CnyBranch")
    .drop("SapCny")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ####2- Trading partner branch
# MAGIC Determination of the branch of the trading partner based on **df_interco_para_raw**. 

# COMMAND ----------

df_GL_Enriched = (
    df_GL_Enriched.join(
        df_interco_para_raw.select("TradingPart", "Branch", "SapCny").withColumnRenamed(
            "SapCny", "Trading_partner_desc"
        ),
        df_GL_Enriched.Company_ID_of_trading_partner == df_interco_para_raw.TradingPart,
        how="left",
    )
    .drop("TradingPart")
    .withColumnRenamed("Branch", "Branch_S-L")
    .withColumn(
        "Branch_S-L",
        f.when(f.col("Branch_S-L").isNull(), f.lit("Out")).otherwise(
            f.col("Branch_S-L")
        ),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ####3- DES identification
# MAGIC DES is specific non recurring activities, that acts as a company in the P&L management, supported legally by LATE (and sometimes LLVS) but associated to IS in a management point of view. It is identified by profit centers.
# MAGIC

# COMMAND ----------

df_GL_Enriched = df_GL_Enriched.withColumn(
    "Company_adjusted",
    f.when(
        (f.col("PC_Branch") == "IS") & (f.col("CnyBranch") == "AS"), f.lit("LIS-DES")
    )
    .when(f.col("Profit_Center") == "DD1", f.lit("LIS-DES"))
    .when(f.col("Profit_Center") == "DD3", f.lit("LIS-DES"))
    .otherwise(f.col("Company_code")),
).withColumn(
    "CnyBranch",
    f.when(f.col("Company_adjusted") == "LIS-DES", f.lit("IS")).otherwise(
        f.col("CnyBranch")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ####4- HQ identification 
# MAGIC HQ = Headquarter is identified by a list of profit center. 

# COMMAND ----------

df_GL_Enriched = df_GL_Enriched.withColumn(
    "CnyBranch_mngt",
    f.when(
        f.col("Profit_Center").isin(
            ["A02", "S05", "S06", "S07", "S08", "F01", "F02", "N02"]
        ),
        f.lit("HQ"),
    ).otherwise(f.col("CnyBranch")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 5 - Add intercompany parameter
# MAGIC A transaction can be defined as interbranch, intrabranch or out.
# MAGIC - Out: between the company and an other entity not relative to Latecoere 
# MAGIC - Intra: Inside a branch 
# MAGIC - Inter: Between two branches

# COMMAND ----------

# MAGIC %md
# MAGIC #### 1- Financial view
# MAGIC With HQ that acts as a branch

# COMMAND ----------

df_GL_Enriched = df_GL_Enriched.withColumn(
    "Interco_mngt",
    f.when(
        (f.col("CnyBranch_mngt") == f.col("Branch_S-L")),
        f.lit("Intra"),
    )
    .when(
        (f.col("CnyBranch_mngt") == "AS") & (f.col("Branch_S-L") == "IS"),
        f.lit("Inter"),
    )
    .when(
        (f.col("CnyBranch_mngt") == "HQ") & (f.col("Branch_S-L") == "AS"),
        f.lit("Inter"),
    )
    .when(
        (f.col("CnyBranch_mngt") == "HQ") & (f.col("Branch_S-L") == "IS"),
        f.lit("Inter"),
    )
    .when(
        (f.col("CnyBranch_mngt") == "IS") & (f.col("Branch_S-L") == "AS"),
        f.lit("Inter"),
    )
    .otherwise(f.lit("Out")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### 2- Supply chain view
# MAGIC In supply chain, a flow is defined as "Interco" only when it is between two companies of the same branch, and the HQ branch doesn't exist. 

# COMMAND ----------

df_GL_Enriched = df_GL_Enriched.withColumn(
    "Interbranch",
    f.when(
        (f.col("CnyBranch") == f.col("Branch_S-L")),
        f.lit("INTRA-BRANCH"),
    ).otherwise(f.lit("EXTERNE")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 6 - Reverse amount columns
# MAGIC In SAP, revenue is negative and costs are positives. All columns starts with "Amount" are reversed. 

# COMMAND ----------

list_amount_columns = [
    col for col in df_GL_Enriched.columns if col.startswith("Amount")
]

# COMMAND ----------

for col in list_amount_columns:
    df_GL_Enriched = df_GL_Enriched.withColumn(
        f"{col}",
        -f.col(f"{col}"),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 7 - Categorisation
# MAGIC The aim here is to flag all lines that are relative to production activities of sites.

# COMMAND ----------

df_GL_Enriched = df_GL_Enriched.withColumn(
    "Production_revenue_YN",
    f.when(
        ((f.col("Activity") == "CS") | (f.col("Activity") == "RC"))
        & (f.col("Quantity_") != 0) & (f.col("Material_number").isNotNull()),
        f.lit("Yes"),
    ).otherwise("No"),
).withColumn(
    "Production_revenue_YN",
    f.when(
        ((f.col("WBS_Code").isin(list_of_otp_to_take_for_revenue_site))
        & (f.col('Production_revenue_YN') == "No")
        & (f.col("Quantity_") != 0) & (f.col("Material_number").isNotNull())),
        f.lit("Yes"),
    ).otherwise(f.col('Production_revenue_YN')),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ##QC1 - Amount columns in EUR not null

# COMMAND ----------

if (
    df_GL_Enriched.filter(f.col("Amount_in_cny_curr_in_budget_rate").isNull()).count()
    > 0
):
    raise Exception(
        "Warning: there are nulls in Amount_in_cny_curr_in_budget_rate column"
    )

if (
    df_GL_Enriched.filter(
        f.col("Amount_at_spot_rate_converted_in_EUR_conso").isNull()
    ).count()
    > 0
):
    raise Exception(
        "Warning: there are nulls in the Amount_at_spot_rate_converted_in_EUR_conso column"
    )

if (
    df_GL_Enriched.filter(
        f.col("Amount_at_budget_rate_converted_in_EUR_conso").isNull()
    ).count()
    > 0
):
    raise Exception(
        "Warning: there are nulls in Amount_at_budget_rate_converted_in_EUR_conso column"
    )

if (
    df_GL_Enriched.filter(
        f.col("Amount_transaction_curr_to_eur_budget_rate").isNull()
    ).count()
    > 0
):
    raise Exception(
        "Warning: there are nulls in Amount_transaction_curr_to_eur_budget_rate column"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ##QC2 - No rows duplicated

# COMMAND ----------

if df_filtered.count() != df_GL_Enriched.count():
    raise Exception("Warning: Some values have been duplicated in a join")

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold revenue

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "finance"
table = "revenue"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_GL_Enriched,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
