# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create the silver table for the consolidation chart of accounts. 
# MAGIC
# MAGIC **Output:** 
# MAGIC - {env}_silver.finance.consolidation_chart_of_accounts 
# MAGIC   
# MAGIC **Inputs:**  
# MAGIC - {READ_ENV}_bronze.sap_latecoere_ecc6.ska1_latest
# MAGIC - {READ_ENV}_bronze.headers_sap.headers_sap_business_ska1
# MAGIC   
# MAGIC **Triggered by:**  
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import DataFrame
from leap_utils.data_asset import table_utils


# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")

dbutils.widgets.text("read_env", "prod")
READ_ENV = dbutils.widgets.get("read_env")

# COMMAND ----------

df_ska1 = spark.read.table(f'{READ_ENV}_bronze.sap_latecoere_ecc6.ska1_latest').filter(f.col('ktopl') == "CAFR")

# COMMAND ----------

# MAGIC %md
# MAGIC #Column renaming

# COMMAND ----------

# Renaming Sap Columns // add Table Name in header
def add_table_name(df: DataFrame, table_name: str) -> DataFrame:
    for col in df.columns:
        df = df.withColumnRenamed(f"{col}", f"{table_name}_{col}")
    return df

# --------------------------------------------------------------------------------------------------------------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )

# --------------------------------------------------------------------------------------------------------------

# Rename Columns according with Imput file 'Header Renaming
def rename_sap_column_names(df: DataFrame, df_names: DataFrame) -> DataFrame:
    dfp_names = df_names.toPandas()
    dfp_names["table_field"] = dfp_names["Table_name"] + "_" + dfp_names["Field"]
    for i, r in dfp_names.iterrows():

        df = df.withColumnRenamed(
            r["table_field"], r["Business_name"].replace(" ", "_")
        )
    return df


# --------------------------------------------------------------------------------------------------------------

# Create date format columns when indicated in the headers file
def modificate_format_column(df: DataFrame, df_names: DataFrame) -> DataFrame:
    """
    Create a date column when it is asked in the column name config file
    """
    for col in df.columns:
        if df_names.filter(f.col("Business_name") == col).count() > 0:
            if (
                df_names.filter(f.col("Business_name") == col)
                .select("Format")
                .first()[0]
                == "date"
            ):
                df = df.withColumn(f"{col}", f.to_date(f.col(f"{col}"), "yyyyMMdd"))
            else:
                if (
                    df_names.filter(f.col("Business_name") == col)
                    .select("Format")
                    .first()[0]
                    == "float"
                ):
                    df = df.withColumn(f"{col}", f.col(f"{col}").cast("float"))
    return df

# --------------------------------------------------------------------------------------------------------------

# COMMAND ----------

df_headers_ska1 = spark.read.table(f"{READ_ENV}_bronze.headers_sap.headers_sap_business_ska1")

df_ska1 = add_table_name(df_ska1, "ska1")  
check_schema_of_the_file(df_headers_ska1)  # <- call function Check Header files
df_renamed = rename_sap_column_names(
    df_ska1, df_headers_ska1
)  # <- Call Function Rename Columns according header file

# COMMAND ----------

# MAGIC %md
# MAGIC #Cleaning

# COMMAND ----------

def remove_lead_zero(col, n):
    """
    col: name of the column you want to modify
    n: number of leading 0 you want to remove
    """
    return f.when(
        f.regexp_extract(col, "^0{{{n}}}[^0]".format(n=n), 0) != "",
        f.expr("substring({col}, {n}, length({col}))".format(col=col, n=n + 1)),
    ).otherwise(f.col(col))

# COMMAND ----------

df_clean_acct = df_renamed.withColumn('Account_number', remove_lead_zero('Account_number', 2)).withColumn('Account_number', remove_lead_zero('Account_number', 3))

# COMMAND ----------

# MAGIC %md
# MAGIC #Save

# COMMAND ----------

# Save the proj payables table
catalog = f"{env}_silver"
domain = "finance"
table = "consolidation_chart_of_accounts"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_clean_acct,
    mode="overwrite",
    overwrite_schema=True
)
