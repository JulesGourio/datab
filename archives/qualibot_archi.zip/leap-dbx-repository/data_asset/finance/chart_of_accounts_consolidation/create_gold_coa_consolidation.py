# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to create the gold table for the consolidation chart of accounts.
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - {env}_gold.finance.consolidation_chart_of_accounts
# MAGIC - {env}_gold.finance.consolidation_chart_of_accounts_exposed
# MAGIC
# MAGIC **Input :**
# MAGIC - {env}_silver.finance.consolidation_chart_of_accounts
# MAGIC
# MAGIC **Triggered by:**
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
from databricks.sdk.runtime import dbutils

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("env", "dev")
env = dbutils.widgets.get("env")

dbutils.widgets.text("read_env", "prod")
READ_ENV = dbutils.widgets.get("read_env")

# COMMAND ----------

df_silver = spark.read.table(f"{env}_silver.finance.consolidation_chart_of_accounts")

# COMMAND ----------

# MAGIC %md
# MAGIC #Group designation
# MAGIC With a manual excel file. The aim here is to have a designation of consolidation groups code (ex R70100).

# COMMAND ----------

df_conso_map = spark.read.table("prod_bronze.manual_input.pnl_conso_categorisation")
df_with_conso_pnl = df_silver.join(
    df_conso_map,
    df_silver.conso_group_account == df_conso_map.Conso_account_group,
    how="left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Type of accounts
# MAGIC - Accounts that start with a "C" are consolidation accounts
# MAGIC - Accounts that start from 1 to 7 are social accounts
# MAGIC - Other accounts are analytics accounts

# COMMAND ----------

social_accounts = ["1", "2", "3", "4", "5", "6", "7"]
df_f = (
    df_with_conso_pnl.withColumn(
        "Type_of_accounts",
        f.when(f.col("Account_number").startswith("C"), f.lit("Conso")),
    )
    .withColumn(
        "Type_of_accounts",
        f.when(
            (f.col("Account_number")[0:1].isin(social_accounts))
            & (f.col("Type_of_accounts").isNull()),
            f.lit("Social"),
        ).otherwise(f.col("Type_of_accounts")),
    )
    .withColumn(
        "Type_of_accounts",
        f.when(f.col("Type_of_accounts").isNull(), f.lit("Analytics")).otherwise(
            f.col("Type_of_accounts")
        ),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Add EBIT and D&A flags based on Category and DnA columns
# MAGIC
# MAGIC TODO refactor/remove old Category and DnA columns one day, it's a tech debt.

# COMMAND ----------

df_conso_chart_of_accounts = df_f.withColumns(
    {
        "conso_is_EBIT": f.when(
            f.col("Category") == f.lit("EBIT"),
            f.lit(True),
        ).otherwise(False),
        "conso_is_DnA": f.when(
            f.col("DnA") == f.lit("D&A"),
            f.lit(True),
        ).otherwise(False),
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save

# COMMAND ----------

conso_chart_tablename = f"{env}_gold.finance.consolidation_chart_of_accounts"

table_utils.save_table(
    dest_table=conso_chart_tablename,
    df=df_conso_chart_of_accounts,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Gold exposed

# COMMAND ----------

Begin_By = "ska1"
selected_columns = [
    col for col in df_conso_chart_of_accounts.columns if not col.startswith(Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename=conso_chart_tablename,
    dest_full_tablename=f"{conso_chart_tablename}_exposed",
    select_statement=select_statement,
    replace_view=True,
)
