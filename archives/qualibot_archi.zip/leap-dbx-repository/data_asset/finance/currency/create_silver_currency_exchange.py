# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to create a silver table for currency exchange rate based on the full TCURR SAP table. The output table is a table with all days and all existing transactions between two currencies and the associated exchange rate. Both spot and budget rates are in this table. A column ID with the format '{CurrencySource}to{CurrencyTarget}' is created to simplify the use of the table.
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - {WRITE_ENV}_silver.finance.currency_exchange
# MAGIC
# MAGIC **Input table :**
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.tcurr_latest
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - SAP Ingestion Bronze
# MAGIC

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql import functions as f
from pyspark.sql.window import Window

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.removeAll()

# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")

# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table Currency from SAP

# COMMAND ----------

df_tcurr = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tcurr_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC #Cleaning TCURR

# COMMAND ----------

# Keep Only Budget (P), Spot (M), closure (1001) and conso (1002) currency exchange
df_tcurr = df_tcurr.filter(f.col("kurst").isin(["M", "P", "1001", "1002"]))

# COMMAND ----------

# Keep Only Exchange_Date between 2000-01-01 and Current date
df_tcurr = df_tcurr.withColumn("gdatu", f.col("gdatu").cast("int")).withColumn(
    "Current_Date", f.current_date()
)

df_tcurr = df_tcurr.withColumn(
    "gdatu_DateFormat", f.lit(-(f.col("gdatu") - 99999999))
).withColumn("gdatu_DateFormat", f.to_date(f.col("gdatu_DateFormat"), "yyyyMMdd"))

df_tcurr = df_tcurr.filter(
    (f.col("gdatu_DateFormat") >= "2000-01-01")
    & (f.col("gdatu_DateFormat") <= f.col("Current_Date"))
)

# COMMAND ----------

# Management of negative value in exchange_currency(ukurs):
df_tcurr = df_tcurr.withColumn(
    "ukurs_new",
    f.when(
        f.substring("ukurs", -1, 1) == "-",
        f.lit(1 / (f.expr("substring(ukurs, 1, length(ukurs)-1)")).cast("float")),
    ).otherwise(f.col("ukurs").cast("float")),
)

# COMMAND ----------

# Add UID and currencyPairID
df_tcurr = df_tcurr.withColumn(
    "currencyPairID", f.concat_ws("_", df_tcurr.kurst, df_tcurr.fcurr, df_tcurr.tcurr)
)

df_tcurr = df_tcurr.withColumn(
    "UID",
    f.concat_ws("_", df_tcurr.kurst, df_tcurr.fcurr, df_tcurr.tcurr, df_tcurr.gdatu),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Management of reverse exchange not found in Currency SAP

# COMMAND ----------

# In some case we don't have the reverse exchange in TCURR from SAP, so we add here all exchange missing
# Switch Currency
df_tcurr1 = df_tcurr.withColumnRenamed("tcurr", "fcurr1").withColumnRenamed(
    "fcurr", "tcurr1"
)

df_tcurr1 = df_tcurr1.withColumnRenamed("tcurr1", "tcurr").withColumnRenamed(
    "fcurr1", "fcurr"
)

# Calculate reverse exchange
df_tcurr1 = df_tcurr1.withColumn("ukurs_new", f.lit(1 / f.col("ukurs_new")))

# Add UID and currencyPairID
df_tcurr1 = df_tcurr1.withColumn(
    "currencyPairID",
    f.concat_ws("_", df_tcurr1.kurst, df_tcurr1.fcurr, df_tcurr1.tcurr),
)

df_tcurr1 = df_tcurr1.withColumn(
    "UID",
    f.concat_ws(
        "_", df_tcurr1.kurst, df_tcurr1.fcurr, df_tcurr1.tcurr, df_tcurr1.gdatu
    ),
)

# Union Tcurr and Tcurr_reverse
df_tcurr = df_tcurr.unionByName(df_tcurr1).drop_duplicates(["UID"])

# COMMAND ----------

# MAGIC %md
# MAGIC #Creation Complete DataBase with all date between beginDate and LastDate

# COMMAND ----------

# Get the column currencyPairID
df_currencyPairID = df_tcurr.select("currencyPairID").drop_duplicates()

# Get max and min date
beginDate = df_tcurr.agg({"gdatu_DateFormat": "min"}).collect()[0][0]
endDate = df_tcurr.agg({"gdatu_DateFormat": "max"}).collect()[0][0]

# Create sequential dates
spark.sql(
    f"select explode(sequence(to_date('{beginDate}'), to_date('{endDate}'), interval 1 day)) as gdatu_DateFormat"
).createOrReplaceTempView("dates")
df_date_range = spark.table("dates")

# Cross join entre currencyPairIDD et dates
df_all = df_currencyPairID.crossJoin(df_date_range)

# COMMAND ----------

# MAGIC %md
# MAGIC #Join TCURR with manual database

# COMMAND ----------

df_merged = df_all.join(
    df_tcurr, ["currencyPairID", "gdatu_DateFormat"], how="left"
).select(
    "currencyPairID",
    "gdatu_DateFormat",
    "mandt",
    "kurst",
    "fcurr",
    "tcurr",
    "gdatu",
    "ffact",
    "tfact",
    "UID",
    "ukurs_new",
)
window = Window.partitionBy("currencyPairID").orderBy("gdatu_DateFormat")
filled_column = f.last(df_merged["ukurs_new"], ignorenulls=True).over(window)
df_tcurr_master = df_merged.withColumn("ukurs", filled_column)

# COMMAND ----------

# MAGIC %md
# MAGIC #Create Master Dataframe for exchange rate

# COMMAND ----------

# Generate entries not found in SAP table by calculate all field for specific date
# Convert gdatu to sap format
df_tcurr_master = df_tcurr_master.withColumn(
    "tcurr_gdatu", f.regexp_replace((f.col("gdatu_DateFormat").cast("string")), "-", "")
)

df_tcurr_master = df_tcurr_master.withColumn(
    "tcurr_gdatu", f.lit(f.abs((f.col("tcurr_gdatu").cast("int")) - 99999999))
)

df_tcurr_master = df_tcurr_master.withColumn(
    "ID", f.concat_ws("_", "currencyPairID", "tcurr_gdatu")
)

df_tcurr_1 = df_tcurr_master.filter(f.col("ukurs_new").isNotNull())
df_tcurr_2 = df_tcurr_master.filter(f.col("ukurs_new").isNull())
df_tcurr_2 = df_tcurr_2.withColumn("mandt", f.lit(600))
df_tcurr_2 = df_tcurr_2.withColumn("kurst", f.split(f.col("ID"), "_").getItem(0))
df_tcurr_2 = df_tcurr_2.withColumn("fcurr", f.split(f.col("ID"), "_").getItem(1))
df_tcurr_2 = df_tcurr_2.withColumn("tcurr", f.split(f.col("ID"), "_").getItem(2))
df_tcurr_end = df_tcurr_1.unionByName(df_tcurr_2)
df_tcurr_end = df_tcurr_end.drop("ukurs_new", "gdatu", "ffact", "tfact", "UID")

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming Headers

# COMMAND ----------

# Rename Header files
df_tcurr = table_utils.add_prefix_to_columns(df_tcurr_end, "TCURR")

df_name_tcurr = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_tcurr")
# Check header schema
table_utils.check_schema_of_the_header_file(df_name_tcurr)
# Call Function Delete rows null
df_name_tcurr = delete_null_rows(df_name_tcurr)
# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(df_tcurr, df_name_tcurr)
# Call Funtion Create Columns on Date format
df_tcurr = table_utils.cast_columns_with_sap_business_headers(df_column_names, df_name_tcurr)
# Manual renaming
df_tcurr = (
    df_tcurr.withColumnRenamed("TCURR_gdatu_DateFormat", "Validity_Date_DateFormat")
    .withColumnRenamed("TCURR_currencyPairID", "currencyPairID")
    .withColumnRenamed("TCURR_tcurr_gdatu", "TCURR_gdatu")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save table

# COMMAND ----------

catalog = f"{WRITE_ENV}_silver"
domain = "finance"
table = "currency_exchange"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_tcurr,
    mode="overwrite",
    overwrite_schema=True
)
