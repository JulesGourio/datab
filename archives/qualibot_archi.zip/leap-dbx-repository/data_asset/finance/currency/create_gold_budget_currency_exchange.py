# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The aim of this notebook is to create a gold table for currency exchange rates based on the full TCURR SAP table. The output is a complete table containing:
# MAGIC - all calendar days,
# MAGIC - all existing transactions between two currencies,
# MAGIC - the associated exchange rate (both spot and budget rates).
# MAGIC Additionally, an ID column with the format {CurrencySource}to{CurrencyTarget} is generated to simplify usage.
# MAGIC
# MAGIC **What's new compared to create_gold_currency_exchange notebook**
# MAGIC This notebook replaces the other notebook for the calculation of budget_exchange_rate.
# MAGIC In the other notebook, only dates up to the current day were considered.
# MAGIC In this version, the restriction on date < today has been removed, which makes it possible to also include budget rates for next year.
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.finance.budget_currency_exchange
# MAGIC
# MAGIC **Input table :**
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tcurr_latest
# MAGIC

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql import functions as f
from pyspark.sql.window import Window

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.removeAll()

# Get read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------


# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# --------------------------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table Currency from SAP

# COMMAND ----------

df_tcurr = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tcurr_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC #Cleaning TCURR

# COMMAND ----------

# Keep Only Budget (P), Spot (M), closure (1001) and conso (1002) currency exchange
df_tcurr = df_tcurr.filter(f.col("kurst") == "P")

# COMMAND ----------

# Keep Only Exchange_Date between 2000-01-01 and Current date
df_tcurr = df_tcurr.withColumn("gdatu", f.col("gdatu").cast("int"))

df_tcurr = df_tcurr.withColumn(
    "gdatu_DateFormat", f.lit(-(f.col("gdatu") - 99999999))
).withColumn("gdatu_DateFormat", f.to_date(f.col("gdatu_DateFormat"), "yyyyMMdd"))

# COMMAND ----------

# Management of negative value in exchange_currency(ukurs):
df_tcurr = df_tcurr.withColumn(
    "ukurs_new",
    f.when(
        f.substring("ukurs", -1, 1) == "-",
        f.lit(1 / (f.expr("substring(ukurs, 1, length(ukurs)-1)")).cast("float")),
    ).otherwise(f.col("ukurs").cast("float")),
)

# COMMAND ----------

# Add UID and currencyPairID
df_tcurr = df_tcurr.withColumn(
    "currencyPairID", f.concat_ws("_", df_tcurr.kurst, df_tcurr.fcurr, df_tcurr.tcurr)
)

df_tcurr = df_tcurr.withColumn(
    "UID",
    f.concat_ws("_", df_tcurr.kurst, df_tcurr.fcurr, df_tcurr.tcurr, df_tcurr.gdatu),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Management of reverse exchange not found in Currency SAP

# COMMAND ----------

# In some case we don't have the reverse exchange in TCURR from SAP, so we add here all exchange missing
# Switch Currency
df_tcurr1 = df_tcurr.withColumnRenamed("tcurr", "fcurr1").withColumnRenamed(
    "fcurr", "tcurr1"
)

df_tcurr1 = df_tcurr1.withColumnRenamed("tcurr1", "tcurr").withColumnRenamed(
    "fcurr1", "fcurr"
)

# Calculate reverse exchange
df_tcurr1 = df_tcurr1.withColumn("ukurs_new", f.lit(1 / f.col("ukurs_new")))

# Add UID and currencyPairID
df_tcurr1 = df_tcurr1.withColumn(
    "currencyPairID",
    f.concat_ws("_", df_tcurr1.kurst, df_tcurr1.fcurr, df_tcurr1.tcurr),
)

df_tcurr1 = df_tcurr1.withColumn(
    "UID",
    f.concat_ws(
        "_", df_tcurr1.kurst, df_tcurr1.fcurr, df_tcurr1.tcurr, df_tcurr1.gdatu
    ),
)

# Union Tcurr and Tcurr_reverse
df_tcurr = df_tcurr.unionByName(df_tcurr1).drop_duplicates(["UID"])

# COMMAND ----------

# MAGIC %md
# MAGIC #Join TCURR with manual database

# COMMAND ----------

window = Window.partitionBy("currencyPairID").orderBy("gdatu_DateFormat")
filled_column = f.last(df_tcurr["ukurs_new"], ignorenulls=True).over(window)
df_tcurr_master = df_tcurr.withColumn("ukurs", filled_column)

# COMMAND ----------

# MAGIC %md
# MAGIC #Create Master Dataframe for exchange rate

# COMMAND ----------

# Generate entries not found in SAP table by calculate all field for specific date
# Convert gdatu to sap format
df_tcurr_master = df_tcurr_master.withColumn(
    "tcurr_gdatu", f.regexp_replace((f.col("gdatu_DateFormat").cast("string")), "-", "")
)

df_tcurr_master = df_tcurr_master.withColumn(
    "tcurr_gdatu", f.lit(f.abs((f.col("tcurr_gdatu").cast("int")) - 99999999))
)

df_tcurr_master = df_tcurr_master.withColumn(
    "ID", f.concat_ws("_", "currencyPairID", "tcurr_gdatu")
)

df_tcurr_1 = df_tcurr_master.filter(f.col("ukurs_new").isNotNull())
df_tcurr_2 = df_tcurr_master.filter(f.col("ukurs_new").isNull())
df_tcurr_2 = df_tcurr_2.withColumn("mandt", f.lit(600))
df_tcurr_2 = df_tcurr_2.withColumn("kurst", f.split(f.col("ID"), "_").getItem(0))
df_tcurr_2 = df_tcurr_2.withColumn("fcurr", f.split(f.col("ID"), "_").getItem(1))
df_tcurr_2 = df_tcurr_2.withColumn("tcurr", f.split(f.col("ID"), "_").getItem(2))
df_tcurr_end = df_tcurr_1.unionByName(df_tcurr_2)
df_tcurr_end = df_tcurr_end.drop("ukurs_new", "gdatu", "ffact", "tfact", "UID")

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming Headers

# COMMAND ----------

# Rename Header files
df_tcurr = table_utils.add_prefix_to_columns(df_tcurr_end, "TCURR")

df_name_tcurr = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_tcurr")
# Check header schema
table_utils.check_schema_of_the_header_file(df_name_tcurr)
# Call Function Delete rows null
df_name_tcurr = delete_null_rows(df_name_tcurr)
# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(df_tcurr, df_name_tcurr)
# Call Funtion Create Columns on Date format
df_tcurr = table_utils.cast_columns_with_sap_business_headers(df_column_names, df_name_tcurr)
# Manual renaming
df_tcurr = (
    df_tcurr.withColumnRenamed("TCURR_gdatu_DateFormat", "Validity_Date_DateFormat")
    .withColumnRenamed("TCURR_currencyPairID", "currencyPairID")
    .withColumnRenamed("TCURR_tcurr_gdatu", "TCURR_gdatu")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save table

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "finance"
table = "budget_currency_exchange"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_tcurr,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Gold Enrichment

# COMMAND ----------

df_tcurr_enrich = df_tcurr.withColumn(
    "Conversion_rate_Type_exp",
    f.when(f.col("Conversion_rate_Type") == "P", f.lit("Budget"))
    .otherwise(f.col("Conversion_rate_Type")),
)

df_tcurr_enrich = df_tcurr_enrich.drop("TCURR_mandt", "TCURR_gdatu", "TCURR_ID")

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_tcurr_enrich,
    mode="overwrite",
    overwrite_schema=True
)
