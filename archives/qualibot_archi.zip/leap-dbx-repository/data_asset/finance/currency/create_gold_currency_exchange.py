# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to create a gold / Gold Exposed table for currency exchange rate.
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - {WRITE_ENV}_dev.finance.currency_exchange
# MAGIC
# MAGIC **Input :**
# MAGIC   - {READ_ENV}_silver.finance.currency_exchange
# MAGIC
# MAGIC **Triggered by:**
# MAGIC NoteBook : create_silver_currency_exchange

# COMMAND ----------

from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.removeAll()

# Get read environment variable
dbutils.widgets.text("READ_ENV", "dev")
READ_ENV = dbutils.widgets.get("READ_ENV")

# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload table Currency

# COMMAND ----------

df_tcurr_silver = spark.read.table(f"{READ_ENV}_silver.finance.currency_exchange")

# COMMAND ----------

# MAGIC %md
# MAGIC #Gold Enrichement

# COMMAND ----------

df_tcurr_enrich = df_tcurr_silver.withColumn(
    "Conversion_rate_Type_exp",
    f.when(f.col("Conversion_rate_Type") == "M", f.lit("Spot"))
    .when(f.col("Conversion_rate_Type") == "P", f.lit("Budget"))
    .when(f.col("Conversion_rate_Type") == "1001", f.lit("Closure"))
    .when(f.col("Conversion_rate_Type") == "1002", f.lit("Consolidation"))
    .otherwise(f.col("Conversion_rate_Type")),
)

df_tcurr_enrich = df_tcurr_enrich.drop("TCURR_mandt", "TCURR_gdatu", "TCURR_ID")

# COMMAND ----------

# MAGIC %md
# MAGIC #Save the table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "finance"
table = "currency_exchange"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_tcurr_enrich,
    mode="overwrite",
    overwrite_schema=True
)
