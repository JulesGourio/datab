# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for data asset wbs_otp. 
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - `{WRITE_ENV}_silver.finance.wbs_otp`
# MAGIC
# MAGIC **Input :**  
# MAGIC   - `{READ_ENV}_bronze.sap_latecoere_ecc6.prps_latest`
# MAGIC   - `{HEADER_READ_ENV}_bronze.headers_sap.headers_sap_business_prps`
# MAGIC  
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> Ingestion raw data SAP
# MAGIC
# MAGIC **Things done:** 
# MAGIC - Renaming Headers
# MAGIC - Cleansing data : filter on "pkokr" to have only one Controlling Area per wbs. If PA01 exists keep it in priority else keep PA20
# MAGIC - Cleansing and Rewriting field WBS_Code
# MAGIC

# COMMAND ----------

# DBTITLE 1,Librairies
from pyspark.sql import DataFrame
from pyspark.sql import functions as f
from pyspark.sql.functions import row_number
from pyspark.sql.window import Window

## Upload LEAP Utils
from leap_utils.data_asset import table_utils

# Get read environment variable
dbutils.widgets.text("read_env", "prod")
READ_ENV = dbutils.widgets.get("read_env")
# Get write environment variable
dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

# Global variables
HEADER_READ_ENV = "prod"
DEBUG = False

# COMMAND ----------

# MAGIC %md 
# MAGIC #Functions

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# --------------------------------------------------------------------------------------------------------------

# Rename Columns according with Imput file 'Header Renaming
def rename_sap_column_names(df: DataFrame, df_names: DataFrame) -> DataFrame:
    dfp_names = df_names.toPandas()
    dfp_names["table_field"] = dfp_names["Table_name"] + "_" + dfp_names["Field"]
    for i, r in dfp_names.iterrows():

        df = df.withColumnRenamed(
            r["table_field"], r["Business_name"].replace(" ", "_")
        )
    return df


# --------------------------------------------------------------------------------------------------------------

# Create date format columns when indicated in the headers file
def modificate_format_column(df: DataFrame, df_names: DataFrame) -> DataFrame:
    """
    Create a date column when it is asked in the column name config file
    """
    for col in df.columns:
        if df_names.filter(f.col("Business_name") == col).count() > 0:
            if (
                df_names.filter(f.col("Business_name") == col)
                .select("Format")
                .first()[0]
                == "date"
            ):
                df = df.withColumn(f"{col}", f.to_date(f.col(f"{col}"), "yyyyMMdd"))
            else:
                if (
                    df_names.filter(f.col("Business_name") == col)
                    .select("Format")
                    .first()[0]
                    == "float"
                ):
                    df = df.withColumn(f"{col}", f.col(f"{col}").cast("float"))
    return df


# --------------------------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC # Upload PRPS Table

# COMMAND ----------

table_prps = f"{READ_ENV}_bronze.sap_latecoere_ecc6.prps_latest"
table_name_prps = f"{HEADER_READ_ENV}_bronze.headers_sap.headers_sap_business_prps"

df_prps = spark.read.table(f"{table_prps}")  # <- Upload SAP table for WBS_OTP

# COMMAND ----------

# MAGIC %md
# MAGIC # Cleaning raw data
# MAGIC ## Filtering duplicate controlling area - keeping PA01 over PA20 when both exists

# COMMAND ----------

# Filtering on SAP fields : partition on pspnr (WBS ID) , sorted by pkokr (Controlling_area) and keeping 1st occurence of Controlling_area
w = Window.partitionBy("mandt", "pspnr").orderBy("pkokr")
df_prps_before_filtering = df_prps
df_prps = (
    df_prps.withColumn("rn", row_number().over(w)).filter(f.col("rn") == 1).drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Renaming PRPS Table columns

# COMMAND ----------

# Add table prefix to columns
df_prps = table_utils.add_prefix_to_columns(df_prps, "PRPS")  # <- Renaming starting with PRPS_

# Read header table
df_name_prps = spark.read.table(
    f"{table_name_prps}"
)  # <- Upload manual table for headers naming

# Check header table
check_schema_of_the_file(df_name_prps)  # <- call function Check Header files
df_name_prps = delete_null_rows(df_name_prps)  # <- Call Function Delete rows null

# Rename table columns according to header
df_column_names = rename_sap_column_names(
    df_prps, df_name_prps
)  # <- Call Function Rename Columns according header file

# Change Date columns
df = modificate_format_column(
    df_column_names, df_name_prps
)  # <- Call Funtion Create Columns on Date format

# COMMAND ----------

# MAGIC %md
# MAGIC # Cleaning raw data

# COMMAND ----------

# DBTITLE 1,cleaning leading zeroes
# Create an int version of the WBS_Code_Num by removing leading zeroes
df_silver_wbs_otp = df.withColumn(
    "WBS_Code_Num_short", f.regexp_replace("WBS_Code_Num", r"^[0]*", "").cast("int")
)

# COMMAND ----------

# DBTITLE 1,clean WBS_Code
# Remove unwanted '-' or ' ' in the WBS_Code
df_silver_wbs_otp = df_silver_wbs_otp.withColumn(
    "WBS_Code", f.regexp_replace("WBS_Code", r"-", "")
)
df_silver_wbs_otp = df_silver_wbs_otp.withColumn(
    "WBS_Code", f.regexp_replace("WBS_Code", r" ", "")
)

# COMMAND ----------

# DBTITLE 1,re-write WBS_Code to new_column
# We change product ID format to fit the one known by users
# if 12 caracters long : XX-XXXXXXXX-XX
# if 14 caracters long : XX-XXXXXXXX-XX-XX
# else keep as is
df_silver_wbs_otp = df_silver_wbs_otp.withColumn("WBS_Code", f.trim(f.col("WBS_Code")))
df_silver_wbs_otp = df_silver_wbs_otp.withColumn(
    "WBS_Code",
    f.when(
        (f.length("WBS_Code") == 12),
        f.concat_ws(
            "-",
            f.substring("WBS_Code", 1, 2),
            f.substring("WBS_Code", 3, 8),
            f.substring("WBS_Code", 11, 2),
        ),
    )
    .when(
        (f.length("WBS_Code") == 14),
        f.concat_ws(
            "-",
            f.substring("WBS_Code", 1, 2),
            f.substring("WBS_Code", 3, 8),
            f.substring("WBS_Code", 11, 2),
            f.substring("WBS_Code", 13, 2),
        ),
    )
    .otherwise(f.col("WBS_Code")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Save Silver Table

# COMMAND ----------

catalog = f"{WRITE_ENV}_silver"
domain = "finance"
table = "wbs_otp"

CreateSchemaIfNotExists = False

if CreateSchemaIfNotExists:
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_silver_wbs_otp,
    mode="overwrite",
    overwrite_schema=True
)
