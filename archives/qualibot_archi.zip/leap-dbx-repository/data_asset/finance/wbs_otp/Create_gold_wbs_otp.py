# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table & Gold_Exposed for data asset wbs_otp..
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - `{WRITE_ENV}_gold.finance.wbs_otp`
# MAGIC   - `{WRITE_ENV}_gold.finance.wbs_otp_exposed`
# MAGIC
# MAGIC **Input :** 
# MAGIC   - `{READ_ENV}_silver.finance.wbs_otp`
# MAGIC   - `{READ_ENV}_bronze.sap_latecoere_ecc6.t001_latest`
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> 
# MAGIC
# MAGIC **Things done :** 
# MAGIC - add company name and currency           
# MAGIC - add field "Is_currency_valid" = True when "Currency" match "CompanyCurrency"          
# MAGIC - change field "WBS_Lock_Indicator", when "X" then "Locked" else "Unlocked"                  

# COMMAND ----------

# MAGIC %md 
# MAGIC # Process

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from leap_utils.data_asset import table_utils

# Get read environment variable
dbutils.widgets.text("read_env", "prod")
READ_ENV = dbutils.widgets.get("read_env")
# Get write environment variable
dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Tables from Silver

# COMMAND ----------

df_wbs_otp = spark.read.table(f"{READ_ENV}_silver.finance.wbs_otp")  # <- Upload wbs_otp
df_company = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.t001_latest")  # <- Upload companies
df_company = df_company.select(
    "mandt",
    "bukrs",
    f.col("butxt").alias("CompanyDesc"),
    f.col("waers").alias("CompanyCurrency"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Gold Enrichment

# COMMAND ----------

# MAGIC %md
# MAGIC ###Add company text data

# COMMAND ----------

df_join_wbs_otp = df_wbs_otp.alias("A").join(
    df_company.alias("B"), (f.col("A.WBS_Company_Code") == f.col("B.bukrs")), "left"
)
df_join_wbs_otp = df_join_wbs_otp.drop("mandt", "bukrs")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Management of Null values

# COMMAND ----------

# Replace all null value by Unknown
columns_to_replace = ["CompanyDesc"]
replacement_value = "Unknown"
replacement_values = {col_name: replacement_value for col_name in columns_to_replace}
df_join_wbs_otp = df_join_wbs_otp.fillna(replacement_values)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Add field "Is_currency_valid"

# COMMAND ----------

# check if WBS_Currency_Code match the company currency
df_join_wbs_otp = df_join_wbs_otp.withColumn(
    "Is_currency_valid",
    f.when(f.col("WBS_Currency_Code") == f.col("CompanyCurrency"), True).otherwise(
        False
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Change field "WBS_Lock_Indicator"
# MAGIC when "X" then "Locked" else "Unlocked"

# COMMAND ----------

df_join_wbs_otp = df_join_wbs_otp.withColumn(
    "WBS_Lock_Indicator",
    f.when(f.col("WBS_Lock_Indicator") == "X", "Locked").otherwise("Unlocked"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save the gold table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "finance"
table = "wbs_otp"

CreateSchemaIfNotExists = True

if CreateSchemaIfNotExists:
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_join_wbs_otp,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save the gold_exposed view

# COMMAND ----------

def exposed_gold_table_latest(goldColumns):
    query = "CREATE OR REPLACE VIEW {}_gold.finance.wbs_otp_exposed as select {} from {}_gold.finance.wbs_otp;".format(
        WRITE_ENV, ", ".join(goldColumns), WRITE_ENV
    )

    print(query)

    query_results = spark.sql(str(query))

    display(query_results)
    return None

# COMMAND ----------

goldColumns = []
Begin_By = "PRPS"
for i in df_join_wbs_otp.columns:
    if not i.startswith(Begin_By):
        goldColumns.append(i)

exposed_gold_table_latest(goldColumns)
