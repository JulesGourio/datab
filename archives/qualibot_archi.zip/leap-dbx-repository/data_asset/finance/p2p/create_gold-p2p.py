# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to match between P2P items: invoices, purchase orders and good receipts.
# MAGIC
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.finance.p2p_payables  
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - {REFERENCE_READ_ENV}_gold.supply_chain_procurement.purchase_orders_exposed  
# MAGIC   - {REFERENCE_READ_ENV}_gold.supply_chain_procurement.purchase_request_all    
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.gr_latest  
# MAGIC   - {PIPELINE_READ_ENV}_gold.finance.invoices_supplier_all
# MAGIC   - {PIPELINE_READ_ENV}_gold.finance.sap_deposit_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.currency_exchange
# MAGIC   - {REFERENCE_READ_ENV}_bronze.manual_input.vat_company_supplier  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest  
# MAGIC   
# MAGIC **Triggered by:**  
# MAGIC   - End NoteBook Purchase Order // Purchase Order
# MAGIC   
# MAGIC **Remarks:**

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window


from leap_utils.data_asset import payment_term
from leap_utils.data_asset.table_utils import (
    save_table
)

dbutils.widgets.removeAll()
# Get read reference environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get read pipeline environment variable
dbutils.widgets.text("pipeline_read_env", "prod")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# --------------------------------------------------------------------------------------------------------------
# Function for Conversion Currency
def convert_currency_spot(
    df_currency,
    df_base,
    target_currency_value,
    source_currency_column_name,
    df_base_conversion_date_column_name,
    conversion_output_column_name,
):
    """Function for Conversion Currency"""
    listColumns = df_base.columns
    df_currency_spot = df_currency.filter(f.col("Conversion_rate_Type") == "M")
    df = (
        df_base.alias("A")
        .join(
            df_currency_spot.alias("B"),
            (f.col("B.Currency_Target") == target_currency_value)
            & (f.col("B.Currency_Source") == f.col(source_currency_column_name))
            & (
                f.col("B.Validity_Date_DateFormat")
                == f.col(df_base_conversion_date_column_name)
            ),
            "left",
        )
        .select(
            f.col("A.*"), f.col("B.Exchange_Rate").alias(conversion_output_column_name)
        )
    )
    listColumns.append(conversion_output_column_name)
    return df.select(listColumns)

# COMMAND ----------

# MAGIC %md
# MAGIC #Import tables

# COMMAND ----------

# Upload Gold exposed Purchase Order
df_gold_PO = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain_procurement.purchase_orders_exposed"
)
# Upload Gold exposed Purchase Order
df_gold_PR = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain_procurement.purchase_request_all"
)
# Upload Gold exposed Good Receipts
df_gold_GR = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.gr_latest")
# Upload Gold exposed Invoices
df_gold_INV = spark.read.table(f"{PIPELINE_READ_ENV}_gold.finance.invoices_supplier_all")
# Upload Gold exposed Deposit
df_gold_deposit = spark.read.table(f"{PIPELINE_READ_ENV}_gold.finance.sap_deposit_exposed")
# Upload Gold Currency
df_currency = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.currency_exchange")

# Upload Payment terms
df_t052 = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 1 - PURCHASE ORDER

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filter on PO Table

# COMMAND ----------

# Keep Only PO in Progress
df_gold_PO = df_gold_PO.filter(f.col("PO_Status") == "PO_In_Progress")

# Exclusion transfer PO inside same company  && Exclusion Open PO inside
df_gold_PO = df_gold_PO.withColumn("PO_Type", f.trim("PO_Type"))
list_cde = ["UB", "ZUB", "FO", "FOA", "FOF", "FOP", "FOTS"]
df_gold_PO = df_gold_PO.withColumn(
    "PO_Type_todelete",
    f.when(f.col("PO_Type").isin(list_cde), f.lit("Out")).otherwise(f.lit("X")),
)
df_gold_PO = df_gold_PO.filter(f.col("PO_Type_todelete") == "X").drop(
    "PO_Type_todelete"
)
# Exclusion free PO
df_gold_PO = df_gold_PO.filter(f.col("Remaining_Value") != 0)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Finance PO Gold enrichments 

# COMMAND ----------

# Error Gestion if Payment Term is null
df_gold_GR = df_gold_GR.withColumn(
    "PO_Payment_Term",
    f.when(
        f.col("PO_Payment_Term").isNull(), f.col("Supplier_Payment_Term")
    ).otherwise(f.col("PO_Payment_Term")),
)
df_gold_GR = df_gold_GR.withColumn(
    "PO_Payment_Term",
    f.when(f.col("PO_Payment_Term").isNull(), f.lit("Z005")).otherwise(
        f.col("PO_Payment_Term")
    ),
)
df_gold_GR = df_gold_GR.withColumn(
    "Supplier_Payment_Term",
    f.when(
        f.col("Supplier_Payment_Term").isNull(), f.col("PO_Payment_Term")
    ).otherwise(f.col("Supplier_Payment_Term")),
)
df_gold_GR = df_gold_GR.withColumn(
    "Supplier_Payment_Term",
    f.when(f.col("Supplier_Payment_Term").isNull(), f.lit("Z005")).otherwise(
        f.col("Supplier_Payment_Term")
    ),
)
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Add Cat & Payment Status
df_gold_PO = df_gold_PO.withColumn("Cat", f.lit("PO"))
df_gold_PO = df_gold_PO.withColumn("Payment_Status", f.lit("UNPAID"))

# Calcul Payment_Term_Due_Date & Supplier_Term_Due_Date

df_gold_PO = payment_term.calculate_payment_term_due_date(
    df_gold_PO,
    df_t052,
    df_gold_PO["PO_Payment_Term"],
    df_gold_PO.Delivery_Date_Planned,
    "Payment_Term_Due_Date",
)

df_gold_PO = payment_term.calculate_payment_term_due_date(
    df_gold_PO,
    df_t052,
    df_gold_PO["Supplier_Payment_Term"],
    df_gold_PO.Delivery_Date_Planned,
    "Supplier_Payment_Term_Due_Date",
)

df_gold_PO = df_gold_PO.withColumn(
    "Gap_Payment_Term",
    f.when(
        f.col("PO_Payment_Term") != f.col("Supplier_Payment_Term"), f.lit("Yes")
    ).otherwise(f.lit("No")),
)

# Calcul VAT
df_vat = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.manual_input.vat_company_supplier")
df_gold_PO = (
    df_gold_PO.alias("A")
    .join(
        df_vat.alias("B"),
        (f.col("A.Company_Code") == f.col("B.Company_Code"))
        & (f.col("A.Supplier_country") == f.col("B.Supplier_country")),
        "left",
    )
    .select(f.col("A.*"), f.col("B.Coefficient").alias("VAT_Rate"))
)
df_gold_PO = df_gold_PO.withColumn("VAT_Rate", f.regexp_replace(df_gold_PO["VAT_Rate"], ",", "."))

df_gold_PO = df_gold_PO.withColumn(
    "VAT_Rate",
    f.when(f.col("VAT_Rate").isNull()==True, f.lit(1)).otherwise(f.col("VAT_Rate")),
)

df_gold_PO = df_gold_PO.withColumnRenamed(
    "Remaining_Value", "Amount_Net_Document_Currency"
)
# "Erreur dans le NET et GROSS
# -----------------------------------------------------------------------------------------------------------------------------------------
df_gold_PO = df_gold_PO.withColumn(
    "Amount_Net_Document_Currency", f.col("Amount_Net_Document_Currency").cast("double")
)
df_gold_PO = df_gold_PO.withColumn(
    "Amount_Gross_Doc_Currency",
    f.col("Amount_Net_Document_Currency") * f.col("VAT_Rate"),
)
df_gold_PO = df_gold_PO.withColumn(
    "Amount_VAT_Doc_Currency",
    f.col("Amount_Gross_Doc_Currency") - f.col("Amount_Net_Document_Currency"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Select View On PO table

# COMMAND ----------

df_gold_PO = df_gold_PO.select(
    "Cat",
    "Payment_Status",
    "Company_Entity",
    "Company_Code",
    "Company_Description",
    "Company_Land",
    "Company_Currency",
    "PO_Number",
    "PO_Item_Number",
    "Delivery_Date_Planned",
    "Currency_PO",
    "Amount_Net_Document_Currency",
    "Amount_Gross_Doc_Currency",
    "Amount_VAT_Doc_Currency",
    "Intercompany_flow",
    "Profit_Center",
    "Supplier_Code",
    "Supplier_name",
    "Supplier_country",
    "Supplier_Category",
    "Incoterm_Code",
    "Incoterm_Detail",
    "Spend_category",
    "Payment_Term_Due_Date",
    "Supplier_Payment_Term_Due_Date",
    "Gap_Payment_Term",
    "PO_Payment_Term",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 2 - GOODS RECEIPTS

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filter on GR Table

# COMMAND ----------

# Add Cat & Payment status
df_gold_GR = df_gold_GR.withColumn("Cat", f.lit("GR"))
df_gold_GR = df_gold_GR.withColumn("Payment_Status", f.lit("UNPAID"))
# Calcul of remaning value
df_gold_GR = df_gold_GR.withColumn(
    "Remaining_Value", f.col("Quantity") * f.col("Unit_price")
)
# Exclusion transfer PO inside same company  && Exclusion Open PO inside
df_gold_GR = df_gold_GR.withColumn("PO_Type", f.trim("PO_Type"))
list_cde = ["UB", "ZUB", "FO", "FOA", "FOF", "FOP", "FOTS"]
df_gold_GR = df_gold_GR.withColumn(
    "PO_Type_todelete",
    f.when(f.col("PO_Type").isin(list_cde), f.lit("Out")).otherwise(f.lit("X")),
)
df_gold_GR = df_gold_GR.filter(f.col("PO_Type_todelete") == "X").drop(
    "PO_Type_todelete"
)

# Exclusion free PO
df_gold_GR = df_gold_GR.filter(f.col("Remaining_Value") > 0)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Finance GR Gold enrichments 

# COMMAND ----------

# Error Gestion if Payment Term is null
df_gold_GR = df_gold_GR.withColumn(
    "PO_Payment_Term",
    f.when(
        f.col("PO_Payment_Term").isNull(), f.col("Supplier_Payment_Term")
    ).otherwise(f.col("PO_Payment_Term")),
)
df_gold_GR = df_gold_GR.withColumn(
    "PO_Payment_Term",
    f.when(f.col("PO_Payment_Term").isNull(), f.lit("Z005")).otherwise(
        f.col("PO_Payment_Term")
    ),
)
df_gold_GR = df_gold_GR.withColumn(
    "Supplier_Payment_Term",
    f.when(
        f.col("Supplier_Payment_Term").isNull(), f.col("PO_Payment_Term")
    ).otherwise(f.col("Supplier_Payment_Term")),
)
df_gold_GR = df_gold_GR.withColumn(
    "Supplier_Payment_Term",
    f.when(f.col("Supplier_Payment_Term").isNull(), f.lit("Z005")).otherwise(
        f.col("Supplier_Payment_Term")
    ),
)
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Calcul Payment_Term_Due_Date
df_gold_GR = payment_term.calculate_payment_term_due_date(
    df_gold_GR,
    df_t052,
    df_gold_GR["PO_Payment_Term"],
    df_gold_GR.Delivery_Date_Planned,
    "Payment_Term_Due_Date",
)

df_gold_GR = payment_term.calculate_payment_term_due_date(
    df_gold_GR,
    df_t052,
    df_gold_GR["Supplier_Payment_Term"],
    df_gold_GR.Delivery_Date_Planned,
    "Supplier_Payment_Term_Due_Date",
)


df_gold_GR = df_gold_GR.withColumn(
    "Gap_Payment_Term",
    f.when(
        f.col("PO_Payment_Term") != f.col("Supplier_Payment_Term"), f.lit("Yes")
    ).otherwise(f.lit("No")),
)
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Calcul VAT
df_vat = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.manual_input.vat_company_supplier")
df_gold_GR = (
    df_gold_GR.alias("A")
    .join(
        df_vat.alias("B"),
        (f.col("A.Company_Code") == f.col("B.Company_Code"))
        & (f.col("A.Supplier_country") == f.col("B.Supplier_country")),
        "left",
    )
    .select(f.col("A.*"), f.col("B.Coefficient").alias("VAT_Rate"))
)
df_gold_GR = df_gold_GR.withColumn("VAT_Rate", f.regexp_replace(df_gold_GR["VAT_Rate"], ",", "."))
df_gold_GR = df_gold_GR.withColumn(
    "VAT_Rate",
    f.when(f.col("VAT_Rate").isNull(), f.lit(1)).otherwise(f.col("VAT_Rate")),
)
df_gold_GR = df_gold_GR.withColumnRenamed(
    "Remaining_Value", "Amount_Net_Document_Currency"
)
# "Erreur dans le NET et GROSS
# -----------------------------------------------------------------------------------------------------------------------------------------
df_gold_GR = df_gold_GR.withColumn(
    "Amount_Net_Document_Currency", f.col("Amount_Net_Document_Currency").cast("double")
)
df_gold_GR = df_gold_GR.withColumn(
    "Amount_Gross_Doc_Currency",
    f.col("Amount_Net_Document_Currency") * f.col("VAT_Rate"),
)
df_gold_GR = df_gold_GR.withColumn(
    "Amount_VAT_Doc_Currency",
    f.col("Amount_Gross_Doc_Currency") - f.col("Amount_Net_Document_Currency"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Select View On PO table

# COMMAND ----------

df_gold_GR = df_gold_GR.select(
    "Cat",
    "Payment_Status",
    "Company_Entity",
    "Company_Code",
    "Company_Description",
    "Company_Land",
    "Company_Currency",
    "PO_Number",
    "PO_Item_Number",
    "Delivery_Date_Planned",
    "PO_Payment_Term",
    "Currency_PO",
    "Amount_Net_Document_Currency",
    "Amount_Gross_Doc_Currency",
    "Amount_VAT_Doc_Currency",
    "Intercompany_flow",
    "Profit_Center",
    "Supplier_Code",
    "Supplier_name",
    "Supplier_country",
    "Supplier_Category",
    "Incoterm_Code",
    "Incoterm_Detail",
    "Spend_category",
    "Payment_Term_Due_Date",
    "Supplier_Payment_Term_Due_Date",
    "Gap_Payment_Term",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 3 - Stack & Mach PO / GR

# COMMAND ----------

df_stack_pogr = df_gold_PO.unionByName(df_gold_GR, allowMissingColumns=True)

# Renaming Columns for Match PO / GR
new_column_names = {
    "Amount_Net_Document_Currency": "Amount_Net_Doc_Currency",
    "PO_Item_Number": "Doc_Item_Number",
    "PO_Number": "Doc_Number",
    "Currency_PO": "Document_Currency",
    "Delivery_Date_Planned": "Doc_Date",
    "PO_Payment_Term": "Payment_Term",
}
for old_name, new_name in new_column_names.items():
    df_stack_pogr = df_stack_pogr.withColumnRenamed(old_name, new_name)

# Enrichment Stack for match with invoices
df_stack_pogr = df_stack_pogr.withColumn("Posting_Year", f.year(f.col("Doc_Date")))
df_stack_pogr = df_stack_pogr.withColumn(
    "Payment_Term_Due_Date",
    f.when(
        f.col("Payment_Term_Due_Date").isNull(), f.col("Doc_Date")
    ).otherwise(f.col("Payment_Term_Due_Date")),
)
df_stack_pogr = df_stack_pogr.withColumn(
    "Supplier_Payment_Term_Due_Date",
    f.when(
        f.col("Supplier_Payment_Term_Due_Date").isNull(), f.col("Doc_Date")
    ).otherwise(f.col("Supplier_Payment_Term_Due_Date")),
)
df_stack_pogr = df_stack_pogr.withColumn(
    "latest_known_payment_date", f.col("Payment_Term_Due_Date")
)
df_stack_pogr = df_stack_pogr.withColumn(
    "Gap_Payment_Term",
    f.when(
        f.col("Supplier_Payment_Term_Due_Date") != f.col("Payment_Term_Due_Date"),
        f.lit("Yes"),
    ).otherwise(f.lit("No")),
)
df_stack_pogr = df_stack_pogr.withColumn("DataSource", f.lit("SAP"))

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 4 - INVOICES

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filter on invoice Table

# COMMAND ----------

# Nothing we take all Invoices

# COMMAND ----------

# MAGIC %md
# MAGIC ## Finance Invoices Gold enrichments 

# COMMAND ----------

# Add Cat + Check Payment_Due_Date
df_gold_INV = df_gold_INV.withColumn(
    "Cat",
    f.when(f.col("Payment_Block_Code") == "*", f.lit("INV-LOCK")).otherwise(
        f.lit("INV")
    ),
)

df_gold_INV = df_gold_INV.withColumn(
    "latest_known_payment_date",
    f.when(f.col("Payment_Status") == "PAID", f.col("Clearing_Date")).otherwise(
        f.col("Payment_Term_Due_Date")
    ),
)
df_gold_INV = df_gold_INV.withColumn(
    "latest_known_payment_date",
    f.when(f.col("latest_known_payment_date").isNull(), f.col("Base_Date")).otherwise(
        f.col("latest_known_payment_date")
    ),
)
df_gold_INV = df_gold_INV.withColumn(
    "Supplier_Payment_Term_Due_Date",
    f.when(
        f.col("Supplier_Payment_Term_Due_Date").isNull(), f.col("Base_Date")
    ).otherwise(f.col("Supplier_Payment_Term_Due_Date")),
)
df_gold_INV = df_gold_INV.withColumnRenamed(
    "Amount_Net_Document_Currency", "Amount_Net_Doc_Currency"
)
df_gold_INV = df_gold_INV.withColumnRenamed(
    "Amount_Gross_Document_Currency", "Amount_Gross_Doc_Currency"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Select View On Invoice Table
# MAGIC

# COMMAND ----------

df_gold_INV = df_gold_INV.select(
    "Cat",
    "Payment_Status",
    "Company_Code",
    "Company_Entity",
    "Company_Description",
    "Posting_Year",
    "Posting_Date",
    "Doc_Number",
    "Doc_Item_Number",
    "Clearing_Date",
    "Amount_Gross_Doc_Currency",
    "Amount_VAT_Doc_Currency",
    "Amount_Net_Doc_Currency",
    "latest_known_payment_date",
    "Payment_Term_Due_Date",
    "Supplier_Payment_Term_Due_Date",
    "Supplier_Code",
    "Supplier_name",
    "Incoterm_Code",
    "Incoterm_Detail",
    "Intercompany_flow",
    "Supplier_country",
    "Spend_category",
    "Supplier_Category",
    "Profit_Center",
    "DataSource",
    "Document_Type",
    "Gap_Payment_Term",
    "Gap_BaseDate_DocDate",
    "Company_Land",
    "Company_Currency",
    "Document_Currency",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 5 - Purchase Request

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filter on Purchase Request Table

# COMMAND ----------

# Take only Open Purchase Requisition
df_gold_PR = df_gold_PR.filter(f.col('Status')== "PR_Open")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Purchase Request Gold enrichments 

# COMMAND ----------

# Add Cat + Check Payment_Due_Date
df_gold_PR = df_gold_PR.withColumn("Cat", f.lit("PR"))
df_gold_PR = df_gold_PR.withColumn("Payment_Status", f.lit("UNPAID"))
# Renaming for Stack
df_gold_PR = df_gold_PR.withColumnRenamed("Supplier_Name","Supplier_name")
df_gold_PR = df_gold_PR.withColumnRenamed("Spend_Category","Spend_category")
df_gold_PR = df_gold_PR.withColumnRenamed("Company_Country_Code","Company_Land")
df_gold_PR = df_gold_PR.withColumnRenamed("Amount_Standard_Price","Amount_Net_Doc_Currency")
df_gold_PR = df_gold_PR.withColumnRenamed("PR_Number","Doc_Number")
df_gold_PR = df_gold_PR.withColumnRenamed("PR_Item_Number","Doc_Item_Number")
# Management if Payment Term is null
df_gold_PR = df_gold_PR.withColumn(
    "Payment_Term",
    f.when(f.col("Payment_Term").isNull(), f.lit("Z005")).otherwise(
        f.col("Payment_Term")
    ),
)
# Calcul Payment_Term_Due_Date & Supplier_Term_Due_Date & Gap

df_gold_PR = payment_term.calculate_payment_term_due_date(
    df_gold_PR,
    df_t052,
    df_gold_PR["Payment_Term"],
    df_gold_PR.Delivery_Date,
    "Supplier_Payment_Term_Due_Date",
)

#No Payment terms in PR so we take same value comming from Supplier
df_gold_PR = df_gold_PR.withColumn("Payment_Term_Due_Date",f.col('Supplier_Payment_Term_Due_Date'))
df_gold_PR = df_gold_PR.withColumn("latest_known_payment_date",f.col('Supplier_Payment_Term_Due_Date'))
df_gold_PR = df_gold_PR.withColumn("Gap_Payment_Term",f.lit("No"))
df_gold_PR = df_gold_PR.withColumn("Posting_Year", f.year(f.col("latest_known_payment_date")))

# Calcul VAT
df_vat = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.manual_input.vat_company_supplier")
df_gold_PR = (
    df_gold_PR.alias("A")
    .join(
        df_vat.alias("B"),
        (f.col("A.Company_Code") == f.col("B.Company_Code"))
        & (f.col("A.Supplier_country") == f.col("B.Supplier_country")),
        "left",
    )
    .select(f.col("A.*"), f.col("B.Coefficient").alias("VAT_Rate"))
)

df_gold_PR = df_gold_PR.withColumn("VAT_Rate", f.regexp_replace(df_gold_PR["VAT_Rate"], ",", "."))
df_gold_PR = df_gold_PR.withColumn(
    "VAT_Rate",
    f.when(f.col("VAT_Rate").isNull(), f.lit(1)).otherwise(f.col("VAT_Rate")),
)

# Creation Gross and VAT value
# -----------------------------------------------------------------------------------------------------------------------------------------
df_gold_PR = df_gold_PR.withColumn(
    "Amount_Net_Doc_Currency", f.col("Amount_Net_Doc_Currency").cast("double")
)
df_gold_PR = df_gold_PR.withColumn(
    "Amount_Gross_Doc_Currency",
    f.col("Amount_Net_Doc_Currency") * f.col("VAT_Rate"),
)
df_gold_PR = df_gold_PR.withColumn(
    "Amount_VAT_Doc_Currency",
    f.col("Amount_Gross_Doc_Currency") - f.col("Amount_Net_Doc_Currency"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Select View On PR Table

# COMMAND ----------

df_gold_PR = df_gold_PR.select(
    "Cat",
    "Payment_Status",
    "Company_Code",
    "Company_Entity",
    "Company_Description",
    "Doc_Number",
    "Doc_Item_Number",
    "Posting_Year",
    "Amount_Gross_Doc_Currency",
    "Amount_VAT_Doc_Currency",
    "Amount_Net_Doc_Currency",
    "latest_known_payment_date",
    "Payment_Term_Due_Date",
    "Supplier_Payment_Term_Due_Date",
    "Supplier_Code",
    "Supplier_name",
    "Incoterm_Code",
    "Incoterm_Detail",
    "Supplier_country",
    "Spend_category",
    "Supplier_Category",
    "Profit_Center",
    "DataSource",
    "Gap_Payment_Term",
    "Company_Land",
    "Company_Currency",
    "Document_Currency",
    "Payment_Term",
    "Intercompany_flow",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 6 - Deposit

# COMMAND ----------

# MAGIC %md
# MAGIC ## PO_Deposit filter

# COMMAND ----------

# We keep only DEPOSIT with Number Purchase Order
df_gold_deposit = df_gold_deposit.filter(f.col("Cat")=='PO_Deposit')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Desposit  Gold enrichments

# COMMAND ----------

df_gold_deposit = df_gold_deposit.withColumn(
    "latest_known_payment_date",
    f.when(f.col("Payment_Status") == "PAID", f.col("Clearing_Date")).otherwise(
        f.col("Payment_Term_Due_Date")
    ),
)
df_gold_deposit = df_gold_deposit.withColumn(
    "latest_known_payment_date",
    f.when(
        f.col("latest_known_payment_date").isNull(), f.col("Base_Date")
    ).otherwise(f.col("latest_known_payment_date")),
)
df_gold_deposit = df_gold_deposit.withColumn(
    "Supplier_Payment_Term_Due_Date",
    f.when(
        f.col("Supplier_Payment_Term_Due_Date").isNull() , f.col("Base_Date")
    ).otherwise(f.col("Supplier_Payment_Term_Due_Date")),
)
df_gold_deposit = df_gold_deposit.withColumn("DataSource",f.lit("SAP"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Select View On Desposit Table

# COMMAND ----------

df_gold_deposit = df_gold_deposit.select(
    "Cat",
    "Payment_Status",
    "Company_Code",
    "Company_Entity",
    "Company_Description",
    "Posting_Year",
    "Posting_Date",
    "Doc_Number",
    "Doc_Item_Number",
    "Clearing_Date",
    "Amount_Gross_Doc_Currency",
    "Amount_VAT_Doc_Currency",
    "Amount_Net_Doc_Currency",
    "latest_known_payment_date",
    "Payment_Term_Due_Date",
    "Supplier_Payment_Term_Due_Date",
    "Supplier_Code",
    "Supplier_name",
    "Incoterm_Code",
    "Incoterm_Detail",
    "Supplier_country",
    "Spend_category",
    "Supplier_Category",
    "Profit_Center",
    "DataSource",
    "Gap_Payment_Term",
    "Gap_BaseDate_DocDate",
    "Company_Land",
    "Company_Currency",
    "Document_Currency",
    "Doc_Date",
    "Payment_Term",
    "Intercompany_flow",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # STEP 6 - Stack & Mach PO / GR / INV / PR

# COMMAND ----------

# MAGIC %md
# MAGIC ##  Stack & Mach PO / GR / INV / PR

# COMMAND ----------

df_stack_all = df_gold_INV.unionByName(df_stack_pogr, allowMissingColumns=True).unionByName(df_gold_PR, allowMissingColumns=True).unionByName(df_gold_deposit, allowMissingColumns=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Enrichment Stack & Mach PO / GR / INV / PR

# COMMAND ----------

# Managment of Intercompany Flows
df_stack_all = df_stack_all.withColumn(
    "Intercompany_Flow", f.trim(f.col("Intercompany_Flow"))
)

df_stack_all = df_stack_all.withColumnRenamed("Intercompany_Flow", "Partner")
List_no_interco = ["", "X000", "000500", "S400", "S200", "001200"]
df_stack_all = df_stack_all.withColumn(
    "Intercompany_flow",
    f.when(
        (f.col("Partner").isin(List_no_interco)) | (f.col("Partner").isNull()),
        f.lit("No"),
    ).otherwise(f.lit("Yes")),
).drop(f.col("Partner"))
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Cast Doc_Currency
df_stack_all = df_stack_all.withColumn(
    "Amount_Net_Doc_Currency", f.col("Amount_Net_Doc_Currency").cast("double")
)
df_stack_all = df_stack_all.withColumn(
    "Amount_Gross_Doc_Currency", f.col("Amount_Gross_Doc_Currency").cast("double")
)
df_stack_all = df_stack_all.withColumn(
    "Amount_VAT_Doc_Currency", f.col("Amount_VAT_Doc_Currency").cast("double")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Managment of Currency Rates - Spot

# COMMAND ----------

latest_currency_date = df_currency.agg(
    f.max("Validity_Date_DateFormat").alias("Latest currency date")
).collect()[0][
    0
]  # <- Take the max date from Gold Currency

df_stack_all = df_stack_all.withColumn(
    "Document_conversion_date",
    f.when((f.col("Payment_Status") == "PAID"), f.col("Clearing_Date"))
    .when((f.col("Payment_Status") == "UNPAID"), f.lit(latest_currency_date))
    .otherwise(f.lit(latest_currency_date)),
)

df_stack_all = convert_currency_spot(
    df_currency,
    df_stack_all,
    target_currency_value="EUR",
    source_currency_column_name="Document_Currency",
    df_base_conversion_date_column_name="Document_conversion_date",
    conversion_output_column_name="Document_exchange_spot_temp",
)

# Management EUR & null
df_stack_all = df_stack_all.withColumn(
    "Exchange_Spot",
    f.when(f.col("Document_Currency") == f.lit("EUR"), 1.0)
    .when(f.col("Document_exchange_spot_temp").isNull(), 1.0)
    .otherwise(f.col("Document_exchange_spot_temp")),
)

# Calcul Value in Currency EUR
df_stack_all = (
    df_stack_all.withColumn(
        "Amount_Net_EUR_TxSpot",
        f.col("Amount_Net_Doc_Currency") * f.col("Exchange_Spot"),
    )
    .withColumn(
        "Amount_Gross_EUR_TxSpot",
        f.col("Amount_Gross_Doc_Currency") * f.col("Exchange_Spot"),
    )
    .withColumn(
        "Amount_VAT_EUR_TxSpot",
        f.col("Amount_VAT_Doc_Currency") * f.col("Exchange_Spot"),
    )
)
df_stack_all = df_stack_all.drop("Exchange_Spot", "Document_exchange_spot_temp")
# Cancel Entry without Company Entity
df_stack_all = df_stack_all.filter(f.col("Company_Entity").isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "finance"
table = "p2p_payables"

save_table(f"{catalog}.{domain}.{table}", df_stack_all, "overwrite", True)
