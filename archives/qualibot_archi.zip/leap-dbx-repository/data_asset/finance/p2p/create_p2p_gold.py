# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose P2P GOLD TABLE
# MAGIC
# MAGIC **Description:**  
# MAGIC The creation of a P2P data asset consolidates supplier invoices, good receipt (with no invoice linked) and purchase orders into a single, unified dataset. This enables:
# MAGIC
# MAGIC  - A comprehensive view of the procure-to-pay process.  
# MAGIC  - Better monitoring of supplier liabilities and outstanding payments.  
# MAGIC  - Improved forecasting and cash flow management.  
# MAGIC  - Enhanced reporting and analytics for finance and procurement teams.
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.p2p_payables_sap`  
# MAGIC   
# MAGIC **Input :**  
# MAGIC - `{PIPELINE_READ_ENV}_silver.supply_chain_ordering.purchase_orders_gr_without_invoices_sap`
# MAGIC - `{PIPELINE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_and_requests_sap_stacked`  
# MAGIC - `{PIPELINE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_sap`  
# MAGIC - `{PIPELINE_READ_ENV}_gold.finance.invoices_supplier_stacked_sap` 
# MAGIC - `{PIPELINE_READ_ENV}_gold.finance.po_deposit_sap_exposed`    
# MAGIC - `{REFERENCE_READ_ENV}_bronze.manual_input.vat_company_supplier`   
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest`    
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame

import time
from pyspark.sql.utils import AnalysisException
from datetime import datetime, timedelta

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Import

# COMMAND ----------

from leap_utils.data_asset import table_utils, payment_term

# Logging imports
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments

# COMMAND ----------

# Get read reference environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get read pipeline environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

log = setup_applevel_logger(log_level=LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - Manual set of VAT for Purchase order 
# MAGIC df_bronze_vat

# COMMAND ----------

# Calcul VAT
df_bronze_vat = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.vat_company_supplier"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - Payment Term (T052)
# MAGIC
# MAGIC Contains payment term configurations and rules used to compute expected due dates.
# MAGIC Joined later to determine expected payment timelines for purchase orders.

# COMMAND ----------

df_t052_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### SILVER - Purchase order with GR without invoices 
# MAGIC df_silver_gr

# COMMAND ----------

df_gold_gr = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.supply_chain_ordering.purchase_orders_gr_without_invoices_sap"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Purchase order & Purchase request stacked  
# MAGIC df_gold_po_pr  

# COMMAND ----------

df_gold_po_pr = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_and_requests_sap_stacked"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Purchase orders  
# MAGIC df_gold_po

# COMMAND ----------

df_gold_po = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_sap"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Invoice  
# MAGIC df_gold_invoice

# COMMAND ----------

df_gold_invoice = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.finance.invoices_supplier_stacked_sap"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Deposit  
# MAGIC df_gold_deposit

# COMMAND ----------

df_gold_deposit = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.finance.po_deposit_sap_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Material master data  
# MAGIC material_plant_exposed

# COMMAND ----------

df_gold_material = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 - Manual VAT 

# COMMAND ----------

df_bronze_vat = df_bronze_vat.toDF(*[c.lower() for c in df_bronze_vat.columns])
df_bronze_vat_prepared = df_bronze_vat.select(
    "company_code", "supplier_country", f.col("coefficient").alias("VAT_rate")
)

df_bronze_vat_prepared = df_bronze_vat_prepared.withColumn(
    "VAT_rate",
    f.regexp_replace(df_bronze_vat_prepared["VAT_rate"], ",", ".").cast("double"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 - Purchase order and Purchase request

# COMMAND ----------

# Calculate ratio between document unit and stock unit
df_gold_po_pr = df_gold_po_pr.withColumn(
    "ratio_unit_stock",
    f.when(
        f.col("document_type") == "PR", 1
    )
    .otherwise(
        f.coalesce(f.col("quantity_ordered_in_stock_unit") / f.col("quantity_ordered"), f.lit(1))
    )
)

# COMMAND ----------

# Keep Only PO in Progress
df_gold_po_pr_prepared = df_gold_po_pr.filter(f.col("document_status") == "Doc_Open")
# Exclusion free PO
df_gold_po_pr_prepared = df_gold_po_pr_prepared.filter(
    f.col("net_order_unit_price_in_EUR_budget") != 0
)
# Exclusion transfer PO inside same company
df_gold_po_pr_prepared = df_gold_po_pr_prepared.filter(
    f.col("intercompany") != "intra-co"
)
# Redefine ID Doc
df_gold_po_pr_prepared = df_gold_po_pr_prepared.withColumn(
    "document_item_ID",
    f.when(
        f.col("document_type") == "PO",
        f.concat(f.lit("PO_"), f.col("document_item_ID")),
    ).otherwise(f.concat(f.lit("PR_"), f.col("document_item_ID"))),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 - Purchase order with GR without invoices

# COMMAND ----------

df_gold_gr = df_gold_gr.select(
    f.col("PO_number").alias("document_number"),
    f.col("PO_item_number").alias("document_item_number"),
    f.col("sum_GR").alias("GR_quantity"),
)
df_gold_gr = df_gold_gr.join(
    df_gold_po_pr_prepared, ["document_number", "document_item_number"], "inner"
)
df_gold_gr = (
    df_gold_gr.withColumn("quantity_remaining", f.col("GR_quantity"))
    .withColumn("document_type", f.lit("GR"))
    .withColumn("document_status_detail", f.lit("PO_Received"))
    .drop("GR_quantity")
)
# Redefine ID Doc
df_gold_gr = df_gold_gr.withColumn(
    "document_item_ID",
    f.concat(
        f.lit("GR_"),
        f.col("document_number"),
        f.lit("-"),
        f.col("document_item_number"),
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 4 - PO deposit  
# MAGIC According with Business rules, we keep only DEPOSIT with Number Purchase Order

# COMMAND ----------

df_gold_deposit_prepared = df_gold_deposit.filter(f.col("invoice_type") == "PO_Deposit")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 5 - Material commodity
# MAGIC Select unique material number and (sub) commodity

# COMMAND ----------

df_gold_material_prepared = (
  df_gold_material.select(
    "material_number",
    "sub_commodity",
    "commodity"
  )
  .dropDuplicates()
  .withColumn(
    "direct_indirect",
    f.lit("DIRECT") # all materials are direct purchase
  )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC # TR 1 - Management PO / PR / GR

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR 1.1 - Union - PO / PR / GR

# COMMAND ----------

df_gold_union = df_gold_po_pr_prepared.unionByName(df_gold_gr)

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR 1.2 - Calculate Remaining Quantity in stock unit

# COMMAND ----------

# Calculate ratio between document unit and stock unit
df_gold_union = df_gold_union.withColumn(
    "quantity_remaining_in_stock_unit",
    f.col("quantity_remaining") * f.col("ratio_unit_stock")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR 1.3 - Calculate Gross Value acccording VAT rate

# COMMAND ----------

df_gold_union_pay = df_gold_union.withColumn("payment_status", f.lit("UNPAID"))

df_gold_union_end = df_gold_union_pay.join(
    df_bronze_vat_prepared, ["company_code", "supplier_country"], "left"
)
df_gold_union_end = df_gold_union_end.withColumn(
    "VAT_rate",
    f.when(f.col("VAT_Rate").isNull() == True, f.lit(1)).otherwise(f.col("VAT_Rate")),
)
df_gold_poprgr_price = df_gold_union_end.withColumn(
    "amount_net_document_currency",
    f.col("quantity_remaining") * f.col("net_order_unit_price_in_document_currency"),
).withColumn(
    "amount_net_EUR_currency",
    f.col("quantity_remaining") * f.col("net_order_unit_price_in_EUR_budget"),
)
# calcul with VAT
df_gold_poprgr_price = (
    df_gold_poprgr_price.withColumn(
        "amount_gross_document_currency",
        f.col("amount_net_document_currency") * f.col("VAT_rate"),
    )
    .withColumn(
        "amount_gross_EUR_currency",
        f.col("amount_net_EUR_currency") * f.col("VAT_rate"),
    )
    .withColumn(
        "amount_VAT_document_currency",
        f.col("amount_gross_document_currency") - f.col("amount_net_document_currency"),
    )
    .withColumn(
        "amount_VAT_EUR_currency",
        f.col("amount_gross_EUR_currency") - f.col("amount_net_EUR_currency"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR 1.4 - Calculate due Date according Payment terms

# COMMAND ----------

# Error Gestion if Payment Term is null
df_gold_poprgr_term = df_gold_poprgr_price.withColumn(
    "payment_term",
    f.coalesce(
        f.col("document_payment_term"), f.col("supplier_payment_term"), f.lit("Z005")
    ),
)

df_gold_poprgr_term = df_gold_poprgr_term.withColumn(
    "supplier_payment_term",
    f.coalesce(
        f.col("supplier_payment_term"), f.col("document_payment_term"), f.lit("Z005")
    ),
).drop("document_payment_term")
# ---------------------------------------------
# Calcul payment due date from Base_Date and the payment term
df_poprgr_end = payment_term.calculate_payment_term_due_date(
    df_gold_poprgr_term,
    df_t052_raw,
    df_gold_poprgr_term["payment_term"],
    df_gold_poprgr_term.delivery_date_expected,
    "payment_term_due_date",
)
#  Calcul supplier payment due date from Doc_Date and Supplier payment term
df_poprgr_end = payment_term.calculate_payment_term_due_date(
    df_poprgr_end,
    df_t052_raw,
    df_poprgr_end["supplier_payment_term"],
    df_poprgr_end.delivery_date_expected,
    "supplier_payment_term_due_date",
)
df_poprgr_end = df_poprgr_end.withColumn(
    "payment_term_due_date",
    f.coalesce(f.col("payment_term_due_date"), f.col("supplier_payment_term_due_date")),
)

df_poprgr_end = df_poprgr_end.withColumn(
    "supplier_payment_term_due_date",
    f.coalesce(f.col("supplier_payment_term_due_date"), f.col("payment_term_due_date")),
)

df_poprgr_end = df_poprgr_end.withColumn(
    "is_gap_payment_term",
    f.when(
        f.col("payment_term") != f.col("supplier_payment_term"), f.lit(True)
    ).otherwise(f.lit(False)),
)
# Calcul_due_date
df_poprgr_end = df_poprgr_end.withColumn(
    "due_date",
    f.coalesce(
        f.col("payment_term_due_date"),
        f.col("supplier_payment_term_due_date"),
        f.col("delivery_date_expected"),
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR 1.5 - Selection of PO/PR/GR columns for stack

# COMMAND ----------

df_gold_poprgr_selected = df_poprgr_end.select(
    "company_code",
    "company_country",
    "company_description",
    "customer_group",
    "contract_enablement",
    "division",
    "region",
    "site",
    "document_type",
    "document_status_detail",
    "document_number",
    "document_item_number",
    "document_currency",
    "intercompany",
    "supplier_code",
    "supplier_country",
    "supplier_name",
    "supplier_category",
    "supplier_city",
    "spend_category",
    f.col("plant_delivered").alias("plant"),
    "profit_center",
    "profit_center_description",
    "purchasing_group_name",
    "purchasing_group",
    "material_group",
    "commodity",
    "sub_commodity",
    "direct_indirect",
    "is_open_type",
    "has_material_indicator",
    "has_purchase_request_indicator",
    "has_contract_indicator",
    "quantity_ordered",
    "quantity_remaining",
    "quantity_remaining_in_stock_unit",
    "material_number",
    f.col("document_item_description").alias("material_description"),
    "delivery_date_expected",
    "supplier_payment_term",
    "payment_term",
    "is_gap_payment_term",
    "payment_term_due_date",
    "supplier_payment_term_due_date",
    "due_date",
    "payment_status",
    "stock_unit_of_measure",
    "net_stock_unit_price_in_EUR_budget",
    "net_stock_unit_price_in_document_currency",
    f.col("net_order_unit_price_in_EUR_budget").alias("net_unit_price_in_EUR_budget"),
    f.col("net_order_unit_price_in_document_currency").alias("net_unit_price_in_document_currency"),
    "amount_net_document_currency",
    "amount_net_EUR_currency",
    "amount_gross_document_currency",
    "amount_gross_EUR_currency",
    "amount_VAT_document_currency",
    "amount_VAT_EUR_currency",
    "document_item_ID",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR 1.6 - Enrichment Stack for match with invoices

# COMMAND ----------

df_stack_pogr = df_gold_poprgr_selected.withColumn(
    "year_due_date", f.year(f.col("due_date"))
).withColumn("datasource", f.lit("SAP"))

# COMMAND ----------

# MAGIC %md
# MAGIC # TR 2 - Management Invoices

# COMMAND ----------

# MAGIC %md
# MAGIC ## TR 2.1 - Add document type & status

# COMMAND ----------

df_gold_invoice = df_gold_invoice.withColumn(
    "document_type", f.lit("Invoice")
).withColumn(
    "document_status_detail",
    f.when(f.col("Payment_Block_Code").isNull(), f.lit("Invoiced")).otherwise(
        f.lit("Invoice-Locked")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## TR 2.2 - Select View On Invoices Table
# MAGIC

# COMMAND ----------

df_gold_invoice_selected = df_gold_invoice.select(
    "base_date",
    "clearing_date",
    "company_code",
    "company_country",
    "company_description",
    "customer_group",
    "datasource",
    "division",
    "document_currency",
    "document_item_number",
    "document_number",
    "document_type",
    "document_status_detail",
    "due_date",
    "is_gap_payment_term",
    "intercompany",
    "invoice_type",
    "material_number",
    "material_description",
    "payment_status",
    "payment_term",
    "payment_term_due_date",
    "plant",
    f.col("PO_item_number").alias("PO_item_number_linked"),
    f.col("PO_number").alias("PO_number_linked"),
    "profit_center",
    "profit_center_description",
    f.col("quantity").alias("quantity_ordered"),
    f.col("quantity").alias("quantity_remaining"),
    "region",
    "site",
    "spend_category",
    "supplier_category",
    "supplier_city",
    "supplier_code",
    "supplier_country",
    "supplier_name",
    "supplier_payment_term",
    "supplier_payment_term_due_date",
    "year_due_date",
    "amount_gross_document_currency",
    "amount_gross_EUR_currency",
    "amount_net_document_currency",
    "amount_net_EUR_currency",
    "amount_VAT_document_currency",
    "amount_VAT_EUR_currency",
    "is_supplier_a_distributor",
    "invoice_supplier_sap_all_ID",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## TR 2.3 - Join with Material to retrieve Commodity

# COMMAND ----------

# Join on material_number to enrich invoices with Material Commodity
df_gold_invoice_enriched = df_gold_invoice_selected.join(
    df_gold_material_prepared,
    on=["material_number"],
    how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## TR 2.4 - Join with PO to retrieve PO information

# COMMAND ----------

# From gold PO where we have all POs whatever the status, recalculate the stock unit ratio and select information to be added to invoices
df_gold_po = (
    df_gold_po
    .withColumn(
        "ratio_unit_stock",
        f.coalesce(f.col("quantity_ordered_in_stock_unit") / f.col("quantity_ordered"), f.lit(1))
    )
    .select(
        f.col("PO_number").alias("PO_number_linked"),
        f.col("PO_item_number").alias("PO_item_number_linked"),
        "ratio_unit_stock",
        "purchasing_group_name",
        "purchasing_group",
        "contract_enablement",
        "material_group",
        f.col("commodity").alias("commodity_po"),
        f.col("sub_commodity").alias("sub_commodity_po"),
        f.col("direct_indirect").alias("direct_indirect_po"),
        "is_open_type",
        "has_material_indicator",
        "has_purchase_request_indicator",
        "has_contract_indicator",
        "stock_unit_of_measure"
    )
)

# COMMAND ----------

# Join on PO_number and PO_item to enrich invoices with PO information
df_gold_invoice_enriched = df_gold_invoice_enriched.join(
    df_gold_po,
    on=["PO_number_linked", "PO_item_number_linked"],
    how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## TR 2.5 - Complete with Commodity from PO if Invoice commodity is null

# COMMAND ----------

# Join on PO_number and PO_item to enrich invoices with PO information
df_gold_invoice_enriched = (
    df_gold_invoice_enriched
    .withColumn(
        "commodity",
        f.coalesce("commodity", "commodity_po")
    )
    .withColumn(
        "sub_commodity",
        f.coalesce("sub_commodity", "sub_commodity_po")
    )
    .withColumn(
        "direct_indirect",
        f.coalesce("direct_indirect", "direct_indirect_po")
    )
    .drop("commodity_po", "sub_commodity_po", "direct_indirect_po")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## TR 2.6 - Recalculate quantity remaining in stock unit and 4 unit prices

# COMMAND ----------

df_gold_invoice_enriched = (
    df_gold_invoice_enriched
    .withColumn(
        "quantity_remaining_in_stock_unit",
        f.col("quantity_remaining") * f.col("ratio_unit_stock")
    )
    .withColumn(
        "net_unit_price_in_document_currency",
        f.col("amount_net_document_currency") / f.col("quantity_remaining")
    )
    .withColumn(
        "net_unit_price_in_EUR_budget",
        f.col("amount_net_EUR_currency") / f.col("quantity_remaining")
    )
    .withColumn(
        "net_stock_unit_price_in_document_currency",
        f.col("amount_net_document_currency") / f.col("quantity_remaining_in_stock_unit")
    )
    .withColumn(
        "net_stock_unit_price_in_EUR_budget",
        f.col("amount_net_EUR_currency") / f.col("quantity_remaining_in_stock_unit")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # TR 3 - Management PO Deposit

# COMMAND ----------

# MAGIC %md
# MAGIC ## TR 3.1 - Add document type & Status

# COMMAND ----------

df_gold_deposit = (
    df_gold_deposit_prepared.withColumn("document_type", f.lit("PO_Deposit"))
    .withColumn(
        "document_status_detail",
        f.when(f.col("payment_block_code").isNull(), f.lit("PO_Deposit")).otherwise(
            f.lit("PO_Deposit-Locked")
        ),
    )
    .withColumn("datasource", f.lit("SAP"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## TR 3.2 - Select View On Desposit Table

# COMMAND ----------

df_gold_deposit_selected = df_gold_deposit.select(
    "base_date",
    "clearing_date",
    "company_code",
    "company_country",
    "company_description",
    "customer_group",
    "datasource",
    "division",
    "document_currency",
    "document_item_number",
    "document_number",
    "document_type",
    "document_status_detail",
    "due_date",
    "is_gap_payment_term",
    "intercompany",
    "invoice_type",
    "material_number",
    "material_description",
    "payment_status",
    "payment_term",
    "payment_term_due_date",
    "plant",
    f.col("PO_item_number").alias("PO_item_number_linked"),
    f.col("PO_number").alias("PO_number_linked"),
    "profit_center",
    "profit_center_description",
    "region",
    "site",
    "spend_category",
    "supplier_category",
    "supplier_city",
    "supplier_code",
    "supplier_country",
    "supplier_name",
    "supplier_payment_term",
    "supplier_payment_term_due_date",
    "year_due_date",
    "amount_gross_document_currency",
    "amount_gross_EUR_currency",
    "amount_net_document_currency",
    "amount_net_EUR_currency",
    "amount_VAT_document_currency",
    "amount_VAT_EUR_currency",
    "is_supplier_a_distributor",
    "PO_deposit_supplier_ID",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## TR 3.3 - Join with Material to retrieve Commodity

# COMMAND ----------

# Join on material_number to enrich invoices with Material Commodity
df_gold_deposit_enriched = df_gold_deposit_selected.join(
    df_gold_material_prepared,
    on=["material_number"],
    how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## TR 3.4 - Join with PO to retrieve PO information

# COMMAND ----------

# Join on PO_number and PO_item to enrich invoices with PO information
df_gold_deposit_enriched = df_gold_deposit_enriched.join(
    df_gold_po,
    on=["PO_number_linked", "PO_item_number_linked"],
    how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## TR 3.5 - Complete with Commodity from PO if Invoice commodity is null

# COMMAND ----------

# Join on PO_number and PO_item to enrich invoices with PO information
df_gold_deposit_enriched = (
    df_gold_deposit_enriched
    .withColumn(
        "commodity",
        f.coalesce("commodity", "commodity_po")
    )
    .withColumn(
        "sub_commodity",
        f.coalesce("sub_commodity", "sub_commodity_po")
    )
    .withColumn(
        "direct_indirect",
        f.coalesce("direct_indirect", "direct_indirect_po")
    )
    .drop("commodity_po", "sub_commodity_po", "direct_indirect_po")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # TR 4 - Stack & Mach PO / GR / INV / PR

# COMMAND ----------

df_stack_all = df_gold_invoice_enriched.unionByName(
    df_stack_pogr, allowMissingColumns=True
).unionByName(df_gold_deposit_enriched, allowMissingColumns=True)

df_stack_all = df_stack_all.withColumnRenamed("due_date", "latest_known_payment_date")

df_stack_all = df_stack_all.drop("ratio_unit_stock")

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

# create primary key
df_stack_end = df_stack_all.withColumn(
    "p2p_sap_ID",
    f.coalesce(
        f.col("invoice_supplier_sap_all_ID"), f.col("document_item_ID"),f.col("PO_deposit_supplier_ID")
    ),
).drop("invoice_supplier_sap_all_ID","document_item_ID","PO_deposit_supplier_ID")


df_to_check = df_stack_end
col_pk = "p2p_sap_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for p2p payable table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="p2p_payables_sap_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "finance"
DESTINATION_TABLE = "p2p_payables_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_stack_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_stack_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_p2p_payables_sap_pk"
TABLE_PK_COLS = "p2p_sap_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
