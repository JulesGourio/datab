# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create the self service table for general ledger from the gold exposed table.
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_selfservice.finance.general_ledger_sap
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - {PIPELINE_READ_ENV}_gold.finance.general_ledger_sap_exposed
# MAGIC   
# MAGIC **Triggered by:**  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f

from leap_utils.data_asset.table_utils import (
    save_table,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Input
# MAGIC - **df_gl_raw** is the gold exposed table

# COMMAND ----------

df_gl_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.finance.general_ledger_sap_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 1 - Filtering on the current year
# MAGIC In order to limit the size of the output table provided for self service, the GL is filtered on the current year. 

# COMMAND ----------

df_gl_filter = df_gl_raw.filter(f.col("Fiscal_year") == f.lit(f.year(f.current_date())))

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 2 - Aggregation

# COMMAND ----------

COL_AGG = [
    "WBS_element",
    "cost_center",
    "controlling_area",
    "plant",
    "company_code",
    "profit_center",
    "account_number",
    "extraction_timestamp_glpca",
    "fiscal_year",
    "currency_key",
    "posting_period",
    "document_type",
    "accounting_document_number",
    "accounting_document_line",
    "trading_partner_id",
    "sender_company_code",
    "sap_enter_date",
    "GL_item_text",
    "document_date",
    "posting_document_date",
    "reference_doc_number",
    "work_order",
    "material_number",
    "PO_number",
    "PO_item_number",
    "sales_order_number",
    "sales_order_item_number",
    "sales_organization",
    "sales_document",
    "billing_document_number",
    "billing_document_item",
    "movement_type",
    "supplier_code",
    "account_group",
    "account_group_description",
    "Business_Unit",
    "PC_Responsible",
    "Aircraft_platform",
    "Accounting_PC_Group",
    "Product_Group",
    "Customer_Group",
    "Aircraft_product",
    "PC_description",
    "company_currency",
    "Company_Entity",
    "CC_Responsible",
    "CC_site",
    "CC_description",
    "cost_center_adjusted",
    "WBS_Code",
    "WBS_Description",
    "WBS_Plant",
    "conso_exchange_rate_from_company_currency_to_eur",
    "budget_exchange_rate_from_company_currency_to_eur",
]

# COMMAND ----------

COL_TO_SUM = [
    "quantity",
    "amount_in_transaction_currency",
    "amount_in_company_currency",
    "amount_in_company_currency_to_EUR_in_conso_rate",
    "amount_in_company_currency_to_EUR_in_budget_rate",
]

# COMMAND ----------

df_gl_agg = df_gl_filter.groupBy(COL_AGG).agg(
    *[f.sum(f.col(x)).alias(x) for x in COL_TO_SUM]
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_selfservice"
domain = "finance"
table = "general_ledger_sap"

save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_gl_agg,
    mode="overwrite",
    overwrite_schema=True,
)
