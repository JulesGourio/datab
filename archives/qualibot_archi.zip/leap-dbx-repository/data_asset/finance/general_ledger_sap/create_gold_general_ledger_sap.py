# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to create a gold table for general ledger. In this notebook, enrichments are made on the company, profit center and plant. The gold exposed table is also created.
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.finance.general_ledger_sap
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.finance.general_ledger_sap_exposed
# MAGIC
# MAGIC **Inputs:**
# MAGIC   - {PIPELINE_READ_ENV}_silver.finance.general_ledger_sap
# MAGIC   - {REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.profit_center_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.cost_center_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.wbs_otp_exposed
# MAGIC
# MAGIC **Used by:**
# MAGIC P&L projects, industrial variances, revenue calculation

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.window import Window
import great_expectations as gx

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.data_asset.amount_correction import (
    create_corrected_amounts,
)

from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - **df_gl_silver_raw** is the silver table if the general ledger for SAP companies
# MAGIC - **df_pc_raw** is the gold exposed table relative to profit center
# MAGIC - **df_company_raw** is the company master data table
# MAGIC - **df_plant_raw** is the company master data table
# MAGIC - **df_cc_raw** is the cost center gold exposed table
# MAGIC - **df_wbs_raw** is the WBS gold exposed table

# COMMAND ----------

df_gl_silver_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.general_ledger_sap"
)

# COMMAND ----------

df_pc_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed")

# COMMAND ----------

df_company_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)

# COMMAND ----------

df_plant_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)

# COMMAND ----------

df_cc_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.cost_center_exposed")

# COMMAND ----------

df_wbs_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.wbs_otp_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Profit center table

# COMMAND ----------

dict_to_rename_pc_columns = {
    "Branch": "PC_branch",
    "Short_Description": "PC_description",
    "Long_Description": "PC_long_description",
    "Profit_Center_short": "profit_center",
    "Start_Validity_Date": "PC_start_validity_date",
    "End_Validity_Date": "PC_end_validity_date",
    "Is_valid": "is_pc_valid",
    "Match_Code": "PC_match_code",
}

# COMMAND ----------

df_pc_prep = df_pc_raw.drop("Profit_Center").withColumnsRenamed(
    dict_to_rename_pc_columns
)

# COMMAND ----------

df_pc_prep = df_pc_prep.withColumn(
    "profit_center", f.regexp_replace("profit_center", "0000000000", "0")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - Company table
# MAGIC Aim: Having the description associated to a company code and the currency of the company.

# COMMAND ----------

dict_to_rename_company_columns = {
    "Currency": "company_currency",
    "Company": "company_Code",
}

# COMMAND ----------

df_company_prep = df_company_raw.withColumnsRenamed(dict_to_rename_company_columns)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 3 - Plant table
# MAGIC Only the description of the plant is useful here.

# COMMAND ----------

COL_SELECT_PLANT = ["Plant", "Plant_Description"]

# COMMAND ----------

df_plant_prep = df_plant_raw.select(COL_SELECT_PLANT)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 4 - Cost center table
# MAGIC The goal is to enrich with all information relative to cost center as it is a key aggregates for finance projects.

# COMMAND ----------

dict_to_rename_cc_columns = {
    "Site": "CC_site",
    "Branch": "CC_entity",
    "Short_Description": "CC_description",
    "Long_Description": "CC_long_description",
    "Cost_Center_short": "cost_center_adjusted",
    "Is_valid": "is_CC_valid",
    "Is_active": "is_CC_active",
    "Start_Validity_Date": "CC_start_validity_date",
    "End_Validity_Date": "CC_end_validity_date",
}

# COMMAND ----------

df_cc_prep = df_cc_raw.drop("cost_center").withColumnsRenamed(dict_to_rename_cc_columns)

# COMMAND ----------

COL_TO_DROP_CC = [
    "Company_Code",
    "Currency",
    "Profit_Center",
    "Plant",
    "IS_PnL_Level_1",
    "IS_PnL_Level_2",
    "IS_PnL_Level_3",
    "IS_PnL_Level_4",
    "Name4_TBD",
    "Business_Unit",
    "Match_Code",
    "CompanyDesc",
    "CompanyCurrency",
    "Is_currency_valid",
]

# COMMAND ----------

df_cc_prep = df_cc_prep.drop(*COL_TO_DROP_CC)

# COMMAND ----------

# MAGIC %md
# MAGIC The controlling area (PA01 / PA20) must be taken into account while joining the cost center table to the General Ledger. In order to ensure the unicity of (cost_center, controlling_area), we take the last validity date.

# COMMAND ----------

df_cc_prep = df_cc_prep.withColumn(
    "_temp_business_id_cc",
    f.concat_ws("-", f.col("cost_center_adjusted"), f.col("Controlling_Area")),
)

windowSpec = Window.partitionBy("_temp_business_id_cc").orderBy(
    f.desc("CC_end_validity_date")
)

df_cc_prep = df_cc_prep.withColumn(
    "_temp_last_end_validity_date", f.row_number().over(windowSpec)
).filter(f.col("_temp_last_end_validity_date") == 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 5 - WBS table

# COMMAND ----------

COL_TO_DROP_WBS = [
    "Controlling_Area",
    "Profit_Center",
    "WBS_Company_Code",
    "WBS_Currency_Code",
    "CompanyDesc",
    "CompanyCurrency",
    "Is_currency_valid",
    "WBS_Code_Num",
]

# COMMAND ----------

df_wbs_prep = df_wbs_raw.drop(*COL_TO_DROP_WBS)

# COMMAND ----------

df_wbs_prep = df_wbs_prep.withColumnRenamed("WBS_Code_Num_short", "WBS_element")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Data quality checks

# COMMAND ----------

# Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
dfgx_pc = gx.dataset.SparkDFDataset(df_pc_prep, persist=False)
dfgx_cc = gx.dataset.SparkDFDataset(df_cc_prep, persist=False)
dfgx_company = gx.dataset.SparkDFDataset(df_company_prep, persist=False)
dfgx_plant = gx.dataset.SparkDFDataset(df_plant_prep, persist=False)
dfgx_wbs = gx.dataset.SparkDFDataset(df_wbs_prep, persist=False)


# Define the red quality checks here
red_quality_check_results = [
    dfgx_pc.expect_column_values_to_be_unique(column="profit_center"),
    dfgx_cc.expect_column_values_to_be_unique(column="_temp_business_id_cc"),
    dfgx_company.expect_column_values_to_be_unique(column="company_code"),
    dfgx_plant.expect_column_values_to_be_unique(column="Plant"),
    dfgx_wbs.expect_column_values_to_be_unique(column="WBS_element"),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="Quality Checks passed for joined tables - RED",
    error_message="Quality checks failed for joined tables, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="general_ledger_sap_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 1 - Join with profit center

# COMMAND ----------

df_gl_transf = df_gl_silver_raw.join(df_pc_prep, ["profit_center"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 2 - Join with company

# COMMAND ----------

df_gl_transf = df_gl_transf.join(df_company_prep, ["company_code"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 3 - Join with plant

# COMMAND ----------

df_gl_transf = df_gl_transf.join(df_plant_prep, ["plant"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 4 - Join with cost center
# MAGIC **Cost center adjusted** \
# MAGIC For accounts 92*, 93*, 94* and 95* the cost center is the last 6 characters of the account numbers.
# MAGIC Decision made: no join again with cost center table so as to not being confused between the Cost center information relative to the raw cost center, and the ones relative to the adjusted.
# MAGIC
# MAGIC **Join** \
# MAGIC Join on cost_center and controlling_area

# COMMAND ----------

ACCOUNT_STARTS_WITH_931 = f.col("account_number").startswith("931")
ACCOUNT_STARTS_WITH_92_93 = (f.col("account_number").startswith("92")) | (
    f.col("Account_number").startswith("93")
)
ACCOUNT_STARTS_WITH_94_95 = (f.col("account_number").startswith("94")) | (
    f.col("Account_number").startswith("95")
)
EMPTY_COST_CENTER = f.col("cost_center").isNull()

df_gl_transf = df_gl_transf.withColumn(
    "cost_center_adjusted",
    f.when(
        ACCOUNT_STARTS_WITH_931 & EMPTY_COST_CENTER,
        f.concat(f.lit("A"), f.substring(df_gl_transf["Account_number"], -5, 5)),
    )
    .when(
        ACCOUNT_STARTS_WITH_92_93 & EMPTY_COST_CENTER,
        f.substring(df_gl_transf["Account_number"], -6, 6),
    ).when(
        ACCOUNT_STARTS_WITH_94_95 & EMPTY_COST_CENTER,
        f.substring(df_gl_transf["Account_number"], -6, 6),
    )
    .otherwise(f.col("cost_center")),
)

# COMMAND ----------

df_gl_transf = df_gl_transf.join(
    df_cc_prep, ["cost_center_adjusted", "controlling_area"], how="left"
)

# COMMAND ----------

# The cost center adjusted is correct only when the deducted cost center is in the gold cost center table
CC_DOESNOT_EXISTS = f.col("CC_start_validity_date").isNull()

df_gl_transf = df_gl_transf.withColumn(
    "cost_center_adjusted",
    f.when(
        CC_DOESNOT_EXISTS & EMPTY_COST_CENTER,
        f.col("cost_center"),
    ).otherwise(f.col("cost_center_adjusted")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 5 - Join with WBS
# MAGIC WBS = Work Breakdown Structure = OTP

# COMMAND ----------

df_gl_transf = df_gl_transf.join(df_wbs_prep, ["WBS_element"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 6 - SAP amounts correction
# MAGIC Correction of the decimals using the function create_corrected_amounts of the columns amount_in_transaction_currency and amount_in_company_currency.

# COMMAND ----------

df_gl_transf = (
    create_corrected_amounts(
        df_gl_transf, "amount_in_transaction_currency", "currency_key"
    )
    .drop("amount_in_transaction_currency")
    .withColumnRenamed(
        "amount_in_transaction_currency_corrected", "amount_in_transaction_currency"
    )
)
df_gl_transf = (
    create_corrected_amounts(
        df_gl_transf, "amount_in_company_currency", "company_currency"
    )
    .drop("amount_in_company_currency")
    .withColumnRenamed(
        "amount_in_company_currency_corrected", "amount_in_company_currency"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 7 - Currency conversion
# MAGIC Conversion to EUR of the amount in company currency with both consolidation and budget rates.

# COMMAND ----------

df_gl_transf = df_gl_transf.withColumn(
    "_temp_budget_date",
    f.when(
        f.col("posting_document_date") > f.current_date(),
        f.date_sub(f.current_date(), 1),
    ).otherwise(f.col("posting_document_date")),
)

df_gl_transf = df_gl_transf.withColumn(
    "_temp_actual_date",
    f.when(
        f.year(f.col("posting_document_date")) < f.year(f.current_date()),
        f.to_date(
            f.concat(f.year(f.col("posting_document_date")), f.lit("12"), f.lit("31")),
            "yyyyMMdd",
        ),
    ).otherwise(f.last_day(f.add_months(f.current_date(), -1))),
)

# COMMAND ----------

df_gl_transf = table_utils.currency_conversion(
    df=df_gl_transf,
    document_currency_column=df_gl_transf.company_currency,
    rate_types=["Consolidation"],
    rate_dates=[df_gl_transf._temp_actual_date],
    target_currency_value="EUR",
    document_amounts=[df_gl_transf.amount_in_company_currency],
).withColumnsRenamed(
    {
        "company_currency_to_EUR_in_Consolidation_rate_at__temp_actual_date": "conso_exchange_rate_from_company_currency_to_eur",
        "amount_in_company_currency_from_company_currency_to_EUR_in_Consolidation_rate_at__temp_actual_date": "amount_in_company_currency_to_EUR_in_conso_rate",
    }
)

df_gl_transf = table_utils.currency_conversion(
    df=df_gl_transf,
    document_currency_column=df_gl_transf.company_currency,
    rate_types=["Budget"],
    rate_dates=[df_gl_transf._temp_budget_date],
    target_currency_value="EUR",
    document_amounts=[df_gl_transf.amount_in_company_currency],
).withColumnsRenamed(
    {
        "company_currency_to_EUR_in_Budget_rate_at__temp_budget_date": "budget_exchange_rate_from_company_currency_to_eur",
        "amount_in_company_currency_from_company_currency_to_EUR_in_Budget_rate_at__temp_budget_date": "amount_in_company_currency_to_EUR_in_budget_rate",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##GL Gold table

# COMMAND ----------

permanent_columns = [col for col in df_gl_transf.columns if not col.startswith("_temp")]

df_gl_transf = df_gl_transf.select(permanent_columns)

# COMMAND ----------

OUTPUT_PATH_NAME = f"{PIPELINE_WRITE_ENV}_gold.finance.general_ledger_sap"
table_utils.save_table(dest_table=OUTPUT_PATH_NAME, df=df_gl_transf, mode="overwrite")

# COMMAND ----------

# MAGIC %md
# MAGIC ##GL Gold exposed table

# COMMAND ----------

Begin_By = "glpca"
selected_columns = [col for col in df_gl_transf.columns if not col.startswith(Begin_By)]
select_statement = ", ".join(selected_columns)

src_full_tablename = OUTPUT_PATH_NAME
dest_full_tablename = f"{src_full_tablename}_exposed"

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
