# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to transform the new rows of GLPCA and merge into the silver table of the general ledger.
# MAGIC - Cleaning of data format
# MAGIC - Join with dimension table
# MAGIC
# MAGIC **Input table(s):**
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.glpca_latest
# MAGIC   - {PIPELINE_READ_ENV}_bronze.headers_sap.headers_sap_business_glpca_v2
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - {PIPELINE_WRITE_ENV}_silver.finance.general_ledger_sap
# MAGIC
# MAGIC **Triggered by:**
# MAGIC create_gold_general_ledger_sap

# COMMAND ----------

# MAGIC %md
# MAGIC # Tech Debt

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

df_glpca_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.glpca_latest"
)
df_header_glpca_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze.headers_sap.headers_sap_business_glpca_v2"
)

df_account_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.account_groups_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

FLOAT_COL = [
    "amount_in_transaction_currency",
    "amount_in_company_currency",
    "amount_in_profit_center_currency",
    "quantity",
]

# COMMAND ----------

COL_ACCOUNT_SELECT = [
    "Group_Name",
    "Group_Description",
    "Account_number",
    "Account_Description",
]

# COMMAND ----------

DATE_COL = ["sap_enter_date", "posting_document_date", "document_date"]

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - GLPCA column renaming

# COMMAND ----------

df_glpca_prep = table_utils.add_prefix_to_columns(df_glpca_raw, "glpca")

df_glpca_prep = table_utils.rename_columns_with_sap_business_header(
    df_glpca_prep, df_header_glpca_raw
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - GLCPA Cleaning

# COMMAND ----------

# MAGIC %md
# MAGIC ###1- Sign management

# COMMAND ----------

for col_name in FLOAT_COL:
    df_glpca_prep = table_utils.transform_float_column(df_glpca_prep, col_name)

# COMMAND ----------

# MAGIC %md
# MAGIC ###2- Remove leading zeros

# COMMAND ----------

COL_REMOVE_LEADING_ZEROS = [
    "profit_center",
    "account_number",
    "sender_profit_center",
    "material_number",
    "sales_order_number",
    "cost_center",
    "reference_doc_number",
    "trading_partner_id",
    "ID_GL_record_number",
    "accounting_document_number",
    "accounting_document_line",
    "work_order",
    "PO_number",
    "PO_item_number",
    "WBS_element",
    "sales_order_item_number",
    "billing_document_number",
    "billing_document_item",
]

# COMMAND ----------

df_glpca_prep = table_utils.remove_leading_zeros(
    df_glpca_prep, COL_REMOVE_LEADING_ZEROS
)

# COMMAND ----------

df_glpca_prep = df_glpca_prep.replace({"": None}, subset=COL_REMOVE_LEADING_ZEROS)

# COMMAND ----------

df_glpca_prep = df_glpca_prep.na.fill(value="0", subset=["profit_center"])

# COMMAND ----------

# MAGIC %md
# MAGIC ###3- Posting period cleaning

# COMMAND ----------

df_glpca_prep = df_glpca_prep.withColumn(
    "posting_period", f.format_string("%02d", df_glpca_prep.posting_period.cast("int"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 3 - Account number table
# MAGIC - remove leading zeros column account number
# MAGIC - select columns
# MAGIC - renaming columns

# COMMAND ----------

COL_REMOVE_LEADING_ZEROS_ACCOUNT = ["account_number"]

df_account_prep = table_utils.remove_leading_zeros(
    df_account_raw, COL_REMOVE_LEADING_ZEROS_ACCOUNT
)

# COMMAND ----------

df_account_prep = df_account_prep.filter(
    f.col("Hierarchy_Level1") == "HIER-PC"
)  # HIER-PC is the standard hierarchy for accounts

# COMMAND ----------

df_account_prep = df_account_prep.select(COL_ACCOUNT_SELECT)

# COMMAND ----------

dict_to_rename_account_columns = {
    "Group_Name": "account_group",
    "Group_Description": "account_group_description",
}

# COMMAND ----------

df_account_prep = df_account_prep.withColumnsRenamed(dict_to_rename_account_columns)

# COMMAND ----------

# Check unicity of account number
# Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
dfgx = gx.dataset.SparkDFDataset(df_account_prep, persist=False)

# Define the red quality checks here
red_quality_check_results = [
    dfgx.expect_column_values_to_be_unique(column="account_number"),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="Quality Checks passed for account group table - RED",
    error_message="Quality checks failed for account group table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="general_ledger_sap_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 1 - Join with account number

# COMMAND ----------

df_gl_transf = df_glpca_prep.join(df_account_prep, ["account_Number"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 2 - Date casting

# COMMAND ----------

for col_name in DATE_COL:
    df_gl_transf = df_gl_transf.withColumn(
        col_name, f.to_date(f.col(col_name), format="yyyyMMdd")
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

OUTPUT_PATH_NAME = f"{PIPELINE_WRITE_ENV}_silver.finance.general_ledger_sap"
table_utils.save_table(
    dest_table=OUTPUT_PATH_NAME,
    df=df_gl_transf,
    mode="overwrite",
)
