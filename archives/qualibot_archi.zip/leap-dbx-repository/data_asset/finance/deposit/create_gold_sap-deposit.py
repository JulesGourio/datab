# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table & Gold_Exposed for invoices based on silver invoices table. 
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.finance.sap_deposit
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.finance.sap_deposit_exposed
# MAGIC
# MAGIC **Input :**  
# MAGIC   - {PIPELINE_READ_ENV}_silver.finance.deposit_sap
# MAGIC   - {REFERENCE_READ_ENV}_gold.master_data.supplier_master_data_latest_exposed
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> Create_silver_sap-invoices
# MAGIC
# MAGIC **Things to do:** 
# MAGIC
# MAGIC - Cleansing data
# MAGIC - Add Supplier Master data
# MAGIC - Determination of Invoice Status                                                      
# MAGIC - Calcul Amount_Net_Doc_Currency
# MAGIC - Calcul payment date Base_Date
# MAGIC

# COMMAND ----------

# MAGIC %md 
# MAGIC # Process

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from leap_utils.data_asset import payment_term,table_utils

dbutils.widgets.removeAll()
# Get read reference environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get read pipeline environment variable
dbutils.widgets.text("pipeline_read_env", "prod")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table from Invoice & Supplier Master Data

# COMMAND ----------

df_deposit = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.deposit_sap"
)  # <- Upload Deposit silver
df_supplier_master_data = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed"
)  # <- Upload Supplier Master Data
df_t052 = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Add Supplier Master Data

# COMMAND ----------

df_supplier_master_data = (
    df_supplier_master_data.withColumnRenamed("Payment_Term", "Supplier_Payment_Term")
    .withColumnRenamed("Company_Code", "Company_Code_")
    .withColumnRenamed("Supplier_Code", "Supplier_Code_")
)
df_supplier_master_data = df_supplier_master_data.select(
    "Company_Code_",
    "Supplier_Code_",
    "Supplier_name",
    "Supplier_country",
    "Spend_category",
    "Intercompany_flow",
    "Incoterm_Code",
    "Incoterm_Detail",
    "Supplier_Category",
    "Supplier_Payment_Term",
)

df_join_deposit = (
    df_deposit.alias("A")
    .join(
        df_supplier_master_data.alias("B"),
        (f.col("A.Supplier_Code") == f.col("B.Supplier_Code_"))
        & (f.col("A.Company_Code") == f.col("B.Company_Code_")),
        "left",
    )
    .drop("Company_Code_", "Supplier_Code_")
)
df_deposit = df_join_deposit.withColumnRenamed(
    "BSXK_ebeln", "PO_Number"
).withColumnRenamed("BSXK_ebelp", "PO_Item_Number")

# COMMAND ----------

# MAGIC %md
# MAGIC #Gold Enrichment

# COMMAND ----------

# -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Error Gestion if Payment Term is null
df_deposit = df_deposit.withColumn(
    "Payment_Term",
    f.when(
        f.col("Payment_Term").isNull() , f.col("Supplier_Payment_Term")
    ).otherwise(f.col("Payment_Term")),
)
df_deposit = df_deposit.withColumn(
    "Payment_Term",
    f.when(f.col("Payment_Term").isNull() , f.lit("Z005")).otherwise(
        f.col("Payment_Term")
    ),
).withColumn(
    "Supplier_Payment_Term",
    f.when(
        f.col("Supplier_Payment_Term").isNull() , f.col("Payment_Term")
    ).otherwise(f.col("Supplier_Payment_Term")),
)
# -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Determination of Invoice Status & Calcul  Amount_Net_Doc_Currency
df_deposit = (
    df_deposit.withColumn(
        "Supplier_Payment_Term",
        f.when(
            f.col("Supplier_Payment_Term").isNull(), f.lit("Z005")
        ).otherwise(f.col("Supplier_Payment_Term")),
    )
    .withColumn(
        "Payment_Status",
        f.when(f.col("Clearing_Date").isNotNull(), f.lit("PAID")).otherwise("UNPAID"),
    )
    .withColumn(
        "Amount_Net_Doc_Currency",
        f.col("Amount_Gross_Doc_Currency") - f.col("Amount_VAT_Doc_Currency"),
    )
    .withColumn(
        "Base_Date",
        f.when(f.col("Base_Date").isNull() , f.col("Doc_Date")).otherwise(
            f.col("Base_Date")
        ),
    )
)
# -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# In Case of deposit, we don't take in account payment term
df_deposit_pay = (
    df_deposit.withColumn("Payment_Term_Due_Date", f.col("Base_Date"))
    .withColumn("Supplier_Payment_Term_Due_Date", f.col("Base_Date"))
    .withColumn(
        "Gap_BaseDate_DocDate",
        f.when(f.col("Doc_Date") != f.col("Base_Date"), f.lit("Yes")).otherwise(
            f.lit("No")
        ),
    )
    .withColumn(
        "Gap_Payment_Term",
        f.when(
            f.col("Payment_Term") != f.col("Supplier_Payment_Term"), f.lit("Yes")
        ).otherwise(f.lit("No")),
    )
)
df_deposit_pay = df_deposit_pay.drop("Debit_Credit")
# -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Change sign of value on specific case of Deposit
df_deposit_sign = (
    df_deposit_pay.withColumn(
        "Amount_Gross_Company_Currency",
        -f.col("Amount_Gross_Company_Currency"),
    )
    .withColumn(
        "Amount_Gross_Doc_Currency",
        -f.col("Amount_Gross_Doc_Currency"),
    )
    .withColumn("Amount_VAT_Doc_Currency", -f.col("Amount_VAT_Doc_Currency"))
    .withColumn(
        "Amount_Net_Doc_Currency",
        -f.col("Amount_Net_Doc_Currency"),
    )
)
# -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Categorisation Deposit
df_deposit_sign = df_deposit_sign.withColumn("Cat", f.lit("Deposit")).withColumn(
    "Payment_Status", f.lit("UNPAID")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Creation of dataframe deposit recovery

# COMMAND ----------

# ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
df_deposit_reverse = df_deposit_sign.withColumn(
    "Cat",
    f.when(f.col("PO_Number").isNull(), f.lit("Deposit_to_Control")).otherwise(
        f.lit("PO_Deposit")
    ),
)
df_deposit_reverse = (
    df_deposit_reverse.withColumn(
        "Doc_Number",
        f.when(f.col("Cat") == "PO_Deposit", f.col("PO_Number")).otherwise(
            f.col("Doc_Number")
        ),
    )
    .withColumn(
        "Doc_Item_Number",
        f.when(f.col("Cat") == "PO_Deposit", f.col("PO_Item_Number")).otherwise(
            f.col("Doc_Item_Number")
        ),
    )
    .withColumn(
        "Document_Type",
        f.when(f.col("Cat") == "PO_Deposit", f.lit("")).otherwise(
            f.col("Document_Type")
        ),
    )
)

# Calcul payment Date
df_deposit_reverse_Payment = df_deposit_reverse.drop(
    "Payment_Term_Due_Date", "Supplier_Payment_Term_Due_Date"
)

# Calcul payment date according Base date
df_deposit_reverse_Payment = payment_term.calculate_payment_term_due_date(
    df_deposit_reverse_Payment,
    df_t052,
    df_deposit_reverse_Payment["Payment_Term"],
    df_deposit_reverse_Payment.Base_Date,
    "Payment_Term_Due_Date",
)

# Calcul payment date according Doc Date
df_deposit_reverse_Payment = payment_term.calculate_payment_term_due_date(
    df_deposit_reverse_Payment,
    df_t052,
    df_deposit_reverse_Payment["Supplier_Payment_Term"],
    df_deposit_reverse_Payment.Doc_Date,
    "Supplier_Payment_Term_Due_Date",
)

# ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# If it's sot a Deposit Reverse Category we take Base Date as Payment Term due Date & Supplier_Payment Due Date
f_deposit_reverse_end = df_deposit_reverse_Payment.withColumn(
    "Payment_Term_Due_Date",
    f.when(f.col("Cat") != "PO_Deposit", f.col("Base_Date")).otherwise(
        f.col("Payment_Term_Due_Date")
    ),
).withColumn(
    "Supplier_Payment_Term_Due_Date",
    f.when(f.col("Cat") != "PO_Deposit", f.col("Base_Date")).otherwise(
        f.col("Supplier_Payment_Term_Due_Date")
    ),
)
# ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Change sign of value on specific case of Deposit
df_deposit_reverse_end = (
    f_deposit_reverse_end.withColumn(
        "Amount_Gross_Company_Currency",
        f.lit(-1 * f.col("Amount_Gross_Company_Currency")),
    )
    .withColumn(
        "Amount_Gross_Doc_Currency",
        f.lit(-1 * f.col("Amount_Gross_Doc_Currency")),
    )
    .withColumn("Amount_VAT_Doc_Currency", f.lit(-1 * f.col("Amount_VAT_Doc_Currency")))
    .withColumn(
        "Amount_Net_Doc_Currency",
        f.lit(-1 * f.col("Amount_Net_Doc_Currency")),
    )
)
# ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Union 2 DataFrame for Standard Deposit & Reverse
df_deposit_union = df_deposit_sign.unionByName(df_deposit_reverse_end)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Management Null value

# COMMAND ----------

# Replace all null value by Unknown
columns_to_replace = [
    "Company_Entity",
    "Incoterm_Code",
    "Incoterm_Detail",
    "Supplier_Code",
    "Supplier_name",
    "Spend_category",
    "Supplier_country",
    "Supplier_Category",
]
replacement_value = "Unknown"
replacement_values = {col_name: replacement_value for col_name in columns_to_replace}
df_deposit_union = df_deposit_union.fillna(replacement_values)

# COMMAND ----------

Begin_By = "BSX"
df_end_exposed = df_deposit_union.select(
    [col for col in df_deposit_union.columns if not col.startswith(Begin_By)]
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save the gold view

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "finance"
table = "sap_deposit"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_end_exposed,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold exposed table

# COMMAND ----------

catalog = "gold"
domain = "finance"
table = "sap_deposit"
src_full_tablename = f"{PIPELINE_WRITE_ENV}_{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "BSX"
selected_columns = [col for col in df_end_exposed.columns if not col.startswith(Begin_By)]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
