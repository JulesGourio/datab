# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose GOLD Deposit purchase 
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table & Gold_Exposed for invoices based on silver invoices table. 
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC  - `{PIPELINE_WRITE_ENV}_gold.finance.po_deposit_sap`
# MAGIC  - `{PIPELINE_WRITE_ENV}_gold.finance.po_deposit_sap_exposed`
# MAGIC
# MAGIC **Input :**  
# MAGIC  - `{PIPELINE_READ_ENV}_silver.finance.po_deposit_sap`
# MAGIC  - `{REFERENCE_READ_ENV}_bronze.manual_input.mapping_sites_division_region`
# MAGIC  - `{REFERENCE_READ_ENV}_bronze.manual_input.mapping_plant_site`
# MAGIC  - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest`  
# MAGIC  - `{REFERENCE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_sap_exposed`
# MAGIC  - `{REFERENCE_READ_ENV}_gold.master_data.supplier_exposed`
# MAGIC  - `{REFERENCE_READ_ENV}_gold..material_plant_exposed`
# MAGIC  - `{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed` 
# MAGIC  - `{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed` 
# MAGIC  - `{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed`
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> create_sap-deposit_bronze_to_silver
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

import time
from pyspark.sql.utils import AnalysisException
from datetime import datetime, timedelta

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils, payment_term, business_rules

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - Manual Mapping division site  
# MAGIC **df_bronze_site** Mapping site-division-region  
# MAGIC **df_bronze_site_plant** Mapping site-plant 

# COMMAND ----------

df_bronze_site = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region"
)
df_bronze_site_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_plant_site"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### SILVER - PO DEPOSIT SAP

# COMMAND ----------

df_silver_deposit = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.po_deposit_sap"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Purchase Orders  
# MAGIC **df_gold_purchase**  Extraction Purchase Orders 

# COMMAND ----------

df_gold_purchase = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_sap_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Supplier Master Data  
# MAGIC **df_gold_supplier**  Extraction Master Data Supplier

# COMMAND ----------

df_gold_supplier = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.supplier_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Material by plant
# MAGIC **df_gold_material** Extraction master data material

# COMMAND ----------

df_gold_material = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Profit Center
# MAGIC **df_gold_profitcenter** profit center master data
# MAGIC

# COMMAND ----------

df_gold_profitcenter = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD -  Company Master Data  
# MAGIC **df_gold_company**  Extraction Master Data Company 

# COMMAND ----------

df_gold_company = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Plant Master Data  
# MAGIC **df_gold_plant**  Extraction Master Data Company

# COMMAND ----------

df_gold_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP table

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - Payment Term (T052)
# MAGIC
# MAGIC Contains payment term configurations and rules used to compute expected due dates.
# MAGIC Joined later to determine expected payment timelines for purchase orders. 

# COMMAND ----------

df_t052_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – Purchase Orders

# COMMAND ----------

df_gold_purchase_prepared = df_gold_purchase.select(
    "PO_number",
    "PO_item_number",
    "material_number",
    f.col("plant_delivered").alias("plant"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 – Supplier Master Data
# MAGIC
# MAGIC

# COMMAND ----------

df_gold_supplier_prepared = df_gold_supplier.select(
    "supplier_code",
    "supplier_name",
    "supplier_country",
    "supplier_city",
    "supplier_category",
    "spend_category",
    f.col("payment_term").alias("supplier_payment_term"),
    "company_code",
    "intercompany_flow",
    "is_supplier_a_distributor",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 – Company master data

# COMMAND ----------

df_gold_company = df_gold_company.toDF(*[c.lower() for c in df_gold_company.columns])

df_gold_company_prepared = df_gold_company.select(
    f.col("company").alias("company_code"),
    f.col("country").alias("company_country"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 – Plant master data  
# MAGIC We keep only company with only one plant affected

# COMMAND ----------

df_gold_plant = df_gold_plant.toDF(*[c.lower() for c in df_gold_plant.columns])

df_gold_plant_selected = df_gold_plant.select(
    f.col("plant").alias("plant_master"), f.col("company").alias("company_code")
)
df_gold_plant_temp = (
    df_gold_plant_selected.groupBy("company_code")
    .count()
    .filter("count = 1")
    .drop("count")
)
df_gold_plant_prepared = df_gold_plant_selected.join(
    df_gold_plant_temp, "company_code", "inner"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 4 - Material master data
# MAGIC AS we could have several MRP Unit(not used in invoices) for couple Material/Plant we keep only one entries

# COMMAND ----------

window_spec = Window.partitionBy("material_number", "plant").orderBy("mrp_controller")

df_gold_material_prepared = (
    df_gold_material.withColumn("row_num", f.row_number().over(window_spec))
    .filter(f.col("row_num") == 1)
    .select(
        "material_number",
        "plant",
        "decopling_point",
        "mrp_controller",
        f.col("profit_center").alias("profit_center_material"),
        "material_description",
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 5 - Profit Center

# COMMAND ----------

df_gold_profitcenter = df_gold_profitcenter.toDF(
    *[c.lower() for c in df_gold_profitcenter.columns]
)

df_gold_profitcenter_selected = df_gold_profitcenter.select(
    f.col("profit_center_short").alias("profit_center"),
    f.col("short_description").alias("profit_center_description"),
    f.col("customer_group"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 6 - Select and translate Site mapping

# COMMAND ----------

df_bronze_site = (
    df_bronze_site.select(f.col("site").alias("stock_site"), "division", "region")
    .distinct()
    .withColumn(
        "stock_site", f.translate("stock_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
    )
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 – Add Purchase Orders informations

# COMMAND ----------

df_deposit_po = df_silver_deposit.join(
    df_gold_purchase_prepared, ["PO_number", "PO_item_number"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 – Add plant for invoice without PO number associated
# MAGIC For Invoice FI, we have to determine the plant associated

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 2.1 – Add plant from plant master data 
# MAGIC Only when we have one plant for one company associated

# COMMAND ----------

df_deposit_plant = df_deposit_po.join(df_gold_plant_prepared, ["company_code"], "left")
df_deposit_plant = df_deposit_plant.withColumn(
    "plant", f.coalesce(f.col("plant"), f.col("plant_master"))
).drop("plant_master")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 2.2 – Add plant from supplier master data 

# COMMAND ----------

df_deposit_supplier = df_deposit_plant.join(
    df_gold_supplier_prepared, ["supplier_code", "company_code"], "left"
)

# COMMAND ----------

# This cell assigns a plant code to each row in df_deposit_supplier based on business rules:
# - For suppliers from Mexico or the US, assigns plant 4000 for company LATE and 2300 for company LFR1.
# - For company LATE, assigns plant 1000.
# - For company LTN1, assigns plant 2110.
# - For companies starting with LFR or equal to LDEV, assigns plant 2000.
# - Otherwise, assigns "TBD".
# The final plant code is set to the original plant if present, otherwise to the calculated value.

list_lmx_country = ["MX", "US"]
# Rules for LATE COMPANY
df_deposit_supplier = df_deposit_supplier.withColumn(
    "plant_temp",
    f.when(
        (f.col("supplier_country").isin(list_lmx_country))
        & (f.col("company_code") == "LATE"),
        f.lit("4000"),
    )
    .when(
        (f.col("supplier_country").isin(list_lmx_country))
        & (f.col("company_code") == "LFR1"),
        f.lit("2300"),
    )
    .when(f.col("company_code") == "LATE", f.lit("1000"))
    .when(f.col("company_code") == "LTN1", f.lit("2110"))
    .when(
        (f.col("company_code").startswith("LFR")) | (f.col("company_code") == "LDEV"),
        f.lit("2000"),
    )
    .otherwise(f.lit("TBD")),
)
# ----------------------------------------------------------------------------------
df_deposit_supplier = df_deposit_supplier.withColumn(
    "plant", f.coalesce(f.col("plant"), f.col("plant_temp"))
).drop("plant_temp")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 – Add Company information

# COMMAND ----------

df_deposit_company = df_deposit_supplier.join(
    df_gold_company_prepared, ["company_code"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 4 – Add material information for invoice-MM

# COMMAND ----------

df_deposit_material = df_deposit_company.join(
    df_gold_material_prepared, ["material_number", "plant"], "left"
)
df_deposit_material = df_deposit_material.withColumn(
    "profit_center", f.coalesce(f.col("profit_center"), f.col("profit_center_material"))
).drop("profit_center_material")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 5 – Division / Region / Site Classification  
# MAGIC Target is to determine Stock_site according case here under
# MAGIC  - Case 1 : Determination with 1:1 Site / plant (only one site is linked to a plant)
# MAGIC  - Case 2 : Determination with Decopling point and MRP Controller
# MAGIC  - Case 3 : Determination with profit center affectation 
# MAGIC The finale affectation is done by respectinf the priority of case(1.2.3).  
# MAGIC If nothing is found "LAT - Mach1" is set by default

# COMMAND ----------

# ----------------------------------------------------------------------------------
# We keep only in the mapping plant code when there are associated to a unique site
window_plant = Window.partitionBy("plant_code")
df_bronze_site_plant = (
    df_bronze_site_plant.withColumn("_tmp_count", f.count("*").over(window_plant))
    .filter(f.col("_tmp_count") == 1)
    .drop("_tmp_count")
).withColumnsRenamed({"plant_code": "plant", "site": "_tmp_site_case_1"})
# ----------------------------------------------------------------------------------
df_gold_profitcenter = df_gold_profitcenter.select(
    f.col("profit_center_short").alias("profit_center"),
    f.col("pc_attributed_site").alias("_tmp_site_case_3"),
).filter(f.col("_tmp_site_case_3").startswith("LATE"))

# COMMAND ----------

# Determination of Branch
# -----------------------------------------------------------------
# Determination 1:1 relationship
df_material_w_site = df_deposit_material.join(df_bronze_site_plant, ["plant"], "left")
# Determination DES
df_material_w_site = df_material_w_site.join(
    df_gold_profitcenter, ["profit_center"], "left"
)
# Determination dispatch plant 1000 and 2000

df_material_w_site = df_material_w_site.withColumn(
    "_tmp_site_case_2",
    f.when(
        (f.col("plant") == "1000") & (f.col("decopling_point").startswith("MON")),
        f.lit("LATE - Montredon"),
    )
    .when(
        ((f.col("plant") == "1000") | (f.col("plant") == "2000"))
        & (f.col("mrp_controller").startswith("DE")),
        f.lit("LATE-LFR1 - Labege Systems"),
    )
    .when(
        (f.col("plant") == "1000") & (f.col("decopling_point").startswith("GMT")),
        f.lit("LATE - Gimont"),
    )
    .when(
        (f.col("plant") == "1000") & (f.col("decopling_point").startswith("HUB")),
        f.lit("LATE - Gabardie"),
    )
    .when(
        (f.col("plant") == "1000") & (f.col("_tmp_site_case_3").isNull()),
        f.lit("LATE - Mach1"),
    )
    .when(
        (f.col("plant") == "2000") & (f.col("_tmp_site_case_3").isNull()),
        f.lit("LFR1 - Labège"),
    )
    .otherwise(f.lit(None)),
)

df_material_w_site = df_material_w_site.withColumn(
    "stock_site",
    f.coalesce(
        f.col("_tmp_site_case_1"),
        f.col("_tmp_site_case_2"),
        f.col("_tmp_site_case_3"),
        f.lit("LATE - Mach1"),
    ),
)
df_material_w_site = df_material_w_site.select(
    [col for col in df_material_w_site.columns if not col.startswith("_tmp")]
)
# -----------------------------------------------------------------
# Remove all accents in site so as to join correctly
df_material_w_site = df_material_w_site.withColumn(
    "stock_site", f.translate("stock_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
)

df_material_w_site = df_material_w_site.join(
    df_bronze_site, ["stock_site"], "left"
).drop("decopling_point", "mrp_controller")
df_material_w_site = df_material_w_site.withColumnRenamed("stock_site", "site")

# Quality check: all lines must have a site
if df_material_w_site.where(f.col("site").isNull()).count() > 0:
    raise Exception("At least 1 row with blank site")
# -----------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 6 – Add Intercompany Flow

# COMMAND ----------

df_deposit_interco = business_rules.add_intercompany_column(
    df_material_w_site, "company_code", "intercompany_flow"
).drop("intercompany_flow")
# Specific case of LATFI
df_deposit_interco = df_deposit_interco.withColumn(
    "intercompany",
    f.when(f.col("supplier_code") == "F08875", f.lit("Inter-co")).otherwise(
        f.col("intercompany")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 7 – Add Profit Center information

# COMMAND ----------

df_deposit_pf = df_deposit_interco.join(df_gold_profitcenter_selected, ["profit_center"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 8 – Add Due date to deposit invoices

# COMMAND ----------

# Error Gestion if Payment Term is null
df_deposit = df_deposit_pf.withColumn(
    "payment_term",
    f.coalesce(f.col("payment_term"), f.col("supplier_payment_term"), f.lit("Z005")),
)

df_deposit = df_deposit.withColumn(
    "supplier_payment_term",
    f.coalesce(f.col("supplier_payment_term"), f.col("payment_term"), f.lit("Z005")),
)
# -------------------------------------------------------------------------------------
# Calcul  Amount_Net_Doc_Currency
df_deposit = df_deposit.withColumn(
    "amount_net_document_currency",
    f.col("amount_gross_document_currency") - f.col("amount_VAT_document_currency"),
)
# -------------------------------------------------------------------------------------
# Management error in base where Base_date is null
df_deposit = df_deposit.withColumn(
    "base_date",
    f.coalesce(f.col("base_date"), f.col("document_date")),
)

# COMMAND ----------

# In Case of deposit, we don't take in account payment term
df_deposit_pay = (
    df_deposit.withColumn("payment_term_due_date", f.col("base_date"))
    .withColumn("supplier_payment_term_due_date", f.col("base_date"))
    .withColumn(
        "is_gap_basedate_docdate",
        f.when(f.col("document_date") != f.col("base_date"), f.lit(True)).otherwise(
            f.lit(False)
        ),
    )
    .withColumn(
        "is_gap_payment_term",
        f.when(
            f.col("payment_term") != f.col("supplier_payment_term"), f.lit(True)
        ).otherwise(f.lit(False)),
    )
).drop("Debit_Credit")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 9 – Adapt quantity on deposit invoices

# COMMAND ----------

# Change sign of value on specific case of Deposit
df_deposit_sign = (
    df_deposit_pay.withColumn(
        "amount_gross_company_currency",
        -f.col("amount_gross_company_currency"),
    )
    .withColumn(
        "amount_gross_document_currency",
        -f.col("amount_gross_document_currency"),
    )
    .withColumn("amount_VAT_document_currency", -f.col("amount_VAT_document_currency"))
    .withColumn(
        "amount_net_document_currency",
        -f.col("amount_net_document_currency"),
    )
)
# ---------------------------------------------------------------------------------
# Categorisation Deposit
df_deposit_sign = df_deposit_sign.withColumn(
    "invoice_type", f.lit("Deposit")
).withColumn("payment_status", f.lit("UNPAID"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 10 – Management of deposit recovery
# MAGIC As we have already paid a deposit to our supplier, it's necessary to calculate when this deposit will be used on future invoice  
# MAGIC That for why we calculate according payment term in case of reverse deposit instead of current date for deposit category

# COMMAND ----------

df_deposit_reverse = df_deposit_sign.withColumn(
    "invoice_type",
    f.when(f.col("PO_Number").isNull(), f.lit("Deposit_to_Control")).otherwise(
        f.lit("PO_Deposit")
    ),
)
df_deposit_reverse = (
    df_deposit_reverse.withColumn(
        "document_number",
        f.when(f.col("invoice_type") == "PO_Deposit", f.col("PO_number")).otherwise(
            f.col("document_number")
        ),
    )
    .withColumn(
        "document_item_number",
        f.when(
            f.col("invoice_type") == "PO_Deposit", f.col("PO_item_number")
        ).otherwise(f.col("document_item_number")),
    )
    .withColumn(
        "document_type",
        f.when(f.col("invoice_type") == "PO_Deposit", f.lit("")).otherwise(
            f.col("document_type")
        ),
    )
).drop("Payment_Term_Due_Date", "Supplier_Payment_Term_Due_Date")


# Calcul payment date according Base date
df_deposit_reverse_payment = payment_term.calculate_payment_term_due_date(
    df_deposit_reverse,
    df_t052_raw,
    df_deposit_reverse["payment_term"],
    df_deposit_reverse.base_date,
    "payment_term_due_date",
)

# Calcul payment date according Doc Date
df_deposit_reverse_payment = payment_term.calculate_payment_term_due_date(
    df_deposit_reverse_payment,
    df_t052_raw,
    df_deposit_reverse_payment["supplier_payment_term"],
    df_deposit_reverse_payment.document_date,
    "supplier_payment_term_due_date",
)

# ------------------------------------------------------------------------
# If it's not a Deposit Reverse Category
# we take Base Date as Payment Term due Date & Supplier_Payment Due Date
f_deposit_reverse_end = df_deposit_reverse_payment.withColumn(
    "payment_term_due_date",
    f.when(f.col("invoice_type") != "PO_Deposit", f.col("base_date")).otherwise(
        f.col("payment_term_due_date")
    ),
).withColumn(
    "supplier_payment_term_due_date",
    f.when(f.col("invoice_type") != "PO_Deposit", f.col("base_date")).otherwise(
        f.col("supplier_payment_term_due_date")
    ),
)
# ---------------------------------------------------------
# Change sign of value on specific case of Deposit
df_deposit_reverse_end = (
    f_deposit_reverse_end.withColumn(
        "amount_gross_company_currency",
        f.lit(-1 * f.col("amount_gross_company_currency")),
    )
    .withColumn(
        "amount_gross_document_currency",
        f.lit(-1 * f.col("amount_gross_document_currency")),
    )
    .withColumn(
        "amount_VAT_document_currency",
        f.lit(-1 * f.col("amount_VAT_document_currency")),
    )
    .withColumn(
        "amount_net_document_currency",
        f.lit(-1 * f.col("amount_net_document_currency")),
    )
)


# COMMAND ----------

# Union 2 DataFrame for Standard Deposit & Reverse
df_deposit_union = df_deposit_sign.unionByName(df_deposit_reverse_end)

# Calcul_due_date
df_deposit_union = df_deposit_union.withColumn(
    "due_date",
    f.when(f.col("payment_status") == "PAID", f.col("clearing_date")).otherwise(
        f.col("payment_term_due_date")
    ),
).withColumn(
    "is_gap_payment_term",
    f.when(
        f.col("payment_term") != f.col("supplier_payment_term"), f.lit(True)
    ).otherwise(f.lit(False)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 11 – Currency Conversion
# MAGIC
# MAGIC This transformation converts key monetary fields from the document currency to a common target currency (EUR), using the appropriate rate type (`Budget`) and the PO document date as the reference for conversion.
# MAGIC
# MAGIC It handles multiple financial fields, including:
# MAGIC - Net and gross total price
# MAGIC - Unit prices
# MAGIC - Stock unit prices
# MAGIC
# MAGIC Ensures consistency across reporting by standardizing currency values.

# COMMAND ----------

# Determination of budget_currency_conversion_date
today_str = datetime.today().strftime("%Y-%m-%d")
today = f.lit(today_str)
two_days_ago = f.lit((datetime.today() - timedelta(days=2)).strftime("%Y-%m-%d"))
df_deposit_date = df_deposit_union.withColumn(
    "spot_currency_conversion_date",
    f.when(f.col("document_date") > today, two_days_ago).otherwise(
        f.col("document_date")
    ),
).withColumn(
    "spot_currency_conversion_date_source",
    f.when(
        f.col("spot_currency_conversion_date") == two_days_ago,
        f.lit("today - 2 days"),
    ).otherwise(f.lit("document_date")),
)

# COMMAND ----------

df_converted_currency = table_utils.currency_conversion(
    df=df_deposit_date,
    document_currency_column=df_deposit_date.document_currency,
    rate_types=["Spot"],
    rate_dates=[df_deposit_date.spot_currency_conversion_date],
    target_currency_value="EUR",
    document_amounts=[
        df_deposit_date.amount_gross_document_currency,
        df_deposit_date.amount_net_document_currency,
        df_deposit_date.amount_VAT_document_currency,
    ],
)
# Renaming Columns Price
df_converted_currency_end = df_converted_currency.withColumnsRenamed(
    {
        "amount_gross_document_currency_from_document_currency_to_EUR_in_Spot_rate_at_spot_currency_conversion_date": "amount_gross_EUR_currency",
        "amount_net_document_currency_from_document_currency_to_EUR_in_Spot_rate_at_spot_currency_conversion_date": "amount_net_EUR_currency",
        "amount_VAT_document_currency_from_document_currency_to_EUR_in_Spot_rate_at_spot_currency_conversion_date": "amount_VAT_EUR_currency",
    }
)

# COMMAND ----------

df_deposit_end = df_converted_currency_end.withColumn(
    "year_due_date", f.year(f.col("due_date"))
).withColumn(
    "posting_year", f.year(f.col("posting_date"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_deposit_end = df_deposit_end.withColumn(
    "PO_deposit_supplier_ID",
    f.concat_ws("_", f.col("PO_deposit_supplier_ID"), f.col("invoice_type")),
)
df_to_check = df_deposit_end
col_pk = "PO_deposit_supplier_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for invoice supplier deposit table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="invoices_supplier_deposit_sap_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "finance"
DESTINATION_TABLE = "po_deposit_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_deposit_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_deposit_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_po_deposit_supplier_pk"
TABLE_PK_COLS = "PO_deposit_supplier_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

dest_full_tablename = f"{DESTINATION_TABLE_FULL_PATH}_exposed"
Begin_By = [
    "BSXK",
    "RSEG",
]

selected_columns = [
    col
    for col in df_deposit_end.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename,
    select_statement,
    replace_view=True,
)

log.info(f"The table view {dest_full_tablename} has been successfully created")
