# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for deposit based on Bronze table BSIK BSAK.
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_silver.finance.deposit_sap
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsak_latest 
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsik_latest  
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.profit_center_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed  
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC Bronze ingestion of sap_latecoere.bsk_latest
# MAGIC
# MAGIC **Things to do:** 
# MAGIC
# MAGIC - Join Master Data Company
# MAGIC - Filter BSIK/BSAK on Supplier Deposit
# MAGIC - Renaming Columns
# MAGIC - Clean data
# MAGIC - Create Silver Table

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils
from leap_utils.data_asset.amount_correction import (
    create_corrected_amounts,
)  # Correction Amount for SAP currency with 3 digits


dbutils.widgets.removeAll()
# Get read reference environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md 
# MAGIC #Functions

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# --------------------------------------------------------------------------------------------------------------

# Rename Columns according with Imput file 'Header Renaming
def rename_sap_column_names(df: DataFrame, df_names: DataFrame) -> DataFrame:
    dfp_names = df_names.toPandas()
    dfp_names["table_field"] = dfp_names["Table_name"] + "_" + dfp_names["Field"]
    for i, r in dfp_names.iterrows():

        df = df.withColumnRenamed(
            r["table_field"], r["Business_name"].replace(" ", "_")
        )
    return df


# --------------------------------------------------------------------------------------------------------------

# Create date format columns when indicated in the headers file
def modificate_format_column(df: DataFrame, df_names: DataFrame) -> DataFrame:
    """
    Create a date column when it is asked in the column name config file
    """
    for col in df.columns:
        if df_names.filter(f.col("Business_name") == col).count() > 0:
            if (
                df_names.filter(f.col("Business_name") == col)
                .select("Format")
                .first()[0]
                == "date"
            ):
                df = df.withColumn(f"{col}", f.to_date(f.col(f"{col}"), "yyyyMMdd"))
            else:
                if (
                    df_names.filter(f.col("Business_name") == col)
                    .select("Format")
                    .first()[0]
                    == "float"
                ):
                    df = df.withColumn(f"{col}", f.col(f"{col}").cast("float"))
    return df


# --------------------------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table fom SAP & Renaming Headers 

# COMMAND ----------

# Stack BSIK / BSAK
df_BSAK_Latest = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsak_latest")
df_BSIK_Latest = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsik_latest")

CommonCols = list(set(df_BSAK_Latest.columns).intersection(df_BSIK_Latest.columns))
df_bsxk = (
    df_BSAK_Latest.select(CommonCols)
    .unionByName(df_BSIK_Latest.select(CommonCols))
    .drop("version_history", "Status", "row_nb", "selectedColumn")
)
df_bsxk = table_utils.add_prefix_to_columns(df_bsxk, "BSXK")  # <- Renaming starting with BSXK_

# Upload Gold Company master data
df_company = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)

# Upload SAP Master Data Profit Center
df_pfc = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC # Add Company Master Data

# COMMAND ----------

df_bsxk = df_bsxk.withColumn(
    "BSXK_BUKRS", f.trim(f.col("BSXK_BUKRS"))
)  # <- Cancel Space in Company name for join

df_join_deposit = (
    df_bsxk.alias("A")
    .join(df_company.alias("B"), (f.col("A.BSXK_BUKRS") == f.col("B.Company")), "left")
    .select(
        f.col("A.*"),
        f.col("B.Currency").alias("Company_Currency"),
        f.col("B.Country").alias("Company_Land"),
        f.col("B.Company_Description"),
        f.col("B.Company_Entity").alias("Company_Entity_"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter for invoices on BSIK / BSAK

# COMMAND ----------

# Keep only Deposit
# BSCHL 29 -> Special G/L debit // BSCHL 39 -> Special G/L credit
df_deposit = (
    df_join_deposit.filter(
        (f.col("BSXK_HKONT").startswith("00409"))
        | f.col("BSXK_HKONT").startswith("0023")
    )
    .filter((f.col("BSXK_BSCHL") != "0040999999"))
    .filter((f.col("BSXK_BSCHL") == "29") | (f.col("BSXK_BSCHL") == "39"))
    .filter(f.col("BSXK_AUGBL").isNull())
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming Headers according Business entries

# COMMAND ----------

df_name_bsxk = spark.read.table("prod_bronze.headers_sap.headers_sap_business_bsxk")
check_schema_of_the_file(df_name_bsxk)  # <- Call function Check Header files
df_name_bsxk = delete_null_rows(df_name_bsxk)  # <- Call Function Delete rows null

# Call Function Rename Columns according header file
df_column_names = rename_sap_column_names(
    df_deposit, df_name_bsxk
)  
# Call Funtion Create Columns on Date format
df_deposit = modificate_format_column(
    df_column_names, df_name_bsxk
)  

# COMMAND ----------

df_deposit_corrected = create_corrected_amounts(
    df_deposit, "Amount_Gross_Document_Currency", "Document_Currency"
)
df_deposit_corrected = create_corrected_amounts(
    df_deposit_corrected, "Amount_VAT_Doc_Currency", "Document_Currency"
)
df_deposit_corrected = create_corrected_amounts(
    df_deposit_corrected, "Amount_Gross_Company_Currency", "Company_Currency"
)
df_deposit_corrected = df_deposit_corrected.drop("Amount_Gross_Company_Currency","Amount_VAT_Doc_Currency","Amount_Gross_Document_Currency")
df_deposit_corrected = df_deposit_corrected.withColumnRenamed("Amount_Gross_Document_Currency_corrected","Amount_Gross_Doc_Currency")
df_deposit_corrected = df_deposit_corrected.withColumnRenamed("Amount_VAT_Doc_Currency_corrected","Amount_VAT_Doc_Currency")
df_deposit_corrected = df_deposit_corrected.withColumnRenamed("Amount_Gross_Company_Currency_corrected","Amount_Gross_Company_Currency")

# COMMAND ----------

# MAGIC %md
# MAGIC # Cleaning Data

# COMMAND ----------

# MAGIC %md
# MAGIC ### Trim + Negative Value

# COMMAND ----------

# Managment of negative value for cancellation document
df_deposit_doc = df_deposit_corrected.withColumn(
    "Amount_Gross_Company_Currency",
    f.when(
        f.col("Debit_Credit") == "S",
        (f.col("Amount_Gross_Company_Currency") * -1).cast("double"),
    ).otherwise(f.col("Amount_Gross_Company_Currency").cast("double")),
).withColumn(
    "Amount_Gross_Doc_Currency",
    f.when(
        f.col("Debit_Credit") == "S",
        (f.col("Amount_Gross_Doc_Currency") * -1).cast("double"),
    ).otherwise(f.col("Amount_Gross_Doc_Currency").cast("double")),
).withColumn(
    "Amount_VAT_Doc_Currency",
    f.when(
        f.col("Debit_Credit") == "S",
        (f.col("Amount_VAT_Doc_Currency") * -1).cast("double"),
    ).otherwise(f.col("Amount_VAT_Doc_Currency").cast("double")),
)
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Cancel space on data
df_deposit_doc = (
    df_deposit_doc.withColumn("Profit_Center", f.trim(f.col("Profit_Center")))
    .withColumn("Document_Currency", f.trim(f.col("Document_Currency")))
    .withColumn("Company_Currency", f.trim(f.col("Company_Currency")))
    .withColumn("Supplier_Code", f.trim(f.col("Supplier_Code")))
)
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Managment Profit Center

# COMMAND ----------

# Managment Profit Center
df_deposit_pf = df_deposit_doc.withColumn(
    "Profit_Center",
    f.when(f.col("Profit_Center") == "", f.lit("Unknown")).otherwise(
        f.col("Profit_Center")
    ),
)
df_branch = (df_pfc.select("Profit_Center", "Branch")).withColumnRenamed(
    "Profit_Center", "Profit_Center_"
)

df_deposit_end = (
    df_deposit_pf.join(
        df_branch, df_deposit_pf.Profit_Center == df_branch.Profit_Center_, how="left"
    )
    .withColumnRenamed("Branch", "Company_Entity")
    .drop("Profit_Center_")
)
# Creation Company_Entity
df_deposit_end = (
    df_deposit_end.withColumn(
        "Company_Entity",
        f.when(f.col("Company_Entity").isNull(), f.lit("Unknown")).otherwise(
            f.col("Company_Entity")
        ),
    )
    .withColumn(
        "Company_Entity",
        f.when(f.col("Company_Entity") == "ND", f.lit("Unknown")).otherwise(
            f.col("Company_Entity")
        ),
    )
    .withColumn(
        "Company_Entity",
        f.when(
            f.col("Company_Entity") == "Unknown", f.col("Company_Entity_")
        ).otherwise(f.col("Company_Entity")),
    )
    .drop("Company_Entity_")
)
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md 
# MAGIC # Create Silver Table

# COMMAND ----------

# Save the Silver Deposit table
catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "finance"
table = "deposit_sap"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_deposit_end,
    mode="overwrite",
    overwrite_schema=True
)
