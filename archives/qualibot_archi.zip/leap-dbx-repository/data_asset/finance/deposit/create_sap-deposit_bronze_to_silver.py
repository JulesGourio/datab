# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for deposit based on Bronze table BSIK BSAK.
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - `{PIPELINE_WRITE_ENV}_silver.finance.po_deposit_sap`
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsak_latest` 
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsik_latest`  
# MAGIC   - `{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed`  
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC Bronze ingestion of sap_latecoere.bsxk_latest
# MAGIC
# MAGIC **Things to do:** 
# MAGIC
# MAGIC - Join Master Data Company
# MAGIC - Filter BSIK/BSAK on Supplier Deposit
# MAGIC - Renaming Columns
# MAGIC - Clean data
# MAGIC - Create Silver Table

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

import time
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils, amount_correction

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# --------------------------------------------------------------------------------------------------------------
# Define language priority for description
def language_priority(df: DataFrame, col_partition: str) -> DataFrame:
    """Assign language priorities: 1- English, 2-French, 3-Others"""
    # First we define language priority. 1- English, 2-French, 3-German

    df = df.withColumn(
        "language_priority",
        f.when(f.col("language") == "E", 1)
        .when(f.col("language") == "F", 2)
        .otherwise(3),
    )

    # Create a window to sort descriptions based on language priority
    w = Window.partitionBy(col_partition).orderBy("language_priority")

    # Assign a row number to each row, based on language priority
    df = df.withColumn("row_num", f.row_number().over(w))

    # For each User, take only the language with highest priority (row_num == 1)
    df = df.filter(f.col("row_num") == 1).drop(
        "row_num", "language_priority", "language"
    )
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### BSIK – Accounting: Secondary Index for Vendors (Open Items)
# MAGIC
# MAGIC It contains the open items for vendors. That is, all vendor invoices, credit memos, debit/credit notes that are not yet fully settled.

# COMMAND ----------

df_bsik_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsik_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BSAK – Accounting: Secondary Index for Vendors (Cleared Items)
# MAGIC
# MAGIC It contains the cleared (settled) entries for vendors. That is, invoices, credit memos, or debit/credit notes that have already been settled or cleared.

# COMMAND ----------

df_bsak_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsak_latest"
)
df_bsxk_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_bsxk"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Company Master Data  
# MAGIC **df_gold_company**  Extraction Master Data Company 

# COMMAND ----------

df_gold_company = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – BSXK
# MAGIC
# MAGIC Applies:
# MAGIC - Union BSIK/BSAK
# MAGIC - Column prefixing
# MAGIC - Business-name-based renaming
# MAGIC - Format casting based on SAP header metadata

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 1.1 – Union BSIK/BSAK + Business renaming

# COMMAND ----------

CommonCols = list(set(df_bsak_raw.columns).intersection(df_bsik_raw.columns))
df_bsxk = (
    df_bsak_raw.select(CommonCols)
    .unionByName(df_bsik_raw.select(CommonCols))
    .drop("version_history", "Status", "row_nb", "selectedColumn")
)

df_bsxk = table_utils.add_prefix_to_columns(df_bsxk, "BSXK")
# Call Function Delete rows null
df_name_bsxk = delete_null_rows(df_bsxk_header)
# Call Function Rename Columns according header file
df_column_bsxk = table_utils.rename_columns_with_sap_business_header(
    df_bsxk, df_name_bsxk
)
# Call Funtion Create Columns on Date format
df_bsxk = table_utils.cast_columns_with_sap_business_headers(
    df_column_bsxk, df_name_bsxk
)
# Specific renaming for deposit
df_bsxk = df_bsxk.withColumnsRenamed(
    {"BSXK_ebeln": "PO_number", "BSXK_ebelp": "PO_item_number"}
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 1.2 – Invoices filtered

# COMMAND ----------

# Keep only Deposit
# BSCHL 29 -> Special G/L debit // BSCHL 39 -> Special G/L credit
df_deposit_filtered = (
    df_bsxk.filter(
        (f.col("BSXK_HKONT").startswith("00409"))
        | f.col("BSXK_HKONT").startswith("0023")
    )
    .filter((f.col("BSXK_BSCHL") != "0040999999"))
    .filter((f.col("BSXK_BSCHL") == "29") | (f.col("BSXK_BSCHL") == "39"))
    .filter(f.col("BSXK_AUGBL").isNull())
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 1.3 – Remove leading zero

# COMMAND ----------

df_deposit_clean = table_utils.remove_leading_zeros(
    df=df_deposit_filtered,
    column_names=[
        "document_number",
        "document_item_number",
        "account_of_balance_sheet",
        "cost_center",
        "profit_center",
        "payment_term",
        "PO_number",
        "PO_item_number",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 1.4 – Adjustement Quantity according debit_credit indicator

# COMMAND ----------

# Management of negative value for cancellation document
columns_to_adjust = [
    "amount_gross_company_currency",
    "amount_VAT_document_currency",
    "amount_gross_document_currency",
]

for col_name in columns_to_adjust:
    df_deposit_clean = df_deposit_clean.withColumn(
        col_name,
        f.when(f.col("debit_credit") == "S", -f.col(col_name)).otherwise(
            f.col(col_name)
        ),
    )
df_deposit_prepared = df_deposit_clean

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 – Company
# MAGIC
# MAGIC - Column selection + renaming

# COMMAND ----------

df_gold_company = df_gold_company.select(
    [f.col(col).alias(col.lower()) for col in df_gold_company.columns]
)
df_gold_company_prepared = df_gold_company.select(
    f.col("company").alias("company_code"),
    "company_description",
    f.col("currency").alias("company_currency"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 – Add Company information

# COMMAND ----------

df_deposit_company = df_deposit_prepared.join(
    df_gold_company_prepared, ["company_code"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 – Management of Wrong SAP decimal for spécific currency (TND, JPY,...)

# COMMAND ----------

df_deposit_corrected = amount_correction.create_corrected_amounts(
    df_deposit_company, "amount_gross_company_currency", "company_currency"
)
df_deposit_corrected = amount_correction.create_corrected_amounts(
    df_deposit_corrected, "amount_gross_document_currency", "document_currency"
)
df_deposit_corrected = amount_correction.create_corrected_amounts(
    df_deposit_corrected, "amount_VAT_document_currency", "document_currency"
)

df_deposit_corrected = df_deposit_corrected.drop(
    "amount_gross_company_currency",
    "amount_gross_document_currency",
    "amount_VAT_document_currency",
)

df_deposit_corrected = df_deposit_corrected.withColumnsRenamed(
    {
        "amount_gross_company_currency_corrected": "amount_gross_company_currency",
        "amount_gross_document_currency_corrected": "amount_gross_document_currency",
        "amount_VAT_document_currency_corrected": "amount_VAT_document_currency",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 – Management synchro BSIK / BSAK  
# MAGIC  On SAP when an invoice is paid, rows are erase from BSIK and create in BSAK  
# MAGIC  As we extract data from SAP to our cloud, we could have some errors  
# MAGIC  So if we found entries in BSIK & BSAK, we keep only entries in BSAK

# COMMAND ----------

# create primary key
df_deposit_end = df_deposit_corrected.withColumn(
    "PO_deposit_supplier_ID",
    f.concat_ws(
        "-",
        f.col("document_number"),
        f.col("posting_year"),
        f.col("document_item_number"),
        f.col("company_code"),
    ),
)

window_spec = Window.partitionBy("PO_deposit_supplier_ID").orderBy(
    f.col("BSXK_table_name").asc()
)

df_deposit_final = (
    df_deposit_end.withColumn("row_num", f.row_number().over(window_spec))
    .filter(f.col("row_num") == 1)
    .drop("row_num")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_to_check = df_deposit_final
col_pk = "PO_deposit_supplier_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for invoice supplier deposit table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="deposit_supplier_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "finance"
DESTINATION_TABLE = "po_deposit_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_deposit_final,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_deposit_final.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "silver_po_deposit_supplier_pk"
TABLE_PK_COLS = "PO_deposit_supplier_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
