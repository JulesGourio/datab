# Databricks notebook source
# MAGIC %md
# MAGIC # SAP FC consolidation balance sheet gold data asset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Description
# MAGIC The aim of this notebook is to create the gold data asset of
# MAGIC the SAP FC consolidation sheet of balance data.
# MAGIC
# MAGIC ## Highlighted complexities
# MAGIC None
# MAGIC
# MAGIC ## Intended pipeline
# MAGIC `SAP FC consolidation balance sheet data asset`
# MAGIC
# MAGIC ## Pipeline input tables
# MAGIC - `{PIPELINE_READ_ENV}_silver.finance.consolidation_balance_sheet_sap_fc`
# MAGIC
# MAGIC ## Reference input tables
# MAGIC None
# MAGIC
# MAGIC ## Pipeline output tables
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.consolidation_balance_sheet_sap_fc`
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.finance.consolidation_balance_sheet_sap_fc_exposed` (view)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Technical debt
# MAGIC In [Inputs - Manual data]:
# MAGIC - The two different mappings we use are manual definition for this specific subject
# MAGIC   but the usage of manual mappings hinder re-usability of mappings.
# MAGIC   We could also ask the business to provide the `is_EBIT` or `is_DnA`
# MAGIC   column information in SAP directly so we don't have to maintain this information
# MAGIC   up to date in the code.

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config imports

# COMMAND ----------

import functools
import io
import operator

import pandas as pd
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.common import logger
from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "SAP FC consolidation gold"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import silver consolidation balance sheet table
# MAGIC
# MAGIC `df_silver_consolidation` is the silver consolidation balance sheet table.

# COMMAND ----------

df_silver_consolidation = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.consolidation_balance_sheet_sap_fc"
)

# COMMAND ----------

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_silver_consolidation.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual data

# COMMAND ----------

# MAGIC %md
# MAGIC ### Define and read the consolidation company mapping
# MAGIC
# MAGIC `df_consolidation_company_mapping` is a one-to-one mapping between a "entity" from the
# MAGIC SAP FC consolidation data and the corresponding company code that we know of in Latécoère's SAP.

# COMMAND ----------

consolidation_company_mapping_data = """entity	company_code
A-BSMEX - BIENES RAICES MEXICO	LMXB
A-LATE-ACF - ACF Composite Fabrication Avcorp	LAC4
A-LATE-AEC - AEC Comteck Avcorp	LAC2
A-LATE-ASI - ASI Avcorp Structures Industri	LAC1
A-LATE-BULG - LATECOERE BULGARIA	LBG1
A-LATE-CORPO - Holding Corporate Avcorp	LAC3
A-LATE-CZKAS - LETOV LV as	LLVA
A-LATE-CZKSR - LATECOERE CZECH REPUBLIC sro	LLVS
A-LATE-DEV - LATECOERE DEVELOPPEMENT	LDEV
A-LATE-DOBRA - LATECOERE DO BRASIL	LDB
A-LATE-FR - LATECOERE France	LATE
A-LATE-INC - LATECOERE inc.	LUS2
A-LATE-LATFI - LATFI1	LFR2
A-LATE-MEX - LATECOERE MEXICO	LMXA
A-LATE-MEXSE - LATECOERE MEXICO SERVICES	LMXY
A-LATE-SDM - SHIMTECH DE MEXICO	LMXC
A-LATE-TAC - TACOMA	LBE1
SI-LATE-IND - LATECOERE INDIA PRIVATE LIMITED	LIN1
SI-LATE-JPN - LATECOERE INTERCONNECTION  SYSTEMS JAPAN KK.	LJP1
SI-LATE-UK - LATECOERE INTERCONNECTION SYSTEMS UK	LUK1
SI-LATE-US - LATECOERE INTERCONNECTION SYSTEMS US, Inc.	LUS1
SI-LTC-CAN - LATELEC CANADA	LCA1
SI-LTC-FR - LATELEC France	LFR1
SI-LTC-GMBH - LATELEC gmbh	LDE1
SI-LTC-MAR - LATSIMA Maroc	LMA1
SI-LTC-MEX - LATELEC MEXICO	LMXI
SI-LTC-MEXSE - LATELEC MEXICO SERVICES	LMXZ
SI-LTC-SEA - SEA LATELEC	LTN1
SI-MADES-ES - MADES	LSP1
"""

# COMMAND ----------

consolidation_company_file = io.StringIO(consolidation_company_mapping_data)
pdf_consolidation_company = pd.read_csv(
    consolidation_company_file,
    header=0,
    names=["entity_code", "company_code"],
    sep="\t",
    dtype="string",
)
df_consolidation_company_mapping = spark.createDataFrame(pdf_consolidation_company)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_consolidation_company_mapping.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Define and read the EBIT and D&A consolidation group mapping
# MAGIC
# MAGIC `df_EBIT_DnA_mapping` is a classification mapping between consolidation group accounts
# MAGIC and an account type flag to know if a certain consolidation group account is part of
# MAGIC the EBIT account types, the D&A account types, etc.
# MAGIC A consolidation group account can be part of multiple consolidation account type,
# MAGIC so this mapping is N-to-one.

# COMMAND ----------

EBIT_DnA_mapping_data = """conso_group_account	type
R60100	EBIT
R60310	EBIT
R60370	EBIT
R603L	EBIT
R60400	EBIT
R60500	EBIT
R60580	EBIT
R60600	EBIT
R60700	EBIT
R61100	EBIT
R61220	EBIT
R61300	EBIT
R61500	EBIT
R61600	EBIT
R61700	EBIT
R61800	EBIT
R62100	EBIT
R62110	EBIT
R62200	EBIT
R62210	EBIT
R62300	EBIT
R62400	EBIT
R62500	EBIT
R62600	EBIT
R62700	EBIT
R62710	EBIT
R62800	EBIT
R62810	EBIT
R63100	EBIT
R63700	EBIT
R63710	EBIT
R63720	EBIT
R63730	EBIT
R63740	EBIT
R63750	EBIT
R63760	EBIT
R64100	EBIT
R64500	EBIT
R64700	EBIT
R64800	EBIT
R64810	EBIT
R64850	EBIT
R650L	EBIT
R65500	EBIT
R65800	EBIT
R658A	EBIT
R65900	EBIT
R66630	EBIT
R670L	EBIT
R67200	EBIT
R67500	EBIT
R67510	EBIT
R67520	EBIT
R67565	EBIT
R67580	EBIT
R67800	EBIT
R67825	EBIT
R678A	EBIT
R68111	D&A
R68111	EBIT
R68112	D&A
R68112	EBIT
R68120	D&A
R68120	EBIT
R68150	EBIT
R68160	EBIT
R68170	EBIT
R68180	EBIT
R68181	EBIT
R68190	EBIT
R68191	EBIT
R68720	D&A
R68720	EBIT
R68750	EBIT
R68760	D&A
R68760	EBIT
R68761	EBIT
R68770	EBIT
R68780	EBIT
R68790	EBIT
R69100	EBIT
R69610	EBIT
R69620	EBIT
R69640	EBIT
R70100	EBIT
R70159	EBIT
R70600	EBIT
R70700	EBIT
R70800	EBIT
R70810	EBIT
R70900	EBIT
R71000	EBIT
R71010	EBIT
R71020	EBIT
R710L	EBIT
R72000	EBIT
R74000	EBIT
R75500	EBIT
R75800	EBIT
R75900	EBIT
R77200	EBIT
R77500	EBIT
R77510	EBIT
R77520	EBIT
R77580	EBIT
R77700	EBIT
R77800	EBIT
R77825	EBIT
R78111	D&A
R78111	EBIT
R78112	D&A
R78112	EBIT
R78150	EBIT
R78160	EBIT
R78170	EBIT
R78180	EBIT
R78181	EBIT
R78190	EBIT
R78191	EBIT
R78720	D&A
R78720	EBIT
R78750	EBIT
R78760	D&A
R78760	EBIT
R78761	EBIT
R78762	EBIT
R78763	EBIT
R78780	EBIT
R79100	EBIT
R79700	EBIT
R80200	EBIT
"""

# COMMAND ----------

EBIT_DnA_file = io.StringIO(EBIT_DnA_mapping_data)
pdf_EBIT_DnA = pd.read_csv(
    EBIT_DnA_file,
    header=0,
    names=["conso_group_account", "type"],
    sep="\t",
    dtype="string",
)
df_EBIT_DnA_mapping = spark.createDataFrame(pdf_EBIT_DnA)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_EBIT_DnA_mapping.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Transform EBIT and D&A mapping to have a single row per conso group

# COMMAND ----------

df_EBIT_DnA_unique_mapping = (
    df_EBIT_DnA_mapping.groupBy("conso_group_account")
    .pivot("type", ["EBIT", "D&A"])
    .agg(f.lit(True))
    .fillna(False, ["EBIT", "D&A"])
    .withColumnsRenamed({"EBIT": "conso_is_EBIT", "D&A": "conso_is_DnA"})
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_EBIT_DnA_unique_mapping.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Get the fiscal year and the posting period from the `period` column

# COMMAND ----------

df_consolidation = df_silver_consolidation.withColumns(
    {
        "fiscal_year": f.year("period"),
        "posting_period": f.month("period"),
    }
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_consolidation.select("period", "fiscal_year", "posting_period").display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Find consolidation account using the account column

# COMMAND ----------

df_consolidation = df_consolidation.withColumns(
    {
        "conso_group_account": f.regexp_extract(
            f.col("account"),
            pattern="^(.*?) - (.*)$",
            idx=1,
        ),
        "conso_group_description": f.regexp_extract(
            f.col("account"),
            pattern="^(.*?) - (.*)$",
            idx=2,
        ),
    }
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_consolidation.groupBy(
        "account", "conso_group_account", "conso_group_description"
    ).count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Add SAP company (`company_code`) with the manual conso entity to company code

# COMMAND ----------

df_consolidation = (
    df_consolidation.alias("df_consolidation")
    .join(
        df_consolidation_company_mapping.alias("df_company_mapping"),
        on=(
            f.col("df_consolidation.entity_code")
            == f.col("df_company_mapping.entity_code")
        ),
        how="left",
    )
    .drop(f.col("df_company_mapping.entity_code"))
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_consolidation.groupBy("entity_code", "company_code").count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Add revenue flag
# MAGIC
# MAGIC Revenue accounts are consolidation group accounts that starts with `R70`.

# COMMAND ----------

df_consolidation = df_consolidation.withColumn(
    "conso_is_revenue", f.col("conso_group_account").startswith("R70")
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_consolidation.groupBy(
        "conso_group_account", "conso_is_revenue"
    ).count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 5 - Add EBIT/D&A mapping

# COMMAND ----------

df_consolidation = (
    df_consolidation.alias("df_consolidation")
    .join(
        df_EBIT_DnA_unique_mapping.alias("df_EBIT_DnA_mapping"),
        on=(
            f.col("df_consolidation.conso_group_account")
            == f.col("df_EBIT_DnA_mapping.conso_group_account")
        ),
        how="left",
    )
    .drop(f.col("df_EBIT_DnA_mapping.conso_group_account"))
    .fillna(value=False, subset=["conso_is_EBIT", "conso_is_DnA"])
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_consolidation.groupBy(
        "conso_group_account", "conso_is_EBIT", "conso_is_DnA"
    ).count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## QC 1 - Check that all rows have one company, one period and one consolidation account
# MAGIC
# MAGIC That also means we check that all SAP FC entity maps to a company code

# COMMAND ----------

columns_to_check = ["entity_code", "company_code", "period", "conso_group_account"]

column_is_null_names = [f"{name}_is_null" for name in columns_to_check]

df_check_non_null = df_consolidation.select(
    "_meta_filename",
    "fiscal_year",
    *[
        f.col(name).isNull().alias(is_null_name)
        for name, is_null_name in zip(columns_to_check, column_is_null_names)
    ],
).withColumn(
    "all_not_null",
    functools.reduce(
        operator.and_,
        [~f.col(name) for name in column_is_null_names],
        f.lit(True),
    ),
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_check_non_null.groupBy(
        "_meta_filename", "fiscal_year", *column_is_null_names
    ).count().display()

df_check_all_non_null = df_check_non_null.groupBy("all_not_null").count()

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_check_all_non_null.display()

assert all(
    df_check_all_non_null.toPandas()["all_not_null"]
), "Some columns have null values, check logs for details"

# COMMAND ----------

# MAGIC %md
# MAGIC ## QC 2 - Check that `R70100` accounts have positive amounts
# MAGIC
# MAGIC Indeed the idea is to check the sign convention: positive for revenue,
# MAGIC negative for costs.
# MAGIC The `R70100` accounts are supposed to be revenue.

# COMMAND ----------

R70100_amount_sum_per_year = (
    df_consolidation.where(f.col("conso_group_account") == f.lit("R70100"))
    .groupBy("fiscal_year")
    .agg(f.sum("amount_ytd").alias("amount_sum"))
)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    R70100_amount_sum_per_year.display()

R70100_amounts = list(R70100_amount_sum_per_year.toPandas()["amount_sum"])

assert all(map(lambda amount: amount > 0, R70100_amounts)), (
    "The sum of R70100 accounts is not positive for every year."
    " Some data should be corrected and re-ingested."
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Preview gold data asset

# COMMAND ----------

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_consolidation.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output 1 - Save SAP FC consolidation balance sheet **gold table**

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.finance.consolidation_balance_sheet_sap_fc",
    df=df_consolidation,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output 2 - Save SAP FC consolidation balance sheet **gold exposed view**

# COMMAND ----------

log.debug("All columns are: %s", df_consolidation.columns)

exposed_columns = [
    col for col in df_consolidation.columns if not col.startswith("_meta_")
]

log.debug("Exposed columns are: %s", exposed_columns)

# COMMAND ----------

table_utils.create_table_view(
    src_full_tablename=(
        f"{PIPELINE_WRITE_ENV}_gold.finance.consolidation_balance_sheet_sap_fc"
    ),
    dest_full_tablename=(
        f"{PIPELINE_WRITE_ENV}_gold.finance.consolidation_balance_sheet_sap_fc_exposed"
    ),
    select_statement=", ".join(exposed_columns),
    replace_view=True,
)
