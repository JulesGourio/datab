# Databricks notebook source
# MAGIC %md
# MAGIC # SAP FC consolidation balance sheet silver data asset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Description
# MAGIC The aim of this notebook is to create the silver data asset of
# MAGIC the SAP FC consolidation sheet of balance data. It is based on the
# MAGIC SAP FC consolidation stack of files we ingested on leap_depot using
# MAGIC the ViaReport financial tool.
# MAGIC
# MAGIC ## Highlighted complexities
# MAGIC None
# MAGIC
# MAGIC ## Intended pipeline
# MAGIC `SAP FC consolidation balance sheet data asset`
# MAGIC
# MAGIC ## Pipeline input tables
# MAGIC - `{PIPELINE_READ_ENV}_bronze.leap_depot_uc16_pnl_reporting.sap_fc_consolidation_stack`
# MAGIC
# MAGIC ## Reference input tables
# MAGIC None
# MAGIC
# MAGIC ## Pipeline output tables
# MAGIC - `{PIPELINE_WRITE_ENV}_silver.finance.consolidation_balance_sheet_sap_fc`

# COMMAND ----------

# MAGIC %md
# MAGIC ## Technical debt
# MAGIC None identified yet

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config imports

# COMMAND ----------

from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f, Window

from leap_utils.common import logger
from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.dropdown("log_level", "warning", logger.LOGGER_MAPPING.keys())
LOG_LEVEL = dbutils.widgets.get("log_level").upper()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

# TODO refactor leap_utils logger someday,
#  we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "SAP FC consolidation silver"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import bronze consolidation stack table
# MAGIC
# MAGIC `df_SAP_FC_stack` is the bronze SAP FC consolidation stack table ingested through leap_depot.

# COMMAND ----------

df_SAP_FC_stack = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze"
    ".leap_depot_uc16_pnl_reporting"
    ".sap_fc_consolidation_stack"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Rename columns

# COMMAND ----------

SAP_FC_header_renaming = {
    "AC": "account",
    "DP": "period",
    "RU": "entity_code",
    "Amt": "amount_ytd",
}

old_header_names = SAP_FC_header_renaming.keys()
SAP_FC_columns = SAP_FC_header_renaming.values()

df_SAP_FC = df_SAP_FC_stack.withColumnsRenamed(SAP_FC_header_renaming)

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_SAP_FC.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Row cleaning

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2.1 - Cleanup null rows

# COMMAND ----------

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_SAP_FC.where(f.coalesce(*SAP_FC_columns).isNull()).display()

df_SAP_FC = df_SAP_FC.where(f.coalesce(*SAP_FC_columns).isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2.2 - Cleanup left-over headers
# MAGIC
# MAGIC In the SAP FC consolidation files, there are left-over headers lying around in the data,
# MAGIC so we filter the rows that contains the old header names in any of the columns of the
# MAGIC source data.

# COMMAND ----------

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_SAP_FC.where(
        f.coalesce(*SAP_FC_columns).isin([f.lit(val) for val in old_header_names])
    ).display()

df_SAP_FC = df_SAP_FC.where(
    ~f.coalesce(*SAP_FC_columns).isin([f.lit(val) for val in old_header_names])
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2.3 - Fill null amount values to 0

# COMMAND ----------

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_SAP_FC.where(f.col("amount_ytd").isNull()).display()

df_SAP_FC = df_SAP_FC.fillna(subset="amount_ytd", value=0.0)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Parse `period` to date
# MAGIC
# MAGIC The parsed date is not exact but it let's us have a date object to find the year or
# MAGIC the month of the posting.
# MAGIC **Therefore, do not make the hypothesis that all documents are produced on the first day
# MAGIC of the month, this information is actually unknown in this SAP FC ingested data.**

# COMMAND ----------

df_SAP_FC = df_SAP_FC.withColumn("period", f.to_date(f.col("period"), "yyyy.MM"))

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_SAP_FC.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Keep only each year's latest SAP FC file
# MAGIC
# MAGIC We want to keep the latest ingested file per document year of posting, meaning
# MAGIC we only want to keep the latest file for each year of financial data, since there
# MAGIC is only one year of data per file at most.

# COMMAND ----------

rank_per_year_expression = (
    f.rank()
    .over(
        Window.partitionBy(f.year(f.col("period"))).orderBy(
            f.col("_meta_ingestion_timestamp").desc(),
            f.col("_meta_leapdepot_timestamp").desc(),
        )
    )
    .alias("rank")
)

# COMMAND ----------

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_SAP_FC.select(
        "_meta_filename",
        f.year(f.col("period")).alias("year"),
        rank_per_year_expression,
    ).groupBy("year", "rank", "_meta_filename").count().orderBy(
        "year", "rank"
    ).display()

df_SAP_FC_latest_per_year = (
    df_SAP_FC.withColumn("rank", rank_per_year_expression)
    .where(f.col("rank") == f.lit(1))
    .drop("rank")
)

# COMMAND ----------

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_SAP_FC.groupBy(f.year(f.col("period")).alias("year")).agg(
        f.max("_meta_ingestion_timestamp").alias("_meta_ingestion_timestamp"),
        f.max("_meta_leapdepot_timestamp").alias("_meta_leapdepot_timestamp"),
    ).join(
        df_SAP_FC.groupBy(
            "_meta_ingestion_timestamp", "_meta_leapdepot_timestamp", "_meta_filename"
        )
        .count()
        .drop("count"),
        on=["_meta_ingestion_timestamp", "_meta_leapdepot_timestamp"],
        how="left",
    ).select(
        "year",
        "_meta_ingestion_timestamp",
        "_meta_leapdepot_timestamp",
        "_meta_filename",
    ).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Preview silver data asset

# COMMAND ----------

if log.level <= logger.LOGGER_MAPPING["debug"]:
    df_SAP_FC_latest_per_year.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Save SAP FC consolidation balance sheet silver table

# COMMAND ----------

table_utils.save_table(
    dest_table=(
        f"{PIPELINE_WRITE_ENV}_silver.finance.consolidation_balance_sheet_sap_fc"
    ),
    df=df_SAP_FC_latest_per_year,
    mode="overwrite",
    overwrite_schema=True,
)
