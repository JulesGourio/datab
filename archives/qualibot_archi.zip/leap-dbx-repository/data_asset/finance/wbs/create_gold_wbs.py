# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC Data asset to create a gold table (master data) for WBS = OTP. \
# MAGIC WBS = Work Breakdown Structure 
# MAGIC
# MAGIC **Input tables:** 
# MAGIC - {PIPELINE_READ_ENV}_silver.master_data.wbs
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.jest_latest
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.master_data.wbs
# MAGIC - {PIPELINE_WRITE_ENV}_gold.master_data.wbs_exposed
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ##Config Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

from pyspark.sql import functions as f
from pyspark.sql.types import StringType
from pyspark.sql.utils import AnalysisException

import great_expectations as gx
from leap_utils.common.validation import gx_validation
from leap_utils.common import logger

import time

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Config logger

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC #Inputs

# COMMAND ----------

df_silver_raw = spark.read.table(f"{PIPELINE_READ_ENV}_silver.master_data.wbs")

# COMMAND ----------

df_jest_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.jest_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep1 - WBS status
# MAGIC is WBS invoiced or not --> through the status "FACT", which corresponds to the system status I0097.

# COMMAND ----------

df_status_wbs = (
    df_jest_raw.where(f.col("objnr").startswith("PR"))
    .where(f.col('inact').isNull()) #Keep only active status 
    .select("objnr", "stat")
    .where(f.col("stat") == "I0097")
)

# COMMAND ----------

df_status_wbs = df_status_wbs.withColumnsRenamed(
    {"objnr": "WBS_id", "stat": "status_system"}
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep2 - WBS silver table

# COMMAND ----------

df_wbs_prep = df_silver_raw

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Get aircraft rank 

# COMMAND ----------

def extract_last_5_digits(s):
    import re

    if s is None:
        return None

    digits = re.findall(r"\d+", s)
    if not digits:
        return None

    last_digits = digits[-1]

    return last_digits[-5:] if len(last_digits) >= 5 else last_digits


extract_udf = f.udf(extract_last_5_digits, StringType())

df_wbs_transf = df_wbs_prep.withColumn(
    "segment",
    f.when(
        f.col("WBS_Code").rlike(r"^\d+[A-Z]*-\d+-"),
        f.regexp_extract(f.col("WBS_Code"), r"^\d+[A-Z]*-(\d+)-", 1),
    )
    .when(
        # Cas générique : n'importe quel préfixe (RA, RL, SA, …) suivi d’un / puis de chiffres
        f.col("WBS_Code").rlike(r"[A-Z]{2}-[A-Z0-9]+/\d+"),
        f.regexp_extract(f.col("WBS_Code"), r"/(\d+)-", 1),
    )
    .when(
        f.col("WBS_Code").rlike(r"RA-[A-Z]+\d+-BG"),
        f.regexp_extract(f.col("WBS_Code"), r"RA-[A-Z]+(\d+)-BG", 1),
    )
    .when(
        f.col("WBS_Code").rlike(r"RA-([A-Z0-9]+)(-|$)"),
        f.regexp_extract(f.col("WBS_Code"), r"RA-([A-Z0-9]+)(-|$)", 1),
    )
    .otherwise(None),
)

df_wbs_transf = df_wbs_transf.withColumn(
    "aircraft_rank", extract_udf(f.col("segment"))
).drop("segment")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - is_associated_msn

# COMMAND ----------

df_wbs_transf = df_wbs_transf.withColumn(
    "is_associated_msn_production",
    f.when(f.col("aircraft_rank").isNotNull(), f.lit(True)).otherwise(f.lit(False)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr3 - Get WBS status

# COMMAND ----------

df_wbs_transf = (
    df_wbs_transf.join(df_status_wbs, ["WBS_id"], how="left")
    .withColumn(
        "is_wbs_invoiced",
        f.when(f.col("status_system").isNotNull(), f.lit(True)).otherwise(f.lit(False)),
    )
    .drop("status_system")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality check
# MAGIC - Unicity of WBS code in the output dataframe

# COMMAND ----------

dfgx = gx.dataset.SparkDFDataset(df_wbs_transf, persist=True)

red_quality_check_results = [
    dfgx.expect_compound_columns_to_be_unique(column_list=["WBS_code"]),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="Quality Checks opassed for WBS gold table - RED",
    error_message="Quality checks failed for unicity of WBS code in the WBS table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="wbs",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output 

# COMMAND ----------

# MAGIC %md
# MAGIC ##WBS gold table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "master_data"
DESTINATION_TABLE = "wbs"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_wbs_transf,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_wbs_transf.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##WBS exposed table

# COMMAND ----------

dest_full_tablename = f"{DESTINATION_TABLE_FULL_PATH}_exposed"

Begin_By = ["PRPS"]

selected_columns = [
    col
    for col in df_wbs_transf.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename,
    select_statement,
    replace_view=True,
)

log.info(f"The table view {dest_full_tablename} has been successfully created")
