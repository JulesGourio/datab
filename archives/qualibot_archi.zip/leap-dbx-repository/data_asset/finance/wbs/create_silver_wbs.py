# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC Data asset to create a gold table (master data) for WBS = OTP. \
# MAGIC WBS = Work Breakdown Structure 
# MAGIC
# MAGIC **Input tables:** 
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.prps_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_prps
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.master_data.wbs 
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

from pyspark.sql import functions as f
from leap_utils.common import logger

import great_expectations as gx
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Config logger

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC #Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Input tables

# COMMAND ----------

df_prps_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.prps_latest"
)

df_headers_prps_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_prps"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

# MAGIC %md
# MAGIC #Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep1 - PRPS table

# COMMAND ----------

df_prps_prep = table_utils.add_prefix_to_columns(df_prps_raw, "PRPS")

df_prps_prep = table_utils.rename_columns_with_sap_business_header(
    df_prps_prep, df_headers_prps_raw
)
df_prps_prep = table_utils.cast_columns_with_sap_business_headers(
    df_prps_prep, df_headers_prps_raw
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep2 - Basic cleaning  

# COMMAND ----------

df_prps_prep = table_utils.remove_leading_zeros(
    df_prps_prep, ["WBS_element", "WBS_profit_center"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Reshape WBS code 
# MAGIC to fit what the user is used to in SAP  
# MAGIC - if 12 caracters long : XX-XXXXXXXX-XX
# MAGIC - if 14 caracters long : XX-XXXXXXXX-XX-XX

# COMMAND ----------

df_wbs_tr = df_prps_prep.withColumn(
    "WBS_code",
    f.when(
        (f.length("WBS_code") == 12),
        f.concat_ws(
            "-",
            f.substring("WBS_code", 1, 2),
            f.substring("WBS_code", 3, 8),
            f.substring("WBS_code", 11, 2),
        ),
    )
    .when(
        (f.length("WBS_code") == 14),
        f.concat_ws(
            "-",
            f.substring("WBS_code", 1, 2),
            f.substring("WBS_code", 3, 8),
            f.substring("WBS_code", 11, 2),
            f.substring("WBS_code", 13, 2),
        ),
    )
    .otherwise(f.col("WBS_code")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality checks 

# COMMAND ----------

# Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
dfgx = gx.dataset.SparkDFDataset(df_wbs_tr, persist=True)

# Define the red quality checks here
red_quality_check_results = [
    dfgx.expect_compound_columns_to_be_unique(column_list=["WBS_code"]),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="Quality Checks opassed for WBS silver table - RED",
    error_message="Quality checks failed for unicity of WBS code in the WBS table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="wbs",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

OUTPUT_TABLE_WBS = f"{PIPELINE_WRITE_ENV}_silver.master_data.wbs"
table_utils.save_table(dest_table=OUTPUT_TABLE_WBS, df=df_wbs_tr, mode="overwrite")
