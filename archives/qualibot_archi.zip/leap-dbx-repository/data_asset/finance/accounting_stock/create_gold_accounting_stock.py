# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to create a gold table for accounting stock (financial view of stock).
# MAGIC
# MAGIC In this notebook, enrichments are made on the company, profit center and plant. The gold exposed table is also created.
# MAGIC
# MAGIC The whole documentation for the accounting stock could be found here: [Accounting Stock Documentation](http://confluence.lat.corp:8090/display/LEAP/UCYY+-+Accounting+Stock+-+JLP).
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - `{PIPELINE_WRITE_ENV}_gold.finance.accounting_stock`
# MAGIC   - `{PIPELINE_WRITE_ENV}_gold.finance.accounting_stock_exposed`
# MAGIC
# MAGIC **Inputs:**
# MAGIC   - `{PIPELINE_READ_ENV}_silver.finance.accounting_stock`
# MAGIC   - `{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed`
# MAGIC   - `{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed`
# MAGIC   - `{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed`
# MAGIC   - `{REFERENCE_READ_ENV}_gold.finance.wbs_otp_exposed`
# MAGIC
# MAGIC **Used by:**
# MAGIC Accounting Stock project

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.data_asset.amount_correction import (
    create_corrected_amounts,
)

from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - **df_as_silver_raw** is the silver table for accounting stock
# MAGIC - **df_pc_raw** is the gold exposed table relative to profit center
# MAGIC - **df_company_raw** is the company master data table
# MAGIC - **df_plant_raw** is the company master data table
# MAGIC - **df_wbs_raw** is the WBS gold exposed table

# COMMAND ----------

df_as_silver_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.accounting_stock"
)

# COMMAND ----------

df_pc_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed")

# COMMAND ----------

df_company_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)

# COMMAND ----------

df_plant_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)

# COMMAND ----------

df_wbs_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.wbs_otp_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Profit center table

# COMMAND ----------

dict_to_rename_pc_columns = {
    "Branch": "PC_branch",
    "Short_Description": "PC_description",
    "Long_Description": "PC_long_description",
    "Profit_Center_short": "profit_center",
    "Start_Validity_Date": "PC_start_validity_date",
    "End_Validity_Date": "PC_end_validity_date",
    "Is_valid": "is_pc_valid",
    "Match_Code": "PC_match_code",
}

# COMMAND ----------

df_pc_prep = df_pc_raw.drop("Profit_Center").withColumnsRenamed(
    dict_to_rename_pc_columns
)

# COMMAND ----------

df_pc_prep = df_pc_prep.withColumn(
    "profit_center", f.regexp_replace("profit_center", "0000000000", "0")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - Company table
# MAGIC Aim: Having the description associated to a company code and the currency of the company.

# COMMAND ----------

dict_to_rename_company_columns = {
    "Currency": "company_currency",
    "Company": "company_Code",
}

# COMMAND ----------

df_company_prep = df_company_raw.withColumnsRenamed(dict_to_rename_company_columns)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 3 - Plant table
# MAGIC Only the description of the plant is useful here.

# COMMAND ----------

COL_SELECT_PLANT = ["Plant", "Plant_Description"]

# COMMAND ----------

df_plant_prep = df_plant_raw.select(COL_SELECT_PLANT)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 4 - WBS table

# COMMAND ----------

COL_TO_DROP_WBS = [
    "Controlling_Area",
    "Profit_Center",
    "WBS_Company_Code",
    "WBS_Currency_Code",
    "CompanyDesc",
    "CompanyCurrency",
    "Is_currency_valid",
    "WBS_Code_Num",
]

# COMMAND ----------

df_wbs_prep = df_wbs_raw.drop(*COL_TO_DROP_WBS)

# COMMAND ----------

df_wbs_prep = df_wbs_prep.withColumnRenamed("WBS_Code_Num_short", "WBS_element")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Data quality checks

# COMMAND ----------

# Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
dfgx_pc = gx.dataset.SparkDFDataset(df_pc_prep, persist=False)
dfgx_company = gx.dataset.SparkDFDataset(df_company_prep, persist=False)
dfgx_plant = gx.dataset.SparkDFDataset(df_plant_prep, persist=False)
dfgx_wbs = gx.dataset.SparkDFDataset(df_wbs_prep, persist=False)


# Define the red quality checks here
red_quality_check_results = [
    dfgx_pc.expect_column_values_to_be_unique(column="profit_center"),
    dfgx_company.expect_column_values_to_be_unique(column="company_code"),
    dfgx_plant.expect_column_values_to_be_unique(column="Plant"),
    dfgx_wbs.expect_column_values_to_be_unique(column="WBS_element"),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="Quality Checks passed for joined tables - RED",
    error_message="Quality checks failed for joined tables, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="accountig_stock_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 1 - Join with profit center

# COMMAND ----------

df_as_transf = df_as_silver_raw.join(df_pc_prep, ["profit_center"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 2 - Join with company

# COMMAND ----------

df_as_transf = df_as_transf.join(df_company_prep, ["company_code"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 3 - Join with plant

# COMMAND ----------

df_as_transf = df_as_transf.join(df_plant_prep, ["plant"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr 4 - Select relevant columns

# COMMAND ----------

cols_to_remove = ("transaction_currency", "profit_center_currency", "units_of_measure")

columns_to_keep = [
    col
    for col in df_as_transf.columns
    if not (col.endswith(cols_to_remove) or (col.startswith("GLPCT")))
]

df_as_filtered = df_as_transf.select(columns_to_keep)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr 5 - Unpivot accounting Stock
# MAGIC Unpivot the columns related to the stock quantity. Namely those named as amt_XX_in_company_code_currency, where XX is the reference reporting month.
# MAGIC The column amt_RAN_in_company_currency (Rapport A Nouveau, which contains the stock amount at the end of the previous year) is kept.

# COMMAND ----------

# Lista delle colonne da "srotolare"
months = [f"amt_{i:02d}_in_company_code_currency" for i in range(1, 13)]

# Applichiamo l'unpivot
df_as_unpivoted = df_as_filtered.selectExpr("*").unpivot(
    ids=[
        col for col in df_as_filtered.columns if (col not in months)
    ],  # & (col != "amt_RAN_in_company_code_currency")],
    values=months,
    variableColumnName="posting_period_long",
    valueColumnName="amount_in_company_code_currency",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 6 - SAP amounts correction
# MAGIC Correction of the decimals using the function create_corrected_amounts of the columns amount_in_company_code_currency and amount_in_company_currency.

# COMMAND ----------

df_as_transf_corrected = (
    create_corrected_amounts(
        df_as_unpivoted, "amount_in_company_code_currency", "company_currency"
    )
    .drop("amount_in_company_code_currency")
    .withColumnRenamed(
        "amount_in_company_code_currency_corrected", "amount_in_company_code_currency"
    )
)

df_as_transf_corrected = (
    create_corrected_amounts(
        df_as_transf_corrected, "amt_RAN_in_company_code_currency", "company_currency"
    )
    .drop("amt_RAN_in_company_code_currency")
    .withColumnRenamed(
        "amt_RAN_in_company_code_currency_corrected",
        "amount_RAN_in_company_code_currency",
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 7 - Currency conversion
# MAGIC Conversion to EUR of the amount in company currency with both consolidation and budget rates.

# COMMAND ----------

df_as_transf = df_as_transf_corrected.withColumn(
    "posting_period",
    f.regexp_replace(
        f.regexp_replace(f.col("posting_period_long"), "amt_", ""),
        "_in_company_code_currency",
        "",
    ),
).withColumn(
    "posting_document_date",
    f.to_date(
        f.concat(f.col("fiscal_year"), f.col("posting_period"), f.lit("01")), "yyyyMMdd"
    ),
)

df_as_transf = df_as_transf.withColumn(
    "_temp_budget_date",
    f.when(
        f.col("posting_document_date") > f.current_date(),
        f.date_sub(f.current_date(), 1),
    ).otherwise(f.col("posting_document_date")),
)

df_as_transf = df_as_transf.withColumn(
    "_temp_actual_date",
    f.when(
        f.year(f.col("posting_document_date")) < f.year(f.current_date()),
        f.to_date(
            f.concat(f.year(f.col("posting_document_date")), f.lit("12"), f.lit("31")),
            "yyyyMMdd",
        ),
    ).otherwise(f.last_day(f.add_months(f.current_date(), -1))),
)

# COMMAND ----------

df_as_transf = table_utils.currency_conversion(
    df=df_as_transf,
    document_currency_column=df_as_transf.company_currency,
    rate_types=["Consolidation"],
    rate_dates=[df_as_transf._temp_actual_date],
    target_currency_value="EUR",
    document_amounts=[
        df_as_transf.amount_in_company_code_currency,
        df_as_transf.amount_RAN_in_company_code_currency,
    ],
).withColumnsRenamed(
    {
        "company_currency_to_EUR_in_Consolidation_rate_at__temp_actual_date": "conso_exchange_rate_from_company_currency_to_eur",
        "amount_in_company_code_currency_from_company_currency_to_EUR_in_Consolidation_rate_at__temp_actual_date": "amount_in_company_code_currency_to_EUR_in_conso_rate",
        "amount_RAN_in_company_code_currency_from_company_currency_to_EUR_in_Consolidation_rate_at__temp_actual_date": "amount_RAN_in_company_code_currency_to_EUR_in_conso_rate",
    }
)

# COMMAND ----------

df_as_transf = table_utils.currency_conversion(
    df=df_as_transf,
    document_currency_column=df_as_transf.company_currency,
    rate_types=["Budget"],
    rate_dates=[df_as_transf._temp_actual_date],
    target_currency_value="EUR",
    document_amounts=[
        df_as_transf.amount_in_company_code_currency,
        df_as_transf.amount_RAN_in_company_code_currency,
    ],
).withColumnsRenamed(
    {
        "company_currency_to_EUR_in_Budget_rate_at__temp_actual_date": "budget_exchange_rate_from_company_currency_to_eur",
        "amount_in_company_code_currency_from_company_currency_to_EUR_in_Budget_rate_at__temp_actual_date": "amount_in_company_code_currency_to_EUR_in_budget_rate",
        "amount_RAN_in_company_code_currency_from_company_currency_to_EUR_in_Budget_rate_at__temp_actual_date": "amount_RAN_in_company_code_currency_to_EUR_in_budget_rate",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Save the Stock Gold Table

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "finance"
table = "accounting_stock"

src_full_tablename = f"{catalog}.{domain}.{table}"


spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=src_full_tablename,
    df=df_as_transf,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save the Stock Gold Exposed Table

# COMMAND ----------

dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "_temp"
selected_columns = [col for col in df_as_transf.columns if not col.startswith(Begin_By)]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
