# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC ## Description
# MAGIC The aim is to create the silver table for the accounting stock from GLPCT SAP Table.
# MAGIC
# MAGIC The whole documentation for the accounting stock could be found here: [Accounting Stock Documentation](http://confluence.lat.corp:8090/display/LEAP/UCYY+-+Accounting+Stock+-+JLP).
# MAGIC
# MAGIC ## Intended pipeline
# MAGIC ## Pipeline input Tables
# MAGIC - `{PIPELINE_READ_ENV}_bronze.headers_sap.headers_sap_business_glpct`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.glpct_latest`
# MAGIC ## Reference input Tables
# MAGIC - `{REFERENCE_READ_ENV}_proj.profit_and_loss.site_pnl_plant_mapping`
# MAGIC - `{REFERENCE_READ_ENV}_proj.profit_and_loss.site_pnl_division_mapping`
# MAGIC - `{REFERENCE_READ_ENV}_proj.profit_and_loss.site_pnl_company_to_plant_mapping`
# MAGIC - `{PIPELINE_READ_ENV}_gold.finance.account_groups_exposed`
# MAGIC ## Pipeline output Tables
# MAGIC - `{PIPELINE_WRITE_ENV}_silver.finance.accounting_stock`

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
import re

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

df_glpct = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.glpct_latest"
)

df_headers_glpct = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze.headers_sap.headers_sap_business_glpct"
).withColumn("Table_name", f.lit("glpct"))

df_plant_mapping = spark.read.table(
    f"{REFERENCE_READ_ENV}_proj.profit_and_loss.site_pnl_plant_mapping"
)

df_division_mapping = spark.read.table(
    f"{REFERENCE_READ_ENV}_proj.profit_and_loss.site_pnl_division_mapping"
)

df_company_to_plant_mapping = spark.read.table(
    f"{REFERENCE_READ_ENV}_proj.profit_and_loss.site_pnl_company_to_plant_mapping"
)

df_account_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.finance.account_groups_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual Declaration

# COMMAND ----------

pattern = r"^amt_.*_in_.*_currency$"

# COMMAND ----------

COL_REMOVE_LEADING_ZEROS = [
    "profit_center",
    "account_number",
    "sender_profit_center",
    "material_number",
]

# COMMAND ----------

COL_ACCOUNT_SELECT = [
    f.col("Group_Name").alias("account_group"),
    f.col("Group_Description").alias("account_group_description"),
    f.col("Account_number"),
    f.col("Account_Description"),
    f.col("Hierarchy_Level5"),
    f.col("Hierarchy_Level6"),
    f.col("Hierarchy_Level7"),
    f.col("Hierarchy_Level5_Description"),
    f.col("Hierarchy_Level6_Description"),
    f.col("Hierarchy_Level7_Description"),
]

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 1 - GLPCT column renaming

# COMMAND ----------

df_glpct_prep = table_utils.add_prefix_to_columns(df_glpct, "GLPCT")

table_utils.check_schema_of_the_header_file(df_headers_glpct)

df_glpct_renamed = table_utils.rename_columns_with_sap_business_header(
    df_glpct_prep, df_headers_glpct
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 2 - GLCPT Cleaning

# COMMAND ----------

# MAGIC %md
# MAGIC ### 1 - Sign management

# COMMAND ----------

for col_name in [col for col in df_glpct_renamed.columns if re.match(pattern, col)]:
    df_glpct_renamed = table_utils.transform_float_column(df_glpct_renamed, col_name)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2 - Remove leading zeros and fill nulls

# COMMAND ----------

df_glpct_filtered = table_utils.remove_leading_zeros(
    df_glpct_renamed, COL_REMOVE_LEADING_ZEROS
)

df_glpct_filtered = df_glpct_filtered.replace(
    {"": None}, subset=COL_REMOVE_LEADING_ZEROS
)

df_glpct_filtered = df_glpct_filtered.na.fill(value="0", subset=["profit_center"])

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3 - Filter stock accounts
# MAGIC Stock accounts correspond to those starting with "3" or "C3"

# COMMAND ----------

df_accounting_stock = df_glpct_filtered.filter(
    f.col("account_number").startswith("3") | f.col("account_number").startswith("C3")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4 - Fill empty plant
# MAGIC Fill AS empty plant with "1000" and IS empty plant with "2000"

# COMMAND ----------

df_accounting_stock_plant_filled = (
    df_accounting_stock.join(df_company_to_plant_mapping, ["company_code"], "left")
    .withColumn(
        "plant",
        f.when(f.col("plant").isNotNull(), f.col("plant")).otherwise(
            f.col("plant_code")
        ),
    )
    .drop("plant_code")
)

# Assign to company_code = LATE, plant = 1000 and to LFR1, 2000
df_accounting_stock_plant_filled = df_accounting_stock_plant_filled.withColumn(
    "plant",
    f.when(f.col("plant").isNotNull(), f.col("plant")).otherwise(
        f.when(f.col("company_code") == "LATE", f.lit("1000")).otherwise(
            f.when(f.col("company_code") == "LFR1", f.lit("2000"))
        )
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 5 - Assign site

# COMMAND ----------

df_plant_mapping_prep = (
    df_plant_mapping.filter(~f.col("plant_code").isin(["1000", "2000"]))
    .withColumnRenamed("plant_code", "plant")
    .withColumnRenamed("site_attribution", "final_site")
)
df_accounting_stock_site = df_accounting_stock_plant_filled.join(
    df_plant_mapping_prep, "plant", "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 5 - Assign Division

# COMMAND ----------

df_division_mapping_prep = df_division_mapping.withColumnRenamed("site", "final_site")

df_accounting_stock_division = df_accounting_stock_site.join(
    df_division_mapping_prep, ["final_site"], "left"
)

df_accounting_stock_division = df_accounting_stock_division.withColumn(
    "division",
    f.when(f.col("division").isNotNull(), f.col("division")).otherwise(
        f.when(
            (f.col("final_site").isNull()) & (f.col("plant") == "1000"), f.lit("ASEU")
        ).otherwise(
            f.when(
                (f.col("final_site").isNull()) & (f.col("plant") == "2000"), f.lit("IS")
            )
        )
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 3 - Account number table
# MAGIC - remove leading zeros column account number
# MAGIC - select columns
# MAGIC - renaming columns

# COMMAND ----------

COL_REMOVE_LEADING_ZEROS_ACCOUNT = ["account_number"]

df_account_prep = table_utils.remove_leading_zeros(
    df_account_raw, COL_REMOVE_LEADING_ZEROS_ACCOUNT
)

df_account_prep = df_account_prep.select(COL_ACCOUNT_SELECT)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr 1 - Join with account number

# COMMAND ----------

df_as_transf = df_accounting_stock_division.join(
    df_account_prep, ["account_Number"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Save Table

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "finance"
table = "accounting_stock"

src_full_tablename = f"{catalog}.{domain}.{table}"


spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=src_full_tablename,
    df=df_as_transf,
    mode="overwrite",
    overwrite_schema=True,
)
