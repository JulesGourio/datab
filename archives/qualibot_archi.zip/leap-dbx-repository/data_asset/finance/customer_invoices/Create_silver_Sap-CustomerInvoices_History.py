# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Silver Customer invoices (Order to Cash Management)
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to transform a bronze table into a silver table by applying cleaning, filtering, and column renaming operations. The notebook performs the following tasks:
# MAGIC
# MAGIC - Data Loading: Loads the 2 bronze table containing the raw data bsad and bsid
# MAGIC - Table Stacking: Stacks two tables  "bsid" and "bsad" respectively.
# MAGIC - Data Filtering: Filters only the customer invoices from the stacked table -> If BSCHL included in the list => Order to Cash management 
# MAGIC     - If = 01, 02 , 04,11, 12 Then   "Invoice O2C"
# MAGIC     - Or = 05, 06, 16            then   "Partial Payment"
# MAGIC - Date Formatting: Formats the date column to a desired format.
# MAGIC - Column Renaming: Renames specific columns to be exposed
# MAGIC - Handle negative values for debit or credit . If Debit_Credit == H it credit (*-1) -> Amount_Gross_Company_Currency * -1
# MAGIC - Silver Table Creation: Generates a silver table with the cleaned and transformed data.
# MAGIC
# MAGIC
# MAGIC **Intput :**
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsad_stack`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsid_stack`
# MAGIC - `{PIPELINE_READ_ENV}_bronze.headers_sap.headers_sap_business_bsxd`
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - `{PIPELINE_WRITE_ENV}_silver.finance.CustomerInvoices_history`
# MAGIC
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - Update : Daily
# MAGIC   - History : Once (exceptionally more)
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql.window import Window
from leap_utils.data_asset import table_utils
from datetime import datetime, timedelta

dbutils.widgets.removeAll()

# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Get read environment variables
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")


# Get job type environment variable
dbutils.widgets.text("run_job_on_latest", "true")  # history/update
RUN_JOB_ON_LATEST = dbutils.widgets.get("run_job_on_latest").lower() == "true"

# Global variable
TIME_DELTA_ALLOWANCE = f.make_dt_interval(hours=f.lit(8))
TABLE_DEST = f"{PIPELINE_WRITE_ENV}_silver.finance.customerinvoices_history"
MODE = "append" if RUN_JOB_ON_LATEST else "overwrite"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Upload Table fom SAP & Renaming Headers

# COMMAND ----------

# Load bsad bsid filterd on start date
df_BSAD = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsad_stack")
df_BSID = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.bsid_stack")
# Load business header
df_name_bsxd = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_bsxd"
)

# COMMAND ----------

# MAGIC %md 
# MAGIC Stack only when the two tables are extracted otherwise don't stack at all 

# COMMAND ----------

# Retrieve Extraction timestamps (bsid/bsad)
bsid_timestamps = (
    df_BSID.select(f.col("extraction_timestamp").alias("bsid_extraction_timestamp"))
    .distinct()
    .sort("bsid_extraction_timestamp")
)
bsad_timestamps = (
    df_BSAD.select(f.col("extraction_timestamp").alias("bsad_extraction_timestamp"))
    .distinct()
    .sort("bsad_extraction_timestamp")
)
# Join both to drop mmultiple extraction and remove incomplete extractions (only allow a certain interval of 8 hours between two extractions)
bsxd_timestamps = bsid_timestamps.join(
    bsad_timestamps,
    on=(
        bsad_timestamps.bsad_extraction_timestamp
        >= (bsid_timestamps.bsid_extraction_timestamp - TIME_DELTA_ALLOWANCE)
    )
    & (
        bsad_timestamps.bsad_extraction_timestamp
        < (bsid_timestamps.bsid_extraction_timestamp + TIME_DELTA_ALLOWANCE)
    ),
    how="left",
)
bsxd_timestamps = bsxd_timestamps.dropna()
bsxd_timestamps = bsxd_timestamps.withColumn(
    "extraction_date", f.to_date(f.col("bsid_extraction_timestamp"))
)
# Drop dupplicates of date based on first occurence in case
bsxd_timestamps = table_utils.drop_duplicates_by_order(
    bsxd_timestamps, "extraction_date", "bsid_extraction_timestamp"
)

# COMMAND ----------

# filter bsid bsad with incomplete extraction
df_BSID = df_BSID.join(
    bsxd_timestamps.select(
        f.col("bsid_extraction_timestamp").alias("extraction_timestamp"),
        "extraction_date",
    ),
    on="extraction_timestamp",
    how="inner",
)
df_BSAD = df_BSAD.join(
    bsxd_timestamps.select(
        f.col("bsad_extraction_timestamp").alias("extraction_timestamp"),
        "extraction_date",
    ),
    on="extraction_timestamp",
    how="inner",
)

# COMMAND ----------

# Get the stack of bsad and bsid
df_bsxd = df_BSAD.unionByName(df_BSID)

# COMMAND ----------

# Add Prefix BSXD to column coming from BSXD
df_bsxd = table_utils.add_prefix_to_columns(df_bsxd, "BSXD")

# COMMAND ----------

# check job type
if RUN_JOB_ON_LATEST:  # update job
    df_customer_invoices = spark.read.table(TABLE_DEST)
    latest_extraction_date = df_customer_invoices.select(
        f.max("BSXD_extraction_timestamp")
    ).first()[0]
    # filter on unseen data
    df_bsxd = df_bsxd.filter(
        f.col("BSXD_extraction_timestamp") > latest_extraction_date
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Filter for invoices on BSID / BSAD

# COMMAND ----------

df_invoices = df_bsxd.filter(f.col("BSXD_HKONT").startswith("00411"))

# COMMAND ----------

# Keep only Invoices
# HKONT start 411 -> customer account
# Filter Postying Key (BSCHL) ->If BSCHL included in the list ["01", "02", "04", "11", "12", "05", "06", "16"]  => Order to Cash management AND If = 01, 02 , 04,11, 12 Then   "Invoice O2C" else "Partial Payment
df_invoices = df_bsxd.filter(f.col("BSXD_HKONT").startswith("00411")).filter(
    f.col("BSXD_BSCHL").isin(["01", "02", "04", "11", "12", "05", "06", "16"])
)
df_invoices = df_invoices.withColumn(
    "posting_type",
    f.when(
        f.col("BSXD_BSCHL").isin(["01", "02", "04", "11", "12"]), f.lit("Invoice O2C")
    ).otherwise(f.lit("Partial Payment")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Renaming Headers according Business entries

# COMMAND ----------

# Check_schema_of_the_file(df_name_bsxd)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_invoices, df_name_bsxd
)
df_invoice = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_bsxd
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Cleaning Data

# COMMAND ----------

# Add "Amount_Gross_x_Currency" for both document and company
for currency_source in ["Company", "Document"]:
    column_name = f"Amount_Gross_{currency_source}_Currency"
    df_invoice = df_invoice.withColumn(
        column_name,
        f.when(
            f.col("Debit_Credit") == "H",
            (f.col(column_name) * -1).cast("float"),
        ).otherwise(f.col(column_name).cast("float")),
    )
# Trim columns
trimed_cols = ["Company_Code", "Profit_Center", "Document_Currency", "Customer_Code"]
for col in trimed_cols:
    df_invoice = df_invoice.withColumn(col, f.trim(f.col(col)))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Silver Table

# COMMAND ----------

table_utils.save_table(
    dest_table=TABLE_DEST, df=df_invoice, mode=MODE, overwrite_schema=True
)
