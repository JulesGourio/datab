# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Gold Customer invoices (Order to Cash Management)
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to enrich a silver table with additional business information to obtain a gold table. The notebook performs the following tasks:
# MAGIC
# MAGIC   - Data Loading: Loads the silver table containing the transformed and cleaned data.
# MAGIC   - Add Informations From "Company Master Data Manual" table and "Company Master Data SAP" (Company_Description,Company_Currency,Company_Land)
# MAGIC   - Payment Due Date Enrichment: Adds the payment due date (document and customer).
# MAGIC   - Comparison: Compares the payment due date for documents and customers to determine if they are equal or not
# MAGIC   - Customer Information Enrichment: Adds additional customer information, such as name, address, and contact details using customer_master_data
# MAGIC   - Payment Status Calculation: Determines the payment status (paid or unpaid)
# MAGIC   - Profit Center and Intercompany Flow Enrichment: Includes profit center and intercompany flow information in the gold table.
# MAGIC   - Gold Table Creation: Generates a gold table with the enriched data
# MAGIC
# MAGIC
# MAGIC
# MAGIC **Output tables:**
# MAGIC   - {pipeline_write_env}_golf.finance.customerinvoices_history
# MAGIC   - {pipeline_write_env}_gold.finance.CustomerInvoices_latest
# MAGIC
# MAGIC **Input :**
# MAGIC   - {pipeline_read_env}_silver.finance.customerinvoices_history
# MAGIC   - {pipeline_read_env}_gold.finance.customerinvoices_latest
# MAGIC   - {reference_read_env}_gold.master_data.supplier_master_data_latest_exposed
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.t052_stack
# MAGIC   - {reference_read_env}_gold.finance.profit_center_exposed
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.vbfa_stack
# MAGIC
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - Update : Daily
# MAGIC   - History : Once (exceptionally more)
# MAGIC
# MAGIC **Assuumptions:**
# MAGIC List_no_interco = ["", "X000", "000500", "S400", "S200", "001200"] -> intercompany_flow (no)
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Process

# COMMAND ----------

from datetime import date
import pyspark.sql.functions as f
from databricks.sdk.runtime import dbutils
from pyspark.sql import DataFrame, Column
from pyspark.sql.window import Window

from leap_utils.config import spark
from leap_utils.data_asset import amount_correction, table_utils, payment_term

dbutils.widgets.removeAll()
# Get write environment variables
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Get read environment variables
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Get job type environment variable
dbutils.widgets.text("run_job_on_latest", "true")
RUN_JOB_ON_LATEST = dbutils.widgets.get("run_job_on_latest").lower() == "true"

# Global Variables
END_DATE = date(9999, 12, 31)
TABLE_DEST = f"{PIPELINE_WRITE_ENV}_gold.finance.customerinvoices"
MODE = "append" if RUN_JOB_ON_LATEST else "overwrite"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Read Tables

# COMMAND ----------

df_invoice = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.customerinvoices_history"
)  # <- Upload Customer Invoices silver

df_customer_master_data = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.customer_master_data_latest_exposed"
)  # <- Upload Customer Master Data
df_t052 = spark.read.table("prod_bronze.sap_latecoere_ecc6.t052_stack").drop_duplicates(
    ["zterm", "extraction_timestamp", "ingestion_timestamp"]
)
df_profit_center = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)  # <- Upload Master Data Profit Center
# <- Company Master Data  Gold
df_company = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)

df_vbfa = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.vbfa_stack")

if RUN_JOB_ON_LATEST:
    # read the latest invoices
    df_invoice_latest = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.finance.customerinvoices_latest"
    )
    # only keep the the invoices with extraction data > latest_extraction_date (update)
    latest_extraction_timestamp = df_invoice_latest.select(
        f.max("extraction_timestamp")
    ).first()[0]
    df_invoice = df_invoice.filter(
        f.col("BSXD_extraction_timestamp") > latest_extraction_timestamp
    )

# COMMAND ----------

# rename a column
df_invoice = df_invoice.withColumnRenamed("BSXD_ZBD1T", "Add_Days_Invoice")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Delivery Note
# MAGIC Overdues is based on SAP Accounting Database which contains
# MAGIC
# MAGIC Invoices coming from SD module
# MAGIC Invoices coming directly form G/L accounting
# MAGIC Payment from G/L accounting
# MAGIC Other form G/L accounting
# MAGIC => issue : user want to know the delivery note number attached to the invoice => this information is only available in "Invoices coming from SD module"
# MAGIC
# MAGIC => traceability is the following :
# MAGIC
# MAGIC 1) From SAP BSID/BSAD : in the reference BSxD-VBELN = N° of invoice issued from SD module (this field is automatically fill up by SD module and cannot be changed)
# MAGIC 2) From Table VBFA : this table makes the link between Invoice and all document related to the invoice : => in our case Delivery Note
# MAGIC BSxD-VBELN = VBFA-VBELN and VBFA-VBTYP_V = "J" then delivery note = VBFA-VBELV

# COMMAND ----------

df_vbfa = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.vbfa_latest"
)

# Filter on  Document category of preceding SD document values J => Delivery Document
df_vbfa = (
    df_vbfa.filter(f.col("vbtyp_v") == "J")
    .select("vbeln", "vbelv")
    .drop_duplicates()
    .withColumnsRenamed({"vbeln": "Invoice_number_SD", "vbelv": "Delivery_Note"})
)
df_vbfa = df_vbfa.groupby("Invoice_number_SD").agg(
    f.concat_ws(", ", f.collect_set(df_vbfa.Delivery_Note)).alias("Delivery_Note")
)

# Join with invoices
df_invoice = df_invoice.join(df_vbfa, on="Invoice_number_SD", how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Currencies Conversion: Amount Correction 

# COMMAND ----------

df_invoice = (
    df_invoice.alias("A")
    .join(
        df_company.alias("B"), (f.col("A.Company_Code") == f.col("B.Company")), "left"
    )
    .select(
        f.col("A.*"),
        f.col("B.Currency").alias("Company_Currency"),
        f.col("B.Country").alias("Company_Country"),
        f.col("B.Company_Description"),
    )
)
df_invoice = df_invoice.withColumn(
    "Company_Currency", f.trim(f.col("Company_Currency"))
)
## Correct SAP amount errors
for currency_source in ["Company", "Document"]:
    df_invoice = amount_correction.create_corrected_amounts(
        df_invoice,
        f"Amount_Gross_{currency_source}_Currency",
        f"{currency_source}_Currency",
    ).drop(f"Amount_Gross_{currency_source}_Currency")
    df_invoice = df_invoice.withColumnRenamed(
        f"Amount_Gross_{currency_source}_Currency_corrected",
        f"Amount_Gross_{currency_source}_Currency",
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Customer Information Enrichment

# COMMAND ----------

# Filter OC19 and OC29 on customer master data to have a unique Sales Organisation per Company Code
df_customer_master_data = df_customer_master_data.filter(
    (~f.col("Sales_Organization").isin(["OC19", "OC29"]))
    | (f.col("Sales_Organization").isNull())
)

# COMMAND ----------

# Don't join on sales organization since we have a unique sales organisation now
df_invoice = df_invoice.join(
    df_customer_master_data,
    ["Customer_Code", "Company_Code"],
    "left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Versioning

# COMMAND ----------

df_invoice = df_invoice.withColumnRenamed("BSXD_extraction_date", "extraction_date")
df_invoice = df_invoice.withColumn(
    "ingestion_date", f.to_date("BSXD_ingestion_timestamp")
)

# COMMAND ----------

# Add next extraction date
w = Window.orderBy("extraction_timestamp")
df_extraction_next = (
    df_t052.select("extraction_timestamp")
    .drop_duplicates()
    .withColumn(
        "next_extraction_timestamp",
        f.lead(f.col("extraction_timestamp"), 1, END_DATE).over(w),
    )
)
df_t052 = df_t052.join(df_extraction_next, on="extraction_timestamp", how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preprocessing

# COMMAND ----------

# MAGIC %md
# MAGIC - Payment Status Calculation & Payment Due Date Enrichment

# COMMAND ----------

# Determination of Invoice Status -> PAID or UNPAID
df_invoice = df_invoice.withColumn(
    "Payment_Status",
    f.when(f.col("Clearing_Date").isNotNull(), f.lit("PAID")).otherwise("UNPAID"),
)

# Calcul Amount_Net_Doc_Currency
df_invoice = df_invoice.withColumn(
    "Amount_Net_Document_Currency",
    f.col("Amount_Gross_Document_Currency") - f.col("Amount_VAT_Doc_Currency"),
)

# Calcul payment date
df_invoice = df_invoice.withColumn(
    "Base_Date",
    f.when(f.col("Base_Date").isNull(), f.col("Doc_Date")).otherwise(
        f.col("Base_Date")
    ),
)

# COMMAND ----------

# Time delta to match BSXD and df_t052 extractions together
time_delta_allowance = f.make_dt_interval(hours=f.lit(3))

# noinspection PyTypeChecker
payment_term_time_delta_join_condition: Column = (
    df_invoice.BSXD_extraction_timestamp
    >= (df_t052.extraction_timestamp + time_delta_allowance)
) & (
    df_invoice.BSXD_extraction_timestamp
    < (df_t052.next_extraction_timestamp + time_delta_allowance)
)

# Actual payment term due date in SAP
df_invoice = payment_term.get_payment_term_due_date_from_existing_columns(
    df=df_invoice,
    base_date_column=df_invoice["Base_Date"],
    zbd123t_column_names=["Add_Days_Invoice", "BSXD_zbd2t", "BSXD_zbd3t"],
    output_column_name="Payment_Term_Due_Date",
)

# Expected payment term due date using payment term code and reference payment term calculation
df_invoice = payment_term.calculate_payment_term_due_date(
    df=df_invoice,
    df_payment_term=f.broadcast(df_t052),
    df_payment_term_column=df_invoice["Payment_Term"],
    base_date_column=df_invoice["Base_Date"],
    output_column_name="Expected_Payment_Term_Due_Date",
    additional_payment_term_join_condition=payment_term_time_delta_join_condition,
)

# <- Calcul payment date according -> Doc_Date
df_invoice = payment_term.calculate_payment_term_due_date(
    df=df_invoice,
    df_payment_term=f.broadcast(df_t052),
    df_payment_term_column=df_invoice["Customer_Payment_Term"],
    base_date_column=df_invoice["Doc_Date"],
    # TODO refactor to "Expected_Customer_Payment_Term_Due_Date" later on
    output_column_name="Customer_Payment_Term_Due_Date",
    additional_payment_term_join_condition=payment_term_time_delta_join_condition,
)

# COMMAND ----------

# Gaps and differences of added payment term due dates
short_names = {
    "Payment_Term_Due_Date": "Actual",
    "Expected_Payment_Term_Due_Date": "Expected",
    "Customer_Payment_Term_Due_Date": "Customer",
}

for (reference_date, other_date) in [
    ("Expected_Payment_Term_Due_Date", "Payment_Term_Due_Date"),
    ("Customer_Payment_Term_Due_Date", "Payment_Term_Due_Date"),
    ("Customer_Payment_Term_Due_Date", "Expected_Payment_Term_Due_Date"),
]:
    reference_date_short_name = short_names[reference_date]
    other_date_short_name = short_names[other_date]

    gap_expression = f.when(
        f.col(reference_date) != f.col(reference_date), f.lit("Yes")
    ).otherwise(f.lit("No"))
    diff_expression = f.date_diff(end=f.col(reference_date), start=f.col(other_date))

    # Gap and difference between reference date and another date
    df_invoice = df_invoice.withColumns(
        {
            f"Gap_Payment_Term_Due_Date_{reference_date_short_name}_{other_date_short_name}": gap_expression,
            f"Payment_Term_Due_Date_{reference_date_short_name}_{other_date_short_name}_Diff": diff_expression,
        }
    )

# COMMAND ----------

# <- Calcul gap between docDate and BaseDate
df_invoice = df_invoice.withColumn(
    "Gap_BaseDate_DocDate",
    f.when(f.col("Doc_Date") != f.col("Base_Date"), f.lit("Yes")).otherwise(
        f.lit("No")
    ),
)

# <- Calcul gap between payment date due date
df_invoice = df_invoice.withColumn(
    "Gap_Payment_Term",
    f.when(
        f.col("Payment_Term") != f.col("Customer_Payment_Term"), f.lit("Yes")
    ).otherwise(f.lit("No")),
)

# COMMAND ----------

# Latest_known_payment_date if paid = clearing_Date (payment_date) else = Payment_Term_Due_Date
df_invoice = df_invoice.withColumn(
    "Latest_Known_Payment_Date",
    f.when(f.col("Payment_Status") == "PAID", f.col("Clearing_Date")).otherwise(
        f.col("Payment_Term_Due_Date")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC - Profit Center and Intercompany Flow Enrichment

# COMMAND ----------

# Add Company Entity
df_branch = (
    df_profit_center.withColumnRenamed("Short_Description", "PC_Short_Description")
    .withColumnRenamed("Customer_group", "PC_Customer_group")
    .filter(f.col("Branch").isNotNull())
    .withColumn("Profit_Center", f.trim(f.col("Profit_Center")))
    .dropDuplicates(["Profit_Center"])
)

# Add Profit Center using branch
df_invoice = df_invoice.withColumn("Profit_Center", f.trim(f.col("Profit_Center")))

# join on profit center
df_invoice = df_invoice.join(df_branch, on="Profit_Center", how="left")

df_invoice = df_invoice.withColumn(
    "Profit_Center",
    f.when(f.col("Profit_Center") == "", f.lit("Unknown")).otherwise(
        f.col("Profit_Center")
    ),
)

# COMMAND ----------

df_invoice = df_invoice.withColumn(
    "Company_Entity",
    f.when(f.col("Branch").isNull(), f.lit("Unknown")).otherwise(f.col("Branch")),
)

df_invoice = df_invoice.withColumn(
    "Profit_center_short",
    f.regexp_replace(
        f.when(f.col("Profit_Center").isNull(), f.lit("Unknown")).otherwise(
            f.regexp_replace(f.col("Profit_Center"), "\\s+", "")
        ),
        "^0+",
        "",
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC - Intercompany flow

# COMMAND ----------

df_invoice = df_invoice.withColumnRenamed("Intercompany_flow", "Partner")
List_no_interco = ["", "X000", "000500", "S400", "S200", "001200"]
df_invoice = df_invoice.withColumn(
    "Intercompany_flow",
    f.when(
        (f.col("Partner").isin(List_no_interco)) | (f.col("Partner").isNull()),
        f.lit("No"),
    ).otherwise(f.lit("Yes")),
).drop(f.col("Partner"))

# COMMAND ----------

df_invoice = df_invoice.withColumnRenamed(
    "BSXD_extraction_timestamp", "extraction_timestamp"
).withColumnRenamed("BSXD_ingestion_timestamp", "ingestion_timestamp")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Gold table

# COMMAND ----------

table_utils.save_table(
    dest_table=TABLE_DEST + "_history", df=df_invoice, mode=MODE, overwrite_schema=True
)

# COMMAND ----------

# create latest but check if there is no update
if df_invoice.count() != 0:
    latest_extraction_date = df_invoice.select(f.max("extraction_date")).collect()[0][0]
    df_invoice = df_invoice.filter(f.col("extraction_date") >= latest_extraction_date)
    table_utils.save_table(
        dest_table=TABLE_DEST + "_latest",
        df=df_invoice,
        mode="overwrite",
        overwrite_schema=True,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Expose Gold table

# COMMAND ----------

# get columns that have been validated
gold_columns = ", ".join(
    [col for col in df_invoice.columns if not (col.startswith("BSXD"))]
)
# expose gold table
for type_data in ["latest", "history"]:
    src_table = f"{TABLE_DEST}_{type_data}"
    dest_table = f"{TABLE_DEST}_{type_data}_exposed"
    table_utils.create_table_view(
        src_full_tablename=src_table,
        dest_full_tablename=dest_table,
        select_statement=gold_columns,
        replace_view=True,
    )
