# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Total Postings
# MAGIC **Description:**  
# MAGIC This notebook contains total postings spends which refer to the Latecoere expenses as part of its day-to-day operations, excluding costs related to the production of goods or services.
# MAGIC The aim is to create a silver table for budgets and actuals of G&A.
# MAGIC
# MAGIC In this notebook, enrichments are made through 2 data assets:
# MAGIC - coss (Cost Totals for Internal Postings)
# MAGIC - cosp (Cost Totals for External Postings)
# MAGIC
# MAGIC It intends to replicates former report from BW + Excel formulas
# MAGIC
# MAGIC Headers are filled by using the following data asset : {pipeline_write_env}_bronze.headers_sap.headers_sap_business_cos
# MAGIC
# MAGIC **Input Table**:
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.cosp_latest
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.coss_latest
# MAGIC
# MAGIC **Output Table:**
# MAGIC - {pipeline_write_env}_silver.finance.g_a_co_total_postings

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import DataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from data_asset.finance.g_a.global_variables import *

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_read_env", "dev")
pipeline_read_env = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
reference_read_env = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
pipeline_write_env = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC ## Inputs - Functions

# COMMAND ----------

def clean_split_actual_budget_co(
    df_co: DataFrame, columns_to_select: list[str], columns_to_cast: list[str]
) -> tuple[DataFrame, DataFrame]:
    """
    1. Clean specific columns of the dataframe `df_co` containing all the Costs Objects data
    2. Filter the data and only keep the rows such as VERSN = 000 & WRTTP = 01 ou 04
    3. Extract from it the rows which only concerns 'budget' and 'actual'.

    Returns the newly two dataframes of budgets and actuals
    Args:
    - df_co (DataFrame): The raw DataFrame containing CO data.
    - columns_to_select (list[str]): List of column names to select from the raw DataFrame
    - columns_to_cast (list[str]): List of columns to be cast

    Returns:
    - tuple[DataFrame, DataFrame]: A tuple containing two DataFrames, the first one representing the budget data
      and the second one representing the actual data.
    """

    df_co = df_co.select(columns_to_select)

    for column in columns_to_cast:
        df_co = df_co.withColumn(
            column,
            f.when(
                f.col(column).endswith("-"),
                -f.regexp_replace(f.col(column), "-", "").cast("double"),
            ).otherwise(f.col(column).cast("double")),
        )
    df_co_filtered = df_co.filter(
        (f.col(VERSN) == "000") & (f.col(OBJNR).startswith("KS"))
    )

    return df_co_filtered.filter(f.col(WRTTP) == "01"), df_co_filtered.filter(
        f.col(WRTTP) == "04"
    )


def extract_useful_info_from_objnr(df_co: DataFrame) -> DataFrame:
    """
    Extract useful information from the 'OBJNR' column of the given DataFrame.

    Args:
    - df_co (DataFrame): The DataFrame containing CO data.

    Returns:
    - DataFrame: A DataFrame with additional columns 'COST_OBJECT', 'KOKRS', and 'KOSTL' extracted from 'OBJNR'.
    """
    df_co_new_columns = (
        df_co.withColumn(COST_OBJECT, f.substring(df_co[OBJNR], 1, 2))
        .withColumn(KOKRS, f.substring(df_co[OBJNR], 3, 4))
        .withColumn(KOSTL, f.substring(df_co[OBJNR], 7, 10))
    )
    df_co_budget_real_extract = df_co_new_columns.withColumn(
        KOSTL, f.regexp_replace(df_co_new_columns[KOSTL], " ", "")
    )
    return df_co_budget_real_extract

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

df_cosp_raw = spark.read.table(
    f"{reference_read_env}_bronze.sap_latecoere_ecc6.cosp_latest"
)
df_coss_raw = spark.read.table(
    f"{reference_read_env}_bronze.sap_latecoere_ecc6.coss_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

cosp_coss_columns_to_select = [
    f.col(TABLE_NAME),
    f.col(COST_OBJECT),
    f.col(KOSTL),
    f.col(KOKRS),
    f.col(OBJNR),
    f.col(ACTUAL_TWAER),
    f.col(BUDGET_TWAER),
    f.col(KSTAR),
    f.col(ACTUAL),
    f.col(BUDGET),
    f.col(PERIOD),
    f.col(GJAHR),
    f.col(BEKNZ),
    f.col(BURKS),
]

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Process

# COMMAND ----------

monthly_costs_columns = [
    W_001,
    W_002,
    W_003,
    W_004,
    W_005,
    W_006,
    W_007,
    W_008,
    W_009,
    W_010,
    W_011,
    W_012,
]
columns_cosp = [
    TABLE_NAME,
    OBJNR,
    TWAER,
    VERSN,
    KSTAR,
    WRTTP,
    PERBL,
    GJAHR,
    HRKFT,
    VRGNG,
    VBUND,
    PARGB,
    BEKNZ,
    BURKS,
    *monthly_costs_columns,
]
columns_coss = [
    TABLE_NAME,
    OBJNR,
    TWAER,
    VERSN,
    KSTAR,
    WRTTP,
    GJAHR,
    HRKFT,
    VRGNG,
    PAROB,
    USPOB,
    BEKNZ,
    BURKS,
    *monthly_costs_columns,
]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extract Actuals and Budgets Dataframes for COSS & COSP

# COMMAND ----------

df_cosp_budget, df_cosp_real = clean_split_actual_budget_co(
    df_co=df_cosp_raw,
    columns_to_select=columns_cosp,
    columns_to_cast=monthly_costs_columns,
)

df_coss_budget, df_coss_real = clean_split_actual_budget_co(
    df_co=df_coss_raw,
    columns_to_select=columns_coss,
    columns_to_cast=monthly_costs_columns,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Unpivot cosp & coss table
# MAGIC The actual dataframes contain as many actuals and budgets as months. 
# MAGIC But we do prefere to unpivot it such as we keep two columns : the period / month and the actual or budget related  

# COMMAND ----------

list_ids_cosp = [
    TABLE_NAME,
    OBJNR,
    TWAER,
    KSTAR,
    GJAHR,
    HRKFT,
    VRGNG,
    VBUND,
    PARGB,
    BEKNZ,
    BURKS,
]

df_unpivot_cosp_budget = df_cosp_budget.unpivot(
    ids=list_ids_cosp,
    values=monthly_costs_columns,
    variableColumnName=PERIOD,
    valueColumnName=BUDGET,
)

df_unpivot_cosp_real = df_cosp_real.unpivot(
    ids=list_ids_cosp,
    values=monthly_costs_columns,
    variableColumnName=PERIOD,
    valueColumnName=ACTUAL,
)

list_ids_coss = [
    TABLE_NAME,
    OBJNR,
    GJAHR,
    KSTAR,
    HRKFT,
    VRGNG,
    PAROB,
    USPOB,
    BEKNZ,
    TWAER,
    BURKS,
]
df_unpivot_coss_budget = df_coss_budget.unpivot(
    ids=list_ids_coss,
    values=monthly_costs_columns,
    variableColumnName=PERIOD,
    valueColumnName=BUDGET,
)

df_unpivot_coss_real = df_coss_real.unpivot(
    ids=list_ids_coss,
    values=monthly_costs_columns,
    variableColumnName=PERIOD,
    valueColumnName=ACTUAL,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join Budget & Actual 
# MAGIC ### COSP

# COMMAND ----------

df_unpivot_cosp_budget = df_unpivot_cosp_budget.select(
    f.col(TABLE_NAME),
    f.col(BUDGET),
    f.col(OBJNR),
    f.col(KSTAR),
    f.col(GJAHR),
    f.col(PERIOD),
    f.col(TWAER).alias(BUDGET_TWAER),
    f.col(BEKNZ).alias("COSP_BUDGET_BEKNZ"),
)

df_cosp_budget_real = df_unpivot_cosp_real.join(
    df_unpivot_cosp_budget,
    on=[OBJNR, KSTAR, GJAHR, PERIOD, TABLE_NAME],
    how="full",
)

df_cosp_budget_real = df_cosp_budget_real.withColumn(
    BEKNZ, f.coalesce(BEKNZ, "COSP_BUDGET_BEKNZ")
)
df_cosp_budget_real = df_cosp_budget_real.withColumnRenamed(TWAER, ACTUAL_TWAER)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Extract Cost_Object, Controlling Aera and Cost Center from OBJNR
# MAGIC
# MAGIC rules : OBJNR values contain specific logic :
# MAGIC
# MAGIC - substring( covp.objnr , 1, 2 ) = 'KS' (cost object)
# MAGIC - substring( covp.objnr , 3, 4 ) = csks.kokrs (controlling area)
# MAGIC - substring( covp.objnr , 7, 10 ) = csks.kostl (cost center)

# COMMAND ----------

df_cosp_budget_real_extract = extract_useful_info_from_objnr(df_co=df_cosp_budget_real)

# COMMAND ----------

# MAGIC %md
# MAGIC ### COSS

# COMMAND ----------

df_coss_budget_renamed = df_unpivot_coss_budget.select(
    f.col(TABLE_NAME),
    f.col(BUDGET),
    f.col(OBJNR),
    f.col(KSTAR),
    f.col(GJAHR),
    f.col(USPOB),
    f.col(PERIOD),
    f.col(TWAER).alias(BUDGET_TWAER),
    f.col(BEKNZ).alias("COSS_BUDGET_BEKNZ"),
)

df_budget_real = df_unpivot_coss_real.join(
    df_coss_budget_renamed,
    on=[OBJNR, KSTAR, USPOB, GJAHR, PERIOD, TABLE_NAME],
    how="full",
)

df_budget_real = df_budget_real.withColumn(
    BEKNZ, f.coalesce(BEKNZ, "COSS_BUDGET_BEKNZ")
)
df_budget_real = df_budget_real.withColumnRenamed(TWAER, ACTUAL_TWAER)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Extract Cost_Object, Controlling Aera and Cost Center from OBJNR
# MAGIC

# COMMAND ----------

df_coss_budget_real_extract = extract_useful_info_from_objnr(df_co=df_budget_real)

# COMMAND ----------

df_coss = df_coss_budget_real_extract.select(cosp_coss_columns_to_select)
df_cosp = df_cosp_budget_real_extract.select(cosp_coss_columns_to_select)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Union of COSP & COSS  

# COMMAND ----------

df_co = df_coss.unionByName(df_cosp)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Rename co columns dataset

# COMMAND ----------

# Upload manual table for headers naming MDKP
df_name_cos = spark.read.table(
    f"{pipeline_write_env}_bronze.headers_sap.headers_sap_business_cos"
)

# Renaming header with starting cos_
df_co_prefix = table_utils.add_prefix_to_columns(df=df_co, prefix="cos")

# Call Function Rename Columns according Business header file
df_co_renamed = table_utils.rename_columns_with_sap_business_header(
    df=df_co_prefix, df_sap_business_header=df_name_cos
)
#  Call Funtion Cast Column according Business header file
df_co_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_co_renamed, df_name_cos
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables
# MAGIC -  KOKRS -> 2 unique values
# MAGIC -  KOSTL -> 1268 unique values
# MAGIC - KSTAR -> 899 unique values
# MAGIC
# MAGIC We could have used a key/column of `df_co_renamed` dataset to partition it (`partition_col = "CO_KSTAR"`). But, after having studied the values repartition of any columns this dataset, there is no any key that let contemplate such a partition

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{pipeline_write_env}_silver.finance.total_postings",
    df=df_co_renamed,
    mode="overwrite",
)

# COMMAND ----------


