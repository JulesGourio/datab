"""
`global_variables.py file contains all the global variable name which are used in this module for the three related notebook`
"""

# Common COSP/COSS column name
TABLE_NAME = "table_name"
GJAHR = "gjahr"
HRKFT = "hrkft"
OBJNR = "objnr"
TWAER = "twaer"
VERSN = "versn"
KSTAR = "kstar"
WRTTP = "wrttp"
VRGNG = "vrgng"
COST_OBJECT = "Cost_Object"
KOSTL = "kostl"
BURKS = "bukrs"
BURKS_BUSINESS = "company_code"
W_001 = "wog001"
W_002 = "wog002"
W_003 = "wog003"
W_004 = "wog004"
W_005 = "wog005"
W_006 = "wog006"
W_007 = "wog007"
W_008 = "wog008"
W_009 = "wog009"
W_010 = "wog010"
W_011 = "wog011"
W_012 = "wog012"

# COSP Column name
PERBL = "perbl"
VBUND = "vbund"
PARGB = "pargb"
BEKNZ = "beknz"

# CSS Column name
USPOB = "uspob"
PAROB = "parob"

# Renamed COSS/COSP
BUDGET_TWAER = "BUDGET_TWAER"
ACTUAL_TWAER = "ACTUAL_TWAER"
CO_KOKRS = "controlling_area"
ACTUAL = "Actual"
BUDGET = "Budget"
PERIOD = "Period"

# CSKB Column name
KATYP = "katyp"
KOKRS = "kokrs"

# Cost Center Column name
CSKS_KOKRS = "Controlling_Area"
COST_CENTER = "Cost_Center"
BRANCH = "Branch"
PROFIT_CENTER = "Profit_Center"
COMPANY_CODE = "Company_Code"
CC_RESPONSIBLE = "CC_Responsible"
IS_PNL_LEVEL_1 = "IS_PnL_Level_1"
IS_PNL_LEVEL_2 = "IS_PnL_Level_2"
IS_PNL_LEVEL_3 = "IS_PnL_Level_3"
IS_PNL_LEVEL_4 = "IS_PnL_Level_4"
NAME4_TBD = "Name4_TBD"
SITE = "Site"
CURRENCY = "Currency"
CC_TYPE = "CC_Type"

# Account group Column name
GROUP_CATEGORY = "Group_Category"
GROUP_SUBCATEGORY = "Group_SubCategory"
ACCOUNT_NUMBER = "Account_Number"
GROUP_NAME = "Group_Name"
GROUP_DESCRIPTION = "Group_Description"
HIERARCHY_LEVEL6="Hierarchy_level6"
HIERARCHY_LEVEL7 = "Hierarchy_Level7"
HIERARCHY_LASTLEVEL = "Hierarchy_LastLevel"

# MAterial master data
MMD_CURRENCY = "Currency_origin"