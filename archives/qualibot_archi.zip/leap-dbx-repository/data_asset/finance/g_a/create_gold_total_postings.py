# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Total Postings
# MAGIC **Description:**  
# MAGIC This notebook contains total postings spends which refer to the Latecoere expenses as part of its day-to-day operations, excluding costs related to the production of goods or services.  
# MAGIC The aim is to create a golds data asset of indirect G&A features. 
# MAGIC
# MAGIC **Input Table**:
# MAGIC - {pipeline_read_env}_silver.finance.total_postings
# MAGIC - {reference_read_env}_gold.master_data.company_master_data_latest_exposed
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.cskb_latest
# MAGIC - {reference_read_env}_gold.finance.cost_center_exposed
# MAGIC
# MAGIC
# MAGIC **Output Table:**
# MAGIC - {pipeline_write_env}_gold.g_a_expenses.total_postings

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.types import IntegerType
from pyspark.sql import DataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.data_asset import amount_correction

from data_asset.finance.g_a.global_variables import *

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_read_env", "dev")
pipeline_read_env = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
reference_read_env = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
pipeline_write_env = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Input - LEAP Tables

# COMMAND ----------

df_co = spark.read.table(f"{pipeline_read_env}_silver.finance.total_postings")
df_master_data = spark.read.table(
    f"{reference_read_env}_gold.master_data.company_master_data_latest_exposed"
)

# Table related to cost elements information
df_cskb = spark.read.table(
    f"{reference_read_env}_bronze.sap_latecoere_ecc6.cskb_latest"
)

# Import gold cost center table
df_cc = spark.read.table(f"{reference_read_env}_gold.finance.cost_center_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

selected_exposed_columns = [
    "cos_table_name",
    "controlling_area",
    "fiscal_year",
    "cost_element",
    COST_CENTER,
    BRANCH,
    PROFIT_CENTER,
    BURKS_BUSINESS,
    CC_RESPONSIBLE,
    IS_PNL_LEVEL_1,
    IS_PNL_LEVEL_2,
    IS_PNL_LEVEL_3,
    IS_PNL_LEVEL_4,
    NAME4_TBD,
    SITE,
    "Date",
    CURRENCY,
    PERIOD,
    MMD_CURRENCY,
    "Budget_rate",
    "Actual_rate",
    ACTUAL,
    "Actual_to_euro",
    "Budget_to_euro",
    BUDGET,
]

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Process

# COMMAND ----------

# Take only valid row from Cost Center gold DataAsset
df_cc = df_cc.filter(f.col("Is_valid"))

# COMMAND ----------

df_cskb = (
    df_cskb.withColumn("datbi", f.to_date("datbi", "yyyyMMdd"))
    .filter(f.col("datbi") >= f.current_date())
    .dropDuplicates([KSTAR, KOKRS, KATYP])
)

# COMMAND ----------

# As the `df_co` isn't properly partitioned and does not have any key adapted to a partition, we use `repartition()` to ease the calculation and decrease the time of processing.
# any repartition -> more than 1 hour
# repartition(10) -> 17 min
# repartition(50) -> 10 min

df_co_partition = df_co.repartition(50)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join tables (left join)
# MAGIC
# MAGIC ### CO <-- CSKS <-- CSKB <-- Material_master_data

# COMMAND ----------

df_cc = (
    df_cc.withColumnRenamed(CSKS_KOKRS, "CSKS_" + CSKS_KOKRS)
    .withColumnRenamed(COST_CENTER, "CSKS_" + COST_CENTER)
    .withColumnRenamed("Company_Code", "CSKS_" + "Company_Code")
)
df_cskb = df_cskb.withColumnRenamed(KOKRS, "CSKB_" + KOKRS).withColumnRenamed(
    KSTAR, "CSKB_" + KSTAR
)
df_co_partition = df_co_partition.withColumnRenamed("table_name", "cos_table_name")

# COMMAND ----------

joined_df_with_csks = df_co_partition.join(
    df_cc,
    (df_co_partition["controlling_area"] == df_cc["CSKS_" + CSKS_KOKRS])
    & (df_co_partition["cost_center"] == df_cc["CSKS_" + COST_CENTER]),
    how="left",
).drop(*["CSKS_" + CSKS_KOKRS, "CSKS_" + COST_CENTER, "CSKS_" + "Company_Code"])

df_join = joined_df_with_csks.join(
    df_cskb,
    (joined_df_with_csks["controlling_area"] == df_cskb["CSKB_" + KOKRS])
    & (joined_df_with_csks["cost_element"] == df_cskb["CSKB_" + KSTAR]),
    how="left",
).drop(*["CSKB_" + KOKRS, "CSKB_" + KSTAR])

# COMMAND ----------

df_master_data_renamed = df_master_data.withColumnRenamed(CURRENCY, MMD_CURRENCY)
df_join = df_join.join(
    df_master_data_renamed,
    df_join[BURKS_BUSINESS] == df_master_data_renamed["Company"],
    "left",
).drop("Company")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Transformation
# MAGIC ### Currency
# MAGIC The following cells are used to adjust the currency transaction of the `actuals` and `budgets` to convert it into euro by matching with the transaction rate date 

# COMMAND ----------

# Convert currency
df_dated = df_join.withColumn("Month", f.substring("Period", 5, 2)).withColumn(
    "Date", f.to_date(f.concat(f.col("fiscal_year"), f.col("Month")), "yyyyMM")
)

# Management of Wrong SAP decimal for spécific currency (TND, JPY,...)
df_curr_corrected_actual = amount_correction.create_corrected_amounts(
    df_dated, "Actual", "Currency_origin"
)
df_curr_corrected_actual_budget = amount_correction.create_corrected_amounts(
    df_curr_corrected_actual, "Budget", "Currency"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Convert Budget and actual Date

# COMMAND ----------

# Future budget date to current day malus 1 and Actual Date to end of month
df_budget_date_clean = df_curr_corrected_actual_budget.withColumn(
    "Budget_date",
    f.when(f.col("Date") > f.current_date(), f.date_sub(f.current_date(), 1)).otherwise(
        f.col("Date")
    ),
)

df_budget_date_clean = df_budget_date_clean.withColumn(
    "Actual_date",
    f.when(
        f.year(f.col("Date")) < f.year(f.current_date()),
        f.to_date(
            f.concat(f.year(f.col("Date")), f.lit("12"), f.lit("31")), "yyyyMMdd"
        ),
    ).otherwise(f.last_day(f.add_months(f.current_date(), -1))),
)

# COMMAND ----------

# df_budget_date_clean = df_budget_date_clean.withColumnRenamed("table_name", "cos_table_name")

# COMMAND ----------

df_curr_actual = (
    table_utils.currency_conversion(
        df=df_budget_date_clean,
        document_currency_column=df_budget_date_clean.Currency_origin,
        rate_types=["Consolidation"],
        rate_dates=[df_budget_date_clean.Actual_date],
        target_currency_value="EUR",
        document_amounts=[df_budget_date_clean.Actual_corrected],
    )
    .withColumnRenamed(
        "Actual_corrected_from_Currency_origin_to_EUR_in_Consolidation_rate_at_Actual_date",
        "Actual_to_euro",
    )
    .withColumnRenamed(
        "Currency_origin_to_EUR_in_Consolidation_rate_at_Actual_date",
        "Actual_rate",
    )
)
df_curr_tot = (
    table_utils.currency_conversion(
        df=df_curr_actual,
        document_currency_column=df_curr_actual.Currency,
        rate_types=[BUDGET],
        rate_dates=[df_curr_actual.Budget_date],
        target_currency_value="EUR",
        document_amounts=[df_curr_actual.Budget_corrected],
    )
    .withColumnRenamed(
        "Budget_corrected_from_Currency_to_EUR_in_Budget_rate_at_Budget_date",
        "Budget_to_euro",
    )
    .withColumnRenamed("Currency_to_EUR_in_Budget_rate_at_Budget_date", "Budget_rate")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

table_name = "total_postings"
table_utils.save_table(
    dest_table=f"{pipeline_write_env}_gold.finance.{table_name}",
    df=df_curr_tot,
    mode="overwrite",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Exposed

# COMMAND ----------

catalog = f"{pipeline_write_env}_gold"
domain = "finance"
select_statement = ", ".join(selected_exposed_columns)
src_full_tablename = f"{catalog}.{domain}.{table_name}"

table_utils.create_table_view(
    src_full_tablename=src_full_tablename,
    dest_full_tablename=f"{src_full_tablename}_exposed",
    select_statement=select_statement,
    replace_view=True,
)

# COMMAND ----------


