# Databricks notebook source
# MAGIC %md
# MAGIC # Apply Silver HR Metadata
# MAGIC Runs **once** after multiple source writes complete (downstream task).
# MAGIC Applies table comment, PK constraint, PII tags, and column comments — all idempotent.

# COMMAND ----------

from pathlib import Path
from data_asset.hr.utils.table_schema_map_utils import load_config, post_write_checks
from leap_utils.platform.freshness import freshness_spark
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# Parameter
dbutils.widgets.text("yaml_config_filename", "")
YAML_CONFIG_PATH = f"config/{dbutils.widgets.get("yaml_config_filename")}.yaml"
if not Path(YAML_CONFIG_PATH).exists():
    raise FileNotFoundError(f"YAML config file not found at {YAML_CONFIG_PATH}")

# --- Target ---
config = load_config(YAML_CONFIG_PATH)
_target = config["target"]
SILVER_CATALOG = f"{PIPELINE_WRITE_ENV}_silver_hr"
SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{_target['schema']}.{_target['table']}"

log.info(f"Applying metadata governance on {SILVER_FULL_TABLE}...")

# COMMAND ----------

post_write_checks(spark, SILVER_FULL_TABLE, config)

# freshness pilot table — single sequential call (avoids ConcurrentAppendException from multiple parallel MERGE INTO)
freshness_spark.update_freshness_pilot_table(table_name=SILVER_FULL_TABLE)

log.info(f"Metadata governance + freshness applied on {SILVER_FULL_TABLE} ✓")
dbutils.notebook.exit(f"ok:{SILVER_FULL_TABLE}")

