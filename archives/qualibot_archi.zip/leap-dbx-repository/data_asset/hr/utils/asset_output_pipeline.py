"""Shared final pipeline for HR silver and gold notebooks.

This helper standardises the final tail of the notebooks:
1. Final select and optional cleaning
2. Standard schema GX + notebook-specific GX
3. Table creation
4. Table save
5. Post-write metadata checks
"""

import time
from typing import Callable
import logging

from pyspark.sql.utils import AnalysisException
from great_expectations.dataset import SparkDFDataset

from data_asset.hr.utils.quality_checks import build_schema_quality_checks
from data_asset.hr.utils.silver_cleaning_utils import clean_non_pii
from data_asset.hr.utils.table_schema_map_utils import (
    get_columns,
    get_non_pii_columns,
    get_pk_columns,
    post_write_checks,
)
from leap_utils.common.validation import gx_validation
from leap_utils.data_asset import table_utils


def run_asset_output_pipeline(
    *,
    spark,
    df_input,
    config: dict,
    full_table_path: str,
    pipeline_write_env: str,
    log: logging.Logger,
    extra_gx_builder: Callable | None,
    apply_clean_non_pii: bool,
    drop_null_pk_rows: bool,
    cluster_cols: str | None = None,
    replace_where: str | None = None,
    overwrite_schema: bool = False,
    is_debug: bool = False
) -> None:
    """Run the standard final silver/gold pipeline.

    :param spark: Active SparkSession.
    :param df_input: DataFrame ready for final projection.
    :param config: Parsed YAML configuration dictionary.
    :param full_table_path: Fully qualified destination table path.
    :param pipeline_write_env: Environment used for GX event logging.
    :param log: Application logger.
    :param extra_gx_builder: Callable taking ``df_gx`` and returning a list of notebook-specific GX expectations.
    :param apply_clean_non_pii: Whether to run ``clean_non_pii``.
    :param drop_null_pk_rows: Whether to drop rows with null PK columns before GX.
    :param cluster_cols: Optional comma-separated clustering columns for table creation and write.
    :param replace_where: Optional replaceWhere predicate for scoped overwrite.
    :param overwrite_schema: Value for Delta ``overwriteSchema`` option / save utility.
    :param is_debug: Whether to run debug counts and log them
    """
    target = config["target"]
    table_name = target["table"]
    columns = get_columns(config=config)
    pk_columns = get_pk_columns(config=config)

    df_final = df_input.select(*columns.keys())

    if is_debug:
        count_raw = df_final.count()
        log.debug(f"[{table_name}] {count_raw:,} rows before final pipeline")

    if apply_clean_non_pii:
        df_final = clean_non_pii(df_final, get_non_pii_columns(config))

    if drop_null_pk_rows and pk_columns:
        df_final = df_final.dropna(how="any", subset=pk_columns)

    if is_debug:
        count_clean = df_final.count()
        log.debug(
            f"[{table_name}] {count_clean:,} rows after final pipeline prep "
            f"({count_raw - count_clean} dropped)"
        )

    df_gx = SparkDFDataset(df_final, persist=False)
    red_results = [
        *build_schema_quality_checks(df_gx, config),
        *(extra_gx_builder(df_gx) if extra_gx_builder else []),
    ]

    gx_validation.validate_and_log_gx_results(
        quality_check_results=red_results,
        validation_level="RED",
        info_message=f"{table_name} quality checks, PK={pk_columns})",
        error_message=f"Quality checks FAILED for {table_name}, please check log messages",
        pipeline_write_env=pipeline_write_env,
        table_name=table_name,
        log_to_event_table=True,
        log_successes=True,
        dest_table=full_table_path,
    )

    catalog, schema, table_name = full_table_path.split(".")
    try:
        table_utils.create_unity_catalog_table(
            catalog,
            schema,
            table_name,
            force_reinitialization=False,
            cluster_cols=cluster_cols,
            partition_col=None,
            primary_key_cols=",".join(pk_columns) if pk_columns else None,
            columns=columns,
            force_drop=False,
        )
    except AnalysisException as e:
        log.error(f"Table {full_table_path} could not be created. Error is {e}")
        raise OSError(
            f"An error occurred while creating the table {full_table_path}"
        ) from e

    try:
        start_time = time.time()
        table_utils.save_table(
            dest_table=full_table_path,
            df=df_final,
            mode="overwrite",
            overwrite_schema=overwrite_schema,
            cluster_cols=cluster_cols,
            partition_col=None,
            merge_schema=False,
            replace_where=replace_where,
        )
    except AnalysisException as e:
        log.error(f"Table {full_table_path} could not be saved. Error is {e}")
        raise OSError(
            f"An error occurred while saving the table {full_table_path}"
        ) from e
    else:
        duration = time.time() - start_time
        log.info(f"Table {full_table_path} saved in {duration:.1f} seconds.")
        log.info(f"Wrote {df_final.count():,} rows.")

    post_write_checks(spark, full_table_path, config)
    log.info(f"Metadata governance applied on {full_table_path} ✓")
