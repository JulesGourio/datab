"""Shared bronze → bronze_cleaned cleaning pipeline.

Centralises the loading, three-layer PII cleaning, and save logic that is
duplicated across the create_bronze_cleaned_hr_* notebooks.  Each notebook
keeps its own imports, widgets, configuration dicts, and Layer-3 overrides
(apply_specific_cleaning); this module provides the reusable orchestration.
"""

import logging
import time
from typing import Callable

from pyspark.sql import DataFrame, SparkSession, functions as f
from pyspark.sql.utils import AnalysisException

from leap_utils.data_asset import table_utils
from leap_utils.data_asset.pii_cleaning_utils import (
    PIITag,
    PIICleaningManager,
    cast_columns_to_bool,
    cast_columns_to_date,
    clean_string_columns,
)


# ---------------------------------------------------------------------------
# Layer 2 — type correction
# ---------------------------------------------------------------------------

def apply_type_casts(
    df: DataFrame,
    columns: list[str],
    *,
    columns_to_cast_to_bool: list[str] | None = None,
    columns_to_cast_to_date: dict[str, str | None] | None = None,
    columns_to_cast_to_string: list[str] | None = None,
) -> DataFrame:
    """Correct Spark-inferred column types to their intended semantic types.

    Applies boolean, date, and string casts to the subset of PII columns
    provided.  Columns not listed are left untouched.

    Only columns that are both declared in the config **and** actually present
    in the DataFrame are processed — this prevents ``AnalysisException`` when a
    config dict references a column absent from the current table.

    :param df: Source DataFrame (may already be partially cleaned).
    :type df: DataFrame
    :param columns: PII column names in scope for this table.
    :type columns: list[str]
    :param columns_to_cast_to_bool: Columns to cast to boolean.
    :type columns_to_cast_to_bool: list[str] | None
    :param columns_to_cast_to_date: ``{column: date_format | None}`` mapping.
    :type columns_to_cast_to_date: dict[str, str | None] | None
    :param columns_to_cast_to_string: Columns to cast to string.
    :type columns_to_cast_to_string: list[str] | None
    :return: DataFrame with corrected column types.
    :rtype: DataFrame
    """
    df_cols = set(df.columns)
    columns_to_cast_to_bool = columns_to_cast_to_bool or []
    columns_to_cast_to_date = columns_to_cast_to_date or {}
    columns_to_cast_to_string = columns_to_cast_to_string or []
    df = cast_columns_to_bool(
        df=df,
        columns=[col for col in columns_to_cast_to_bool if col in columns and col in df_cols],
    )
    for col, date_fmt in columns_to_cast_to_date.items():
        if col in columns and col in df_cols:
            df = cast_columns_to_date(df=df, columns=[col], date_format=date_fmt)
    str_cols = [col for col in columns_to_cast_to_string if col in columns and col in df_cols]
    if str_cols:
        df = df.withColumns({col: f.col(col).cast("string") for col in str_cols})
    return df


# ---------------------------------------------------------------------------
# PII-tag-level orchestrator
# ---------------------------------------------------------------------------

def process_pii_tagged_data(
    dfs_raw_per_tag: dict[str, DataFrame],
    tag: PIITag,
    dfs_clean_all: dict[str, DataFrame],
    cleaner: PIICleaningManager,
    log: logging.Logger,
    *,
    pk_columns: dict[str, list[str]] | None = None,
    columns_to_cast_to_bool: dict[str, list[str]] | None = None,
    columns_to_cast_to_date: dict[str, dict[str, str | None]] | None = None,
    columns_to_cast_to_string: dict[str, list[str]] | None = None,
    columns_to_rename: dict[str, dict[str, str]] | None = None,
    apply_specific_cleaning_fn: Callable[[DataFrame, str, list[str]], DataFrame] | None = None,
) -> None:
    """Orchestrate the three-layer cleaning pipeline for one PII tag level.

    Populates *dfs_clean_all* in-place.

    :param dfs_raw_per_tag: Raw DataFrames grouped by PII tag.
    :type dfs_raw_per_tag: dict[str, DataFrame]
    :param tag: PII sensitivity level to process.
    :type tag: PIITag
    :param dfs_clean_all: Accumulator dict updated in-place with cleaned DataFrames.
    :type dfs_clean_all: dict[str, DataFrame]
    :param cleaner: PIICleaningManager instance holding schema metadata.
    :type cleaner: PIICleaningManager
    :param log: Logger instance.
    :type log: logging.Logger
    :param pk_columns: Per-table list of PK column names.
    :type pk_columns: dict[str, list[str]] | None
    :param columns_to_cast_to_bool: Per-table boolean cast config.
    :type columns_to_cast_to_bool: dict[str, list[str]] | None
    :param columns_to_cast_to_date: Per-table date cast config.
    :type columns_to_cast_to_date: dict[str, dict[str, str | None]] | None
    :param columns_to_cast_to_string: Per-table string cast config.
    :type columns_to_cast_to_string: dict[str, list[str]] | None
    :param columns_to_rename: Per-table column rename overrides.
    :type columns_to_rename: dict[str, dict[str, str]] | None
    :param apply_specific_cleaning_fn: Layer 3 callable (table-specific business rules).
    :type apply_specific_cleaning_fn: Callable[[DataFrame, str, list[str]], DataFrame] | None
    """
    pk_cols = pk_columns or {}
    columns_to_cast_to_bool = columns_to_cast_to_bool or {}
    columns_to_cast_to_date = columns_to_cast_to_date or {}
    columns_to_cast_to_string = columns_to_cast_to_string or {}
    columns_to_rename = columns_to_rename or {}

    dfs_pii_raw = dfs_raw_per_tag.get(tag, {})
    for table_name, df_raw in dfs_pii_raw.items():
        log.info(f"Now cleaning table {table_name} for PII tag {tag.value}...")
        pii_cols = cleaner.get_pii_columns(table_name=table_name, tag=tag)
        df_clean = dfs_clean_all.get(table_name, df_raw)
        dtypes_map = dict(df_clean.dtypes)

        # Layer 1 — string baseline (trim + nullify, string PII columns only)
        # preserve PK columns from nullify
        log.info("Standard cleaning for string columns...")
        string_pii_cols = [col for col in pii_cols if dtypes_map.get(col) == "string"]
        table_pk_cols = pk_cols.get(table_name, [])
        nullify_cols = [col for col in string_pii_cols if col not in table_pk_cols]
        trim_only_pk_cols = [col for col in string_pii_cols if col in table_pk_cols]
        df_clean = clean_string_columns(
            df=df_clean, columns=nullify_cols, is_clean_all=True, is_nullify_empty=True
        )
        df_clean = clean_string_columns(
            df=df_clean, columns=trim_only_pk_cols, is_clean_all=True, is_nullify_empty=False
        )

        # Layer 2 — type correction
        table_cast_to_bool = columns_to_cast_to_bool.get(table_name, [])
        table_cast_to_date = columns_to_cast_to_date.get(table_name, {})
        table_cast_to_string = columns_to_cast_to_string.get(table_name, [])
        if any([table_cast_to_bool, table_cast_to_date, table_cast_to_string]):
            log.info("Applying requested type casts...")
            df_clean = apply_type_casts(
                df=df_clean, columns=pii_cols,
                columns_to_cast_to_bool=table_cast_to_bool,
                columns_to_cast_to_date=table_cast_to_date,
                columns_to_cast_to_string=table_cast_to_string,
            )

        # Layer 3 — business rules
        if apply_specific_cleaning_fn is not None:
            log.info(f"Applying specific cleaning using {apply_specific_cleaning_fn.__name__}...")
            df_clean = apply_specific_cleaning_fn(
                df=df_clean, table_name=table_name, pii_cols=pii_cols,
            )

        # Column normalization and rename
        log.info("Normalize column names...")
        df_clean = cleaner.normalize_column_names(
            df=df_clean, table_name=table_name, columns=pii_cols,
        )
        column_map = columns_to_rename.get(table_name, {})
        if column_map:
            log.info(f"Renaming {len(column_map)} columns ...")
            df_clean = cleaner.rename_columns(
                df=df_clean, table_name=table_name,
                column_map=column_map,
            )

        dfs_clean_all[table_name] = df_clean


# ---------------------------------------------------------------------------
# Full pipeline runner
# ---------------------------------------------------------------------------

def run_bronze_cleaning_pipeline(
    spark: SparkSession,
    log: logging.Logger,
    *,
    catalog_source: str,
    catalog_target: str,
    schema: str,
    tables_to_clean: set[str],
    primary_keys: dict[str, list[str]],
    columns_to_cast_to_bool: dict[str, list[str]] | None = None,
    columns_to_cast_to_date: dict[str, dict[str, str | None]] | None = None,
    columns_to_cast_to_string: dict[str, list[str]] | None = None,
    columns_to_rename: dict[str, dict[str, str]] | None = None,
    apply_specific_cleaning_fn: Callable[[DataFrame, str, list[str]], DataFrame] | None = None,
    post_clean_fn: Callable[[dict[str, DataFrame], PIICleaningManager], dict[str, DataFrame]] | None = None,
) -> None:
    """Run the full bronze → bronze_cleaned pipeline for a single schema.

    1. Load tables via PIICleaningManager
    2. Apply three-layer PII cleaning (baseline → type correction → business rules)
    3. Apply post-clean transformations (independent of PII tagging)
    4. Write cleaned tables, propagate comments, PII tags, and primary keys

    :param spark: Active SparkSession.
    :type spark: SparkSession
    :param log: Logger instance.
    :type log: logging.Logger
    :param catalog_source: Catalog where raw (uncleaned) tables live.
    :type catalog_source: str
    :param catalog_target: Catalog where cleaned tables will be written.
    :type catalog_target: str
    :param schema: Schema containing the tables to process.
    :type schema: str
    :param tables_to_clean: Allowlist of table names to process.
    :type tables_to_clean: set[str]
    :param primary_keys: Per-table primary key columns for the cleaned tables.
    :type primary_keys: dict[str, list[str]]
    :param columns_to_cast_to_bool: Per-table boolean cast config.
    :type columns_to_cast_to_bool: dict[str, list[str]] | None
    :param columns_to_cast_to_date: Per-table date cast config.
    :type columns_to_cast_to_date: dict[str, dict[str, str | None]] | None
    :param columns_to_cast_to_string: Per-table string cast config.
    :type columns_to_cast_to_string: dict[str, list[str]] | None
    :param columns_to_rename: Per-table column rename overrides.
    :type columns_to_rename: dict[str, dict[str, str]] | None
    :param apply_specific_cleaning_fn: Layer 3 callable (table-specific business rules).
    :type apply_specific_cleaning_fn: Callable[[DataFrame, str, list[str]], DataFrame] | None
    :param post_clean_fn: PII-independent transform applied after cleaning, before save.
        Receives ``(dfs_clean_all, cleaner)`` and returns the updated dict.
    :type post_clean_fn: Callable[[dict[str, DataFrame], PIICleaningManager], dict[str, DataFrame]] | None
    """
    columns_to_cast_to_bool = columns_to_cast_to_bool or {}
    columns_to_cast_to_date = columns_to_cast_to_date or {}
    columns_to_cast_to_string = columns_to_cast_to_string or {}
    columns_to_rename = columns_to_rename or {}

    log.info("Starting Bronze Cleaning Pipeline...")

    # ── Load ──────────────────────────────────────────────────────────────
    cleaner = PIICleaningManager(
        spark=spark,
        catalog_source=catalog_source,
        catalog_target=catalog_target,
        schema=schema,
        tables_to_load=tables_to_clean,
    )
    dfs_raw_per_tag = cleaner.load_all_by_tag()

    # Pre-populate with non-PII tables (pass-through)
    dfs_clean_all: dict[str, DataFrame] = {
        name: df
        for name, df in dfs_raw_per_tag.get(None, {}).items()
        if not tables_to_clean or name in tables_to_clean
    }

    log.info(f"Schema processed:\n{cleaner}")

    # ── Clean ─────────────────────────────────────────────────────────────
    for tag in PIITag:
        process_pii_tagged_data(
            dfs_raw_per_tag=dfs_raw_per_tag,
            tag=tag,
            dfs_clean_all=dfs_clean_all,
            cleaner=cleaner,
            pk_columns=primary_keys,
            columns_to_cast_to_bool=columns_to_cast_to_bool,
            columns_to_cast_to_date=columns_to_cast_to_date,
            columns_to_cast_to_string=columns_to_cast_to_string,
            columns_to_rename=columns_to_rename,
            apply_specific_cleaning_fn=apply_specific_cleaning_fn,
            log=log,
        )

    # ── Post-clean (PII-independent transforms) ────────────────────────────
    if post_clean_fn is not None:
        log.info(f"Applying post-clean function {post_clean_fn.__name__}...")
        dfs_clean_all = post_clean_fn(dfs_clean_all, cleaner)

    # ── Save ──────────────────────────────────────────────────────────────
    if log.isEnabledFor(logging.DEBUG):
        log.debug("Propagating PII tags as simulation...")
        cleaner.propagate_pii_tags(simulate=True)

    for table_name, df_clean in dfs_clean_all.items():
        destination_table_full_path = f"{catalog_target}.{schema}.{table_name}"

        # Re-attach source column comments
        log.info("Propagating columns comments...")
        df_clean = cleaner.propagate_columns_comments(
            table_name=table_name, df_clean=df_clean,
        )

        # Only (re)write the schema when the table is new or its schema changed
        table_exists = table_utils.UnityCatalogCheckTableExists(
            destination_table_full_path,
        )
        if not table_exists:
            rewrite_schema = True
        else:
            _existing_sig = {
                (fld.name, fld.dataType)
                for fld in spark.table(destination_table_full_path).schema
            }
            _new_sig = {(fld.name, fld.dataType) for fld in df_clean.schema}
            rewrite_schema = _existing_sig != _new_sig

        log.info(f"Saving table {destination_table_full_path} (rewrite_schema={rewrite_schema})...")
        try:
            start_time = time.time()
            table_utils.save_table(
                dest_table=destination_table_full_path,
                df=df_clean,
                mode="overwrite",
                overwrite_schema=rewrite_schema,
            )
        except AnalysisException as e:
            log.error(
                f"Table {destination_table_full_path} could not be saved.\nError: {e}"
            )
            raise

        duration = time.time() - start_time
        log.info(f"Table {destination_table_full_path} saved in {duration:.1f}s.")

        # Table comment — apply only if it differs from the source
        log.info("Propagating table description...")
        cleaner.propagate_table_comments(
            table_name=table_name,
            df_clean=df_clean,
            destination_table_full_path=destination_table_full_path,
        )

        # Primary key — design property of the cleaned table
        log.info("Setting PKs...")
        cleaner.set_primary_keys(
            table_name=table_name,
            df_clean=df_clean,
            destination_table_full_path=destination_table_full_path,
            primary_keys=primary_keys,
        )

    # Propagate PII tags from source to target
    log.info("Propagating PII tags...")
    cleaner.propagate_pii_tags()
