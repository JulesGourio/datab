"""
Silver Cleaning Utils — standard non-PII cleaning for silver absence notebooks.

Usage in notebooks:
    from data_asset.hr.utils.silver_cleaning_utils import clean_non_pii
    df = clean_non_pii(df_raw, get_mandatory_columns(config))
"""

import unicodedata
from pyspark.sql import DataFrame
from pyspark.sql import functions as f


def normalize_string(s: str) -> str:
    """Split, lowercase, and remove accents from a string.

    :param s: The input string to normalize.
    :type s: str
    :return: lowercase, accent-stripped string.
    :rtype: str
    """
    if not s:
        return ""
    # Remove accents by decomposing unicode and stripping combining characters
    nfkd = unicodedata.normalize("NFKD", s)
    stripped = "".join(c for c in nfkd if not unicodedata.combining(c))
    return stripped.lower()

def clean_non_pii(df: DataFrame, non_pii_cols: list[str]) -> DataFrame:
    """Standard non-PII cleaning applied after column mapping.

    PII cleaning is already handled upstream (Bronze → Bronze Cleaned).

    Rules:

    1. Trim all string columns and nullify empty strings.

    :param df: The input DataFrame to clean.
    :type df: pyspark.sql.DataFrame
    :param non_pii_cols: List of non-PII column names to apply cleaning on.
    :type non_pii_cols: list[str]
    :return: DataFrame with cleaned non-PII string columns.
    :rtype: pyspark.sql.DataFrame
    """
    # cache - avoids RPCs + select non-PII columns only:
    dtypes_map = [(c, t) for c, t in df.dtypes if c in non_pii_cols]
    # 1. Trim all string columns and nullify empty strings
    string_cols = [c for c, t in dtypes_map if t == "string"]
    if string_cols:
        df = df.withColumns({
            col_name: f.when(f.trim(f.col(col_name)) == "", None)
            .otherwise(f.trim(f.col(col_name)))
            for col_name in string_cols
        })
    return df
