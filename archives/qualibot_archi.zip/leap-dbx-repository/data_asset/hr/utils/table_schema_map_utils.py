"""
Table schema map utils — reads YAML column contract and validates DataFrames.

Usage in notebooks:
    from data_asset.hr.utils.table_schema_map_utils import (
        load_config, apply_tags, get_mandatory_columns, post_write_checks,
    )
    config = load_config()
    apply_tags(spark, catalog, schema, table, full_table_path, config)
    post_write_checks(spark, full_table_path, config)
    mandatory_cols = get_mandatory_columns(config)
"""

import yaml
import logging
from pathlib import Path


_TYPE_ALIASES = {
    "string": "string",
    "date": "date",
    "bigint": "bigint",
    "long": "bigint",
    "int": "int",
    "integer": "int",
    "double": "double",
    "float": "float",
    "bool": "boolean",
    "boolean": "boolean",
}

_SPARK_TYPE_ALIASES = {
    "string": "StringType",
    "date": "DateType",
    "bigint": "LongType",
    "long": "LongType",
    "int": "IntegerType",
    "integer": "IntegerType",
    "double": "DoubleType",
    "float": "FloatType",
    "bool": "BooleanType",
    "boolean": "BooleanType",
}

def load_config(config_path: str) -> dict:
    """Load the YAML column contract.

    :param config_path: Filesystem path to the YAML configuration file.
    :type config_path: str
    :return: Parsed configuration dictionary containing ``target`` and ``columns`` sections.
    :rtype: dict
    :raises RuntimeError: If the file cannot be read or required sections are missing.
    """
    try:
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
    except (IOError, OSError) as e:
        raise RuntimeError(f"Cannot load config from {config_path}: {e}") from e

    # Check presence of main fields
    if "target" not in config:
        raise KeyError("Missing 'target' section in config.")
    if "columns" not in config:
        raise KeyError("Missing 'columns' section in config.")

    # Check primary keys consistency (defined in columns + cannot be null_allowed)
    column_names = get_columns(config=config)
    null_not_allowed = get_not_null_columns(config=config)
    primary_keys = config["target"].get("primary_key", [])
    if any(pk not in column_names for pk in primary_keys):
        raise ValueError(f"At least one primary key is not defined in the schema.")
    if any(pk not in null_not_allowed for pk in primary_keys):
        raise ValueError(f"At least one primary key is marked as null_allowed.")

    return config

def get_columns(config: dict, use_spark_types: bool = False) -> dict[str, str]:
    """Return dict of columns with name as keys and SQL type as values.

    :param config: Parsed YAML configuration dictionary.
    :type config: dict
    :return: Mapping of column names to their normalised SQL type strings.
    :rtype: dict[str, str]
    """
    if use_spark_types:
        type_aliases = _SPARK_TYPE_ALIASES
    else:
        type_aliases = _TYPE_ALIASES
    return {col["column_name"]: type_aliases.get(col["type"], "") for col in config["columns"]}

def get_not_null_columns(config: dict) -> list[str]:
    """Return list of columns marked that are not supposed to contain null values.

    :param config: Parsed YAML configuration dictionary.
    :type config: dict
    :return: List of column names where ``null_allowed`` is ``False``.
    :rtype: list[str]
    """
    return [c["column_name"] for c in config["columns"] if not c.get("null_allowed", True)]

def get_pii_columns(config: dict) -> list[str]:
    """Return list of columns with PII tags

    :param config: Parsed YAML configuration dictionary.
    :type config: dict
    :return: List of column names where ``pii_tag`` is not ``None``.
    :rtype: list[str]
    """
    return [c["column_name"] for c in config["columns"] if c.get("pii_tag") is not None]

def get_non_pii_columns(config: dict) -> list[str]:
    """Return list of columns wihtout PII tags

    :param config: Parsed YAML configuration dictionary.
    :type config: dict
    :return: List of column names where ``pii_tag`` is ``None``.
    :rtype: list[str]
    """
    return [c["column_name"] for c in config["columns"] if c.get("pii_tag") is None]

def get_pk_columns(config: dict) -> list[str]:
    """Return list of primary key columns

    :param config: Parsed YAML configuration dictionary.
    :type config: dict
    :return: List of primary key column names.
    :rtype: list[str]
    """
    return config["target"].get("primary_key", [])

def apply_tags(spark, full_table_path: str, config: dict) -> None:
    """Apply tags (PII and non-PII) to target table columns.

    Idempotent — skips columns that are already tagged.

    :param spark: Active SparkSession.
    :type spark: SparkSession
    :param full_table_path: Fully qualified table name (``catalog.schema.table``).
    :type full_table_path: str
    :param config: Parsed YAML configuration dictionary containing PII and general
        tag definitions.
    :type config: dict
    """
    catalog, schema, table = full_table_path.split(".")

    # Collect PII tags (single string per column)
    required_tags = [
        (c["column_name"], c["pii_tag"])
        for c in config["columns"]
        if "pii_tag" in c
    ]
    # Collect additional general tags (list of strings per column)
    required_tags += [
        (c["column_name"], tag)
        for c in config["columns"]
        if "tags" in c
        for tag in c["tags"]
    ]

    existing_set = {
        (r.column_name, r.tag_name)
        for r in spark.sql(f"""
            SELECT column_name, tag_name
            FROM system.information_schema.column_tags
            WHERE catalog_name = '{catalog}'
              AND schema_name  = '{schema}'
              AND table_name   = '{table}'
        """).collect()
    }

    for col_name, tag_name in required_tags:
        if (col_name, tag_name) not in existing_set:
            spark.sql(f"ALTER TABLE {full_table_path} ALTER COLUMN `{col_name}` SET TAGS ('{tag_name}')")
            logging.info(f"Tagged {col_name} ← {tag_name}")
        else:
            logging.info(f"Already tagged: {col_name} ← {tag_name}")


def post_write_checks(spark, full_table_path: str, config: dict) -> None:
    """Post-write guarantees — idempotent, check-before-alter pattern.

    Applies the following checks and alterations in order:

    1. Table comment (skip if already matches YAML)
    2. PK constraint (skip if already exists)
    3. PII tags (skip already-tagged columns)
    4. Column comments (skip if already match YAML)

    On a normal run (nothing changed): only SELECT queries, zero ALTER.
    Designed to run in a single downstream task (no parallel contention).

    :param spark: Active SparkSession.
    :type spark: SparkSession
    :param full_table_path: Fully qualified table name (``catalog.schema.table``).
    :type full_table_path: str
    :param config: Parsed YAML configuration dictionary containing target metadata
        and column definitions.
    :type config: dict
    """
    target = config["target"]
    catalog, schema, table = full_table_path.split(".")

    # 1. Table comment — check current, alter only if different
    desired_comment = target.get("comment")
    if desired_comment:
        current_comment = spark.sql(f"""
            SELECT comment FROM system.information_schema.tables
            WHERE table_catalog = '{catalog}'
              AND table_schema  = '{schema}'
              AND table_name    = '{table}'
        """).first()
        current = current_comment["comment"] if current_comment else None
        if current != desired_comment:
            escaped = desired_comment.replace("'", "\\'")
            spark.sql(f"COMMENT ON TABLE {full_table_path} IS '{escaped}'")
            logging.info(f"Table comment applied on {full_table_path}")
        else:
            logging.info(f"Table comment already up-to-date")

    # 2. PK constraint (informational, NOT ENFORCED)
    pk_cols = target.get("primary_key")
    if pk_cols:
        constraint_name = f"pk_{target['table']}"
        existing = spark.sql(f"""
            SELECT constraint_name
            FROM system.information_schema.table_constraints
            WHERE table_catalog = '{catalog}'
              AND table_schema  = '{schema}'
              AND table_name    = '{table}'
              AND constraint_name = '{constraint_name}'
        """).collect()
        if not existing:
            for col in pk_cols:
                spark.sql(f"ALTER TABLE {full_table_path} ALTER COLUMN `{col}` SET NOT NULL")
            cols_sql = ", ".join(pk_cols)
            spark.sql(f"ALTER TABLE {full_table_path} ADD CONSTRAINT {constraint_name} PRIMARY KEY ({cols_sql}) NOT ENFORCED")
            logging.info(f"PK constraint '{constraint_name}' added: ({cols_sql})")
        else:
            logging.info(f"PK constraint '{constraint_name}' already exists")

    # 3. PII tags
    apply_tags(spark, full_table_path=full_table_path, config=config)

    # 4. Column comments — check current, alter only if different
    current_comments = {
        r.column_name: r.comment
        for r in spark.sql(f"""
            SELECT column_name, comment
            FROM system.information_schema.columns
            WHERE table_catalog = '{catalog}'
              AND table_schema  = '{schema}'
              AND table_name    = '{table}'
        """).collect()
    }
    applied = 0
    for col_def in config.get("columns", []):
        col_comment = col_def.get("comment")
        col_name = col_def["column_name"]
        if col_comment and current_comments.get(col_name) != col_comment:
            escaped = col_comment.replace("'", "\\'")
            spark.sql(f"ALTER TABLE {full_table_path} ALTER COLUMN `{col_name}` COMMENT '{escaped}'")
            applied += 1
    if applied:
        logging.info(f"Column comments: {applied} updated on {full_table_path}")
    else:
        logging.info(f"Column comments already up-to-date on {full_table_path}")
