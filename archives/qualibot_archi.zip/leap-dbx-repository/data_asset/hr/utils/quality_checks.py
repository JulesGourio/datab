"""Standard Great Expectations quality checks derived from the YAML column contract.

Usage in notebooks:
    from data_asset.hr.utils.quality_checks import build_schema_quality_checks

    red_results = [
        *build_schema_quality_checks(df_gx, config),
        # --- domain-specific checks below ---
        ...
    ]
"""

from data_asset.hr.utils.table_schema_map_utils import (
    get_columns,
    get_pk_columns,
    get_not_null_columns,
)


def build_schema_quality_checks(df_gx, config: dict) -> list:
    """Build standard GX quality checks from the YAML config contract.

    Returns a list of GX expectation results covering:
    1. Column order matches YAML spec
    2. Column types match YAML spec (Spark type names)
    3. Row count > 0
    4. PK grain uniqueness
    5. Not-null constraints (PKs + null_allowed=False columns)

    :param df_gx: A Great Expectations SparkDFDataset.
    :param config: Parsed YAML configuration dictionary.
    :return: List of GX expectation result dicts.
    """
    columns_w_spark_types = get_columns(config=config, use_spark_types=True)
    pk_columns = get_pk_columns(config=config)
    columns_not_null = get_not_null_columns(config=config)

    return [
        # 1. Column order
        df_gx.expect_table_columns_to_match_ordered_list(
            column_list=list(columns_w_spark_types.keys())
        ),
        # 2. Column types
        *[
            df_gx.expect_column_values_to_be_of_type(column=col_name, type_=col_type)
            for col_name, col_type in columns_w_spark_types.items()
        ],
        # 3. Row count > 0
        df_gx.expect_table_row_count_to_be_between(min_value=1),
        # 4. PK grain uniqueness
        df_gx.expect_compound_columns_to_be_unique(column_list=pk_columns),
        # 5. Not-null columns (PKs + null_allowed=False)
        *[
            df_gx.expect_column_values_to_not_be_null(column=col)
            for col in sorted(set(pk_columns + columns_not_null))
        ],
    ]
