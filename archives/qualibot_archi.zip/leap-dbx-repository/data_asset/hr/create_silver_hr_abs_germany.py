# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Silver HR Calendar — Site Working Days
# MAGIC %md
# MAGIC ## Silver HR Absences — Germany
# MAGIC
# MAGIC Autonomous notebook: reads Germany monthly absence counts from bronze cleaned, maps to unified silver schema,
# MAGIC and writes to the target table defined in `silver_monthly_abs_column_mapping.yaml` with `REPLACE WHERE source = 'GERMANY'`.
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | Germany absences | `{pipeline_read_env}_bronze_cleaned_hr` | `germany_abs` | `germany_abs_unpivot_latest` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_silver_hr.<schema>.<table>` (from YAML config, column `source = 'GERMANY'`)
# MAGIC
# MAGIC **Granularity**: Monthly — one row per group (`id_group`) per absence motive (`absence_type_code`) per `year_month`. The `absence_type_count` column holds the occurrence count for that period.
# MAGIC
# MAGIC **Column mapping**:
# MAGIC
# MAGIC | Source column | Silver column |
# MAGIC |---|---|
# MAGIC | `group_id` | `id_group` |
# MAGIC | `motive_name` | `absence_type_code` |
# MAGIC | `occurrence_count` | `absence_type_count` |
# MAGIC | `year_month` | `year_month` |
# MAGIC | _(literal)_ | `source` = `'GERMANY'` |
# MAGIC | _(null)_ | `absence_type_desc` |
# MAGIC
# MAGIC **Derived columns**: `absence_month`, `absence_year`, `absence_year_month` (extracted from `year_month`).

# COMMAND ----------

# DBTITLE 1,Imports
import re
from pyspark.sql import functions as f

from data_asset.hr.utils.table_schema_map_utils import load_config
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# DBTITLE 1,Config: widgets & logging
# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config: source and target
# --- Source ---
SOURCE_CATALOG = f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
SOURCE_SCHEMA = "germany_abs"
SOURCE_TABLE = "germany_abs_unpivot_latest"
SOURCE = "GERMANY"

# --- Target ---
config = load_config(config_path="config/silver_fact_absence_month_column_mapping.yaml")
_target = config["target"]
SILVER_CATALOG = f"{PIPELINE_WRITE_ENV}_silver_hr"
SILVER_SCHEMA = _target["schema"]
SILVER_TABLE = _target["table"]

# --- Full table paths ---
SOURCE_FULL_TABLE = f"{SOURCE_CATALOG}.{SOURCE_SCHEMA}.{SOURCE_TABLE}"
SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# COMMAND ----------

# DBTITLE 1,Specific parameters
dbutils.widgets.text("min_absence_year_month", "2025-01")
MIN_ABSENCE_YEAR_MONTH = dbutils.widgets.get("min_absence_year_month")

match = re.match(r"(?P<year>\d{4})-\d{2}", MIN_ABSENCE_YEAR_MONTH)
if not match:
    raise ValueError("Invalid date format for min absence year-month. Expected YYYY-MM")
min_year = int(match.group("year")) # used for GX

# COMMAND ----------

# DBTITLE 1,Input data
df_source = spark.table(SOURCE_FULL_TABLE)

df_silver = df_source.select(
    f.col("group_id").alias("id_group"),
    f.col("motive_name").alias("absence_type_code"),
    f.col("occurrence_count").alias("absence_type_count"),
    f.col("year_month"),
    f.lit(SOURCE).alias("source"),
    f.expr("CAST(NULL AS STRING)").alias("absence_type_desc") # null abs. descriptions
)

# COMMAND ----------

# DBTITLE 1,Tr. 1.1 - Derive date columns
df_silver = df_silver.withColumns(
    {
        "absence_month_str": f.date_format("year_month", "MM"),
        "absence_year_str": f.date_format("year_month", "yyyy"),
    }
).withColumns(
    {
        "absence_year_month": f.concat_ws("-", "absence_year_str", "absence_month_str"),
        "absence_month": f.col("absence_month_str").cast("int"),
        "absence_year": f.col("absence_year_str").cast("int"),
    }
)

# COMMAND ----------

# DBTITLE 1,Tr. 1.2 - Filter by min date
df_silver = df_silver.filter(f.col("absence_year_month") >= MIN_ABSENCE_YEAR_MONTH)

# COMMAND ----------

# DBTITLE 1,Tr. 1.3 - Exclude zero-count rows
df_silver = df_silver.filter(f.col("absence_type_count") > 0)

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
def _build_extra_red_results(df_gx: SparkDFDataset) -> list[ExpectationSuiteValidationResult]:
    return [
        # absence_type_count > 0
        df_gx.expect_column_values_to_be_between(
            column="absence_type_count", min_value=0, strict_min=True
        ),
        # absence_month >= 1 and <= 12
        df_gx.expect_column_values_to_be_between(
            column="absence_month",
            min_value=1,
            max_value=12,
        ),
        # absence_year >= min_year
        df_gx.expect_column_values_to_be_between(
            column="absence_year", min_value=min_year,
        ),
        # absence_year_month is like YEAR_MONTH_PATTERN
        df_gx.expect_column_values_to_match_regex(
            column="absence_year_month", regex=r"\d{4}-\d{2}",
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_silver,
    config=config,
    full_table_path=SILVER_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=True,
    drop_null_pk_rows=True,
    cluster_cols="source, id_group",
    replace_where=f"source = '{SOURCE}'",
    is_debug=LOG_LEVEL == "debug",
)
