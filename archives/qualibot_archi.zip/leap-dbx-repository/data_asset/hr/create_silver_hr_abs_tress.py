# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Silver — TRESS Absences
# MAGIC %md
# MAGIC ## Silver HR Absences — TRESS
# MAGIC
# MAGIC Autonomous notebook: reads TRESS absences from bronze cleaned, maps to unified silver schema,
# MAGIC and writes to `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` with `REPLACE WHERE source = 'TRESS'`.
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | TRESS | `{pipeline_read_env}_bronze_cleaned_hr` | `tress` | `v_leap_abscence_latest` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` (column `source = 'TRESS'`)
# MAGIC
# MAGIC **Filter**: Valid records only (`_meta_validity_check = true`). Excludes null `au_tipo`.
# MAGIC
# MAGIC **Note**: TRESS provides daily absences only — no time granularity. `absence_duration_min` defaults to 480 min (8h). `absence_day_value` is always 1.0.

# COMMAND ----------

# DBTITLE 1,Config
from pyspark.sql import functions as f, Window

from data_asset.hr.utils.table_schema_map_utils import load_config
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# --- Source ---
BRONZE_CLEANED_CATALOG   = f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
TRESS_SCHEMA             = "tress"
TRESS_ABSENCES_TABLE     = "v_leap_abscence_latest"

# --- Business rules ---
TRESS_DEFAULT_DURATION_MIN = 480  # TRESS daily absences only — 8h assumed (no time granularity)

# --- Target (from YAML contract — single source of truth) ---
config = load_config(config_path="config/silver_abs_column_mapping.yaml")
_target = config["target"]
SILVER_CATALOG    = f"{PIPELINE_WRITE_ENV}_silver_hr"  # env-driven, overrides YAML default
SILVER_SCHEMA     = _target["schema"]     # absenteism
SILVER_TABLE      = _target["table"]      # fact_absence_day
SOURCE            = "TRESS"

SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# Derive MIN_ABSENCE_DATE from immat coverage start (absences before immat cannot be enriched)
_immat_table = f"{PIPELINE_READ_ENV}_gold_hr.immat.immat_monthly_history"
_min_immat_month = spark.sql(f"SELECT MIN(year_month) FROM {_immat_table}").collect()[0][0]
MIN_ABSENCE_DATE = f"{_min_immat_month}-01"
log.info(f"[{SOURCE}] MIN_ABSENCE_DATE = {MIN_ABSENCE_DATE} (immat coverage floor)")

# COMMAND ----------

# DBTITLE 1,Non-PII Cleaning
# MAGIC %md
# MAGIC ## Non-PII Cleaning
# MAGIC
# MAGIC Standard cleaning applied to all Silver absence notebooks **after** column mapping.
# MAGIC PII cleaning is already handled upstream (Bronze → Bronze Cleaned).
# MAGIC
# MAGIC Rules applied here:
# MAGIC 1. **Trim** all string columns (remove leading/trailing whitespace)
# MAGIC 2. **Nullify** empty strings (consistent NULL representation)
# MAGIC 3. **Drop rows where mandatory fields are null** (driven from YAML contract)
# MAGIC
# MAGIC → `data_asset.hr.utils.silver_cleaning_utils`

# COMMAND ----------

# DBTITLE 1,read_tress_absences
def read_tress_absences():
    """
    Read and map TRESS absence records to the silver schema.

    Source filter: _meta_validity_check = true, au_tipo IS NOT NULL.
    au_tipo maps to both absence_type_code and absence_type_desc (no separate description in source).

    absence_duration_min: defaulted to TRESS_DEFAULT_DURATION_MIN (480 min = 8h) — TRESS provides
    daily absences only, no time granularity available.
    absence_day_value: always 1.0 — no half-day notion in TRESS.
    day_order: row_number() per (id_group, absence_date) ordered by absence_type_code.
    dropDuplicates() is a defensive guard against potential upstream re-ingestion of identical
    records. Applied after select on silver columns only.
    """
    df = spark.table(f"{BRONZE_CLEANED_CATALOG}.{TRESS_SCHEMA}.{TRESS_ABSENCES_TABLE}")
    return (
        df.filter(
            f.col("_meta_validity_check")
            & f.col("au_tipo").isNotNull()
            & (f.col("date_") >= MIN_ABSENCE_DATE)
        )
        .select(
            f.col("idemployee").alias("id_group"),
            f.col("date_").alias("absence_date"),
            f.col("au_tipo").alias("absence_type_code"),
            f.col("au_tipo").alias("absence_type_desc"),  # no description in source
            f.lit(TRESS_DEFAULT_DURATION_MIN).cast("long").alias("absence_duration_min"),
            f.lit(1.0).alias("absence_day_value"),        # always full day in TRESS
        )
        .dropDuplicates()  # remove exact source duplicates before assigning day_order
        .withColumn("day_order", f.row_number().over(
            Window.partitionBy("id_group", "absence_date").orderBy("absence_type_code")
        ))
        .withColumn("source", f.lit(SOURCE))
    )

# COMMAND ----------

# DBTITLE 1,Input data
df_raw = read_tress_absences()

if LOG_LEVEL == "debug":
    count_raw = df_raw.count()
    log.debug(f"[{SOURCE}] {count_raw:,} rows after read + mapping")

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
def _build_extra_red_results(
    df_gx: SparkDFDataset,
) -> list[ExpectationSuiteValidationResult]:
    return [
        # absence_duration_min >= 0 and <= 1440 (no single-day absence > 24h)
        df_gx.expect_column_values_to_be_between(
            column="absence_duration_min",
            min_value=0,
            max_value=1440,
        ),
        # absence_day_value in [0, 1]
        df_gx.expect_column_values_to_be_between(
            column="absence_day_value",
            min_value=0,
            max_value=1,
            mostly=1.0,
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_raw,
    config=config,
    full_table_path=SILVER_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=True,
    drop_null_pk_rows=True,
    cluster_cols="source, id_group",
    replace_where=f"source = '{SOURCE}'",
    is_debug=LOG_LEVEL == "debug",
)
