# Databricks notebook source
# DBTITLE 1,Header – Notebook Documentation
# MAGIC %md
# MAGIC
# MAGIC # [HR] - USA Abs Bronze to Bronze Clean
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC **Description:**
# MAGIC Loads all tables from the USA Abs bronze schema, applies PII-aware cleaning and type-casting operations, then writes the cleaned DataFrames to the bronze_cleaned catalog. PII tag propagation and comments propagation are handled directly in this notebook.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - **PII Tag-based processing**: Tables and columns are processed iteratively per PII sensitivity level (STANDARD, CONFIDENTIAL, RGPD) using `PIICleaningManager`
# MAGIC - **PII tag propagation**: Handled directly in this notebook after the write step, using a column name map from source to target schemas
# MAGIC - **Comments propagation**: Table and column comments are propagated automatically from source to target during the write step
# MAGIC
# MAGIC **Intended Pipeline:**
# MAGIC - HR USA Abs Bronze Cleaning pipeline
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - `{PIPELINE_WRITE_ENV}_bronze_cleaned_hr.usa_abs.*`
# MAGIC
# MAGIC **Inputs:**
# MAGIC - `{PIPELINE_READ_ENV}_bronze_hr.usa_abs.*`
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - USA Abs Bronze Ingestion pipeline
# MAGIC
# MAGIC **Automatically handled:**
# MAGIC - PII tag propagation (source → target column name map)
# MAGIC - Table and column comments propagation
# MAGIC
# MAGIC **Things performed in this notebook:**
# MAGIC 1. Load all USA Abs tables and organize columns by PII tag
# MAGIC 2. Apply three-layer cleaning pipeline per PII level (Layer 1: universal string baseline; Layer 2: type correction; Layer 3: business rules)
# MAGIC 3. Write cleaned tables to bronze_cleaned catalog
# MAGIC 4. Propagate PII tags from source to target
# MAGIC 5. Propagate table and column comments automatically

# COMMAND ----------

# DBTITLE 1,Imports header
# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
import time

# Logging
from leap_utils.common import logger

from utils.bronze_cleaning_pipeline import run_bronze_cleaning_pipeline


# COMMAND ----------

# DBTITLE 1,Widgets header
# MAGIC %md
# MAGIC ## Standard Configuration & Widgets

# COMMAND ----------

# DBTITLE 1,Pipeline environment widgets
# Environment where this notebook writes its output silver table
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Environment from which other pipeline silver/gold tables are read
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Environment from which reference/bronze tables are read (usually prod)
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# When true, quality check failures are logged as warnings instead of errors
dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# DBTITLE 1,Debug and log-level widgets
dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Logger setup
log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Notebook Configuration & Constants header
# MAGIC %md
# MAGIC ## Notebook Configuration & Constants

# COMMAND ----------

# DBTITLE 1,Source and Target
# @DevTeam -> This cell is dedicated to source and target configuration, only the schema should be modified by the user
CATALOG_SOURCE = f"{PIPELINE_READ_ENV}_bronze_hr"
CATALOG_TARGET = f"{PIPELINE_WRITE_ENV}_bronze_cleaned_hr"
SCHEMA = "usa_abs"

# Allowlist of tables to clean into bronze_cleaned. Empty set → clean the whole schema.
# USA Abs bronze materialises the business table with a _latest suffix. We clean it explicitly so
# the freshness pilot table (usa_abs_ingestion_freshness_all) — which also lives in the usa_abs
# bronze schema — is NOT swept into bronze_cleaned.
TABLES_TO_CLEAN: set[str] = {"usa_abs_latest"}

# Explicit primary key per cleaned table. The grain is a design property of the TARGET table, so
# it is declared here and applied deliberately after the write — NOT propagated from bronze via
# lineage (a cleaned table may re-grain / rename / drop key columns). Column names must match the
# CLEANED (post-rename) names. Empty / absent → no PK tag applied.
PRIMARY_KEYS: dict[str, list[str]] = {
    "usa_abs_latest": ["employee_id", "time_off_start", "time_off_type", "time_off_end"],
}

# COMMAND ----------

# DBTITLE 1,Specific configuration
# @DevTeam -> Schema-specific configuration — edit this cell when adapting the notebook to a new schema.
# For table-specific business rules, see the Specific Overrides cell.

# Boolean cast — {table_name: [col, ...]}
COLUMNS_BOOL: dict[str, list[str]] = {}

# Date cast — {table_name: {col_name: date_format | None}}
# date_format: explicit pattern (e.g. "dd/MM/yyyy") or None → DEFAULT_DATE_FORMATS
# Example:
# COLUMNS_DATE = {
#     "table_name": {
#         "date_col":  "dd/MM/yyyy",
#         "date_col2": None,
#     }
# }
COLUMNS_DATE: dict[str, dict[str, str | None]] = {}

# String cast — {table_name: [col, ...]}. Force these PII columns to string in bronze_cleaned.
# Applies to PII columns only, via the Layer 2 pass below.
COLUMNS_STRING: dict[str, list[str]] = {}

# Column renames — overrides the default rstrip("_") rule for specific columns.
# Keys: source column names (as tagged in bronze). Values: desired final names.
# The standard strip is applied first; these overrides are applied on top.
# Example:
# COLUMNS_RENAME = {
#     "table_name": {
#         "source_col": "target_col",
#     },
# }
COLUMNS_RENAME: dict[str, dict[str, str]] = {}

# COMMAND ----------

# DBTITLE 1,Specific Overrides – header
# MAGIC %md
# MAGIC ## Specific Overrides (Layer 3)
# MAGIC
# MAGIC The three-layer cleaning pipeline is centralised in `utils/bronze_cleaning_pipeline.py`. Layers 1 (trim + nullify) and 2 (type correction) are driven by the configuration dicts above.
# MAGIC
# MAGIC **The cell below is the only schema-specific code** — edit `apply_specific_cleaning` to add or change Layer 3 business rules. The function receives:
# MAGIC - `df` — the DataFrame, already trimmed (Layer 1) and typed (Layer 2)
# MAGIC - `table_name` — the table currently being processed
# MAGIC - `pii_cols` — the PII column names in scope

# COMMAND ----------

# MAGIC %md
# MAGIC ### usa\_abs\_latest — intra-file dedup
# MAGIC
# MAGIC The USA absence data comes from monthly Excel reports manually pulled from TriNet by HR.
# MAGIC Each file covers one site (Los Alamitos or International) for one month. When an absence
# MAGIC spans two months (e.g. start in March, end in April), it appears in both monthly files —
# MAGIC those cross-file duplicates are resolved upstream by the ingestion pipeline (DELTA mode,
# MAGIC keeps the row from the most recent extraction timestamp).
# MAGIC
# MAGIC However, TriNet also exports **status-change history within a single file**: the same
# MAGIC absence event (same employee, start, type, end) can appear twice with different
# MAGIC `leave_status_desc` values (e.g. `Paid` then `Cancelled`). These intra-file duplicates
# MAGIC share the same `_meta_extraction_timestamp`, so the pipeline's DELTA dedup cannot
# MAGIC distinguish them.
# MAGIC
# MAGIC The `apply_specific_cleaning` step resolves them with a `ROW_NUMBER` partitioned by the
# MAGIC 4-column PK `(employee_id, time_off_start, time_off_type, time_off_end)`, ordered by:
# MAGIC 1. `last_updated_date DESC` — most recent update wins
# MAGIC 2. Status priority (tie-breaker): `Cancelled (4) > Denied (3) > Paid (2) > Not Approved (1)`
# MAGIC
# MAGIC Only the rank-1 row is kept.

# COMMAND ----------

# DBTITLE 1,apply_specific_cleaning
# @DevTeam -> THIS IS THE CELL TO EDIT for table-specific cleaning logic (Layer 3).
# The function is called once per table inside process_pii_tag, after Layers 1 and 2.
# Add transforms inside the relevant table block. Non-targeted tables pass through unchanged.

def apply_specific_cleaning(
    df: DataFrame,
    table_name: str,
    pii_cols: list[str],
) -> DataFrame:
    """Apply table-specific business rule transformations (Layer 3).

    Called once per table inside process_pii_tag, after Layer 1 (string baseline)
    and Layer 2 (type correction). Columns are guaranteed to be trimmed and typed.

    Args:
        df:         DataFrame after Layers 1 and 2.
        table_name: Name of the table currently being processed.
        pii_cols:   PII column names in scope for this table.

    Returns:
        DataFrame with table-specific transformations applied.
    """
    _NAME_COLS = ["employee_name"]

    # -------------------------------------------------------------------------
    # usa_abs_latest — employee time-off / absence records (USA site).
    # PII STANDARD: employee_name, employee_id
    # -------------------------------------------------------------------------
    if table_name == "usa_abs_latest":
        lower_map = {c: f.lower(f.col(c)) for c in _NAME_COLS if c in pii_cols}
        if lower_map:
            df = df.withColumns(lower_map)

        # Resolve intra-file duplicates: TriNet exports status-change history
        # for the same absence event (e.g. Paid → Cancelled). Keep the most
        # recently updated row; break ties by terminal status priority.
        _STATUS_PRIORITY = {
            "Cancelled": 4, "Denied": 3, "Paid": 2, "Not Approved": 1,
        }
        status_priority = f.coalesce(
            *[f.when(f.col("leave_status_desc") == s, f.lit(p))
              for s, p in _STATUS_PRIORITY.items()],
            f.lit(0),
        )
        w = Window.partitionBy(
            "employee_id", "time_off_start", "time_off_type", "time_off_end",
        ).orderBy(
            f.to_date(f.col("last_updated_date"), "MM/dd/yyyy").desc_nulls_last(),
            status_priority.desc(),
        )
        df = (
            df.withColumn("_rn", f.row_number().over(w))
            .filter("_rn = 1")
            .drop("_rn")
        )

    return df

# COMMAND ----------

# DBTITLE 1,Pipeline Execution – header
# MAGIC %md
# MAGIC # Pipeline Execution

# COMMAND ----------

# DBTITLE 1,Run bronze cleaning pipeline
run_bronze_cleaning_pipeline(
    spark=spark,
    log=log,
    catalog_source=CATALOG_SOURCE,
    catalog_target=CATALOG_TARGET,
    schema=SCHEMA,
    tables_to_clean=TABLES_TO_CLEAN,
    primary_keys=PRIMARY_KEYS,
    columns_to_cast_to_bool=COLUMNS_BOOL,
    columns_to_cast_to_date=COLUMNS_DATE,
    columns_to_cast_to_string=COLUMNS_STRING,
    columns_to_rename=COLUMNS_RENAME,
    apply_specific_cleaning_fn=apply_specific_cleaning,
)
