# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Gold HR Fact Absence Day
# MAGIC %md
# MAGIC ## Gold HR Fact Absence Day
# MAGIC
# MAGIC Autonomous notebook: reads the silver fact_absence_day table, passes it through to gold,
# MAGIC and writes to `{pipeline_write_env}_gold_hr.absenteism.fact_absence_day`
# MAGIC (full overwrite).
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | Silver fact_absence_day | `{pipeline_read_env}_silver_hr` | `absenteism` | `fact_absence_day` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_gold_hr.absenteism.fact_absence_day`
# MAGIC
# MAGIC **Purpose**: Enriches the silver absence fact with employee workplace context (from `immat_monthly_history`)
# MAGIC to produce a `calendar_id` linking each absence to its site calendar.
# MAGIC
# MAGIC **Enrichment**: `calendar_id = workplace + '-' + absence_date` (FK to `dim_calendar`).
# MAGIC Join is temporal: employee's assignment at the month of the absence.
# MAGIC
# MAGIC **Resolved-months filter**: only absences whose month is covered by `immat_monthly_history` are included
# MAGIC (`absence_month <= MAX(year_month)` in immat). This avoids calendar_id containing only the date
# MAGIC (no workplace/country) when immat hasn't been updated yet for the most recent month.
# MAGIC When immat is refreshed, the next gold rebuild automatically picks up the newly resolved absences.
# MAGIC
# MAGIC **Write mode**: overwrite (full table rebuild).

# COMMAND ----------

# DBTITLE 1,Imports
from datetime import datetime
from pyspark.sql import Window
from pyspark.sql import functions as f

from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger
from data_asset.hr.utils.table_schema_map_utils import load_config

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# DBTITLE 1,Config: widgets & logging
# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config: source and target
# --- Source ---
SILVER_CATALOG = f"{PIPELINE_READ_ENV}_silver_hr"
SILVER_SCHEMA = "absenteism"
SILVER_TABLE = "fact_absence_day"
SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# --- Target ---
config = load_config(config_path="config/gold_fact_absence_day_column_mapping.yaml")
_target = config["target"]
GOLD_CATALOG = f"{PIPELINE_WRITE_ENV}_gold_hr"
GOLD_SCHEMA = _target["schema"]
GOLD_TABLE = _target["table"]

# --- Full table paths ---
GOLD_FULL_TABLE = f"{GOLD_CATALOG}.{GOLD_SCHEMA}.{GOLD_TABLE}"

# COMMAND ----------

# DBTITLE 1,Input data - Silver absences
df_silver = spark.table(SILVER_FULL_TABLE)

if LOG_LEVEL == "debug":
    count_source = df_silver.count()
    log.debug(f"[{SILVER_TABLE}] {count_source:,} rows read from silver")

# COMMAND ----------

# DBTITLE 1,Input data - Calendar
df_calendar = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold_hr.absenteism.calendar"
)

# COMMAND ----------

# DBTITLE 1,Input data - Absence types
df_absences_types = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold_hr.absenteism.dim_absence_type"
)

# COMMAND ----------

# DBTITLE 1,Input data - Immat history
df_immat = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold_hr.immat.immat_monthly_history"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Immat dedup & enrichment strategy
# MAGIC
# MAGIC An employee who transfers between sites during a month appears as **multiple rows**
# MAGIC in `immat_monthly_history` for the same `(user_id, year_month)`. We need exactly one
# MAGIC workplace per employee per month to build a deterministic `calendar_id`.
# MAGIC
# MAGIC **Window logic** — `partitionBy("user_id", "year_month").orderBy(…)`:
# MAGIC 1. **ACTIVE first**: assigns 0 to ACTIVE rows, 1 to others → the current assignment wins over a closed one.
# MAGIC 2. **Latest snapshot**: among rows with the same status, the most recent `reference_date` comes first → freshest data wins.
# MAGIC
# MAGIC `row_number() == 1` keeps only the top-ranked row per group.
# MAGIC
# MAGIC **Resolved-months filter**: absences are kept only when `absence_month <= max(immat.year_month)`.
# MAGIC This avoids producing a `calendar_id` with a null workplace (immat not yet refreshed for that month).
# MAGIC Once immat is updated, the next full rebuild automatically picks up those absences.

# COMMAND ----------

# DBTITLE 1,Prep. 1 - Dedup immat transfers
# join silver absences with immat to get workplace context at time of absence
# dedup immat: transfers create multiple rows per (user_id, year_month) — keep ACTIVE first, latest snapshot
_w_immat = Window.partitionBy("user_id", "year_month").orderBy(
    f.when(f.col("status") == "ACTIVE", 0).otherwise(1),
    f.col("reference_date").desc(),
)

df_immat_depup = (
    df_immat.withColumn("_rn", f.row_number().over(_w_immat))
    .filter(f.col("_rn") == 1)
    .select(
        "user_id",
        "year_month",
        "workplace",
        "workplace_country",
        "establishment",
        "country_of_company",
    )
)

if LOG_LEVEL == "debug":
    _count_before_dedup = df_immat.count()
    _count_after_dedup = df_immat_depup.count()
    log.debug(
        f"[{GOLD_TABLE}] immat: {_count_before_dedup:,} → {_count_after_dedup:,} "
        "rows after dedup ({_count_before_dedup - _count_after_dedup:,} "
        "transfer duplicates removed)"
    )

# only keep absences up to previous month / now
_today = datetime.now()
_max_year_month = f"{_today.year}-{_today.month - 1:02d}"
log.info(
    f"[{GOLD_TABLE}] immat coverage up to {_max_year_month} "
    "— filtering absences to resolved months only"
)

# COMMAND ----------

# DBTITLE 1,Prep. 2 - Forward and backward fill for immat workplace
# This will propagate the last known value forward and backward for each user
# TODO: fix immat monthly instead to remove possibility of holes in the data

w_ffill = (
    Window
    .partitionBy("user_id")
    .orderBy("year_month")
    .rowsBetween(Window.unboundedPreceding, Window.currentRow)
)

w_bfill = (
    Window
    .partitionBy("user_id")
    .orderBy("year_month")
    .rowsBetween(Window.currentRow, Window.unboundedFollowing)
)

df_immat_filled = (
    df_immat_depup.replace("Unknown", None)
    .withColumn(
        "workplace_ffill",
        f.last("workplace", ignorenulls=True).over(w_ffill)
    )
    .withColumn(
        "workplace_bfill",
        f.first("workplace", ignorenulls=True).over(w_bfill)
    )
    .withColumn(
        "workplace_country_ffill",
        f.last("workplace_country", ignorenulls=True).over(w_ffill)
    )
    .withColumn(
        "workplace_country_bfill",
        f.first("workplace_country", ignorenulls=True).over(w_bfill)
    )
    .withColumn(
        "workplace",
        f.coalesce("workplace_ffill", "workplace_bfill")
    )
    .withColumn(
        "workplace_country",
        f.coalesce("workplace_country_ffill", "workplace_country_bfill")
    )
    .drop(
        "year_month_dt",
        "workplace_ffill",
        "workplace_bfill",
        "workplace_country_ffill",
        "workplace_country_bfill",
    )
)

# COMMAND ----------

# DBTITLE 1,Tr. 1 - Enrich with immat
df_gold = (
    df_silver
    .withColumn("_year_month", f.date_format("absence_date", "yyyy-MM"))
    .filter(f.col("_year_month") <= _max_year_month)  # resolved months only
    .join(
        df_immat_filled,
        on=(f.col("id_group") == f.col("user_id"))
        & (f.col("_year_month") == df_immat_filled["year_month"]),
        how="left",
    )
    .withColumn(
        "calendar_id",
        f.concat_ws("-", f.col("workplace"), f.col("absence_date").cast("string")),
    )
    .drop("user_id", "year_month", "_year_month", "workplace")
)

if LOG_LEVEL == "debug":
    count_before_filter = df_silver.count()
    count_gold = df_gold.count()
    unmatched = df_gold.filter(f.col("calendar_id").isNull()).count()
    log.debug(
        f"[{GOLD_TABLE}] {count_gold:,} rows after immat enrichment ({unmatched:,} "
        "without immat match → calendar_id NULL)"
    )

# COMMAND ----------

# DBTITLE 1,Tr. 2 - Enrich with absence types
# Enrich with absence category from dim_absence_type ---
# Use workplace country or fallback on caountry_of_company to
# obtain standard absence types - this is to handle the case
# of detached workers


def normalize_raw_category(col):
    """Upper-case, strip non Unicode letters and digits (replaced with spaces),
    and trim."""
    return f.upper(
        f.trim(
            f.regexp_replace(f.regexp_replace(col, r"[^\p{L}\p{N}]", " "), r" +", " ")
        )
    )


_dim_types = df_absences_types.select(
    f.col("country").alias("_dim_country"),
    normalize_raw_category(f.col("absence_type_code")).alias("absence_type_code_upper"),
    "absence_category",
).distinct()

df_gold_w_std_abs_types = (
    df_gold.withColumn(
        "absence_type_code_upper",
        normalize_raw_category(f.col("absence_type_code")),
    )
    # Priority 1: match on workplace_country
    .join(
        _dim_types.select(
            f.col("_dim_country").alias("workplace_country"),
            "absence_type_code_upper",
            f.col("absence_category").alias("_cat_wp"),
        ),
        on=["workplace_country", "absence_type_code_upper"],
        how="left",
    )
    # Priority 2: fallback on country_of_company
    .join(
        _dim_types.select(
            f.col("_dim_country").alias("country_of_company"),
            "absence_type_code_upper",
            f.col("absence_category").alias("_cat_cc"),
        ),
        on=["country_of_company", "absence_type_code_upper"],
        how="left",
    )
    .withColumn("absence_category", f.coalesce("_cat_wp", "_cat_cc"))
    .drop("absence_type_code_upper", "_cat_wp", "_cat_cc")
)

# COMMAND ----------

# DBTITLE 1,Tr. 3 - Use calendar to filter to working days
df_gold_w_calendar = (
    df_gold_w_std_abs_types.join(
        df_calendar.select("calendar_id", "is_working_day"),
        on="calendar_id",
        how="left",
    )
    .filter(f.col("is_working_day"))
    .drop("is_working_day")
)

if LOG_LEVEL == "debug":
    count_excluded = count_before_filter - count_gold
    date_only = df_gold_w_calendar.filter(~f.col("calendar_id").rlike(".*-.*-.*-.*")).count()
    log.debug(
        f"[{GOLD_TABLE}] {count_gold:,} rows after enrichment ({count_excluded:,} excluded "
        f"— month not yet in immat, {date_only:,} still without workplace)"
    )

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
def _build_extra_red_results(
    df_gx: SparkDFDataset,
) -> list[ExpectationSuiteValidationResult]:
    return [
        # absence_duration_min >= 0
        df_gx.expect_column_values_to_be_between(
            column="absence_duration_min",
            min_value=0,
        ),
        # absence_day_value in [0, 1] (nullable — only non-null are checked)
        df_gx.expect_column_values_to_be_between(
            column="absence_day_value",
            min_value=0,
            max_value=1,
            mostly=1.0,
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_gold_w_calendar,
    config=config,
    full_table_path=GOLD_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=False,
    drop_null_pk_rows=False,
    overwrite_schema=True,
    cluster_cols="source, id_group",
    is_debug=LOG_LEVEL == "debug",
)
