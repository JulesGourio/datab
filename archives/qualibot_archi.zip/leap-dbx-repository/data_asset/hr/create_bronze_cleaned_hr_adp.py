# Databricks notebook source
# DBTITLE 1,Header – Notebook Documentation
# MAGIC %md
# MAGIC # [HR] - ADP Payroll Bronze to Bronze Clean
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC **Description :**
# MAGIC Charge la table de paie ADP du schéma bronze, applique le nettoyage PII-aware
# MAGIC (trim/nullify par niveau de sensibilité) et écrit la table nettoyée dans
# MAGIC `bronze_cleaned`. La propagation des tags PII (dont `_meta_id` et `matricule`
# MAGIC taggés `standard`) et des commentaires est gérée par la pipeline.
# MAGIC
# MAGIC **Entrée :** `{PIPELINE_READ_ENV}_bronze_hr.adp_payroll.adp_data_latest`
# MAGIC **Sortie :** `{PIPELINE_WRITE_ENV}_bronze_cleaned_hr.adp_payroll.adp_data_latest`
# MAGIC
# MAGIC **Déclenché par :** D_0_adp_ingestion (run_job_task en fin de chaîne).
# MAGIC
# MAGIC **Notes :**
# MAGIC - `_meta_id` (= `matricule-mois-année`) reste tagué `standard` → hashé/masqué par
# MAGIC   l'ABAC de `bronze_cleaned_hr` selon le niveau d'accès du grantee.
# MAGIC - Typage (dans `post_clean`, exécuté une seule fois) : dates `dd/MM/yyyy` -> DATE ;
# MAGIC   montants/salaires/coûts (format FR virgule) -> decimal(15,2), % -> decimal(9,4),
# MAGIC   heures sup -> decimal(9,2). Les libellés / grades / motifs / base Cadre-ETAM
# MAGIC   restent en `string`. Matricule -> strip des zéros de tête (match immat.user_id).

# COMMAND ----------

# DBTITLE 1,Imports
import sys
from pyspark.sql import functions as f
from pyspark.sql import DataFrame

dbutils.widgets.removeAll()

# Add bundle_root to sys.path for leap_utils imports (when running from an Asset Bundle)
dbutils.widgets.text("bundle_root", "")
bundle_root = dbutils.widgets.get("bundle_root")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

from leap_utils.common import logger

from utils.bronze_cleaning_pipeline import run_bronze_cleaning_pipeline

# COMMAND ----------

# DBTITLE 1,Pipeline environment widgets
# Aligned with adp_hr_ingestion bundle widget convention (UPPERCASE)
dbutils.widgets.text("PIPELINE_WRITE_ENV", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("PIPELINE_WRITE_ENV")

dbutils.widgets.text("PIPELINE_READ_ENV", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("PIPELINE_READ_ENV")

dbutils.widgets.text("REFERENCE_READ_ENV", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("REFERENCE_READ_ENV")

dbutils.widgets.text("target_schema", "adp_payroll")
TARGET_SCHEMA = dbutils.widgets.get("target_schema")

# COMMAND ----------

# DBTITLE 1,Log-level widget
dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Source and Target
CATALOG_SOURCE = f"{PIPELINE_READ_ENV}_bronze_hr"
CATALOG_TARGET = f"{PIPELINE_WRITE_ENV}_bronze_cleaned_hr"
SCHEMA = TARGET_SCHEMA  # adp_payroll

# Allowlist — table de paie ADP (latest). adp_ingestion_freshness_all exclue (monitoring).
TABLES_TO_CLEAN: set[str] = {
    "adp_data_latest",
}

# Clé primaire par table nettoyée (noms POST-rename ; ici inchangés).
PRIMARY_KEYS: dict[str, list[str]] = {
    "adp_data_latest": ["matricule", "mois_de_paie", "annee_de_paie"],
}

# COMMAND ----------

# DBTITLE 1,Specific cast configuration (baseline string)
# Cast booléen — {table_name: [col, ...]}
COLUMNS_BOOL: dict[str, list[str]] = {}

# Cast date — {table_name: {col_name: date_format | None}}
# NB : apply_type_casts ne caste que les colonnes TAGUÉES PII (columns=pii_cols).
# Les dates ADP ne sont PAS taguées -> on les caste en Layer 3 (apply_specific_cleaning),
# comme employeeid chez greythr. Ce dict reste donc vide.
COLUMNS_DATE: dict[str, dict[str, str | None]] = {}

# Dates ADP au format dd/MM/yyyy (lu depuis la table LZ). Castées en DATE en Layer 3.
# Exclues : periode_de_paie_couverte_... (plage "dd/MM/yyyy - dd/MM/yyyy", reste string),
# mois_de_paie / annee_de_paie (composants de période, string, PK).
DATE_COLUMNS_DMY: list[str] = [
    "date_d_entree_dans_la_societe",
    "date_d_anciennete",
    "date_de_sortie_dans_la_societe",
    "date_deffet_du_salaire_theorique",
    "date_deffet_de_laugmentation",
    "date_deffet_des_de_bonus",
]
DATE_FORMAT_DMY = "dd/MM/yyyy"

# Montants / salaires / coûts ADP (format FR "1234,56") -> decimal(15,2).
# Cast via try_cast(replace(col, ',', '.') as decimal) en post_clean (idempotent).
# Les libellés / grades / motifs / base Cadre-ETAM restent en string (texte).
DECIMAL_AMOUNT_COLS: list[str] = [
    "salaire_de_base_annuel_theorique_a_etp_100",
    "salaire_de_base_etp_mensuel",
    "salaire_de_base_brut_reellement_paye_sur_la_periode",
    "montant_de_laugmentation_1",
    "montant_de_laugmentation_2",
    "bonus_montant_de_la_rubrique_1",
    "bonus_montant_de_la_rubrique_2",
    "bonus_montant_de_la_rubrique_3",
    "bonus_montant_de_la_rubrique_4",
    "bonus_montant_de_la_rubrique_5",
    "bonus_montant_de_la_rubrique_6",
    "bonus_montant_de_la_rubrique_7",
    "bonus_montant_de_la_rubrique_8",
    "bonus_montant_de_la_rubrique_9",
    "bonus_montant_de_la_rubrique_10",
    "montant_de_prime_exceptionnelle_payee_brut",
    "indemnites_de_depart_soumis_a_cotisations",
    "deplacements_soumis_a_cotisations",
    "montant_paye_au_titre_des_heures_supplementaires",
    "avantage_en_nature_montant_de_la_rubrique_1",
    "avantage_en_nature_montant_de_la_rubrique_2",
    "avantage_en_nature_montant_de_la_rubrique_3",
    "brut_securite_sociale",
    "contributions_sociales_part_employeur",
    "cout_total_employeur_reel",
]
DECIMAL_AMOUNT_TYPE = "decimal(15,2)"

# Pourcentages -> decimal(9,4).
DECIMAL_PCT_COLS: list[str] = ["daugmentation_total", "total_de_bonus_cible"]
DECIMAL_PCT_TYPE = "decimal(9,4)"

# Compteurs d'heures (confidential) -> decimal(9,2).
DECIMAL_HOURS_COLS: list[str] = ["nombre_dheures_supplementaires"]
DECIMAL_HOURS_TYPE = "decimal(9,2)"

# Cast string — {table_name: [col, ...]}
COLUMNS_STRING: dict[str, list[str]] = {}

# Renommage de colonnes — surcharge la règle rstrip("_") par défaut.
COLUMNS_RENAME: dict[str, dict[str, str]] = {}

# COMMAND ----------

# DBTITLE 1,apply_specific_cleaning (Layer 3)
def apply_specific_cleaning(
    df: DataFrame,
    table_name: str,
    pii_cols: list[str],
) -> DataFrame:
    """Règles métier spécifiques (Layer 3) pour la paie ADP.

    ⚠️ Appelée UNE FOIS PAR NIVEAU DE TAG PII présent dans la table (standard, confidential,
    ...). Toute transformation ici doit donc être IDEMPOTENTE. Les casts non-idempotents
    (dates) sont faits dans post_clean (exécuté une seule fois, avant save).
    Point d'extension idempotent pour de futures règles métier.
    """
    return df

# COMMAND ----------

# DBTITLE 1,post_clean — transformations idempotentes (exécutées une seule fois)
def post_clean(dfs_clean_all, cleaner):
    """Transformations PII-indépendantes, appliquées UNE SEULE FOIS avant save.

    - Cast des dates ADP (dd/MM/yyyy) en DATE. Fait ici (et non en Layer 3) car Layer 3 est
      ré-exécuté une fois par niveau de tag -> un 2e try_to_date sur une colonne déjà DATE la
      viderait. Garde-fou supplémentaire : on ne caste que si la colonne est string.
    - Matricule : strip des zéros de tête -> forme canonique qui matche immat.user_id
      (référentiel maître, sans zéros de tête, comme ron/horoquartz/kelio). Idempotent.
    `_meta_id` n'est pas transformé ici : protégé par son tag ABAC (propagé depuis la bronze,
    posé par update_meta_tags).
    """
    df = dfs_clean_all.get("adp_data_latest")
    if df is not None:
        # Matricule -> canonique (sans zéros de tête) : "00000003" -> "3", "0" -> "0".
        if "matricule" in df.columns:
            df = df.withColumn("matricule", f.regexp_replace(f.col("matricule"), r"^0+(?=.)", ""))
        dtypes = dict(df.dtypes)
        # Dates dd/MM/yyyy -> DATE (string uniquement, idempotent).
        for col_name in DATE_COLUMNS_DMY:
            if col_name in df.columns and dtypes.get(col_name) == "string":
                df = df.withColumn(
                    col_name,
                    f.expr(f"try_to_date(`{col_name}`, '{DATE_FORMAT_DMY}')"),
                )
        # Montants / % / heures (format FR "1234,56") -> decimal via try_cast
        # (null si non numérique ; les libellés/grades/motifs restent en string).
        for cols, dtype in (
            (DECIMAL_AMOUNT_COLS, DECIMAL_AMOUNT_TYPE),
            (DECIMAL_PCT_COLS, DECIMAL_PCT_TYPE),
            (DECIMAL_HOURS_COLS, DECIMAL_HOURS_TYPE),
        ):
            for col_name in cols:
                if col_name in df.columns and dtypes.get(col_name) == "string":
                    df = df.withColumn(
                        col_name,
                        f.expr(f"try_cast(replace(`{col_name}`, ',', '.') as {dtype})"),
                    )
        dfs_clean_all["adp_data_latest"] = df
    return dfs_clean_all

# COMMAND ----------

# DBTITLE 1,Run bronze cleaning pipeline
run_bronze_cleaning_pipeline(
    spark=spark,
    log=log,
    catalog_source=CATALOG_SOURCE,
    catalog_target=CATALOG_TARGET,
    schema=SCHEMA,
    tables_to_clean=TABLES_TO_CLEAN,
    primary_keys=PRIMARY_KEYS,
    columns_to_cast_to_bool=COLUMNS_BOOL,
    columns_to_cast_to_date=COLUMNS_DATE,
    columns_to_cast_to_string=COLUMNS_STRING,
    columns_to_rename=COLUMNS_RENAME,
    apply_specific_cleaning_fn=apply_specific_cleaning,
    post_clean_fn=post_clean,
)
