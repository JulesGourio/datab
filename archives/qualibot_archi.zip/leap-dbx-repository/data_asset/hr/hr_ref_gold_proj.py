# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # HR REFERENTIAL GOLD
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to build gold data asset for HR Referential.
# MAGIC - 1st STEP : preparing a gold daily history based on silver one
# MAGIC - 2nd STEP : preparing a proj monthly history based on end of each month
# MAGIC - 3rd STEP : enrich and transform proj monthly history
# MAGIC - 4th STEP : keep secure a plain text version of the gold daily history
# MAGIC - 5th STEP : save the tables
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - hr data asset.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - sd_{pipeline_read_env}_bronze.token_vault.pii_data
# MAGIC - {pipeline_read_env}_silver.hr.hr_workforce_silver_stack_history
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.hr.hr_workforce_gold_history
# MAGIC - sd_{pipeline_write_env}_gold.hr.hr_workforce_gold_history
# MAGIC - {pipeline_write_env}_proj.hr.hr_workforce_proj_monthly_history
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
import great_expectations as gx
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.validation import gx_validation
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.dropdown("run_mode", "delta", ["init", "delta"])

try:
    _legacy_run_mode = dbutils.widgets.get("run_mode")
except:
    _legacy_run_mode = None

dbutils.widgets.dropdown(
    "gold_run_mode",
    _legacy_run_mode if _legacy_run_mode else "delta",
    ["init", "delta"],
)

GOLD_RUN_MODE = dbutils.widgets.get("gold_run_mode")
RUN_MODE = GOLD_RUN_MODE

# For Status Quality check
dbutils.widgets.text(
    "status_change_alert_threshold_pct", "1.0"
)  # percentage or whole number
dbutils.widgets.text(
    "status_change_min_population", "100"
)  # minimum of common IDs between D & D-1 for evaluation
dbutils.widgets.dropdown("status_change_alert_mode", "ratio", ["ratio", "count"])

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_CATALOG = f"{PIPELINE_READ_ENV}_silver"
SILVER_SCHEMA = "hr"

REPORT_RH_SILVER_STACK_TABLE = (
    f"{SILVER_CATALOG}.{SILVER_SCHEMA}.hr_workforce_silver_stack_history"
)

TOKEN_VAULT_TABLE = f"sd_{PIPELINE_READ_ENV}_bronze.token_vault.pii_data"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# attributes for table REPORT_RH_SILVER_STACK_TABLE
SILVER_ATTRS_DICT = {
    "string_cols": [],
    "float_cols": [],
    "columns_to_drop": [
        "Conv__Category",
        "Default_language",
        "Working_day",
        "Matrix_manager",
        "Custom_manager",
        "Second_manager",
        "Time_manager",
        "Payroll_category",
        "Payroll_Sync",
        "HQA_Service_code",
    ],
    "columns_to_trim": [
        "Job",
        "Category",
        "Company",
        "Establishment",
        "Workplace",
        "Organization",
        "Department",
        "Service",
        "Reason_for_leaving",
        "Workplace_country",
        "Conventional_category_name",
        "Working_day",
        "Country",
        "Nationality",
        "External_company",
        "Job_family",
        "Job_speciality",
        "Category",
    ],
    "columns_to_replace_nulls_by_unknown": [
        "Job",
        "Category",
        "Company",
        "Establishment",
        "Workplace",
        "Department",
        "Service",
        "Conventional_category_name",
        "Working_day",
        "Country",
        "Nationality",
        "Job_family",
        "Job_speciality",
        "Category",
    ],
    "date_cols": ["Company_Seniority_Date", "Last_hire_date", "End_Date"],
    "primary_key": "User_ID,_leap_extraction_date",
    "notnull_cols": "User_ID,First_name,Last_name",
    "cluster_cols": "User_ID,_leap_extraction_date",
    "columns_to_hash": [
        "User_ID",
        "First_name",
        "Last_name",
        "Email",
        "IT_Account",
        "ID_Local",
        "Maiden_Name",
        "Business_Phone",
        "Cell_Phone",
    ],
    "columns_to_clean_before_hashing": ["User_ID", "Email"],
    "date_to_year": ["Birth_date"],
}

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

GOLD_CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
GOLD_SD_CATALOG = f"sd_{PIPELINE_WRITE_ENV}_gold"
GOLD_SCHEMA = "hr"
PROJ_CATALOG = f"{PIPELINE_WRITE_ENV}_proj"
PROJ_SCHEMA = "hr"

REPORT_RH_GOLD_TABLE = f"{GOLD_CATALOG}.{GOLD_SCHEMA}.hr_workforce_gold_history"
REPORT_RH_GOLD_TABLE_PLAIN = (
    f"{GOLD_SD_CATALOG}.{GOLD_SCHEMA}.hr_workforce_gold_history"
)
REPORT_RH_PROJ_TABLE_MONTHLY = (
    f"{PROJ_CATALOG}.{PROJ_SCHEMA}.hr_workforce_proj_monthly_history"
)
REPORT_RH_PROJ_TABLE_AGGREGATED = (
    f"{PROJ_CATALOG}.{PROJ_SCHEMA}.hr_workforce_proj_aggregated"
)
PROJ_EMAIL_WORKPLACE = (
    f"{PROJ_CATALOG}.{PROJ_SCHEMA}.hr_workforce_proj_email_to_workplace"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# MAGIC %md
# MAGIC #### for the Gold History

# COMMAND ----------

TABLE_GOLD_FIRST_COLS = {
    "_meta_stack_row_id": "STRING COMMENT 'STACK UNIQUE ID GENERATED ALWAYS AS IDENTITY'",
    "_meta_ID": "STRING",
    "_meta_extraction_timestamp": "TIMESTAMP",
    "_meta_ingestion_timestamp": "TIMESTAMP",
    "_meta_file_name": "STRING",
    "_meta_file_mode": "STRING",
    "_meta_file_path": "STRING",
    "User_ID": "STRING",
    "_leap_extraction_date": "DATE",
    "_leap_year_month_extraction_date": "STRING",
    "First_name": "STRING",
    "Last_name": "STRING",
    "Email": "STRING",
    "IT_Account": "STRING",
    "ID_Local": "STRING",
    "Maiden_Name": "STRING",
}

GOLD_CLUSTER_COLS_STR = "User_ID,_leap_extraction_date,_leap_year_month_extraction_date"
GOLD_PK_COLUMNS_LIST = ["User_ID"]  # PRIMARY KEY OF THE LATEST (aka id_column_list)
GOLD_PK_NAME = "hr_workforce_gold_history_pk"
GOLD_TIMELINE_COL = "_leap_extraction_date"
GOLD_SK_COLUMNS_LIST = GOLD_PK_COLUMNS_LIST + [
    GOLD_TIMELINE_COL
]  # SURROGATE KEY , PRIMARY KEY OF THE HISTORY
GOLD_SK_COLUMNS_STR = ", ".join(GOLD_SK_COLUMNS_LIST)

# COMMAND ----------

# MAGIC %md
# MAGIC #### for the Proj History

# COMMAND ----------

TABLE_PROJ_FIRST_COLS = {
    "_meta_stack_row_id": "BIGINT COMMENT 'STACK UNIQUE ID GENERATED ALWAYS AS IDENTITY'",
    "User_ID": "STRING",
    "_leap_extraction_date": "DATE",
    "_leap_year_month_extraction_date": "STRING",
    "First_name": "STRING",
    "Last_name": "STRING",
    "Email": "STRING",
    "IT_Account": "STRING",
    "ID_Local": "STRING",
    "Maiden_Name": "STRING",
}

PROJ_MONTHLY_CLUSTER_COLS_STR = "User_ID,_leap_year_month_extraction_date"
PROJ_MONTHLY_PK_COLUMNS_LIST = [
    "User_ID"
]  # PRIMARY KEY OF THE LATEST (aka id_column_list)
PROJ_MONTHLY_PK_NAME = "hr_workforce_proj_monthly_history"
PROJ_MONTHLY_TIMELINE_COL = "_leap_year_month_extraction_date"
PROJ_MONTHLY_SK_COLUMNS_LIST = PROJ_MONTHLY_PK_COLUMNS_LIST + [
    PROJ_MONTHLY_TIMELINE_COL
]  # SURROGATE KEY , PRIMARY KEY OF THE HISTORY
PROJ_MONTHLY_SK_COLUMNS_STR = ", ".join(PROJ_MONTHLY_SK_COLUMNS_LIST)

# PRIMARY KEY for email_to_workplace table
PROJ_EMAIL_WORKPLACE_PK_NAME = "hr_workforce_proj_email_to_workplace"
PROJ_EMAIL_WORKPLACE_PK_COLUMNS_LIST = ["email"]
PROJ_EMAIL_WORKPLACE_PK_COLUMNS_STR = "email"
PROJ_EMAIL_WORKPLACE_FIRST_COLS = {
    "date_end": "DATE",
    "email": "STRING",
    "country": "STRING",
    "workplace": "STRING",
}

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# MAGIC %md
# MAGIC #### Common global variables

# COMMAND ----------

if (table_utils.UnityCatalogCheckTableExists(REPORT_RH_GOLD_TABLE)) and (
    RUN_MODE == "delta"
):
    RUN_JOB_ON_LATEST = True
    MODE = "append"
    FORCE_REINITIALIZATION = False
else:
    RUN_JOB_ON_LATEST = False
    MODE = "overwrite"
    FORCE_REINITIALIZATION = True

# Flag to avoid processing Empty Dataframe
EMPTY_DATAFRAME_FLAG = False

#
UPDATE_COUNT = None
THE_ORIGIN = "1970-01-01"
THE_MAX_DATE = "2099-12-31"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"RUN_MODE is:  {RUN_MODE}")
log.info(f"RUN_JOB_ON_LATEST is:  {RUN_JOB_ON_LATEST}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"GOLD_SCHEMA is:  {GOLD_SCHEMA}")
log.info(f"REPORT_RH_SILVER_STACK_TABLE is:  {REPORT_RH_SILVER_STACK_TABLE}")
log.info(f"REPORT_RH_GOLD_TABLE is:  {REPORT_RH_GOLD_TABLE}")
log.info(f"REPORT_RH_PROJ_TABLE_MONTHLY is:  {REPORT_RH_PROJ_TABLE_MONTHLY}")
log.info(f"MODE is:  {MODE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Tables Read

# COMMAND ----------

# Upload REPORT_RH_SILVER_STACK_TABLE
df_report_rh_silver_stack = spark.read.table(f"{REPORT_RH_SILVER_STACK_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------


def last_day_of_month(date_col):
    """
    Returns the last day of the month for the given date column.

    :param date_col: A Spark SQL Column representing a date.
    :type date_col: Column
    :return: A Spark SQL Column containing the last day of the month for each date in the input column.
    :rtype: Column
    """
    return f.last_day(date_col)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - If RUN_JOB_ON_LATEST Filter silver history table

# COMMAND ----------

# check job type
if RUN_JOB_ON_LATEST:
    log.info(f"Filtering current silver history table.")
    df_target = spark.read.table(f"{REPORT_RH_GOLD_TABLE }")

    latest_extraction_date = df_target.select(
        f.date_add(f.max("_leap_extraction_date"), 1).alias("Max_Start_Validity")
    ).first()[0]
    print(latest_extraction_date)

    if latest_extraction_date is None:
        latest_target_extraction_timestamp = THE_ORIGIN
        RUN_JOB_ON_LATEST = False
        log.info(
            f"the latest_extraction_date in {REPORT_RH_GOLD_TABLE} is None, taking : {latest_extraction_date}"
        )
    else:
        log.info(
            f"the latest_extraction_date in {REPORT_RH_GOLD_TABLE} is : {latest_extraction_date}"
        )

    # Filter input  on delta loads
    df_report_rh_gold_history_update = df_report_rh_silver_stack.filter(
        f.col("_meta_extraction_timestamp") > latest_extraction_date
    )

    UPDATE_COUNT = df_report_rh_gold_history_update.count()
    log.debug(f"Current history  to update count {UPDATE_COUNT} rows.")
    if UPDATE_COUNT == 0:
        log.info(f"the table {REPORT_RH_GOLD_TABLE} is already up to date")
        EMPTY_DATAFRAME_FLAG = True
else:
    log.info(f"Reading full silver history table.")
    RUN_JOB_ON_LATEST = False
    df_report_rh_gold_history_update = df_report_rh_silver_stack
    UPDATE_COUNT = df_report_rh_gold_history_update.count()
    log.debug(f"Full history count {UPDATE_COUNT} rows.")

df_report_rh_gold_history = df_report_rh_silver_stack

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Calculate the monthly history with last extraction of each month

# COMMAND ----------

# Window to retrieve the last extraction of month N
window_spec_last = Window.partitionBy(
    "User_ID", "_leap_year_month_extraction_date"
).orderBy(f.col("_leap_extraction_date").desc())

# Retrieve the last extraction for each user each month
df_report_rh_proj_history_monthly = (
    df_report_rh_gold_history.withColumn(
        "row_number", f.row_number().over(window_spec_last)
    )
    .filter(f.col("row_number") == 1)
    .drop("row_number")
)

monthly_table_cols = df_report_rh_proj_history_monthly.columns
forced_included_cols = ["_meta_stack_row_id"]
exposed_column_list = forced_included_cols + [
    column for column in monthly_table_cols if (not column.startswith("_meta"))
]
df_report_rh_proj_history_monthly = df_report_rh_proj_history_monthly.select(
    *exposed_column_list
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Calculate a temporary reference date that will serve for Status update rule

# COMMAND ----------

df_report_rh_proj_history_monthly_ref = df_report_rh_proj_history_monthly.withColumn(
    "_leap_reference_date",
    f.when(
        (f.year("_leap_extraction_date") == f.year(f.current_date()))
        & (f.month("_leap_extraction_date") == f.month(f.current_date())),
        f.current_date(),  # If it is in the current month -> today()
    ).otherwise(
        last_day_of_month(
            "_leap_extraction_date"
        )  # Otherwise, last day of the month of _leap_extraction_date
    ),
)

df_report_rh_proj_history_monthly_ref = (
    df_report_rh_proj_history_monthly_ref.withColumn(
        "_leap_reference_date_1",
        last_day_of_month(
            f.add_months(f.col("_leap_reference_date"), -1)
        ),  # Last day of the previous month
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Calculate a temporary monthly history with first extraction of each month

# COMMAND ----------

# Window to retrieve the first extraction of month N
window_spec_first = Window.partitionBy(
    "User_ID", "_leap_year_month_extraction_date"
).orderBy(f.col("_leap_extraction_date").asc())

# Calculate a temporary Dataframe with the first extraction of the month N+1
df_report_rh_proj_history_monthly_beginning = (
    df_report_rh_gold_history.withColumn(
        "row_number", f.row_number().over(window_spec_first)
    )
    .filter(f.col("row_number") == 1)
    .drop("row_number")
)

df_report_rh_proj_history_monthly_beginning = (
    df_report_rh_proj_history_monthly_beginning.withColumn(
        "_leap_year_month_extraction_date_N_1",
        f.date_format(f.add_months(f.col("_leap_extraction_date"), -1), "yyyy-MM"),
    )
)

beginning_table_cols = df_report_rh_proj_history_monthly_beginning.columns
forced_included_cols = ["_meta_stack_row_id"]
exposed_column_list = forced_included_cols + [
    column for column in beginning_table_cols if (not column.startswith("_meta"))
]
df_report_rh_proj_history_monthly_beginning = (
    df_report_rh_proj_history_monthly_beginning.select(*exposed_column_list)
)

df_report_rh_proj_history_monthly_beginning = table_utils.add_prefix_to_columns(
    df_report_rh_proj_history_monthly_beginning, "_tmp"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC - Transformations 1 to 9 concern the table proj monthly history
# MAGIC - Transformation 10 concern the table gold daily history
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------


def move_dataframe_cols_first(df: SparkDataFrame, cols_to_move: list) -> SparkDataFrame:
    """
    Move specified columns to the beginning of the DataFrame.

    :param df: The Spark DataFrame to modify.
    :type df: SparkDataFrame
    :param cols_to_move: A list of column names to move to the beginning of the DataFrame.
    :type cols_to_move: list
    :return: A new Spark DataFrame with the specified columns moved to the front.
    :rtype: SparkDataFrame
    """
    first_cols = cols_to_move
    other_cols = [c for c in df.columns if c not in first_cols]
    df_new = df.select(*first_cols, *other_cols)
    return df_new


# COMMAND ----------


def remove_prefix_from_columns(df, prefix):
    """
    Rename columns in the DataFrame by removing the specified prefix if it is present.

    :param df: The Spark DataFrame to modify.
    :type df: SparkDataFrame
    :param prefix: The prefix to remove from the column names.
    :type prefix: str
    :return: A new Spark DataFrame with the specified prefix removed from the column names.
    :rtype: SparkDataFrame
    """
    # Rename columns by removing the prefix if it is present
    new_column_names = [
        (col[len(prefix) :] if col.startswith(prefix) else col) for col in df.columns
    ]

    # Use toDF to rename the columns of the DataFrame
    df = df.toDF(*new_column_names)

    return df


# COMMAND ----------

# MAGIC %md
# MAGIC ## PII - Functions

# COMMAND ----------


def decrypt_hash_for_column(
    df_token_vault: SparkDataFrame, df_anonymized: SparkDataFrame, col_to_decrypt: str
):
    """
    Decrypt the hash of a column from the token vault

    :param df_token_vault: The token vault dataframe
    :type df_token_vault: DataFrame
    :param df_sd: The table to decrypt
    :type df_sd: DataFrame
    :param col_to_hash: The column to decrypt
    :type col_to_hash: str
    :return: The input table with the corresponding column decrypt
    """
    # Decrypt the column
    df_with_decrypted_column = df_anonymized.join(
        df_token_vault.withColumnRenamed("HashedValue", col_to_decrypt),
        on=col_to_decrypt,
        how="left",
    )

    df_with_decrypted_column = df_with_decrypted_column.drop(col_to_decrypt)
    df_with_decrypted_column = df_with_decrypted_column.withColumnRenamed(
        "OriginalValue", col_to_decrypt
    )

    return df_with_decrypted_column


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - business rule - End_Date and Reason_for_leaving enrichment
# MAGIC
# MAGIC - Left Join with 1st extraction of next month if exists
# MAGIC - keep the 1st not null value for "End_Date" between (1st extraction of next month, last extraction of current month)
# MAGIC - keep the 1st not null value for "Reason_for_leaving" between (1st extraction of next month, last extraction of current month)

# COMMAND ----------

df_transfo_input_monthly = df_report_rh_proj_history_monthly_ref

# Join the data from the last extraction of month N with the data from the first extraction of month N+1
df_report_rh_proj_history_monthly_end_date = df_transfo_input_monthly.alias(
    "base"
).join(
    df_report_rh_proj_history_monthly_beginning.alias("next"),
    (f.col("base.User_ID") == f.col("next._tmp_User_ID"))
    & (
        f.col("base._leap_year_month_extraction_date")
        == f.col("next._tmp__leap_year_month_extraction_date_N_1")
    ),
    how="left",
)

# Business rule : adjust End_Date and Reason_for_leaving
df_report_rh_proj_history_monthly_end_date = (
    df_report_rh_proj_history_monthly_end_date.withColumn(
        "End_Date", f.coalesce(f.col("_tmp_End_Date"), f.col("End_Date"))
    )
    .withColumn(
        "Reason_for_leaving",
        f.coalesce(f.col("_tmp_Reason_for_leaving"), f.col("Reason_for_leaving")),
    )
    .withColumn(
        "_leap_year_month_end_date", f.date_format(f.col("End_Date"), "yyyy-MM")
    )
)

table_cols = df_report_rh_proj_history_monthly_end_date.columns
cols_to_drop = [column for column in table_cols if (column.startswith("_tmp_"))]
df_report_rh_proj_history_monthly_end_date = (
    df_report_rh_proj_history_monthly_end_date.drop(*cols_to_drop)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - business rule - check Last_hire_date on beginning of next month
# MAGIC
# MAGIC - For a given month, identify at 1st day of next month new hired people that were not present at end of month and whose last_hire_date in in current given month
# MAGIC - Append this dataset to last extraction of current month
# MAGIC - Example : a new hired people with last_hire_date at 2024-09-01 , but appearing only starting as of 2024-10-01, will be appended to dataset of 2024-09
# MAGIC

# COMMAND ----------

# New hired with hire_date at previous month
df_report_rh_proj_history_monthly_start_date_in_future_new_hired = (
    df_report_rh_proj_history_monthly_beginning.alias("next")
    .join(
        df_report_rh_proj_history_monthly_end_date.alias("base"),
        (f.col("base.User_ID") == f.col("next._tmp_User_ID"))
        & (
            f.col("base._leap_year_month_extraction_date")
            == f.col("next._tmp__leap_year_month_extraction_date_N_1")
        ),
        how="leftanti",
    )
    .filter(f.col("next._tmp__leap_year_month_last_hire_date").isNotNull())
    .filter(
        (
            f.col("next._tmp__leap_year_month_last_hire_date")
            == f.col("next._tmp__leap_year_month_extraction_date_N_1")
        )
    )
    .filter(f.dayofmonth(f.col("next._tmp__leap_extraction_date")) == 1)
)

df_report_rh_proj_history_monthly_start_date_in_future_new_hired = (
    remove_prefix_from_columns(
        df_report_rh_proj_history_monthly_start_date_in_future_new_hired, "_tmp_"
    )
)


df_report_rh_proj_history_monthly_start_date_in_future_new_hired = (
    df_report_rh_proj_history_monthly_start_date_in_future_new_hired.withColumn(
        "_leap_extraction_date", f.col("_leap_extraction_date_1")
    )
    .withColumn(
        "_leap_year_month_extraction_date", f.col("_leap_year_month_extraction_date_1")
    )
    .withColumn(
        "_leap_reference_date",
        f.when(
            (f.year("_leap_extraction_date") == f.year(f.current_date()))
            & (f.month("_leap_extraction_date") == f.month(f.current_date())),
            f.current_date(),  # If it is in the current month
        ).otherwise(
            last_day_of_month(
                "_leap_extraction_date"
            )  # Otherwise, last day of the month of _leap_extraction_date
        ),
    )
    .withColumn(
        "_leap_reference_date_1",
        last_day_of_month(
            f.add_months(f.col("_leap_reference_date"), -1)
        ),  # Last day of the previous month
    )
    .withColumn(
        "_leap_extraction_date_1", f.date_add(f.col("_leap_extraction_date"), -1)
    )
    .withColumn(
        "_leap_year_month_extraction_date_1",
        f.date_format(f.col("_leap_reference_date_1"), "yyyy-MM"),
    )
    .drop("_leap_year_month_extraction_date_N_1")
)

# COMMAND ----------

df_report_rh_proj_history_monthly_end_date = (
    df_report_rh_proj_history_monthly_end_date.unionByName(
        df_report_rh_proj_history_monthly_start_date_in_future_new_hired
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - business rule - check Last_hire_date on beginning of next month
# MAGIC
# MAGIC - For a given month, identify at 1st day of next month people with a new contract starting in current given month
# MAGIC - Catch this information to enrich the current month
# MAGIC - Example : a people with last_hire_date at 2024-04-01 as 2024-09-30 , but appearing as of 2024-10-01 with last_hire_date at 2024-09-02. The last_hire_date at 2024-09-02 will be used to enrich the dataset of 2024-09 instead of 2024-04-01
# MAGIC

# COMMAND ----------

df_report_rh_proj_history_monthly_start_date_in_future = (
    df_report_rh_proj_history_monthly_end_date.alias("base")
    .join(
        df_report_rh_proj_history_monthly_beginning.alias("next"),
        (f.col("base.User_ID") == f.col("next._tmp_User_ID"))
        & (
            f.col("base._leap_year_month_extraction_date")
            == f.col("next._tmp__leap_year_month_extraction_date_N_1")
        )
        & (
            f.col("base._leap_year_month_extraction_date")
            == f.col("next._tmp__leap_year_month_last_hire_date")
        )
        & (
            f.col("base._leap_year_month_last_hire_date")
            != f.col("next._tmp__leap_year_month_last_hire_date")
        ),
        how="left",
    )
    .filter(f.col("next._tmp__leap_year_month_last_hire_date").isNotNull())
)

# COMMAND ----------

df_report_rh_proj_history_monthly_start_date_in_future = (
    df_report_rh_proj_history_monthly_start_date_in_future.withColumns(
        {
            "Status": f.col("next._tmp_Status"),
            "Contract_Type": f.col("next._tmp_Contract_Type"),
            "Last_hire_date": f.col("next._tmp_Last_hire_date"),
            "End_Date": f.col("next._tmp_End_Date"),
            "Job": f.col("next._tmp_Job"),
            "Category": f.col("next._tmp_Category"),
            "Reason_for_leaving": f.col("next._tmp_Reason_for_leaving"),
            "Reason_for_leaving_code": f.col("next._tmp_Reason_for_leaving_code"),
            "Payroll_category": f.col("next._tmp_Payroll_category"),
            "External_company": f.col("next._tmp_External_company"),
            "Conventional_category_name": f.col("next._tmp_Conventional_category_name"),
            "_leap_year_month_last_hire_date": f.col(
                "next._tmp__leap_year_month_last_hire_date"
            ),
            "_leap_year_month_end_date": f.col("next._tmp__leap_year_month_end_date"),
        },
    )
)

table_cols = df_report_rh_proj_history_monthly_start_date_in_future.columns
cols_to_drop = [column for column in table_cols if (column.startswith("_tmp_"))]
df_report_rh_proj_history_monthly_start_date_in_future = (
    df_report_rh_proj_history_monthly_start_date_in_future.drop(*cols_to_drop)
)

df_report_rh_proj_history_monthly_end_date_filtered = (
    df_report_rh_proj_history_monthly_end_date.join(
        df_report_rh_proj_history_monthly_start_date_in_future,
        on=["User_ID", "_leap_extraction_date"],
        how="left_anti",
    )
)

# Then we union "df_report_rh_proj_history_monthly_end_date_filtered" with "df_report_rh_proj_history_monthly_start_date_in_future"
df_report_rh_proj_history_monthly_combined = (
    df_report_rh_proj_history_monthly_end_date_filtered.unionByName(
        df_report_rh_proj_history_monthly_start_date_in_future
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - business rule - ACTIVE/INACTIVE Status
# MAGIC
# MAGIC - ACTIVE : when (End_Date is null) or (End_Date >= _leap_reference_date)
# MAGIC - INACTIVE : when (End_Date < _leap_reference_date) or (Last_hire_date > _leap_reference_date) or (Last_hire_date is null)

# COMMAND ----------

# When Employee End_Date is last calendar day of Month then ACTIVE else current Status
df_report_rh_proj_history_monthly_status = (
    df_report_rh_proj_history_monthly_combined.withColumn(
        "Status",
        f.when(
            (f.col("End_Date").isNull())
            | (f.col("End_Date") >= f.col("_leap_reference_date")),
            f.lit("ACTIVE"),
        ).otherwise(f.col("Status")),
    )
)

df_report_rh_proj_history_monthly_status = (
    df_report_rh_proj_history_monthly_status.withColumn(
        "Status",
        f.when(
            (f.col("End_Date").isNotNull())
            & (f.col("End_Date") < f.col("_leap_reference_date")),
            f.lit("INACTIVE"),
        ).otherwise(f.col("Status")),
    )
)

df_report_rh_proj_history_monthly_status = (
    df_report_rh_proj_history_monthly_status.withColumn(
        "Status",
        f.when(
            (f.col("Last_hire_date").isNull())
            | (f.col("Last_hire_date") > f.col("_leap_reference_date")),
            f.lit("INACTIVE"),
        ).otherwise(f.col("Status")),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 5 - business rule - Filter Contract_type
# MAGIC
# MAGIC - Contract_type in ["CDI", "CDD", "INT", "APR", "PR", "SIVP", "ANA", "SST"]
# MAGIC - or
# MAGIC - Contract_type in ["Permanent contract", "Fixed-term contract", "CDD ANAPEC", "Fixed-term professionnal contract", "Permanent professionnal contract", "Stage SIVP", "Apprentice", "Interim contract", "Temporary worker", "Subcontractor"]
# MAGIC - "SST" and "Subcontractor" will be filtered later, they are needed in an aggregated view

# COMMAND ----------

df_report_rh_proj_history_monthly_contract_type = (
    df_report_rh_proj_history_monthly_status.filter(
        f.col("Contract_type").isin(
            [
                "CDI",
                "CDD",
                "INT",
                "APR",
                "PR",
                "SIVP",
                "ANA",
                "SST",
                "Permanent contract",
                "Fixed-term contract",
                "CDD ANAPEC",
                "Fixed-term professionnal contract",
                "Permanent professionnal contract",
                "Stage SIVP",
                "Apprentice",
                "Interim contrat",
                "Temporary worker",
                "Subcontractor",
            ]
        )
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 6 - business rule - Categorize Contract_type
# MAGIC
# MAGIC - Contract_type == "CDI", "Permanent contract"
# MAGIC - Contract_type in ["INT", "Interim contract"], "Temporary worker"
# MAGIC - Contract_type in ["CDD", "APR", "PR", "SIVP", "ANA", "CDD ANAPEC", "Fixed-term professionnal contract", "Permanent professionnal contract", "Stage SIVP", "Apprentice"], "Fixed term contract"

# COMMAND ----------

# old rules and new rules cumulated to build a new column _leap_contract_type_category
df_report_rh_proj_history_monthly_contract_type_category = (
    df_report_rh_proj_history_monthly_contract_type.withColumn(
        "_leap_contract_type_category",
        f.when(f.col("Contract_type") == "CDI", "Permanent contract")
        .when(
            f.col("Contract_type").isin(
                [
                    "CDD",
                    "APR",
                    "PR",
                    "SIVP",
                    "ANA",
                    "CDD ANAPEC",
                    "Fixed-term contract",
                    "Fixed-term professionnal contract",
                    "Permanent professionnal contract",
                    "Stage SIVP",
                    "Apprentice",
                ]
            ),
            "Fixed-term contract",
        )
        .when(
            f.col("Contract_type").isin(["INT", "Interim contrat"]), "Temporary worker"
        )
        .when(f.col("Contract_type").isin(["SST"]), "Subcontractor")
        .otherwise(f.col("Contract_type")),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 7 - business rule - Categorize Workplace for North America
# MAGIC
# MAGIC - Company_Code == "LDM" and Workplace == "Hermosillo", "Hermosillo A"
# MAGIC - Company_Code == "LDM" and Workplace == "HERMOSILLO F", "Hermosillo D"
# MAGIC - Company_Code == "LMXC" and Workplace == "Hermosillo", "Hermosillo C"
# MAGIC - Company_Code == "LEM" and Workplace == "Hermosillo", "Hermosillo I"
# MAGIC - Company_Code == "INC", "Mountain Lake Terrace"
# MAGIC - Company_Code == "LIUS" and Establishment == "Los Angeles", "Los Alamitos"
# MAGIC - Company_Code == "LIUS" and Establishment == "Seattle", "Redmond"
# MAGIC - Otherwise : Workplace

# COMMAND ----------

df_report_rh_proj_history_monthly_workplace_category = (
    df_report_rh_proj_history_monthly_contract_type_category.withColumn(
        "_leap_workplace_category",
        f.when(
            (f.col("Company_Code") == "LDM")
            & (f.lower(f.col("Workplace")) == "hermosillo"),
            "Hermosillo A",
        )
        .when(
            (f.col("Company_Code") == "LDM")
            & (f.lower(f.col("Workplace")) == "hermosillo f"),
            "Hermosillo D",
        )
        .when(
            (f.col("Company_Code") == "LMXC")
            & (f.lower(f.col("Workplace")) == "hermosillo"),
            "Hermosillo C",
        )
        .when(
            (f.col("Company_Code") == "LEM")
            & (f.lower(f.col("Workplace")) == "hermosillo"),
            "Hermosillo I",
        )
        .when(f.col("Company_Code") == "INC", "Mountain Lake Terrace")
        .when(
            (f.col("Company_Code") == "LIUS")
            & (f.lower(f.col("Establishment")) == "los angeles"),
            "Los Alamitos",
        )
        .when(
            (f.col("Company_Code") == "LIUS")
            & (f.lower(f.col("Establishment")) == "seattle"),
            "Redmond",
        )
        .otherwise(f.col("Workplace")),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 8 - Flags about contracts
# MAGIC
# MAGIC   **is_end_of_contract** - **is_start_of_contract** - **is_change_of_contract**
# MAGIC
# MAGIC - is_start_of_contract : year-month of last_hire_date = year-month of extraction_date
# MAGIC - is_end_of_contract : (year-month of end_date = year-month of extraction_date and Status="INACTIVE") or (year-month of end_date < year-month of extraction_date and end_date=last_day_of_previous_month)
# MAGIC - is_start_of_contract is always True when starting a new contract
# MAGIC - is_end_of_contract is not True when contracts follow one another without interruption.
# MAGIC - is_change_of_contract : True when Contract_type different from previous month

# COMMAND ----------

window_spec = Window.partitionBy("User_ID").orderBy("_leap_extraction_date")

# _leap_is_start_of_contract
df_report_rh_proj_history_monthly_flags = (
    df_report_rh_proj_history_monthly_workplace_category.withColumn(
        "_leap_is_start_of_contract",
        f.when(
            (
                f.col("_leap_year_month_last_hire_date")
                == f.col("_leap_year_month_extraction_date")
            ),
            True,
        ).otherwise(False),
    )
)

# _leap_is_end_of_contract
df_report_rh_proj_history_monthly_flags = (
    df_report_rh_proj_history_monthly_flags.withColumn(
        "_leap_is_end_of_contract",
        f.when(
            (
                (
                    f.col("_leap_year_month_end_date")
                    == f.col("_leap_year_month_extraction_date")
                )
                & (f.col("Status") == "INACTIVE")
            )
            | (
                (
                    f.col("_leap_year_month_end_date")
                    < f.col("_leap_year_month_extraction_date")
                )
                & (f.col("End_Date") == f.col("_leap_reference_date_1"))
            ),
            True,
        ).otherwise(False),
    )
)
# _leap_previous_is_end_of_contract
df_report_rh_proj_history_monthly_flags = (
    df_report_rh_proj_history_monthly_flags.withColumn(
        "_leap_previous_is_end_of_contract",
        f.lag("_leap_is_end_of_contract").over(window_spec),
    ).withColumn(
        "_leap_previous_status",
        f.lag("Status").over(window_spec),
    )
)

# _leap_is_end_of_contract_in_the_past  based on _leap_previous_is_end_of_contract
df_report_rh_proj_history_monthly_flags = (
    df_report_rh_proj_history_monthly_flags.withColumn(
        "_leap_is_end_of_contract_in_the_past",
        f.when(
            (
                f.col("_leap_year_month_end_date")
                < f.col("_leap_year_month_extraction_date")
            )
            & (f.col("End_Date") < f.col("_leap_reference_date_1"))
            & (f.col("_leap_previous_is_end_of_contract") == False)
            & (f.col("_leap_previous_status") == "ACTIVE"),
            True,
        ).otherwise(False),
    )
)

# _leap_previous_is_end_of_contract_in_the_past + update of _leap_is_end_of_contract_in_the_past
df_report_rh_proj_history_monthly_flags = (
    df_report_rh_proj_history_monthly_flags.withColumn(
        "_leap_previous_is_end_of_contract_in_the_past",
        f.lag("_leap_is_end_of_contract_in_the_past").over(window_spec),
    ).withColumn(
        "_leap_is_end_of_contract_in_the_past",
        f.when(
            (f.col("_leap_is_end_of_contract_in_the_past") == True)
            & (
                f.col("_leap_previous_is_end_of_contract_in_the_past") == True
            ),  # If the previous month is also set to True
            False,  # Do not keep True for two consecutive months
        ).otherwise(f.col("_leap_is_end_of_contract_in_the_past")),
    )
)

# update of _leap_is_end_of_contract   based   on _leap_is_end_of_contract_in_the_past
# set up Status to "ACTIVE/END" when _leap_is_end_of_contract is True
df_report_rh_proj_history_monthly_flags = (
    df_report_rh_proj_history_monthly_flags.withColumn(
        "_leap_is_end_of_contract",
        f.when(
            (f.col("_leap_is_end_of_contract_in_the_past") == True),
            True,
        ).otherwise(f.col("_leap_is_end_of_contract")),
    )
)

# _leap_is_change_of_contract   based   on _leap_previous_contract_type
df_report_rh_proj_history_monthly_flags = (
    df_report_rh_proj_history_monthly_flags.withColumn(
        "_leap_previous_contract_type_category",
        f.lag("_leap_contract_type_category").over(window_spec),
    ).withColumn(
        "_leap_is_change_of_contract",
        f.when(
            (
                f.col("_leap_contract_type_category")
                != f.col("_leap_previous_contract_type_category")
            ),
            True,
        ).otherwise(False),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 9 - Create a FK to ABSENTEISM table

# COMMAND ----------

df_report_rh_proj_history_monthly_id = (
    df_report_rh_proj_history_monthly_flags.withColumn(
        "_meta_ABSENTEISM_FK_ID",
        f.concat(
            f.col("_leap_year_month_extraction_date"),
            f.lit("-"),
            f.col("Workplace_country"),
            f.lit("-"),
            f.col("_leap_workplace_category"),
        ),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug step
# MAGIC

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    df_report_rh_proj_history_monthly_id.select(
        "User_ID",
        "First_name",
        "Last_name",
        "_leap_extraction_date",
        "_leap_year_month_extraction_date",
        "Company_Seniority_Date",
        "Last_hire_date",
        "_leap_year_month_last_hire_date",
        "Contract_Type",
        "_leap_is_change_of_contract",
        "End_Date",
        "_leap_year_month_end_date",
        "Reason_for_leaving",
        "Status",
        "_leap_is_start_of_contract",
        "_leap_is_end_of_contract",
        "_leap_is_end_of_contract_in_the_past",
    ).filter(f.col("User_ID") == "37547").display()
    # 23833 -> ok bien inactif en juillet et Aout, fin de contrat en juillet, actif et nouveau contrat à partir de septembre
    # 36837 -> ok bien inactif à partir de Septembre avec une saisie de fin de contrat en retard au 2024-08-30, saisie postérieure au 2024-09-01
    # 31123 -> ok bien inactif à partir de Juillet avec une saisie de fin de contrat en retard au  2024-06-28, saisie postérieure au 2024-07-01
    # 36677 -> ok et nouveau contrat à partir du 2024-09-02, saisi en date du 2024-10-01 donc effectif pour 2024-09, mais _leap_is_end_of_contract aurait du être true en aout 2024 ? Vu avec Carolina, on pourra tracer ce cas de figure grâce au flag _leap_is_change_of_contract qui est True pour 2024-09
    # 16616 -> ok _leap_is_end_of_contract_in_the_past bien détecté /!\
    # 32934 -> ok _leap_is_end_of_contract_in_the_past bien détecté mais type de contrat filtré (SST)
    # 33362 -> ok , bien actif en juillet , et nouveau contrat en Aout, mais _leap_is_end_of_contract aurait du être true en juillet 2024 ? Vu avec Carolina, on pourra tracer ce cas de figure grâce au flag _leap_is_change_of_contract qui est True pour 2024-08
    # 35413 -> ok mais type de contrat filtré (SST)
    # 34862 -> ok contrat dans le futur en 2024-09 donc INACTIVE, repasse active en 2024-10
    # 37566 -> ok actif en septembre et en octobre, malgré la première apparition dans l'extraction du 2024-10-01
    # 37182 -> ok actif en septembre et en octobre, avec une fin de contrat au 2024-09-17 dès l'extraction du 2024-10-01
    # 37547 : bug a corriger
    # 33411 : ok actif en 2024-10 et inactif auparavant, ayant un Last_hire_date au 2024-10-10 depuis 2024-04

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    df_report_rh_gold_history.select(
        "User_ID",
        "First_name",
        "Last_name",
        "_leap_extraction_date",
        "_leap_year_month_extraction_date",
        "Company_Seniority_Date",
        "Last_hire_date",
        "_leap_year_month_last_hire_date",
        "Contract_Type",
        "End_Date",
        "_leap_year_month_end_date",
        "Reason_for_leaving",
        "Status",
    ).filter(f.col("User_ID") == "37547").sort("_leap_extraction_date").display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 10 - Drop unwanted Columns

# COMMAND ----------

df_report_rh_proj_history_monthly_id = df_report_rh_proj_history_monthly_id.drop(
    "_leap_previous_is_end_of_contract",
    "_leap_previous_status",
    "_leap_previous_is_end_of_contract_in_the_past",
    "_leap_previous_contract_type_category",
    "_leap_reference_date",
    "_leap_reference_date_1",
)

df_report_rh_gold_history_update = df_report_rh_gold_history_update.drop(
    "_leap_extraction_date_1",
    "_leap_year_month_extraction_date_1",
)

for col_to_drop in SILVER_ATTRS_DICT["columns_to_drop"]:
    df_report_rh_proj_history_monthly_id = df_report_rh_proj_history_monthly_id.drop(
        col_to_drop
    )
    df_report_rh_gold_history_update = df_report_rh_gold_history_update.drop(
        col_to_drop
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 11 - make an aggregated dataframe

# COMMAND ----------

PROJ_AGGREGATED_COLUMNS_GROUPBY = [
    "_leap_year_month_extraction_date",
    "Status",
    "Cost_Center",
    "Direction",
    "Direction_code",
    "Country_of_company",
    "Workplace_country",
    "_leap_workplace_category",
    "_leap_contract_type_category",
    "Category",
    "Int_Ext",
    "_leap_is_start_of_contract",
    "_leap_is_end_of_contract",
    "Organization",
    "Organization_code",
]

df_proj_grouped = df_report_rh_proj_history_monthly_id.groupBy(
    *PROJ_AGGREGATED_COLUMNS_GROUPBY
).count()

# COMMAND ----------

df_proj_grouped.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 12 - business rule - Filter Contract_type

# COMMAND ----------

df_report_rh_proj_history_monthly_id = df_report_rh_proj_history_monthly_id.filter(
    ~f.col("_leap_contract_type_category").isin(
        [
            "Subcontractor",
        ]
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 13 - Optimize order of Columns

# COMMAND ----------

first_cols = list(TABLE_GOLD_FIRST_COLS.keys())
df_report_rh_gold_history_update_end = move_dataframe_cols_first(
    df_report_rh_gold_history_update, first_cols
)

first_cols = list(TABLE_PROJ_FIRST_COLS.keys())
df_report_rh_proj_history_monthly_end = move_dataframe_cols_first(
    df_report_rh_proj_history_monthly_id, first_cols
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 14 - keep a plaintext version of the gold history

# COMMAND ----------

# Load Token Vault
df_token_vault = spark.read.table(TOKEN_VAULT_TABLE)

# Take Full Gold history and unhash data
df_report_rh_gold_history_decrypted = df_report_rh_gold_history_update_end
for col_to_decrypt in SILVER_ATTRS_DICT["columns_to_hash"]:
    df_report_rh_gold_history_decrypted = decrypt_hash_for_column(
        df_token_vault, df_report_rh_gold_history_decrypted, col_to_decrypt
    )

# Take Full Gold history and move first cols to front
first_cols = list(TABLE_GOLD_FIRST_COLS.keys())
keep_cols = set(first_cols + SILVER_ATTRS_DICT["columns_to_hash"])
df_report_rh_gold_history_decrypted = df_report_rh_gold_history_decrypted.select(
    *keep_cols
)
df_report_rh_gold_history_decrypted = move_dataframe_cols_first(
    df_report_rh_gold_history_decrypted, first_cols
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 15 - specific plaintext dataframe with correspondance between : email, country, workspace

# COMMAND ----------

# Define window to get the latest extraction date per Email
window_spec_latest = Window.partitionBy("Email").orderBy(
    f.col("_leap_extraction_date").desc()
)

# Filter for the latest extraction per Email
df_hr_email_to_workplace = (
    df_report_rh_gold_history_update_end.withColumn(
        "row_number", f.row_number().over(window_spec_latest)
    )
    .filter(f.col("row_number") == 1)
    .filter(f.col("Email").isNotNull())
    .drop("row_number")
)

# Decrypt the necessary columns
df_hr_email_to_workplace_decrypted = df_hr_email_to_workplace

for col_to_decrypt in ["Email"]:
    df_hr_email_to_workplace_decrypted = decrypt_hash_for_column(
        df_token_vault, df_hr_email_to_workplace_decrypted, col_to_decrypt
    )

# Select and rename the required columns
df_hr_email_to_workplace_decrypted = df_hr_email_to_workplace_decrypted.select(
    f.col("_leap_extraction_date").alias("date_end"),
    "email",
    f.col("Workplace_country").alias("country"),
    "workplace",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# TBD

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - Uniqueness
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Quality checks with great_expectations : uniqueness for Email
# Raise an Exception if not pass the checks
df_to_check = df_hr_email_to_workplace_decrypted

dfgx = gx.dataset.SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    dfgx.expect_column_values_to_be_unique(column="email"),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="Quality Checks passed for email in gold table - RED",
    error_message="Quality checks failed for unicity of email, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="hr_referential_email_to_workplace",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# Quality checks with great_expectations : uniqueness for  ["_leap_extraction_date", "User_ID"]
# Raise an Exception if not pass the checks
df_to_check = df_report_rh_gold_history_decrypted

dfgx = gx.dataset.SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    dfgx.expect_compound_columns_to_be_unique(["_leap_extraction_date", "User_ID"]),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="Quality Checks passed for compound columns _leap_extraction_date,User_ID in gold table - RED",
    error_message="Quality checks failed for unicity of _leap_extraction_date,User_ID, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="hr_workforce_gold_history",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 2 - Not null expectation
# MAGIC
# MAGIC N/A

# COMMAND ----------

# TBD

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 3 - Surge of Status change
# MAGIC
# MAGIC N/A

# COMMAND ----------


# ---------- Quality Checks 3 - Surge of Status change (GOLD) ----------
df_to_check = df_report_rh_gold_history_update_end

# 1) Parameters
_threshold_pct = float(dbutils.widgets.get("status_change_alert_threshold_pct"))
_min_pop = int(dbutils.widgets.get("status_change_min_population"))
_alert_mode = dbutils.widgets.get("status_change_alert_mode")  # "ratio" | "count"

# 2) latest date in current batch
_latest_date_in_batch = df_to_check.agg(
    f.max("_leap_extraction_date").alias("d")
).first()["d"]

# 3) latest date in existing table
if table_utils.UnityCatalogCheckTableExists(REPORT_RH_GOLD_TABLE):
    df_gold_hist = spark.read.table(REPORT_RH_GOLD_TABLE)
    df_dates = (
        df_gold_hist.select("_leap_extraction_date")
        .where(f.col("_leap_extraction_date") < f.lit(_latest_date_in_batch))
        .distinct()
    )
    prev_date_row = df_dates.agg(f.max("_leap_extraction_date").alias("d")).first()
    _prev_date = prev_date_row["d"]

else:
    _prev_date = None

if _prev_date is not None:
    # 4) D vs D-1
    dfD = (
        df_to_check.where(
            f.col("_leap_extraction_date") == f.lit(_latest_date_in_batch)
        )
        .select(f.col("User_ID"), f.col("Status").alias("status_D"))
        .dropDuplicates(["User_ID"])
    )
    dfDm1 = (
        df_gold_hist.where(f.col("_leap_extraction_date") == f.lit(_prev_date))
        .select(f.col("User_ID"), f.col("Status").alias("status_Dm1"))
        .dropDuplicates(["User_ID"])
    )

    df_join = dfD.join(dfDm1, on="User_ID", how="inner")
    base_population = df_join.count()

    if base_population >= _min_pop:
        change_count = df_join.where(f.col("status_D") != f.col("status_Dm1")).count()
        change_ratio = (change_count / base_population) if base_population > 0 else 0.0

        # 5) Encapsulate metric in df for Great Expectations
        df_metric = spark.createDataFrame(
            [(float(change_ratio), int(change_count), int(base_population))],
            ["status_change_ratio", "status_change_count", "base_population"],
        )
        dfgx = gx.dataset.SparkDFDataset(df_metric, persist=False)

        if _alert_mode == "ratio":
            gx_results = [
                dfgx.expect_column_max_to_be_between(
                    column="status_change_ratio",
                    min_value=None,
                    max_value=_threshold_pct / 100.0,
                )
            ]
        else:  # "count"
            gx_results = [
                dfgx.expect_column_max_to_be_between(
                    column="status_change_count",
                    min_value=None,
                    max_value=int(round(_threshold_pct)),
                )
            ]

        gx_validation.validate_and_log_gx_results(
            quality_check_results=gx_results,
            validation_level="RED",
            info_message=(
                f"QC GOLD: Status change surge OK. "
                f"change_ratio={change_ratio:.4f}, change_count={change_count}, base={base_population}, "
                f"latest={_latest_date_in_batch}, prev={_prev_date}"
            ),
            error_message=(
                f"QC GOLD: Status change surge KO (above alert level). "
                f"change_ratio={change_ratio:.4f}, change_count={change_count}, base={base_population}, "
                f"latest={_latest_date_in_batch}, prev={_prev_date}"
            ),
            pipeline_write_env=PIPELINE_WRITE_ENV,
            table_name="hr_workforce_gold_history",
            log_to_event_table=True,
            log_successes=True,
        )
    else:
        log.info(
            f"QC GOLD: base_population={base_population} < min_pop={_min_pop}, quality check ignored."
            f"(latest={_latest_date_in_batch}, prev={_prev_date})"
        )
else:
    log.info(
        "QC GOLD: No previous date D-1 available in history, quality check ignored."
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Gold Table

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by GOLD_CLUSTER_COLS_STR
if not EMPTY_DATAFRAME_FLAG:
    catalog, schema, table = REPORT_RH_GOLD_TABLE.split(".")

    try:
        table_utils.create_unity_catalog_table(
            catalog,
            schema,
            table,
            force_reinitialization=False,
            cluster_cols=GOLD_CLUSTER_COLS_STR,
            partition_col=None,
            primary_key_cols=None,
            columns=TABLE_GOLD_FIRST_COLS,
            force_drop=False,
        )
    except AnalysisException as e:
        log.error(
            f"Table {REPORT_RH_GOLD_TABLE} has not been created, an error occured during creation. \nError is {e}"
        )
        raise OSError(
            f"An error occurred while creating the table {REPORT_RH_GOLD_TABLE}"
        ) from e

# COMMAND ----------

# Save the table from Dataframe df_report_rh_gold_history_update_end, preserving cluster columns
if not EMPTY_DATAFRAME_FLAG:
    try:
        startTime = time.time()
        table_utils.save_table(
            dest_table=REPORT_RH_GOLD_TABLE,
            df=df_report_rh_gold_history_update_end,
            mode=MODE,
            overwrite_schema=True,
            cluster_cols=GOLD_CLUSTER_COLS_STR,
            merge_schema=True,
        )
    except AnalysisException as e:
        log.error(
            f"Table {REPORT_RH_GOLD_TABLE} has not been created, an error occured during table_utils.save_table . \nError is {e}"
        )
        raise OSError(
            f"An error occurred while saving the table {REPORT_RH_GOLD_TABLE}"
        ) from e
    else:
        duration = time.time() - startTime
        log.info(f"Table {REPORT_RH_GOLD_TABLE} saved in {duration} seconds.")
        log.info(f"Mode {MODE}.")
        log.info(f"Wrote {df_report_rh_gold_history_update_end.count()} rows.")

# COMMAND ----------

# Add Primary Key if not exists
catalog, schema, table = REPORT_RH_GOLD_TABLE.split(".")
pk_name = GOLD_PK_NAME.lower()
nb_cons = spark.sql(
    f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    for col in GOLD_SK_COLUMNS_LIST:
        table_utils.set_table_column_not_null(
            table_path=REPORT_RH_GOLD_TABLE, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=REPORT_RH_GOLD_TABLE,
        pk_name=GOLD_PK_NAME,
        columns=GOLD_SK_COLUMNS_STR,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - sd_gold Table

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by GOLD_CLUSTER_COLS_STR
if not EMPTY_DATAFRAME_FLAG:
    catalog, schema, table = REPORT_RH_GOLD_TABLE_PLAIN.split(".")

    try:
        table_utils.create_unity_catalog_table(
            catalog,
            schema,
            table,
            force_reinitialization=False,
            cluster_cols=GOLD_CLUSTER_COLS_STR,
            partition_col=None,
            primary_key_cols=None,
            columns=TABLE_GOLD_FIRST_COLS,
            force_drop=False,
        )
    except AnalysisException as e:
        log.error(
            f"Table {REPORT_RH_GOLD_TABLE_PLAIN} has not been created, an error occured during creation. \nError is {e}"
        )
        raise OSError(
            f"An error occurred while creating the table {REPORT_RH_GOLD_TABLE_PLAIN}"
        ) from e

# COMMAND ----------

# Save the table from Dataframe df_report_rh_gold_history_decrypted, preserving cluster columns
try:
    startTime = time.time()
    table_utils.save_table(
        dest_table=REPORT_RH_GOLD_TABLE_PLAIN,
        df=df_report_rh_gold_history_decrypted,
        mode=MODE,
        overwrite_schema=True,
        cluster_cols=GOLD_CLUSTER_COLS_STR,
        merge_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {REPORT_RH_GOLD_TABLE_PLAIN} has not been created, an error occured during table_utils.save_table . \nError is {e}"
    )
    raise OSError(
        f"An error occurred while saving the table {REPORT_RH_GOLD_TABLE_PLAIN}"
    ) from e
else:
    duration = time.time() - startTime
    log.info(f"Table {REPORT_RH_GOLD_TABLE_PLAIN} saved in {duration} seconds.")
    log.info(f"Mode {MODE}.")
    log.info(f"Wrote {df_report_rh_gold_history_decrypted.count()} rows.")

# COMMAND ----------

# Add Primary Key if not exists
catalog, schema, table = REPORT_RH_GOLD_TABLE_PLAIN.split(".")
pk_name = GOLD_PK_NAME.lower()
nb_cons = spark.sql(
    f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    for col in GOLD_SK_COLUMNS_LIST:
        table_utils.set_table_column_not_null(
            table_path=REPORT_RH_GOLD_TABLE_PLAIN, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=REPORT_RH_GOLD_TABLE_PLAIN,
        pk_name=GOLD_PK_NAME,
        columns=GOLD_SK_COLUMNS_STR,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Proj Table

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by PROJ_MONTHLY_CLUSTER_COLS_STR
for table in [REPORT_RH_PROJ_TABLE_MONTHLY]:
    catalog, schema, table = table.split(".")

    try:
        table_utils.create_unity_catalog_table(
            catalog,
            schema,
            table,
            force_reinitialization=False,
            cluster_cols=PROJ_MONTHLY_CLUSTER_COLS_STR,
            partition_col=None,
            primary_key_cols=None,
            columns=TABLE_PROJ_FIRST_COLS,
            force_drop=False,
        )
    except AnalysisException as e:
        log.error(
            f"Table {table} has not been created, an error occured during creation. \nError is {e}"
        )
        raise OSError(f"An error occurred while creating the table {table}") from e

# COMMAND ----------

# Save the table from Dataframe df_report_rh_proj_history_monthly_end, preserving cluster columns
try:
    startTime = time.time()
    table_utils.save_table(
        dest_table=REPORT_RH_PROJ_TABLE_MONTHLY,
        df=df_report_rh_proj_history_monthly_end,
        mode="overwrite",
        overwrite_schema=True,
        cluster_cols=PROJ_MONTHLY_CLUSTER_COLS_STR,
        merge_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {REPORT_RH_PROJ_TABLE_MONTHLY} has not been created, an error occured during table_utils.save_table . \nError is {e}"
    )
    raise OSError(
        f"An error occurred while saving the table {REPORT_RH_PROJ_TABLE_MONTHLY}"
    ) from e
else:
    duration = time.time() - startTime
    log.info(f"Table {REPORT_RH_PROJ_TABLE_MONTHLY} saved in {duration} seconds.")
    log.info(f"Mode overwrite.")
    log.info(f"Wrote {df_report_rh_proj_history_monthly_end.count()} rows.")

# COMMAND ----------

# Add Primary Key if not exists
catalog, schema, table = REPORT_RH_PROJ_TABLE_MONTHLY.split(".")
pk_name = PROJ_MONTHLY_PK_NAME.lower()
nb_cons = spark.sql(
    f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    for col in PROJ_MONTHLY_SK_COLUMNS_LIST:
        table_utils.set_table_column_not_null(
            table_path=REPORT_RH_PROJ_TABLE_MONTHLY, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=REPORT_RH_PROJ_TABLE_MONTHLY,
        pk_name=PROJ_MONTHLY_PK_NAME,
        columns=PROJ_MONTHLY_SK_COLUMNS_STR,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - aggregated proj table
# MAGIC
# MAGIC produced for other use cases that need aggregated HR data

# COMMAND ----------

# Save the table from Dataframe df_proj_grouped
try:
    startTime = time.time()
    table_utils.save_table(
        dest_table=REPORT_RH_PROJ_TABLE_AGGREGATED,
        df=df_proj_grouped,
        mode="overwrite",
        overwrite_schema=True,
        merge_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {REPORT_RH_PROJ_TABLE_AGGREGATED} has not been created, an error occured during table_utils.save_table . \nError is {e}"
    )
    raise OSError(
        f"An error occurred while saving the table {REPORT_RH_PROJ_TABLE_AGGREGATED}"
    ) from e
else:
    duration = time.time() - startTime
    log.info(f"Table {REPORT_RH_PROJ_TABLE_AGGREGATED} saved in {duration} seconds.")
    log.info(f"Mode overwrite.")
    log.info(f"Wrote {df_proj_grouped.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Email to Workplace proj table
# MAGIC
# MAGIC produced for other use cases that need matching email to country and workplace

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by PROJ_EMAIL_WORKPLACE_PK_COLUMNS_STR
for table in [PROJ_EMAIL_WORKPLACE]:
    catalog, schema, table = table.split(".")

    try:
        table_utils.create_unity_catalog_table(
            catalog,
            schema,
            table,
            force_reinitialization=FORCE_REINITIALIZATION,
            cluster_cols=PROJ_EMAIL_WORKPLACE_PK_COLUMNS_STR,
            partition_col=None,
            primary_key_cols=None,
            columns=PROJ_EMAIL_WORKPLACE_FIRST_COLS,
            force_drop=False,
        )
    except AnalysisException as e:
        log.error(
            f"Table {table} has not been created, an error occured during creation. \nError is {e}"
        )
        raise OSError(f"An error occurred while creating the table {table}") from e

# COMMAND ----------

# Save the table from Dataframe df_hr_email_to_workplace_decrypted
try:
    startTime = time.time()
    table_utils.merge_into(
        df_source=df_hr_email_to_workplace_decrypted,
        target_table=PROJ_EMAIL_WORKPLACE,
        list_id_matching_columns=PROJ_EMAIL_WORKPLACE_PK_COLUMNS_LIST,
    ).display()
except AnalysisException as e:
    log.error(
        f"Table {PROJ_EMAIL_WORKPLACE} has not been created, an error occured during MERGE INTO. \nError is {e}"
    )
    raise OSError(
        f"An error occurred while saving the table {PROJ_EMAIL_WORKPLACE}"
    ) from e
else:
    duration = time.time() - startTime
    log.info(f"Table {PROJ_EMAIL_WORKPLACE} saved in {duration} seconds.")
    log.info(f"Mode {MODE}.")
    log.info(f"Wrote {df_hr_email_to_workplace_decrypted.count()} rows.")

# COMMAND ----------

# Add Primary Key if not exists
catalog, schema, table = PROJ_EMAIL_WORKPLACE.split(".")
pk_name = PROJ_EMAIL_WORKPLACE_PK_NAME.lower()
nb_cons = spark.sql(
    f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    for col in PROJ_EMAIL_WORKPLACE_PK_COLUMNS_LIST:
        table_utils.set_table_column_not_null(
            table_path=PROJ_EMAIL_WORKPLACE, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=PROJ_EMAIL_WORKPLACE,
        pk_name=PROJ_EMAIL_WORKPLACE_PK_NAME,
        columns=PROJ_EMAIL_WORKPLACE_PK_COLUMNS_STR,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Set up governed tags and comments on assets
# MAGIC
# MAGIC - HR
# MAGIC - domain
# MAGIC - refresh_frequency
# MAGIC - system.certification_status
# MAGIC - class.name
# MAGIC - class.email_address
# MAGIC - class.phone_number

# COMMAND ----------

# set governed tags
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} ALTER COLUMN First_name SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} ALTER COLUMN Last_name SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} ALTER COLUMN IT_Account SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} ALTER COLUMN ID_Local SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} ALTER COLUMN Maiden_Name SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} ALTER COLUMN User_ID SET TAGS ('primary_key','class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} ALTER COLUMN _leap_extraction_date SET TAGS ('primary_key');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} ALTER COLUMN ID_Manager SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} ALTER COLUMN ID_HR_Manager SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} ALTER COLUMN Email SET TAGS ('class.email_address');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} ALTER COLUMN Business_Phone SET TAGS ('class.phone_number');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} ALTER COLUMN Cell_Phone SET TAGS ('class.phone_number');"
)

spark.sql(f"ALTER TABLE {REPORT_RH_GOLD_TABLE} SET TAGS ('HR');")
spark.sql(f"ALTER TABLE {REPORT_RH_GOLD_TABLE} SET TAGS ('domain' = 'HR');")
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} SET TAGS ('refresh_frequency' = 'daily');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} SET TAGS ('system.certification_status' = 'certified');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE} SET TAGS ('primary_key_columns' = '{GOLD_SK_COLUMNS_STR}');"
)


# set comments
spark.sql(
    f"""COMMENT ON TABLE {REPORT_RH_GOLD_TABLE} IS
'HR workforces gold daily with encrypted fields.';"""
)

# COMMAND ----------

# set governed tags
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} ALTER COLUMN First_name SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} ALTER COLUMN Last_name SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} ALTER COLUMN IT_Account SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} ALTER COLUMN ID_Local SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} ALTER COLUMN Maiden_Name SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} ALTER COLUMN User_ID SET TAGS ('primary_key','class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} ALTER COLUMN _leap_extraction_date SET TAGS ('primary_key');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} ALTER COLUMN Email SET TAGS ('class.email_address');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} ALTER COLUMN Business_Phone SET TAGS ('class.phone_number');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} ALTER COLUMN Cell_Phone SET TAGS ('class.phone_number');"
)

spark.sql(f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} SET TAGS ('HR');")
spark.sql(f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} SET TAGS ('domain' = 'HR');")
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} SET TAGS ('refresh_frequency' = 'daily');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} SET TAGS ('system.certification_status' = 'certified');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_GOLD_TABLE_PLAIN} SET TAGS ('primary_key_columns' = '{GOLD_SK_COLUMNS_STR}');"
)

# set comments
spark.sql(
    f"""COMMENT ON TABLE {REPORT_RH_GOLD_TABLE_PLAIN} IS
'HR workforces gold daily table plaintext.';"""
)

# COMMAND ----------

# set governed tags
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} ALTER COLUMN First_name SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} ALTER COLUMN Last_name SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} ALTER COLUMN IT_Account SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} ALTER COLUMN ID_Local SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} ALTER COLUMN Maiden_Name SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} ALTER COLUMN User_ID SET TAGS ('primary_key','class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} ALTER COLUMN _leap_year_month_extraction_date SET TAGS ('primary_key');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} ALTER COLUMN ID_Manager SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} ALTER COLUMN ID_HR_Manager SET TAGS ('class.name');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} ALTER COLUMN Email SET TAGS ('class.email_address');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} ALTER COLUMN Business_Phone SET TAGS ('class.phone_number');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} ALTER COLUMN Cell_Phone SET TAGS ('class.phone_number');"
)

spark.sql(f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} SET TAGS ('HR');")
spark.sql(f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} SET TAGS ('domain' = 'HR');")
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} SET TAGS ('refresh_frequency' = 'daily');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} SET TAGS ('system.certification_status' = 'certified');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} SET TAGS ('primary_key_columns' = '{PROJ_MONTHLY_SK_COLUMNS_STR}');"
)

# set comments
spark.sql(
    f"""COMMENT ON TABLE {REPORT_RH_PROJ_TABLE_MONTHLY} IS
'HR workforces proj monthly table.
Updated daily with last extraction of each month per User_ID';"""
)

# COMMAND ----------

# set governed tags
spark.sql(
    f"ALTER TABLE {PROJ_EMAIL_WORKPLACE} ALTER COLUMN email SET TAGS ('primary_key','class.email_address');"
)

spark.sql(f"ALTER TABLE {PROJ_EMAIL_WORKPLACE} SET TAGS ('HR');")
spark.sql(f"ALTER TABLE {PROJ_EMAIL_WORKPLACE} SET TAGS ('domain' = 'HR');")
spark.sql(
    f"ALTER TABLE {PROJ_EMAIL_WORKPLACE} SET TAGS ('refresh_frequency' = 'daily');"
)
spark.sql(
    f"ALTER TABLE {PROJ_EMAIL_WORKPLACE} SET TAGS ('system.certification_status' = 'certified');"
)
spark.sql(
    f"ALTER TABLE {PROJ_EMAIL_WORKPLACE} SET TAGS ('primary_key_columns' = '{PROJ_EMAIL_WORKPLACE_PK_COLUMNS_STR}');"
)

# set comments
spark.sql(
    f"""COMMENT ON TABLE {PROJ_EMAIL_WORKPLACE} IS
'Mapping all historical emails to country and workplace with last valid date.
Used by others use cases.';"""
)

# COMMAND ----------

# set governed tags for columns
for col in PROJ_AGGREGATED_COLUMNS_GROUPBY:
    spark.sql(
        f"ALTER TABLE {REPORT_RH_PROJ_TABLE_AGGREGATED} ALTER COLUMN {col} SET TAGS ('primary_key');"
    )

# set governed tags for table
spark.sql(f"ALTER TABLE {REPORT_RH_PROJ_TABLE_AGGREGATED} SET TAGS ('HR');")
spark.sql(f"ALTER TABLE {REPORT_RH_PROJ_TABLE_AGGREGATED} SET TAGS ('domain' = 'HR');")
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_AGGREGATED} SET TAGS ('refresh_frequency' = 'daily');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_AGGREGATED} SET TAGS ('system.certification_status' = 'certified');"
)
spark.sql(
    f"ALTER TABLE {REPORT_RH_PROJ_TABLE_AGGREGATED} SET TAGS ('primary_key_columns' = '{','.join(PROJ_AGGREGATED_COLUMNS_GROUPBY)}');"
)

# set comments
spark.sql(
    f"""COMMENT ON TABLE {REPORT_RH_PROJ_TABLE_AGGREGATED} IS
'HR aggregated data.
Used by others use cases.';"""
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Proj view mexico

# COMMAND ----------

target_view_mexico = (
    f"{PIPELINE_WRITE_ENV}_proj.hr.hr_workforce_proj_active_mexico_employees"
)
source_pii_table = f"sd_{PIPELINE_READ_ENV}_gold.hr.hr_workforce_gold_history"
source_table = f"{PIPELINE_READ_ENV}_gold.hr.hr_workforce_gold_history"

spark.sql(
    f"""
CREATE OR REPLACE VIEW {target_view_mexico} AS
WITH CTE_CLEAR AS (
    SELECT *
    FROM (
        SELECT
            *,
            ROW_NUMBER() OVER (
                PARTITION BY User_ID
                ORDER BY _meta_extraction_timestamp DESC
            ) AS rn
        FROM {source_pii_table}
    )
    WHERE rn = 1
)
SELECT
    CTE_CLEAR.User_ID as user_id,                -- Employee unique identifier
    CTE_CLEAR.First_name as first_name,             -- Employee first name
    CTE_CLEAR.Last_name as last_name,              -- Employee last name
    GOLD.ID_Manager as manager_id,                  -- Manager's User_ID
    CTE_CLEAR_2.First_name AS manager_first_name, -- Manager's first name
    CTE_CLEAR_2.Last_name  AS manager_last_name   -- Manager's last name
FROM CTE_CLEAR
INNER JOIN {source_table} GOLD
    ON CTE_CLEAR._meta_stack_row_id = GOLD._meta_stack_row_id
LEFT JOIN CTE_CLEAR CTE_CLEAR_2
    ON GOLD.ID_Manager = CTE_CLEAR_2.User_ID
WHERE UPPER(GOLD.Workplace_Country) = 'MEXICO'
  AND GOLD.Status = 'ACTIVE';"""
).display()

# COMMAND ----------

spark.sql(
    f"""
COMMENT ON VIEW {target_view_mexico} IS
'Shows active employees whose workplace_country is Mexico with their manager first and last name.';
"""
)

spark.sql(
    f"""
COMMENT ON COLUMN {target_view_mexico}.user_id IS 'Employee unique identifier';
"""
)

spark.sql(
    f"""
COMMENT ON COLUMN {target_view_mexico}.first_name IS 'Employee first name';
"""
)

spark.sql(
    f"""
COMMENT ON COLUMN {target_view_mexico}.last_name IS 'Employee last name';
"""
)
spark.sql(
    f"""
COMMENT ON COLUMN {target_view_mexico}.manager_id IS 'Manager User_ID';
"""
)
spark.sql(
    f"""
COMMENT ON COLUMN {target_view_mexico}.manager_first_name IS 'Manager first name';
"""
)
spark.sql(
    f"""
COMMENT ON COLUMN {target_view_mexico}.manager_last_name IS 'Manager last name';
"""
)

# COMMAND ----------

spark.sql(
    f"""
ALTER TABLE {target_view_mexico} SET TAGS ('HR');
"""
)
spark.sql(
    f"""
ALTER TABLE {target_view_mexico} SET TAGS ('domain' = 'HR');
"""
)
spark.sql(
    f"""
ALTER TABLE {target_view_mexico} ALTER COLUMN user_id SET TAGS ('primary_key','class.name');
"""
).display()
spark.sql(
    f"""
ALTER TABLE {target_view_mexico} ALTER COLUMN first_name SET TAGS ('class.name');
"""
).display()
spark.sql(
    f"""
ALTER TABLE {target_view_mexico} ALTER COLUMN last_name SET TAGS ('class.name');
"""
).display()
spark.sql(
    f"""
ALTER TABLE {target_view_mexico} ALTER COLUMN manager_first_name SET TAGS ('class.name');
"""
).display()
spark.sql(
    f"""
ALTER TABLE {target_view_mexico} ALTER COLUMN manager_last_name SET TAGS ('class.name');
"""
).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Proj view mexico (all statuses)

# COMMAND ----------

target_view_mexico_all = (
    f"{PIPELINE_WRITE_ENV}_proj.hr.hr_workforce_proj_all_mexico_employees"
)
source_pii_table = f"sd_{PIPELINE_READ_ENV}_gold.hr.hr_workforce_gold_history"
source_table = f"{PIPELINE_READ_ENV}_gold.hr.hr_workforce_gold_history"

spark.sql(
    f"""
CREATE OR REPLACE VIEW {target_view_mexico_all} AS
WITH CTE_CLEAR AS (
    SELECT *
    FROM (
        SELECT
            *,
            ROW_NUMBER() OVER (
                PARTITION BY User_ID
                ORDER BY _meta_extraction_timestamp DESC
            ) AS rn
        FROM {source_pii_table}
    )
    WHERE rn = 1
)
SELECT
    CTE_CLEAR.User_ID as user_id,                -- Employee unique identifier
    CTE_CLEAR.First_name as first_name,             -- Employee first name
    CTE_CLEAR.Last_name as last_name,              -- Employee last name
    GOLD.Status as status,                          -- Employee status (e.g. ACTIVE, INACTIVE)
    GOLD.ID_Manager as manager_id,                  -- Manager's User_ID
    CTE_CLEAR_2.First_name AS manager_first_name, -- Manager's first name
    CTE_CLEAR_2.Last_name  AS manager_last_name   -- Manager's last name
FROM CTE_CLEAR
INNER JOIN {source_table} GOLD
    ON CTE_CLEAR._meta_stack_row_id = GOLD._meta_stack_row_id
LEFT JOIN CTE_CLEAR CTE_CLEAR_2
    ON GOLD.ID_Manager = CTE_CLEAR_2.User_ID
WHERE UPPER(GOLD.Workplace_Country) = 'MEXICO';"""
).display()

# COMMAND ----------

spark.sql(
    f"""
COMMENT ON VIEW {target_view_mexico_all} IS
'Shows all employees (any status) whose workplace_country is Mexico, with their status and manager first and last name.';
"""
)

spark.sql(
    f"""
COMMENT ON COLUMN {target_view_mexico_all}.user_id IS 'Employee unique identifier';
"""
)

spark.sql(
    f"""
COMMENT ON COLUMN {target_view_mexico_all}.first_name IS 'Employee first name';
"""
)

spark.sql(
    f"""
COMMENT ON COLUMN {target_view_mexico_all}.last_name IS 'Employee last name';
"""
)
spark.sql(
    f"""
COMMENT ON COLUMN {target_view_mexico_all}.status IS 'Employee status (e.g. ACTIVE, INACTIVE)';
"""
)
spark.sql(
    f"""
COMMENT ON COLUMN {target_view_mexico_all}.manager_id IS 'Manager User_ID';
"""
)
spark.sql(
    f"""
COMMENT ON COLUMN {target_view_mexico_all}.manager_first_name IS 'Manager first name';
"""
)
spark.sql(
    f"""
COMMENT ON COLUMN {target_view_mexico_all}.manager_last_name IS 'Manager last name';
"""
)

# COMMAND ----------

spark.sql(
    f"""
ALTER TABLE {target_view_mexico_all} SET TAGS ('HR');
"""
)
spark.sql(
    f"""
ALTER TABLE {target_view_mexico_all} SET TAGS ('domain' = 'HR');
"""
)
spark.sql(
    f"""
ALTER TABLE {target_view_mexico_all} ALTER COLUMN user_id SET TAGS ('primary_key','class.name');
"""
).display()
spark.sql(
    f"""
ALTER TABLE {target_view_mexico_all} ALTER COLUMN first_name SET TAGS ('class.name');
"""
).display()
spark.sql(
    f"""
ALTER TABLE {target_view_mexico_all} ALTER COLUMN last_name SET TAGS ('class.name');
"""
).display()
spark.sql(
    f"""
ALTER TABLE {target_view_mexico_all} ALTER COLUMN manager_first_name SET TAGS ('class.name');
"""
).display()
spark.sql(
    f"""
ALTER TABLE {target_view_mexico_all} ALTER COLUMN manager_last_name SET TAGS ('class.name');
"""
).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Finance view monthly (all countries, PII in clear)
# MAGIC
# MAGIC Global monthly workforce history : one row per `user_id` per month =
# MAGIC the **last extraction of the month** (`_leap_extraction_date` = max over the month), with a
# MAGIC wider set of business fields. `user_id`, `first_name`, `last_name` are exposed **in clear**,
# MAGIC read from the `sd_{env}_gold` catalog (same pattern as the mexico views) and joined to the
# MAGIC regular gold on `_meta_stack_row_id`; every other (non-PII) field comes from the regular gold.
# MAGIC Replaces the PowerBI native query that read the masked `{env}_gold` table directly.

# COMMAND ----------

target_view_finance_monthly = (
    f"sd_{PIPELINE_WRITE_ENV}_gold.hr.hr_workforce_gold_finance_view_monthly"
)
source_pii_table = f"sd_{PIPELINE_READ_ENV}_gold.hr.hr_workforce_gold_history"
source_table = f"{PIPELINE_READ_ENV}_gold.hr.hr_workforce_gold_history"

spark.sql(
    f"""
CREATE OR REPLACE VIEW {target_view_finance_monthly} AS
WITH month_last AS (
    -- last extraction day of each month (global), so each user appears once per month
    SELECT
        h.*,
        MAX(_leap_extraction_date) OVER (
            PARTITION BY _leap_year_month_extraction_date
        ) AS _max_month_extraction_date
    FROM {source_table} h
),
gold_month AS (
    SELECT * FROM month_last
    WHERE _leap_extraction_date = _max_month_extraction_date
),
clear AS (
    -- PII in clear from the sd_ catalog, keyed by the stack row id
    SELECT _meta_stack_row_id, User_ID, First_name, Last_name
    FROM {source_pii_table}
)
SELECT
    GOLD._meta_ID,
    REGEXP_REPLACE(CLEAR.User_ID, '^0+', '') AS User_ID,   -- in clear, leading zeros stripped
    GOLD._leap_extraction_date,
    GOLD._leap_year_month_extraction_date,
    CLEAR.First_name,                                       -- in clear
    CLEAR.Last_name,                                        -- in clear
    GOLD.Status,
    GOLD.Contract_Type,
    GOLD.Company_Seniority_Date,
    GOLD.Last_hire_date,
    GOLD.End_Date,
    GOLD.Category,
    GOLD.Company,
    GOLD.Workplace,
    GOLD.Workplace_Country,
    GOLD.Organization,
    GOLD.Department,
    GOLD.Service,
    GOLD.Cost_Center,
    GOLD.Level,
    GOLD.Grade,
    GOLD.Coefficient,
    GOLD.Job_family,
    GOLD.Job_family_code,
    GOLD.Job_speciality,
    GOLD.Job_speciality_code,
    GOLD.STU,
    GOLD.Contract_suspension_start_date,
    GOLD.Contract_suspension_end_date
FROM gold_month GOLD
INNER JOIN clear CLEAR
    ON GOLD._meta_stack_row_id = CLEAR._meta_stack_row_id;"""
).display()

# COMMAND ----------

spark.sql(
    f"""
COMMENT ON VIEW {target_view_finance_monthly} IS
'Global monthly workforce history (all countries): one row per user_id per month (last extraction of the month), with user_id / first_name / last_name in clear (sourced from sd_ gold).';
"""
)

for _col, _cmt in {
    "User_ID": "Employee unique identifier (in clear, leading zeros stripped)",
    "_leap_extraction_date": "Last extraction date of the month",
    "_leap_year_month_extraction_date": "Extraction month (yyyy-MM) — grain with User_ID",
    "First_name": "Employee first name (in clear)",
    "Last_name": "Employee last name (in clear)",
    "Status": "Employee status (e.g. ACTIVE, INACTIVE)",
}.items():
    spark.sql(
        f"COMMENT ON COLUMN {target_view_finance_monthly}.{_col} IS '{_cmt}'"
    )

# COMMAND ----------

spark.sql(f"ALTER TABLE {target_view_finance_monthly} SET TAGS ('HR')")
spark.sql(f"ALTER TABLE {target_view_finance_monthly} SET TAGS ('domain' = 'HR')")
# PII columns tagged for lineage/governance (grain = User_ID + month, so User_ID is NOT a PK here)
for _pii in ["User_ID", "First_name", "Last_name"]:
    spark.sql(
        f"ALTER TABLE {target_view_finance_monthly} ALTER COLUMN {_pii} SET TAGS ('class.name')"
    ).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
