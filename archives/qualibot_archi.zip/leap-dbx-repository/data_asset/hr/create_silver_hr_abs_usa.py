# Databricks notebook source
# DBTITLE 1,Silver — USA Absences
# MAGIC %md
# MAGIC ## Silver HR Absences — USA
# MAGIC
# MAGIC Autonomous notebook: reads USA absences from bronze cleaned, maps to unified silver schema,
# MAGIC and writes to silver tables with `REPLACE WHERE source = 'USA'`.
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | TriNet | `{pipeline_read_env}_bronze_cleaned_hr` | `usa_abs` | `usa_abs_latest` |
# MAGIC
# MAGIC **Target**:
# MAGIC - `fact_absence_day` — one row per calendar day (exploded from TriNet episodes)
# MAGIC
# MAGIC **Filter**: Valid records only (`_meta_validity_check = true`). Excludes null `time_off_type`
# MAGIC and null `latecoere_id`.
# MAGIC
# MAGIC ### id\_group resolution — latecoere\_id direct mapping
# MAGIC
# MAGIC `latecoere_id` in bronze cleaned maps directly to `immat.user_id`
# MAGIC
# MAGIC Rows with null `latecoere_id` are filtered out.
# MAGIC
# MAGIC ### fact\_absence\_day
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` (column `source = 'USA'`)
# MAGIC
# MAGIC TriNet episodes are exploded to one row per calendar day (same pattern as Senior).
# MAGIC Grain: one row per `id_group × absence_date × day_order × source`.
# MAGIC `absence_duration_min` two-pass dispatch: fill half-days (4h) to each weekday first,
# MAGIC then upgrade to full days (8h) in order, remainder at the end. Weekends get 0.
# MAGIC `absence_day_value`: > 240 min → 1.0, > 0 min → 0.5, 0 min → 0.0.
# MAGIC Filtering to actual working days is left to the absenteeism KPI layer.

# COMMAND ----------

# DBTITLE 1,Config
import re
from pyspark.sql import Window
from pyspark.sql import functions as f
from data_asset.hr.utils.table_schema_map_utils import load_config
from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger
from great_expectations.dataset import SparkDFDataset
from great_expectations.core import ExpectationSuiteValidationResult

# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# --- Source ---
BRONZE_CLEANED_CATALOG = f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
USA_SCHEMA = "usa_abs"
USA_ABSENCES_TABLE = "usa_abs_latest"
# --- Business rules ---
USA_DATE_FORMAT = "MM/dd/yyyy"  # TriNet date format in source columns
ABSENCE_DAY_THRESHOLD_MIN = 240  # > 4h = 1 day, <= 4h = 0.5 day

# --- Target (from YAML contract — single source of truth) ---
SOURCE = "USA"
config = load_config(config_path="config/silver_abs_column_mapping.yaml")
_target = config["target"]
SILVER_CATALOG = f"{PIPELINE_WRITE_ENV}_silver_hr"
SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{_target['schema']}.{_target['table']}"

log.info(f"[{SOURCE}] Target = {SILVER_FULL_TABLE}")

# COMMAND ----------

# DBTITLE 1,Specific parameter
dbutils.widgets.text("min_absence_date", "2025-12-01")
MIN_ABSENCE_DATE = dbutils.widgets.get("min_absence_date")

match = re.match(r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})$", MIN_ABSENCE_DATE)
if not match:
    raise ValueError("Invalid date format for min absence date. Expected YYYY-MM-DD")

# COMMAND ----------

# DBTITLE 1,Non-PII Cleaning
# MAGIC %md
# MAGIC ## Non-PII Cleaning
# MAGIC
# MAGIC Standard cleaning applied to all Silver absence notebooks **after** column mapping.
# MAGIC PII cleaning is already handled upstream (Bronze → Bronze Cleaned).
# MAGIC
# MAGIC Rules applied here:
# MAGIC 1. **Trim** all string columns (remove leading/trailing whitespace)
# MAGIC 2. **Nullify** empty strings (consistent NULL representation)
# MAGIC 3. **Drop rows where mandatory fields are null** (driven from YAML contract)
# MAGIC
# MAGIC → `data_asset.hr.utils.silver_cleaning_utils`

# COMMAND ----------

# DBTITLE 1,read_usa_absences
def read_usa_absences():
    """
    Read and map USA (TriNet) absence episodes to the silver daily schema.

    Explodes each episode to one row per calendar day (same pattern as Senior).
    Filtering to actual working days is left to the absenteeism KPI layer.
    id_group: latecoere_id from bronze_cleaned (= immat.user_id, 100% match).
    absence_duration_min: two-pass dispatch over weekday days:
    Pass 1 — fill 4h (half-day) to each weekday in order.
    Pass 2 — fill another 4h to each weekday in order (upgrade to full day).
    Remainder allocated to the next weekday in sequence.
    Weekends always get 0 min.
    absence_day_value: > 240 min → 1.0, > 0 min → 0.5, 0 min → 0.0.
    """
    raw = spark.table(
        f"{BRONZE_CLEANED_CATALOG}.{USA_SCHEMA}.{USA_ABSENCES_TABLE}"
    ).filter(
        (f.col("_meta_validity_check") == True)
        & f.col("time_off_type").isNotNull()
        & f.col("latecoere_id").isNotNull()
        & (f.col("latecoere_id") != "")
    )

    # remove vacation entries fully cancelled by a vacation Adjustment
    w = Window.partitionBy("latecoere_id", "time_off_start", "time_off_end")

    raw = (
        raw.withColumn("_sum_hours", f.sum("total_hours").over(w))
        .withColumn("_types", f.collect_set("time_off_type").over(w))
        .filter(
            ~(
                (f.col("_sum_hours") == 0)
                & (f.array_contains(f.col("_types"), "Vacation - Adjustment"))
                & (f.array_contains(f.col("_types"), "Vacation"))
            )
        )
        .drop("_sum_hours", "_types")
    )

    # parse dates
    df_with_dates = raw.withColumns(
        {
            "_episode_start": f.to_date("time_off_start", USA_DATE_FORMAT),
            "_episode_end": f.to_date("time_off_end", USA_DATE_FORMAT),
        }
    )

    # explode episode to one row per calendar day
    df_exploded = df_with_dates.withColumn(
        "absence_date",
        f.explode(f.sequence(f.col("_episode_start"), f.col("_episode_end"))),
    ).withColumn(
        "_is_weekday",
        f.dayofweek("absence_date").between(2, 6),  # Mon=2 ... Fri=6
    )

    # count weekday days per episode + rank each weekday within its episode
    _w_ep_unbound = Window.partitionBy(
        "latecoere_id", "_episode_start", "_episode_end", "time_off_type"
    )
    _w_ep_cumul = _w_ep_unbound.orderBy(
        "absence_date"
    ).rowsBetween(Window.unboundedPreceding, Window.currentRow)

    df_exploded = df_exploded.withColumns(
        {
            "_weekday_count": f.sum(
                f.when(f.col("_is_weekday"), 1).otherwise(0)
            ).over(_w_ep_unbound),
            "_weekday_rank": f.sum(
                f.when(f.col("_is_weekday"), 1).otherwise(0)
            ).over(_w_ep_cumul),
        }
    )

    # two-pass dispatch: fill half-days (4h) first, then upgrade to full days
    _hours = f.col("total_hours").cast("double")
    _slots = f.floor(_hours / 4)            # number of 4h blocks available
    _rem = ((_hours % 4) * 60).cast("long")  # leftover minutes after 4h blocks
    _rank = f.col("_weekday_rank")
    _pass2_pos = f.col("_weekday_count") + _rank

    _pass1 = (
        f.when(_rank <= _slots, 240)
        .when((_rank == _slots + 1) & (_rem > 0), _rem)
        .otherwise(0)
    )
    _pass2 = (
        f.when(_pass2_pos <= _slots, 240)
        .when((_pass2_pos == _slots + 1) & (_rem > 0), _rem)
        .otherwise(0)
    )

    df_exploded = df_exploded.withColumn(
        "_per_day_duration_min",
        f.when(~f.col("_is_weekday"), f.lit(0))     # weekend -> 0
        .otherwise((_pass1 + _pass2).cast("long")),   # two-pass dispatch (null hours -> 0)
    )

    return (
        df_exploded.select(
            f.col("latecoere_id").alias("id_group"),
            f.col("absence_date"),
            f.col("time_off_type").alias("absence_type_code"),
            f.col("time_off_type").alias("absence_type_desc"),
            f.col("_per_day_duration_min").alias("absence_duration_min"),
            f.when(f.col("_per_day_duration_min") > ABSENCE_DAY_THRESHOLD_MIN, 1.0)
            .when(f.col("_per_day_duration_min") > 0, 0.5)
            .otherwise(0.0)
            .alias("absence_day_value"),
        )
        .dropDuplicates()  # defensive guard
        .withColumn(
            "day_order",
            f.row_number().over(
                Window.partitionBy("id_group", "absence_date").orderBy(
                    "absence_type_code"
                )
            ),
        )
        .withColumn("source", f.lit(SOURCE))
    )

# COMMAND ----------

# DBTITLE 1,Input data
df_raw = read_usa_absences()

df_raw = df_raw.filter(
    f.col("absence_date") >= f.to_date(f.lit(MIN_ABSENCE_DATE))
)

# COMMAND ----------

# DBTITLE 1,Specific Quality checks
def _build_extra_red_results(
    df_gx: SparkDFDataset,
) -> list[ExpectationSuiteValidationResult]:
    return [
        # absence_duration_min >= 0 and <= 1440 (no single-day absence > 24h)
        df_gx.expect_column_values_to_be_between(
            column="absence_duration_min",
            min_value=0,
            max_value=1440,
        ),
        # absence_day_value in [0, 1]
        df_gx.expect_column_values_to_be_between(
            column="absence_day_value",
            min_value=0,
            max_value=1,
            mostly=1.0,
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_raw,
    config=config,
    full_table_path=SILVER_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=True,
    drop_null_pk_rows=True,
    cluster_cols="source, id_group",
    replace_where=f"source = '{SOURCE}'",
    is_debug=LOG_LEVEL == "debug",
)
