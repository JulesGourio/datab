# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Silver HR Absences — Kelio
# MAGIC %md
# MAGIC ## Silver HR Absences — Kelio
# MAGIC
# MAGIC Autonomous notebook: reads Kelio absences from bronze cleaned, maps to unified silver schema,
# MAGIC and writes to `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` with `REPLACE WHERE source = 'KELIO'`.
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | Kelio absences | `{pipeline_read_env}_bronze_cleaned_hr` | `kelio` | `affectation_absence_latest` |
# MAGIC | Kelio motif ref | `{pipeline_read_env}_bronze_cleaned_hr` | `kelio` | `motif_calcul_latest` |
# MAGIC | Kelio employee ref | `{pipeline_read_env}_bronze_cleaned_hr` | `kelio` | `salarie_latest` |
# MAGIC | Immat monthly history | `{pipeline_read_env}_gold_hr` | `immat` | `immat_monthly_history` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` (column `source = 'KELIO'`)
# MAGIC
# MAGIC **Filter**: Valid records only (`_meta_validity_check = true`). Excludes null `absence_motif_absence`.
# MAGIC
# MAGIC **id_group resolution**: Kelio `salarie_latest.matricule` is a local payroll number = `immat.id_local` scoped to
# MAGIC `company_code = 'SEA'` (Kelio serves SEA-LATELEC, Tunisia: Fouchana + Charguia). An inner join with
# MAGIC gold `immat_monthly_history` resolves `matricule → id_local → user_id` (group-wide). Recycled id_local
# MAGIC values (employee leaves, number reused) are deduped ACTIVE-first; genuinely ambiguous ones (same status,
# MAGIC multiple user_ids) are excluded and logged. Match rate: ~89%. Unmatched matricules are dropped by the inner join.
# MAGIC
# MAGIC **Note**: Kelio provides episode-based absences (absence_date_debut → absence_date_fin). Each episode is exploded to one row per calendar day. Filtering to actual working days is the responsibility of the absenteeism KPI layer, driven by dim_calendar. `absence_duration_min` defaults to 480 min (8h) — no time granularity available. `absence_day_value` is always 1.0. `absence_type_code` = numeric `absence_motif_absence` cast as string — unique by construction (Kelio PK). `absence_type_desc` resolved via left join with `motif_calcul_latest` on `absence_motif_absence = motif_calcul` (`libelle`) — null when no match.

# COMMAND ----------

# DBTITLE 1,Config
from pyspark.sql import functions as f, Window

from data_asset.hr.utils.table_schema_map_utils import load_config
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# --- Source ---
BRONZE_CLEANED_CATALOG = f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
KELIO_SCHEMA           = "kelio"
KELIO_ABSENCES_TABLE   = "affectation_absence_latest"  # one row per absence episode (start → end date) — source of all absence records
KELIO_MOTIF_REF_TABLE  = "motif_calcul_latest"         # absence type reference — maps absence_motif_absence (Kelio surrogate key) to a human-readable label
KELIO_SALARIE_TABLE    = "salarie_latest"              # employee reference — maps Kelio salarie/personne to payroll matricule used by immat
KELIO_COMPANY_CODE     = "SEA"                         # Kelio = SEA-LATELEC (Tunisia: Fouchana + Charguia) — scopes the id_local → user_id join

config            = load_config(config_path="config/silver_abs_column_mapping.yaml")
_target           = config["target"]
SILVER_CATALOG    = f"{PIPELINE_WRITE_ENV}_silver_hr"
SILVER_SCHEMA     = _target["schema"]
SILVER_TABLE      = _target["table"]
SOURCE            = "KELIO"

SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# Derive MIN_ABSENCE_DATE from immat coverage start (absences before immat cannot be enriched)
_immat_table = f"{PIPELINE_READ_ENV}_gold_hr.immat.immat_monthly_history"
_min_immat_month = spark.table(_immat_table).select(f.min("year_month")).collect()[0][0]
MIN_ABSENCE_DATE = f"{_min_immat_month}-01"
log.info(f"[{SOURCE}] MIN_ABSENCE_DATE = {MIN_ABSENCE_DATE} (immat coverage floor)")

# COMMAND ----------

# DBTITLE 1,Non-PII Cleaning
# MAGIC %md
# MAGIC ### Non-PII Cleaning
# MAGIC Applied by `clean_non_pii` after column mapping:
# MAGIC 1. Trim all string columns and nullify empty strings
# MAGIC 2. Drop rows where any mandatory column (YAML contract) is null

# COMMAND ----------

# DBTITLE 1,read_kelio_absences
def read_kelio_absences():
    """
    Read and map Kelio absence records to the silver schema.

    Source filter: _meta_validity_check = True (currently always true — defensive guard)
    and absence_motif_absence IS NOT NULL.
    absence_type_code = absence_motif_absence cast as string — unique by construction (Kelio PK).
    Left join with motif_calcul_latest on absence_motif_absence = motif_calcul resolves
    absence_type_desc (libelle). Null when no ref match.
    Left join with salarie_latest on salarie = personne resolves the payroll matricule.
    Inner join with immat on matricule = id_local (company_code = SEA) resolves the group-wide
    user_id used as id_group. id_local is a local payroll number recycled across companies —
    the SEA filter and ACTIVE-first dedup handle collisions. Genuinely ambiguous id_local
    values (same status, multiple user_ids) are excluded and logged.
    Episodes (absence_date_debut to absence_date_fin) are exploded to one row per calendar day.
    Filtering to actual working days is left to the absenteeism KPI layer, driven by dim_calendar.

    absence_duration_min defaults to 480 min (8h) -- Kelio does not store time granularity for full-day absences.
    absence_day_value is always 1.0 -- full day assumed for all Kelio absences.
    dropDuplicates() after select removes Airbyte double-ingestion duplicates (685 episodes
    affected in _latest — same BK, different _airbyte_raw_id). Placed after select so only
    silver columns are compared, before day_order assignment to avoid inflating counts.
    """
    motif_ref = (
        spark.table(f"{BRONZE_CLEANED_CATALOG}.{KELIO_SCHEMA}.{KELIO_MOTIF_REF_TABLE}")
        .select(
            f.col("motif_calcul").alias("_ref_motif_calcul"),  # motif_calcul: Kelio internal surrogate key — PK of this reference table
            f.col("libelle").alias("_ref_libelle"),            # libelle: human-readable absence type label (e.g. "MALADIE", "CONGE ANNUEL")
        )
    )
    salarie_ref = (
        spark.table(f"{BRONZE_CLEANED_CATALOG}.{KELIO_SCHEMA}.{KELIO_SALARIE_TABLE}")
        .select(
            f.col("personne").alias("_ref_personne"),
            f.col("matricule").alias("_ref_matricule"),
        )
    )
    # Resolve Kelio matricule → immat user_id via id_local within SEA (gold immat_monthly_history).
    # id_local can be recycled (employee leaves, number reused): dedup ACTIVE first.
    # Exclude genuinely ambiguous id_local (same status, multiple user_ids).
    _immat_sea = (
        spark.table(_immat_table)  # gold immat_monthly_history — already referenced in config
        .filter((f.col("company_code") == KELIO_COMPANY_CODE) & f.col("id_local").isNotNull())
        .select("id_local", "user_id", "status")
        .distinct()  # collapse monthly rows to unique (id_local, user_id, status) triples
    )
    _w_immat = Window.partitionBy("id_local").orderBy(
        f.when(f.col("status") == "ACTIVE", 0).otherwise(1)
    )
    _deduped = _immat_sea.withColumn("_rn", f.row_number().over(_w_immat)).filter("_rn == 1").drop("_rn")
    _uid_counts = _immat_sea.groupBy("id_local", "status").agg(f.countDistinct("user_id").alias("_n"))
    _ambiguous = (
        _deduped.select("id_local", "status")
        .join(_uid_counts, on=["id_local", "status"])
        .filter(f.col("_n") > 1)
        .select("id_local")
    )
    _excl_count = _ambiguous.count()
    if _excl_count > 0:
        _excl_ids = [r.id_local for r in _ambiguous.collect()]
        log.warning(f"[{SOURCE}] {_excl_count} ambiguous id_local excluded: {_excl_ids}")
    immat_ref = (
        _deduped
        .join(_ambiguous, on="id_local", how="left_anti")
        .select(
            f.col("id_local").alias("_ref_id_local"),
            f.col("user_id").alias("_ref_user_id"),
        )
    )

    raw = (
        spark.table(f"{BRONZE_CLEANED_CATALOG}.{KELIO_SCHEMA}.{KELIO_ABSENCES_TABLE}")
        .filter(
            (f.col("_meta_validity_check")) &  # currently always true — defensive guard
            (f.col("absence_motif_absence").isNotNull()) &  # absence_motif_absence: numeric absence reason code assigned by HR — null means unclassified
            (f.col("absence_date_debut") >= MIN_ABSENCE_DATE)
        )
    )
    df = (
        raw
        .join(motif_ref, raw.absence_motif_absence == motif_ref._ref_motif_calcul, "left")
        .join(salarie_ref, raw.salarie.cast("string") == salarie_ref._ref_personne, "left")
        .join(immat_ref, f.col("_ref_matricule") == immat_ref._ref_id_local, "inner")
        .withColumns({
            "id_group": f.col("_ref_user_id"),  # group-wide employee ID resolved via immat
            # absence_date_debut: episode start, absence_date_fin: episode end — each episode becomes one row per calendar day
            "absence_date": f.explode(f.sequence(f.to_date("absence_date_debut"), f.to_date("absence_date_fin"))),
        })
    )
    w = Window.partitionBy("id_group", "absence_date").orderBy("absence_motif_absence")
    return (
        df.select(
            f.col("id_group"),
            f.col("absence_date"),
            f.col("absence_motif_absence").cast("string").alias("absence_type_code"),
            f.col("_ref_libelle").alias("absence_type_desc"),
            f.lit(480).cast("long").alias("absence_duration_min"),
            f.lit(1.0).alias("absence_day_value"),
        )
        .dropDuplicates()  # removes Airbyte double-ingestion (same silver cols, different _airbyte_raw_id)
        .withColumn("day_order", f.row_number().over(
            Window.partitionBy("id_group", "absence_date").orderBy("absence_type_code")
        ))
        .withColumn("source", f.lit(SOURCE))
    )

# COMMAND ----------

# DBTITLE 1,Input data
df_raw = read_kelio_absences()

if LOG_LEVEL == "debug":
    count_raw = df_raw.count()
    log.debug(f"[{SOURCE}] {count_raw:,} rows after read + mapping")

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
def _build_extra_red_results(
    df_gx: SparkDFDataset,
) -> list[ExpectationSuiteValidationResult]:
    return [
        # absence_duration_min >= 0 and <= 1440 (no single-day absence > 24h)
        df_gx.expect_column_values_to_be_between(
            column="absence_duration_min",
            min_value=0,
            max_value=1440,
        ),
        # absence_day_value in [0, 1]
        df_gx.expect_column_values_to_be_between(
            column="absence_day_value",
            min_value=0,
            max_value=1,
            mostly=1.0,
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_raw,
    config=config,
    full_table_path=SILVER_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=True,
    drop_null_pk_rows=True,
    cluster_cols="source, id_group",
    replace_where=f"source = '{SOURCE}'",
    is_debug=LOG_LEVEL == "debug",
)
