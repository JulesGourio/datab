# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # HR REFERENTIAL SILVER
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to build silver data asset for HR Referential.
# MAGIC - 1st STEP : cleaning bronze
# MAGIC - 2nd STEP : tokenize PII
# MAGIC - 3rd STEP : save silver based on daily dataset history
# MAGIC - 4th STEP : historize
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - hr data asset.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - sd_{pipeline_read_env}_bronze.hr.v_report_rh_leap_latest
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.hr.hr_workforce_silver_stack_history
# MAGIC - {pipeline_write_env}_proj.hr.pii_mapping_table
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
import random
import great_expectations as gx
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("init_from", "1970-01-01")  # history/update
INIT_FROM = dbutils.widgets.get("init_from")

dbutils.widgets.text("init_to", "2099-12-31")  # history/update
INIT_TO = dbutils.widgets.get("init_to")

dbutils.widgets.dropdown(
    "run_mode", "delta", ["init_complete", "init_partial", "delta"]
)

try:
    _legacy_run_mode = dbutils.widgets.get("run_mode")
except:
    _legacy_run_mode = None

dbutils.widgets.dropdown(
    "silver_run_mode",
    _legacy_run_mode if _legacy_run_mode else "delta",
    ["init_complete", "init_partial", "delta"],
)
SILVER_RUN_MODE = dbutils.widgets.get("silver_run_mode")
RUN_MODE = SILVER_RUN_MODE

# For Status Quality check
dbutils.widgets.text(
    "status_change_alert_threshold_pct", "1.0"
)  # percentage or whole number
dbutils.widgets.text(
    "status_change_min_population", "100"
)  # minimum of common IDs between D & D-1 for evaluation
dbutils.widgets.dropdown("status_change_alert_mode", "ratio", ["ratio", "count"])

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ### force_reinitialization Boolean
# MAGIC
# MAGIC force_reinitialization -> Used for force ingestion of all S3 files.

# COMMAND ----------

# If force_reinitialization is True then the stack table will be reinitialized
dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = dbutils.widgets.get("force_reinitialization").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

BRONZE_CATALOG = f"sd_{PIPELINE_READ_ENV}_bronze"
BRONZE_SCHEMA = "hr"

# REPORT_RH_BRONZE_STACK_TABLE
REPORT_RH_BRONZE_STACK_TABLE = (
    f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.v_report_rh_leap_stack"
)
# REPORT_RH_BRONZE_STACK_TABLE
REPORT_RH_BRONZE_LATEST_TABLE = (
    f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.v_report_rh_leap_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SILVER_SCHEMA = "hr"
PROJ_CATALOG = f"{PIPELINE_WRITE_ENV}_proj"
PROJ_SCHEMA = "hr"

TOKEN_VAULT_TABLE = f"sd_{PIPELINE_WRITE_ENV}_bronze.token_vault.pii_data"
TOKEN_VAULT_MAPPING_TABLE = f"{PROJ_CATALOG}.{PROJ_SCHEMA}.pii_mapping_table"
REPORT_RH_SILVER_STACK_TABLE = (
    f"{SILVER_CATALOG}.{SILVER_SCHEMA}.hr_workforce_silver_stack_history"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

TABLE_SILVER_FIRST_COLS = {
    "_meta_stack_row_id": "STRING COMMENT 'STACK UNIQUE ID GENERATED ALWAYS AS IDENTITY'",
    "_meta_ID": "STRING",
    "_meta_extraction_timestamp": "TIMESTAMP",
    "_meta_ingestion_timestamp": "TIMESTAMP",
    "_meta_file_name": "STRING",
    "_meta_file_mode": "STRING",
    "_meta_file_path": "STRING",
    "User_ID": "STRING",
    "_leap_extraction_date": "DATE",
    "First_name": "STRING",
    "Last_name": "STRING",
    "Email": "STRING",
    "IT_Account": "STRING",
    "ID_Local": "STRING",
    "Maiden_Name": "STRING",
}

TOKEN_VAULT_COLS = {
    "OriginalValue": "STRING",
    "HashedValue": "STRING",
}

# COMMAND ----------

# MAGIC %md
# MAGIC #### for the Silver History

# COMMAND ----------

# attributes for table REPORT_RH_SILVER_STACK_TABLE
SILVER_ATTRS_DICT = {
    "string_cols": [
        "_meta_stack_row_id"
    ],  # casted to string because bronze is union of landingzone stack tables with prefix
    "float_cols": [],
    "columns_to_drop": ["Conv__Category"],
    "columns_to_trim": [
        "Job",
        "Category",
        "Company",
        "Establishment",
        "Workplace",
        "Organization",
        "Department",
        "Service",
        "Reason_for_leaving",
        "Workplace_country",
        "Conventional_category_name",
        "Working_day",
        "Country",
        "Nationality",
        "External_company",
        "Job_family",
        "Job_speciality",
        "Category",
    ],
    "columns_to_replace_nulls_by_unknown": [
        "Job",
        "Category",
        "Company",
        "Establishment",
        "Workplace",
        "Department",
        "Service",
        "Conventional_category_name",
        "Working_day",
        "Country",
        "Nationality",
        "Job_family",
        "Job_speciality",
        "Category",
    ],
    "date_cols": ["Company_Seniority_Date", "Last_hire_date", "End_Date"],
    "primary_key": "User_ID,_leap_extraction_date",
    "notnull_cols": "User_ID,First_name,Last_name",
    "cluster_cols": "User_ID,_leap_extraction_date",
    "columns_to_hash": [
        "User_ID",
        "First_name",
        "Last_name",
        "Email",
        "IT_Account",
        "ID_Local",
        "Maiden_Name",
        "Business_Phone",
        "Cell_Phone",
    ],
    "columns_to_clean_before_hashing": ["User_ID", "Email"],
    "date_to_year": ["Birth_date"],
    "columns_with_country_name": ["Workplace_country", "Country", "Country_of_company"],
}

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# MAGIC %md
# MAGIC #### Common global variables

# COMMAND ----------

THE_ORIGIN = "1970-01-01"
THE_MAX_DATE = "2099-12-31"

# Flag to avoid processing Empty Dataframe
EMPTY_DATAFRAME_FLAG = False

# COMMAND ----------

# MAGIC %md
# MAGIC #### Analyzing widget RUN_MODE and set global variables

# COMMAND ----------

if (table_utils.UnityCatalogCheckTableExists(REPORT_RH_SILVER_STACK_TABLE)) and (
    RUN_MODE == "delta"
):
    MODE = "append"
    # INIT_FROM and INIT_TO taken from widgets
    RUN_JOB_ON_LATEST = True
elif (table_utils.UnityCatalogCheckTableExists(REPORT_RH_SILVER_STACK_TABLE)) and (
    RUN_MODE == "init_partial"
):
    MODE = "append"
    # INIT_FROM and INIT_TO taken from widgets
    RUN_JOB_ON_LATEST = False
elif RUN_MODE == "init_partial":
    MODE = "overwrite"
    # INIT_FROM and INIT_TO taken from widgets
    RUN_JOB_ON_LATEST = False
elif RUN_MODE == "init_complete":
    MODE = "overwrite"
    RUN_JOB_ON_LATEST = False
    INIT_FROM = THE_ORIGIN
    INIT_TO = THE_MAX_DATE
    FORCE_REINITIALIZATION = True
else:
    MODE = "overwrite"
    RUN_JOB_ON_LATEST = False
    INIT_FROM = THE_ORIGIN
    INIT_TO = THE_MAX_DATE

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"FORCE_REINITIALIZATION is:  {FORCE_REINITIALIZATION}")
log.info(f"BRONZE_CATALOG is:  {BRONZE_CATALOG}")
log.info(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.info(f"SILVER_CATALOG is:  {SILVER_CATALOG}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"RUN_MODE is:  {RUN_MODE}")
log.info(f"RUN_JOB_ON_LATEST is:  {RUN_JOB_ON_LATEST}")
log.info(f"REPORT_RH_SILVER_STACK_TABLE is:  {REPORT_RH_SILVER_STACK_TABLE}")
log.info(f"MODE is:  {MODE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks - Functions

# COMMAND ----------

# Imported from leap_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Tables Read
# MAGIC - Clean Data
# MAGIC - Hash columns
# MAGIC - Table Write

# COMMAND ----------

# Create the empty token vault if not exists

catalog, schema, table = TOKEN_VAULT_TABLE.split(".")

try:
    table_utils.create_unity_catalog_table(
        catalog,
        schema,
        table,
        force_reinitialization=False,
        cluster_cols=None,
        partition_col=None,
        primary_key_cols=None,
        columns=TOKEN_VAULT_COLS,
        force_drop=False,
    )
except AnalysisException as e:
    log.error(
        f"Table {TOKEN_VAULT_TABLE} has not been created, an error occured during creation. \nError is {e}"
    )
    raise OSError(
        f"An error occurred while creating the table {TOKEN_VAULT_TABLE}"
    ) from e

# COMMAND ----------

# Upload token vault
df_token_vault = spark.read.table(TOKEN_VAULT_TABLE)

# COMMAND ----------

# Upload REPORT_RH_BRONZE_STACK_TABLE
df_report_rh_bronze_stack = (
    spark.read.table(f"{REPORT_RH_BRONZE_STACK_TABLE}")
    .filter(f.col("_meta_extraction_timestamp") >= INIT_FROM)
    .filter(f.col("_meta_extraction_timestamp") <= INIT_TO)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------


def clean_before_hashing(df, columns):
    """
    Cleans specified columns by trimming whitespace and converting to lowercase.

    :param df: The Spark DataFrame to modify.
    :type df: SparkDataFrame
    :param columns: A list of column names to clean (trim and lowercase).
    :type columns: list
    :return: A new Spark DataFrame with cleaned columns.
    :rtype: SparkDataFrame
    """
    for col in columns:
        df = df.withColumn(col, f.lower(f.trim(f.col(col))))
    return df


def trim_columns(df, columns):
    """
    Trim leading and trailing whitespace characters from specified columns in a DataFrame.

    :param df: The Spark DataFrame to modify.
    :type df: SparkDataFrame
    :param columns: A list of column names to trim.
    :type columns: list
    :return: A new Spark DataFrame with the specified columns trimmed.
    :rtype: SparkDataFrame
    """
    for col in columns:
        df = df.withColumn(col, f.trim(f.col(col)))
    return df


# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - If RUN_JOB_ON_LATEST Filter all tables on needed stacks

# COMMAND ----------

# check job type - Filter all tables on needed stacks
if RUN_JOB_ON_LATEST:
    log.info(f"Processing Delta Dataset.")
    df_target = spark.read.table(REPORT_RH_SILVER_STACK_TABLE)
    latest_extraction_date = df_target.select(
        f.date_add(f.max("_leap_extraction_date"), 1).alias("Max_Start_Validity")
    ).first()[0]
    print(latest_extraction_date)

    if latest_extraction_date is None:
        # In case of first run, take the INIT_FROM date even if RUN_MODE=="delta"
        latest_extraction_date = INIT_FROM
        RUN_JOB_ON_LATEST = False
        log.info(
            f"the latest_extraction_date in {REPORT_RH_SILVER_STACK_TABLE} is None, taking : {latest_extraction_date}"
        )
    else:
        log.info(
            f"the latest_extraction_date in {REPORT_RH_SILVER_STACK_TABLE} is : {latest_extraction_date}"
        )

    # Filter input  on delta loads
    df_report_rh_bronze_stack = df_report_rh_bronze_stack.filter(
        f.col("_meta_extraction_timestamp") > latest_extraction_date
    )

    if df_report_rh_bronze_stack.isEmpty():
        log.info(f"the table {REPORT_RH_SILVER_STACK_TABLE} is already up to date")
        EMPTY_DATAFRAME_FLAG = True
else:
    log.info(f"Processing {RUN_MODE} from {INIT_FROM} to {INIT_TO}.")

log.debug(f"STACK HISTORY WRITE MODE is:  {MODE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Cast types

# COMMAND ----------

# Cast float to double
for col in SILVER_ATTRS_DICT["float_cols"]:
    df_report_rh_bronze_stack = df_report_rh_bronze_stack.withColumn(
        col, f.col(col).cast("double")
    )

# Cast to string
for col in SILVER_ATTRS_DICT["string_cols"]:
    df_report_rh_bronze_stack = df_report_rh_bronze_stack.withColumn(
        col, f.col(col).cast("string")
    )

# Cast string to date
for col in SILVER_ATTRS_DICT["date_cols"]:
    df_report_rh_bronze_stack = df_report_rh_bronze_stack.withColumn(
        col, f.to_date(f.col(col), "yyyy-MM-dd")
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Columns to drop

# COMMAND ----------

# Drop unwanted columns
df_report_rh_bronze_stack_drop = df_report_rh_bronze_stack.drop(
    *SILVER_ATTRS_DICT["columns_to_drop"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Cleaning before hashing

# COMMAND ----------

df_report_rh_bronze_stack_clean = clean_before_hashing(
    df_report_rh_bronze_stack_drop, SILVER_ATTRS_DICT["columns_to_clean_before_hashing"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 5 - Convert date to year

# COMMAND ----------

# Convert date to year for anonymization purpose
for col in SILVER_ATTRS_DICT["date_to_year"]:
    df_report_rh_bronze_stack_clean = df_report_rh_bronze_stack_clean.withColumn(
        f"{col}_year", f.year(f.col(col))
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 6 - _leap_extraction_date and _leap_year_month_extraction_date

# COMMAND ----------

# Add _leap_extraction_date
df_report_rh_bronze_stack_clean_start = (
    df_report_rh_bronze_stack_clean.withColumn(
        "_leap_extraction_date", f.to_date(f.col("_meta_extraction_timestamp"))
    )
    .withColumn(
        "_leap_extraction_date_1",
        f.date_sub(f.col("_leap_extraction_date"), 1),  # 1 jour en arrière
    )
    .withColumn(
        "_leap_year_month_extraction_date",
        f.date_format(f.col("_leap_extraction_date"), "yyyy-MM"),
    )
    .withColumn(
        "_leap_year_month_extraction_date_1",
        f.date_format(
            f.add_months(f.col("_leap_extraction_date"), -1), "yyyy-MM"
        ),  # Add previous "_leap_year_month_extraction_date" period
    )
)

df_report_rh_bronze_stack_clean_start = (
    df_report_rh_bronze_stack_clean_start.withColumn(
        "_leap_year_month_company_seniority_date",
        f.date_format(f.col("Company_Seniority_Date"), "yyyy-MM"),
    )
    .withColumn(
        "_leap_year_month_last_hire_date",
        f.date_format(f.col("Last_hire_date"), "yyyy-MM"),
    )
    .withColumn(
        "_leap_year_month_end_date", f.date_format(f.col("End_Date"), "yyyy-MM")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 7 - correct INVALID Status
# MAGIC
# MAGIC Regarding the extraction_date

# COMMAND ----------

# Update the Status column based on some conditions
df_report_rh_bronze_stack_clean_status = (
    df_report_rh_bronze_stack_clean_start.withColumn(
        "Status",
        f.when(
            (f.col("Status") == "ACTIVE")
            & (f.col("End_Date") < f.col("_leap_extraction_date")),
            "INACTIVE",
        ).otherwise(f.col("Status")),
    )
)
df_report_rh_bronze_stack_clean_status = (
    df_report_rh_bronze_stack_clean_status.withColumn(
        "Status",
        f.when(
            (f.col("Status") == "ACTIVE")
            & (f.col("Last_hire_date") > f.col("_leap_extraction_date")),
            "INACTIVE",
        ).otherwise(f.col("Status")),
    )
)

# Filter the Status values
df_report_rh_bronze_stack_clean_status = df_report_rh_bronze_stack_clean_status.filter(
    f.col("Status").isin(["ACTIVE", "INACTIVE"])
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 8 - trim columns
# MAGIC
# MAGIC trim columns whose name like **'%_code'**
# MAGIC trim other specific columns

# COMMAND ----------

# Trim all columns containing _code
df_report_rh_bronze_stack_trim = df_report_rh_bronze_stack_clean_status
code_cols = [
    cname
    for cname, dtype in df_report_rh_bronze_stack_trim.dtypes
    if dtype == "string" and ("_code" in cname.lower())
]

df_report_rh_bronze_stack_trim = trim_columns(df_report_rh_bronze_stack_trim, code_cols)

# Trim all columns in SILVER_ATTRS_DICT["columns_to_trim"]
df_report_rh_bronze_stack_trim = trim_columns(
    df_report_rh_bronze_stack_trim, SILVER_ATTRS_DICT["columns_to_trim"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 9 - Replace null et blank by "Unknown"
# MAGIC

# COMMAND ----------

df_report_rh_bronze_stack_notnull = df_report_rh_bronze_stack_trim.fillna(
    "Unknown", subset=SILVER_ATTRS_DICT["columns_to_replace_nulls_by_unknown"]
)
df_report_rh_bronze_stack_notnull = df_report_rh_bronze_stack_notnull.replace(
    "", "Unknown", subset=SILVER_ATTRS_DICT["columns_to_replace_nulls_by_unknown"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 10 - Harmonize country names

# COMMAND ----------

# Dictionary of country names to normalize
country_translation_dict = {
    "Belgique": "Belgium",
    "Czech": "Czech Republic",
    "Cezch": "Czech Republic",
    "CZ": "Czech Republic",
    "Cz": "Czech Republic",
    "Česká republika": "Czech Republic",
    "Czech Rep.": "Czech Republic",
    "Allemagne": "Germany",
    "Espagne": "Spain",
    "Bresil": "Brazil",
    "Brésil": "Brazil",
    "Mexique": "Mexico",
    "Bulgarie": "Bulgaria",
    "BG": "Bulgaria",
    "Bg": "Bulgaria",
    "España": "Spain",
    "FR": "France",
    "Fr": "France",
    "Inde": "India",
    "Italie": "Italy",
    "Etat-Unis": "USA",
    "Maroc": "Morocco",
    "Marocco": "Morocco",
    "Tunisie": "Tunisia",
    "United Kingdom": "UK",
    "United States": "USA",
    "Sk": "Slovakia",
    # Add more countries here
}

# Replacement for all country pairs
df_report_rh_bronze_stack_country = df_report_rh_bronze_stack_notnull.replace(
    country_translation_dict, subset=SILVER_ATTRS_DICT["columns_with_country_name"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 11 - Harmonize workplace

# COMMAND ----------

df_report_rh_bronze_stack_workplace = df_report_rh_bronze_stack_country

# Dictionary of workplace to normalize
workplace_patterns_translation_dict = {
    "periole": "Toulouse-Périole",
    "périole": "Toulouse-Périole",
    "montredon": "Toulouse-Montredon",
    "gabardie": "Toulouse-Gabardie",
    "mach1": "Toulouse-Mach1",
    "nazaire": "Saint-Nazaire",
    "social": "Toulouse-Mach1",
    "merignac": "Dassault-Mérignac",
    "mérignac": "Dassault-Mérignac",
    "argenteuil": "Dassault-Argenteuil",
    "prague": "Praha",
    "casablanca": "Had-Soualem",
    "soualem": "Had-Soualem",
    "malaga": "Malaga",
    "jacareï": "Jacarei",
    "jacarei": "Jacarei",
    "belgaum": "Belagavi",
    "plovdiv": "Plovdiv",
    # Add more workplace here
}

workplace_columns = ["Workplace", "Establishment"]

for col in workplace_columns:
    # Start with the original column, then apply transformations
    new_col = f.col(col)

    # Apply each pattern from the `workplace_patterns` dictionary
    for pattern, replacement in workplace_patterns_translation_dict.items():
        new_col = f.when(f.lower(f.col(col)).contains(pattern), replacement).otherwise(
            new_col
        )

    # Update the normalized column in the DataFrame
    df_report_rh_bronze_stack_workplace = (
        df_report_rh_bronze_stack_workplace.withColumn(col, new_col)
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 12 - Keep latest by _leap_extraction_date

# COMMAND ----------

# For each primary_key in Dataframe keep the latest _meta_extraction_timestamp
df_report_rh_bronze_stack_unique = table_utils.get_latest_version_for_each_id_column(
    df_report_rh_bronze_stack_workplace,
    SILVER_ATTRS_DICT["primary_key"].split(","),
    "_meta_extraction_timestamp",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------


def move_dataframe_cols_first(df: SparkDataFrame, cols_to_move: list) -> SparkDataFrame:
    """
    Move specified columns to the beginning of the DataFrame.

    :param df: The Spark DataFrame to modify.
    :type df: SparkDataFrame
    :param cols_to_move: A list of column names to move to the beginning of the DataFrame.
    :type cols_to_move: list
    :return: A new Spark DataFrame with the specified columns moved to the front.
    :rtype: SparkDataFrame
    """
    first_cols = cols_to_move
    other_cols = [c for c in df.columns if c not in first_cols]
    df_new = df.select(*first_cols, *other_cols)
    return df_new


# COMMAND ----------

# MAGIC %md
# MAGIC ## PII - Functions

# COMMAND ----------


def complete_token_vault_from_column_to_hash(
    df_token_vault: SparkDataFrame, df_sd: SparkDataFrame, col_to_hash: str
) -> None:
    """
    Complete the token vault with the new hashed values for a given column
    A random key is created for the hashing, then use aes_encyption from it. The hashed value is stored in the token vault and the secret key dropped.

    :param df_token_vault: The token vault dataframe
    :type df_token_vault: SparkDataFrame
    :param df_sd: The table to anonymize
    :type df_sd: SparkDataFrame
    :param col_to_hash: The column to anonymize
    :type col_to_hash: str
    :return: None
    """

    # Merge the column with token vault in order to identify which values have not already been hashed
    df_temp = (
        df_sd.select(col_to_hash)
        .dropDuplicates()
        .join(
            df_token_vault,
            df_sd[col_to_hash] == df_token_vault["OriginalValue"],
            how="left_anti",
        )
        .withColumnRenamed(col_to_hash, "OriginalValue")
    )

    # If new values are found, complete the token vault with the new values
    if df_temp.count() > 0:
        # Create a random key for hasing data
        key_hash = str(random.random())[:16]

        # Create the hashed corresponding value
        df_temp = df_temp.withColumn(
            "HashedValue",
            f.base64(f.aes_encrypt(f.col("OriginalValue"), f.lit(key_hash))),
        )
        df_temp = df_temp.withColumn(
            "DecryptedName",
            f.aes_decrypt(f.unbase64(f.col("HashedValue")), f.lit(key_hash)).cast(
                "string"
            ),
        )

        # Make sure to destroy the key
        del key_hash

        # Safeguard that the hash not already exists
        hashed_validation_df = df_temp.select("HashedValue").join(
            df_token_vault.select("HashedValue"), on="HashedValue", how="inner"
        )
        if hashed_validation_df.count() == 0:
            log.debug("All new hashed values doesn't exist in the Token Vault")
        else:
            log.warning("Some new hashed values are already present in the Token Vault")
            complete_token_vault_from_column_to_hash(df_token_vault, df_sd, col_to_hash)

        ## Update the token vault with the new values
        df_temp.select("OriginalValue", "HashedValue").write.mode("append").saveAsTable(
            TOKEN_VAULT_TABLE
        )

    return None


def get_hash_for_column(
    df_token_vault: SparkDataFrame, df_sd: SparkDataFrame, col_to_hash: str
) -> SparkDataFrame:
    """
    Get the hash for a column from the token vault

    :param df_token_vault: The token vault dataframe
    :type df_token_vault: DataFrame
    :param df_sd: The table to anonymize
    :type df_sd: DataFrame
    :param col_to_hash: The column to anonymize
    :type col_to_hash: str
    :return: The input table with the corresponding column anonymized
    """

    ## Create the new hashed column
    df_with_hashed_column = df_sd.join(
        df_token_vault.withColumnRenamed("OriginalValue", col_to_hash),
        on=col_to_hash,
        how="left",
    )
    df_with_hashed_column = df_with_hashed_column.drop(col_to_hash)
    df_with_hashed_column = df_with_hashed_column.withColumnRenamed(
        "HashedValue", col_to_hash
    )

    return df_with_hashed_column


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Calculate age category
# MAGIC  **_leap_age_as_at** and **_leap_age_category_as_at**
# MAGIC
# MAGIC  - _leap_age_as_at : age at extraction_date
# MAGIC  - _leap_age_category_as_at : age category at extraction_date

# COMMAND ----------

df_report_rh_bronze_silver = df_report_rh_bronze_stack_unique

df_report_rh_bronze_silver_age = df_report_rh_bronze_silver.withColumn(
    "_leap_age_as_at",
    f.floor(f.datediff(f.col("_leap_extraction_date"), f.col("Birth_date")) / 365),
).drop("Birth_date")

# Define age groups based on the calculated age
df_report_rh_bronze_silver_age_cat = df_report_rh_bronze_silver_age.withColumn(
    "_leap_age_category_as_at",
    f.when(f.col("_leap_age_as_at") < 30, "30 years and under")
    .when(
        (f.col("_leap_age_as_at") >= 30) & (f.col("_leap_age_as_at") < 45),
        "30-45 years",
    )
    .when(
        (f.col("_leap_age_as_at") >= 45) & (f.col("_leap_age_as_at") < 55),
        "45-55 years",
    )
    .when((f.col("_leap_age_as_at") >= 55), "55 years and over")
    .otherwise("_Unknown"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Calculate company seniority
# MAGIC  **_leap_company_seniority_as_at** and **_leap_company_seniority_category_as_at**

# COMMAND ----------

df_report_rh_bronze_silver_company_seniority = (
    df_report_rh_bronze_silver_age_cat.withColumn(
        "_leap_company_seniority_as_at",
        f.floor(
            f.datediff(f.col("_leap_extraction_date"), f.col("Company_Seniority_Date"))
            / 365
        ),
    )
)

# Define seniority groups based on the calculated seniority
df_report_rh_bronze_silver_company_seniority_cat = (
    df_report_rh_bronze_silver_company_seniority.withColumn(
        "_leap_company_seniority_category_as_at",
        f.when(f.col("_leap_company_seniority_as_at") < 1, "1 year and under")
        .when(
            (f.col("_leap_company_seniority_as_at") >= 1)
            & (f.col("_leap_company_seniority_as_at") < 5),
            "1-5 years",
        )
        .when(
            (f.col("_leap_company_seniority_as_at") >= 5)
            & (f.col("_leap_company_seniority_as_at") < 10),
            "5-10 years",
        )
        .when((f.col("_leap_company_seniority_as_at") >= 10), "10 years and over")
        .otherwise("_Unknown"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Prepare for hashing PII Data

# COMMAND ----------

df_report_rh_bronze_silver_hashed = df_report_rh_bronze_silver_company_seniority_cat
for col_to_hash in SILVER_ATTRS_DICT["columns_to_hash"]:
    complete_token_vault_from_column_to_hash(
        df_token_vault, df_report_rh_bronze_silver_hashed, col_to_hash
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Hashing PII Data
# MAGIC

# COMMAND ----------

df_token_vault = spark.read.table(TOKEN_VAULT_TABLE)

for col_to_hash in SILVER_ATTRS_DICT["columns_to_hash"]:
    df_report_rh_bronze_silver_hashed = get_hash_for_column(
        df_token_vault, df_report_rh_bronze_silver_hashed, col_to_hash
    )

# Dataframe to indicate encrypted columns
df_mapping_table = spark.createDataFrame(
    [(col, True) for col in SILVER_ATTRS_DICT["columns_to_hash"]],
    ["ColumnName", "IsEncrypted"],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 5 - Optimize order of Columns

# COMMAND ----------

first_cols = list(TABLE_SILVER_FIRST_COLS.keys())
df_report_rh_bronze_silver_hashed_first = move_dataframe_cols_first(
    df_report_rh_bronze_silver_hashed, first_cols
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

## Quality Checks - Common Functions defined in leap_utils

#### validate_and_log_gx_results()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - Uniqueness
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Quality checks with great_expectations : uniqueness for SILVER_ATTRS_DICT["primary_key"]
# Raise an Exception if not pass the checks
df_to_check = df_report_rh_bronze_silver_hashed_first
if (SILVER_ATTRS_DICT["primary_key"]) and (SILVER_ATTRS_DICT["primary_key"] != ""):
    gx_validation.gx_check_compound_uniqueness(
        df=df_to_check,
        cols=SILVER_ATTRS_DICT["primary_key"],
        validation_level="RED",
        pipeline_write_env=PIPELINE_WRITE_ENV,
        table_name="hr_referential_silver",
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 2 - Not null expectation
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Quality checks with great_expectations : notnull for SILVER_ATTRS_DICT["notnull_cols"]
# Raise an Exception if not pass the checks
notnull_columns = SILVER_ATTRS_DICT["notnull_cols"].split(",")
for one_col in notnull_columns:
    gx_validation.gx_check_not_null(
        df=df_to_check,
        col=one_col.strip(),
        validation_level="RED",
        pipeline_write_env=PIPELINE_WRITE_ENV,
        table_name="hr_referential_silver",
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 3 - Surge of Status change
# MAGIC
# MAGIC N/A

# COMMAND ----------


# ---------- Quality Checks 3 - Surge of Status change (SILVER) ----------
df_to_check = df_report_rh_bronze_silver_hashed_first

# 1) Parameters
_threshold_pct = float(dbutils.widgets.get("status_change_alert_threshold_pct"))
_min_pop = int(dbutils.widgets.get("status_change_min_population"))
_alert_mode = dbutils.widgets.get("status_change_alert_mode")  # "ratio" | "count"

# 2) latest date in current batch
_latest_date_in_batch = df_to_check.agg(
    f.max("_leap_extraction_date").alias("d")
).first()["d"]

# 3) latest date in existing table
if table_utils.UnityCatalogCheckTableExists(REPORT_RH_SILVER_STACK_TABLE):
    df_silver_hist = spark.read.table(REPORT_RH_SILVER_STACK_TABLE)
    df_dates = (
        df_silver_hist.select("_leap_extraction_date")
        .where(f.col("_leap_extraction_date") < f.lit(_latest_date_in_batch))
        .distinct()
    )
    prev_date_row = df_dates.agg(f.max("_leap_extraction_date").alias("d")).first()
    _prev_date = prev_date_row["d"]

else:
    _prev_date = None

if _prev_date is not None:
    # 4) D vs D-1
    dfD = (
        df_to_check.where(
            f.col("_leap_extraction_date") == f.lit(_latest_date_in_batch)
        )
        .select(f.col("User_ID"), f.col("Status").alias("status_D"))
        .dropDuplicates(["User_ID"])
    )
    dfDm1 = (
        df_silver_hist.where(f.col("_leap_extraction_date") == f.lit(_prev_date))
        .select(f.col("User_ID"), f.col("Status").alias("status_Dm1"))
        .dropDuplicates(["User_ID"])
    )

    df_join = dfD.join(dfDm1, on="User_ID", how="inner")
    base_population = df_join.count()

    if base_population >= _min_pop:
        change_count = df_join.where(f.col("status_D") != f.col("status_Dm1")).count()
        change_ratio = (change_count / base_population) if base_population > 0 else 0.0

        # 5) Encapsulate metric in df for Great Expectations
        df_metric = spark.createDataFrame(
            [(float(change_ratio), int(change_count), int(base_population))],
            ["status_change_ratio", "status_change_count", "base_population"],
        )
        dfgx = gx.dataset.SparkDFDataset(df_metric, persist=False)

        if _alert_mode == "ratio":
            gx_results = [
                dfgx.expect_column_max_to_be_between(
                    column="status_change_ratio",
                    min_value=None,
                    max_value=_threshold_pct / 100.0,
                )
            ]
        else:  # "count"
            gx_results = [
                dfgx.expect_column_max_to_be_between(
                    column="status_change_count",
                    min_value=None,
                    max_value=int(round(_threshold_pct)),
                )
            ]

        gx_validation.validate_and_log_gx_results(
            quality_check_results=gx_results,
            validation_level="RED",
            info_message=(
                f"QC SILVER: Status change surge OK. "
                f"change_ratio={change_ratio:.4f}, change_count={change_count}, base={base_population}, "
                f"latest={_latest_date_in_batch}, prev={_prev_date}"
            ),
            error_message=(
                f"QC SILVER: Status change surge KO (above alert level). "
                f"change_ratio={change_ratio:.4f}, change_count={change_count}, base={base_population}, "
                f"latest={_latest_date_in_batch}, prev={_prev_date}"
            ),
            pipeline_write_env=PIPELINE_WRITE_ENV,
            table_name="hr_referential_silver",
            log_to_event_table=True,
            log_successes=True,
        )
    else:
        log.info(
            f"QC SILVER: base_population={base_population} < min_pop={_min_pop}, quality check ignored."
            f"(latest={_latest_date_in_batch}, prev={_prev_date})"
        )
else:
    log.info(
        "QC SILVER: No previous date D-1 available in history, quality check ignored."
    )


# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by TABLE_DEST_STACK_CLUSTER_COLS
if not EMPTY_DATAFRAME_FLAG:
    catalog, schema, table = REPORT_RH_SILVER_STACK_TABLE.split(".")

    try:
        table_utils.create_unity_catalog_table(
            catalog,
            schema,
            table,
            force_reinitialization=FORCE_REINITIALIZATION,
            cluster_cols=SILVER_ATTRS_DICT["cluster_cols"],
            partition_col=None,
            primary_key_cols=None,
            columns=TABLE_SILVER_FIRST_COLS,
            force_drop=False,
        )
    except AnalysisException as e:
        log.error(
            f"Table {REPORT_RH_SILVER_STACK_TABLE} has not been created, an error occured during creation. \nError is {e}"
        )
        raise OSError(
            f"An error occurred while creating the table {REPORT_RH_SILVER_STACK_TABLE}"
        ) from e

# COMMAND ----------

# Save the silver table from Dataframe df_report_rh_bronze_silver_hashed_first, preserving cluster columns
if not EMPTY_DATAFRAME_FLAG:
    try:
        startTime = time.time()
        table_utils.save_table(
            dest_table=REPORT_RH_SILVER_STACK_TABLE,
            df=df_report_rh_bronze_silver_hashed_first,
            mode=MODE,
            overwrite_schema=True,
            cluster_cols=SILVER_ATTRS_DICT["cluster_cols"],
            merge_schema=True,
        )
    except AnalysisException as e:
        log.error(
            f"Table {REPORT_RH_SILVER_STACK_TABLE} has not been created, an error occured during table_utils.save_table . \nError is {e}"
        )
        raise OSError(
            f"An error occurred while saving the table {REPORT_RH_SILVER_STACK_TABLE}"
        ) from e
    else:
        duration = time.time() - startTime
        log.info(f"Table {REPORT_RH_SILVER_STACK_TABLE} saved in {duration} seconds.")
        log.info(f"Wrote {df_report_rh_bronze_silver_hashed_first.count()} rows.")

# COMMAND ----------

# Save the pii mapping table from Dataframe df_mapping_table
try:
    startTime = time.time()
    table_utils.save_table(
        dest_table=TOKEN_VAULT_MAPPING_TABLE,
        df=df_mapping_table,
        mode="overwrite",
        overwrite_schema=True,
        merge_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {TOKEN_VAULT_MAPPING_TABLE} has not been created, an error occured during table_utils.save_table . \nError is {e}"
    )
    raise OSError(
        f"An error occurred while saving the table {TOKEN_VAULT_MAPPING_TABLE}"
    ) from e
else:
    duration = time.time() - startTime
    log.info(f"Table {TOKEN_VAULT_MAPPING_TABLE} saved in {duration} seconds.")
    log.info(f"Wrote {df_mapping_table.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
