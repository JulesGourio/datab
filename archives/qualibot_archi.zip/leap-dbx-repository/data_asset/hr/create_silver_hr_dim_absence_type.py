# Databricks notebook source
# DBTITLE 1,Silver HR Dim Absence Type
# MAGIC %md
# MAGIC ## Silver HR Dim Absence Type
# MAGIC
# MAGIC Autonomous notebook: reads the abs_mapping dropdown reference table from bronze_cleaned,
# MAGIC maps to the unified silver schema (YAML-driven), and writes to
# MAGIC `{pipeline_write_env}_silver_hr.absenteism.dim_absence_type` (full overwrite).
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | Abs Mapping | `{pipeline_read_env}_bronze_cleaned_hr` | `abs_mapping` | `abs_mapping_dropdown_latest` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_silver_hr.absenteism.dim_absence_type`
# MAGIC
# MAGIC **Schema contract**: `data_asset/hr/config/silver_dim_absence_type_column_mapping.yaml`
# MAGIC
# MAGIC **Transformations**:
# MAGIC - Rename: `field_description` → `absence_type_desc`
# MAGIC - Generate PK: `absence_type_id` (country-source-field_name-absence_type_code)
# MAGIC - Drop `_meta_*` columns
# MAGIC - Clean non-PII strings (trim + nullify)
# MAGIC
# MAGIC **Write mode**: overwrite (full table rebuild — reference/dimension data).
# MAGIC
# MAGIC **Note**: The Excel source is evolving — columns may be added in future ingestion updates.

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql import functions as f

from data_asset.hr.utils.table_schema_map_utils import load_config
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# DBTITLE 1,Config: widgets & logging
# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config: source and target
# --- Source ---
SOURCE_CATALOG = f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
SOURCE_SCHEMA = "abs_mapping"
SOURCE_TABLE = "abs_mapping_dropdown_latest"

# --- Target ---
config = load_config(config_path="config/silver_dim_absence_type_column_mapping.yaml")
_target = config["target"]
SILVER_CATALOG = f"{PIPELINE_WRITE_ENV}_silver_hr"
SILVER_SCHEMA = _target["schema"]
SILVER_TABLE = _target["table"]

# --- Full table paths ---
SOURCE_FULL_TABLE = f"{SOURCE_CATALOG}.{SOURCE_SCHEMA}.{SOURCE_TABLE}"
SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# COMMAND ----------

# DBTITLE 1,Input data
df_source = spark.table(SOURCE_FULL_TABLE)

# Filter only reviewed/confirmed rows, then select and rename business columns
df_silver = (
    df_source
    .filter(f.col("to_be_review_or_confirm") != "Not an absence reason")
    .select(
        f.col("country"),
        f.col("system").alias("source"),
        f.col("field_name"),
        f.col("absence_type_code"),
        f.col("field_description").alias("absence_type_desc"),
        f.col("absence_category"),
        f.col("included_in_absenteesim_official_kpi").alias("included_in_absenteeism_kpi"),
    )
)

# COMMAND ----------

# DBTITLE 1,Tr. 1 - Generate absence_type_id
# Generate a composite PK as concatenation of key columns
df_silver_w_pk = df_silver.withColumn(
    "absence_type_id",
    f.concat_ws(
        "-",
        f.col("country"),
        f.col("source"),
        f.col("field_name"),
        f.col("absence_type_code"),
    ),
)

# COMMAND ----------

# DBTITLE 1,Tr. 2 - Ensure correct Bulgaria letters
CYRILIC_CHAR_MAP = {
    "O": "О",
    "M": "М",
    "A": "А",
    "H": "Н",
    "C": "С",
}

df_silver_cyril = df_silver_w_pk.replace(CYRILIC_CHAR_MAP, subset=["absence_type_code"])

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
# none

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_silver_cyril,
    config=config,
    full_table_path=SILVER_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=None,
    apply_clean_non_pii=True,
    drop_null_pk_rows=False,
    overwrite_schema=True,
    is_debug=LOG_LEVEL == "debug",
)
