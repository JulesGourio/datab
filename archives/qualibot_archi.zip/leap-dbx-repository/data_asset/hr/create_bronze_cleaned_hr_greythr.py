# Databricks notebook source
# DBTITLE 1,Header – Notebook Documentation
# MAGIC %md
# MAGIC # [HR] - greytHR Bronze to Bronze Clean
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC **Description:**  
# MAGIC Loads all tables from the greytHR bronze schema, applies PII-aware cleaning and type-casting operations, then writes the cleaned DataFrames to the bronze_cleaned catalog. PII tag propagation and comments propagation are handled directly in this notebook.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - **PII Tag-based processing**: Tables and columns are processed iteratively per PII sensitivity level (STANDARD, CONFIDENTIAL, RGPD) using `PIICleaningManager`
# MAGIC - **PII tag propagation**: Handled directly in this notebook after the write step, using a column name map from source to target schemas
# MAGIC - **Comments propagation**: Table and column comments are propagated automatically from source to target during the write step
# MAGIC
# MAGIC **Intended Pipeline:**  
# MAGIC - HR greytHR Bronze Cleaning pipeline (task in D_0_greythr_hr_ingestion)
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - `{PIPELINE_WRITE_ENV}_bronze_cleaned_hr.greythr.*`
# MAGIC
# MAGIC **Inputs:**  
# MAGIC - `{PIPELINE_READ_ENV}_bronze_hr.greythr.*`
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC - D_0_greythr_hr_ingestion (after tag/comment/flatten tasks)
# MAGIC
# MAGIC **Automatically handled:**  
# MAGIC - PII tag propagation (source → target column name map)  
# MAGIC - Table and column comments propagation
# MAGIC
# MAGIC **Things performed in this notebook:**  
# MAGIC 1. Load all greytHR tables and organize columns by PII tag  
# MAGIC 2. Apply three-layer cleaning pipeline per PII level (Layer 1: universal string baseline; Layer 2: type correction; Layer 3: business rules)  
# MAGIC 3. Write cleaned tables to bronze_cleaned catalog  
# MAGIC 4. Propagate PII tags from source to target  
# MAGIC 5. Propagate table and column comments automatically

# COMMAND ----------

# DBTITLE 1,Imports header
# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import sys
from pyspark.sql import functions as f
from pyspark.sql import DataFrame

dbutils.widgets.removeAll()

# Add bundle_root to sys.path for leap_utils imports (when running from an Asset Bundle)
dbutils.widgets.text("bundle_root", "")
bundle_root = dbutils.widgets.get("bundle_root")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

from leap_utils.common import logger


from utils.bronze_cleaning_pipeline import run_bronze_cleaning_pipeline


# COMMAND ----------

# DBTITLE 1,Widgets header
# MAGIC %md
# MAGIC ## Standard Configuration & Widgets

# COMMAND ----------

# DBTITLE 1,Pipeline environment widgets
# Aligned with greythr_hr_ingestion bundle widget convention (UPPERCASE)
dbutils.widgets.text("PIPELINE_WRITE_ENV", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("PIPELINE_WRITE_ENV")

dbutils.widgets.text("PIPELINE_READ_ENV", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("PIPELINE_READ_ENV")

dbutils.widgets.text("REFERENCE_READ_ENV", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("REFERENCE_READ_ENV")

dbutils.widgets.text("target_schema", "greythr")
TARGET_SCHEMA = dbutils.widgets.get("target_schema")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# DBTITLE 1,Debug and log-level widgets
dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Logger setup
log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Notebook Configuration & Constants header
# MAGIC %md
# MAGIC ## Notebook Configuration & Constants

# COMMAND ----------

# DBTITLE 1,Source and Target
CATALOG_SOURCE = f"{PIPELINE_READ_ENV}_bronze_hr"
CATALOG_TARGET = f"{PIPELINE_WRITE_ENV}_bronze_cleaned_hr"
SCHEMA = TARGET_SCHEMA  # greythr

# Allowlist — all user-facing tables. greythr_ingestion_freshness_all excluded (admin/monitoring).
TABLES_TO_CLEAN: set[str] = {
    "employees_latest",
    "salary_statement_latest",
    "salary_repository_latest",
    "attendance_muster_latest",
    "attendance_muster_flatten_latest",
    "attendance_summary_latest",
    "leave_balance_latest",
    "leave_transactions_by_employee_latest",
}

# Explicit primary key per cleaned table. Column names must match the
# CLEANED (post-rename) names. Empty / absent → no PK tag applied.
PRIMARY_KEYS: dict[str, list[str]] = {
    "employees_latest": ["employeeid"],
    "salary_statement_latest": ["employeeid", "itemname", "_sync_month"],
    "salary_repository_latest": ["id"],
    "attendance_muster_latest": ["employeeid", "_sync_month"],
    "attendance_muster_flatten_latest": ["employeeid", "attendance_date"],
    "attendance_summary_latest": ["employee", "_sync_month"],
    "leave_balance_latest": ["employeeid", "leavetypecategory", "_balance_year"],
    "leave_transactions_by_employee_latest": ["id"],
}

# COMMAND ----------

# DBTITLE 1,Specific configuration
# Boolean cast — {table_name: [col, ...]}
COLUMNS_BOOL: dict[str, list[str]] = {}

# Date cast — {table_name: {col_name: date_format | None}}
COLUMNS_DATE: dict[str, dict[str, str | None]] = {}

# String cast — {table_name: [col, ...]}. Force these columns to string in bronze_cleaned.
# employeeid lands as bigint from bronze (not PII-tagged, so Layer 2 won't touch it).
# Cast it here so downstream joins across sources are type-consistent.
# Note: since employeeid is NOT PII-tagged, the cast must be applied in Layer 3
# (apply_specific_cleaning) — not via the PII pipeline which only sees tagged columns.
COLUMNS_STRING: dict[str, list[str]] = {
    "employees_latest": ["employeeid"],
    "salary_statement_latest": ["employeeid"],
    "attendance_muster_flatten_latest": ["employeeid"],
    "attendance_muster_latest": ["employeeid"],
    "attendance_summary_latest": ["employee"],
    "leave_balance_latest": ["employeeid"],
    "leave_transactions_by_employee_latest": ["employeeid"],
}

# Column renames — overrides the default rstrip("_") rule for specific columns.
COLUMNS_RENAME: dict[str, dict[str, str]] = {}

# COMMAND ----------

# DBTITLE 1,Specific Overrides – header
# MAGIC %md
# MAGIC ## Specific Overrides (Layer 3)
# MAGIC
# MAGIC The three-layer cleaning pipeline is centralised in `utils/bronze_cleaning_pipeline.py`. Layers 1 (trim + nullify) and 2 (type correction) are driven by the configuration dicts above.
# MAGIC
# MAGIC **The cell below is the only schema-specific code** — edit `apply_specific_cleaning` to add or change Layer 3 business rules. The function receives:
# MAGIC - `df` — the DataFrame, already trimmed (Layer 1) and typed (Layer 2)
# MAGIC - `table_name` — the table currently being processed
# MAGIC - `pii_cols` — the PII column names in scope
# MAGIC
# MAGIC Use an `if table_name == "..."` guard to target a specific table.

# COMMAND ----------

# DBTITLE 1,apply_specific_cleaning
def apply_specific_cleaning(
    df: DataFrame,
    table_name: str,
    pii_cols: list[str],
) -> DataFrame:
    """Apply table-specific cleaning rules (Layer 3)."""
    if table_name == "employees_latest":
        # Validate email structure — nullify malformed values (missing "@")
        for col_name in ("email", "personalemail"):
            if col_name in pii_cols and col_name in df.columns:
                df = df.withColumn(
                    col_name,
                    f.when(f.col(col_name).contains("@"), f.col(col_name)).otherwise(f.lit(None)),
                )

    # Cast non-PII employeeid (LONG → STRING) for downstream join consistency.
    # Done here because employeeid is NOT PII-tagged, so Layer 2 won't process it.
    string_cols = COLUMNS_STRING.get(table_name, [])
    for col_name in string_cols:
        if col_name not in pii_cols and col_name in df.columns:
            df = df.withColumn(col_name, f.col(col_name).cast("string"))

    return df

# COMMAND ----------

# DBTITLE 1,Pipeline Execution – header
# MAGIC %md
# MAGIC # Pipeline Execution

# COMMAND ----------

# DBTITLE 1,Run bronze cleaning pipeline
run_bronze_cleaning_pipeline(
    spark=spark,
    log=log,
    catalog_source=CATALOG_SOURCE,
    catalog_target=CATALOG_TARGET,
    schema=SCHEMA,
    tables_to_clean=TABLES_TO_CLEAN,
    primary_keys=PRIMARY_KEYS,
    columns_to_cast_to_bool=COLUMNS_BOOL,
    columns_to_cast_to_date=COLUMNS_DATE,
    columns_to_cast_to_string=COLUMNS_STRING,
    columns_to_rename=COLUMNS_RENAME,
    apply_specific_cleaning_fn=apply_specific_cleaning,
)
