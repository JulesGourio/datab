# Databricks notebook source
# DBTITLE 1,Header – Notebook Documentation
# MAGIC %md
# MAGIC
# MAGIC # [HR] - Horoquartz Group Bronze to Bronze Clean
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC **Description:**
# MAGIC Loads the Horoquartz Group bronze tables, applies PII-aware cleaning and type-casting operations, then writes the cleaned DataFrames to the bronze_cleaned catalog. PII tag propagation and comments propagation are handled directly in this notebook.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - **PII Tag-based processing**: Tables and columns are processed iteratively per PII sensitivity level (STANDARD, CONFIDENTIAL, RGPD) using `PIICleaningManager`
# MAGIC - **Matricule leading-zero strip**: a dedicated pass strips leading zeros on the matricule-bearing columns (`matri`, `utilmod`, `utilcre`, `utilstatut`) across ALL tables — independent of PII tagging, since some of these columns are not PII-tagged
# MAGIC - **PII tag propagation**: Handled directly in this notebook after the write step, using a column name map from source to target schemas
# MAGIC - **Comments propagation**: Table and column comments are propagated automatically from source to target during the write step
# MAGIC
# MAGIC **Intended Pipeline:**
# MAGIC - HR Horoquartz Group Bronze Cleaning pipeline
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - `{PIPELINE_WRITE_ENV}_bronze_cleaned_hr.horoquartz_group.*`
# MAGIC
# MAGIC **Inputs:**
# MAGIC - `{PIPELINE_READ_ENV}_bronze_hr.horoquartz_group.*`
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - Horoquartz Group Bronze Ingestion pipeline
# MAGIC
# MAGIC **Automatically handled:**
# MAGIC - PII tag propagation (source → target column name map)
# MAGIC - Table and column comments propagation
# MAGIC
# MAGIC **Things performed in this notebook:**
# MAGIC 1. Load the Horoquartz tables and organize columns by PII tag
# MAGIC 2. Apply three-layer cleaning pipeline per PII level (Layer 1: universal string baseline; Layer 2: type correction; Layer 3: business rules)
# MAGIC 3. Strip leading zeros on matricule-bearing columns (all tables)
# MAGIC 4. Rename PII columns (strip trailing `_`; custom overrides via `COLUMNS_RENAME`)
# MAGIC 5. Write cleaned tables to bronze_cleaned catalog
# MAGIC 6. Propagate PII tags from source to target
# MAGIC 7. Propagate table and column comments automatically

# COMMAND ----------

# DBTITLE 1,Imports header
# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame


# Logging
from leap_utils.common import logger

from leap_utils.data_asset.pii_cleaning_utils import PIICleaningManager

from utils.bronze_cleaning_pipeline import run_bronze_cleaning_pipeline


# COMMAND ----------

# DBTITLE 1,Widgets header
# MAGIC %md
# MAGIC ## Standard Configuration & Widgets

# COMMAND ----------

# DBTITLE 1,Pipeline environment widgets
# Environment where this notebook writes its output silver table
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Environment from which other pipeline silver/gold tables are read
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Environment from which reference/bronze tables are read (usually prod)
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# When true, quality check failures are logged as warnings instead of errors
dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# DBTITLE 1,Debug and log-level widgets
dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Logger setup
log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Notebook Configuration & Constants header
# MAGIC %md
# MAGIC ## Notebook Configuration & Constants

# COMMAND ----------

# DBTITLE 1,Source and Target
# @DevTeam -> This cell is dedicated to source and target configuration, only the schema should be modified by the user
CATALOG_SOURCE = f"{PIPELINE_READ_ENV}_bronze_hr"
CATALOG_TARGET = f"{PIPELINE_WRITE_ENV}_bronze_cleaned_hr"
SCHEMA = "horoquartz_group"

# Allowlist of bronze tables to clean into bronze_cleaned (the schema also holds
# {pipeline_name}_freshness_all and internal DLT tables, which must NOT be promoted). The generic
# ingestion pipeline materialises each pilotage table as `{table_name}_latest`.
TABLES_TO_CLEAN: set[str] = {
    "v_hrdatalake_hophabs_latest",   # daily absences
    "v_hrdatalake_hophjoun_latest",  # daily schedule
    "v_hrdatalake_hophorc_latest",   # schedule codes (ref)
    "v_hrdatalake_hophord_latest",   # schedule slots (ref)
    "v_hrdatalake_hopmoti_latest",   # absence reasons (ref)
    "v_hrdatalake_hopproe_latest",   # employment profiles (ref)
}

# Explicit primary key per cleaned table. The grain is a design property of the TARGET table, so
# it is declared here and applied deliberately after the write — NOT propagated from bronze via
# lineage (a cleaned table may re-grain / rename / drop key columns). Column names must match the
# CLEANED (post-rename) names. Empty / absent → no PK tag applied.
PRIMARY_KEYS: dict[str, list[str]] = {
    "v_hrdatalake_hophabs_latest": ["matri", "dat", "motif", "ordre"],
    "v_hrdatalake_hophjoun_latest": ["matri", "dat", "rang"],
    "v_hrdatalake_hophorc_latest": ["horcode"],
    "v_hrdatalake_hophord_latest": ["horcode", "ordre", "attrib"],
    "v_hrdatalake_hopmoti_latest": ["motif"],
    "v_hrdatalake_hopproe_latest": ["profil"],
}

# Matricule-bearing columns: strip leading zeros so employee identifiers are canonical across
# extractions. Applied to ALL tables (see the dedicated pass below), independent of PII tagging —
# some of these columns (e.g. utilcre/utilmod on the reference tables, utilstatut) are not tagged.
MATRICULE_COLS: set[str] = {"matri", "utilmod", "utilcre", "utilstatut"}

# COMMAND ----------

# DBTITLE 1,Specific configuration
# @DevTeam -> Schema-specific configuration — edit this cell when adapting the notebook to a new schema.
# For table-specific business rules, see the Specific Overrides cell.

# Boolean cast — {table_name: [col, ...]}
COLUMNS_BOOL: dict[str, list[str]] = {}

# Date cast — {table_name: {col_name: date_format | None}}
# date_format: explicit pattern (e.g. "dd/MM/yyyy") or None → DEFAULT_DATE_FORMATS
# Example:
# COLUMNS_DATE = {
#     "table_name": {
#         "date_col":  "dd/MM/yyyy",
#         "date_col2": None,
#     }
# }
COLUMNS_DATE: dict[str, dict[str, str | None]] = {}

# Column renames — overrides the default rstrip("_") rule for specific columns.
# Keys: source column names (as tagged in bronze). Values: desired final names.
# The standard strip is applied first; these overrides are applied on top.
# Example:
# COLUMNS_RENAME = {
#     "table_name": {
#         "source_col": "target_col",
#     },
# }
COLUMNS_RENAME: dict[str, dict[str, str]] = {}

# COMMAND ----------

# DBTITLE 1,Specific Overrides – header
# MAGIC %md
# MAGIC ## Specific Overrides (Layer 3)
# MAGIC
# MAGIC The three-layer cleaning pipeline is centralised in `utils/bronze_cleaning_pipeline.py`. Layers 1 (trim + nullify) and 2 (type correction) are driven by the configuration dicts above.
# MAGIC
# MAGIC **The cell below is the only schema-specific code** — edit `apply_specific_cleaning` to add or change Layer 3 business rules. The function receives:
# MAGIC - `df` — the DataFrame, already trimmed (Layer 1) and typed (Layer 2)
# MAGIC - `table_name` — the table currently being processed
# MAGIC - `pii_cols` — the PII column names in scope
# MAGIC
# MAGIC Use an `if table_name == "..."` guard to target a specific table.

# COMMAND ----------

# DBTITLE 1,apply_specific_cleaning
# no specific overrides for this schema

# COMMAND ----------

# DBTITLE 1,Matricule leading-zero strip – header
# MAGIC %md
# MAGIC ## Post-clean: Matricule leading-zero strip
# MAGIC
# MAGIC Employee identifiers are stored with leading zeros that vary across extractions. The function
# MAGIC below strips them so the matricule is canonical. It runs **after** PII cleaning but **before**
# MAGIC the save step, on **all** cleaned tables — independent of PII tagging (some matricule columns
# MAGIC like `utilcre`/`utilmod`/`utilstatut` carry no PII tag).

# COMMAND ----------

# DBTITLE 1,strip_matricule_leading_zeros
def _strip_leading_zeros(col_name: str):
    """Remove leading zeros while keeping at least one character ("007890" -> "7890", "0" -> "0")."""
    return f.regexp_replace(f.col(col_name), r"^0+(?=.)", "")


def post_clean(
    dfs_clean_all: dict[str, DataFrame],
    cleaner: PIICleaningManager,
) -> dict[str, DataFrame]:
    """Strip leading zeros on matricule-bearing columns across all tables."""
    for table_name, df in dfs_clean_all.items():
        matri_cols = [c for c in MATRICULE_COLS if c in df.columns]
        if matri_cols:
            dfs_clean_all[table_name] = df.withColumns(
                {c: _strip_leading_zeros(c) for c in matri_cols}
            )
    return dfs_clean_all

# COMMAND ----------

# DBTITLE 1,Pipeline Execution – header
# MAGIC %md
# MAGIC # Pipeline Execution

# COMMAND ----------

# DBTITLE 1,Run bronze cleaning pipeline
run_bronze_cleaning_pipeline(
    spark=spark,
    log=log,
    catalog_source=CATALOG_SOURCE,
    catalog_target=CATALOG_TARGET,
    schema=SCHEMA,
    tables_to_clean=TABLES_TO_CLEAN,
    primary_keys=PRIMARY_KEYS,
    columns_to_cast_to_bool=COLUMNS_BOOL,
    columns_to_cast_to_date=COLUMNS_DATE,
    columns_to_rename=COLUMNS_RENAME,
    post_clean_fn=post_clean,
)
