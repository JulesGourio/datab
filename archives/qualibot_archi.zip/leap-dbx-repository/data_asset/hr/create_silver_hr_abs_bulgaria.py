# Databricks notebook source
# DBTITLE 1,Silver HR Absences — Bulgaria
# MAGIC %md
# MAGIC ## Silver HR Absences — Bulgaria
# MAGIC
# MAGIC Autonomous notebook: reads Bulgaria absences from bronze cleaned, maps to unified silver schema,
# MAGIC and writes to `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` with `REPLACE WHERE source = 'BULGARIA'`.
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | Bulgaria absences | `{pipeline_read_env}_bronze_cleaned_hr` | `bulgaria_abs` | `bulgaria_abs_unpivot_latest` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` (column `source = 'BULGARIA'`)
# MAGIC
# MAGIC **Filter**: Whitelist approach — only rows whose `day_value` matches a known Cyrillic absence code pass through. All other values (hours worked `8`, `8/1`, `8/2`, short shifts `6`, `4`, day-off marker `П`, `8/H`, etc.) are excluded.
# MAGIC
# MAGIC **Note**: Bulgaria provides one row per employee per calendar day (already unpivoted). `id` is the employee identifier (it matches `immat.user_id`). No half-day notation observed. `absence_duration_min` defaults to 480 min (8h). `absence_day_value` is always 1.0.
# MAGIC
# MAGIC **Code mapping** (Cyrillic → description): Б → Sick Leave, О → Annual Leave, М → Maternity Leave, А → Sick Leave Covid-19, Н → Unpaid Leave, У → Study Leave, Д → Other Leave, Л → Bridge Day, С → Unauthorized Absence. Codes А, Л, С not yet present in data but included for future-proofing.

# COMMAND ----------

# DBTITLE 1,Config
from itertools import chain
from pyspark.sql import functions as f, Window

from data_asset.hr.utils.table_schema_map_utils import load_config
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# --- Source ---
BRONZE_CLEANED_CATALOG = f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
BULGARIA_SCHEMA = "bulgaria_abs"
BULGARIA_ABSENCES_TABLE = "bulgaria_abs_unpivot_latest"  # one row per employee per calendar day — already unpivoted

# Whitelist: only these Cyrillic codes are absence types — everything else (hours, shifts, П) is excluded
BULGARIA_ABSENCE_LABELS = {
    "Б": "Sick Leave",  # Б = Болест
    "О": "Annual Leave",  # О = Редовен отпуск
    "М": "Maternity Leave",  # М = Майчинство
    "А": "Sick Leave Covid-19",  # А = Отпуск по болест Covid-19
    "Н": "Unpaid Leave",  # Н = Неплатен отпуск
    "У": "Study Leave",  # У = Учебен отпуск
    "Д": "Other Leave",  # Д = Други видове отпуск
    "Л": "Bridge Day",  # Л = Bridge day
    "С": "Unauthorized Absence",  # С = Самоотлъчка (AWOL)
}
CYRILIC_CHAR_MAP = {
    "O": "О",
    "M": "М",
    "A": "А",
    "H": "Н",
    "C": "С",
}

config = load_config(config_path="config/silver_abs_column_mapping.yaml")
_target = config["target"]
SILVER_CATALOG = f"{PIPELINE_WRITE_ENV}_silver_hr"
SILVER_SCHEMA = _target["schema"]
SILVER_TABLE = _target["table"]
SOURCE = "BULGARIA"

SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# Derive MIN_ABSENCE_DATE from immat coverage start (absences before immat cannot be enriched)
_immat_table = f"{PIPELINE_READ_ENV}_gold_hr.immat.immat_monthly_history"
_min_immat_month = spark.table(_immat_table).select(f.min("year_month")).collect()[0][0]
MIN_ABSENCE_DATE = f"{_min_immat_month}-01"
log.info(f"[{SOURCE}] MIN_ABSENCE_DATE = {MIN_ABSENCE_DATE} (immat coverage floor)")

# COMMAND ----------

# DBTITLE 1,Non-PII Cleaning
# MAGIC %md
# MAGIC ### Non-PII Cleaning
# MAGIC Applied by `clean_non_pii` after column mapping:
# MAGIC 1. Trim all string columns and nullify empty strings
# MAGIC 2. Drop rows where any mandatory column (YAML contract) is null

# COMMAND ----------

# DBTITLE 1,read_bulgaria_absences
def read_bulgaria_absences():
    """
    Read and map Bulgaria absence records to the silver schema.

    Whitelist filter: only rows whose day_value is in BULGARIA_ABSENCE_LABELS pass through.
    All other values (hours '8', shifts '8/1'/'8/2', day-off 'П', '8/H', short shifts) are excluded.
    _meta_validity_check = True applied as defensive guard.

    id column is used as id_group (to confirm vs immat.user_id).
    No half-day notation in Bulgaria -- absence_day_value is always 1.0.
    absence_duration_min defaults to 480 min (8h) -- no time granularity available.
    absence_type_desc resolved via BULGARIA_ABSENCE_LABELS static mapping.
    dropDuplicates() is a defensive guard against potential upstream re-ingestion.
    """
    _label_map = f.create_map(
        [f.lit(x) for x in chain(*BULGARIA_ABSENCE_LABELS.items())]
    )
    _valid_codes = list(BULGARIA_ABSENCE_LABELS.keys())

    df = (
        spark.table(
            f"{BRONZE_CLEANED_CATALOG}.{BULGARIA_SCHEMA}.{BULGARIA_ABSENCES_TABLE}"
        )
        .replace(CYRILIC_CHAR_MAP, subset=["day_value"])  # ensure cyrilic chars
        .filter(
            (f.col("_meta_validity_check"))  # defensive guard
            & (
                f.col("day_value").isin(_valid_codes)
            )  # whitelist: only known Cyrillic absence codes
            & (f.col("date") >= MIN_ABSENCE_DATE)
        )
    )
    w = Window.partitionBy("id", "date").orderBy("day_value")
    return df.dropDuplicates().select(  # defensive guard against upstream re-ingestion
        f.col("id").alias("id_group"),  # employee ID -- to confirm vs immat.user_id
        f.col("date").alias("absence_date"),
        f.col("day_value").alias("absence_type_code"),
        _label_map[f.col("day_value")].alias("absence_type_desc"),
        f.lit(480).cast("long").alias("absence_duration_min"),
        f.lit(1.0).alias("absence_day_value"),
        f.row_number().over(w).alias("day_order"),
        f.lit(SOURCE).alias("source"),
    )

# COMMAND ----------

# DBTITLE 1,Input data
df_raw = read_bulgaria_absences()

if LOG_LEVEL == "debug":
    count_raw = df_raw.count()
    log.debug(f"[{SOURCE}] {count_raw:,} rows after read + mapping")

# log unknown codes (null desc from static mapping) — currently none expected
unknown = (
    df_raw.filter(f.col("absence_type_desc").isNull())
    .select("absence_type_code")
    .distinct()
    .collect()
)
if unknown:
    log.warning(f"[{SOURCE}] Unknown codes (null desc): {[r[0] for r in unknown]}")

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
def _build_extra_red_results(
    df_gx: SparkDFDataset,
) -> list[ExpectationSuiteValidationResult]:
    return [
        # absence_duration_min >= 0 and <= 1440 (no single-day absence > 24h)
        df_gx.expect_column_values_to_be_between(
            column="absence_duration_min",
            min_value=0,
            max_value=1440,
        ),
        # absence_day_value in [0, 1]
        df_gx.expect_column_values_to_be_between(
            column="absence_day_value",
            min_value=0,
            max_value=1,
            mostly=1.0,
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_raw,
    config=config,
    full_table_path=SILVER_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=True,
    drop_null_pk_rows=True,
    cluster_cols="source, id_group",
    replace_where=f"source = '{SOURCE}'",
    is_debug=LOG_LEVEL == "debug",
)
