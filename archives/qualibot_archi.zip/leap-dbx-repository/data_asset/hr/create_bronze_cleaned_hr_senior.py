# Databricks notebook source
# DBTITLE 1,Header – Notebook Documentation
# MAGIC %md
# MAGIC
# MAGIC # [HR] - SENIOR Bronze to Bronze Clean
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC **Description:**
# MAGIC Loads the SENIOR Sistemas (Brazil HCM/payroll) bronze tables, applies PII-aware cleaning and
# MAGIC type-casting operations, then writes the cleaned DataFrames to the bronze_cleaned catalog. PII
# MAGIC tag propagation and comments propagation are handled directly in this notebook.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - **PII Tag-based processing**: Tables and columns are processed iteratively per PII sensitivity
# MAGIC   level (STANDARD, CONFIDENTIAL, RGPD) using `PIICleaningManager`
# MAGIC - **Six tables cleaned**: the 6 pilotage business tables (`r002fec`, `r002fem`, `r010sit`,
# MAGIC   `r034fun`, `r038afa`, `r070tac`), each ingested FULL as `*_latest`. `r070acc` (physical-access
# MAGIC   log) is deliberately NOT ingested/cleaned.
# MAGIC - **ID-groupe canonical form (Layer 3)**: `usu_idglob` (and `usu_idghie`) is the group id that
# MAGIC   joins `immat.user_id`. In bronze it is **bigint** with `0` used as a "not filled" sentinel,
# MAGIC   whereas `immat.user_id` is a **string** with no leading zeros. Cleaning maps `NULL`/`0` → NULL
# MAGIC   and casts the remaining values to STRING, so the FPE masking is identical on both sides
# MAGIC   (routed to `fpe_digits` like `user_id`) and the masked join holds. Match validated in clear:
# MAGIC   340/341 active + 985/987 dismissed distinct ids match immat.
# MAGIC - **PII tag propagation**: Handled directly in this notebook after the write step, using a column name map from source to target schemas
# MAGIC - **Comments propagation**: Table and column comments are propagated automatically from source to target during the write step
# MAGIC
# MAGIC **Intended Pipeline:**
# MAGIC - HR SENIOR Bronze Cleaning pipeline
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - `{PIPELINE_WRITE_ENV}_bronze_cleaned_hr.senior.{r002fec,r002fem,r010sit,r034fun,r038afa,r070tac}_latest`
# MAGIC
# MAGIC **Inputs:**
# MAGIC - `{PIPELINE_READ_ENV}_bronze_hr.senior.*`
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - SENIOR Bronze Ingestion pipeline
# MAGIC
# MAGIC **Automatically handled:**
# MAGIC - PII tag propagation (source → target column name map)
# MAGIC - Table and column comments propagation
# MAGIC
# MAGIC **Things performed in this notebook:**
# MAGIC 1. Load the SENIOR tables and organize columns by PII tag
# MAGIC 2. Apply three-layer cleaning pipeline per PII level (Layer 1: universal string baseline; Layer 2: type correction; Layer 3: business rules)
# MAGIC 3. Rename PII columns (strip trailing `_`; custom overrides via `COLUMNS_RENAME`)
# MAGIC 4. Write cleaned tables to bronze_cleaned catalog
# MAGIC 5. Propagate PII tags from source to target
# MAGIC 6. Propagate table and column comments automatically

# COMMAND ----------

# DBTITLE 1,Imports header
# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame


# Logging
from leap_utils.common import logger


from utils.bronze_cleaning_pipeline import run_bronze_cleaning_pipeline


# COMMAND ----------

# DBTITLE 1,Widgets header
# MAGIC %md
# MAGIC ## Standard Configuration & Widgets

# COMMAND ----------

# DBTITLE 1,Pipeline environment widgets
# Environment where this notebook writes its output silver table
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Environment from which other pipeline silver/gold tables are read
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Environment from which reference/bronze tables are read (usually prod)
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# When true, quality check failures are logged as warnings instead of errors
dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# DBTITLE 1,Debug and log-level widgets
dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Logger setup
log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Notebook Configuration & Constants header
# MAGIC %md
# MAGIC ## Notebook Configuration & Constants

# COMMAND ----------

# DBTITLE 1,Source and Target
# @DevTeam -> This cell is dedicated to source and target configuration, only the schema should be modified by the user
CATALOG_SOURCE = f"{PIPELINE_READ_ENV}_bronze_hr"
CATALOG_TARGET = f"{PIPELINE_WRITE_ENV}_bronze_cleaned_hr"
SCHEMA = "senior"

# Allowlist of bronze tables to clean into bronze_cleaned. The senior schema also holds the
# Lakeflow internals (event_log_*, __materialization_*) and senior_ingestion_freshness_all,
# which must NOT be promoted — only the 6 pilotage business tables are cleaned. All ingested
# FULL as *_latest. r070acc (physical-access log) is not ingested and therefore absent here.
TABLES_TO_CLEAN: set[str] = {
    "r002fec_latest",  # feriados (holiday dates)
    "r002fem_latest",  # calendarios de feriados
    "r010sit_latest",  # situacoes / absence statuses
    "r034fun_latest",  # employee referential (200 cols)
    "r038afa_latest",  # absences
    "r070tac_latest",  # access-transaction types
}

# Explicit primary key per cleaned table. The grain is a design property of the TARGET table, so
# it is declared here and applied deliberately after the write — NOT propagated from bronze via
# lineage. Column names must match the CLEANED names (senior columns have no trailing `_`, so
# the PII rename strip does not touch these keys). Empty / absent → no PK tag applied.
PRIMARY_KEYS: dict[str, list[str]] = {
    "r002fec_latest": ["codfer", "datfer"],
    "r002fem_latest": ["codfer"],
    "r010sit_latest": ["codsit"],
    "r034fun_latest": ["numemp", "numcad", "tipcol"],
    "r038afa_latest": ["numemp", "tipcol", "numcad", "datafa", "horafa"],
    "r070tac_latest": ["tipacc"],
}

# COMMAND ----------

# DBTITLE 1,Specific configuration
# @DevTeam -> Schema-specific configuration — edit this cell when adapting the notebook to a new schema.
# For table-specific business rules, see the Specific Overrides cell.

# Boolean cast — {table_name: [col, ...]}
COLUMNS_BOOL: dict[str, list[str]] = {}

# Date cast — {table_name: {col_name: date_format | None}}
# date_format: explicit pattern (e.g. "dd/MM/yyyy") or None → DEFAULT_DATE_FORMATS
COLUMNS_DATE: dict[str, dict[str, str | None]] = {}

# String cast — {table_name: [col, ...]}. Force these columns to string in bronze_cleaned
# (for cross-source type consistency). The id-groupe columns (usu_idglob / usu_idghie) are NOT
# listed here: their cast to string is coupled with the 0-sentinel → NULL rule and is handled
# together in Layer 3 (apply_specific_cleaning), while the column is still bigint.
COLUMNS_STRING: dict[str, list[str]] = {}

# Column renames — overrides the default rstrip("_") rule for specific columns.
# Keys: source column names (as tagged in bronze). Values: desired final names.
# The standard strip is applied first; these overrides are applied on top.
COLUMNS_RENAME: dict[str, dict[str, str]] = {}

# COMMAND ----------

# DBTITLE 1,Specific Overrides – header
# MAGIC %md
# MAGIC ## Specific Overrides (Layer 3)
# MAGIC
# MAGIC The three-layer cleaning pipeline is centralised in `utils/bronze_cleaning_pipeline.py`. Layers 1 (trim + nullify) and 2 (type correction) are driven by the configuration dicts above.
# MAGIC
# MAGIC **The cell below is the only schema-specific code** — edit `apply_specific_cleaning` to add or change Layer 3 business rules. The function receives:
# MAGIC - `df` — the DataFrame, already trimmed (Layer 1) and typed (Layer 2)
# MAGIC - `table_name` — the table currently being processed
# MAGIC - `pii_cols` — the PII column names in scope
# MAGIC
# MAGIC Use an `if table_name == "..."` guard to target a specific table.

# COMMAND ----------

# DBTITLE 1,apply_specific_cleaning
# @DevTeam -> THIS IS THE CELL TO EDIT for table-specific cleaning logic (Layer 3).
# The function is called once per table inside process_pii_tag, after Layers 1 and 2.
# Add transforms inside the relevant table block. Non-targeted tables pass through unchanged.

# ID-groupe columns of the employee referential: bigint in bronze, with 0 used as a
# "not filled" sentinel. Cleaned to the canonical form of immat.user_id (string, no leading
# zeros) so the FPE masking matches on both sides and the masked join to immat holds.
ID_GROUP_COLS: list[str] = ["usu_idglob", "usu_idghie"]

def apply_specific_cleaning(
    df: DataFrame,
    table_name: str,
    pii_cols: list[str],
) -> DataFrame:
    """Apply table-specific business rule transformations (Layer 3).

    Called once per table inside process_pii_tag, after Layer 1 (string baseline)
    and Layer 2 (type correction).

    Args:
        df:         DataFrame after Layers 1 and 2.
        table_name: Name of the table currently being processed.
        pii_cols:   PII column names in scope for this table.

    Returns:
        DataFrame with table-specific transformations applied.
    """
    # r034fun — employee referential. Normalise the group id(s) to immat.user_id canonical form:
    #   * usu_idglob / usu_idghie are bigint with 0 meaning "ID Global not filled" → treat as NULL
    #   * cast the remaining values to STRING with no leading zeros (bigint cast already does this)
    # This makes the FPE-masked value identical to immat.user_id (both routed to fpe_digits), so a
    # consumer can join senior ↔ immat on the masked column. In clear the match is 340/341 active
    # (Trabalhando/Ferias/…) and 985/987 dismissed distinct ids. Rows with 0/NULL stay non-joinable
    # (source gap: 25 active employees have no ID Global).
    if table_name == "r034fun_latest":
        _present = [col for col in ID_GROUP_COLS if col in df.columns]  # compute once
        if _present:
            df = df.withColumns({
                col: f.when(f.col(col).isNull() | (f.col(col) == 0), f.lit(None))
                      .otherwise(f.col(col).cast("string"))
                for col in _present
            })
    return df

# COMMAND ----------

# DBTITLE 1,Pipeline Execution – header
# MAGIC %md
# MAGIC # Pipeline Execution

# COMMAND ----------

# DBTITLE 1,Run bronze cleaning pipeline
run_bronze_cleaning_pipeline(
    spark=spark,
    log=log,
    catalog_source=CATALOG_SOURCE,
    catalog_target=CATALOG_TARGET,
    schema=SCHEMA,
    tables_to_clean=TABLES_TO_CLEAN,
    primary_keys=PRIMARY_KEYS,
    columns_to_cast_to_bool=COLUMNS_BOOL,
    columns_to_cast_to_date=COLUMNS_DATE,
    columns_to_cast_to_string=COLUMNS_STRING,
    columns_to_rename=COLUMNS_RENAME,
    apply_specific_cleaning_fn=apply_specific_cleaning,
)
