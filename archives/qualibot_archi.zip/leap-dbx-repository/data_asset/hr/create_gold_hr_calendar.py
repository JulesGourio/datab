# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Gold HR Calendar — Monthly Summary
# MAGIC %md
# MAGIC ## Gold HR Calendar — Monthly Summary per Workplace
# MAGIC
# MAGIC Autonomous notebook: reads the silver calendar reference table, aggregates to one row per
# MAGIC workplace per month, and writes to `{pipeline_write_env}_gold_hr.calendars.calendar_monthly_summary`
# MAGIC (full overwrite).
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | Silver calendar | `{pipeline_read_env}_silver_hr` | `absenteism` | `calendar` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_gold_hr.calendars.calendar_monthly_summary`
# MAGIC
# MAGIC **Grain**: 1 row per `(country, workplace, year, month)`
# MAGIC
# MAGIC **Purpose**: Provides the denominator for absenteeism rate calculations — working days and
# MAGIC standard hours per workplace per month. Also exposes holiday and closure counts for reporting.
# MAGIC
# MAGIC **Write mode**: overwrite (full table rebuild).

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql import functions as f

from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger
from data_asset.hr.utils.table_schema_map_utils import load_config

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# DBTITLE 1,Config: widgets & logging
# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config: source and target
# --- Source ---
SILVER_CATALOG = f"{PIPELINE_READ_ENV}_silver_hr"
SILVER_SCHEMA = "absenteism"
SILVER_TABLE = "calendar"
SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# --- Target ---
config = load_config(config_path="config/gold_calendar_column_mapping.yaml")
_target = config["target"]
GOLD_CATALOG = f"{PIPELINE_WRITE_ENV}_gold_hr"
GOLD_SCHEMA = _target["schema"]
GOLD_TABLE = _target["table"]

# --- Full table paths ---
GOLD_FULL_TABLE = f"{GOLD_CATALOG}.{GOLD_SCHEMA}.{GOLD_TABLE}"

# COMMAND ----------

# DBTITLE 1,Input data - Immat reference
# Load IMMAT GOLD data
df_immat_gold = spark.table(f"{PIPELINE_READ_ENV}_gold_hr.immat.immat_full_latest")

# Next: definition of dicts for mapping cleaned name to actual immat names
workplace_immat = {
    r[0] for r in df_immat_gold.select("workplace").distinct().collect() if r[0]
}

# NOTA: we do not use immat a as a reference for the workplaces' countries.
# this calendar column will, in fact, not be used, we keep it because it's pretty

# COMMAND ----------

# DBTITLE 1,Input data - Silver calendar
df_silver = spark.table(SILVER_FULL_TABLE)

if LOG_LEVEL == "debug":
    count_source = df_silver.count()
    log.debug(f"[{SILVER_TABLE}] {count_source:,} rows read from silver")

# COMMAND ----------

# DBTITLE 1,Prep. 1 - Initialize gold dataframe
df_gold = df_silver

if LOG_LEVEL == "debug":
    count_gold = df_gold.count()
    log.info(f"[{GOLD_TABLE}] {count_gold:,} rows after aggregation")

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
def _build_extra_red_results(
    df_gx: SparkDFDataset,
) -> list[ExpectationSuiteValidationResult]:
    df_days_per_group = df_gold.groupBy("year", "workplace").agg(
        f.count("*").alias("row_count")
    )
    df_gx_grouped = SparkDFDataset(df_days_per_group, persist=False)

    return [
        # working_hours >= 0
        df_gx.expect_column_values_to_be_between(
            column="working_hours",
            min_value=0,
        ),
        # week >= 1 and <= 53
        df_gx.expect_column_values_to_be_between(
            column="week",
            min_value=1,
            max_value=53,
        ),
        # month >= 1 and <= 12
        df_gx.expect_column_values_to_be_between(
            column="month",
            min_value=1,
            max_value=12,
        ),
        # year >= 2020 and <= 3000
        df_gx.expect_column_values_to_be_between(
            column="year",
            min_value=2020,
            max_value=3000,
        ),
        # workplace in workplace_immat
        df_gx.expect_column_values_to_be_in_set(
            column="workplace",
            value_set=workplace_immat,
        ),
        # Each (year, workplace) group must have 365 or 366 days
        df_gx_grouped.expect_column_values_to_be_between(
            column="row_count",
            min_value=365,
            max_value=366,
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_gold,
    config=config,
    full_table_path=GOLD_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=False,
    drop_null_pk_rows=False,
    overwrite_schema=True,
    is_debug=LOG_LEVEL == "debug",
)
