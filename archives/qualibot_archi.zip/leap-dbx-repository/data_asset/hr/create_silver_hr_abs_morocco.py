# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Silver HR Absences — Morocco
# MAGIC %md
# MAGIC ## Silver HR Absences — Morocco
# MAGIC
# MAGIC Autonomous notebook: reads Morocco absences from bronze cleaned, maps to unified silver schema,
# MAGIC and writes to `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` with `REPLACE WHERE source = 'MOROCCO'`.
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | Morocco absences | `{pipeline_read_env}_bronze_cleaned_hr` | `morocco_abs` | `morocco_abs_unpivot_latest` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` (column `source = 'MOROCCO'`)
# MAGIC
# MAGIC **Filter**: Valid records only (`_meta_validity_check = true`). Excludes null `day_value` and numeric values (hours worked, e.g. `8`, `7.57`).
# MAGIC
# MAGIC **Note**: Morocco provides one row per employee per calendar day (already unpivoted). `id_group` is used directly as `id_group` — 100% match with `immat.user_id` confirmed on 300 distinct employees, no employee master join needed. `absence_duration_min` defaults to 480 min (8h) — no time granularity available.
# MAGIC
# MAGIC **Numeric filtering**: `day_value` values parseable as DOUBLE (e.g. `8`, `7.57`, `0`) represent hours worked and are excluded. Absence codes (e.g. `CP`, `CM`) are non-numeric and pass through.
# MAGIC
# MAGIC **Case normalisation**: all codes are uppercased before parsing — `Mat` → `MAT`, `1/2cp` → `1/2CP`.
# MAGIC
# MAGIC **Half-day logic**: `day_value` starting with `1/2` (e.g. `1/2CP`, `1/2cp`) indicates a half-day absence. The `1/2` prefix is stripped to extract the code; `absence_day_value` is set to 0.5. Full-day entries produce `absence_day_value` = 1.0.
# MAGIC
# MAGIC **Code mapping** (static): A → Absence Injustifiée, ALT → Allaitement, CM → Maladie, CP → Congé, CSS → Congé sans solde, CT → Chômage technique, DC → Congé décès, F → Jour Férié (kept pending business decision), MA → Congé mariage, MAT → Maternité, NA → Congé de naissance, R → Retard, REC → Récupération, S → Sortie. `absence_type_desc` is null for unknown codes (`MAP` — 16 records).

# COMMAND ----------

# DBTITLE 1,Config
from itertools import chain
from pyspark.sql import functions as f, Window

from data_asset.hr.utils.table_schema_map_utils import load_config
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# --- Source ---
BRONZE_CLEANED_CATALOG = f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
MOROCCO_SCHEMA = "morocco_abs"
MOROCCO_ABSENCES_TABLE = "morocco_abs_unpivot_latest"  # one row per employee per calendar day — already unpivoted

MOROCCO_ABSENCE_LABELS = {  # static mapping: normalised code → human-readable label (MAP unknown — null desc)
    "A": "Absence Injustifiée",
    "ALT": "Allaitement",
    "CM": "Maladie",
    "CP": "Congé",
    "CSS": "Congé sans solde",
    "CT": "Chômage technique",
    "DC": "Congé décès",
    "F": "Jour Férié",
    "MA": "Congé mariage",
    "MAP": "Mise à pied",
    "MAT": "Maternité",
    "NA": "Congé de naissance",
    "R": "Retard",
    "REC": "Récupération",
    "S": "Sortie",
}

config = load_config(config_path="config/silver_abs_column_mapping.yaml")
_target = config["target"]
SILVER_CATALOG = f"{PIPELINE_WRITE_ENV}_silver_hr"
SILVER_SCHEMA = _target["schema"]
SILVER_TABLE = _target["table"]
SOURCE = "MOROCCO"

SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# Derive MIN_ABSENCE_DATE from immat coverage start (absences before immat cannot be enriched)
_immat_table = f"{PIPELINE_READ_ENV}_gold_hr.immat.immat_monthly_history"
_min_immat_month = spark.sql(f"SELECT MIN(year_month) FROM {_immat_table}").collect()[
    0
][0]
MIN_ABSENCE_DATE = f"{_min_immat_month}-01"
log.info(f"[{SOURCE}] MIN_ABSENCE_DATE = {MIN_ABSENCE_DATE} (immat coverage floor)")

# COMMAND ----------

# DBTITLE 1,Non-PII Cleaning
# MAGIC %md
# MAGIC ### Non-PII Cleaning
# MAGIC Applied by `clean_non_pii` after column mapping:
# MAGIC 1. Trim all string columns and nullify empty strings
# MAGIC 2. Drop rows where any mandatory column (YAML contract) is null

# COMMAND ----------

# DBTITLE 1,read_morocco_absences
def read_morocco_absences():
    """
    Read and map Morocco absence records to the silver schema.

    Source filter: _meta_validity_check = True (defensive guard), day_value IS NOT NULL,
    and try_cast(day_value as double) IS NULL -- excludes numeric hour values (e.g. '8', '7.57', '0').
    Uses try_cast (not cast) to avoid ANSI-mode exceptions on non-numeric strings.
    id_group is used directly.

    Case normalisation: day_value is uppercased before parsing -- Mat->MAT, 1/2cp->1/2CP.
    Half-day logic: day_value starting with '1/2' (e.g. '1/2CP') indicates a half-day absence.
    The '1/2' prefix (3 chars) is stripped to extract the code; absence_day_value = 0.5.
    Full-day entries produce absence_day_value = 1.0.

    absence_type_desc resolved via MOROCCO_ABSENCE_LABELS static mapping. Null for unknown codes (MAP).
    absence_duration_min: 480 min (8h) for full-day absences, 240 min (4h) for half-days -- no finer time granularity available.
    day_order: row_number() per (id_group, absence_date) ordered by absence_code.
    dropDuplicates() is a defensive guard against potential upstream re-ingestion.
    """
    _label_map = f.create_map([f.lit(x) for x in chain(*MOROCCO_ABSENCE_LABELS.items())])

    df = (
        spark.table(f"{BRONZE_CLEANED_CATALOG}.{MOROCCO_SCHEMA}.{MOROCCO_ABSENCES_TABLE}")
        .filter(
            (f.col("_meta_validity_check")) &           # defensive guard
            (f.col("day_value").isNotNull()) &
            (f.expr("try_cast(day_value as double) is null")) &  # exclude numeric hour values (e.g. '8', '7.57') — ANSI-safe
            (f.col("date") >= MIN_ABSENCE_DATE)
        )
        .withColumns({
            "is_half_day": f.upper(f.col("day_value")).startswith("1/2"),
            # strip '1/2' prefix if present, uppercase -- e.g. '1/2cp' -> 'CP', 'Mat' -> 'MAT'
            "absence_code": f.when(
                f.upper(f.col("day_value")).startswith("1/2"),
                f.upper(f.col("day_value")).substr(4, 100)
            ).otherwise(f.upper(f.col("day_value"))),
        })
    )
    w = Window.partitionBy("id_group", "date").orderBy("absence_code")
    return (
        df.dropDuplicates()  # defensive guard against upstream re-ingestion
        .select(
            f.col("id_group"),                                   # id_group: global employee identifier -- 100% match with immat.user_id
            f.col("date").alias("absence_date"),
            f.col("absence_code").alias("absence_type_code"),
            _label_map[f.col("absence_code")].alias("absence_type_desc"),  # static mapping -- null for unknown codes (MAP)
            f.when(f.col("is_half_day"), f.lit(240)).otherwise(f.lit(480)).cast("long").alias("absence_duration_min"),
            f.when(f.col("is_half_day"), f.lit(0.5)).otherwise(f.lit(1.0)).alias("absence_day_value"),
            f.row_number().over(w).alias("day_order"),
            f.lit(SOURCE).alias("source"),
        )
    )

# COMMAND ----------

# DBTITLE 1,Input data
df_raw = read_morocco_absences()
if LOG_LEVEL == "debug":
    count_raw = df_raw.count()
    log.debug(f"[{SOURCE}] {count_raw:,} rows after read + mapping")

# log unknown codes (null desc from static mapping)
unknown = df_raw.filter(f.col("absence_type_desc").isNull()).select("absence_type_code").distinct().collect()
if unknown:
    log.warning(f"[{SOURCE}] Unknown codes (null desc): {[r[0] for r in unknown]}")



# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
def _build_extra_red_results(df_gx: SparkDFDataset) -> list[ExpectationSuiteValidationResult]:
    return [
        # absence_duration_min >= 0 and <= 1440 (no single-day absence > 24h)
        df_gx.expect_column_values_to_be_between(
            column="absence_duration_min", min_value=0, max_value=1440,
        ),
        # absence_day_value in [0, 1]
        df_gx.expect_column_values_to_be_between(
            column="absence_day_value", min_value=0, max_value=1, mostly=1.0,
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_raw,
    config=config,
    full_table_path=SILVER_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=True,
    drop_null_pk_rows=True,
    cluster_cols="source, id_group",
    replace_where=f"source = '{SOURCE}'",
    is_debug=LOG_LEVEL == "debug",
)
