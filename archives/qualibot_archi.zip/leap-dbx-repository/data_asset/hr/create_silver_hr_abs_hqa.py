# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Silver HR Absences — HQA
# MAGIC %md
# MAGIC ## Silver HR Absences — HQA
# MAGIC
# MAGIC Autonomous notebook: reads HQA absences from bronze cleaned, maps to unified silver schema,
# MAGIC and writes to `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` with `REPLACE WHERE source = 'HQA'`.
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | HQA (Horoquartz) | `{pipeline_read_env}_bronze_cleaned_hr` | `horoquartz_group` | `v_hrdatalake_hophabs_latest` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` (column `source = 'HQA'`)
# MAGIC
# MAGIC **Filter**: Only `motype = 'A'` (real absences). Excludes counters (C) and other (P).

# COMMAND ----------

# DBTITLE 1,Config
from pyspark.sql import functions as f, Window

from data_asset.hr.utils.table_schema_map_utils import load_config
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# --- Source ---
BRONZE_CLEANED_CATALOG = f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
HQA_SCHEMA             = "horoquartz_group"
HQA_ABSENCES_TABLE     = "v_hrdatalake_hophabs_latest"
HQA_MOTIF_REF_TABLE    = "v_hrdatalake_hopmoti_latest"

# --- Business rules ---
ABSENCE_DAY_THRESHOLD_MIN = 300  # >= 5h = 1 day, < 5h = 0.5 day (to evolve with dim_calendar)

# --- Target (from YAML contract — single source of truth) ---
config = load_config(config_path="config/silver_abs_column_mapping.yaml")
_target = config["target"]
SILVER_CATALOG    = f"{PIPELINE_WRITE_ENV}_silver_hr"  # env-driven, overrides YAML default
SILVER_SCHEMA     = _target["schema"]     # absenteism
SILVER_TABLE      = _target["table"]      # fact_absence_day
SOURCE            = "HQA"

SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# Derive MIN_ABSENCE_DATE from immat coverage start (absences before immat cannot be enriched)
_immat_table = f"{PIPELINE_READ_ENV}_gold_hr.immat.immat_monthly_history"
_min_immat_month = spark.sql(f"SELECT MIN(year_month) FROM {_immat_table}").collect()[0][0]
MIN_ABSENCE_DATE = f"{_min_immat_month}-01"
log.info(f"[{SOURCE}] MIN_ABSENCE_DATE = {MIN_ABSENCE_DATE} (immat coverage floor)")

# COMMAND ----------

# DBTITLE 1,Non-PII Cleaning
# MAGIC %md
# MAGIC ## Non-PII Cleaning
# MAGIC
# MAGIC Standard cleaning applied to all Silver absence notebooks **after** column mapping.
# MAGIC PII cleaning is already handled upstream (Bronze → Bronze Cleaned).
# MAGIC
# MAGIC Rules applied here:
# MAGIC 1. **Trim** all string columns (remove leading/trailing whitespace)
# MAGIC 2. **Nullify** empty strings (consistent NULL representation)
# MAGIC 3. **Drop rows** where mandatory fields are null (driven from YAML contract)
# MAGIC
# MAGIC → `data_asset.hr.utils.silver_cleaning_utils`

# COMMAND ----------

# DBTITLE 1,read_hqa_absences
def read_hqa_absences():
    """
    Read and map HQA absence records to the silver schema.

    Source filter: motype = 'A' (real absences only) and motidur > 0 (excludes phantom records).
    Joins with the motif reference table to resolve absence_type_desc from the code.
    Left join — absence_type_desc is null when the motif code has no match in the ref table.

    absence_day_value heuristic: motidur >= ABSENCE_DAY_THRESHOLD_MIN (300 min = 5h) → 1.0 full day, else 0.5 half-day.

    Defensive dedup: Window on source PK (matri, dat, ordre) ordered by datmod DESC,
    row_number == 1. Keeps the latest version per source slot if multiple versions exist.

    Guard retained in case upstream source or ingestion regresses.

    day_order: cast(ordre as int) — source value, unique per (matri, dat) by design
    (ordre=0002 exists for genuine multi-absences, 4 rows observed).
    """
    df = spark.table(f"{BRONZE_CLEANED_CATALOG}.{HQA_SCHEMA}.{HQA_ABSENCES_TABLE}")
    ref = spark.table(
        f"{BRONZE_CLEANED_CATALOG}.{HQA_SCHEMA}.{HQA_MOTIF_REF_TABLE}"
    ).select(
        f.col("motif").alias("_ref_motif"),
        f.col("libelle").alias("absence_type_desc"),
    )

    # dedup on source slot — keep latest version per (matri, dat, ordre)
    _w_dedup = Window.partitionBy("matri", "dat", "ordre").orderBy(
        f.col("datmod").desc()
    )
    deduped = (
        df.filter(
            (f.trim(f.col("motype")) == "A")
            & (f.col("motidur") > 0)
            & (f.to_date("dat") >= MIN_ABSENCE_DATE)
        )
        .withColumn("_rn", f.row_number().over(_w_dedup))
        .filter("_rn = 1")
        .drop("_rn")
    )

    return deduped.join(ref, deduped.motif == ref._ref_motif, "left").select(
        f.col("matri").alias("id_group"),
        f.to_date("dat").alias("absence_date"),
        f.col("motif").alias("absence_type_code"),
        # Business rule: no label in ref table → fall back to the code itself
        f.coalesce(f.col("absence_type_desc"), f.col("motif")).alias(
            "absence_type_desc"
        ),
        f.col("motidur").alias("absence_duration_min"),
        f.when(f.col("motidur") >= ABSENCE_DAY_THRESHOLD_MIN, 1.0)
        .otherwise(0.5)
        .alias("absence_day_value"),
        f.col("ordre").cast("int").alias("day_order"),
        f.lit(SOURCE).alias("source"),
    )

# COMMAND ----------

# DBTITLE 1,Input data
# bronze → silver mapping — selects and renames to fixed 8-col silver schema, lazy
df_raw = read_hqa_absences()

if LOG_LEVEL == "debug":
    count_raw = df_raw.count()
    log.debug(f"[{SOURCE}] {count_raw:,} rows after read + mapping")

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
def _build_extra_red_results(df_gx: SparkDFDataset) -> list[ExpectationSuiteValidationResult]:
    return [
        # absence_duration_min >= 0 and <= 1440 (no single-day absence > 24h)
        df_gx.expect_column_values_to_be_between(
            column="absence_duration_min", min_value=0, max_value=1440,
        ),
        # absence_day_value in [0, 1]
        df_gx.expect_column_values_to_be_between(
            column="absence_day_value", min_value=0, max_value=1, mostly=1.0,
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_raw,
    config=config,
    full_table_path=SILVER_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=True,
    drop_null_pk_rows=True,
    cluster_cols="source, id_group",
    replace_where=f"source = '{SOURCE}'",
    is_debug=LOG_LEVEL == "debug",
)
