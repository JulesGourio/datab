# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Silver HR Absences — UKG
# MAGIC %md
# MAGIC ## Silver HR Absences — UKG
# MAGIC
# MAGIC Autonomous notebook: reads UKG daily attendance records from bronze cleaned, filters absence paycodes,
# MAGIC and writes to `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` with `REPLACE WHERE source = 'UKG'`.
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | UKG pointage journalier | `{pipeline_read_env}_bronze_cleaned_hr` | `ukg` | `pointage_journalier_latest` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` (column `source = 'UKG'`)
# MAGIC
# MAGIC **Filter**: Blacklist approach — excludes work hours (REGULAR, OVERTIME, DOUBLETIME), shift premiums, banked hours, statutory holiday pay, and financial/payout codes. Everything else is an absence paycode.
# MAGIC
# MAGIC **Note**: UKG provides one row per employee × day × paycode. `immat_id` is used directly as `id_group`.
# MAGIC
# MAGIC **Duration**: `hours` column gives actual hours per paycode per day → `absence_duration_min = hours * 60`. Real granularity (not a 480 min default).
# MAGIC
# MAGIC **Day value heuristic**: `absence_day_value` = 1.0 if `hours * 60 > 300` (>5h), else 0.5 — same threshold as HQA/RON.
# MAGIC
# MAGIC **Paycode as code+desc**: `paycode` serves as both `absence_type_code` and `absence_type_desc` (English labels already human-readable: VACATION HOURS, SICK, BEREAVEMENT, etc.).

# COMMAND ----------

# DBTITLE 1,Config
from pyspark.sql import functions as f, Window

from data_asset.hr.utils.table_schema_map_utils import load_config
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# --- Source ---
BRONZE_CLEANED_CATALOG  = f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
UKG_SCHEMA              = "ukg"
UKG_ABSENCES_TABLE      = "pointage_journalier_latest"  # one row per employee × day × paycode

# Blacklist: these paycodes are NOT absences — everything else passes through
UKG_EXCLUDE_PAYCODES = {
    # Work hours
    "REGULAR", "SALARIED REGULAR", "OVERTIME", "DOUBLETIME",
    "Overtime Unapproved", "Overtime Refused",
    # Shift premiums
    "AFTERNOON SHIFT PREMIUM 1.00", "AFTERNOON SHIFT PREMIUM 2.00",
    "NIGHT SHIFT PREMIUM 1.00", "NIGHT SHIFT PREMIUM 1.50",
    "NIGHT SHIFT PREMIUM 2.00", "NIGHT SHIFT PREMIUM 3.50",
    # Banked hours (accrual, not time taken)
    "BANKED OT", "BANKED DT", "BANKED REG",
    # Statutory holiday pay
    "STAT PAY", "STAT PAY 1.5", "STAT PAY 2.0", "STAT 1.5", "STAT UNPAID",
    # Financial / payouts
    "BONUS", "RETROACTIVE PAYMENT", "REFERRAL BONUS",
    "EXCESS VACATION $", "VACATION IN LIEU OF SICK $",
    "TERM VACPAY", "TERM VAC PAYOUT", "SICK HOURS - PAYOUT",
    "VACATION NO TIME TAKEN", "REP-PREM",
    # Temp assignments / travel
    "TEMP CH MECH", "TEMP CH GOS2", "TEMP CH OT GOS2",
    "TRAVEL PAY 2.0", "TRAVEL ALLOWANCE", "TRAVEL HOURS",
    # Call-out (extra work, not absence)
    "CALL OUT", "CALL OUT DOUBLETIME",
}

ABSENCE_DAY_THRESHOLD_MIN = 300  # > 5h = full day (1.0), else half-day (0.5)

config            = load_config(config_path="config/silver_abs_column_mapping.yaml")
_target           = config["target"]
SILVER_CATALOG    = f"{PIPELINE_WRITE_ENV}_silver_hr"
SILVER_SCHEMA     = _target["schema"]
SILVER_TABLE      = _target["table"]
SOURCE            = "UKG"

SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# Derive MIN_ABSENCE_DATE from immat coverage start (absences before immat cannot be enriched)
_immat_table = f"{PIPELINE_READ_ENV}_gold_hr.immat.immat_monthly_history"
_min_immat_month = spark.sql(f"SELECT MIN(year_month) FROM {_immat_table}").collect()[0][0]
MIN_ABSENCE_DATE = f"{_min_immat_month}-01"
log.info(f"[{SOURCE}] MIN_ABSENCE_DATE = {MIN_ABSENCE_DATE} (immat coverage floor)")

# COMMAND ----------

# DBTITLE 1,Non-PII Cleaning
# MAGIC %md
# MAGIC ### Non-PII Cleaning
# MAGIC Applied by `clean_non_pii` after column mapping:
# MAGIC 1. Trim all string columns and nullify empty strings
# MAGIC 2. Drop rows where any mandatory column (YAML contract) is null

# COMMAND ----------

# DBTITLE 1,read_ukg_absences
def read_ukg_absences():
    """
    Read and map UKG absence records to the silver schema.

    Blacklist filter: excludes paycodes in UKG_EXCLUDE_PAYCODES (work hours, premiums,
    banked time, stat pay, financial payouts). Everything else is treated as an absence.
    _meta_validity_check = True and is_combined_paycode = False applied as guards.
    signed_off filter NOT applied -- includes pending records (to review if needed).

    immat_id is used directly as id_group -- 100% match with immat.user_id confirmed.
    No join to referentiel_employes needed.

    hours column gives actual per-day duration -- absence_duration_min = hours * 60.
    absence_day_value heuristic: > 300 min (5h) = 1.0, else 0.5.
    paycode serves as both absence_type_code and absence_type_desc (English labels).
    dropDuplicates() after select removes Airbyte double-ingestion duplicates (~1,715 BK combos
    affected in _latest — same BK, different _airbyte_raw_id). Placed after select so only
    silver columns are compared, before day_order assignment to avoid inflating counts.
    """
    _exclude = list(UKG_EXCLUDE_PAYCODES)

    df = (
        spark.table(f"{BRONZE_CLEANED_CATALOG}.{UKG_SCHEMA}.{UKG_ABSENCES_TABLE}")
        .filter(
            (f.col("_meta_validity_check") == True) &
            (f.col("is_combined_paycode") == False) &      # individual paycodes only, no aggregates
            (f.col("paycode").isNotNull()) &
            (~f.col("paycode").isin(_exclude)) &           # blacklist: exclude work/financial codes
            (f.col("hours").isNotNull()) &
            (f.col("hours") > 0) &                          # exclude zero-hour placeholder rows
            (f.col("apply_date") >= MIN_ABSENCE_DATE)
        )
    )
    return (
        df.select(
            f.col("immat_id").alias("id_group"),            # immat_id: 100% match with immat.user_id
            f.col("apply_date").alias("absence_date"),      # already DATE
            f.col("paycode").alias("absence_type_code"),
            f.col("paycode").alias("absence_type_desc"),    # English labels already human-readable
            (f.col("hours") * 60).cast("long").alias("absence_duration_min"),  # real hours per day
            f.when(
                f.col("hours") * 60 > ABSENCE_DAY_THRESHOLD_MIN, f.lit(1.0)
            ).otherwise(f.lit(0.5)).alias("absence_day_value"),
        )
        .dropDuplicates()  # removes Airbyte double-ingestion (same silver cols, different _airbyte_raw_id)
        .withColumn("day_order", f.row_number().over(
            Window.partitionBy("id_group", "absence_date").orderBy("absence_type_code")
        ))
        .withColumn("source", f.lit(SOURCE))
    )

# COMMAND ----------

# DBTITLE 1,Input data
df_raw = read_ukg_absences()

if LOG_LEVEL == "debug":
    count_raw = df_raw.count()
    log.debug(f"[{SOURCE}] {count_raw:,} rows after read + mapping")

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
def _build_extra_red_results(
    df_gx: SparkDFDataset,
) -> list[ExpectationSuiteValidationResult]:
    return [
        # absence_duration_min >= 0 and <= 2880 (48h workaround for UAT)
        df_gx.expect_column_values_to_be_between(
            column="absence_duration_min",
            min_value=0,
            max_value=2880,
        ),
        # absence_day_value in [0, 1]
        df_gx.expect_column_values_to_be_between(
            column="absence_day_value",
            min_value=0,
            max_value=1,
            mostly=1.0,
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_raw,
    config=config,
    full_table_path=SILVER_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=True,
    drop_null_pk_rows=True,
    cluster_cols="source, id_group",
    replace_where=f"source = '{SOURCE}'",
    is_debug=LOG_LEVEL == "debug",
)
