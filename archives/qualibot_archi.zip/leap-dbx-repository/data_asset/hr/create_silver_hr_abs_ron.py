# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Silver — RON Absences
# MAGIC %md
# MAGIC ## Silver HR Absences — RON
# MAGIC
# MAGIC Autonomous notebook: reads RON absences from bronze cleaned, maps to unified silver schema,
# MAGIC and writes to `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` with `REPLACE WHERE source = 'RON'`.
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | RON | `{pipeline_read_env}_bronze_cleaned_hr` | `ron` | `absentieesm_latest` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` (column `source = 'RON'`)
# MAGIC
# MAGIC **Filter**: Excludes attendance events (Arrival, Break, Lunch) and nulls. Keeps only real absences.

# COMMAND ----------

# DBTITLE 1,Config
from pyspark.sql import functions as f, Window

from data_asset.hr.utils.table_schema_map_utils import load_config
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# --- Source ---
BRONZE_CLEANED_CATALOG = f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
RON_SCHEMA             = "ron"
RON_ABSENCES_TABLE     = "absentieesm_latest"

# Operations that are NOT absences
EXCLUDED_OPERATIONS = ["Arrival", "Break", "Lunch"]

# --- Business rules ---
ABSENCE_DAY_THRESHOLD_MIN = 300  # >= 5h = 1 day, < 5h = 0.5 day (to evolve with dim_calendar)

# --- Target (from YAML contract — single source of truth) ---
config = load_config(config_path="config/silver_abs_column_mapping.yaml")
_target = config["target"]
SILVER_CATALOG    = f"{PIPELINE_WRITE_ENV}_silver_hr"  # env-driven, overrides YAML default
SILVER_SCHEMA     = _target["schema"]     # absenteism
SILVER_TABLE      = _target["table"]      # fact_absence_day
SOURCE            = "RON"

SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# Derive MIN_ABSENCE_DATE from immat coverage start (absences before immat cannot be enriched)
_immat_table = f"{PIPELINE_READ_ENV}_gold_hr.immat.immat_monthly_history"
_min_immat_month = spark.sql(f"SELECT MIN(year_month) FROM {_immat_table}").collect()[0][0]
MIN_ABSENCE_DATE = f"{_min_immat_month}-01"
log.info(f"[{SOURCE}] MIN_ABSENCE_DATE = {MIN_ABSENCE_DATE} (immat coverage floor)")

# COMMAND ----------

# DBTITLE 1,Non-PII Cleaning
# MAGIC %md
# MAGIC ## Non-PII Cleaning
# MAGIC
# MAGIC Standard cleaning applied to all Silver absence notebooks **after** column mapping.
# MAGIC PII cleaning is already handled upstream (Bronze → Bronze Cleaned).
# MAGIC
# MAGIC Rules applied here:
# MAGIC 1. **Trim** all string columns (remove leading/trailing whitespace)
# MAGIC 2. **Nullify** empty strings (consistent NULL representation)
# MAGIC 3. **Drop rows** where mandatory fields are null (driven from YAML contract)
# MAGIC
# MAGIC → `data_asset.hr.utils.silver_cleaning_utils`

# COMMAND ----------

# DBTITLE 1,read_ron_absences
def read_ron_absences():
    """
    Read and map RON absence records to the silver schema.

    Source filter: absence_desc IS NOT NULL, not in (Arrival, Break, Lunch), end > start.
    absence_desc maps to both absence_type_code and absence_type_desc (no separate code/label in source).

    absence_duration_min: timestamp_diff(MINUTE, start, end), cast to BIGINT.
    absence_day_value heuristic: duration >= ABSENCE_DAY_THRESHOLD_MIN (300 min = 5h) → 1.0 full day, else 0.5 half-day.
    day_order: row_number() per (id_group, absence_date) ordered by start time.
    dropDuplicates() after select removes Airbyte double-ingestion duplicates (~53 BK combos
    affected in _latest — same BK, different _airbyte_raw_id). Placed after select so only
    silver columns are compared, before day_order assignment to avoid inflating counts.
    _start kept temporarily in select for chronological ordering, then dropped.
    """
    df = spark.table(f"{BRONZE_CLEANED_CATALOG}.{RON_SCHEMA}.{RON_ABSENCES_TABLE}")
    duration_expr = f.timestamp_diff("MINUTE", f.col("start"), f.col("end")).cast("long")
    return (
        df.filter(
            f.col("absence_desc").isNotNull()
            & ~f.col("absence_desc").isin(EXCLUDED_OPERATIONS)
            & (f.col("end") > f.col("start"))
            & (f.to_date("day") >= MIN_ABSENCE_DATE)
        )
        .select(
            f.col("id_group"),
            f.to_date("day").alias("absence_date"),
            f.col("absence_desc").alias("absence_type_code"),
            f.col("absence_desc").alias("absence_type_desc"),
            duration_expr.alias("absence_duration_min"),
            f.when(duration_expr >= ABSENCE_DAY_THRESHOLD_MIN, 1.0)
            .otherwise(0.5).alias("absence_day_value"),
            f.col("start").alias("_start"),  # kept temporarily for chronological day_order
        )
        .dropDuplicates()  # removes Airbyte double-ingestion (same silver cols + start, different _airbyte_raw_id)
        .withColumn("day_order", f.row_number().over(
            Window.partitionBy("id_group", "absence_date").orderBy("_start")
        ))
        .drop("_start")
        .withColumn("source", f.lit(SOURCE))
    )

# COMMAND ----------

# DBTITLE 1,Input data
df_raw = read_ron_absences()

if LOG_LEVEL == "debug":
    count_raw = df_raw.count()
    log.debug(f"[{SOURCE}] {count_raw:,} rows after read + mapping")

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
def _build_extra_red_results(
    df_gx: SparkDFDataset,
) -> list[ExpectationSuiteValidationResult]:
    return [
        # absence_duration_min >= 0 and <= 1440 (no single-day absence > 24h)
        df_gx.expect_column_values_to_be_between(
            column="absence_duration_min",
            min_value=0,
            max_value=1440,
        ),
        # absence_day_value in [0, 1]
        df_gx.expect_column_values_to_be_between(
            column="absence_day_value",
            min_value=0,
            max_value=1,
            mostly=1.0,
        ),
        # RON-specific: absence_type_code must not be an excluded operation (or null)
        df_gx.expect_column_values_to_not_be_null(column="absence_type_code"),
        df_gx.expect_column_values_to_not_be_in_set(
            column="absence_type_code",
            value_set=EXCLUDED_OPERATIONS,
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_raw,
    config=config,
    full_table_path=SILVER_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=True,
    drop_null_pk_rows=True,
    cluster_cols="source, id_group",
    replace_where=f"source = '{SOURCE}'",
    is_debug=LOG_LEVEL == "debug",
)
