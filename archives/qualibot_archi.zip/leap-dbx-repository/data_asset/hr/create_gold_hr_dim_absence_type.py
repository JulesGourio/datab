# Databricks notebook source
# DBTITLE 1,Gold HR Dim Absence Type
# MAGIC %md
# MAGIC ## Gold HR Dim Absence Type
# MAGIC
# MAGIC Autonomous notebook: reads the silver absence mapping dimension table, validates schema,
# MAGIC and writes to `{pipeline_write_env}_gold_hr.absenteism.dim_absence_type` (full overwrite).
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | Silver abs mapping | `{pipeline_read_env}_silver_hr` | `absenteism` | `dim_absence_type` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_gold_hr.absenteism.dim_absence_type`
# MAGIC
# MAGIC **Grain**: 1 row per `(country, source, field_name, absence_type_code)`
# MAGIC
# MAGIC **Purpose**: Reference dimension mapping source system absence codes to Latecoere Group
# MAGIC absence categories. Used as a lookup by `fact_absence_day` for KPI calculations.
# MAGIC
# MAGIC **Write mode**: overwrite (full table rebuild).

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql import functions as f

from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger
from data_asset.hr.utils.table_schema_map_utils import load_config

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# DBTITLE 1,Config: wirdgets
# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config: source and target
# --- Source ---
SILVER_CATALOG = f"{PIPELINE_READ_ENV}_silver_hr"
SILVER_SCHEMA = "absenteism"
SILVER_TABLE = "dim_absence_type"

# --- Target ---
config = load_config(config_path="config/gold_dim_absence_type_column_mapping.yaml")
_target = config["target"]
GOLD_CATALOG = f"{PIPELINE_WRITE_ENV}_gold_hr"
GOLD_SCHEMA = _target["schema"]
GOLD_TABLE = _target["table"]

# --- Full table paths ---
SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"
GOLD_FULL_TABLE = f"{GOLD_CATALOG}.{GOLD_SCHEMA}.{GOLD_TABLE}"

# COMMAND ----------

# DBTITLE 1,Input data
df_silver = spark.table(SILVER_FULL_TABLE)

if LOG_LEVEL == "debug":
    count_source = df_silver.count()
    log.debug(f"[{SILVER_TABLE}] {count_source:,} rows read from silver")

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
# none

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_silver,
    config=config,
    full_table_path=GOLD_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=None,
    apply_clean_non_pii=False,
    drop_null_pk_rows=False,
    overwrite_schema=True,
    is_debug=LOG_LEVEL == "debug",
)
