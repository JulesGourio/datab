# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Silver HR Absences — India
# MAGIC %md
# MAGIC ## Silver HR Absences — India
# MAGIC
# MAGIC Autonomous notebook: reads India absences from bronze cleaned, maps to unified silver schema,
# MAGIC and writes to `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` with `REPLACE WHERE source = 'INDIA'`.
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | India absences | `{pipeline_read_env}_bronze_cleaned_hr` | `india_abs` | `india_abs_unpivot_latest` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` (column `source = 'INDIA'`)
# MAGIC
# MAGIC **Filter**: Valid records only (`_meta_validity_check = true`). Excludes null `day_value`.
# MAGIC
# MAGIC **Note**: India provides one row per employee per calendar day (already unpivoted at bronze cleaned level — no episode explosion needed). `employee_no` is used directly as `id_group` — 100% match with `immat.user_id` confirmed on 191 distinct employees, no employee master join needed. `absence_duration_min` defaults to 480 min (8h) — no time granularity available.
# MAGIC
# MAGIC **Non-absence filtering**: records with `day_value = 'P'` (Present) are excluded. Exact match — codes like `LWP` are not affected. `OFF` (Off Day) and `H` (Holiday) are kept for now pending business decision.
# MAGIC
# MAGIC **Half-day logic**: any `day_value` containing `:` is a half-day entry. `P` is filtered out of the split parts; the remaining codes are each written as a separate row with `absence_day_value` = 0.5. Examples: `P:CL` → 1 row CL(0.5); `EL:P` → 1 row EL(0.5); `CL:LWP` → 2 rows CL(0.5) + LWP(0.5). Full-day entries (no `:`) produce 1 row with `absence_day_value` = 1.0.
# MAGIC
# MAGIC **Code mapping** (static): A → Absent, CL → Casual Leave, COF → Comp-Off, EL → Earned Leave, ESIC → ESIC Leave, LWP → Leave without Pay, MRL → Marriage Leave, OD → On Duty, PTL → Paternity Leave, WFH → Work From Home. `absence_type_desc` is null for unknown codes (`PL`, `C` — 6 records each, meaning unknown).

# COMMAND ----------

# DBTITLE 1,Config
from itertools import chain
from pyspark.sql import functions as f, Window

from data_asset.hr.utils.table_schema_map_utils import load_config
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# --- Source ---
BRONZE_CLEANED_CATALOG = f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
INDIA_SCHEMA           = "india_abs"
INDIA_ABSENCES_TABLE   = "india_abs_unpivot_latest"  # one row per employee per calendar day — already unpivoted, no episode explosion needed

INDIA_EXCLUDE_CODES  = {"P"}  # non-absence markers excluded from silver — P=Present only for now
INDIA_ABSENCE_LABELS = {     # static mapping: absence code → human-readable label
    "A":    "Absent",
    "C":  "Compensatory Off",
    "CL":   "Casual Leave",
    "COF":  "Compensatory Off",
    "EL":   "Earned Leave",
    "ESIC": "ESIC Leave",
    "H":    "Holiday",
    "LWP":  "Leave without Pay",
    "MRL":  "Marriage Leave",
    "MTL":  "Maternity Leave",
    "OD":   "On Duty",
    "OFF":  "Weekly Off",
    "PL":   "Paternity Leave",
    "PTL":  "Paternity Leave",
    "WFH":  "Work From Home",
}

config            = load_config(config_path="config/silver_abs_column_mapping.yaml")
_target           = config["target"]
SILVER_CATALOG    = f"{PIPELINE_WRITE_ENV}_silver_hr"
SILVER_SCHEMA     = _target["schema"]
SILVER_TABLE      = _target["table"]
SOURCE            = "INDIA"

SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# Derive MIN_ABSENCE_DATE from immat coverage start (absences before immat cannot be enriched)
_immat_table = f"{PIPELINE_READ_ENV}_gold_hr.immat.immat_monthly_history"
_min_immat_month = spark.sql(f"SELECT MIN(year_month) FROM {_immat_table}").collect()[0][0]
MIN_ABSENCE_DATE = f"{_min_immat_month}-01"
log.info(f"[{SOURCE}] MIN_ABSENCE_DATE = {MIN_ABSENCE_DATE} (immat coverage floor)")

# COMMAND ----------

# DBTITLE 1,Non-PII Cleaning
# MAGIC %md
# MAGIC ### Non-PII Cleaning
# MAGIC Applied by `clean_non_pii` after column mapping:
# MAGIC 1. Trim all string columns and nullify empty strings
# MAGIC 2. Drop rows where any mandatory column (YAML contract) is null

# COMMAND ----------

# DBTITLE 1,read_india_absences
def read_india_absences():
    """
    Read and map India absence records to the silver schema.

    Source filter: _meta_validity_check = True (defensive guard)
    and day_value IS NOT NULL, and day_value not in INDIA_EXCLUDE_CODES ('P'=Present, 'OFF'=Off Day, 'H'=Holiday).
    Exact match -- codes like LWP are not affected.
    employee_no is used directly as id_group -- 100% match with immat.user_id
    confirmed on 191 distinct employees. No employee master join needed.

    Half-day logic: any day_value containing ':' is a half-day entry. P is filtered out of the
    split parts; remaining codes are each exploded to a separate row with absence_day_value = 0.5.
    Examples: P:CL -> 1 row CL(0.5); EL:P -> 1 row EL(0.5); CL:LWP -> 2 rows CL(0.5) + LWP(0.5).
    Full-day entries (no ':') produce 1 row with absence_day_value = 1.0.

    absence_type_desc resolved via INDIA_ABSENCE_LABELS static mapping. Null when code not in mapping.
    absence_duration_min defaults to 480 min (8h) -- no time granularity available.
    day_order: row_number() per (id_group, absence_date) ordered by absence_code.
    dropDuplicates() is a defensive guard against potential upstream re-ingestion.
    """
    df = (
        spark.table(f"{BRONZE_CLEANED_CATALOG}.{INDIA_SCHEMA}.{INDIA_ABSENCES_TABLE}")
        .filter(
            (f.col("_meta_validity_check"))  # defensive guard
            & (f.col("day_value").isNotNull())
            & (
                ~f.col("day_value").isin(list(INDIA_EXCLUDE_CODES))
            )  # exclude non-absence markers: P=Present, OFF=Off Day, H=Holiday
            & (f.col("date") >= MIN_ABSENCE_DATE)
        )
        .withColumns(
            {
                # Split on ":" and filter out P, then explode — handles P:CL (1 row), CL:P (1 row), CL:LWP (2 rows)
                "absence_code": f.explode(
                    f.when(
                        f.col("day_value").contains(":"),
                        f.filter(
                            f.split(f.col("day_value"), ":"),
                            lambda x: ~x.isin(list(INDIA_EXCLUDE_CODES)),
                        ),
                    ).otherwise(f.array(f.col("day_value")))
                ),
                "is_half_day": f.col("day_value").contains(":"),
            }
        )
    )
    _label_map = f.create_map([f.lit(x) for x in chain(*INDIA_ABSENCE_LABELS.items())])
    w = Window.partitionBy("employee_no", "date").orderBy("absence_code")
    return df.dropDuplicates().select(  # defensive guard against upstream re-ingestion
        f.col("employee_no").alias(
            "id_group"
        ),  # employee_no: unique HR identifier -- 100% match with immat.user_id
        f.col("date").alias("absence_date"),
        f.col("absence_code").alias("absence_type_code"),
        _label_map[f.col("absence_code")].alias(
            "absence_type_desc"
        ),  # static mapping -- null when code not in INDIA_ABSENCE_LABELS
        f.when(f.col("is_half_day"), f.lit(240))
        .otherwise(f.lit(480))
        .cast("long")
        .alias("absence_duration_min"),
        f.when(f.col("is_half_day"), f.lit(0.5))
        .otherwise(f.lit(1.0))
        .alias("absence_day_value"),
        f.row_number().over(w).alias("day_order"),
        f.lit(SOURCE).alias("source"),
    )

# COMMAND ----------

# DBTITLE 1,Input data
# bronze -> silver mapping — selects and renames to fixed 8-col silver schema, lazy
df_raw = read_india_absences()
if LOG_LEVEL == "debug":
    count_raw = df_raw.count()
    log.info(f"[{SOURCE}] {count_raw:,} rows after read + mapping")

# log unknown codes (null desc from static mapping)
unknown = (
    df_raw.filter(f.col("absence_type_desc").isNull())
    .select("absence_type_code")
    .distinct()
    .collect()
)
if unknown:
    log.warning(f"[{SOURCE}] Unknown codes (null desc): {[r[0] for r in unknown]}")

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
def _build_extra_red_results(
    df_gx: SparkDFDataset,
) -> list[ExpectationSuiteValidationResult]:
    return [
        # absence_duration_min >= 0 and <= 1440 (no single-day absence > 24h)
        df_gx.expect_column_values_to_be_between(
            column="absence_duration_min",
            min_value=0,
            max_value=1440,
        ),
        # absence_day_value in [0, 1]
        df_gx.expect_column_values_to_be_between(
            column="absence_day_value",
            min_value=0,
            max_value=1,
            mostly=1.0,
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_raw,
    config=config,
    full_table_path=SILVER_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=True,
    drop_null_pk_rows=True,
    cluster_cols="source, id_group",
    replace_where=f"source = '{SOURCE}'",
    is_debug=LOG_LEVEL == "debug",
)
