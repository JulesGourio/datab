# Databricks notebook source
# DBTITLE 1,Header – Notebook Documentation
# MAGIC %md
# MAGIC
# MAGIC # [HR] - Kelio Bronze to Bronze Clean
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC **Description:**
# MAGIC Loads all tables from the Kelio bronze schema, applies PII-aware cleaning and type-casting operations, then writes the cleaned DataFrames to the bronze_cleaned catalog. PII tag propagation and comments propagation are handled directly in this notebook.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - **PII Tag-based processing**: Tables and columns are processed iteratively per PII sensitivity level (STANDARD, CONFIDENTIAL, RGPD) using `PIICleaningManager`
# MAGIC - **PII tag propagation**: Handled directly in this notebook after the write step, using a column name map from source to target schemas
# MAGIC - **Comments propagation**: Table and column comments are propagated automatically from source to target during the write step
# MAGIC
# MAGIC **Intended Pipeline:**
# MAGIC - HR Kelio Bronze Cleaning pipeline
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - `{PIPELINE_WRITE_ENV}_bronze_cleaned_hr.kelio.*`
# MAGIC
# MAGIC **Inputs:**
# MAGIC - `{PIPELINE_READ_ENV}_bronze_hr.kelio.*`
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - Kelio Bronze Ingestion pipeline
# MAGIC
# MAGIC **Automatically handled:**
# MAGIC - PII tag propagation (source → target column name map)
# MAGIC - Table and column comments propagation
# MAGIC
# MAGIC **Things performed in this notebook:**
# MAGIC 1. Load all Kelio tables and organize columns by PII tag
# MAGIC 2. Apply three-layer cleaning pipeline per PII level (Layer 1: universal string baseline; Layer 2: type correction; Layer 3: business rules)  
# MAGIC 3. Write cleaned tables to bronze_cleaned catalog
# MAGIC 4. Propagate PII tags from source to target
# MAGIC 5. Propagate table and column comments automatically

# COMMAND ----------

# DBTITLE 1,Imports header
# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame


# Logging
from leap_utils.common import logger


from utils.bronze_cleaning_pipeline import run_bronze_cleaning_pipeline


# COMMAND ----------

# DBTITLE 1,Widgets header
# MAGIC %md
# MAGIC ## Standard Configuration & Widgets

# COMMAND ----------

# DBTITLE 1,Pipeline environment widgets
# Environment where this notebook writes its output silver table
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Environment from which other pipeline silver/gold tables are read
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Environment from which reference/bronze tables are read (usually prod)
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# When true, quality check failures are logged as warnings instead of errors
dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# DBTITLE 1,Debug and log-level widgets
dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Logger setup
log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Notebook Configuration & Constants header
# MAGIC %md
# MAGIC ## Notebook Configuration & Constants

# COMMAND ----------

# DBTITLE 1,Source and Target
# @DevTeam -> This cell is dedicated to source and target configuration, only the schema should be modified by the user
CATALOG_SOURCE = f"{PIPELINE_READ_ENV}_bronze_hr"
CATALOG_TARGET = f"{PIPELINE_WRITE_ENV}_bronze_cleaned_hr"
SCHEMA = "kelio"

# Allowlist of tables to clean into bronze_cleaned. Empty set → clean the whole schema.
TABLES_TO_CLEAN: set[str] = {
    "affectation_absence_latest",
    "affectation_service_latest",
    "badge_latest",
    "badgeage_latest",
    "calcule_absence_latest",
    "calcule_compteur_latest",
    "motif_calcul_latest",
    "organigramme_latest",
    "personne_latest",
    "resultats_latest",
    "salarie_latest",
}

# Explicit primary key per cleaned table. 
# The grain is a design property of the TARGET table, so it is declared here and
# applied deliberately after the write — NOT propagated from bronze via
# lineage (a cleaned table may re-grain / rename / drop key columns).
# Column names must match the CLEANED (post-rename) names.
# Empty / absent → no PK tag applied.
PRIMARY_KEYS: dict[str, list[str]] = {
    "affectation_absence_latest": ["affectation_absence"],
    "affectation_service_latest": ["affectation_service"],
    "badge_latest": ["badge"],
    "badgeage_latest": ["badgeage"],
    "calcule_absence_latest": ["resultats", "motif"],
    "calcule_compteur_latest": ["resultats", "motif"],
    "motif_calcul_latest": ["motif_calcul"],
    "organigramme_latest": ["organigramme"],
    "personne_latest": ["personne"],
    "resultats_latest": ["resultats"],
    "salarie_latest": ["personne"],
}

# COMMAND ----------

# DBTITLE 1,Specific configuration
# Schema-specific configuration 
# Edit this cell when adapting the notebook to a new schema.
# For table-specific business rules, see the Specific Overrides cell.

# Boolean cast — {table_name: [col, ...]}
COLUMNS_BOOL: dict[str, list[str]] = {}

# Date cast — {table_name: {col_name: date_format | None}}
# date_format: explicit pattern (e.g. "dd/MM/yyyy") or None → DEFAULT_DATE_FORMATS
# Example:
# COLUMNS_DATE = {
#     "table_name": {
#         "date_col":  "dd/MM/yyyy",
#         "date_col2": None,
#     }
# }
COLUMNS_DATE: dict[str, dict[str, str | None]] = {}

# String cast — {table_name: [col, ...]}.
COLUMNS_STRING: dict[str, list[str]] = {}

# Person identifiers cast to string across tables.
ID_STRING_COLS: list[str] = ["personne_", "salarie_"]

# Column renames — overrides the default rstrip("_") rule for specific columns.
# Keys: source column names (as tagged in bronze). Values: desired final names.
# The standard strip is applied first; these overrides are applied on top.
# Example:
# COLUMNS_RENAME = {
#     "table_name": {
#         "source_col": "target_col",
#     },
# }
COLUMNS_RENAME: dict[str, dict[str, str]] = {}

# COMMAND ----------

# DBTITLE 1,Specific Overrides – header
# MAGIC %md
# MAGIC ## Specific Overrides (Layer 3)
# MAGIC
# MAGIC The three-layer cleaning pipeline is centralised in `utils/bronze_cleaning_pipeline.py`. Layers 1 (trim + nullify) and 2 (type correction) are driven by the configuration dicts above.
# MAGIC
# MAGIC **The cell below is the only schema-specific code** — edit `apply_specific_cleaning` to add or change Layer 3 business rules. The function receives:
# MAGIC - `df` — the DataFrame, already trimmed (Layer 1) and typed (Layer 2)
# MAGIC - `table_name` — the table currently being processed
# MAGIC - `pii_cols` — the PII column names in scope
# MAGIC
# MAGIC Use an `if table_name == "..."` guard to target a specific table.

# COMMAND ----------

# DBTITLE 1,apply_specific_cleaning
def apply_specific_cleaning(
    df: DataFrame,
    table_name: str,
    pii_cols: list[str],
) -> DataFrame:
    """Apply Layer 3 table-specific business rule transformations."""
    # badge — code_ is the group employee identifier, 8-char zero-padded (e.g. "00004894").
    # Strip the leading zeros so it matches immat.user_id canonical form ("4894").
    # Runs at Layer 3 (before columns_rename), so the column is still "code_".
    if table_name == "badge_latest" and "code_" in pii_cols:
        df = df.withColumn("code_", f.regexp_replace(f.col("code_"), r"^0+(?=.)", ""))

    return df

# COMMAND ----------

# DBTITLE 1,Post-clean: trailing underscores & ID casts – header
# MAGIC %md
# MAGIC ## Post-clean: trailing underscores & ID casts
# MAGIC
# MAGIC Kelio exports every column with a trailing underscore. `normalize_column_names` strips PII
# MAGIC columns inside the pipeline; the function below catches the remaining **non-PII** columns.
# MAGIC It also casts `personne_`/`salarie_` to string for cross-source HR join consistency.

# COMMAND ----------

# DBTITLE 1,post_clean_kelio
def post_clean_kelio(
    dfs_clean_all: dict[str, DataFrame],
    cleaner,
) -> dict[str, DataFrame]:
    """Strip trailing underscores on ALL columns and cast person IDs to string."""
    for table_name, df in dfs_clean_all.items():
        # 1. Strip trailing underscores on non-PII columns still carrying them
        renames = {c: c.rstrip("_") for c in df.columns if c != c.rstrip("_")}
        if renames:
            df = df.withColumnsRenamed(renames)
            for old_col, new_col in renames.items():
                if table_name in cleaner.column_mapping and old_col in cleaner.column_mapping[table_name]:
                    cleaner.column_mapping[table_name][old_col] = new_col
            log.info(f"Stripped trailing '_' on {list(renames)} in {table_name}.")

        # 2. Cast person identifiers to string (not PII-tagged, so not reached by Layer 2)
        dtypes_map = dict(df.dtypes)
        casts = {
            c: f.col(c).cast("string")
            for c in ID_STRING_COLS
            if dtypes_map.get(c) not in (None, "string")
        }
        if casts:
            df = df.withColumns(casts)
            log.info(f"Cast {list(casts)} to string on {table_name}.")

        dfs_clean_all[table_name] = df
    return dfs_clean_all

# COMMAND ----------

# DBTITLE 1,Pipeline Execution – header
# MAGIC %md
# MAGIC # Pipeline Execution

# COMMAND ----------

# DBTITLE 1,Run bronze cleaning pipeline
run_bronze_cleaning_pipeline(
    spark=spark,
    log=log,
    catalog_source=CATALOG_SOURCE,
    catalog_target=CATALOG_TARGET,
    schema=SCHEMA,
    tables_to_clean=TABLES_TO_CLEAN,
    primary_keys=PRIMARY_KEYS,
    columns_to_cast_to_bool=COLUMNS_BOOL,
    columns_to_cast_to_date=COLUMNS_DATE,
    columns_to_cast_to_string=COLUMNS_STRING,
    columns_to_rename=COLUMNS_RENAME,
    apply_specific_cleaning_fn=apply_specific_cleaning,
    post_clean_fn=post_clean_kelio,
)
