# Databricks notebook source
# DBTITLE 1,Header – Notebook Documentation
# MAGIC %md
# MAGIC # [HR] — Propagate PII Tags (SILVER)
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC **Description:**
# MAGIC Propagates PII column tags from `{env}_bronze_cleaned_hr.{schema}` to
# MAGIC `{env}_silver_hr.{schema}` using Unity Catalog column lineage.
# MAGIC Only applies tags that are not already present on the target — idempotent, safe to re-run.
# MAGIC
# MAGIC **Why a separate notebook?**
# MAGIC Column lineage is populated asynchronously after a write (multi-minute delay). Running tag
# MAGIC propagation as a dedicated job step, after the silver notebook, ensures lineage is available
# MAGIC and keeps the silver notebook free of tag side-effects. No PII hashing — confidentiality is
# MAGIC enforced by ABAC dynamic masking bound to the `abac_hr_pii*` tags.
# MAGIC
# MAGIC **Inputs:**
# MAGIC - `system.access.column_lineage` — source → target column mapping
# MAGIC - `system.information_schema.column_tags` — PII tags on source columns
# MAGIC
# MAGIC **Output:**
# MAGIC - UC column tags applied on `{PIPELINE_WRITE_ENV}_silver_hr.{SCHEMA}.*`
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - Job step after the `{SCHEMA}` silver notebook (create_silver_hr_immat)

# COMMAND ----------

# DBTITLE 1,Imports header
# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

# DBTITLE 1,Standard imports
import time

# COMMAND ----------

# DBTITLE 1,LEAP imports
from leap_utils.common import logger

# COMMAND ----------

# DBTITLE 1,Widgets header
# MAGIC %md
# MAGIC ## Standard Configuration & Widgets

# COMMAND ----------

# DBTITLE 1,Pipeline environment widgets
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("schema", "immat")
SCHEMA = dbutils.widgets.get("schema")

# Columns that must NEVER receive a PII tag, even if column lineage links them to a PII source.
# Use for DERIVED columns that only inherit a PII tag because they group by / join on a PII KEY
# (e.g. user_id): their VALUE is not personal data. Comma-separated, case-insensitive. Excluded
# columns are skipped when tagging AND actively UN-tagged if already tagged (self-healing).
dbutils.widgets.text("exclude_columns", "")
EXCLUDE_COLUMNS = {
    c.strip().lower() for c in dbutils.widgets.get("exclude_columns").split(",") if c.strip()
}

# COMMAND ----------

# DBTITLE 1,Debug and log-level widgets
dbutils.widgets.text("debug", "true")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Logger setup
log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Notebook Configuration & Constants header
# MAGIC %md
# MAGIC ## Notebook Configuration & Constants

# COMMAND ----------

# DBTITLE 1,Source and Target
# Generic propagation source -> target within the same {schema}. Defaults reproduce the SILVER use
# case (bronze_cleaned_hr -> silver_hr); pass catalog_source / catalog_target to reuse this notebook
# for another layer, e.g. the GOLD step (silver_hr -> gold_hr).
dbutils.widgets.text("catalog_source", "")
dbutils.widgets.text("catalog_target", "")
_catalog_source = dbutils.widgets.get("catalog_source").strip()
_catalog_target = dbutils.widgets.get("catalog_target").strip()

CATALOG_SOURCE = _catalog_source if _catalog_source else f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
CATALOG_TARGET = _catalog_target if _catalog_target else f"{PIPELINE_WRITE_ENV}_silver_hr"

log.info(f"PII tag propagation: {CATALOG_SOURCE}.{SCHEMA} -> {CATALOG_TARGET}.{SCHEMA}")

# COMMAND ----------

# DBTITLE 1,Propagate PII Tags header
# MAGIC %md
# MAGIC ## Propagate PII Tags
# MAGIC
# MAGIC Queries `system.access.column_lineage` to resolve source → target column mappings, then applies the source PII tags to the corresponding target columns.
# MAGIC
# MAGIC **Idempotency**: before applying, existing tags on the target are fetched from `system.information_schema.column_tags`. Only missing tags are applied — columns already tagged are skipped.
# MAGIC
# MAGIC **Resolution (two ways, merged)**: (1) **same-name** — source PII column → target column of the same name (immediate, no lineage needed → the silver keeps the same column names as bronze_cleaned, so this covers everything instantly); (2) **lineage** — `system.access.column_lineage` resolves any *renamed* PII columns, but is async/permission-filtered so it can lag right after the write.
# MAGIC
# MAGIC `simulate = DEBUG` — set `debug=false` to run the actual `ALTER TABLE` statements.

# COMMAND ----------

# DBTITLE 1,propagate_pii_tags
simulate = DEBUG

# Source PII tags → target columns, resolved TWO ways then merged:
#   1) LINEAGE — resolves RENAMED columns via system.access.column_lineage. BUT that view is
#      populated ASYNCHRONOUSLY (multi-minute delay after the write) AND is permission-filtered,
#      so it can be empty right after the silver run.
#   2) SAME-NAME — source PII column → target column of the SAME name. Independent of lineage, so it
#      tags IMMEDIATELY. The silver mirrors the bronze_cleaned column names → (2) covers everything.
# Union of the two: both are idempotent (the already-tagged anti-join below skips existing tags).
df_lineage = spark.sql(f"""
    SELECT DISTINCT
        cl.target_table_full_name AS target_table,
        cl.target_column_name     AS target_col,
        ct.tag_name
    FROM system.access.column_lineage cl
    INNER JOIN system.information_schema.column_tags ct
        ON  concat(ct.catalog_name, '.', ct.schema_name, '.', ct.table_name) = cl.source_table_full_name
        AND ct.column_name = cl.source_column_name
    WHERE cl.source_table_full_name LIKE '{CATALOG_SOURCE}.{SCHEMA}.%'
      AND cl.target_table_full_name LIKE '{CATALOG_TARGET}.{SCHEMA}.%'
      AND ct.tag_name               LIKE 'abac_hr_pii%'
""")

df_samename = spark.sql(f"""
    SELECT concat('{CATALOG_TARGET}', '.', ct.schema_name, '.', ct.table_name) AS target_table,
           ct.column_name AS target_col,
           ct.tag_name
    FROM system.information_schema.column_tags ct
    INNER JOIN {CATALOG_TARGET}.information_schema.columns tc
        ON  tc.table_schema = ct.schema_name
        AND tc.table_name   = ct.table_name
        AND tc.column_name  = ct.column_name
    WHERE ct.catalog_name = '{CATALOG_SOURCE}'
      AND ct.schema_name  = '{SCHEMA}'
      AND ct.tag_name     LIKE 'abac_hr_pii%'
""")

df_to_tag = df_lineage.unionByName(df_samename).distinct()

# Guard against STALE column lineage. system.access.column_lineage accumulates historical edges,
# so after a rename it can still return an OLD target column name from a previous write. Keep only
# target columns that actually exist in the current target table, so a stale edge to a
# dropped/renamed column is skipped instead of failing the ALTER (COLUMN_NOT_FOUND).
df_target_cols = spark.sql(f"""
    SELECT concat(table_catalog, '.', table_schema, '.', table_name) AS target_table,
           column_name AS target_col
    FROM {CATALOG_TARGET}.information_schema.columns
    WHERE table_schema = '{SCHEMA}'
""")
df_to_tag = df_to_tag.join(df_target_cols, on=["target_table", "target_col"], how="inner")

# Columns already tagged on target — skip to avoid redundant ALTER TABLE calls
df_already_tagged = spark.sql(f"""
    SELECT
        concat(catalog_name, '.', schema_name, '.', table_name) AS target_table,
        column_name AS target_col,
        tag_name
    FROM system.information_schema.column_tags
    WHERE catalog_name = '{CATALOG_TARGET}'
      AND schema_name  = '{SCHEMA}'
      AND tag_name     LIKE 'abac_hr_pii%'
""")

# Left anti-join: only rows not already tagged on target
df_pending = df_to_tag.join(
    df_already_tagged,
    on=["target_table", "target_col", "tag_name"],
    how="left_anti",
)

pending_rows = df_pending.collect()

# Never tag the excluded columns (derived columns that inherit a PII tag only via a PII grouping/
# join key). Also actively UN-tag them if a previous run had over-tagged them (self-healing).
if EXCLUDE_COLUMNS:
    _skipped = [r for r in pending_rows if r.target_col.lower() in EXCLUDE_COLUMNS]
    pending_rows = [r for r in pending_rows if r.target_col.lower() not in EXCLUDE_COLUMNS]
    if _skipped:
        log.info(f"Excluded from tagging: {[(r.target_table, r.target_col) for r in _skipped]}")
    for row in df_already_tagged.collect():
        if row.target_col.lower() in EXCLUDE_COLUMNS:
            if simulate:
                log.info(f"[SIMULATE] UNSET {row.target_table}.{row.target_col} ← {row.tag_name}")
            else:
                spark.sql(
                    f"ALTER TABLE {row.target_table} ALTER COLUMN `{row.target_col}` "
                    f"UNSET TAGS ('{row.tag_name}')"
                )
                log.info(f"Untagged (excluded) {row.target_table}.{row.target_col} {row.tag_name}")

log.info(f"{len(pending_rows)} tag(s) to apply.")

for row in pending_rows:
    if simulate:
        log.info(f"[SIMULATE] {row.target_table}.{row.target_col} ← {row.tag_name}")
    else:
        spark.sql(
            f"ALTER TABLE {row.target_table} ALTER COLUMN `{row.target_col}` SET TAGS ('{row.tag_name}')"
        )
        log.info(f"Tagged {row.target_table}.{row.target_col} with {row.tag_name}")

