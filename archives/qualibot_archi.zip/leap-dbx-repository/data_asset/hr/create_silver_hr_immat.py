# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # HR IMMAT SILVER (from history_change_log)
# MAGIC
# MAGIC **Description:**
# MAGIC Build the SILVER data asset for the IMMAT HR referential, **from the SCD2 history
# MAGIC change-log** (NOT the stack, NOT the latest snapshot).
# MAGIC - 1st STEP : read the cleaned SCD2 history change-log (validity intervals) and DROP the
# MAGIC              bronze ingestion technical _meta_* columns (extraction / file metadata) — only
# MAGIC              the SCD2 flags _meta_is_current / _meta_is_latest are kept
# MAGIC - 2nd STEP : clean the NON-PII business columns (trim, null→Unknown, harmonize
# MAGIC              country / workplace, correct INACTIVE status per interval)
# MAGIC - 3rd STEP : add year_month bounds on the validity interval (reference-by-month helpers)
# MAGIC - 4th STEP : save the silver history (PII tags are propagated by a separate notebook)
# MAGIC
# MAGIC **No PII hashing / no token vault** — PII confidentiality is enforced by **ABAC**
# MAGIC (dynamic column masking) via the `abac_hr_pii*` tags. Those tags are NOT applied here: a
# MAGIC dedicated job step (`propagate_silver_hr_pii_tags`) propagates them from bronze_cleaned via
# MAGIC Unity Catalog column lineage (+ same-name fallback), because lineage is async after the write.
# MAGIC
# MAGIC The SCD2 grain is **preserved** (one row per validity interval). The month-by-month
# MAGIC densification (one row per user_id per month) is done in the **GOLD** notebook
# MAGIC (`create_gold_hr_immat`), so that the absenteeism of a given month can be confronted
# MAGIC with the IMMAT state of the same month.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_bronze_cleaned_hr.immat.immat_data_history_change_log
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver_hr.immat.immat_data_history_change_log
# MAGIC
# MAGIC **How to read the silver history:**
# MAGIC - for a user_id at date D, keep the row where `Start_Validity <= D < End_Validity`
# MAGIC - current rows: `_meta_is_current = true` (End_Validity = 9999-12-31)
# MAGIC
# MAGIC **Deployment prerequisite:** the `{env}_silver_hr` catalog must exist and the ABAC
# MAGIC governance policy for `abac_hr_pii_standard` must cover it (else PII is in clear).

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import re
import time
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.data_asset.pii_cleaning_utils import clean_string_columns
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.validation import gx_validation
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------


def parse_column_comment(column_ddl: str) -> str | None:
    """Extract the comment from a FIRST_COLS DDL fragment such as
    "STRING COMMENT 'my comment'". Returns None when there is no COMMENT clause;
    un-escapes the doubled single quotes ('' -> ')."""
    match = re.search(r"COMMENT\s+'(.*)'\s*$", column_ddl, flags=re.DOTALL)
    return match.group(1).replace("''", "'") if match else None


def attach_column_comments(df: SparkDataFrame, comments: dict) -> SparkDataFrame:
    """Re-attach column comments onto the DataFrame schema metadata so save_table persists them.
    Column comments live in StructField.metadata['comment'] and are DROPPED whenever a column is
    rebuilt by a transform (cast / trim / withColumn), so they must be re-applied before the write —
    this makes the comments 'follow' the column across layers without relying on UC lineage.
    Only columns present in df and carrying a non-empty comment are touched."""
    for col_name, comment in comments.items():
        if comment and col_name in df.columns:
            df = df.withMetadata(col_name, {"comment": comment})
    return df


# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

# Source = the SCD2 history change-log, already PII-cleaned into bronze_cleaned_hr.
BRONZE_CLEANED_CATALOG = f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
SCHEMA = "immat"

HISTORY_CHANGELOG_TABLE = (
    f"{BRONZE_CLEANED_CATALOG}.{SCHEMA}.immat_data_history_change_log"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_CATALOG = f"{PIPELINE_WRITE_ENV}_silver_hr"
SILVER_SCHEMA = "immat"

# Same table name as bronze_cleaned (only the catalog changes: silver_hr).
IMMAT_SILVER_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.immat_data_history_change_log"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# First columns of the silver table (identity + SCD2 validity + month bounds).
# Business columns follow (kept in lowercase, as produced by the LEAP ingestion / bronze_cleaned).
TABLE_SILVER_FIRST_COLS = {
    "user_id": "STRING COMMENT 'Identifiant collaborateur (clé métier de la SCD2)'",
    "Start_Validity": "DATE COMMENT 'SCD2 — début de l''intervalle de validité (inclus)'",
    "End_Validity": "DATE COMMENT 'SCD2 — début de l''intervalle suivant ; 9999-12-31 si courant (exclu)'",
    "start_validity_year_month": "STRING COMMENT 'Mois (yyyy-MM) de Start_Validity'",
    "end_validity_year_month": "STRING COMMENT 'Mois (yyyy-MM) de End_Validity'",
    "_meta_is_current": "BOOLEAN COMMENT 'SCD2 — version courante (End_Validity = 9999-12-31)'",
    "_meta_is_latest": "BOOLEAN COMMENT 'SCD2 — dernière version connue du user_id'",
}

# Cleaning attributes for the silver table (NON-PII business columns only — no hashing).
SILVER_ATTRS_DICT = {
    # SCD2 validity dates already typed DATE in bronze_cleaned; re-cast defensively.
    "date_cols": [
        "birth_date",
        "company_seniority_date",
        "last_hire_date",
        "end_date",
        "contract_suspension_start_date",
        "contract_suspension_end_date",
    ],
    "columns_to_trim": [
        "job",
        "category",
        "company",
        "establishment",
        "workplace",
        "organization",
        "department",
        "service",
        "reason_for_leaving",
        "workplace_country",
        "conventional_category_name",
        "working_day",
        "country",
        "nationality",
        "external_company",
        "job_family",
        "job_speciality",
    ],
    "columns_to_replace_nulls_by_unknown": [
        "job",
        "category",
        "company",
        "establishment",
        "workplace",
        "department",
        "service",
        "conventional_category_name",
        "working_day",
        "country",
        "nationality",
        "job_family",
        "job_speciality",
    ],
    "columns_with_country_name": ["workplace_country", "country", "country_of_company"],
    "primary_key": "user_id,Start_Validity",
    "notnull_cols": "user_id,Start_Validity",
    "cluster_cols": "user_id",
}

# Table-level comment (not carried by the DataFrame metadata → applied via COMMENT ON TABLE).
SILVER_TABLE_COMMENT = (
    "IMMAT — historique SCD2 nettoyé du référentiel RH : 1 ligne par intervalle de validité "
    "(user_id / Start_Validity). État à une date D = version où Start_Validity <= D < End_Validity ; "
    "version courante = _meta_is_current. La densification mois par mois est faite en gold "
    "(immat_monthly_history). PII protégée par ABAC (tags propagés depuis bronze_cleaned)."
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# Flag to avoid processing an empty dataframe
EMPTY_DATAFRAME_FLAG = False

# Silver is a deterministic full rebuild from the (delta-maintained) history change-log.
MODE = "overwrite"

# _meta_* columns intentionally kept in the silver. The bronze ingestion technical metadata
# (_meta_id / _meta_extraction_timestamp / _meta_ingestion_timestamp / _meta_file_* /
# _meta_validity_check) plus the Auto Loader _rescued_data describe the SOURCE FILE / EXTRACTION,
# not the SCD2 business grain — meaningless (and misleading) at silver and beyond, so they are
# DROPPED here rather than being carried across layers and dropped later in gold. Only the two SCD2
# chain-position flags are kept: _meta_is_current (read the version valid at a date) and
# _meta_is_latest (used by the gold immat_full_latest to pick the last known version per user_id).
SILVER_META_KEEP = {"_meta_is_current", "_meta_is_latest"}

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"HISTORY_CHANGELOG_TABLE is:  {HISTORY_CHANGELOG_TABLE}")
log.info(f"IMMAT_SILVER_TABLE is:  {IMMAT_SILVER_TABLE}")
log.info(f"MODE is:  {MODE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks - Functions

# COMMAND ----------

# Imported from leap_utils (gx_validation)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Tables Read

# COMMAND ----------

df_history = spark.read.table(HISTORY_CHANGELOG_TABLE)

if df_history.isEmpty():
    log.warning(f"{HISTORY_CHANGELOG_TABLE} is empty — nothing to build.")
    EMPTY_DATAFRAME_FLAG = True

# Drop the bronze ingestion technical _meta_* columns (+ _rescued_data) right away: they describe
# the source file / extraction, not the SCD2 business grain, so they are useless from silver on.
# Only the SCD2 chain-position flags in SILVER_META_KEEP survive. Done BEFORE snapshotting the
# column comments so their comments are not carried over either.
_meta_drop = [
    c
    for c in df_history.columns
    if (c.startswith("_meta_") and c not in SILVER_META_KEEP) or c == "_rescued_data"
]
if _meta_drop:
    df_history = df_history.drop(*_meta_drop)
    log.info(f"Dropped useless technical columns at silver: {sorted(_meta_drop)}")

# Snapshot the source column comments (Spark schema metadata) NOW, before any transform: casts /
# trims / withColumn rebuild columns and DROP their comment metadata. They are re-attached just
# before the write (see Outputs) so the comments "follow" bronze_cleaned -> silver — the FIRST_COLS
# declarations take precedence on the columns they define (identity / SCD2 / month bounds).
source_col_comments = {
    fld.name: fld.metadata["comment"]
    for fld in df_history.schema.fields
    if fld.metadata.get("comment")
}

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions

# COMMAND ----------

# Trimming reuses leap_utils `clean_string_columns` (same helper as the bronze_cleaned
# notebooks): it trims whitespace AND nullifies empty strings, filtering automatically to the
# string-typed columns actually present (is_clean_all=True suppresses missing-column warnings).

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Cast types

# COMMAND ----------

df_prep = df_history

# Cast date columns defensively (already DATE in bronze_cleaned, harmless if re-cast).
for col in SILVER_ATTRS_DICT["date_cols"]:
    if col in df_prep.columns:
        df_prep = df_prep.withColumn(col, f.to_date(f.col(col)))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Trim columns
# MAGIC
# MAGIC - trim columns whose name is like '%_code'
# MAGIC - trim the other business columns in SILVER_ATTRS_DICT["columns_to_trim"]
# MAGIC
# MAGIC Uses leap_utils `clean_string_columns` (trim + nullify empty strings), same as bronze_cleaned.

# COMMAND ----------

# All string columns containing "_code" + the declared business columns.
code_cols = [cname for cname, dtype in df_prep.dtypes if dtype == "string" and "_code" in cname.lower()]
cols_to_trim = list(dict.fromkeys(code_cols + SILVER_ATTRS_DICT["columns_to_trim"]))
df_prep = clean_string_columns(df=df_prep, columns=cols_to_trim, is_clean_all=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Replace null and blank by "Unknown"

# COMMAND ----------

_null_cols = [
    c
    for c in SILVER_ATTRS_DICT["columns_to_replace_nulls_by_unknown"]
    if c in df_prep.columns
]
df_prep = df_prep.fillna("Unknown", subset=_null_cols)
df_prep = df_prep.replace("", "Unknown", subset=_null_cols)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Harmonize country names

# COMMAND ----------

country_translation_dict = {
    "Belgique": "Belgium",
    "Czech": "Czech Republic",
    "Cezch": "Czech Republic",
    "CZ": "Czech Republic",
    "Cz": "Czech Republic",
    "Česká republika": "Czech Republic",
    "Czech Rep.": "Czech Republic",
    "Allemagne": "Germany",
    "Espagne": "Spain",
    "Bresil": "Brazil",
    "Brésil": "Brazil",
    "Mexique": "Mexico",
    "Bulgarie": "Bulgaria",
    "BG": "Bulgaria",
    "Bg": "Bulgaria",
    "España": "Spain",
    "FR": "France",
    "Fr": "France",
    "Inde": "India",
    "Italie": "Italy",
    "Etat-Unis": "USA",
    "Maroc": "Morocco",
    "Marocco": "Morocco",
    "Tunisie": "Tunisia",
    "United Kingdom": "UK",
    "United States": "USA",
    "Sk": "Slovakia",
}

_country_cols = [
    c for c in SILVER_ATTRS_DICT["columns_with_country_name"] if c in df_prep.columns
]
df_prep = df_prep.replace(country_translation_dict, subset=_country_cols)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 5 - Harmonize workplace

# COMMAND ----------

workplace_patterns_translation_dict = {
    "periole": "Toulouse-Périole",
    "périole": "Toulouse-Périole",
    "montredon": "Toulouse-Montredon",
    "gabardie": "Toulouse-Gabardie",
    "mach1": "Toulouse-Mach1",
    "nazaire": "Saint-Nazaire",
    "social": "Toulouse-Mach1",
    "merignac": "Dassault-Mérignac",
    "mérignac": "Dassault-Mérignac",
    "argenteuil": "Dassault-Argenteuil",
    "prague": "Praha",
    "casablanca": "Had-Soualem",
    "soualem": "Had-Soualem",
    "malaga": "Malaga",
    "jacareï": "Jacarei",
    "jacarei": "Jacarei",
    "belgaum": "Belagavi",
    "plovdiv": "Plovdiv",
}

for col in [c for c in ["workplace", "establishment"] if c in df_prep.columns]:
    new_col = f.col(col)
    for pattern, replacement in workplace_patterns_translation_dict.items():
        new_col = f.when(
            f.lower(f.col(col)).contains(pattern), replacement
        ).otherwise(new_col)
    df_prep = df_prep.withColumn(col, new_col)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions

# COMMAND ----------


def move_dataframe_cols_first(df: SparkDataFrame, cols_to_move: list) -> SparkDataFrame:
    """Move the specified columns (that exist) to the front of the DataFrame."""
    first_cols = [c for c in cols_to_move if c in df.columns]
    other_cols = [c for c in df.columns if c not in first_cols]
    return df.select(*first_cols, *other_cols)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Correct INACTIVE status per validity interval
# MAGIC
# MAGIC The SCD2 already historizes status changes. As a safety, if an interval is flagged
# MAGIC ACTIVE while its end_date is already past the interval start, force it to INACTIVE
# MAGIC (a departure recorded on the referential). "as-at" reference = Start_Validity.

# COMMAND ----------

df_transfo = df_prep
if ("status" in df_transfo.columns) and ("end_date" in df_transfo.columns):
    df_transfo = df_transfo.withColumn(
        "status",
        f.when(
            (f.col("status") == "ACTIVE")
            & (f.col("end_date").isNotNull())
            & (f.col("end_date") < f.col("Start_Validity")),
            f.lit("INACTIVE"),
        ).otherwise(f.col("status")),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - year_month bounds of the validity interval
# MAGIC
# MAGIC Helper columns to reason by month. The dense month-by-month densification (one row per
# MAGIC user_id per month) is produced downstream in the GOLD notebook.

# COMMAND ----------

df_transfo = df_transfo.withColumn(
    "start_validity_year_month",
    f.date_format(f.col("Start_Validity"), "yyyy-MM"),
).withColumn(
    "end_validity_year_month",
    f.date_format(f.col("End_Validity"), "yyyy-MM"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Optimize order of columns

# COMMAND ----------

first_cols = list(TABLE_SILVER_FIRST_COLS.keys())
df_silver = move_dataframe_cols_first(df_transfo, first_cols)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Re-attach column comments (bronze_cleaned -> silver)
# MAGIC
# MAGIC Start from the source column comments snapshotted from bronze_cleaned, then let the silver
# MAGIC `TABLE_SILVER_FIRST_COLS` declarations take precedence for the identity / SCD2 / month-bound
# MAGIC columns. Attached to the DataFrame metadata so `save_table` (overwriteSchema) persists them.

# COMMAND ----------

first_cols_comments = {
    c: parse_column_comment(ddl) for c, ddl in TABLE_SILVER_FIRST_COLS.items()
}
desired_col_comments = dict(source_col_comments)
desired_col_comments.update({c: t for c, t in first_cols_comments.items() if t})
df_silver = attach_column_comments(df_silver, desired_col_comments)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# Quality Checks - Common Functions defined in leap_utils (gx_validation)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - SCD2 grain uniqueness + PK not-null (RED)
# MAGIC
# MAGIC Deposit-style pattern: build a single `SparkDFDataset`, collect all RED expectations
# MAGIC (compound uniqueness of the (user_id, Start_Validity) grain + not-null on each PK column),
# MAGIC then log them in one call. `dest_table` is passed so gx_validation resolves the results
# MAGIC into the **HR** quality_event_table ({env}_bronze_hr.data_quality), not the main
# MAGIC {env}_bronze.data_quality (unreachable from the HR workspace).

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    df_to_check = df_silver
    pk_cols = [c.strip() for c in SILVER_ATTRS_DICT["primary_key"].split(",")]
    notnull_cols = [c.strip() for c in SILVER_ATTRS_DICT["notnull_cols"].split(",")]

    df_gx = SparkDFDataset(df_to_check, persist=False)
    red_quality_check_results = [
        df_gx.expect_compound_columns_to_be_unique(column_list=pk_cols),
    ]
    for one_col in notnull_cols:
        red_quality_check_results.append(
            df_gx.expect_column_values_to_not_be_null(column=one_col)
        )

    gx_validation.validate_and_log_gx_results(
        quality_check_results=red_quality_check_results,
        validation_level="RED",
        info_message=f"SCD2 grain {pk_cols} is unique and PK columns are not null",
        error_message=(
            "Quality checks failed for immat_data_history_change_log, "
            "please check log messages"
        ),
        pipeline_write_env=PIPELINE_WRITE_ENV,
        table_name="immat_data_history_change_log",
        log_to_event_table=True,
        log_successes=True,
        dest_table=IMMAT_SILVER_TABLE,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# Create the empty clustered table if not exists (first columns + cluster on user_id).
if not EMPTY_DATAFRAME_FLAG:
    catalog, schema, table = IMMAT_SILVER_TABLE.split(".")
    try:
        table_utils.create_unity_catalog_table(
            catalog,
            schema,
            table,
            force_reinitialization=False,
            cluster_cols=SILVER_ATTRS_DICT["cluster_cols"],
            partition_col=None,
            primary_key_cols=None,
            columns=TABLE_SILVER_FIRST_COLS,
            force_drop=False,
        )
    except AnalysisException as e:
        log.error(f"Table {IMMAT_SILVER_TABLE} could not be created. Error is {e}")
        raise OSError(
            f"An error occurred while creating the table {IMMAT_SILVER_TABLE}"
        ) from e

# COMMAND ----------

# Save the silver history from df_silver, preserving cluster columns.
if not EMPTY_DATAFRAME_FLAG:
    try:
        startTime = time.time()
        table_utils.save_table(
            dest_table=IMMAT_SILVER_TABLE,
            df=df_silver,
            mode=MODE,
            overwrite_schema=True,
            cluster_cols=SILVER_ATTRS_DICT["cluster_cols"],
            merge_schema=True,
        )
    except AnalysisException as e:
        log.error(f"Table {IMMAT_SILVER_TABLE} could not be saved. Error is {e}")
        raise OSError(
            f"An error occurred while saving the table {IMMAT_SILVER_TABLE}"
        ) from e
    else:
        duration = time.time() - startTime
        log.info(f"Table {IMMAT_SILVER_TABLE} saved in {duration} seconds.")
        log.info(f"Wrote {df_silver.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Table-level comment

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG and SILVER_TABLE_COMMENT:
    spark.sql(
        f"COMMENT ON TABLE {IMMAT_SILVER_TABLE} IS "
        f"'{SILVER_TABLE_COMMENT.replace(chr(39), chr(39) * 2)}'"
    )
    log.info(f"Applied table comment on {IMMAT_SILVER_TABLE}.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - PRIMARY KEY
# MAGIC
# MAGIC PK/grain = (user_id, Start_Validity). No PII hashing is performed and NO tag is applied here:
# MAGIC PII confidentiality relies on ABAC, and the `abac_hr_pii*` tags are propagated from
# MAGIC bronze_cleaned by the dedicated `propagate_silver_hr_pii_tags` notebook (separate job step),
# MAGIC because column lineage is populated asynchronously after this write.

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    _existing = set(spark.table(IMMAT_SILVER_TABLE).columns)

    # --- PRIMARY KEY constraint on the SCD2 grain (informational / RELY) ---
    pk_cols = [c for c in SILVER_ATTRS_DICT["primary_key"].split(",") if c in _existing]
    constraint_name = "immat_data_history_change_log_pk"
    nb_cons = spark.sql(
        f"SELECT count(*) FROM system.information_schema.table_constraints "
        f"WHERE table_catalog = '{SILVER_CATALOG}' AND table_schema = '{SILVER_SCHEMA}' "
        f"AND table_name = 'immat_data_history_change_log' AND constraint_name = '{constraint_name}'"
    ).first()[0]
    if pk_cols and nb_cons == 0:
        table_utils.apply_pk_fk_tags_uc(
            full_table_name=IMMAT_SILVER_TABLE,
            primary_key=pk_cols,
            foreign_keys=[],
            dry_run=False,
        )
        for col in pk_cols:
            table_utils.set_table_column_not_null(
                table_path=IMMAT_SILVER_TABLE, column=col
            )
        table_utils.add_table_primary_key(
            table_path=IMMAT_SILVER_TABLE,
            pk_name=constraint_name,
            columns=",".join(pk_cols),
        )
        log.info(f"Applied PK constraint {pk_cols} on {IMMAT_SILVER_TABLE}.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced

# COMMAND ----------

dbutils.notebook.exit(f"ok:{IMMAT_SILVER_TABLE}")
