# Databricks notebook source
# DBTITLE 1,Header – Notebook Documentation
# MAGIC %md
# MAGIC
# MAGIC # [HR] - Abs Mapping Bronze to Bronze Clean
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC **Description:**
# MAGIC Loads the `abs_mapping_dropdown_latest` table from the abs_mapping bronze schema, applies PII-aware cleaning (RGPD columns only), then writes the cleaned DataFrame to the bronze_cleaned catalog. PII tag propagation and comments propagation are handled directly in this notebook.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - **PII Tag-based processing**: Columns are processed iteratively per PII sensitivity level using `PIICleaningManager`
# MAGIC - **PII tag propagation**: Handled directly in this notebook after the write step
# MAGIC - **Comments propagation**: Table and column comments are propagated automatically from source to target during the write step
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - `{PIPELINE_WRITE_ENV}_bronze_cleaned_hr.abs_mapping.abs_mapping_dropdown_latest`
# MAGIC
# MAGIC **Inputs:**
# MAGIC - `{PIPELINE_READ_ENV}_bronze_hr.abs_mapping.abs_mapping_dropdown_latest`
# MAGIC
# MAGIC **PII columns (RGPD):**
# MAGIC - `field_description`, `example_value`, `absence_category`
# MAGIC
# MAGIC **Things performed in this notebook:**
# MAGIC 1. Load abs_mapping table and organize columns by PII tag
# MAGIC 2. Apply three-layer cleaning pipeline per PII level (Layer 1: universal string baseline; Layer 2: type correction; Layer 3: business rules)
# MAGIC 3. Write cleaned table to bronze_cleaned catalog
# MAGIC 4. Propagate PII tags from source to target
# MAGIC 5. Propagate table and column comments automatically

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql import functions as f
from pyspark.sql import DataFrame

from leap_utils.common import logger
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger


from utils.bronze_cleaning_pipeline import run_bronze_cleaning_pipeline

# COMMAND ----------

# DBTITLE 1,Pipeline environment widgets
# Environment where this notebook writes its output bronze_cleaned table
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Environment from which bronze tables are read
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# When true, quality check failures are logged as warnings instead of errors
dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# DBTITLE 1,Debug and log-level widgets
dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Source and Target
CATALOG_SOURCE = f"{PIPELINE_READ_ENV}_bronze_hr"
CATALOG_TARGET = f"{PIPELINE_WRITE_ENV}_bronze_cleaned_hr"
SCHEMA = "abs_mapping"

# Allowlist of tables to clean into bronze_cleaned.
TABLES_TO_CLEAN: set[str] = {"abs_mapping_dropdown_latest"}

# Explicit primary key per cleaned table.
PRIMARY_KEYS: dict[str, list[str]] = {
    "abs_mapping_dropdown_latest": ["country",  "system", "field_name", "absence_type_code"],
}

# COMMAND ----------

# DBTITLE 1,Specific configuration
# No type casts needed — all business columns are STRING.
COLUMNS_BOOL: dict[str, list[str]] = {}
COLUMNS_DATE: dict[str, dict[str, str | None]] = {}
COLUMNS_STRING: dict[str, list[str]] = {}
COLUMNS_RENAME: dict[str, dict[str, str]] = {}

# COMMAND ----------

# MAGIC %md
# MAGIC ## Specific Overrides (Layer 3)
# MAGIC
# MAGIC The three-layer cleaning pipeline is centralised in `utils/bronze_cleaning_pipeline.py`. Layers 1 (trim + nullify) and 2 (type correction) are driven by the configuration dicts above.
# MAGIC
# MAGIC **The cell below is the only schema-specific code** — edit `apply_specific_cleaning` to add or change Layer 3 business rules. The function receives:
# MAGIC - `df` — the DataFrame, already trimmed (Layer 1) and typed (Layer 2)
# MAGIC - `table_name` — the table currently being processed
# MAGIC - `pii_cols` — the PII column names in scope
# MAGIC
# MAGIC Use an `if table_name == "..."` guard to target a specific table.

# COMMAND ----------

# no specific override

# COMMAND ----------

# DBTITLE 0,Pipeline Execution – header
# MAGIC %md
# MAGIC # Pipeline Execution

# COMMAND ----------

# DBTITLE 1,Run bronze cleaning pipeline
run_bronze_cleaning_pipeline(
    spark=spark,
    log=log,
    catalog_source=CATALOG_SOURCE,
    catalog_target=CATALOG_TARGET,
    schema=SCHEMA,
    tables_to_clean=TABLES_TO_CLEAN,
    primary_keys=PRIMARY_KEYS,
    columns_to_cast_to_bool=COLUMNS_BOOL,
    columns_to_cast_to_date=COLUMNS_DATE,
    columns_to_cast_to_string=COLUMNS_STRING,
    columns_to_rename=COLUMNS_RENAME,
    apply_specific_cleaning_fn=None
)
