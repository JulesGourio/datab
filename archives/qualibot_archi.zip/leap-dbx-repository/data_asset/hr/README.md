# HR Data Asset - Silver, Gold & Proj Notebooks

This folder contains the data asset notebooks for the **HR (Human Resources)** data domain. Two data domains are processed: **Absenteism (ABS)** and **Workforce Referential (REF)**, each with their own Silver and Gold pipelines.

> **Note:** These notebooks currently run as Databricks Jobs (not yet bundled as a Databricks Asset Bundle). A bundle will be created to integrate them.

## Architecture

```mermaid
flowchart LR
    subgraph BRONZE["Bronze Layer"]
        B1["sd_{env}_bronze.hr<br/>.v_report_rh_leap_latest"]
        B2["sd_{env}_bronze.hr<br/>.t_absenteism_rh_leap_latest"]
    end

    subgraph JOBS["Databricks Jobs"]
        direction TB
        S1["hr_abs_silver"]
        S2["hr_ref_silver"]
        G1["hr_abs_gold"]
        G2["hr_ref_gold_proj"]
        S1 --> G1
        S2 --> G2
    end

    subgraph UC["Unity Catalog Output"]
        SV["Silver Tables"]
        GD["Gold Tables"]
        PJ["Proj Tables"]
    end

    B2 --> S1
    B1 --> S2
    S1 --> SV
    S2 --> SV
    G1 --> GD
    G2 --> GD
    G2 --> PJ

    style B1 fill:#c8e6c9,stroke:#2e7d32,color:#1a1a1a
    style B2 fill:#c8e6c9,stroke:#2e7d32,color:#1a1a1a
    style S1 fill:#fff3e0,stroke:#e65100,color:#1a1a1a
    style S2 fill:#fff3e0,stroke:#e65100,color:#1a1a1a
    style G1 fill:#fce4ec,stroke:#b71c1c,color:#1a1a1a
    style G2 fill:#fce4ec,stroke:#b71c1c,color:#1a1a1a
    style SV fill:#fff3e0,stroke:#e65100,color:#1a1a1a
    style GD fill:#fce4ec,stroke:#b71c1c,color:#1a1a1a
    style PJ fill:#e8eaf6,stroke:#283593,color:#1a1a1a
```

## Workflow

```mermaid
sequenceDiagram
    participant BZ as Bronze (sd_ catalogs)
    participant Job as Databricks Job
    participant TV as Token Vault (PII)
    participant SV as Silver
    participant GD as Gold
    participant PJ as Proj

    Note over BZ,PJ: Domain 1: Absenteism (ABS)
    Job->>BZ: hr_abs_silver: Read t_absenteism_rh_leap_latest
    Note over Job: Clean, normalize countries/workplaces<br/>Cast types, compute calendar dates<br/>GX checks (uniqueness, not null)
    Job->>SV: Write hr_absenteism_silver_latest (overwrite)

    Job->>SV: hr_abs_gold: Read hr_absenteism_silver_latest
    Note over Job: Calculate _leap_absence_rate<br/>GX max value check (<= 1)<br/>Set PK constraint, UC tags
    Job->>GD: Write hr_absenteism_gold_latest (overwrite)

    Note over BZ,PJ: Domain 2: Workforce Referential (REF)
    Job->>BZ: hr_ref_silver: Read v_report_rh_leap_stack
    Note over Job: Cast types, drop columns, trim<br/>Normalize countries/workplaces<br/>Calculate age & seniority categories<br/>Convert Birth_date → year only
    Job->>TV: Hash PII columns (AES encrypt)
    Job->>SV: Write hr_workforce_silver_stack_history (append/overwrite)
    Job->>PJ: Write pii_mapping_table

    Job->>SV: hr_ref_gold_proj: Read silver + token vault
    Note over Job: Gold daily history (tokenized)<br/>Proj monthly history (last extraction/month)<br/>De-tokenize for plain text gold<br/>Email-to-workplace mapping
    Job->>GD: Write hr_workforce_gold_history (tokenized)
    Job->>GD: Write sd_ hr_workforce_gold_history (plain text)
    Job->>PJ: Write hr_workforce_proj_monthly_history
    Job->>PJ: Write hr_workforce_proj_aggregated
    Job->>PJ: Write hr_workforce_proj_email_to_workplace
```

## Data Flow

```mermaid
flowchart TB
    subgraph PIPELINE[" "]
        direction TB

        subgraph BRONZE_INPUT["BRONZE INPUT"]
            b1[("sd_{env}_bronze.hr<br/>.t_absenteism_rh_leap_latest")]
            b2[("sd_{env}_bronze.hr<br/>.v_report_rh_leap_stack")]
        end

        subgraph ABS_SCRIPTS["ABS DOMAIN"]
            sa{{"hr_abs_silver"}}
            ga{{"hr_abs_gold"}}
        end

        subgraph REF_SCRIPTS["REF DOMAIN"]
            sr{{"hr_ref_silver"}}
            gr{{"hr_ref_gold_proj"}}
        end

        subgraph SILVER["SILVER"]
            s1[("hr_absenteism<br/>_silver_latest")]
            s2[("hr_workforce_silver<br/>_stack_history")]
        end

        subgraph GOLD["GOLD"]
            g1[("hr_absenteism<br/>_gold_latest")]
            g2[("hr_workforce<br/>_gold_history")]
            g3[("sd_ hr_workforce<br/>_gold_history<br/>(plain text)")]
        end

        subgraph PROJ["PROJ"]
            p1[("pii_mapping_table")]
            p2[("hr_workforce_proj<br/>_monthly_history")]
            p3[("hr_workforce_proj<br/>_aggregated")]
            p4[("hr_workforce_proj<br/>_email_to_workplace")]
        end

        b1 --> sa
        sa --> s1
        s1 --> ga
        ga --> g1

        b2 --> sr
        sr --> s2
        sr --> p1
        s2 --> gr
        gr --> g2
        gr --> g3
        gr --> p2
        gr --> p3
        gr --> p4
    end

    subgraph REF["PII / CONFIG"]
        tv[("sd_{env}_bronze<br/>.token_vault.pii_data")]
    end

    tv -.-> sr
    tv -.-> gr

    classDef source fill:#fff9c4,stroke:#f57f17,stroke-width:2px,color:#1a1a1a
    classDef script fill:#f3e5f5,stroke:#7b1fa2,stroke-width:2px,color:#1a1a1a
    classDef silver fill:#fff3e0,stroke:#e65100,stroke-width:2px,color:#1a1a1a
    classDef gold fill:#fce4ec,stroke:#b71c1c,stroke-width:2px,color:#1a1a1a
    classDef proj fill:#e8eaf6,stroke:#283593,stroke-width:2px,color:#1a1a1a
    classDef enrichment fill:#c8e6c9,stroke:#2e7d32,stroke-width:1px,color:#1a1a1a
    classDef dataTable fill:#e1f5fe,stroke:#01579b,stroke-width:2px,color:#1a1a1a

    class b1,b2 dataTable
    class sa,ga,sr,gr script
    class s1,s2 silver
    class g1,g2,g3 gold
    class p1,p2,p3,p4 proj
    class tv enrichment
```

**Legend:**
- **Cylinders** `[( )]` = DATA (Tables)
- **Hexagons** `{{ }}` = SCRIPTS (Transformations)
- **Solid arrows** `-->` = Direct pipeline data flow
- **Dashed arrows** `-.->` = Configuration / enrichment data

## Tables Summary

### Input Tables

| Table | Catalog | Description |
|-------|---------|-------------|
| `t_absenteism_rh_leap_latest` | `sd_{env}_bronze.hr` | Deduplicated absenteism data |
| `v_report_rh_leap_stack` | `sd_{env}_bronze.hr` | Full history of workforce referential |
| `v_report_rh_leap_latest` | `sd_{env}_bronze.hr` | Latest workforce referential per User_ID |
| `pii_data` | `sd_{env}_bronze.token_vault` | Token vault for PII encryption/decryption |

### Output Tables

| Table | Catalog | Domain | Description |
|-------|---------|--------|-------------|
| `hr_absenteism_silver_latest` | `{env}_silver.hr` | ABS | Cleaned absenteism with normalized countries/workplaces |
| `hr_absenteism_gold_latest` | `{env}_gold.hr` | ABS | Absenteism with `_leap_absence_rate` |
| `hr_workforce_silver_stack_history` | `{env}_silver.hr` | REF | Daily workforce history (PII tokenized) |
| `pii_mapping_table` | `{env}_proj.hr` | REF | Mapping of encrypted column names |
| `hr_workforce_gold_history` | `{env}_gold.hr` | REF | Gold daily history (PII tokenized) |
| `hr_workforce_gold_history` | `sd_{env}_gold.hr` | REF | Gold daily history (PII plain text, restricted access) |
| `hr_workforce_proj_monthly_history` | `{env}_proj.hr` | REF | Monthly snapshot (last extraction per month) |
| `hr_workforce_proj_aggregated` | `{env}_proj.hr` | REF | Aggregated workforce counts by 14 dimensions |
| `hr_workforce_proj_email_to_workplace` | `{env}_proj.hr` | REF | Email-to-workplace/country mapping (upsert) |
| `hr_workforce_proj_active_mexico_employees` | `{env}_proj.hr` | REF | SQL VIEW: active Mexico employees with manager names |

### Catalog Conventions

| Catalog Pattern | Usage |
|----------------|-------|
| `sd_{env}_landingzone` | Sensitive data landingzone (ingestion) |
| `sd_{env}_bronze` | Sensitive data bronze (PII present) |
| `{env}_silver` | Standard silver (PII tokenized) |
| `{env}_gold` | Standard gold (PII tokenized) |
| `sd_{env}_gold` | Sensitive data gold (PII plain text, restricted) |
| `{env}_proj` | Project/consumption layer |

## Notebooks

### Domain 1: Absenteism (ABS)

#### `hr_abs_silver.py`

Transforms bronze absenteism data into a cleaned silver table.

**Input:** `sd_{env}_bronze.hr.t_absenteism_rh_leap_latest`
**Output:** `{env}_silver.hr.hr_absenteism_silver_latest` (overwrite, clustered by `Year, Month`)
**PK:** `Year, Month, Country, Workplace`
**Write mode:** Always overwrite

**Detailed Transformations:**

| # | Step | Description | Details |
|---|------|-------------|---------|
| 1 | **Add extraction dates** | Derive date columns from `_meta_extraction_timestamp` | `_leap_extraction_date = to_date(_meta_extraction_timestamp)`<br/>`_leap_year_month_extraction_date = date_format(..., "yyyy-MM")` |
| 2 | **Add calendar dates** | Build calendar period from `Year`+`Month` columns | Pad `Month` to 2 digits (`lpad(Month, 2, "0")`)<br/>`_leap_year_month_calendar_date = concat(Year, "-", Month)`<br/>`_leap_calendar_date = last_day(to_date(Year-Month-01))` |
| 3 | **Trim columns** | Remove leading/trailing whitespace | Columns: `Year`, `Month`, `Country`, `Workplace`, `Target_Absenteeism`, `Target_Resignations`, `Target_Leavings` |
| 4 | **Replace nulls by 0** | Ensure numeric columns are never NULL | `fillna("0")` + replace empty strings by `"0"` for `Total_Work_days`, `Total_abs`<br/>Then `regexp_replace(" ", "")` to remove spaces before casting |
| 5 | **Cast integer columns** | Convert string to int | `Total_Work_days`, `Total_abs` → `cast("int")` |
| 6 | **Clean targets & cast to double** | Clean percentage strings and convert | `Target_Absenteeism`, `Target_Resignations`, `Target_Leavings`, `Target_Resignations_All_contracts`<br/>Remove spaces → remove `%` → replace `,` by `.` → `cast("double") / 100` |
| 7 | **Normalize countries** | Standardize country names across languages | 22 translations including:<br/>`Belgique→Belgium`, `FR/Fr→France`, `Allemagne→Germany`, `Espagne/España→Spain`<br/>`Bresil/Brésil→Brazil`, `CZ/Czech/Česká republika→Czech Republic`<br/>`Etat-Unis/United States→USA`, `United Kingdom→UK`, `Maroc/Marocco→Morocco` |
| 8 | **Normalize workplaces** | Standardize workplace names using pattern matching | Uses `lower().contains(pattern)` for fuzzy matching:<br/>`periole/périole→Toulouse-Périole`, `montredon→Toulouse-Montredon`<br/>`gabardie→Toulouse-Gabardie`, `mach1/social→Toulouse-Mach1`<br/>`nazaire→Saint-Nazaire`, `merignac/mérignac→Dassault-Mérignac`<br/>`prague→Praha`, `casablanca/soualem→Had-Soualem`<br/>`belgaum→Belagavi`, `jacareï/jacarei→Jacarei` |
| 9 | **Rebuild `_meta_ID`** | Recompute composite key after normalization | `_meta_ID = concat(_leap_year_month_calendar_date, "-", Country, "-", Workplace)` |
| 10 | **Reorder columns** | Move metadata + PK columns to front | Order: `_meta_stack_row_id`, `_meta_ID`, `_meta_extraction_timestamp`, ..., `Year`, `Month`, `Country`, `Workplace`, then remaining |

**Quality Checks:**
- `gx_check_compound_uniqueness` on `Year, Month, Country, Workplace` (RED — pipeline fails if duplicates)
- `gx_check_not_null` on `Year`, `Month`, `Country`, `Workplace` individually (RED)

#### `hr_abs_gold.py`

Computes the absence rate, sets PK constraint, and applies Unity Catalog governance tags.

**Input:** `{env}_silver.hr.hr_absenteism_silver_latest`
**Output:** `{env}_gold.hr.hr_absenteism_gold_latest` (overwrite, clustered by `Year, Month`)
**PK:** `_meta_ID` (constraint name: `hr_abs_gold_history_pk`, NOT ENFORCED)
**Write mode:** Always overwrite
**Config:** `spark.sql.ansi.enabled = false` (to allow division by zero → NULL)

**Detailed Transformations:**

| # | Step | Description | Details |
|---|------|-------------|---------|
| 1 | **Calculate absence rate** | Compute `_leap_absence_rate` | `_leap_absence_rate = (Total_abs / Total_Work_days).cast("double")`<br/>Replace NULL by 0 (when `Total_Work_days = 0`) |
| 2 | **Reorder columns** | Move metadata + calendar columns to front | Same column ordering as silver + `_leap_year_month_calendar_date`, `_leap_calendar_date` |
| 3 | **Set PK constraint** | Add NOT ENFORCED primary key | Check `system.information_schema.table_constraints` first<br/>Set `_meta_ID` NOT NULL, then `ADD CONSTRAINT hr_abs_gold_history_pk PRIMARY KEY (_meta_ID)` |
| 4 | **Apply UC tags** | Governance tags on table and columns | Table: `HR`, `domain=HR`, `refresh_frequency=daily`, `system.certification_status=certified`, `primary_key_columns=_meta_ID`<br/>Column `_meta_ID`: tag `primary_key`<br/>Table comment: `'HR workforces absenteism by year-month, country, workplace.'` |

**Quality Checks:**
- `gx_check_max_value` on `_leap_absence_rate` <= 1 (RED — absence rate should never exceed 100%)

---

### Domain 2: Workforce Referential (REF)

#### `hr_ref_silver.py`

The most complex notebook in the HR domain. Cleans, normalizes, calculates derived attributes, and tokenizes PII data to produce a daily workforce history.

**Input:** `sd_{env}_bronze.hr.v_report_rh_leap_stack` (filtered by date range based on run mode)
**Output:**
- `{env}_silver.hr.hr_workforce_silver_stack_history` (append or overwrite)
- `{env}_proj.hr.pii_mapping_table` (overwrite — list of encrypted column names)
- `sd_{env}_bronze.token_vault.pii_data` (append — new token vault entries)

**PK:** `User_ID, _leap_extraction_date`
**Cluster columns:** `User_ID, _leap_extraction_date`

**Run Modes:**

| Mode | Table exists? | Write mode | Date range | Source |
|------|:------------:|:----------:|:----------:|--------|
| `delta` | Yes | append | `> latest_extraction_date + 1 day` | `_latest` view |
| `delta` | No | overwrite | Full range | `_stack` table |
| `init_partial` | Yes | append | `init_from` → `init_to` (from widgets) | `_stack` table |
| `init_partial` | No | overwrite | `init_from` → `init_to` (from widgets) | `_stack` table |
| `init_complete` | Any | overwrite | `1970-01-01` → `2099-12-31` | `_stack` table |

**Detailed Transformations:**

| # | Step | Description | Details |
|---|------|-------------|---------|
| 1 | **Delta filtering** | In delta mode, skip already-processed dates | Read existing silver table, find `max(_leap_extraction_date) + 1 day`, filter bronze input to only newer rows. If no new data → set `EMPTY_DATAFRAME_FLAG = True` and skip all processing |
| 2 | **Cast types** | Standardize column types | `float_cols` → `cast("double")`<br/>`string_cols` (`_meta_stack_row_id`) → `cast("string")`<br/>`date_cols` (`Company_Seniority_Date`, `Last_hire_date`, `End_Date`) → `to_date(..., "yyyy-MM-dd")` |
| 3 | **Drop columns** | Remove unwanted columns | Drop `Conv__Category` |
| 4 | **Clean before hashing** | Prepare PII columns for consistent hashing | `trim()` + `lower()` on `User_ID` and `Email` — ensures the same person always produces the same hash regardless of case/whitespace |
| 5 | **Convert date to year** | Anonymize birth date | `Birth_date` → `Birth_date_year = year(Birth_date)` then drop original `Birth_date` — only birth year is kept for age calculation |
| 6 | **Add computed dates** | Derive temporal columns | `_leap_extraction_date = to_date(_meta_extraction_timestamp)`<br/>`_leap_extraction_date_1 = date_sub(_leap_extraction_date, 1)` (previous day)<br/>`_leap_year_month_extraction_date = date_format(..., "yyyy-MM")`<br/>`_leap_year_month_extraction_date_1 = date_format(add_months(..., -1), "yyyy-MM")`<br/>`_leap_year_month_company_seniority_date`, `_leap_year_month_last_hire_date`, `_leap_year_month_end_date` |
| 7 | **Correct invalid status** | Fix ACTIVE employees that should be INACTIVE | Rule 1: If `Status == "ACTIVE"` AND `End_Date < _leap_extraction_date` → set `"INACTIVE"`<br/>Rule 2: If `Status == "ACTIVE"` AND `Last_hire_date > _leap_extraction_date` → set `"INACTIVE"` (contract in the future)<br/>Then filter to keep only `Status IN ("ACTIVE", "INACTIVE")` |
| 8 | **Trim columns** | Remove whitespace | All columns containing `_code` in their name (dynamic detection)<br/>Plus explicit list: `Job`, `Category`, `Company`, `Establishment`, `Workplace`, `Organization`, `Department`, `Service`, `Reason_for_leaving`, `Workplace_country`, `Conventional_category_name`, `Working_day`, `Country`, `Nationality`, `External_company`, `Job_family`, `Job_speciality` |
| 9 | **Replace nulls by "Unknown"** | Standardize missing values | `fillna("Unknown")` + replace empty strings by `"Unknown"` for: `Job`, `Category`, `Company`, `Establishment`, `Workplace`, `Department`, `Service`, `Conventional_category_name`, `Working_day`, `Country`, `Nationality`, `Job_family`, `Job_speciality` |
| 10 | **Normalize countries** | Same 22 country translations as ABS silver | Applied to 3 columns: `Workplace_country`, `Country`, `Country_of_company` |
| 11 | **Normalize workplaces** | Same 16 workplace pattern translations as ABS silver | Applied to 2 columns: `Workplace`, `Establishment` |
| 12 | **Keep latest by extraction date** | Deduplicate per PK | `table_utils.get_latest_version_for_each_id_column(df, ["User_ID", "_leap_extraction_date"], "_meta_extraction_timestamp")` — keeps the row with the most recent `_meta_extraction_timestamp` for each `(User_ID, _leap_extraction_date)` pair |
| 13 | **Calculate age** | Derive age and age category | `_leap_age_as_at = floor(datediff(_leap_extraction_date, Birth_date) / 365)`<br/>Then drop `Birth_date`<br/>`_leap_age_category_as_at`: `< 30` → "30 years and under", `30-44` → "30-45 years", `45-54` → "45-55 years", `≥ 55` → "55 years and over", else → "_Unknown" |
| 14 | **Calculate company seniority** | Derive seniority and seniority category | `_leap_company_seniority_as_at = floor(datediff(_leap_extraction_date, Company_Seniority_Date) / 365)`<br/>`_leap_company_seniority_category_as_at`: `< 1` → "1 year and under", `1-4` → "1-5 years", `5-9` → "5-10 years", `≥ 10` → "10 years and over" |
| 15 | **PII tokenization** | AES-encrypt sensitive columns via token vault | For each of 10 PII columns: (a) find values not yet in token vault, (b) generate random AES key, (c) encrypt: `base64(aes_encrypt(value, key))`, (d) verify no hash collision, (e) append new tokens to vault, (f) destroy key. Then replace original values with hashed values via join |
| 16 | **Reorder columns** | Move metadata + PII columns to front | `_meta_stack_row_id`, `_meta_ID`, timestamps, `User_ID`, `_leap_extraction_date`, `First_name`, `Last_name`, `Email`, `IT_Account`, `ID_Local`, `Maiden_Name`, then remaining columns |

**PII Columns Tokenized (10 columns):**

| Column | Cleaned Before Hash | Description |
|--------|:-------------------:|-------------|
| `User_ID` | Yes (trim+lower) | Employee unique identifier |
| `First_name` | No | First name |
| `Last_name` | No | Last name |
| `Email` | Yes (trim+lower) | Corporate email |
| `IT_Account` | No | IT login account |
| `ID_Local` | No | Local employee ID |
| `Maiden_Name` | No | Maiden name |
| `Business_Phone` | No | Office phone number |
| `Cell_Phone` | No | Mobile phone number |

> **How PII tokenization works:** Each unique value is encrypted with a random AES key. The encrypted value is stored in the token vault (`sd_{env}_bronze.token_vault.pii_data`) alongside the original. The key is immediately destroyed — decryption is only possible by looking up the hashed value in the vault. If a hash collision occurs (extremely rare), the notebook recursively retries with a new random key.

**Quality Checks:**
- `gx_check_compound_uniqueness` on `User_ID, _leap_extraction_date` (RED — pipeline fails)
- `gx_check_not_null` on `User_ID`, `First_name`, `Last_name` individually (RED)
- **Status change surge detection** (D vs D-1): Compares status distribution between latest batch date and previous date in history. If `change_ratio > threshold_pct/100` (or `change_count > threshold` in count mode), raises RED alert. Requires `base_population >= min_population` to trigger. Uses Great Expectations `expect_column_max_to_be_between`.

**Widgets:**

| Widget | Default | Description |
|--------|---------|-------------|
| `PIPELINE_READ_ENV` | `dev` | Read environment |
| `PIPELINE_WRITE_ENV` | `dev` | Write environment |
| `REFERENCE_READ_ENV` | `dev` | Reference environment |
| `silver_run_mode` | `delta` | Run mode: `init_complete`, `init_partial`, `delta` |
| `init_from` | `1970-01-01` | Start date for init modes |
| `init_to` | `2099-12-31` | End date for init modes |
| `force_reinitialization` | `False` | Drop and recreate silver table |
| `status_change_alert_threshold_pct` | `10` | Status change surge threshold (%) |
| `status_change_min_population` | `100` | Min population for surge check |
| `status_change_alert_mode` | `ratio` | Alert mode: `ratio` or `count` |

---

#### `hr_ref_gold_proj.py`

The most business-rule-intensive notebook. Produces 5 output tables: gold daily history (tokenized), gold daily history (plain text), proj monthly history, proj aggregated, and email-to-workplace mapping. Also creates a Mexico-specific view.

**Input:**
- `{env}_silver.hr.hr_workforce_silver_stack_history`
- `sd_{env}_bronze.token_vault.pii_data`

**Output:**
- `{env}_gold.hr.hr_workforce_gold_history` (PII tokenized, append/overwrite)
- `sd_{env}_gold.hr.hr_workforce_gold_history` (PII plain text, restricted access)
- `{env}_proj.hr.hr_workforce_proj_monthly_history` (last extraction per month, overwrite)
- `{env}_proj.hr.hr_workforce_proj_aggregated` (grouped counts, overwrite)
- `{env}_proj.hr.hr_workforce_proj_email_to_workplace` (merge/upsert)
- `{env}_proj.hr.hr_workforce_proj_active_mexico_employees` (SQL view)

**PK (Gold):** `User_ID, _leap_extraction_date` (constraint: `hr_workforce_gold_history_pk`)
**PK (Proj Monthly):** `User_ID, _leap_year_month_extraction_date`
**PK (Email-to-Workplace):** `email` (merge/upsert via `table_utils.merge_into`)

**Run Modes:**

| Mode | Table exists? | Gold write mode | Description |
|------|:------------:|:--------------:|-------------|
| `delta` | Yes | append | Only process rows newer than `max(_leap_extraction_date) + 1 day` in gold |
| `init` / first run | No | overwrite | Full reprocess from silver |

**Detailed Transformations:**

The notebook splits into two parallel paths: **Gold daily** (transformations 10, 13-15) and **Proj monthly** (transformations 1-9, 11-12).

##### Path 1: Proj Monthly History (Transformations 1-9)

| # | Step | Description | Details |
|---|------|-------------|---------|
| 1 | **Monthly snapshot — last extraction** | Keep last extraction of each month per user | Window: `PARTITION BY (User_ID, _leap_year_month_extraction_date) ORDER BY _leap_extraction_date DESC`, keep `row_number = 1`<br/>Drop all `_meta_*` columns except `_meta_stack_row_id` |
| 2 | **Monthly snapshot — first extraction of next month** | Calculate a reference dataset from month N+1 | Window: `PARTITION BY (User_ID, _leap_year_month_extraction_date) ORDER BY _leap_extraction_date ASC`, keep `row_number = 1`<br/>Add `_leap_year_month_extraction_date_N_1 = add_months(..., -1)`<br/>Prefix all columns with `_tmp_` for safe join |
| 3 | **Calculate reference dates** | Temporal anchor for status rules | `_leap_reference_date`: if current month → `current_date()`, otherwise → `last_day(_leap_extraction_date)`<br/>`_leap_reference_date_1 = last_day(add_months(_leap_reference_date, -1))` |
| 4 | **Enrich End_Date / Reason_for_leaving** | Use next month's data to complete missing info | Left join last-of-month-N with first-of-month-N+1 on `(User_ID, year_month = year_month_N_1)`<br/>`End_Date = COALESCE(_tmp_End_Date, End_Date)` — prefer next month's value<br/>`Reason_for_leaving = COALESCE(_tmp_Reason_for_leaving, Reason_for_leaving)` |
| 5 | **Detect new hires with retro-dated contracts** | Identify employees appearing in month N+1 with `Last_hire_date` in month N | Left-anti join: employees in first-of-N+1 but NOT in last-of-N, where `_leap_year_month_last_hire_date == _leap_year_month_extraction_date_N_1` and extraction is on the 1st of the month<br/>Append these "retroactive new hires" to month N's dataset with adjusted dates |
| 6 | **Detect new contracts for existing employees** | Capture contract changes detected at beginning of next month | Left join: same-user, same-month, but `_leap_year_month_last_hire_date` differs between N and N+1<br/>Update `Status`, `Contract_Type`, `Last_hire_date`, `End_Date`, `Job`, `Category`, `Reason_for_leaving`, `Payroll_category`, `External_company`, `Conventional_category_name` from next month's first extraction |
| 7 | **Recalculate ACTIVE/INACTIVE status** | Business rules based on reference date | ACTIVE: `End_Date IS NULL` OR `End_Date >= _leap_reference_date`<br/>INACTIVE: `End_Date < _leap_reference_date` OR `Last_hire_date IS NULL` OR `Last_hire_date > _leap_reference_date` |
| 8 | **Filter contract types** | Keep only relevant contract types | Include: `CDI`, `CDD`, `INT`, `APR`, `PR`, `SIVP`, `ANA`, `SST`, `Permanent contract`, `Fixed-term contract`, `CDD ANAPEC`, `Fixed-term professionnal contract`, `Permanent professionnal contract`, `Stage SIVP`, `Apprentice`, `Interim contrat`, `Temporary worker`, `Subcontractor` |
| 9 | **Categorize contract types** | Map raw types to 4 categories | `_leap_contract_type_category`:<br/>`CDI` → "Permanent contract"<br/>`CDD, APR, PR, SIVP, ANA, CDD ANAPEC, Fixed-term*, Apprentice` → "Fixed-term contract"<br/>`INT, Interim contrat` → "Temporary worker"<br/>`SST` → "Subcontractor" |
| 10 | **Categorize workplaces (North America)** | Resolve ambiguous workplace names by Company_Code | `_leap_workplace_category`:<br/>`LDM + Hermosillo` → "Hermosillo A"<br/>`LDM + HERMOSILLO F` → "Hermosillo D"<br/>`LMXC + Hermosillo` → "Hermosillo C"<br/>`LEM + Hermosillo` → "Hermosillo I"<br/>`INC` → "Mountain Lake Terrace"<br/>`LIUS + Los Angeles` → "Los Alamitos"<br/>`LIUS + Seattle` → "Redmond"<br/>Otherwise → `Workplace` as-is |
| 11 | **Contract lifecycle flags** | Track contract start/end/change events | `_leap_is_start_of_contract`: `True` when `_leap_year_month_last_hire_date == _leap_year_month_extraction_date`<br/>`_leap_is_end_of_contract`: `True` when (`year_month_end_date == year_month_extraction_date` AND `Status == "INACTIVE"`) OR (`End_Date == last day of previous month`)<br/>`_leap_is_end_of_contract_in_the_past`: `True` when end date detected retroactively (end_date < previous month's reference date, previous month was still ACTIVE)<br/>`_leap_is_change_of_contract`: `True` when `_leap_contract_type_category` differs from previous month (via `lag()` window) |
| 12 | **FK to absenteism table** | Create foreign key for joining with ABS domain | `_meta_ABSENTEISM_FK_ID = concat(_leap_year_month_extraction_date, "-", Workplace_country, "-", _leap_workplace_category)` — matches ABS gold `_meta_ID` |
| 13 | **Aggregated data** | Group by for reporting | `GROUP BY` on 14 columns: `_leap_year_month_extraction_date`, `Status`, `Cost_Center`, `Direction`, `Direction_code`, `Country_of_company`, `Workplace_country`, `_leap_workplace_category`, `_leap_contract_type_category`, `Category`, `Int_Ext`, `_leap_is_start_of_contract`, `_leap_is_end_of_contract`, `Organization`, `Organization_code`<br/>Count employees per group → `hr_workforce_proj_aggregated` (includes Subcontractors) |
| 14 | **Filter Subcontractors** | Remove SST from detailed proj monthly | After aggregation, filter out `_leap_contract_type_category != "Subcontractor"` from the detailed monthly table (SST employees only appear in aggregated view) |
| 15 | **Drop temporary columns** | Clean up computation artifacts | Drop: `_leap_previous_is_end_of_contract`, `_leap_previous_status`, `_leap_previous_is_end_of_contract_in_the_past`, `_leap_previous_contract_type_category`, `_leap_reference_date`, `_leap_reference_date_1`, plus `columns_to_drop` from SILVER_ATTRS_DICT |

##### Path 2: Gold Daily + Plain Text + Outputs (Transformations 10, 13-15)

| # | Step | Description | Details |
|---|------|-------------|---------|
| 10 | **Gold daily history** | Drop extra columns from silver, reorder | Drop `_leap_extraction_date_1`, `_leap_year_month_extraction_date_1` and `columns_to_drop` from silver<br/>Reorder columns with metadata first |
| 13 | **Plain text gold** | De-tokenize all PII columns | Load token vault, then for each of 10 hashed columns: join on `HashedValue` to recover `OriginalValue`<br/>Keep only metadata + PII columns (subset of gold daily)<br/>Write to `sd_{env}_gold.hr.hr_workforce_gold_history` (restricted access catalog) |
| 14 | **Email-to-workplace mapping** | Latest email → country/workplace per employee | Window: `PARTITION BY Email ORDER BY _leap_extraction_date DESC`, keep `row_number = 1`, filter `Email IS NOT NULL`<br/>Decrypt `Email` column only, select `(date_end, email, country, workplace)`<br/>Write via `table_utils.merge_into` (upsert on email) |
| 15 | **Mexico view** | SQL view for active Mexico employees | `CREATE OR REPLACE VIEW hr_workforce_proj_active_mexico_employees`<br/>Joins plain text gold (sd_ catalog) with tokenized gold to resolve manager names<br/>Filters: `Workplace_Country = 'MEXICO'` AND `Status = 'ACTIVE'`<br/>Columns: `user_id`, `first_name`, `last_name`, `manager_id`, `manager_first_name`, `manager_last_name` |

**Quality Checks:**
- `gx_expect_compound_columns_to_be_unique` on `(_leap_extraction_date, User_ID)` in gold plain text (RED)
- `gx_expect_column_values_to_be_unique` on `email` in email-to-workplace (RED)
- Status change surge detection (D vs D-1) — same logic as silver, applied at gold level

**Unity Catalog Tags (applied to all output tables):**

| Table | Tags |
|-------|------|
| `hr_workforce_gold_history` | `HR`, `domain=HR`, `refresh_frequency=daily`, `system.certification_status=certified`<br/>Column tags: `class.name` on User_ID/First_name/Last_name/IT_Account/ID_Local/Maiden_Name/ID_Manager/ID_HR_Manager<br/>`class.email_address` on Email, `class.phone_number` on Business_Phone/Cell_Phone |
| `sd_ hr_workforce_gold_history` | Same as above (plain text copy) |
| `hr_workforce_proj_monthly_history` | Same table + column tags |
| `hr_workforce_proj_aggregated` | `HR`, `domain=HR`, all groupby columns tagged `primary_key` |
| `hr_workforce_proj_email_to_workplace` | `HR`, `domain=HR`, email tagged `primary_key` + `class.email_address` |

**Widgets:**

| Widget | Default | Description |
|--------|---------|-------------|
| `PIPELINE_READ_ENV` | `dev` | Read environment |
| `PIPELINE_WRITE_ENV` | `dev` | Write environment |
| `REFERENCE_READ_ENV` | `dev` | Reference environment |
| `gold_run_mode` | `delta` | Run mode: `init`, `delta` |
| `status_change_alert_threshold_pct` | `10` | Status change surge threshold |
| `status_change_min_population` | `100` | Min population for surge check |
| `status_change_alert_mode` | `ratio` | Alert mode: `ratio` or `count` |

## LEAP Modules Used

```python
from leap_utils.table import table_utils        # Table operations, save_table, create_table_view
from leap_utils.quality import gx_validation     # Great Expectations checks
from leap_utils.log import log                   # Structured logging
import great_expectations as gx                  # Direct GX for custom checks
```

## Troubleshooting

### Common Issues

1. **PII tokenization failure — "hashed value already exists"**
   - **Cause:** Hash collision in AES encryption (extremely rare)
   - **Fix:** The notebook auto-retries with a new random key

2. **Silver quality check failure (compound uniqueness)**
   - **Cause:** Duplicate `(User_ID, _leap_extraction_date)` pairs in source
   - **Fix:** Check if multiple extractions happened on the same date; dedup logic should handle it

3. **Status change surge alert (RED)**
   - **Cause:** More than threshold % of employees changed status between D and D-1
   - **Fix:** Verify with HR if a mass status change is expected (e.g., year-end process)

4. **Gold plain text table not updated**
   - **Cause:** Token vault missing entries for some hashed values
   - **Fix:** Re-run silver to ensure token vault is complete

5. **Empty delta update (0 rows)**
   - **Cause:** No new data since last gold extraction date
   - **Fix:** Normal behavior — check if new source files were ingested in bronze

6. **Missing `sd_` catalog tables**
   - **Cause:** Service principal doesn't have access to `sd_{env}_gold` catalog
   - **Fix:** Request access through admin for sensitive data catalogs

### Useful Queries

```sql
-- Silver: absenteism latest
SELECT Year, Month, Country, Workplace, Total_Work_days, Total_abs, _leap_absence_rate
FROM {env}_gold.hr.hr_absenteism_gold_latest
ORDER BY Year DESC, Month DESC;

-- Silver: workforce history row counts per extraction date
SELECT _leap_extraction_date, count(*) as employees
FROM {env}_silver.hr.hr_workforce_silver_stack_history
GROUP BY 1
ORDER BY 1 DESC
LIMIT 30;

-- Gold: workforce latest per user (tokenized)
SELECT User_ID, Status, _leap_extraction_date, _leap_age_category_as_at, _leap_company_seniority_category_as_at
FROM {env}_gold.hr.hr_workforce_gold_history
WHERE _leap_extraction_date = (SELECT MAX(_leap_extraction_date) FROM {env}_gold.hr.hr_workforce_gold_history)
LIMIT 100;

-- Proj: monthly history counts
SELECT _leap_year_month_extraction_date, count(*) as employees
FROM {env}_proj.hr.hr_workforce_proj_monthly_history
GROUP BY 1
ORDER BY 1 DESC;

-- Token vault: check PII encryption
SELECT count(*) as total_tokens
FROM sd_{env}_bronze.token_vault.pii_data;

-- PII mapping: which columns are encrypted
SELECT * FROM {env}_proj.hr.pii_mapping_table;
```

## Folder Structure

```
data_asset/hr/
├── hr_abs_silver.py        # ABS domain: bronze → silver (clean, normalize, cast)
├── hr_abs_gold.py          # ABS domain: silver → gold (absence rate, PK, UC tags)
├── hr_ref_silver.py        # REF domain: bronze → silver (clean, tokenize PII, historize)
├── hr_ref_gold_proj.py     # REF domain: silver → gold + proj (daily/monthly history, de-tokenize)
└── README.md
```

## Related Documentation

- **Ingestion Notebooks:** `ingestion/hr/README.md` (S3 → landingzone → bronze)
- **LEAP Table Utils:** `leap_utils/table/table_utils.py`
- **GX Validation:** `leap_utils/quality/gx_validation.py`
- **Token Vault:** `sd_{env}_bronze.token_vault.pii_data` (AES encryption for PII)
