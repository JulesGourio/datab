# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Silver HR Absences — Senior
# MAGIC %md
# MAGIC ## Silver HR Absences — Senior
# MAGIC
# MAGIC Autonomous notebook: reads Senior (Brazilian payroll) absences from bronze cleaned, maps to unified silver schema,
# MAGIC and writes to `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` with `REPLACE WHERE source = 'SENIOR'`.
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | Senior absences | `{pipeline_read_env}_bronze_cleaned_hr` | `senior` | `r038afa_latest` |
# MAGIC | Senior employees | `{pipeline_read_env}_bronze_cleaned_hr` | `senior` | `r034fun_latest` |
# MAGIC | Senior sit. ref | `{pipeline_read_env}_bronze_cleaned_hr` | `senior` | `r010sit_latest` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_silver_hr.absenteism.fact_absence_day` (column `source = 'SENIOR'`)
# MAGIC
# MAGIC **Filter**: Valid records only (`_meta_validity_check = true`, currently always true — defensive guard). Excludes null `sitafa`. Inner join with `r010sit_latest` to resolve the absence type label — `conabs` not filtered (all 134 types have `conabs = 1` in Senior, meaning unverified). **Dismissals** (`sitafa = 7`) with sentinel `datter = 1900-12-31` are excluded (not real absenteeism). Other sentinel cases (ongoing sick leave) use `datafa` as single-day fallback to avoid exploding millions of backward rows.
# MAGIC
# MAGIC **id_group**: resolved via left join with `r034fun_latest` on `(numcad, numemp)` — `usu_idglob` (group-wide matricule, custom field) joins `immat.user_id` at 78.7% for employees with absences. `codidn` is unused (all zeros in current data). `numcad` alone is a local Brazilian matricule (~52% match only).
# MAGIC
# MAGIC **Note**: Senior provides episode-based absences (datafa → datter). Each episode is exploded to one row per calendar day. Filtering to actual working days is the responsibility of the absenteeism KPI layer, driven by dim_calendar. `absence_duration_min`: `horter - horafa` when both non-zero, else defaults to 480 min (8h). `absence_day_value` heuristic: ≥ 300 min (5h) → 1.0, else 0.5.

# COMMAND ----------

# DBTITLE 1,Config
from pyspark.sql import functions as f, Window

from data_asset.hr.utils.table_schema_map_utils import load_config
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# --- Source ---
BRONZE_CLEANED_CATALOG  = f"{PIPELINE_READ_ENV}_bronze_cleaned_hr"
SENIOR_SCHEMA           = "senior"
SENIOR_ABSENCES_TABLE   = "r038afa_latest"  # one row per absence episode (start → end date) — source of all absence records
SENIOR_SIT_REF_TABLE    = "r010sit_latest"  # absence type reference — maps absence type code (sitafa) to a human-readable label
SENIOR_EMP_TABLE        = "r034fun_latest"  # employee master — maps (numcad, numemp) to usu_idglob, the group-wide employee ID

ABSENCE_DAY_THRESHOLD_MIN = 300  # >= 5h = 1 day, < 5h = 0.5 day (to evolve with dim_calendar)

config            = load_config(config_path="config/silver_abs_column_mapping.yaml")
_target           = config["target"]
SILVER_CATALOG    = f"{PIPELINE_WRITE_ENV}_silver_hr"
SILVER_SCHEMA     = _target["schema"]
SILVER_TABLE      = _target["table"]
SOURCE            = "SENIOR"

SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# Derive MIN_ABSENCE_DATE from immat coverage start (absences before immat cannot be enriched)
_immat_table = f"{PIPELINE_READ_ENV}_gold_hr.immat.immat_monthly_history"
_min_immat_month = spark.sql(f"SELECT MIN(year_month) FROM {_immat_table}").collect()[0][0]
MIN_ABSENCE_DATE = f"{_min_immat_month}-01"
log.info(f"[{SOURCE}] MIN_ABSENCE_DATE = {MIN_ABSENCE_DATE} (immat coverage floor)")

# COMMAND ----------

# DBTITLE 1,Non-PII Cleaning
# MAGIC %md
# MAGIC ### Non-PII Cleaning
# MAGIC Applied by `clean_non_pii` after column mapping:
# MAGIC 1. Trim all string columns and nullify empty strings
# MAGIC 2. Drop rows where any mandatory column (YAML contract) is null

# COMMAND ----------

# DBTITLE 1,read_senior_absences
def read_senior_absences():
    """
    Read and map Senior (Brazilian payroll) absence records to the silver schema.

    Source filter: _meta_validity_check = True (currently always true in Senior — kept as a defensive guard)
    and sitafa IS NOT NULL.
    Inner join with r010sit_latest resolves absence_type_desc from the reference label.
    All 134 absence types in Senior currently have conabs = 1 — no filtering applied on conabs.
    Fallback: absence_type_desc falls back to sitafa code when dessit is null.

    Left join with r034fun_latest on (numcad, numemp) to resolve id_group from usu_idglob
    (the group-wide employee identifier, joins immat.user_id — 78.7% match on employees with absences).
    Rows with no match in employee master are dropped by clean_non_pii (id_group mandatory).

    Episodes (datafa to datter) are exploded to one row per calendar day.
    Filtering to actual working days is left to the absenteeism KPI layer, driven by dim_calendar.

    Sentinel handling (datter = 1900-12-31):
    - sitafa=7 (Demitido / dismissal): excluded entirely — not real absenteeism.
    - Other motifs (ongoing sick leave, judicial pension): datter replaced by datafa (single-day fallback).
      When Senior fills the real end date, the next pipeline run will explode the full period correctly.

    absence_duration_min: horter - horafa when both non-zero, else defaults to 480 min (8h).
    absence_day_value heuristic: duration >= ABSENCE_DAY_THRESHOLD_MIN (300 min = 5h) -> 1.0, else 0.5.
    dropDuplicates() after select removes Airbyte double-ingestion duplicates (~246 episodes
    affected in _latest — same BK, different _airbyte_raw_id). Placed after select so only
    silver columns are compared, before day_order assignment to avoid inflating counts.
    """
    df  = spark.table(f"{BRONZE_CLEANED_CATALOG}.{SENIOR_SCHEMA}.{SENIOR_ABSENCES_TABLE}")
    emp = (
        spark.table(f"{BRONZE_CLEANED_CATALOG}.{SENIOR_SCHEMA}.{SENIOR_EMP_TABLE}")
        .select(
            f.col("numcad").alias("_emp_numcad"),  # numcad: employee number within this legal entity — restarts at each entity, so not unique across the group
            f.col("numemp").alias("_emp_numemp"),  # numemp: "número da empresa" (Portuguese) = legal entity code, NOT an employee number despite the abbreviation
            f.col("usu_idglob").alias("id_group"),  # usu_idglob: group-wide employee ID (already STRING in bronze_cleaned, joins immat.user_id)
        )
    )
    ref = (
        spark.table(f"{BRONZE_CLEANED_CATALOG}.{SENIOR_SCHEMA}.{SENIOR_SIT_REF_TABLE}")
        .select(
            f.col("codsit").alias("_ref_codsit"),        # codsit: absence type code — primary key of this reference table, masked because it is health data (GDPR art.9)
            f.col("dessit").alias("absence_type_desc"),  # dessit: human-readable label for the absence type
        )
    )
    # --- Sentinel handling for datter = 1900-12-31 ---
    # Senior uses 1900-12-31 as a sentinel when the absence end date is unknown.
    # 97% of these are sitafa=7 (Demitido / dismissal) — not real absenteeism, excluded.
    # Remaining (ongoing sick leave, judicial pension) → treated as single-day absence (datter = datafa).
    _DATTER_SENTINEL = f.to_date(f.lit("1900-12-31"))
    _SITAFA_DEMITIDO = 7

    df_joined = (
        df.filter(
            (f.col("_meta_validity_check") == True) &
            (f.col("sitafa").isNotNull()) &  # sitafa: absence type recorded on this leave — links to r010sit for the label (health data, GDPR art.9)
            (f.col("datafa") >= MIN_ABSENCE_DATE) &  # limit to recent data — configurable via widget
            ~((f.to_date("datter") == _DATTER_SENTINEL) & (f.col("sitafa") == _SITAFA_DEMITIDO))  # exclude dismissals with no end date
        )
        .join(ref, df.sitafa == ref._ref_codsit, "inner")
        .join(emp, (df.numcad == emp._emp_numcad) & (df.numemp == emp._emp_numemp), "left")
        .withColumn(
            # non-dismissal sentinels (ongoing sick leave etc.) → single-day fallback
            "_datter_safe", f.when(f.to_date("datter") == _DATTER_SENTINEL, f.to_date("datafa"))
                            .otherwise(f.to_date("datter"))
        )
        .withColumns({
            # datafa: absence start date, _datter_safe: corrected end date — each episode becomes one row per calendar day
            "absence_date": f.explode(f.sequence(f.to_date("datafa"), f.col("_datter_safe"))),
            # horafa/horter: start/end time in minutes since midnight (e.g. 490 = 8h10, 670 = 11h10)
            "duration_min": f.when((f.col("horter") > f.col("horafa")) & (f.col("horafa") > 0),
                                   f.col("horter") - f.col("horafa"))
                            .otherwise(f.lit(480))
                            .cast("long"),
        })
        .drop("_datter_safe")
    )
    return (
        df_joined.select(
            f.col("id_group"),
            f.col("absence_date"),
            f.col("sitafa").cast("string").alias("absence_type_code"),
            # Business rule: no label in ref table -> fall back to the code itself
            f.coalesce(f.col("absence_type_desc"), f.col("sitafa").cast("string")).alias("absence_type_desc"),
            f.col("duration_min").alias("absence_duration_min"),
            f.when(f.col("duration_min") >= ABSENCE_DAY_THRESHOLD_MIN, 1.0)
            .otherwise(0.5).alias("absence_day_value"),
        )
        .dropDuplicates()  # removes Airbyte double-ingestion (same silver cols, different _airbyte_raw_id)
        .withColumn("day_order", f.row_number().over(
            Window.partitionBy("id_group", "absence_date").orderBy("absence_type_code")
        ))
        .withColumn("source", f.lit(SOURCE))
    )

# COMMAND ----------

# DBTITLE 1,Input data
# bronze -> silver mapping — selects and renames to fixed 8-col silver schema, lazy
df_raw = read_senior_absences()

if LOG_LEVEL == "debug":
    count_raw = df_raw.count()
    log.debug(f"[{SOURCE}] {count_raw:,} rows after read + mapping")

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
def _build_extra_red_results(df_gx: SparkDFDataset) -> list[ExpectationSuiteValidationResult]:
    return [
        # absence_duration_min >= 0 and <= 1440 (no single-day absence > 24h)
        df_gx.expect_column_values_to_be_between(
            column="absence_duration_min", min_value=0, max_value=1440,
        ),
        # absence_day_value in [0, 1]
        df_gx.expect_column_values_to_be_between(
            column="absence_day_value", min_value=0, max_value=1, mostly=1.0,
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_raw,
    config=config,
    full_table_path=SILVER_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=True,
    drop_null_pk_rows=True,
    cluster_cols="source, id_group",
    replace_where=f"source = '{SOURCE}'",
    is_debug=LOG_LEVEL == "debug",
)
