# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # HR IMMAT GOLD — monthly history + full latest (from the SCD2 silver history)
# MAGIC
# MAGIC **Description:**
# MAGIC Build the GOLD data assets for the IMMAT HR referential from the SCD2 silver history:
# MAGIC
# MAGIC 1. **`immat_monthly_history`** — one row per `user_id` per `year_month` for the **employed
# MAGIC    population** of the month (so monthly absenteeism can be confronted with the IMMAT state of
# MAGIC    the same month). A departed user still appears on their **departure month** (ACTIVE if they
# MAGIC    left on the last calendar day, INACTIVE if mid-month) then disappears the next month.
# MAGIC    Computed **incrementally**: on a scheduled run the target month (widget, default = current
# MAGIC    month) AND the **previous** month are (re)processed — the previous month is reprocessed to
# MAGIC    catch departures recorded late, after the month closed. On an explicit month / **native
# MAGIC    Databricks backfill** run (`snapshot_month` = `{{backfill.iso_date}}`) ONLY that month is
# MAGIC    processed and written via a `replaceWhere` scoped to it. The table is liquid-clustered
# MAGIC    (not partitioned), so concurrent backfill runs may hit a transient Delta
# MAGIC    ConcurrentAppendException — the F_3b backfill job absorbs it with task retries (each
# MAGIC    per-month write is idempotent). `immat_full_latest` (Part 2) is skipped on a backfill run.
# MAGIC    It also exposes, per month, the **intra-month change date** of a few attributes
# MAGIC    (`workplace_country_change_date`, `contract_type_change_date`, `job_family_change_date` —
# MAGIC    null if unchanged that month), pre-computed from the silver SCD2 so downstream consumers
# MAGIC    (absenteeism: rules & holidays vary by country) get the exact in-month change date without
# MAGIC    reading the SCD2 themselves. See `CHANGE_DATE_ATTRS` for the semantics and caveats.
# MAGIC
# MAGIC 2. **`immat_full_latest`** — one row per `user_id` = the **latest known state of everyone**
# MAGIC    (active AND departed), with the status evaluated as-of today. Full rebuild each run. This is
# MAGIC    the complete current referential; the complete referential *at any past date* remains
# MAGIC    reconstructable from the silver SCD2 directly.
# MAGIC
# MAGIC **The business problem solved — late-recorded departures.**
# MAGIC In the SCD2, a departure (`end_date`) is sometimes recorded *after* it happened, on a version
# MAGIC that only starts later. Example: `end_date = 7 May` recorded on `24 June` → the version
# MAGIC carrying it starts `24 June`, so the "as-at 31 May" view falls back on the *previous* (ACTIVE)
# MAGIC version and the person wrongly looks present at 31 May.
# MAGIC
# MAGIC We reproduce the LEAP HR referential rule (`data_asset/hr/hr_ref_gold_proj.py`, Transfo 1 + 4)
# MAGIC transposed to SCD2:
# MAGIC - **reference date** of month M = `last_day(M)`, or `current_date()` for the current month.
# MAGIC - **as-at version** = the SCD2 row valid at the reference date: `Start_Validity <= ref <
# MAGIC   End_Validity` (End_Validity is the exclusive start of the next interval).
# MAGIC - **effective_end_date** = the `end_date` of the earliest version STARTING AFTER the as-at one
# MAGIC   whose `end_date <= reference_date` (the late-recorded departure), else the as-at `end_date`.
# MAGIC - **status** = INACTIVE if `last_hire_date` is null or after the reference date (contract not
# MAGIC   started — also handles rehires), or if `effective_end_date < reference_date` (left before
# MAGIC   month-end); else ACTIVE. Leaving on the last calendar day counts as ACTIVE for that month.
# MAGIC
# MAGIC No "latest version" heuristic is needed for the monthly grain: rehires are handled by
# MAGIC `last_hire_date` read as-at, late departures by the forward look.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver_hr.immat.immat_data_history_change_log
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold_hr.immat.immat_monthly_history
# MAGIC - {pipeline_write_env}_gold_hr.immat.immat_full_latest
# MAGIC
# MAGIC **No PII hashing / no token vault** — PII confidentiality relies on ABAC dynamic masking via
# MAGIC the `abac_hr_pii*` tags, propagated onto the gold tables by the dedicated tag-propagation step.

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. Lot 2 columns (previous_status / is_change_of_contract — lag over months) not yet added.
# MAGIC     2. N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import re
import time
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.validation import gx_validation
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Target month for immat_monthly_history. Empty = current month (scheduled run).
# Accepts either "yyyy-MM" (manual run) OR a full ISO date "yyyy-MM-dd": the Databricks NATIVE
# BACKFILL passes {{backfill.iso_date}} (= yyyy-MM-dd), normalized here to its month.
#  - scheduled/current run (empty)   : (re)process the target month AND the previous one, and
#                                       rebuild the as-of-today immat_full_latest.
#  - explicit month / native backfill: process ONLY that month (disjoint replaceWhere → backfill
#                                       runs are safe to parallelize) and SKIP immat_full_latest.
dbutils.widgets.text("snapshot_month", "")
_snapshot_month_raw = dbutils.widgets.get("snapshot_month").strip()
# Ignore an unresolved template such as "{{backfill.iso_date}}" (not a backfill run) -> current month.
if "{{" in _snapshot_month_raw:
    _snapshot_month_raw = ""
# Accept yyyy-MM or yyyy-MM-dd; normalize to the month yyyy-MM. Reject anything else.
if _snapshot_month_raw:
    _m = re.match(r"^(\d{4}-\d{2})(-\d{2})?$", _snapshot_month_raw)
    if not _m:
        raise ValueError(
            f"snapshot_month must be 'yyyy-MM' or 'yyyy-MM-dd', got '{_snapshot_month_raw}'"
        )
    SNAPSHOT_MONTH = _m.group(1)
else:
    SNAPSHOT_MONTH = ""

# Reinitialize the GOLD monthly table: when "true", DROP immat_monthly_history then CONTINUE the
# run normally — the table is recreated (clean, current schema) and this run rebuilds its month(s).
# Use after a schema/logic change to clear stale columns/rows instead of relying on schema-merge.
# Run as a SINGLE, non-backfill run (a parallel backfill would drop concurrently); backfill the rest
# of the history with F_3b afterwards. immat_full_latest is not dropped.
dbutils.widgets.text("reinit_gold", "false")
REINIT_GOLD = dbutils.widgets.get("reinit_gold").strip().lower() == "true"

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------


def move_dataframe_cols_first(df: SparkDataFrame, cols_to_move: list) -> SparkDataFrame:
    """Move the specified columns (that exist) to the front of the DataFrame."""
    first_cols = [c for c in cols_to_move if c in df.columns]
    other_cols = [c for c in df.columns if c not in first_cols]
    return df.select(*first_cols, *other_cols)


def parse_column_comment(column_ddl: str) -> str | None:
    """Extract the comment from a FIRST_COLS DDL fragment such as
    "STRING COMMENT 'my comment'". Returns None when there is no COMMENT clause;
    un-escapes the doubled single quotes ('' -> ')."""
    match = re.search(r"COMMENT\s+'(.*)'\s*$", column_ddl, flags=re.DOTALL)
    return match.group(1).replace("''", "'") if match else None


def attach_column_comments(df: SparkDataFrame, comments: dict) -> SparkDataFrame:
    """Re-attach column comments onto the DataFrame schema metadata so save_table persists them.
    Column comments live in StructField.metadata['comment'] and are DROPPED whenever a column is
    rebuilt by a transform (cast / withColumn / rename), so they must be re-applied before the write —
    this makes the comments 'follow' the column across layers without relying on UC lineage.
    Only columns present in df and carrying a non-empty comment are touched."""
    for col_name, comment in comments.items():
        if comment and col_name in df.columns:
            df = df.withMetadata(col_name, {"comment": comment})
    return df


# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location

# COMMAND ----------

SILVER_CATALOG = f"{PIPELINE_READ_ENV}_silver_hr"
SILVER_SCHEMA = "immat"
IMMAT_SILVER_TABLE = (
    f"{SILVER_CATALOG}.{SILVER_SCHEMA}.immat_data_history_change_log"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location

# COMMAND ----------

GOLD_CATALOG = f"{PIPELINE_WRITE_ENV}_gold_hr"
GOLD_SCHEMA = "immat"

IMMAT_MONTHLY_HISTORY_TABLE = (
    f"{GOLD_CATALOG}.{GOLD_SCHEMA}.immat_monthly_history"
)
IMMAT_FULL_LATEST_TABLE = f"{GOLD_CATALOG}.{GOLD_SCHEMA}.immat_full_latest"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings

# COMMAND ----------

# ---- immat_monthly_history (grain: user_id + year_month) ----
TABLE_MONTHLY_FIRST_COLS = {
    "user_id": "STRING COMMENT 'Identifiant collaborateur (clé métier)'",
    "year_month": "STRING COMMENT 'Mois du snapshot (yyyy-MM) — grain de la table avec user_id'",
    "reference_date": "DATE COMMENT 'Date-photo du mois : dernier jour du mois, ou aujourd''hui pour le mois courant'",
    "status": "STRING COMMENT 'Statut métier CORRIGÉ du mois (ACTIVE/INACTIVE), départs rétroactifs pris en compte'",
    "is_active": "BOOLEAN COMMENT 'True si status = ACTIVE'",
    "effective_end_date": "DATE COMMENT 'Date de fin de contrat effective connue pour ce mois (départ rétroactif inclus)'",
    "is_late_recorded_departure": "BOOLEAN COMMENT 'True si la fin de contrat de ce mois a été enregistrée sur une version SCD2 ultérieure (saisie en retard)'",
    "is_start_of_contract": "BOOLEAN COMMENT 'True si last_hire_date tombe dans ce mois (embauche/ré-embauche)'",
    "is_end_of_contract": "BOOLEAN COMMENT 'True si effective_end_date tombe dans ce mois (fin de contrat)'",
    "workplace_country_change_date": "DATE COMMENT 'Date (dans le mois) du dernier changement de workplace_country ; null si pas de changement ce mois-ci. Valeur avant changement = ligne du mois précédent'",
    "contract_type_change_date": "DATE COMMENT 'Date (dans le mois) du dernier changement de contract_type ; null si pas de changement ce mois-ci. Valeur avant changement = ligne du mois précédent'",
    "job_family_change_date": "DATE COMMENT 'Date (dans le mois) du dernier changement de job_family ; null si pas de changement ce mois-ci. Valeur avant changement = ligne du mois précédent'",
    "contract_type_category": "STRING COMMENT 'Catégorie métier dérivée de contract_type (Permanent contract / Fixed-term contract / Temporary worker / Subcontractor), mêmes règles que hr_ref_gold_proj ; contract_type inchangé sinon'",
    "age_as_at": "INT COMMENT 'Âge (années révolues) à la reference_date, depuis birth_date — même calcul que hr_ref_silver _leap_age_as_at'",
    "age_category_as_at": "STRING COMMENT 'Tranche d''âge à la reference_date (30 years and under / 30-45 years / 45-55 years / 55 years and over / _Unknown), comme _leap_age_category_as_at'",
    "company_seniority_as_at": "INT COMMENT 'Ancienneté entreprise (années) à la reference_date, depuis company_seniority_date — comme _leap_company_seniority_as_at'",
    "company_seniority_category_as_at": "STRING COMMENT 'Tranche d''ancienneté à la reference_date (1 year and under / 1-5 years / 5-10 years / 10 years and over / _Unknown), comme _leap_company_seniority_category_as_at'",
    "_meta_status_recorded_as_at": "STRING COMMENT 'Statut brut de la version SCD2 as-at fin de mois (avant correction) — audit'",
    "_meta_source_start_validity": "DATE COMMENT 'Start_Validity de la version SCD2 utilisée (as-at) — lignage'",
    "_meta_source_end_validity": "DATE COMMENT 'End_Validity de la version SCD2 utilisée (as-at) — lignage'",
}
MONTHLY_ATTRS = {
    "primary_key": "user_id,year_month",
    "notnull_cols": "user_id,year_month",
    "cluster_cols": "user_id,year_month",
}
MONTHLY_PK_NAME = "immat_monthly_history_pk"

# ---- immat_full_latest (grain: user_id) ----
TABLE_FULL_LATEST_FIRST_COLS = {
    "user_id": "STRING COMMENT 'Identifiant collaborateur (clé métier)'",
    "reference_date": "DATE COMMENT 'Date d''évaluation du statut (aujourd''hui)'",
    "status": "STRING COMMENT 'Statut courant (ACTIVE/INACTIVE) évalué à la date d''évaluation'",
    "is_active": "BOOLEAN COMMENT 'True si status = ACTIVE'",
    "effective_end_date": "DATE COMMENT 'Date de fin de contrat de la dernière version connue'",
    "_meta_status_recorded_as_at": "STRING COMMENT 'Statut brut de la dernière version SCD2 (avant correction) — audit'",
}
FULL_LATEST_ATTRS = {
    "primary_key": "user_id",
    "notnull_cols": "user_id",
    "cluster_cols": "user_id",
}
FULL_LATEST_PK_NAME = "immat_full_latest_pk"

# Table-level comments (not carried by the DataFrame metadata → applied via COMMENT ON TABLE). The
# gold tables have their own grain / meaning, so each gets a dedicated table comment.
MONTHLY_TABLE_COMMENT = (
    "IMMAT — état mensuel de la population employée : 1 ligne par user_id et par mois "
    "(year_month), statut CORRIGÉ des départs enregistrés en retard. Reconstruit as-at "
    "last_day(mois) depuis la SCD2 silver immat_data_history_change_log ; sert à confronter "
    "l'absentéisme du mois à l'état IMMAT du même mois."
)
FULL_LATEST_TABLE_COMMENT = (
    "IMMAT — dernier état connu de chaque collaborateur (actifs ET sortis), statut évalué à ce "
    "jour depuis la dernière version SCD2 silver immat_data_history_change_log. Référentiel "
    "courant complet (l'état à une date passée reste reconstructible depuis la SCD2 silver)."
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

EMPTY_DATAFRAME_FLAG = False

# immat_full_latest is the "state as of TODAY" of everyone → a FULL overwrite that is meaningless
# for a historical-month backfill (and would conflict if many parallel backfill runs overwrote it
# at once). It is therefore (re)built ONLY on the scheduled/current run (snapshot_month empty);
# an explicit month / native backfill run builds immat_monthly_history only.
BUILD_FULL_LATEST = not SNAPSHOT_MONTH

# Raw referential statuses that are NOT a real employment state → excluded from the GOLD employed
# population (both immat_monthly_history and immat_full_latest). The SCD2 changelog (bronze/silver)
# keeps them untouched; we only drop, at the gold grain, any (user[, month]) whose as-at version is
# one of these. CREATE = record just created (not yet active) ; OFF = off/suspended (not working).
# NB: a user whose ALL as-at versions are CREATE/OFF disappears from the gold entirely (intended:
# never really employed — e.g. permanently OFF, never hired).
EXCLUDED_RAW_STATUSES = ("CREATE", "OFF")

# _meta_* columns intentionally kept in the gold. The bronze ingestion technical metadata was
# already dropped at silver (see create_silver_hr_immat), so the only OTHER _meta_* columns
# reaching here are the SCD2 chain-position flags (_meta_is_current / _meta_is_latest): they are
# DROPPED before writing because a version's position in the SCD2 chain is meaningless — and
# misleading — at the gold monthly / latest grain (the dynamic drop below stays defensive in case
# further technical _meta_* columns ever slip through).
META_KEEP_MONTHLY = {
    "_meta_status_recorded_as_at",
    "_meta_source_start_validity",
    "_meta_source_end_validity",
}
META_KEEP_FULL_LATEST = {"_meta_status_recorded_as_at"}

# Attributes for which immat_monthly_history exposes the intra-month change date, as
# <attr>_change_date = the Start_Validity of the LAST SCD2 version within the month whose value
# changed between two KNOWN values (null if none that month). A value merely APPEARING
# (null/blank/"Unknown" -> X, i.e. data completion) or DISAPPEARING (X -> null/blank/"Unknown") is
# NOT counted as a change — those are data-quality artifacts, not real business moves. Consumers read the
# "before" value from the previous month's row of the same table.
# Caveats (documented for the absenteeism use case): Start_Validity is the extraction (detection)
# date of the daily FULL snapshot → change dates are day-level, not the business effective date;
# and if an attribute changes MORE THAN ONCE in a month only the last change date is exposed (a
# single date cannot represent several changes).
CHANGE_DATE_ATTRS = ["workplace_country", "contract_type", "job_family"]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Resolve target months (target + previous)

# COMMAND ----------

# Resolve the target month (widget or current) and the previous month, via Spark (avoids driver
# date handling). Both are (re)processed and written with replaceWhere.
_today_ym = spark.sql("SELECT date_format(current_date(), 'yyyy-MM') AS ym").first()["ym"]
TARGET_YM = SNAPSHOT_MONTH if SNAPSHOT_MONTH else _today_ym
if SNAPSHOT_MONTH:
    # Explicit month (manual run OR native backfill): process ONLY that month, written via a
    # replaceWhere scoped to that single year_month. No previous-month catch-up is needed — a
    # backfill recomputes each month as-at last_day() from the full silver SCD2, independently of
    # the others. NB the table is liquid-clustered (not partitioned) so concurrent backfill runs on
    # different months may still hit a transient Delta ConcurrentAppendException — the backfill job
    # F_3b absorbs it with task retries (the per-month write is idempotent).
    PROCESS_YMS = [TARGET_YM]
else:
    # Scheduled/current run: also reprocess the PREVIOUS month to catch departures recorded late,
    # after the month had already closed.
    PREV_YM = spark.sql(
        f"SELECT date_format(add_months(to_date('{TARGET_YM}-01'), -1), 'yyyy-MM') AS ym"
    ).first()["ym"]
    PROCESS_YMS = [PREV_YM, TARGET_YM]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"IMMAT_SILVER_TABLE is:  {IMMAT_SILVER_TABLE}")
log.info(f"IMMAT_MONTHLY_HISTORY_TABLE is:  {IMMAT_MONTHLY_HISTORY_TABLE}")
log.info(f"IMMAT_FULL_LATEST_TABLE is:  {IMMAT_FULL_LATEST_TABLE}")
log.info(f"SNAPSHOT_MONTH (widget) is:  {SNAPSHOT_MONTH or '(empty -> current month)'}")
log.info(f"REINIT_GOLD (widget) is:  {REINIT_GOLD}")
log.info(
    f"Months processed (monthly_history):  {len(PROCESS_YMS)} month(s) "
    f"[{PROCESS_YMS[0]} .. {PROCESS_YMS[-1]}]"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Reinitialize gold monthly (optional — DROP, then rebuild normally)
# MAGIC
# MAGIC When `reinit_gold=true`, DROP `immat_monthly_history` and CONTINUE the run: the notebook then
# MAGIC recreates the table (clean, current schema) and rebuilds its normal month(s) below. This
# MAGIC clears stale columns/rows after a schema/logic change. Run as a SINGLE, non-backfill run
# MAGIC (a parallel backfill would drop concurrently), then backfill the rest of the history with
# MAGIC `F_3b`. `immat_full_latest` is not dropped.

# COMMAND ----------

if REINIT_GOLD:
    spark.sql(f"DROP TABLE IF EXISTS {IMMAT_MONTHLY_HISTORY_TABLE}")
    log.warning(
        f"REINIT_GOLD=true → dropped {IMMAT_MONTHLY_HISTORY_TABLE}; it is recreated (clean schema) "
        f"and rebuilt by this run for month(s) {PROCESS_YMS}. Backfill the rest with F_3b."
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

df_silver = spark.read.table(IMMAT_SILVER_TABLE)

if df_silver.isEmpty():
    log.warning(f"{IMMAT_SILVER_TABLE} is empty — nothing to build.")
    EMPTY_DATAFRAME_FLAG = True

# Snapshot the source column comments (Spark schema metadata) from the silver table NOW, before any
# transform: withColumn / rename rebuild columns and DROP their comment metadata. They are
# re-attached just before each write (see Outputs) so the comments "follow" silver -> gold. The
# per-table FIRST_COLS declarations take precedence on the columns they define (grain, as-at,
# derived flags, renamed lineage columns). Business columns carried over inherit the silver comment.
source_col_comments = {
    fld.name: fld.metadata["comment"]
    for fld in df_silver.schema.fields
    if fld.metadata.get("comment")
}

# COMMAND ----------

# MAGIC %md
# MAGIC # Part 1 — immat_monthly_history (employed population per month)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Months spine (target + previous) with reference date

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    _month_rows = [(ym, f"{ym}-01") for ym in PROCESS_YMS]
    df_months = (
        spark.createDataFrame(_month_rows, "year_month string, _first_day_str string")
        .withColumn("month_first_day", f.to_date(f.col("_first_day_str")))
        # reference date = last day of month, or today() for the current (partial) month
        .withColumn(
            "reference_date",
            f.when(
                f.date_format(f.col("month_first_day"), "yyyy-MM")
                == f.date_format(f.current_date(), "yyyy-MM"),
                f.current_date(),
            ).otherwise(f.last_day(f.col("month_first_day"))),
        )
        .select("year_month", "month_first_day", "reference_date")
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - As-at join (version valid at the reference date)
# MAGIC
# MAGIC `Start_Validity <= reference_date < End_Validity` (End_Validity exclusive) → exactly one
# MAGIC version per (user, month). df_months is tiny → broadcast.

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    df_asat = df_silver.crossJoin(f.broadcast(df_months)).filter(
        (f.col("Start_Validity") <= f.col("reference_date"))
        & (f.col("reference_date") < f.col("End_Validity"))
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Effective end_date (late-recorded departures)
# MAGIC
# MAGIC For each (user, month), the effective end_date is the `end_date` of the EARLIEST version that
# MAGIC STARTS AFTER the as-at version and whose recorded `end_date <= reference_date` (the departure
# MAGIC entered late), else the as-at `end_date`.

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    df_base_keys = df_asat.select(
        "user_id",
        "year_month",
        "reference_date",
        f.col("Start_Validity").alias("_base_start"),
    )

    df_r = df_silver.select(
        f.col("user_id").alias("_r_user_id"),
        f.col("Start_Validity").alias("_r_start"),
        f.col("end_date").alias("_r_end_date"),
    )

    df_retro = (
        df_base_keys.join(
            df_r,
            (f.col("user_id") == f.col("_r_user_id"))
            & (f.col("_r_start") > f.col("_base_start"))
            & (f.col("_r_end_date").isNotNull())
            & (f.col("_r_end_date") <= f.col("reference_date")),
            how="left",
        )
        .groupBy("user_id", "year_month")
        .agg(f.expr("min_by(_r_end_date, _r_start)").alias("retro_end_date"))
    )

    df_monthly = df_asat.join(df_retro, on=["user_id", "year_month"], how="left")
    df_monthly = df_monthly.withColumn(
        "effective_end_date",
        f.coalesce(f.col("retro_end_date"), f.col("end_date")),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Corrected status + Lot 1 flags
# MAGIC
# MAGIC Status rule (same as hr_ref_gold_proj.py Transfo 4): INACTIVE if `last_hire_date` null/after
# MAGIC the reference date (also covers rehires), or `effective_end_date < reference_date`; else
# MAGIC ACTIVE (leaving on the last calendar day counts as present that month).

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    _has_hire = "last_hire_date" in df_monthly.columns
    inactive_by_end = f.col("effective_end_date").isNotNull() & (
        f.col("effective_end_date") < f.col("reference_date")
    )
    inactive_by_hire = (
        (f.col("last_hire_date").isNull() | (f.col("last_hire_date") > f.col("reference_date")))
        if _has_hire
        else f.lit(False)
    )

    df_monthly = (
        df_monthly.withColumn("_meta_status_recorded_as_at", f.col("status"))
        .withColumn(
            "status",
            f.when(inactive_by_hire | inactive_by_end, f.lit("INACTIVE")).otherwise(
                f.lit("ACTIVE")
            ),
        )
        .withColumn("is_active", f.col("status") == f.lit("ACTIVE"))
        # departure applicable to this month came from a LATER SCD2 version (recorded late)
        .withColumn(
            "is_late_recorded_departure", f.col("retro_end_date").isNotNull()
        )
        # contract started this month (last_hire_date in month) — covers (re)hires
        .withColumn(
            "is_start_of_contract",
            f.col("last_hire_date").isNotNull()
            & (f.date_format(f.col("last_hire_date"), "yyyy-MM") == f.col("year_month"))
            if _has_hire
            else f.lit(False),
        )
        # contract ended this month (effective_end_date in month)
        .withColumn(
            "is_end_of_contract",
            f.col("effective_end_date").isNotNull()
            & (
                f.date_format(f.col("effective_end_date"), "yyyy-MM")
                == f.col("year_month")
            ),
        )
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Keep the employed population (option A)
# MAGIC
# MAGIC A user is kept for month M only if not already departed BEFORE that month: they still appear
# MAGIC on their departure month (ACTIVE if left the last day, INACTIVE if mid-month) then drop out.

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    df_monthly = df_monthly.filter(
        (
            f.col("effective_end_date").isNull()
            | (f.col("effective_end_date") >= f.col("month_first_day"))
        )
        # Exclude months whose as-at (month-end) version is a non-employment raw status
        # (CREATE / OFF). _meta_status_recorded_as_at holds the raw status (see above).
        & ~f.col("_meta_status_recorded_as_at").isin(*EXCLUDED_RAW_STATUSES)
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4b - Intra-month attribute change dates
# MAGIC
# MAGIC For each processed month, expose `<attr>_change_date` = the `Start_Validity` of the LAST SCD2
# MAGIC version STARTING in that month whose value differs from the previous version (null if the
# MAGIC attribute did not change that month). Consumed by the absenteeism use case to know the exact
# MAGIC in-month date a country / contract change took effect (rules & holidays vary by country); the
# MAGIC "before" value is read from the previous month's row. See CHANGE_DATE_ATTRS for the caveats.

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    _change_attrs = [c for c in CHANGE_DATE_ATTRS if c in df_silver.columns]
    for _missing in [c for c in CHANGE_DATE_ATTRS if c not in df_silver.columns]:
        log.warning(f"CHANGE_DATE_ATTRS: '{_missing}' absent from silver — its change date is skipped.")

    if _change_attrs:
        # Previous version's value per user (ordered by Start_Validity). _prev_start distinguishes
        # "no previous version" (first appearance → not a change) from "previous value was null".
        _w = Window.partitionBy("user_id").orderBy("Start_Validity")
        df_chg = df_silver.select("user_id", "Start_Validity", *_change_attrs).withColumn(
            "_prev_start", f.lag("Start_Validity").over(_w)
        )
        for a in _change_attrs:
            df_chg = df_chg.withColumn(f"_prev_{a}", f.lag(a).over(_w))

        # Keep only genuine transitions falling in the processed months.
        df_chg = df_chg.filter(f.col("_prev_start").isNotNull()).withColumn(
            "year_month", f.date_format("Start_Validity", "yyyy-MM")
        ).filter(f.col("year_month").isin(PROCESS_YMS))

        # <attr>_change_date = latest Start_Validity in the month where the attr changed between two
        # KNOWN values. A value only APPEARING (null/Unknown -> X, i.e. data completion) or
        # DISAPPEARING (X -> null/Unknown) is NOT a real business change and is ignored — otherwise
        # the columns fill up with data-quality noise (e.g. ~225/228 workplace_country "changes"
        # were just null -> country). "Unknown" is excluded because the silver fills some columns
        # (e.g. job_family) with it.
        def _known(colname):
            # A value is "known" only if it is a real business value: not null, not blank/empty
            # (a value being filled in for the first time is a completion, not a change), and not the
            # "Unknown" placeholder the silver assigns to some columns.
            c = f.col(colname)
            return c.isNotNull() & (f.trim(c) != f.lit("")) & (c != f.lit("Unknown"))

        _agg = [
            f.max(
                f.when(
                    _known(a) & _known(f"_prev_{a}") & (f.col(a) != f.col(f"_prev_{a}")),
                    f.col("Start_Validity"),
                )
            ).alias(f"{a}_change_date")
            for a in _change_attrs
        ]
        df_change_dates = df_chg.groupBy("user_id", "year_month").agg(*_agg)

        df_monthly = df_monthly.join(df_change_dates, on=["user_id", "year_month"], how="left")

    # Ensure the columns always exist (null) even when an attribute is absent or nothing changed.
    for a in CHANGE_DATE_ATTRS:
        if f"{a}_change_date" not in df_monthly.columns:
            df_monthly = df_monthly.withColumn(f"{a}_change_date", f.lit(None).cast("date"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4c - contract_type_category (business rule)
# MAGIC
# MAGIC Derive a contract category from `contract_type`, reusing the same mapping as the LEAP HR
# MAGIC referential (`hr_ref_gold_proj.py`, Transfo 6): Permanent contract / Fixed-term contract /
# MAGIC Temporary worker / Subcontractor; the raw `contract_type` is kept for any unmapped value.

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG and "contract_type" in df_monthly.columns:
    df_monthly = df_monthly.withColumn(
        "contract_type_category",
        f.when(f.col("contract_type") == "CDI", "Permanent contract")
        .when(
            f.col("contract_type").isin(
                [
                    "CDD",
                    "APR",
                    "PR",
                    "SIVP",
                    "ANA",
                    "CDD ANAPEC",
                    "Fixed-term contract",
                    "Fixed-term professionnal contract",
                    "Permanent professionnal contract",
                    "Stage SIVP",
                    "Apprentice",
                ]
            ),
            "Fixed-term contract",
        )
        .when(f.col("contract_type").isin(["INT", "Interim contrat"]), "Temporary worker")
        .when(f.col("contract_type").isin(["SST"]), "Subcontractor")
        .otherwise(f.col("contract_type")),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4d - age / seniority as-at (business rule)
# MAGIC
# MAGIC Age and company seniority (years + category) evaluated at the month `reference_date`, reusing
# MAGIC the same calculation as the LEAP HR referential (`hr_ref_silver.py`, Transfo 1 & 2) — there
# MAGIC the "as-at" date is the extraction date; here it is the month reference date.

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    _asat = f.col("reference_date")

    if "birth_date" in df_monthly.columns:
        df_monthly = df_monthly.withColumn(
            "age_as_at",
            f.floor(f.datediff(_asat, f.col("birth_date")) / 365).cast("int"),
        ).withColumn(
            "age_category_as_at",
            f.when(f.col("age_as_at") < 30, "30 years and under")
            .when((f.col("age_as_at") >= 30) & (f.col("age_as_at") < 45), "30-45 years")
            .when((f.col("age_as_at") >= 45) & (f.col("age_as_at") < 55), "45-55 years")
            .when(f.col("age_as_at") >= 55, "55 years and over")
            .otherwise("_Unknown"),
        )

    if "company_seniority_date" in df_monthly.columns:
        df_monthly = df_monthly.withColumn(
            "company_seniority_as_at",
            f.floor(f.datediff(_asat, f.col("company_seniority_date")) / 365).cast("int"),
        ).withColumn(
            "company_seniority_category_as_at",
            f.when(f.col("company_seniority_as_at") < 1, "1 year and under")
            .when(
                (f.col("company_seniority_as_at") >= 1) & (f.col("company_seniority_as_at") < 5),
                "1-5 years",
            )
            .when(
                (f.col("company_seniority_as_at") >= 5) & (f.col("company_seniority_as_at") < 10),
                "5-10 years",
            )
            .when(f.col("company_seniority_as_at") >= 10, "10 years and over")
            .otherwise("_Unknown"),
        )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 5 - Lineage columns + column order

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    df_monthly = (
        df_monthly.withColumnRenamed("Start_Validity", "_meta_source_start_validity")
        .withColumnRenamed("End_Validity", "_meta_source_end_validity")
        .drop("retro_end_date", "month_first_day")
    )
    # Drop the silver-carried SCD2 chain flags (_meta_is_current / _meta_is_latest) that carry no
    # meaning at the monthly grain; keep only META_KEEP_MONTHLY (bronze technical _meta_* were
    # already dropped at silver).
    _meta_drop = [
        c
        for c in df_monthly.columns
        if c.startswith("_meta_") and c not in META_KEEP_MONTHLY
    ]
    df_monthly = df_monthly.drop(*_meta_drop)
    df_monthly = move_dataframe_cols_first(
        df_monthly, list(TABLE_MONTHLY_FIRST_COLS.keys())
    )

    # Re-attach comments (silver source overlaid by the monthly FIRST_COLS declarations) so
    # save_table persists them on the derived + carried-over columns.
    _monthly_first_comments = {
        c: parse_column_comment(ddl) for c, ddl in TABLE_MONTHLY_FIRST_COLS.items()
    }
    _monthly_comments = dict(source_col_comments)
    _monthly_comments.update({c: t for c, t in _monthly_first_comments.items() if t})
    df_monthly = attach_column_comments(df_monthly, _monthly_comments)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks — monthly grain uniqueness + PK not-null (RED)
# MAGIC
# MAGIC `dest_table` routes the results into the HR quality_event_table ({env}_bronze_hr.data_quality).

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    pk_cols = [c.strip() for c in MONTHLY_ATTRS["primary_key"].split(",")]
    notnull_cols = [c.strip() for c in MONTHLY_ATTRS["notnull_cols"].split(",")]

    df_gx = SparkDFDataset(df_monthly, persist=False)
    red_results = [df_gx.expect_compound_columns_to_be_unique(column_list=pk_cols)]
    for one_col in notnull_cols:
        red_results.append(df_gx.expect_column_values_to_not_be_null(column=one_col))

    gx_validation.validate_and_log_gx_results(
        quality_check_results=red_results,
        validation_level="RED",
        info_message=f"Monthly grain {pk_cols} unique and not null (months {PROCESS_YMS})",
        error_message="Quality checks failed for immat_monthly_history, please check log messages",
        pipeline_write_env=PIPELINE_WRITE_ENV,
        table_name="immat_monthly_history",
        log_to_event_table=True,
        log_successes=True,
        dest_table=IMMAT_MONTHLY_HISTORY_TABLE,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - immat_monthly_history (replaceWhere on the processed months)

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    catalog, schema, table = IMMAT_MONTHLY_HISTORY_TABLE.split(".")
    try:
        table_utils.create_unity_catalog_table(
            catalog,
            schema,
            table,
            force_reinitialization=False,
            cluster_cols=MONTHLY_ATTRS["cluster_cols"],
            partition_col=None,
            primary_key_cols=None,
            columns=TABLE_MONTHLY_FIRST_COLS,
            force_drop=False,
        )
    except AnalysisException as e:
        log.error(f"Table {IMMAT_MONTHLY_HISTORY_TABLE} could not be created. Error is {e}")
        raise OSError(
            f"An error occurred while creating the table {IMMAT_MONTHLY_HISTORY_TABLE}"
        ) from e

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    # Idempotent per-month write: replaceWhere atomically replaces exactly the processed months
    # (handles updates AND removals — e.g. a user that became departed-before-month drops out).
    _ym_list = ", ".join([f"'{ym}'" for ym in PROCESS_YMS])
    _replace_where = f"year_month in ({_ym_list})"
    try:
        startTime = time.time()
        table_utils.save_table(
            dest_table=IMMAT_MONTHLY_HISTORY_TABLE,
            df=df_monthly,
            mode="overwrite",
            overwrite_schema=False,  # replaceWhere is incompatible with overwriteSchema
            cluster_cols=MONTHLY_ATTRS["cluster_cols"],
            merge_schema=True,
            replace_where=_replace_where,
        )
    except AnalysisException as e:
        log.error(f"Table {IMMAT_MONTHLY_HISTORY_TABLE} could not be saved. Error is {e}")
        raise OSError(
            f"An error occurred while saving the table {IMMAT_MONTHLY_HISTORY_TABLE}"
        ) from e
    else:
        duration = time.time() - startTime
        log.info(
            f"Table {IMMAT_MONTHLY_HISTORY_TABLE} saved in {duration}s "
            f"(replaceWhere {_replace_where})."
        )
        log.info(f"Wrote {df_monthly.count()} rows for months {PROCESS_YMS}.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - immat_monthly_history table comment

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG and MONTHLY_TABLE_COMMENT:
    spark.sql(
        f"COMMENT ON TABLE {IMMAT_MONTHLY_HISTORY_TABLE} IS "
        f"'{MONTHLY_TABLE_COMMENT.replace(chr(39), chr(39) * 2)}'"
    )
    log.info(f"Applied table comment on {IMMAT_MONTHLY_HISTORY_TABLE}.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - immat_monthly_history PRIMARY KEY

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG:
    _existing = set(spark.table(IMMAT_MONTHLY_HISTORY_TABLE).columns)
    pk_cols = [c for c in MONTHLY_ATTRS["primary_key"].split(",") if c in _existing]
    nb_cons = spark.sql(
        f"SELECT count(*) FROM system.information_schema.table_constraints "
        f"WHERE table_catalog = '{GOLD_CATALOG}' AND table_schema = '{GOLD_SCHEMA}' "
        f"AND table_name = 'immat_monthly_history' AND constraint_name = '{MONTHLY_PK_NAME}'"
    ).first()[0]
    if pk_cols and nb_cons == 0:
        table_utils.apply_pk_fk_tags_uc(
            full_table_name=IMMAT_MONTHLY_HISTORY_TABLE,
            primary_key=pk_cols,
            foreign_keys=[],
            dry_run=False,
        )
        for col in pk_cols:
            table_utils.set_table_column_not_null(
                table_path=IMMAT_MONTHLY_HISTORY_TABLE, column=col
            )
        table_utils.add_table_primary_key(
            table_path=IMMAT_MONTHLY_HISTORY_TABLE,
            pk_name=MONTHLY_PK_NAME,
            columns=",".join(pk_cols),
        )
        log.info(f"Applied PK constraint {pk_cols} on {IMMAT_MONTHLY_HISTORY_TABLE}.")

# COMMAND ----------

# MAGIC %md
# MAGIC # Part 2 — immat_full_latest (latest complete state of everyone)
# MAGIC
# MAGIC Built ONLY on the scheduled/current run (`BUILD_FULL_LATEST`, i.e. snapshot_month empty).
# MAGIC Skipped on an explicit month / native backfill run (it is an as-of-today full overwrite,
# MAGIC unrelated to a historical month, and must not be overwritten by parallel backfill runs).

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Latest version per user + status as-of today
# MAGIC
# MAGIC One row per user_id = the latest known SCD2 version (`_meta_is_latest = true`). Status is
# MAGIC evaluated as-of today from that version's dates (no forward look needed — it IS the latest
# MAGIC knowledge, so its end_date already reflects any late-recorded departure).

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG and BUILD_FULL_LATEST:
    df_latest = df_silver.filter(f.col("_meta_is_latest") == f.lit(True))
    # Exclude users whose latest raw status is a non-employment state (CREATE / OFF): they are not
    # part of the employed population (here `status` still holds the raw value, before correction).
    df_latest = df_latest.filter(~f.col("status").isin(*EXCLUDED_RAW_STATUSES))

    _has_hire_l = "last_hire_date" in df_latest.columns
    _inactive_end_l = f.col("end_date").isNotNull() & (
        f.col("end_date") < f.current_date()
    )
    _inactive_hire_l = (
        (f.col("last_hire_date").isNull() | (f.col("last_hire_date") > f.current_date()))
        if _has_hire_l
        else f.lit(False)
    )

    df_full_latest = (
        df_latest.withColumn("reference_date", f.current_date())
        .withColumn("effective_end_date", f.col("end_date"))
        .withColumn("_meta_status_recorded_as_at", f.col("status"))
        .withColumn(
            "status",
            f.when(_inactive_hire_l | _inactive_end_l, f.lit("INACTIVE")).otherwise(
                f.lit("ACTIVE")
            ),
        )
        .withColumn("is_active", f.col("status") == f.lit("ACTIVE"))
    )
    # Drop the silver-carried SCD2 chain flags (_meta_is_current / _meta_is_latest) that carry no
    # meaning at the latest grain; keep only META_KEEP_FULL_LATEST (bronze technical _meta_* were
    # already dropped at silver).
    _meta_drop_l = [
        c
        for c in df_full_latest.columns
        if c.startswith("_meta_") and c not in META_KEEP_FULL_LATEST
    ]
    df_full_latest = df_full_latest.drop(*_meta_drop_l)
    df_full_latest = move_dataframe_cols_first(
        df_full_latest, list(TABLE_FULL_LATEST_FIRST_COLS.keys())
    )

    # Re-attach comments (silver source overlaid by the full_latest FIRST_COLS declarations).
    _latest_first_comments = {
        c: parse_column_comment(ddl) for c, ddl in TABLE_FULL_LATEST_FIRST_COLS.items()
    }
    _latest_comments = dict(source_col_comments)
    _latest_comments.update({c: t for c, t in _latest_first_comments.items() if t})
    df_full_latest = attach_column_comments(df_full_latest, _latest_comments)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks — full_latest uniqueness + not-null (RED)

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG and BUILD_FULL_LATEST:
    df_gx_l = SparkDFDataset(df_full_latest, persist=False)
    red_results_l = [
        df_gx_l.expect_column_values_to_be_unique(column="user_id"),
        df_gx_l.expect_column_values_to_not_be_null(column="user_id"),
    ]
    gx_validation.validate_and_log_gx_results(
        quality_check_results=red_results_l,
        validation_level="RED",
        info_message="immat_full_latest: user_id unique and not null",
        error_message="Quality checks failed for immat_full_latest, please check log messages",
        pipeline_write_env=PIPELINE_WRITE_ENV,
        table_name="immat_full_latest",
        log_to_event_table=True,
        log_successes=True,
        dest_table=IMMAT_FULL_LATEST_TABLE,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - immat_full_latest (full overwrite)

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG and BUILD_FULL_LATEST:
    catalog, schema, table = IMMAT_FULL_LATEST_TABLE.split(".")
    try:
        table_utils.create_unity_catalog_table(
            catalog,
            schema,
            table,
            force_reinitialization=False,
            cluster_cols=FULL_LATEST_ATTRS["cluster_cols"],
            partition_col=None,
            primary_key_cols=None,
            columns=TABLE_FULL_LATEST_FIRST_COLS,
            force_drop=False,
        )
    except AnalysisException as e:
        log.error(f"Table {IMMAT_FULL_LATEST_TABLE} could not be created. Error is {e}")
        raise OSError(
            f"An error occurred while creating the table {IMMAT_FULL_LATEST_TABLE}"
        ) from e

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG and BUILD_FULL_LATEST:
    try:
        startTime = time.time()
        table_utils.save_table(
            dest_table=IMMAT_FULL_LATEST_TABLE,
            df=df_full_latest,
            mode="overwrite",
            overwrite_schema=True,
            cluster_cols=FULL_LATEST_ATTRS["cluster_cols"],
            merge_schema=True,
        )
    except AnalysisException as e:
        log.error(f"Table {IMMAT_FULL_LATEST_TABLE} could not be saved. Error is {e}")
        raise OSError(
            f"An error occurred while saving the table {IMMAT_FULL_LATEST_TABLE}"
        ) from e
    else:
        duration = time.time() - startTime
        log.info(f"Table {IMMAT_FULL_LATEST_TABLE} saved in {duration}s.")
        log.info(f"Wrote {df_full_latest.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - immat_full_latest table comment

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG and BUILD_FULL_LATEST and FULL_LATEST_TABLE_COMMENT:
    spark.sql(
        f"COMMENT ON TABLE {IMMAT_FULL_LATEST_TABLE} IS "
        f"'{FULL_LATEST_TABLE_COMMENT.replace(chr(39), chr(39) * 2)}'"
    )
    log.info(f"Applied table comment on {IMMAT_FULL_LATEST_TABLE}.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - immat_full_latest PRIMARY KEY

# COMMAND ----------

if not EMPTY_DATAFRAME_FLAG and BUILD_FULL_LATEST:
    _existing = set(spark.table(IMMAT_FULL_LATEST_TABLE).columns)
    pk_cols = [c for c in FULL_LATEST_ATTRS["primary_key"].split(",") if c in _existing]
    nb_cons = spark.sql(
        f"SELECT count(*) FROM system.information_schema.table_constraints "
        f"WHERE table_catalog = '{GOLD_CATALOG}' AND table_schema = '{GOLD_SCHEMA}' "
        f"AND table_name = 'immat_full_latest' AND constraint_name = '{FULL_LATEST_PK_NAME}'"
    ).first()[0]
    if pk_cols and nb_cons == 0:
        table_utils.apply_pk_fk_tags_uc(
            full_table_name=IMMAT_FULL_LATEST_TABLE,
            primary_key=pk_cols,
            foreign_keys=[],
            dry_run=False,
        )
        for col in pk_cols:
            table_utils.set_table_column_not_null(
                table_path=IMMAT_FULL_LATEST_TABLE, column=col
            )
        table_utils.add_table_primary_key(
            table_path=IMMAT_FULL_LATEST_TABLE,
            pk_name=FULL_LATEST_PK_NAME,
            columns=",".join(pk_cols),
        )
        log.info(f"Applied PK constraint {pk_cols} on {IMMAT_FULL_LATEST_TABLE}.")

# COMMAND ----------

dbutils.notebook.exit(
    f"ok:{IMMAT_MONTHLY_HISTORY_TABLE}|months={PROCESS_YMS}|"
    f"full_latest={'rebuilt' if BUILD_FULL_LATEST else 'skipped(backfill)'}"
)
