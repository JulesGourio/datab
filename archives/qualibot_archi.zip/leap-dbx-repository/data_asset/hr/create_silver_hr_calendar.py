# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Silver HR Calendar — Site Working Days
# MAGIC %md
# MAGIC ## Silver HR Calendar — Workplace Working Days
# MAGIC
# MAGIC Autonomous notebook: reads workplace calendars from bronze, maps to the unified silver schema
# MAGIC (YAML-driven), and writes to `{pipeline_write_env}_silver_hr.absenteism.calendar` (full overwrite).
# MAGIC
# MAGIC | Source | Catalog | Schema | Table |
# MAGIC |---|---|---|---|
# MAGIC | Workplaces calendars | `{pipeline_read_env}_bronze_hr` | `calendars` | `calendars_latest` |
# MAGIC
# MAGIC **Target**: `{pipeline_write_env}_silver_hr.absenteism.calendar`
# MAGIC
# MAGIC **Schema contract**: `data_asset/hr/config/silver_calendar_column_mapping.yaml`
# MAGIC
# MAGIC **Transformations**:
# MAGIC - Rename: `country` → `workplace_country`, `date` → `calendar_date`, `standard_daily_working_hours` → `working_hours`
# MAGIC - Generate PK: `calendar_id` (dense_rank per country/workplace)
# MAGIC - Enrich dates: `week`, `month`, `year` derived from `calendar_date`
# MAGIC - Derive flags from `day_type`: `is_working_day`, `is_workplace_closure`, `is_holiday` (+ nullable `workplace_closure_reason`, `holiday_name`)
# MAGIC - Clean: trim strings, nullify empty, drop rows with null mandatory columns
# MAGIC
# MAGIC **Write mode**: overwrite (full table rebuild). Clustered by `workplace`, `calendar_date`.

# COMMAND ----------

# DBTITLE 1,Imports
from itertools import chain
from pyspark.sql import functions as f

from data_asset.hr.utils.table_schema_map_utils import load_config
from data_asset.hr.utils.silver_cleaning_utils import normalize_string
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

from data_asset.hr.utils.asset_output_pipeline import run_asset_output_pipeline
from great_expectations.core import (
    ExpectationSuiteValidationResult,
)
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# DBTITLE 1,Config: widgets & logging
# --- Widgets ---
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = setup_applevel_logger(log_level=LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config: source and target
# --- Source ---
SOURCE_CATALOG = f"{PIPELINE_READ_ENV}_bronze_hr"
SOURCE_SCHEMA = "calendars"
SOURCE_TABLE = "calendars_latest"

# --- Target ---
config = load_config(config_path="config/silver_calendar_column_mapping.yaml")
_target = config["target"]
SILVER_CATALOG = f"{PIPELINE_WRITE_ENV}_silver_hr"
SILVER_SCHEMA = _target["schema"]
SILVER_TABLE = _target["table"]

# --- Full table paths ---
SOURCE_FULL_TABLE = f"{SOURCE_CATALOG}.{SOURCE_SCHEMA}.{SOURCE_TABLE}"
SILVER_FULL_TABLE = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{SILVER_TABLE}"

# COMMAND ----------

# DBTITLE 1,Input data - Immat reference
# Load IMMAT GOLD data
df_immat_gold = spark.table(f"{PIPELINE_READ_ENV}_gold_hr.immat.immat_full_latest")

# Next: definition of dicts for mapping cleaned name to actual immat names
workplace_immat = {
    normalize_string(r[0]): r[0]
    for r in df_immat_gold.select("workplace").distinct().collect()
    if r[0]
}

# NOTA: we do not use immat a as a reference for the workplaces' countries.
# this calendar column will, in fact, not be used, we keep it because it's pretty

# COMMAND ----------

# DBTITLE 1,Input data - Source calendar
df_source = spark.table(SOURCE_FULL_TABLE)

df_silver = df_source.select(
    f.col("country").alias("workplace_country"),
    f.col("workplace"),
    f.col("date").alias("calendar_date"),
    f.col("day_type"),
    f.col("standard_daily_working_hours").alias("working_hours").cast("float")
)

# COMMAND ----------

# DBTITLE 1,Tr. 1 - Generate calendar_id
# Generate a PK key as concatenation of multiple columns
df_silver = df_silver.withColumn(
    "calendar_id",
    f.concat_ws("-", "workplace", "calendar_date")
)

# COMMAND ----------

# DBTITLE 1,Tr. 2 - Derive date components
df_silver = df_silver.withColumns(
    {
        "week": f.weekofyear(f.col("calendar_date")).cast("int"),
        "month": f.date_format("calendar_date", "MM").cast("int"),
        "year": f.date_format("calendar_date", "yyyy").cast("int"),
    }
)

# COMMAND ----------

# DBTITLE 1,Tr. 3 - Derive day type flags
df_silver = df_silver.withColumns(
    {
        "is_working_day": f.lower(f.col("day_type")) == "working day",
        "is_workplace_closure": f.lower(f.col("day_type")) == "workplace closed",
        "workplace_closure_reason": f.expr("CAST(NULL AS STRING)"),
        "is_holiday": f.lower(f.col("day_type")) == "public holiday",
        "holiday_name": f.expr("CAST(NULL AS STRING)"),
    }
)

# COMMAND ----------

# DBTITLE 1,Tr. 4 - Default null hours to zero
# Null hours => zero values
df_silver = df_silver.withColumn(
    "working_hours",
    f.when(f.col("working_hours").isNull(), f.lit(0)).otherwise(f.col("working_hours")),
)

# COMMAND ----------

# DBTITLE 1,Tr. 5 - Map workplace to immat
normalize_string_udf = f.udf(normalize_string, "string")

# Build Spark map columns from the immat reference dicts (normalized_name -> immat_name)
workplace_map = f.create_map([f.lit(x) for x in chain(*workplace_immat.items())])

# Normalize then map to the official immat reference value
# for instance "FranCé" will be matched and replaced with "France", which is
# one of the reference values from immat
df_silver = df_silver.withColumns(
    {
        "workplace_mapped": workplace_map[normalize_string_udf(f.col("workplace"))]
    }
)

# COMMAND ----------

# DBTITLE 1,Specific Quality Checks
def _build_extra_red_results(
    df_gx: SparkDFDataset,
) -> list[ExpectationSuiteValidationResult]:
    # Completeness: each (year, workplace) must have 365 or 366 rows
    df_days_per_group = df_silver.groupBy("year", "workplace").agg(
        f.count("*").alias("row_count")
    )
    df_gx_grouped = SparkDFDataset(df_days_per_group, persist=False)

    return [
        # working_hours >= 0
        df_gx.expect_column_values_to_be_between(
            column="working_hours",
            min_value=0,
        ),
        # week >= 1 and <= 53
        df_gx.expect_column_values_to_be_between(
            column="week",
            min_value=1,
            max_value=53,
        ),
        # month >= 1 and <= 12
        df_gx.expect_column_values_to_be_between(
            column="month",
            min_value=1,
            max_value=12,
        ),
        # year >= 2020 and <= 3000
        df_gx.expect_column_values_to_be_between(
            column="year",
            min_value=2020,
            max_value=3000,
        ),
        # workplace in workplace_immat
        df_gx.expect_column_values_to_be_in_set(
            column="workplace",
            value_set=set(workplace_immat.values()),
        ),
        # Each (year, workplace) group must have 365 or 366 days
        df_gx_grouped.expect_column_values_to_be_between(
            column="row_count",
            min_value=365,
            max_value=366,
        ),
    ]

# COMMAND ----------

# DBTITLE 1,Run Pipeline
run_asset_output_pipeline(
    spark=spark,
    df_input=df_silver,
    config=config,
    full_table_path=SILVER_FULL_TABLE,
    pipeline_write_env=PIPELINE_WRITE_ENV,
    log=log,
    extra_gx_builder=_build_extra_red_results,
    apply_clean_non_pii=True,
    drop_null_pk_rows=True,
    is_debug=LOG_LEVEL == "debug",
)
