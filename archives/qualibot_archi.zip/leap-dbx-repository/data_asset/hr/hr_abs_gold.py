# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # HR ABSENTEISM GOLD
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to build gold data asset for HR Absenteism.
# MAGIC - 1st STEP : load silver table
# MAGIC - 2nd STEP : calculate abs rate
# MAGIC - 2nd STEP : save the gold table
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - hr data asset.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver.hr.hr_absenteism_silver_latest
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.hr.hr_absenteism_gold_latest
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

spark.conf.set("spark.sql.ansi.enabled", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_CATALOG = f"{PIPELINE_READ_ENV}_silver"
SILVER_SCHEMA = "hr"
ABS_SILVER_LATEST_TABLE = (
    f"{SILVER_CATALOG}.{SILVER_SCHEMA}.hr_absenteism_silver_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

GOLD_CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
GOLD_SCHEMA = "hr"

ABS_GOLD_LATEST_TABLE = f"{GOLD_CATALOG}.{GOLD_SCHEMA}.hr_absenteism_gold_latest"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

TABLE_GOLD_FIRST_COLS = {
    "_meta_stack_row_id": "STRING COMMENT 'STACK UNIQUE ID GENERATED ALWAYS AS IDENTITY'",
    "_meta_ID": "STRING",
    "_meta_extraction_timestamp": "TIMESTAMP",
    "_meta_ingestion_timestamp": "TIMESTAMP",
    "_meta_file_name": "STRING",
    "_meta_file_mode": "STRING",
    "_meta_file_path": "STRING",
    "_leap_extraction_date": "DATE",
    "_leap_year_month_extraction_date": "STRING",
    "Year": "STRING",
    "Month": "STRING",
    "Country": "STRING",
    "Workplace": "STRING",
    "_leap_year_month_calendar_date": "STRING",
    "_leap_calendar_date": "DATE",
}

GOLD_CLUSTER_COLS_STR = "Year,Month"
GOLD_PK_COLUMNS_LIST = [
    "Year",
    "Month",
    "Country",
    "Workplace",
]  # PRIMARY KEY OF THE LATEST (aka id_column_list)
GOLD_PK_NAME = "hr_abs_gold_history_pk"
ABS_GOLD_LATEST_TABLE_PK_COLUMNS_STR = "_meta_ID"
ABS_GOLD_LATEST_TABLE_PK_COLUMNS_LIST = [ABS_GOLD_LATEST_TABLE_PK_COLUMNS_STR]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# MAGIC %md
# MAGIC #### Common global variables

# COMMAND ----------

MODE = "overwrite"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"SILVER_CATALOG is:  {SILVER_CATALOG}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"GOLD_CATALOG is:  {SILVER_CATALOG}")
log.info(f"GOLD_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"ABS_SILVER_LATEST_TABLE is:  {ABS_SILVER_LATEST_TABLE}")
log.info(f"ABS_GOLD_LATEST_TABLE is:  {ABS_GOLD_LATEST_TABLE}")
log.info(f"MODE is:  {MODE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks - Functions

# COMMAND ----------

# Imported from leap_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Tables Read
# MAGIC - Clean Data
# MAGIC - Hash columns
# MAGIC - Table Write

# COMMAND ----------

# Upload ABS_SILVER_LATEST_TABLE
df_abs_silver = spark.read.table(f"{ABS_SILVER_LATEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------


# Move a List of Columns in first cols of Dataframe
def move_dataframe_cols_first(df: SparkDataFrame, cols_to_move: list) -> SparkDataFrame:
    """
    Reorders the columns in a Spark DataFrame by moving the specified columns to the front.

    :param df: The input Spark DataFrame.
    :type df: SparkDataFrame
    :param cols_to_move: A list of column names to move to the beginning.
    :type cols_to_move: list
    :return: A Spark DataFrame with the reordered columns.
    :rtype: SparkDataFrame
    """
    first_cols = cols_to_move
    other_cols = [c for c in df.columns if c not in first_cols]
    df_new = df.select(*first_cols, *other_cols)
    return df_new


def last_day_of_month(date_col):
    """
    Returns the last day of the month for a given date column.

    :param date_col: A Spark SQL Column representing a date.
    :type date_col: Column
    :return: A Spark SQL Column containing the last day of the month.
    :rtype: Column
    """
    return f.last_day(date_col)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Abs rate

# COMMAND ----------

df_abs_silver_rate = df_abs_silver.withColumn(
    "_leap_absence_rate", (f.col("Total_abs") / f.col("Total_Work_days")).cast("double")
).fillna(
    {"_leap_absence_rate": 0}
)  # replace null in Absence_Rate by 0

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Optimize order of Columns

# COMMAND ----------

first_cols = list(TABLE_GOLD_FIRST_COLS.keys())
df_abs_gold = move_dataframe_cols_first(df_abs_silver_rate, first_cols)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

## Quality Checks - Common Functions defined in leap_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - check abs rate value
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Quality checks with great_expectations : col "Absence_Rate" should be < 1
# Raise an Exception if not pass the checks
df_to_check = df_abs_gold
gx_validation.gx_check_max_value(
    df=df_to_check,
    col="_leap_absence_rate",
    max_value=1,
    validation_level="RED",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="hr_absenteism_gold",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 2

# COMMAND ----------

# TBD

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by GOLD_CLUSTER_COLS_STR
catalog, schema, table = ABS_GOLD_LATEST_TABLE.split(".")

try:
    table_utils.create_unity_catalog_table(
        catalog,
        schema,
        table,
        force_reinitialization=False,
        cluster_cols=GOLD_CLUSTER_COLS_STR,
        partition_col=None,
        primary_key_cols=None,
        columns=TABLE_GOLD_FIRST_COLS,
        force_drop=False,
    )
except AnalysisException as e:
    log.error(
        f"Table {ABS_GOLD_LATEST_TABLE} has not been created, an error occured during creation. \nError is {e}"
    )
    raise OSError(
        f"An error occurred while creating the table {ABS_GOLD_LATEST_TABLE}"
    ) from e

# COMMAND ----------

# Save the gold table from Dataframe df_abs_gold, preserving cluster columns
try:
    startTime = time.time()
    table_utils.save_table(
        dest_table=ABS_GOLD_LATEST_TABLE,
        df=df_abs_gold,
        mode=MODE,
        overwrite_schema=True,
        cluster_cols=GOLD_CLUSTER_COLS_STR,
        merge_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {ABS_GOLD_LATEST_TABLE} has not been created, an error occured during table_utils.save_table . \nError is {e}"
    )
    raise OSError(
        f"An error occurred while saving the table {ABS_GOLD_LATEST_TABLE}"
    ) from e
else:
    duration = time.time() - startTime
    log.info(f"Table {ABS_GOLD_LATEST_TABLE} saved in {duration} seconds.")
    log.info(f"Wrote {df_abs_gold.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Set up primary key
# MAGIC

# COMMAND ----------

# Add Primary Key if not exists
catalog, schema, table = ABS_GOLD_LATEST_TABLE.split(".")
pk_name = GOLD_PK_NAME.lower()
nb_cons = spark.sql(
    f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    for col in ABS_GOLD_LATEST_TABLE_PK_COLUMNS_LIST:
        table_utils.set_table_column_not_null(
            table_path=ABS_GOLD_LATEST_TABLE, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=ABS_GOLD_LATEST_TABLE,
        pk_name=GOLD_PK_NAME,
        columns=ABS_GOLD_LATEST_TABLE_PK_COLUMNS_STR,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Set up governed tags and comments on assets
# MAGIC
# MAGIC - HR
# MAGIC - domain
# MAGIC - refresh_frequency
# MAGIC - system.certification_status

# COMMAND ----------

# set governed tags
spark.sql(f"ALTER TABLE {ABS_GOLD_LATEST_TABLE} ALTER COLUMN _meta_ID SET TAGS ('primary_key');")

spark.sql(f"ALTER TABLE {ABS_GOLD_LATEST_TABLE} SET TAGS ('HR');")
spark.sql(f"ALTER TABLE {ABS_GOLD_LATEST_TABLE} SET TAGS ('domain' = 'HR');")
spark.sql(f"ALTER TABLE {ABS_GOLD_LATEST_TABLE} SET TAGS ('refresh_frequency' = 'daily');")
spark.sql(f"ALTER TABLE {ABS_GOLD_LATEST_TABLE} SET TAGS ('system.certification_status' = 'certified');")
spark.sql(f"ALTER TABLE {ABS_GOLD_LATEST_TABLE} SET TAGS ('primary_key_columns' = '{ABS_GOLD_LATEST_TABLE_PK_COLUMNS_STR}');")

# set comments
spark.sql(f"""COMMENT ON TABLE {ABS_GOLD_LATEST_TABLE} IS
'HR workforces absenteism by year-month, country, workplace.';""")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
