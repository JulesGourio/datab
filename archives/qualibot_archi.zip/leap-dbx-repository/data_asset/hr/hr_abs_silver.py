# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # HR ABSENTEISM SILVER
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to build silver data asset for HR Absenteism.
# MAGIC - 1st STEP : cleaning bronze
# MAGIC - 2nd STEP : save silver table
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - hr data asset.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - sd_{pipeline_read_env}_bronze.hr.t_absenteism_rh_leap_latest
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.hr.hr_absenteism_silver_latest
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

BRONZE_CATALOG = f"sd_{PIPELINE_READ_ENV}_bronze"
BRONZE_SCHEMA = "hr"

ABS_BRONZE_LATEST_TABLE = (
    f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.t_absenteism_rh_leap_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SILVER_SCHEMA = "hr"

ABS_SILVER_LATEST_TABLE = (
    f"{SILVER_CATALOG}.{SILVER_SCHEMA}.hr_absenteism_silver_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

TABLE_SILVER_FIRST_COLS = {
    "_meta_stack_row_id": "STRING COMMENT 'STACK UNIQUE ID GENERATED ALWAYS AS IDENTITY'",
    "_meta_ID": "STRING",
    "_meta_extraction_timestamp": "TIMESTAMP",
    "_meta_ingestion_timestamp": "TIMESTAMP",
    "_meta_file_name": "STRING",
    "_meta_file_mode": "STRING",
    "_meta_file_path": "STRING",
    "_leap_extraction_date": "DATE",
    "_leap_year_month_extraction_date": "STRING",
    "Year": "STRING",
    "Month": "STRING",
    "Country": "STRING",
    "Workplace": "STRING",
}

# COMMAND ----------

# MAGIC %md
# MAGIC #### for the Silver History

# COMMAND ----------

# attributes for table ABS_SILVER_LATEST_TABLE
SILVER_ATTRS_DICT = {
    "string_cols": [],
    "float_cols": [
        "Target_Absenteeism",
        "Target_Resignations",
        "Target_Leavings",
        "Target_Resignations_All_contracts",
    ],
    "int_cols": ["Total_Work_days", "Total_abs"],
    "columns_to_drop": [],
    "columns_to_trim": [
        "Year",
        "Month",
        "Country",
        "Workplace",
        "Target_Absenteeism",
        "Target_Resignations",
        "Target_Leavings",
    ],
    "columns_to_replace_nulls_by_zero": ["Total_Work_days", "Total_abs"],
    "date_cols": [],
    "primary_key": "Year,Month,Country,Workplace",
    "notnull_cols": "Year,Month,Country,Workplace",
    "cluster_cols": "Year,Month",
    "date_to_year": [],
}

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# MAGIC %md
# MAGIC #### Common global variables

# COMMAND ----------

MODE = "overwrite"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"BRONZE_CATALOG is:  {BRONZE_CATALOG}")
log.info(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.info(f"SILVER_CATALOG is:  {SILVER_CATALOG}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"ABS_SILVER_LATEST_TABLE is:  {ABS_SILVER_LATEST_TABLE}")
log.info(f"MODE is:  {MODE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks - Functions

# COMMAND ----------

# Imported from leap_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Tables Read
# MAGIC - Clean Data
# MAGIC - Hash columns
# MAGIC - Table Write

# COMMAND ----------

# Upload ABS_BRONZE_LATEST_TABLE
df_abs_bronze = spark.read.table(f"{ABS_BRONZE_LATEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------


def trim_columns(df, columns):
    """
    Trim leading and trailing whitespace characters from specified columns in a DataFrame.

    :param df: The Spark DataFrame to modify.
    :type df: SparkDataFrame
    :param columns: A list of column names to trim.
    :type columns: list
    :return: A new Spark DataFrame with the specified columns trimmed.
    :rtype: SparkDataFrame
    """
    for col in columns:
        df = df.withColumn(col, f.trim(f.col(col)))
    return df


def last_day_of_month(date_col):
    """
    Returns the last day of the month for the given date column.

    :param date_col: A Spark SQL Column representing a date.
    :type date_col: Column
    :return: A Spark SQL Column containing the last day of the month for each date in the input column.
    :rtype: Column
    """
    return f.last_day(date_col)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - _leap_extraction_date and _leap_year_month_extraction_date

# COMMAND ----------

# Add _leap_extraction_date
df_abs_bronze_start = df_abs_bronze.withColumn(
    "_leap_extraction_date", f.to_date(f.col("_meta_extraction_timestamp"))
).withColumn(
    "_leap_year_month_extraction_date",
    f.date_format(f.col("_leap_extraction_date"), "yyyy-MM"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Add _leap_calendar_date , _leap_year_month_calendar_date

# COMMAND ----------

df_abs_bronze_ym = df_abs_bronze_start.withColumn(
    "Month", f.lpad(f.col("Month"), 2, "0")
).withColumn(
    "_leap_year_month_calendar_date",
    f.concat(f.col("Year"), f.lit("-"), f.col("Month")),
)

df_abs_bronze_date = df_abs_bronze_ym.withColumn(
    "_leap_calendar_date",
    last_day_of_month(
        f.to_date(
            f.concat_ws("-", f.col("Year"), f.col("Month"), f.lit("01")), "yyyy-MM-dd"
        )
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - trim columns
# MAGIC
# MAGIC trim columns whose name like **'%_code'**
# MAGIC trim other specific columns

# COMMAND ----------

# Trim all columns in SILVER_ATTRS_DICT["columns_to_trim"]
df_abs_bronze_trim = trim_columns(
    df_abs_bronze_date, SILVER_ATTRS_DICT["columns_to_trim"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Replace null et blank by "0" and convert to int
# MAGIC

# COMMAND ----------

df_abs_bronze_notnull = df_abs_bronze_trim.fillna(
    "0", subset=SILVER_ATTRS_DICT["columns_to_replace_nulls_by_zero"]
)
df_abs_bronze_notnull = df_abs_bronze_notnull.replace(
    "", "0", subset=SILVER_ATTRS_DICT["columns_to_replace_nulls_by_zero"]
)

# Remove the " " from string columns
for col in SILVER_ATTRS_DICT["int_cols"]:
    df_abs_bronze_notnull = df_abs_bronze_notnull.withColumn(
        col, f.regexp_replace(f.col(col), " ", "")
    )

df_abs_bronze_int = df_abs_bronze_notnull
# Cast columns from string to int
for col in SILVER_ATTRS_DICT["int_cols"]:
    df_abs_bronze_int = df_abs_bronze_int.withColumn(col, f.col(col).cast("int"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 5 - Clean targets and convert to double
# MAGIC

# COMMAND ----------

df_abs_bronze_targets = df_abs_bronze_int
# Remove the " " from string columns
for col in SILVER_ATTRS_DICT["float_cols"]:
    df_abs_bronze_targets = (
        df_abs_bronze_targets.withColumn(col, f.regexp_replace(f.col(col), " ", ""))
        .withColumn(col, f.regexp_replace(f.col(col), "%", ""))
        .withColumn(col, f.regexp_replace(f.col(col), ",", ".").cast("double") / 100)
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 6 - Harmonize country names

# COMMAND ----------

# Dictionary of country names to normalize
country_translation_dict = {
    "Belgique": "Belgium",
    "Czech": "Czech Republic",
    "Cezch": "Czech Republic",
    "CZ": "Czech Republic",
    "Cz": "Czech Republic",
    "Česká republika": "Czech Republic",
    "Czech Rep.": "Czech Republic",
    "Allemagne": "Germany",
    "Espagne": "Spain",
    "Bresil": "Brazil",
    "Brésil": "Brazil",
    "Mexique": "Mexico",
    "Bulgarie": "Bulgaria",
    "BG": "Bulgaria",
    "Bg": "Bulgaria",
    "España": "Spain",
    "FR": "France",
    "Fr": "France",
    "Inde": "India",
    "Italie": "Italy",
    "Etat-Unis": "USA",
    "Maroc": "Morocco",
    "Marocco": "Morocco",
    "Tunisie": "Tunisia",
    "United Kingdom": "UK",
    "United States": "USA",
    "Sk": "Slovakia",
    # Add more countries here
}

# Replacement for all country pairs
df_abs_bronze_country = df_abs_bronze_targets.replace(
    country_translation_dict, subset="Country"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 7 - Harmonize workplace

# COMMAND ----------

df_abs_bronze_workplace = df_abs_bronze_country

# Dictionary of workplace to normalize
workplace_patterns_translation_dict = {
    "periole": "Toulouse-Périole",
    "périole": "Toulouse-Périole",
    "montredon": "Toulouse-Montredon",
    "gabardie": "Toulouse-Gabardie",
    "mach1": "Toulouse-Mach1",
    "nazaire": "Saint-Nazaire",
    "social": "Toulouse-Mach1",
    "merignac": "Dassault-Mérignac",
    "mérignac": "Dassault-Mérignac",
    "prague": "Praha",
    "casablanca": "Had-Soualem",
    "soualem": "Had-Soualem",
    "malaga": "Malaga",
    "jacareï": "Jacarei",
    "jacarei": "Jacarei",
    "belgaum": "Belagavi",
    "plovdiv": "Plovdiv",
    # Add more workplace here
}

workplace_columns = ["Workplace"]

for col in workplace_columns:
    # Start with the original column, then apply transformations
    new_col = f.col(col)

    # Apply each pattern from the `workplace_patterns` dictionary
    for pattern, replacement in workplace_patterns_translation_dict.items():
        new_col = f.when(f.lower(f.col(col)).contains(pattern), replacement).otherwise(
            new_col
        )

    # Update the normalized column in the DataFrame
    df_abs_bronze_workplace = df_abs_bronze_workplace.withColumn(col, new_col)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 8 - Clean _meta_ID

# COMMAND ----------

df_abs_bronze_id = df_abs_bronze_workplace.withColumn(
    "_meta_ID",
    f.concat(
        f.col("_leap_year_month_calendar_date"),
        f.lit("-"),
        f.col("Country"),
        f.lit("-"),
        f.col("Workplace"),
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------


def move_dataframe_cols_first(df: SparkDataFrame, cols_to_move: list) -> SparkDataFrame:
    """
    Move specified columns to the beginning of the DataFrame.

    :param df: The Spark DataFrame to modify.
    :type df: SparkDataFrame
    :param cols_to_move: A list of column names to move to the beginning of the DataFrame.
    :type cols_to_move: list
    :return: A new Spark DataFrame with the specified columns moved to the front.
    :rtype: SparkDataFrame
    """
    first_cols = cols_to_move
    other_cols = [c for c in df.columns if c not in first_cols]
    df_new = df.select(*first_cols, *other_cols)
    return df_new


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Optimize order of Columns

# COMMAND ----------

first_cols = list(TABLE_SILVER_FIRST_COLS.keys())
df_abs_silver_first = move_dataframe_cols_first(df_abs_bronze_id, first_cols)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

## Quality Checks - Common Functions defined in leap_utils

#### validate_and_log_gx_results()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - Uniqueness
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Quality checks with great_expectations : uniqueness for SILVER_ATTRS_DICT["primary_key"]
# Raise an Exception if not pass the checks
df_to_check = df_abs_silver_first
if (SILVER_ATTRS_DICT["primary_key"]) and (SILVER_ATTRS_DICT["primary_key"] != ""):
    gx_validation.gx_check_compound_uniqueness(
        df=df_to_check,
        cols=SILVER_ATTRS_DICT["primary_key"],
        validation_level="RED",
        pipeline_write_env=PIPELINE_WRITE_ENV,
        table_name="hr_absenteism_silver",
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 2 - Not null expectation
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Quality checks with great_expectations : notnull for SILVER_ATTRS_DICT["notnull_cols"]
# Raise an Exception if not pass the checks
notnull_columns = SILVER_ATTRS_DICT["notnull_cols"].split(",")
for one_col in notnull_columns:
    gx_validation.gx_check_not_null(
        df=df_to_check,
        col=one_col.strip(),
        validation_level="RED",
        pipeline_write_env=PIPELINE_WRITE_ENV,
        table_name="hr_absenteism_silver",
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by SILVER_ATTRS_DICT["cluster_cols"]
catalog, schema, table = ABS_SILVER_LATEST_TABLE.split(".")

try:
    table_utils.create_unity_catalog_table(
        catalog,
        schema,
        table,
        force_reinitialization=False,
        cluster_cols=SILVER_ATTRS_DICT["cluster_cols"],
        partition_col=None,
        primary_key_cols=None,
        columns=TABLE_SILVER_FIRST_COLS,
        force_drop=False,
    )
except AnalysisException as e:
    log.error(
        f"Table {ABS_SILVER_LATEST_TABLE} has not been created, an error occured during creation. \nError is {e}"
    )
    raise OSError(
        f"An error occurred while creating the table {ABS_SILVER_LATEST_TABLE}"
    ) from e

# COMMAND ----------

# Save the silver table from Dataframe df_abs_bronze_first, preserving cluster columns
try:
    startTime = time.time()
    table_utils.save_table(
        dest_table=ABS_SILVER_LATEST_TABLE,
        df=df_abs_silver_first,
        mode=MODE,
        overwrite_schema=True,
        cluster_cols=SILVER_ATTRS_DICT["cluster_cols"],
        merge_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {ABS_SILVER_LATEST_TABLE} has not been created, an error occured during table_utils.save_table . \nError is {e}"
    )
    raise OSError(
        f"An error occurred while saving the table {ABS_SILVER_LATEST_TABLE}"
    ) from e
else:
    duration = time.time() - startTime
    log.info(f"Table {ABS_SILVER_LATEST_TABLE} saved in {duration} seconds.")
    log.info(f"Wrote {df_abs_silver_first.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
