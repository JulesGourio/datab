# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # engineering_bigdbprd data_asset
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to create gold tables
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC Know how to use DLT features
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Production
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{pipeline_read_env}_silver.engineering_bigdbprd.*`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC -
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_gold.engineering_bigdbprd.*`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

from pyspark import pipelines as dp
import logging
from pyspark.sql import DataFrame as DataFrame
import pyspark.sql.functions as f
import pyspark.sql.types as t
from functools import reduce

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

# Add bundle_root to sys.path for leap_utils imports (when running from Asset Bundle)
import sys
bundle_root = spark.conf.get("bundle_root", "")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

pipeline_read_env_param = spark.conf.get("pipeline_read_env", "default_value")
pipeline_write_env_param = spark.conf.get("pipeline_write_env", "default_value")
reference_read_env_param = spark.conf.get("reference_read_env", "default_value")
bronze_catalog_param = spark.conf.get("bronze_catalog", "default_value")
target_schema_param = spark.conf.get("target_schema", "default_value")
pipeline_name_param = spark.conf.get("pipeline_name", "default_value")
log_level_param = spark.conf.get("log_level", "info")

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", pipeline_write_env_param)
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", pipeline_read_env_param)
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", reference_read_env_param)
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_name", pipeline_name_param)
PIPELINE_NAME = dbutils.widgets.get("pipeline_name")

dbutils.widgets.text("bronze_catalog", bronze_catalog_param)
BRONZE_CATALOG = dbutils.widgets.get("bronze_catalog")

dbutils.widgets.text("target_schema", target_schema_param)
BRONZE_SCHEMA = dbutils.widgets.get("target_schema")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue=log_level_param,
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_GOLD_FREQUENCIES = {
    "t_actionreport_ar": 1,
    "t_actionreportsnapshot_ars": 1,
    "t_checklist_chl": 1,
    "t_checkpoint_chp": 1,
    "t_checkresult_chr": 1,
    "t_checkstep_chs": 1,
    "t_checktopic_cht": 1,
    "t_fieldtype_fit": 1,
    "t_inflow_inf": 1,
    "t_inflowtype_int": 1,
    "t_productionplan_pp": 1,
    "t_reference_ref": 1,
    "t_user_use": 1,
    "t_userrole_usr": 1,
    "t_workflowcollection_woc": 1,
    "t_workflowfamily_wof": 1,
    "t_workflowstep_wos": 1,
    "t_workflowstepprocessing_wsp": 1,
    "tj_actionreportinflowconfiguration_aic": 1,
    "tj_actionreportinflowconfigurationsnapshot_ais": 1,
    "tj_aircraftprogramuserrole_apu": 1,
    "tj_checkstepcheckresult_csr": 1,
    "tj_referenceinflowconfiguration_ric": 1,
    "tj_workflowstepprocessingcheckpointresult_wpr": 1,
    "tj_workflowstepprocessingcheckresult_wsr": 1,
    "tj_workflowstepprocessinguserrole_wpu": 1,
    "tj_workflowstepuserrole_wsu": 1,
    "tj_workspace_wor": 1,
    "tr_aircraftprogram_aip": 1,
    "tr_aircraftversion_aiv": 1,
    "tr_customerprogram_cup": 1,
    "tr_holiextraday_hed": 1,
    "tr_site_sit": 1,
}
DEFAULT_FREQUENCY = 1

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SILVER_SCHEMA = "engineering_bigdbprd"

GOLD_CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
GOLD_SCHEMA = "engineering_bigdbprd"

ADD_PREFIX_TO_TABLES = "PROD_"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"GOLD_SCHEMA is:  {GOLD_SCHEMA}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Read Bronze Input Tables & Cast types
# MAGIC

# COMMAND ----------


def standardize_strings(df):
    """
    Replace '' -> NULL and trim() for all string columns.
    """
    exprs = []
    for field in df.schema.fields:
        c = f.col(field.name)
        if isinstance(field.dataType, t.StringType):
            # empty string -> NULL, then TRIM
            exprs.append(
                f.when(f.length(f.trim(c)) == 0, f.lit(None))
                .otherwise(f.trim(c))
                .alias(field.name)
            )
        else:
            exprs.append(c)
    return df.select(*exprs)


# ---------- create 1 silver table per bronze table ----------
def create_clean_silver_table(table_name: str):
    bronze_name = table_name + "_latest"
    final_name = ADD_PREFIX_TO_TABLES + table_name

    @dp.table(
        name=f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{final_name}",
        comment=f"Silver cleaned table derived from {bronze_name}",
        table_properties={"quality": "silver"},
    )
    def _create_silver_table():
        try:
            df_bronze_src = (
                spark.table(f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{bronze_name}")
                .filter(f.col("_meta_validity_check") == True)
                .drop("_rescued_data", "_meta_validity_check")
            )
        except Exception as e:
            log.warning(f"Erreur lecture table bronze {bronze_name}: {e}")
            return spark.createDataFrame([], t.StructType([]))

        try:
            df_bronze_drop = df_bronze_src.filter(
                f.col("_meta_validity_check") == True
            ).drop("_rescued_data", "_meta_validity_check")
            df_bronze_clean = standardize_strings(df_bronze_drop)
        except Exception as e:
            log.warning(f"Erreur dans standardize_strings: {e}")
            return df_bronze_src
        # Retourner le DataFrame avec les colonnes sélectionnées

        # Expectations minimales (facultatives). Adapte si tu connais la PK / colonnes obligatoires :
        # Ici on illustre : aucune ligne entièrement vide sur la 1re colonne
        first_col = df_bronze_clean.columns[0] if df_bronze_clean.columns else None
        if first_col:
            dp.expect(
                f"{final_name}_non_empty_{first_col}", f.col(first_col).isNotNull()
            )
        return df_bronze_clean


# COMMAND ----------


# ---------- create 1 gold table per bronze/silver table ----------
def create_clean_gold_table(table_name: str):
    gold_name = table_name

    @dp.table(
        name=f"{GOLD_CATALOG}.{GOLD_SCHEMA}.{gold_name}",
        comment=f"Gold cleaned table derived from {table_name}",
        table_properties={"quality": "gold"},
    )
    def _create_gold_table():
        try:
            df_gold = (
                dp.read(f"{SILVER_CATALOG}.{SILVER_SCHEMA}.{gold_name}")
                # put your enrichments below
            )
        except Exception as e:
            log.warning(f"Erreur lecture table silver {table_name}: {e}")
            return spark.createDataFrame([], t.StructType([]))

        # Retourner le DataFrame Gold
        return df_gold


# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 - Silver to Gold
# MAGIC

# COMMAND ----------

# ---------- create 1 silver table per bronze table ----------
for src_table, _ in SILVER_GOLD_FREQUENCIES.items():
    create_clean_silver_table(src_table)
    src_table_with_prefix = ADD_PREFIX_TO_TABLES + src_table
    create_clean_gold_table(src_table_with_prefix)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2 - Gold to Freshness

# COMMAND ----------

freshness_view_names = []


def create_freshness_view(
    source_table, table_name_short, frequency, schema_name, job_name, view_name
):
    @dp.view(name=view_name)
    def _generated_view():
        return (
            dp.read(source_table)
            .agg(
                f.max("_meta_ingestion_timestamp").alias("last_update_time"),
            )
            .withColumn("frequency", f.lit(frequency).cast("int"))
            .withColumn("schema_name", f.lit(schema_name))
            .withColumn("job_name", f.lit(job_name))
            .withColumn("table_name", f.lit(source_table))
            .withColumn("table_name_short", f.lit(table_name_short))
        )

    return _generated_view  # return is optional in this case


for src_table, freq_days in SILVER_GOLD_FREQUENCIES.items():
    frequency = freq_days or DEFAULT_FREQUENCY
    src_table_with_prefix = ADD_PREFIX_TO_TABLES + src_table
    frequency = "1"
    view_name = f"{src_table_with_prefix}_freshness"
    gold_src_table_full = f"{GOLD_CATALOG}.{GOLD_SCHEMA}.{src_table_with_prefix}"

    freshness_view_names.append(f"LIVE.{view_name}")

    # Appel pour générer une nouvelle vue avec nom unique (chaque appel génère une nouvelle fonction)
    create_freshness_view(
        source_table=gold_src_table_full,
        table_name_short=src_table_with_prefix,
        frequency=frequency,
        schema_name=GOLD_SCHEMA,
        job_name=PIPELINE_NAME,
        view_name=view_name,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 3 - Freshness to Freshness_all

# COMMAND ----------


@dp.table(
    name=f"{GOLD_CATALOG}.{GOLD_SCHEMA}.{PIPELINE_NAME}_freshness_all",
    comment="update_freshness_for_schema",
)
def update_freshness_all():
    dfs = [spark.table(name) for name in freshness_view_names]
    df_freshness = reduce(lambda a, b: a.unionByName(b), dfs)
    df_freshness = df_freshness.drop("table_name_short")
    return df_freshness


# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC # Hooks

# COMMAND ----------

# N/A
