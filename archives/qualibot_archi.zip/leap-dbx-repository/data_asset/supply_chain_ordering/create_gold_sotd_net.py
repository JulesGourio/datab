# Databricks notebook source
# MAGIC %md
# MAGIC    
# MAGIC
# MAGIC # S-OTD Net : Silver to Gold
# MAGIC
# MAGIC **Description:**  
# MAGIC This script enriches silver data with PO information, rescheduling and root cause type.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - UC9 S-OTD
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {PIPELINE_READ_ENV}_silver.supply_chain_ordering.sotd_net_history
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_sap_exposed
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.supply_chain_ordering.sotd_net_history

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import yaml

import pyspark.sql.functions as f
from pyspark.sql.window import Window
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# MAGIC %md
# MAGIC    
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset.table_utils import save_table
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

config_path = "config_sotd.yaml"
with open(config_path, "r") as file:
    config = yaml.safe_load(file)

ROOT_CAUSE_CODES_AND_FAMILIES = config["ROOT_CAUSE_CODES_AND_FAMILIES"]

ROOT_CAUSE_CODES = list(ROOT_CAUSE_CODES_AND_FAMILIES.keys())
ROOT_CAUSE_FAMILIES = [
    f"{key} - {family}" for key, family in ROOT_CAUSE_CODES_AND_FAMILIES.items()
]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.dropdown("init", "false", ["true", "false"])
INIT = dbutils.widgets.get("init").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC    
# MAGIC ### Debug & Logging

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC    
# MAGIC ## Config Logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

df_sotd_history = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.supply_chain_ordering.sotd_net_history"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - PO Gold table

# COMMAND ----------

df_purchase_order = spark.read.table(
        f"{REFERENCE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_sap_exposed")


# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get current run data (or keep all if init)

# COMMAND ----------

if INIT:
    df_sotd_net = df_sotd_history
else:
    df_sotd_net = df_sotd_history.filter(
        f.col("run_date") == f.current_date()
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Select and cast PO

# COMMAND ----------

df_purchase_order = df_purchase_order.select(
    f.col("PO_number").try_cast("string"),
    f.col("PO_item_number").try_cast("string"),
    f.col("PO_status").try_cast("string"),
).distinct()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr1. Enrich data

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr1.1 Join PO

# COMMAND ----------

# Join df_sotd & PO table to get status
df_sotd_net_enriched = df_sotd_net.join(df_purchase_order, on=["PO_number","PO_item_number"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr1.2 Add root cause code, type & family
# MAGIC
# MAGIC Two types : Supplier or Customer + family computed from configuration file

# COMMAND ----------

df_sotd_net_enriched = df_sotd_net_enriched.withColumn(
    "root_cause_code",
    f.when(
        f.upper(f.substring(f.col("root_cause_description"), 1, 2)).isin(ROOT_CAUSE_CODES),
        f.upper(f.substring(f.col("root_cause_description"), 1, 2)),
    ).otherwise(None),
).withColumn(
    "root_cause_type",
    f.when(f.col("root_cause_code").startswith("F"), "Supplier").when(
        f.col("root_cause_code").startswith("C"), "Customer"
    ),
)

# COMMAND ----------

mapping_expr = f.create_map(
    [f.lit(x) for pair in zip(ROOT_CAUSE_CODES, ROOT_CAUSE_FAMILIES) for x in pair]
)

df_sotd_net_enriched = df_sotd_net_enriched.withColumn(
    "root_cause_family",
    f.when(
        f.col("root_cause_code").isNotNull(), mapping_expr[f.col("root_cause_code")]
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr2. Filter columns to save

# COMMAND ----------

df_sotd_net_current = (
    df_sotd_net_enriched.withColumn(
        "business_id",
        f.concat_ws("-", "PO_number", "PO_item_number", "nb_month"),
    )
    .select(
        "business_id",
        "PO_number",
        "PO_item_number",
        "PO_status",
        "nb_month",
        "run_date",
        "ingestion_date",
        "requested_delivery_date",
        "root_cause_code",
        "root_cause_description",
        "root_cause_type",
        "root_cause_family",
        "supplier_comment",
        "final_OTD",
        "latecoere_comment",
    )
    .distinct()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr3. Get and update history
# MAGIC
# MAGIC 0. Get history if there is + stack new data
# MAGIC 1. Handle order lines uploaded multiple times :
# MAGIC     - if requested delivery date is different, it's post-poned and already handled
# MAGIC     - if requested delivery date is the same :
# MAGIC         - it might be a mistake so it's a duplicate -> we keep row ingested most recently
# MAGIC         - it's not a mistake and something changed ->same
# MAGIC 2. Remove rows not to count in collaboration : latecoere comment #TO BE DELETED - WRONG COLLABORATION#
# MAGIC
# MAGIC NB : if a row was to count again, it would simply be uploaded and the latest comment would not be #TO BE DELETED - WRONG COLLABORATION# anymore, so the row would be kept.
# MAGIC

# COMMAND ----------

dest_table = f"{PIPELINE_WRITE_ENV}_gold.supply_chain_ordering.sotd_net_history"

if INIT:
    df_sotd_net_full = df_sotd_net_current
else:
    df_history = spark.read.table(dest_table).filter(f.col("run_date") < f.current_date())
    df_sotd_net_full = df_history.unionByName(df_sotd_net_current, allowMissingColumns=True)

# COMMAND ----------

w = Window.partitionBy("PO_number", "PO_item_number", "requested_delivery_date").orderBy(
    f.col("ingestion_date").desc()
)

df_sotd_net_clean = (
    df_sotd_net_full.withColumn("_rn", f.row_number().over(w))
    .filter(f.col("_rn") == 1)
    .drop("_rn","ingestion_date")
    .filter((f.col("latecoere_comment") != "#TO BE DELETED - WRONG COLLABORATION#") | f.col("latecoere_comment").isNull())
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr3.1 Update cancelled PO data

# COMMAND ----------

# Set S-OTD Net value to '/' for cancelled PO (not to count it in scoring)
df_sotd_net_end = df_sotd_net_clean.withColumn(
    "final_OTD",
    f.when(f.col("PO_status") == "PO_Cancelled","/").otherwise(f.col("final_OTD"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks
# MAGIC
# MAGIC ## Quality Check 1 - New data

# COMMAND ----------

# Check 1 - Data not empty
if df_sotd_net_end.isEmpty():
    log.info("No data found after transformations. Check landingzone tables and ingestion_date filter if it's unexpected.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Check 2 - Uniqueness

# COMMAND ----------

dfgx = SparkDFDataset(df_sotd_net_end, persist=False)

gx_validation.validate_and_log_gx_results(
    quality_check_results=[
        dfgx.expect_column_values_to_be_unique(column="business_id"),
    ],
    validation_level="RED",
    info_message="RED checks passed: sotd_net_history (gold) business_id unique",
    error_message="RED check failed on sotd_net_history (gold) — duplicate business_id",
)

# COMMAND ----------

# MAGIC %md
# MAGIC    
# MAGIC # Outputs
# MAGIC
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

save_table(
    dest_table=dest_table,
    df=df_sotd_net_end,
    mode="overwrite",
    overwrite_schema=True,
    partition_col="nb_month",
)
