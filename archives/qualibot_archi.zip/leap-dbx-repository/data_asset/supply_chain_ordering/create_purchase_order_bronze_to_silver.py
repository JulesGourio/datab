# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purchase Order - Bronze to silver
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC This notebook performs the preparation and transformation of SAP ECC6 purchasing data for analytical and reporting use.  
# MAGIC The process includes:
# MAGIC - Loading and renaming raw input tables from EKPO, EKKO, EKET, EKES, EKKN, EKBE, and T001W
# MAGIC - Applying business-friendly column names and data types
# MAGIC - Joining relevant tables to construct a unified PO dataset enriched with delivery, confirmation, assignment, and history information
# MAGIC - Computing key purchasing KPIs such as remaining quantities, net/gross values, unit prices, and conversion rates
# MAGIC - Deriving PO statuses based on document and transactional history (goods/invoice receipts)
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - **[Transformations → PO Status Derivation]**: Logic combining both document flags and movement history to determine the current PO lifecycle status  
# MAGIC - **[Transformations → Accurate Date Selection]**: Multiple date sources (invoice, goods receipt, confirmation) prioritized to compute the most reliable PO activity date  
# MAGIC - **[Currency Handling]**: Decimal and currency conversions performed using TCURX/TCURR reference tables with dynamic year-based logic
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Name of pipeline(s) the script was built for.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekpo_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekko_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eket_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekes_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekkn_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekbe_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t024_latest`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_silver.supply_chain_ordering.purchase_order_sap`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.window import Window
from pyspark.sql import DataFrame
from pyspark.sql.utils import AnalysisException
import time

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils, amount_correction
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

# Logging imports
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

log = setup_applevel_logger(log_level=LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC
# MAGIC

# COMMAND ----------

# list of document type BSART been open
list_open_doc = ["FOP", "FOA", "FO", "FOTS", "FOF"]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### EKKO – Purchase Order Header
# MAGIC
# MAGIC This table contains header-level metadata for purchase orders.  
# MAGIC It includes:
# MAGIC - PO number
# MAGIC - Vendor account
# MAGIC - Document type
# MAGIC - Purchasing organization
# MAGIC - Currency
# MAGIC - Order creation dates
# MAGIC
# MAGIC Used to provide context for all associated EKPO line items.

# COMMAND ----------

df_ekko_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekko_latest"
)
df_ekko_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_ekko"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EKPO – Purchase Order Items
# MAGIC
# MAGIC This table contains line-level details of each purchase order (PO).  
# MAGIC Each row represents a specific item or service being procured. It includes information such as:
# MAGIC - Material number
# MAGIC - Quantity ordered
# MAGIC - Net price
# MAGIC - Delivery date
# MAGIC - Final delivery and invoice flags
# MAGIC
# MAGIC Used to analyze what was ordered, in what quantity, and at what price.

# COMMAND ----------

df_ekpo_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekpo_latest"
)
df_ekpo_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_ekpo"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EKET – Schedule Lines (Delivery Planning)
# MAGIC
# MAGIC Contains scheduling data for each purchase order item, including:
# MAGIC - Planned delivery dates
# MAGIC - Quantities to be delivered
# MAGIC - Actual delivered quantities
# MAGIC
# MAGIC This table supports tracking of delivery planning vs actuals, and enables computation of delivery progress.

# COMMAND ----------

df_eket_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eket_latest"
)
df_eket_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_eket"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EKES – Service Entry Sheets
# MAGIC
# MAGIC This table holds information about services rendered by vendors and confirmed in SAP.  
# MAGIC It includes:
# MAGIC - Quantities of service accepted
# MAGIC - Reference numbers (external confirmations)
# MAGIC - Confirmation dates and types (e.g., LA = noticed, AB = confirmed)
# MAGIC
# MAGIC Essential for service procurement tracking and confirmation reconciliation.

# COMMAND ----------

df_ekes_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekes_latest"
)
df_ekes_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_ekes"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EKKN – Account Assignment
# MAGIC
# MAGIC Links PO items to their cost objects (e.g., cost centers, internal orders, WBS elements).  
# MAGIC Fields include:
# MAGIC - Quantity assigned per cost object
# MAGIC - Account assignment category (e.g., K = cost center)
# MAGIC
# MAGIC Used for cost traceability and budgeting analysis.

# COMMAND ----------

df_ekkn_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekkn_latest"
)
df_ekkn_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_ekkn"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EKBE – PO History (Goods and Invoice Movements)
# MAGIC
# MAGIC Tracks historical transactions against each PO item, including:
# MAGIC - Goods receipts
# MAGIC - Invoice receipts
# MAGIC - Returns and cancellations
# MAGIC
# MAGIC Each record reflects a movement type (e.g., 101 = GR, 105 = Return) and the corresponding quantity/value.  
# MAGIC Key for determining PO execution and current status.
# MAGIC
# MAGIC

# COMMAND ----------

df_ekbe_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekbe_latest"
)
df_ekbe_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_ekbe"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### T024 - Purchasing group customizing
# MAGIC

# COMMAND ----------

df_t024 = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t024_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC This notebook section handles the initial preparation of "raw" SAP datasets for downstream transformations.
# MAGIC
# MAGIC ✅ This includes:
# MAGIC - Column renaming using business metadata
# MAGIC - Column filtering or selection
# MAGIC - Dataset-specific enrichments (without joins)
# MAGIC
# MAGIC ⚠️ Note: These are preparatory steps to enable consistency, clarity, and clean structure across datasets before more complex processing.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1- EKKO Dataset
# MAGIC
# MAGIC This cell:
# MAGIC - Prefixes columns with `EKKO_`
# MAGIC - Applies business name mappings from headers
# MAGIC - Casts data types accordingly
# MAGIC - Renames `document_number` to `PO_number` for consistency

# COMMAND ----------

df_ekko = table_utils.add_prefix_to_columns(df_ekko_raw, "EKKO")
# Call Function Delete rows null
df_name_ekko = delete_null_rows(df_ekko_header)
# Call Function Rename Columns according header file
df_column_ekko = table_utils.rename_columns_with_sap_business_header(
    df_ekko, df_name_ekko
)
# Call Funtion Create Columns on Date format
df_ekko = table_utils.cast_columns_with_sap_business_headers(
    df_column_ekko, df_name_ekko
)
df_ekko = df_ekko.filter(f.col("po_category") == "F")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 - EKPO Dataset
# MAGIC
# MAGIC This cell applies:
# MAGIC - Prefixing column names with `EKPO_`
# MAGIC - Renaming columns using SAP business headers
# MAGIC - Casting column formats
# MAGIC - Overriding technical fields with business-friendly names (`document_number` → `PO_number`, `item_number` → `PO_item_number`)

# COMMAND ----------

df_ekpo = table_utils.add_prefix_to_columns(df_ekpo_raw, "EKPO")
# Call Function Delete rows null
df_name_ekpo = delete_null_rows(df_ekpo_header)
# Call Function Rename Columns according header file
df_column_ekpo = table_utils.rename_columns_with_sap_business_header(
    df_ekpo, df_name_ekpo
)
# Call Funtion Create Columns on Date format
df_ekpo = table_utils.cast_columns_with_sap_business_headers(
    df_column_ekpo, df_name_ekpo
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 - EKET Dataset
# MAGIC
# MAGIC This cell prepares and enriches the EKET data by:
# MAGIC - Prefixing and renaming columns
# MAGIC - Applying type casting
# MAGIC - Computing delivery quantities using window functions
# MAGIC - Retaining only the latest planned delivery record (`row_number == 1`)

# COMMAND ----------

df_eket = table_utils.add_prefix_to_columns(df_eket_raw, "EKET")
# Call Function Delete rows null
df_name_eket = delete_null_rows(df_eket_header)
# Call Function Rename Columns according header file
df_column_eket = table_utils.rename_columns_with_sap_business_header(
    df_eket, df_name_eket
)
# Call Funtion Create Columns on Date format
df_eket = table_utils.cast_columns_with_sap_business_headers(
    df_column_eket, df_name_eket
)
# ----------------------------------------------------------------------
# For one row in ekpo, ie one (material; PO), it may have multiple rows of EKET,
# which means multiple delivery dates. It is not allowed in SAP but it happens sometime.
# It has been decided to keep only first row of eket and to red flag when there are multiples deliveries.
eket_partition_col = ["PO_number", "PO_item_number"]
eket_ordering_col = ["delivery_date_planned"]
eket_sum_col = [
    "quantity_planned",
    "quantity_delivered",
]
w = Window.partitionBy(*eket_partition_col).orderBy(f.desc(*eket_ordering_col))
df_eket = (
    df_eket.withColumn(eket_sum_col[0], f.sum(eket_sum_col[0]).over(w))
    .withColumn(eket_sum_col[1], f.sum(eket_sum_col[1]).over(w))
    .withColumn("number_due_date", f.count(eket_ordering_col[0]).over(w))
    .withColumn("rn", f.row_number().over(w))
    .filter(f.col("rn") == 1)
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 4 - EKES Dataset
# MAGIC
# MAGIC This cell:
# MAGIC - Prefixes and renames EKES columns using metadata
# MAGIC - Casts types based on headers
# MAGIC - Uses windowing to capture only the latest confirmation record per PO item

# COMMAND ----------

df_ekes = table_utils.add_prefix_to_columns(df_ekes_raw, "EKES")
# Call Function Delete rows null
df_name_ekes = delete_null_rows(df_ekes_header)
# Call Function Rename Columns according header file
df_column_ekes = table_utils.rename_columns_with_sap_business_header(
    df_ekes, df_name_ekes
)
# Call Funtion Create Columns on Date format
df_ekes = table_utils.cast_columns_with_sap_business_headers(
    df_column_ekes, df_name_ekes
)
# ----------------------------------------------------------------------
ekes_partition_col = ["PO_number", "PO_item_number", "confirmation_type"]
ekes_ordering_col = ["confirmation_date"]
w = Window.partitionBy(*ekes_partition_col).orderBy(f.desc(*ekes_ordering_col))

df_ekes = (
    df_ekes.withColumn("number_conf_date", f.count(ekes_ordering_col[0]).over(w))
    .withColumn("quantity_confirmed", f.sum("quantity_confirmed").over(w))
    .withColumn("rn", f.row_number().over(w))
    .filter(f.col("rn") == 1)
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 5 - EKKN Dataset
# MAGIC
# MAGIC This cell:
# MAGIC - Applies consistent renaming and type casting to EKKN fields
# MAGIC - Uses windowing to count and retain only the top-ranked assignment entry (based on assigned quantity)

# COMMAND ----------

df_ekkn = table_utils.add_prefix_to_columns(df_ekkn_raw, "EKKN")
# Call Function Delete rows null
df_name_ekkn = delete_null_rows(df_ekkn_header)
# Call Function Rename Columns according header file
df_column_ekkn = table_utils.rename_columns_with_sap_business_header(
    df_ekkn, df_name_ekkn
)
# Call Funtion Create Columns on Date format
df_ekkn = table_utils.cast_columns_with_sap_business_headers(
    df_column_ekkn, df_name_ekkn
)
# ----------------------------------------------------------------------
ekkn_partition_col = ["po_number", "po_item_number"]
ekkn_ordering_col = ["scheduled_quantity"]
w = Window.partitionBy(*ekkn_partition_col).orderBy(f.desc(*ekkn_ordering_col))
df_ekkn = (
    df_ekkn.withColumn("rn", f.row_number().over(w)).filter(f.col("rn") == 1).drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 6 - EKBE Dataset
# MAGIC
# MAGIC This complex transformation:
# MAGIC - Renames and casts EKBE columns
# MAGIC - Maps operation types (1 → `Goods_Receipt`, 2 → `Invoice_Receipt`)
# MAGIC - Adjusts quantity signs based on debit/credit indicator
# MAGIC - Pivots and aggregates history by PO and item
# MAGIC - Derives status fields to reflect invoicing progress (completed/uncompleted) and enriches the dataset accordingly

# COMMAND ----------

df_ekbe = table_utils.add_prefix_to_columns(df_ekbe_raw, "EKBE")
# Call Function Delete rows null
df_name_ekbe = delete_null_rows(df_ekbe_header)
# Call Function Rename Columns according header file
df_column_ekbe = table_utils.rename_columns_with_sap_business_header(
    df_ekbe, df_name_ekbe
)
# Call Funtion Create Columns on Date format
df_ekbe = table_utils.cast_columns_with_sap_business_headers(
    df_column_ekbe, df_name_ekbe
)
# ----------------------------------------------------------------------
# EKBE Cleaning and Select
df_ekbe_temp = df_ekbe.select(
    "PO_number",
    "PO_item_number",
    "operation_type",
    "debitcredit_indicator",
    "posting_date",
    "quantity",
    "posting_date",
    "EKBE_lfgja",
    "EKBE_lfbnr",
    "EKBE_lfpos",
)
df_ekbe_temp = df_ekbe_temp.where(f.col("Operation_Type").isin("1", "2"))
df_ekbe_temp = df_ekbe_temp.withColumn(
    "new_operation_type",
    f.when(f.col("operation_type") == 2, 2).otherwise(f.col("operation_type")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC This section performs the core transformations on the SAP datasets. It includes logic such as:
# MAGIC - Multi-table joins
# MAGIC - Business logic derivation
# MAGIC - Status enrichment
# MAGIC - Field prioritization
# MAGIC - Metric calculation (e.g. quantities, prices, flags)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 0 – Add Purchase group information

# COMMAND ----------

df_t024 = df_t024.select(
    f.col("ekgrp").alias("purchasing_group"),
    f.col("eknam").alias("purchasing_group_name"),
    f.col("smtp_addr").alias("purchasing_group_email"),
)

df_ekko_enriched = df_ekko.join(
    df_t024,
    ["purchasing_group"],
    "left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 – Combine PO with Headers, Agreements, Assignments, Confirmations
# MAGIC
# MAGIC This transformation progressively joins together:
# MAGIC - EKPO (PO items) with EKKO (PO header)
# MAGIC - EKET (delivery schedule)
# MAGIC - EKKN (account assignments)
# MAGIC - EKES (vendor confirmations: LA & AB categories)
# MAGIC
# MAGIC It creates a unified view of each PO line enriched with all relevant dimensions.

# COMMAND ----------

# Join EKPO (PO items) with EKKO (PO header)
df_ekko_ekpo = df_ekko_enriched.join(df_ekpo, ["PO_number"], "inner")
# ---------------------------------------------------------------------------------
# Add EKET - Agreement
df_ekko_ekpo_eket = df_ekko_ekpo.join(df_eket, ["PO_number", "PO_item_number"], "left")
# ---------------------------------------------------------------------------------
# Add EKKN - Assignment
df_ekko_ekpo_eket_ekkn = df_ekko_ekpo_eket.join(
    df_ekkn, ["PO_number", "PO_item_number"], "left"
)
# ---------------------------------------------------------------------------------
# Join EKES - Confirmation date
df_ekes_temp = df_ekes.select(
    "PO_number",
    "PO_item_number",
    "confirmation_type",
    "confirmation_date",
    "quantity_confirmed",
    "confirmation_text",
    "number_conf_date",
)

df_ekes_la = df_ekes_temp.filter(f.col("confirmation_type") == "LA").drop(
    "confirmation_type"
)
df_ekes_la = table_utils.add_prefix_to_columns(df_ekes_la, "LA").withColumnsRenamed(
    {
        "LA_PO_number": "PO_number",
        "LA_PO_item_number": "PO_item_number",
    }
)
df_ekko_ekpo_eket_ekkn_ekes = df_ekko_ekpo_eket_ekkn.join(
    df_ekes_la, ["PO_number", "PO_item_number"], "left"
)

df_ekes_ab = df_ekes_temp.filter(f.col("confirmation_type") == "AB").drop(
    "confirmation_type"
)
df_ekes_ab = table_utils.add_prefix_to_columns(df_ekes_ab, "AB").withColumnsRenamed(
    {
        "AB_PO_number": "PO_number",
        "AB_PO_item_number": "PO_item_number",
    }
)
df_po_join = df_ekko_ekpo_eket_ekkn_ekes.join(
    df_ekes_ab, ["PO_number", "PO_item_number"], "left"
)
# ---------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr.  2 - Merge PO Status with EKBE History
# MAGIC
# MAGIC This step merges the previously derived document-based status with the EKBE status.
# MAGIC It resolves conflicts and edge cases to produce the final `document_status` field used across reports.  
# MAGIC Target is to determine the status of purchase order when a reception is done. We could have PO invoiced when an invoice is created or PO received when we have only reception and invoice not created yet.  
# MAGIC It's also necessary to manage all cancellation document. That's for why we use EKBE History in order to manage this part.  

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr.2.1 : Remove EKBE from deleted PO

# COMMAND ----------

df_po_for_filtering = df_po_join.select("PO_number", "PO_item_number")
df_step_1 = df_ekbe_temp.join(
    df_po_for_filtering, ["PO_number", "PO_item_number"], "inner"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 2.2 : Remove Cancelled rows and associated entry rows

# COMMAND ----------

# First window is to calculate the number of canceled row per document_id
# "EKBE_lfgja", "EKBE_lfbnr", "EKBE_lfpos")
w1 = Window().partitionBy(
    "PO_number", "PO_item_number", "new_operation_type", "quantity"
)
df_step_2 = df_step_1.withColumn(
    "Nb_H_per_key", f.count(f.when(f.col("debitcredit_indicator") == "H", 1)).over(w1)
)
df_step_2 = df_step_2.withColumn("Nb_H_per_key", f.max(f.col("Nb_H_per_key")).over(w1))

df_step_2 = df_step_2.withColumn(
    "Nb_S_per_key", f.count(f.when(f.col("debitcredit_indicator") == "S", 1)).over(w1)
)
df_step_2 = df_step_2.withColumn("Nb_S_per_key", f.max(f.col("Nb_S_per_key")).over(w1))

# Second window is for ordering and adding an ordered row number depending the date
w2 = (
    Window()
    .partitionBy(
        "PO_number",
        "PO_item_number",
        "new_operation_type",
        "quantity",
        "debitcredit_indicator",
    )
    .orderBy("posting_date")
)
df_step_2 = df_step_2.withColumn("row_number", f.row_number().over(w2))

# Keep only Entries that have not been cancelled
# Entries to keep are those that have a row number strictly greater than the number of total canceled row
df_step_2 = df_step_2.where(
    (
        (f.col("debitcredit_indicator") == "S")
        & (f.col("row_number") > f.col("Nb_H_per_key"))
    )
    | ((f.col("debitcredit_indicator") == "H") & (f.col("Nb_S_per_key") == 0))
)

# Third window is to calculate the number of canceled row per document_id
# ("EKBE_lfgja", "EKBE_lfbnr", "EKBE_lfpos")
w3 = Window().partitionBy("PO_number", "PO_item_number", "new_operation_type")
df_step_2 = df_step_2.withColumn(
    "total_quantity_H_per_key_2",
    f.sum(f.when(f.col("debitcredit_indicator") == "H", f.col("quantity"))).over(w3),
)

w4 = (
    Window()
    .partitionBy(
        "PO_number", "PO_item_number", "new_operation_type", "debitcredit_indicator"
    )
    .orderBy("posting_date")
    .rowsBetween(Window.unboundedPreceding, 0)
)
df_step_2 = df_step_2.withColumn(
    "cumulative_quantity_per_operation_type_2", f.sum("quantity").over(w4)
)
# --------------------------------------------------------------------------
df_step_2 = df_step_2.withColumn(
    "quantity_remaining_S",
    f.when(
        f.col("cumulative_quantity_per_operation_type_2")
        <= f.col("total_quantity_H_per_key_2"),
        0,
    ).otherwise(
        f.when(
            (
                f.col("cumulative_quantity_per_operation_type_2")
                - f.col("total_quantity_H_per_key_2")
            )
            < f.col("quantity"),
            f.col("cumulative_quantity_per_operation_type_2")
            - f.col("total_quantity_H_per_key_2"),
        ).otherwise(f.col("quantity"))
    ),
)
df_step_2 = df_step_2.withColumn(
    "quantity_remaining_S",f.col("quantity_remaining_S").cast("double"))
df_step_2 = df_step_2.where(
    (f.col("debitcredit_indicator") == "S") & (f.col("quantity_remaining_S") != 0)
)
df_step_2 = df_step_2.withColumn("quantity", f.col("quantity_remaining_S"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR. 2.3 : Adjust GRs quantity
# MAGIC 1. Retrieve how many are in invoices statut
# MAGIC 2. Delete GRs that became Invoice
# MAGIC 3. Adjust GRs with quantity changed

# COMMAND ----------

# Delete GR that became Invoice
# 1. Calculate the cumulative sum quantity per operation type in an ordered way (from oldest to newest)
# 2. Calculate the total quantity of Invoices and GR
# 3. Calculate the quantity of remaining GR:
#   - If cumulative quantity is less thant the total invoice then there are GR becomes an Invoice
#   - Else there are GR remaining (a specific case is handled when quantity of GR should be adjusted)
w_1 = (
    Window()
    .partitionBy(
        "PO_number",
        "PO_item_number",
        "new_operation_type",
        "EKBE_lfgja",
        "EKBE_lfbnr",
        "EKBE_lfpos",
    )
    .orderBy("posting_date")
    .rowsBetween(Window.unboundedPreceding, 0)
)
df_step_3 = df_step_2.withColumn(
    "cumulative_quantity_per_operation_type_1", f.sum("quantity").over(w_1)
)
# --------------------------------------------------------------------------
w_2 = Window().partitionBy(
    "PO_number", "PO_item_number", "EKBE_lfgja", "EKBE_lfbnr", "EKBE_lfpos"
)

df_step_3 = df_step_3.withColumn(
    "total_quantity_invoices_1",
    f.max(
        f.when(
            f.col("new_operation_type") == 2,
            f.col("cumulative_quantity_per_operation_type_1"),
        )
    ).over(w_2),
)
df_step_3 = df_step_3.withColumn(
    "total_quantity_GR_1",
    f.max(
        f.when(
            f.col("new_operation_type") == 1,
            f.col("cumulative_quantity_per_operation_type_1"),
        )
    ).over(w_2),
)
# -----------------------------------------------------------------
df_step_3 = df_step_3.withColumn(
    "quantity_remaining_GR_1",
    f.when(
        f.col("cumulative_quantity_per_operation_type_1")
        <= f.col("total_quantity_invoices_1"),
        0,
    ).otherwise(
        f.when(
            (
                f.col("cumulative_quantity_per_operation_type_1")
                - f.col("total_quantity_invoices_1")
            )
            < f.col("quantity"),
            f.col("quantity") - f.col("total_quantity_invoices_1"),
        ).otherwise(f.col("quantity"))
    ),
)
df_step_3 = df_step_3.withColumn(
    "quantity_remaining_INV_1",
    f.when(
        f.col("cumulative_quantity_per_operation_type_1")
        <= f.col("total_quantity_GR_1"),
        0,
    ).otherwise(
        f.when(
            (
                f.col("cumulative_quantity_per_operation_type_1")
                - f.col("total_quantity_GR_1")
            )
            < f.col("quantity"),
            f.col("cumulative_quantity_per_operation_type_1")
            - f.col("total_quantity_GR_1"),
        ).otherwise(f.col("quantity"))
    ),
)

df_step_3 = df_step_3.where(
    (f.col("new_operation_type") == 2) | (f.col("quantity_remaining_GR_1") != 0)
)
df_step_3 = df_step_3.withColumn(
    "quantity",
    f.when(
        f.col("new_operation_type") == 1, f.col("quantity_remaining_GR_1")
    ).otherwise(f.col("quantity")),
)
df_step_3 = df_step_3.withColumn("quantity", f.round(f.col("quantity"), 4))
# -------------------------------------------------------------------------
w_3 = (
    Window()
    .partitionBy("PO_number", "PO_item_number", "new_operation_type")
    .orderBy("posting_date")
    .rowsBetween(Window.unboundedPreceding, 0)
)

df_step_3 = df_step_3.withColumn(
    "cumulative_quantity_per_operation_type_2", f.sum("quantity").over(w_3)
)
# -------------------------------------------------------------------------
w_4 = Window().partitionBy("PO_number", "PO_item_number")
df_step_3 = df_step_3.withColumn(
    "total_quantity_invoices_2",
    f.sum(
        f.when((f.col("new_operation_type") == 2), f.col("quantity_remaining_INV_1"))
    ).over(w_4),
)
# -------------------------------------------------------------------------

df_step_3 = df_step_3.withColumn(
    "quantity_remaining_GR_2",
    f.when(
        f.col("cumulative_quantity_per_operation_type_2")
        <= f.col("total_quantity_invoices_2"),
        0,
    ).otherwise(
        f.when(
            (
                f.col("cumulative_quantity_per_operation_type_2")
                - f.col("total_quantity_invoices_2")
            )
            < f.col("quantity"),
            f.col("cumulative_quantity_per_operation_type_2")
            - f.col("total_quantity_invoices_2"),
        ).otherwise(f.col("quantity"))
    ),
)
df_step_3 = df_step_3.withColumn("quantity", f.round(f.col("quantity"), 4))

df_step_3 = df_step_3.where(
    (f.col("new_operation_type") == 2) | (f.col("quantity_remaining_GR_2") != 0)
)
df_step_3 = df_step_3.withColumn(
    "quantity",
    f.when(
        f.col("new_operation_type") == 1, f.col("quantity_remaining_GR_2")
    ).otherwise(f.col("quantity")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 2.4 : Append PO In progress and select columns for final table (drop columns created for calculations)

# COMMAND ----------

df_ekbe_final = df_step_3.select(
    "PO_number", "PO_item_number", "new_operation_type", "posting_date", "quantity"
)

df_ekbe_final = df_ekbe_final.withColumn(
    "statut", f.when(f.col("new_operation_type") == 1, "GR").otherwise("INV")
).drop("new_operation_type")
df_ekbe_final = df_ekbe_final.withColumnRenamed("posting_date", "date")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 2.5 : Determine Status of PO

# COMMAND ----------

df_statut = df_ekbe_final.withColumn(
    "INV", f.when(f.col("statut") == "INV", (f.col("quantity"))).otherwise(0)
)
df_statut = df_statut.withColumn(
    "GR", f.when(f.col("statut") == "GR", (f.col("quantity"))).otherwise(0)
)
df_statut = df_statut.groupBy("PO_number", "PO_item_number").agg(
    f.sum("INV").alias("sum_INV"), f.sum("GR").alias("sum_GR")
)
df_statut = df_statut.withColumn(
    "PO_status_from_history",
    f.when((f.col("sum_GR") == 0) & (f.col("sum_Inv") > 0), (f.lit("PO_Invoiced")))
    .when((f.col("sum_GR") > 0) & (f.col("sum_Inv") >= 0), (f.lit("PO_Received")))
    .otherwise(f.lit(None)),
)
df_gr_silver = df_statut.filter(f.col("PO_status_from_history") == "PO_Received").drop("sum_INV")
df_statut = df_statut.drop("sum_GR", "sum_INV")

df_join_po_status = df_po_join.join(df_statut, ["PO_Number", "PO_Item_Number"], "left")

# COMMAND ----------

df_gr_silver = table_utils.remove_leading_zeros(
    df=df_gr_silver,
    column_names=[
        "PO_number",
        "PO_item_number",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 – Management of Wrong SAP decimal for spécific currency (TND, JPY,...)
# MAGIC

# COMMAND ----------

df_po_corrected = amount_correction.create_corrected_amounts(
    df_join_po_status, "net_price", "PO_currency"
)
df_po_corrected = amount_correction.create_corrected_amounts(
    df_po_corrected, "global_price", "PO_currency"
)
df_po_corrected = df_po_corrected.drop("net_price", "global_price")
df_po_corrected = df_po_corrected.withColumnRenamed(
    "net_price_corrected", "net_price"
).withColumnRenamed("global_price_corrected", "global_price")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 4 – Update MRP_Unit
# MAGIC
# MAGIC AS MRP_Unit had been deployed 5 years ago, we have to fullfill MRP_unit for old PO.  
# MAGIC Need to make join with material master data.  

# COMMAND ----------

df_po_mrp = df_po_corrected.withColumn(
    "MRP_unit", f.coalesce(f.col("MRP_unit"), f.col("plant_delivered"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 5 – Business Indicator Flags
# MAGIC
# MAGIC This enrichment introduces business logic flags such as:
# MAGIC - Material presence
# MAGIC - Contract/Purchase request link
# MAGIC - Return flags
# MAGIC - Quantity planning validation
# MAGIC - Multi-due or confirmation detection
# MAGIC - Price or currency anomalies

# COMMAND ----------

# Create columns: indicators: material, return, multi ech, multi conf, quantity planned (1)
# Deletion indicator to be done after status definition
# (1) Quantity Planned flag = Order used to invoice an additional service (no marchandise)
df_po_info_final = (
    df_po_mrp.withColumn(
        "has_material_indicator",
        f.when(f.col("material_number").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .withColumn(
        "has_contract_indicator",
        f.when(f.col("contract_number").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .withColumn(
        "has_purchase_request_indicator",
        f.when(f.col("PR_number").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .withColumn(
        "is_returns_indicator",
        f.when(f.col("return_item_indicator") == "X", f.lit(True)).otherwise(
            f.lit(False)
        ),
    )
    .drop("return_item_indicator")
    .withColumn(
        "is_final_delivery_indicator",
        f.when(f.col("final_delivery_indicator") == "X", f.lit(True)).otherwise(
            f.lit(False)
        ),
    )
    .drop("final_delivery_indicator")
    .withColumn(
        "is_deletion_indicator",
        f.when(f.col("deletion_indicator").isNull(), f.lit(False)).otherwise(
            f.lit(True)
        ),
    )
    .drop("deletion_indicator")
    .withColumn(
        "is_invoice_indicator",
        f.when(f.col("associated_invoice_indicator") == "X", f.lit(True)).otherwise(
            f.lit(False)
        ),
    )
    .drop("associated_invoice_indicator")
    .withColumn(
        "is_PO_not_complete",
        f.when(f.col("PO_not_yet_complete") == "X", f.lit(True)).otherwise(
            f.lit(False)
        ),
    )
    .drop("PO_not_yet_complete")
    .withColumn(
        "is_multi_due",
        f.when(f.col("number_due_date") > 1, f.lit(True)).otherwise(f.lit(False)),
    )
    .drop("number_due_date")
    .withColumn(
        "is_multi_conf",
        f.when(
            (f.col("LA_number_conf_date") > 1) | (f.col("AB_number_conf_date") > 1),
            f.lit(True),
        ).otherwise(f.lit(False)),
    )
    .drop("LA_number_conf_date", "AB_number_conf_date")
    .withColumn(
        "is_total_value_one_indicator",
        f.when(f.col("global_price") == 1, f.lit(True)).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_no_quantity_planned_indicator",
        f.when(f.col("quantity_planned") == 0, f.lit(True)).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_one_cent_price_indicator",
        f.when(f.col("net_price") == 0.01, f.lit(True)).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_zero_price_indicator",
        f.when(
            (f.col("net_price") == 0) | (f.col("net_price").isNull()), f.lit(True)
        ).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_open_type",
        f.when(f.col("po_type").isin(list_open_doc), True).otherwise(False),
    )
    .withColumn(
        "is_in_validation_process",
        f.when(
            (
                (f.col("po_realease_indicator") == "6")
                & (f.col("po_release_status").isNotNull())
            ),
            True,
        ).otherwise(False),
    )
    .drop("po_realease_indicator", "po_release_status")
)
# Add source of data
df_po_end = df_po_info_final.withColumn("datasource", f.lit("SAP"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 6 - Cleaning Column on silver table

# COMMAND ----------

df_po_end = table_utils.remove_leading_zeros(
    df=df_po_end,
    column_names=[
        "PO_number",
        "PO_item_number",
        "material_number",
        "supplier_material_number",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# create primary key
df_po_end = df_po_end.withColumn(
    "PO_item_ID", f.concat_ws("-", f.col("PO_number"), f.col("PO_item_number"))
)

df_to_check = df_po_end
col_pk = "PO_item_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for PO table, please check log messages",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "supply_chain_ordering"
DESTINATION_TABLE_PO = "purchase_orders_sap"
DESTINATION_TABLE_GR = "purchase_orders_gr_without_invoices_sap"
DESTINATION_TABLE_FULL_PATH_PO = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE_PO}"
DESTINATION_TABLE_FULL_PATH_GR = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE_GR}"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - SILVER PO 

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH_PO,
        df=df_po_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH_PO} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH_PO} saved in {duration} seconds.")
    log.info(f"Wrote {df_po_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - SILVER GR 

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH_GR,
        df=df_gr_silver,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH_GR} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH_GR} saved in {duration} seconds.")
    log.info(f"Wrote {df_gr_silver.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "silver_po_pk"
TABLE_PK_COLS = "PO_item_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE_PO}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH_PO, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH_PO,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
