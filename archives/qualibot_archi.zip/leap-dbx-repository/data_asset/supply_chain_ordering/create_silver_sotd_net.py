# Databricks notebook source
# MAGIC %md
# MAGIC    
# MAGIC
# MAGIC # S-OTD Net : Bronze to Silver
# MAGIC
# MAGIC **Description:**  
# MAGIC S-OTD Net represents the delivery performance reviewed by the customer and validated by Latécoère.
# MAGIC
# MAGIC Data is provided by the business through the LEAP Depot application (leap_depot). This script gets, cleans and stacks uploaded data in a silver history.
# MAGIC
# MAGIC Process:
# MAGIC - Each month, on the 7th, Gross S-OTD reference file is computed and sent to business
# MAGIC - They have 2 weeks (in theory) to handle all "issues" : approve or disapprove bad OTD (0%)
# MAGIC - Business users upload back a partial S-OTD Net file (= final validated delivery performance)
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - UC9 S-OTD
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {PIPELINE_READ_ENV}_landingzone.leap_depot_uc9_sotd.sotd_net_history
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.supply_chain_ordering.sotd_net_history

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import yaml

import pyspark.sql.functions as f
from pyspark.sql.window import Window
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset.table_utils import save_table, remove_leading_zeros
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC    
# MAGIC ## Config File

# COMMAND ----------

config_path = "config_sotd.yaml"
with open(config_path, "r") as file:
    config = yaml.safe_load(file)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config data period used
# MAGIC
# MAGIC Data period = period during which the data was uploaded, no matter the delivery date

# COMMAND ----------

DEFAULT_DATA_PERIOD = config["DEFAULT_DATA_PERIOD"]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets
# MAGIC
# MAGIC Regular widgets for read and write env + :
# MAGIC - **init** : whether we compute initialization, default to False. If True, all history is computed and written, and all deposited files in leap depot are handled (start from beginning). If False, compute only S-OTD Net for file deposited previous day and append it to history.
# MAGIC - **data_period_to_use (int)** : get data uploaded during the last *data_period* days. For example 5 : get and use data from the past 5 days. Default to 1. If initialization, we get all data.

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.dropdown("init", "false", ["true", "false"])
INIT = dbutils.widgets.get("init").lower() == "true"

dbutils.widgets.text("ingestion_period_to_get", str(DEFAULT_DATA_PERIOD))
DATA_PERIOD = int(dbutils.widgets.get("ingestion_period_to_get"))

# COMMAND ----------

# MAGIC %md
# MAGIC    
# MAGIC ### Debug & Logging

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC    
# MAGIC ## Config Logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

history_landingzone = (
    f"{PIPELINE_READ_ENV}_landingzone.leap_depot_uc9_sotd.sotd_net_history"
)
df_sotd_history = spark.read.table(history_landingzone)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filter ingestion dates to handle
# MAGIC
# MAGIC If INIT is True, handle all ingestion dates, else, handle dates in ***[today - data_period, today]***

# COMMAND ----------

if INIT:
    df_sotd_net = df_sotd_history
else:
    df_sotd_net = df_sotd_history.filter(
        f.col("_meta_ingestion_timestamp")
        >= f.date_sub(f.current_date(), DATA_PERIOD)
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## EXIT if no new data

# COMMAND ----------

if df_sotd_net.isEmpty():
    dbutils.notebook.exit("No new file deposited in landingzone — skipping notebook")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Format columns

# COMMAND ----------

df_sotd_net = (
    df_sotd_net.withColumn(
        "requested_delivery_date",
        f.try_to_date(f.col("requested_delivery_date"), "yyyy-MM-dd"),
    )
    .withColumn(
        "requested_delivery_month",
        f.date_trunc("month", f.col("requested_delivery_date")),
    )
    .withColumn(
        "purchase_order_number",
        f.col("purchase_order_number").try_cast("string"),
    )
    .withColumn(
        "order_item",
        f.col("order_item").try_cast("string"),
    )
    .withColumn("final_OTD", f.col("final_OTD").try_cast("string"))
    .withColumn("ingestion_date", f.col("_meta_ingestion_timestamp").try_cast("date"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Clean Columns

# COMMAND ----------

df_sotd_net_renamed = df_sotd_net.withColumnsRenamed(
    {
        "purchase_order_number": "PO_number",
        "order_item": "PO_item_number",
    }
)

df_sotd_net_renamed = remove_leading_zeros(
    df_sotd_net_renamed, column_names=["PO_number", "PO_item_number"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr1. Format columns

# COMMAND ----------

df_sotd_net_formatted = (
    df_sotd_net_renamed.withColumn(
        "nb_month",
        f.to_date(
            f.col("requested_delivery_month"),
            "MM_yyyy_dd",
        ),
    ).drop("requested_delivery_month")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr2. Deduplicate

# COMMAND ----------

w = Window.partitionBy(
    "PO_number", "PO_item_number", "nb_month", "ingestion_date"
).orderBy(f.col("_meta_ingestion_timestamp").desc())

df_sotd_net_formatted = (
    df_sotd_net_formatted.withColumn("_rn", f.row_number().over(w))
    .filter(f.col("_rn") == 1)
    .drop("_rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr3. Add run date column

# COMMAND ----------

df_sotd_net_formatted = df_sotd_net_formatted.withColumn(
    "run_date",
    f.current_date(),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr4. Add primary key

# COMMAND ----------

df_sotd_net_formatted = df_sotd_net_formatted.withColumn(
    "business_id",
    f.concat_ws("-", "PO_number", "PO_item_number", "nb_month", "ingestion_date"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr5. Final selection on columns

# COMMAND ----------

df_sotd_net_end = df_sotd_net_formatted.select(
    f.col("business_id"),
    f.col("plant").try_cast("string"),
    f.col("supplier_code").try_cast("string"),
    f.col("nb_month"),
    f.col("run_date"),
    f.col("ingestion_date"),
    f.col("PO_number").try_cast("string"),
    f.col("PO_item_number").try_cast("string"),
    f.col("requested_delivery_date"),
    f.col("gross_otd").try_cast("int"),
    f.col("root_cause_description").try_cast("string"),
    f.col("supplier_comment").try_cast("string"),
    f.col("final_OTD").try_cast("string"),
    f.col("latecoere_comment").try_cast("string"),
).distinct()

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks
# MAGIC
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Check 1 - Did we find new data

# COMMAND ----------

if df_sotd_net_end.isEmpty():
    log.info("No data found after transformations. Check landingzone tables and ingestion_date filter if it's unexpected.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Check 2 - Uniqueness

# COMMAND ----------

dfgx = SparkDFDataset(df_sotd_net_end, persist=False)

gx_validation.validate_and_log_gx_results(
    quality_check_results=[
        dfgx.expect_column_values_to_be_unique(column="business_id"),
    ],
    validation_level="RED",
    info_message="RED checks passed: sotd_net_history (silver) business_id unique",
    error_message="RED check failed on sotd_net_history (silver) — duplicate business_id",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Check 3 - Not null

# COMMAND ----------

gx_validation.validate_and_log_gx_results(
    quality_check_results=[
        dfgx.expect_column_values_to_not_be_null(column="business_id"),
        dfgx.expect_column_values_to_not_be_null(column="PO_number"),
        dfgx.expect_column_values_to_not_be_null(column="PO_item_number"),
        dfgx.expect_column_values_to_not_be_null(column="nb_month"),
    ],
    validation_level="RED",
    info_message="RED checks passed: sotd_net_history (silver) business_id, PO_number, PO_item_number, nb_month not null",
    error_message="RED check failed on sotd_net_history (silver) — null values in key columns",
)

# COMMAND ----------

# MAGIC %md
# MAGIC    
# MAGIC # Outputs
# MAGIC
# MAGIC ## Output - LEAP Tables
# MAGIC
# MAGIC If INIT is True, we overwrite whole table, else, we append newly computed rows (or replace if job is run twice).

# COMMAND ----------

dest_table = f"{PIPELINE_WRITE_ENV}_silver.supply_chain_ordering.sotd_net_history"

if INIT:
    save_table(
        dest_table=dest_table,
        df=df_sotd_net_end,
        mode="overwrite",
        overwrite_schema=True,
        partition_col="nb_month",
    )
else:
    spark.sql(
        f"DELETE FROM {dest_table} WHERE ingestion_date >= date_sub(current_date(), {DATA_PERIOD})"
    )
    save_table(
        dest_table=dest_table,
        df=df_sotd_net_end,
        mode="append",
        overwrite_schema=False,
        merge_schema=True,
        partition_col="nb_month",
    )
