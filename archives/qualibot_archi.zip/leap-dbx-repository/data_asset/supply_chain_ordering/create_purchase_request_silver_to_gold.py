# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # SAP Request Orders – Final Gold Layer Transformation
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC
# MAGIC This notebook transforms SAP ECC6 purchase request (PR) data into a final Gold Layer dataset used for reporting and analytics.
# MAGIC It enriches the PR data with:
# MAGIC - Supplier and material master metadata
# MAGIC - Commodity hierarchy and direct/indirect classification
# MAGIC - Derived financial and traceability information
# MAGIC - Currency conversion into EUR
# MAGIC
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC
# MAGIC - Currency conversion with time-based rate logic
# MAGIC - Prioritization logic between material master and document-level metadata
# MAGIC - Indicator logic for traceability and classification
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Name of pipeline(s) the script was built for.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{PIPELINE_READ_ENV}_silver.supply_chain_ordering.purchase_requests_sap`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed`  
# MAGIC - `{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed`  
# MAGIC - `{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed`  
# MAGIC - `{REFERENCE_READ_ENV}_gold.finance.wbs_otp_exposed`  
# MAGIC - `{REFERENCE_READ_ENV}_gold.finance.wbs_otp_exposed`  
# MAGIC - `{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.zmmproccommod_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region`  
# MAGIC - `{REFERENCE_READ_ENV}_bronze.manual_input.mapping_plant_site`
# MAGIC
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_ordering.purchase_requests_sap`
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_ordering.purchase_requests_sap_exposed`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import Window
from datetime import datetime, timedelta
import time
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC Example:
# MAGIC - **Create_corrected_amounts** required for currency correction of SAP currencies with 3 digits
# MAGIC - **gx_validation** required for quality checks - **need "great-expectations" installed on the cluster**
# MAGIC - **logger** for inline logging
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils, business_rules, payment_term

from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not.
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### SILVER - Purchase Request 
# MAGIC
# MAGIC **df_silver_pr** 
# MAGIC
# MAGIC This is the processed PR dataset from the Silver layer, already structured from raw EBAN/EBKN sources.
# MAGIC Used as the base for enrichment and final Gold formatting.

# COMMAND ----------

df_silver_pr = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.supply_chain_ordering.purchase_requests_sap"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - Manual Mapping division site  
# MAGIC **df_bronze_site** Mapping site-division-region  
# MAGIC **df_bronze_site_plant** Mapping site-plant

# COMMAND ----------

df_bronze_site = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region"
)
df_bronze_site_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_plant_site"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - Commodity referential

# COMMAND ----------

df_bronze_commodity = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.zmmproccommod_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Supplier Master Data  
# MAGIC **df_gold_supplier**  Extraction Master Data Supplier

# COMMAND ----------

df_gold_supplier = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.supplier_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Material by plant
# MAGIC **df_gold_material** Extraction masterdata material

# COMMAND ----------

df_gold_material = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Profit Center
# MAGIC **df_gold_profitcenter** profit center master data

# COMMAND ----------

df_gold_profitcenter = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - WBS Master Data  
# MAGIC **df_gold_wbs**  Extraction Master Data Supplier  

# COMMAND ----------

df_gold_wbs = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.wbs_otp_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Plant Master Data  
# MAGIC **df_gold_plant**  Extraction Master Data plant

# COMMAND ----------

df_gold_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Company Master Data  
# MAGIC **df_gold_company**  Extraction Master Data Company 

# COMMAND ----------

df_gold_company = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Supplier Contract Master Data  
# MAGIC **df_gold_contract**  Extraction Master Data contract 

# COMMAND ----------

df_gold_contract = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.procurement_purchasing.purchasing_contract_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Planned Order Operation
# MAGIC **df_gold_operation**  Extraction planned order operation

# COMMAND ----------

df_gold_operation = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.production.planned_order_operation_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Source List
# MAGIC **df_gold_source_list**  Extraction source llist procurement

# COMMAND ----------

df_gold_source_list = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.procurement_purchasing.source_list"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP tables  
# MAGIC We need to extract bronze in otder to treat exceptionnal flow where a purchase request is created when we convert a planned order

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - PLAF (Planned Order)  
# MAGIC The PLAF table stores planned orders.

# COMMAND ----------

df_bronze_plaf_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.plaf_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - MKAL (Production Versions)
# MAGIC The MKAL table in SAP stores Production Versions for materials.

# COMMAND ----------

df_bronze_mkal_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mkal_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - PLPO (Task List Operations)
# MAGIC The PLPO table stores the operations (steps) of a task list (routing or master recipe).

# COMMAND ----------

df_bronze_plpo_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.plpo_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - PLAS (Task List Selection)  
# MAGIC The PLAS table stores the selection of operations and sequences within a task list

# COMMAND ----------

df_bronze_plas_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.plas_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - EINA (Purchasing Info Record - Header)
# MAGIC The EINA table stores purchasing organization–specific data for Purchasing Info Records on header level

# COMMAND ----------

df_bronze_eina_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eina_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - EINE (Purchasing Info Record - Item)  
# MAGIC The EINE table stores purchasing organization–specific data for Purchasing Info Records on item level

# COMMAND ----------

df_bronze_eine_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eine_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - RESB (Reservation from Production )  
# MAGIC The RESB table stores reservation from MRP

# COMMAND ----------

df_bronze_resb_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.resb_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 0 – Filter PR dataframe with only active PR

# COMMAND ----------

df_pr_filtered = df_silver_pr.filter(
    f.col("is_incomplete_document_memorytype_indicator") == False
).drop("is_incomplete_document_memorytype_indicator")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – Integration Purchase request from ICT
# MAGIC

# COMMAND ----------

PR_ICT = ["ZDA1", "ZDA2"]
df_pr_prepared = df_pr_filtered.withColumn(
    "supplier_code",
    f.when(f.col("PR_type").isin(PR_ICT), f.col("supplier_code_ict")).otherwise(
        f.col("supplier_code")
    ),
).drop("supplier_code_ict")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 - Select and translate Site mapping

# COMMAND ----------

df_bronze_site = (
    df_bronze_site.withColumnRenamed("site", "stock_site")
    .withColumn(
        "stock_site", f.translate("stock_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
    )
    .distinct()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 - Select Material Plant info

# COMMAND ----------

df_gold_material = df_gold_material.select(
    "material_number",
    f.col("plant").alias("plant_delivered"),
    f.col("profit_center").alias("profit_center_material"),
    f.col("material_group").alias("mat_material_group"),
    f.col("buyer").alias("mat_purchasing_group"),
    "mrp_controller",
    "decopling_point",
    "MRP_unit",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 4 - Select and rename Supplier Master Data

# COMMAND ----------

df_gold_supplier = df_gold_supplier.select(
    "supplier_code",
    "supplier_name",
    "supplier_country",
    "supplier_city",
    "supplier_category",
    "spend_category",
    "purchasing_organization",
    f.col("payment_term").alias("supplier_payment_term"),
    "incoterm_code",
    "incoterm_detail",
    "intercompany_flow",
    "is_supplier_a_distributor",
    "merchandise_group",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 6 – WBS master data

# COMMAND ----------

df_gold_wbs = df_gold_wbs.select(
    f.col("WBS_Code_Num").alias("WBS_element"), f.col("WBS_Code").alias("WBS_code")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 7 – Plant master data

# COMMAND ----------

df_gold_plant = df_gold_plant.toDF(*[c.lower() for c in df_gold_plant.columns])
df_gold_plant = df_gold_plant.select(
    f.col("plant").alias("plant_delivered"), f.col("company").alias("company_code")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 8 – Company master data

# COMMAND ----------

df_gold_company = df_gold_company.toDF(*[c.lower() for c in df_gold_company.columns])

df_gold_company = df_gold_company.select(
    f.col("company").alias("company_code"),
    f.col("company_description"),
    f.col("country").alias("company_country"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 9 – Supplier Contract

# COMMAND ----------

df_gold_contract_prepared = df_gold_contract.select(
    f.col("contract_number"),
    f.col("item_number").alias("contract_item_number"),
    f.col("contract_enablement"),
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 10 – Profit Center

# COMMAND ----------

df_gold_profitcenter = df_gold_profitcenter.toDF(
    *[c.lower() for c in df_gold_profitcenter.columns]
)

df_gold_profitcenter_prep = df_gold_profitcenter.select(
    f.col("profit_center_short").alias("profit_center"),
    f.col("short_description").alias("profit_center_description"),
    f.col("customer_group"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 11 – Commodity referential

# COMMAND ----------

df_commodity_prepared = df_bronze_commodity.select(
    f.col("matkl").alias("material_group_join"),
    f.col("sens").alias("direct_indirect"),
    f.col("commodity_l1").alias("commodity"),
    f.col("commodity_l2").alias("sub_commodity"),
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 12 – Purchase request comming from Planned Orders

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 12.1 – Select and formatting

# COMMAND ----------

# Prep Sap Plaf Table // keep only production element
df_bronze_plaf_prepared = df_bronze_plaf_raw.filter(f.col("plscn") == "000").select(
    f.col("plnum").alias("planned_order").try_cast("string"),
    f.try_to_date(f.col("psttr"), "yyyyMMdd").alias("start_planned_date"),
    f.try_to_date(f.col("pedtr"), "yyyyMMdd").alias("end_planned_date"),
    f.col("matnr").alias("material_number").try_cast("string"),
    f.col("gsmng").alias("quantity_request").try_cast("double"),
    f.col("plwrk").alias("plant").try_cast("string"),
    f.col("verid").alias("production_version").try_cast("string"),
    f.col("lgort").alias("storage_location").try_cast("string"),
    f.col("pspel").alias("WBS_Element").try_cast("string"),
)
df_bronze_plaf_prepared = table_utils.remove_leading_zeros(
    df_bronze_plaf_prepared, ["planned_order", "material_number", "production_version"]
)
# -----------------------------------------------------------------
# Prep Sap mkal Table
df_bronze_mkal_prepared = df_bronze_mkal_raw.select(
    f.col("plnnr").alias("routing_number").try_cast("string"),
    f.col("alnal").alias("routing_group").try_cast("string"),
    f.col("matnr").alias("material_number").try_cast("string"),
    f.col("werks").alias("plant").try_cast("string"),
    f.col("verid").alias("production_version").try_cast("string"),
)
df_bronze_mkal_prepared = table_utils.remove_leading_zeros(
    df_bronze_mkal_prepared,
    ["routing_number", "material_number", "production_version", "routing_group"],
)
# -----------------------------------------------------------------
# Prep Sap plas Table
df_bronze_plas_prepared = (
    df_bronze_plas_raw.filter(
        f.col("loekz").isNull() | (f.col("loekz") == "")  # exclude deleted sequences
    )
    .select(
        f.col("plnnr").alias("routing_number").try_cast("string"),
        f.col("plnal").alias("routing_group").try_cast("string"),
        f.col("plnkn").alias("node").try_cast("string"),
    )
    .distinct()
)
df_bronze_plas_prepared = table_utils.remove_leading_zeros(
    df_bronze_plas_prepared, ["routing_number", "node", "routing_group"]
)
# -----------------------------------------------------------------
# Prep Sap plpo Table
df_bronze_plpo_prepared = df_bronze_plpo_raw.select(
    f.col("plnnr").alias("routing_number").try_cast("string"),
    f.col("plnkn").alias("node").try_cast("string"),
    f.col("ltxa1").alias("description").try_cast("string"),
    f.col("werks").alias("plant").try_cast("string"),
    f.col("vornr").alias("operation").try_cast("string"),
    f.col("steus").alias("key").try_cast("string"),
    f.col("lifnr").alias("supplier_code").try_cast("string"),
    f.col("infnr").alias("info_records").try_cast("string"),
    f.col("esokz").alias("info_records_type").try_cast("string"),
    f.col("ebeln").alias("contract_number").try_cast("string"),
    f.col("ebelp").alias("contract_item_number").try_cast("string"),
    f.col("preis").alias("net_price").try_cast("double"),
    f.col("peinh").alias("price_base").try_cast("double"),
    f.col("waers").alias("currency").try_cast("string"),
    f.col("matkl").alias("material_group").try_cast("string"),
    f.col("ekorg").alias("purchasing_organization").try_cast("string"),
    f.col("ekgrp").alias("purchasing_group").try_cast("string"),
    f.col("bmeih").alias("PR_unit_of_measure").try_cast("string"),
    f.col("plifz").alias("lead_time").try_cast("string"),
)
df_bronze_plpo_prepared = table_utils.remove_leading_zeros(
    df_bronze_plpo_prepared,
    [
        "routing_number",
        "node",
        "operation",
        "contract_number",
        "contract_item_number",
        "info_records",
    ],
)
# -----------------------------------------------------------------
# Prep Gold operation scheduling
# Z011 operations don't exist in the gold operation table (no KBED capacity record).
# Strategy: get the earliest_scheduled_start_date of the NEXT operation as delivery_date.
df_gold_operation_prepared = df_gold_operation.select(
    f.col("plant").alias("go_plant").try_cast("string"),
    f.col("planned_order_number").alias("go_planned_order").try_cast("string"),
    f.col("planned_operation").alias("go_operation_num").try_cast("int"),
    f.col("earliest_scheduled_start_date").alias("delivery_date_planned"),
)
df_gold_operation_prepared = table_utils.remove_leading_zeros(
    df_gold_operation_prepared, ["go_planned_order"]
)
# -----------------------------------------------------------------
df_bronze_eina_prepared = df_bronze_eina_raw.select(
    f.col("infnr").alias("info_records").try_cast("string"),
    f.col("lifnr").alias("supplier_code_fia").try_cast("string"),
)
df_bronze_eina_prepared = table_utils.remove_leading_zeros(
    df_bronze_eina_prepared, ["info_records"]
)
# -----------------------------------------------------------------
df_bronze_eine_prepared = df_bronze_eine_raw.select(
    f.col("infnr").alias("info_records").try_cast("string"),
    f.col("ekorg").alias("purchasing_organization").try_cast("string"),
    f.col("esokz").alias("info_records_type").try_cast("string"),
    f.col("werks").alias("plant").try_cast("string"),
    f.col("netpr").alias("net_price_fia").try_cast("double"),
    f.col("peinh").alias("price_base_fia").try_cast("double"),
    f.col("bprme").alias("PR_unit_of_measure_fia").try_cast("string"),
    f.try_to_date(f.col("prdat"), "yyyyMMdd").alias("validity_date_fia"),
    f.col("waers").alias("currency_fia").try_cast("string"),
)
df_bronze_eine_prepared = table_utils.remove_leading_zeros(
    df_bronze_eine_prepared, ["info_records"]
)
# -----------------------------------------------------------------
df_bronze_einx_prepared = df_bronze_eina_prepared.join(
    df_bronze_eine_prepared, ["info_records"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 12.2 – Join Sap Bronze table

# COMMAND ----------

df_pr_from_plaf = (
    df_bronze_plaf_prepared.join(
        df_bronze_mkal_prepared,
        ["material_number", "plant", "production_version"],
        "left",
    )
    .join(df_bronze_plas_prepared, ["routing_number", "routing_group"], "left")
    .join(df_bronze_plpo_prepared, ["routing_number", "plant", "node"], "left")
    .join(
        df_bronze_einx_prepared,
        ["info_records", "purchasing_organization", "plant", "info_records_type"],
        "left",
    )
)
# Keep Only Sub_contracted operation
df_pr_from_plaf = df_pr_from_plaf.filter(f.col("key") == "Z011")
# -----------------------------------------------------------------
# Delivery date: earliest_scheduled_start_date of the NEXT operation (Z011 has no KBED entry)
df_pr_from_plaf = df_pr_from_plaf.withColumn(
    "operation_num", f.col("operation").try_cast("int")
)

df_pr_from_plaf = df_pr_from_plaf.join(
    df_gold_operation_prepared,
    on=[
        f.col("planned_order") == f.col("go_planned_order"),
        f.col("plant") == f.col("go_plant"),
        f.col("go_operation_num") > f.col("operation_num"),
    ],
    how="left",
)
# -----------------------------------------------------------------
# Keep only the closest next operation

w_prev = Window.partitionBy("planned_order", "plant", "operation").orderBy(
    f.col("go_operation_num").asc()
)

df_pr_from_plaf = (
    df_pr_from_plaf.withColumn("_rn", f.row_number().over(w_prev))
    .filter(f.col("_rn") == 1)
    .drop("_rn", "go_planned_order", "go_plant", "go_operation_num", "operation_num")
)
# -----------------------------------------------------------------
# Fallback: if no next operation found, use planned order end date
df_pr_from_plaf = df_pr_from_plaf.withColumn(
    "delivery_date_planned",
    f.coalesce(f.col("delivery_date_planned"), f.col("end_planned_date")),
)
# -----------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 12.3 – FallBack if supplier is not found

# COMMAND ----------

# In some case Supplier and price are not updated in PLPO table.
# We need to take information from EINE with inforecord found in PLPO table
df_pr_from_plaf_updated = (
    df_pr_from_plaf.withColumn(
        "net_price",
        f.when(
            (f.col("net_price").isNull() | (f.col("net_price") == 0))
            & (f.col("validity_date_fia") > f.col("delivery_date_planned")),
            f.col("net_price_fia"),
        ).otherwise(f.col("net_price")),
    )
    .withColumn(
        "price_base",
        f.when(
            (f.col("price_base").isNull() | (f.col("price_base") == 0))
            & (f.col("validity_date_fia") > f.col("delivery_date_planned")),
            f.col("price_base_fia"),
        ).otherwise(f.col("price_base")),
    )
    .withColumn(
        "PR_unit_of_measure",
        f.when(
            (f.col("PR_unit_of_measure").isNull())
            & (f.col("validity_date_fia") > f.col("delivery_date_planned")),
            f.col("PR_unit_of_measure_fia"),
        ).otherwise(f.col("PR_unit_of_measure")),
    )
    .withColumn(
        "currency",
        f.when(
            (f.col("currency").isNull())
            & (f.col("validity_date_fia") > f.col("delivery_date_planned")),
            f.col("currency_fia"),
        ).otherwise(f.col("currency")),
    )
    .withColumn(
        "supplier_code",
        f.when(
            f.col("supplier_code").isNull(),
            f.col("supplier_code_fia"),
        ).otherwise(f.col("supplier_code")),
    )
    .drop(
        "currency_fia",
        "validity_date_fia",
        "PR_unit_of_measure_fia",
        "price_base_fia",
        "net_price_fia",
        "supplier_code_fia",
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 12.4 – Preparation to append with standard PR

# COMMAND ----------

df_pr_from_plaf_end = df_pr_from_plaf_updated.withColumnsRenamed(
    {
        "plant": "plant_delivered",
        "planned_order": "PR_number",
        "description": "PR_item_description",
        "currency": "PR_currency",
    }
)
df_pr_from_plaf_end = (
    df_pr_from_plaf_end.withColumn("plant_origin", f.col("plant_delivered"))
    .withColumn("MRP_unit", f.col("plant_delivered"))
    .withColumn("PR_item_number", f.col("operation"))
    .withColumn("PR_number", f.concat_ws("-", f.lit("PL.O"), f.col("PR_number")))
    .withColumn(
        "PR_item_ID", f.concat_ws("-", f.col("PR_number"), f.col("PR_item_number"))
    )
    .withColumn("PR_type", f.lit("WO_ST"))
    .withColumn("datasource", f.lit("SAP"))
    .withColumn("PR_creator", f.lit("SAP"))
    .withColumn("reception_time", f.lit(0))
    .withColumn("launching_date", f.date_sub(f.col("start_planned_date"), 15))
    .withColumn("status_treatment", f.lit("N"))
    .withColumn("PR_creation_date", f.current_date())
    .withColumn("profit_center", f.lit(None))
    .withColumn("PO_creation_date", f.lit(None))
    .withColumn("PO_number", f.lit(None))
    .withColumn("PO_item_number", f.lit(None))
    .withColumn("WO_number", f.lit(None))
    .withColumn("PO_quantity_ordered", f.lit(None))
    .withColumn("PR_info_status", f.lit("00"))
)
df_pr_from_plaf_end = df_pr_from_plaf_end.drop(
    "end_planned_date",
    "info_records",
    "key",
    "node",
    "operation",
    "production_version",
    "routing_group",
    "routing_number",
    "start_planned_date",
    "info_records_type",
)
# Set boolean indicator
df_pr_from_plaf_end = (
    df_pr_from_plaf_end.withColumn(
        "has_contract_indicator",
        f.when(f.col("contract_number").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .withColumn("has_material_indicator", f.lit(False))
    .withColumn("has_no_quantity_planned_indicator", f.lit(False))
    .withColumn("is_deleted", f.lit(False))
    .withColumn("is_one_cent_price_indicator", f.lit(False))
    .withColumn("is_terminated", f.lit(False))
    .withColumn("is_total_value_one_indicator", f.lit(False))
    .withColumn(
        "is_zero_price_indicator",
        f.when(f.col("net_price") == 0, f.lit(True)).otherwise(f.lit(False)),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 13 – Purchase request comming from Providers Flows

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 13.1 – Extract Reservation from direct procurement flow

# COMMAND ----------

# Keep only reservation on planned order (bdart=SB) not closed (kzear) not cancelled (xloek)
# And direct procurement flowws (dbskz=F)
df_bronze_resb_prepared = df_bronze_resb_raw.filter(
    ((f.col("xloek").isNull()) | (f.col("xloek") == ""))
    & ((f.col("kzear").isNull()) | (f.col("kzear") == ""))
    & (f.col("bdart") == "SB")
    & (f.col("dbskz") == "F")
).select(
    f.col("rsnum").alias("PR_number").try_cast("string"),
    f.col("rspos").alias("PR_item_number").try_cast("string"),
    f.col("lgort").alias("storage_location").try_cast("string"),
    f.col("matnr").alias("material_number").try_cast("string"),
    f.col("werks").alias("plant").try_cast("string"),
    f.col("plnum").alias("planned_order").try_cast("string"),
    f.col("bdmng").alias("quantity_request").try_cast("double"),
    f.col("meins").alias("PR_unit_of_measure").try_cast("string"),
    f.try_to_date(f.col("bdter"), "yyyyMMdd").alias("delivery_date_planned"),
)
df_bronze_resb_prepared = table_utils.remove_leading_zeros(
    df_bronze_resb_prepared,
    ["material_number", "planned_order", "PR_number", "PR_item_number"],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 13.2 – Source List Preparation for provider flows

# COMMAND ----------

# We keep only source list active at the delivery date
df_source_list_prep = df_gold_source_list.select(
    "material_number",
    "plant",
    f.col("supplier_code").alias("sl_supplier_code"),
    f.col("purchasing_organization").alias("sl_purchasing_organization"),
    f.col("contract_number").alias("sl_contract_number"),
    f.col("contract_item").alias("sl_contract_item"),
    "source_list_record_valid_from",
    "source_list_record_valid_to",
)

# --- Join RESB with Source List (filter on validity at delivery date) ---
df_pr_provider = (
    df_bronze_resb_prepared.join(
        df_source_list_prep,
        on=["material_number", "plant"],
        how="left",
    )
    .filter(
        # Keep only source list records valid at the delivery date (or no match = null)
        f.col("sl_supplier_code").isNull()
        | (
            (f.col("delivery_date_planned") >= f.col("source_list_record_valid_from"))
            & (f.col("delivery_date_planned") <= f.col("source_list_record_valid_to"))
        )
    )
    .drop("source_list_record_valid_from", "source_list_record_valid_to")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 13.3 – Contract extraction price for provider flows

# COMMAND ----------

# We keep only price active at the delivery date from the contract
df_contract_prepared = df_gold_contract.filter(
    f.col("condition_type") == "PB00"
).select(
    f.col("contract_number").alias("ct_contract_number").try_cast("string"),
    f.col("item_number").alias("ct_item_number").try_cast("string"),
    f.col("condition_amount").try_cast("double"),
    f.col("condition_currency").try_cast("string"),
    f.col("condition_pricing_unit").try_cast("double"),
    f.col("condition_unit").try_cast("string"),
    f.col("validity_start_date_of_the_condition_record").alias("ct_valid_from"),
    f.col("validity_end_date_of_the_condition_record").alias("ct_valid_to"),
)

df_contract_prepared = table_utils.remove_leading_zeros(
    df_contract_prepared, ["ct_contract_number", "ct_item_number"]
)

# --- Join with Purchasing Contract on (contract_number, item_number) + validity ---
df_pr_provider_with_price = df_pr_provider.join(
    df_contract_prepared,
    on=[
        df_pr_provider["sl_contract_number"].alias("sl_contract_number")
        == df_contract_prepared["ct_contract_number"],
        df_pr_provider["sl_contract_item"].alias("sl_contract_item")
        == df_contract_prepared["ct_item_number"],
        # Point-in-time price: delivery date within condition validity period
        df_pr_provider["delivery_date_planned"]
        >= df_contract_prepared["ct_valid_from"],
        df_pr_provider["delivery_date_planned"] <= df_contract_prepared["ct_valid_to"],
    ],
    how="left",
).drop("ct_contract_number", "ct_item_number", "ct_valid_from", "ct_valid_to")

# --- Compute unit price and line price from contract ---
df_pr_provider_with_price = df_pr_provider_with_price.withColumn(
    "unit_price",
    f.try_divide(f.col("condition_amount"), f.col("condition_pricing_unit")),
) 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 13.4 – Preparation to append with standard PR

# COMMAND ----------

# Prepare df_pr_provider_end to be compatible with df_pr_union schema
df_pr_provider_end = df_pr_provider_with_price.withColumnsRenamed(
    {
        "plant": "plant_delivered",
        "currency": "PR_currency",
        "condition_amount": "net_price",
        "condition_currency": "currency",
        "sl_supplier_code": "supplier_code",
        "sl_purchasing_organization": "purchasing_organization",
        "sl_contract_number": "contract_number",
        "sl_contract_item": "contract_item_number",
        "condition_pricing_unit": "price_base",
    }
).drop(
    "condition_unit",
    "unit_price",
    "planned_order",
)
# ------------------------------------------------------------------------------
# Add columns expected by downstream transformations (Tr.1-5)
df_pr_provider_end = (
    df_pr_provider_end.withColumn("plant_origin", f.col("plant_delivered"))
    .withColumn("MRP_unit", f.col("plant_delivered"))
    .withColumn("PR_type", f.lit("PROV"))
    .withColumn("datasource", f.lit("SAP"))
    .withColumn("PR_creator", f.lit("SAP"))
    .withColumn("reception_time", f.lit(0))
    .withColumn(
        "launching_date",
        f.date_sub(f.col("delivery_date_planned"), 7),
    )
    .withColumn("status_treatment", f.lit("N"))
    .withColumn("PR_creation_date", f.current_date())
    .withColumn("PR_item_ID", f.lit(None).try_cast("string"))
    .withColumn("PR_item_description", f.col("material_number"))
    .withColumn("profit_center", f.lit(None).try_cast("string"))
    .withColumn("PO_creation_date", f.lit(None))
    .withColumn("PO_number", f.lit(None))
    .withColumn("PO_item_number", f.lit(None))
    .withColumn("WO_number", f.lit(None))
    .withColumn("PO_quantity_ordered", f.lit(None))
    .withColumn("PR_info_status", f.lit("00"))
    .withColumn("PR_number", f.concat_ws("-", f.lit("Prov"), f.col("PR_number")))
    .withColumn(
        "PR_item_ID", f.concat_ws("-", f.col("PR_number"), f.col("PR_item_number"))
    )
)

# Boolean indicators
df_pr_provider_end = (
    df_pr_provider_end.withColumn(
        "has_contract_indicator",
        f.when(f.col("contract_number").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .withColumn("has_material_indicator", f.lit(True))
    .withColumn("has_no_quantity_planned_indicator", f.lit(False))
    .withColumn("is_deleted", f.lit(False))
    .withColumn("is_one_cent_price_indicator", f.lit(False))
    .withColumn("is_terminated", f.lit(False))
    .withColumn("is_total_value_one_indicator", f.lit(False))
    .withColumn(
        "is_zero_price_indicator",
        f.when(f.col("net_price") == 0, f.lit(True)).otherwise(f.lit(False)),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr. 0 - Append Standard Purchase Request & Subcontracted phase & Provider Flows
# MAGIC

# COMMAND ----------

df_pr_union = df_pr_prepared.unionByName(
    df_pr_from_plaf_end, allowMissingColumns=True
).unionByName(df_pr_provider_end, allowMissingColumns=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr. 1 - Add Material Information
# MAGIC
# MAGIC This logic prioritizes the profit center from the material when available.  
# MAGIC Fallback is to the existing value from the pr.

# COMMAND ----------

df_pr_material = df_pr_union.join(
    df_gold_material, ["material_number", "plant_delivered", "MRP_unit"], "left"
)
# Fallback: if field is NULL in PR, get it from material master
df_pr_material = (
    df_pr_material.withColumn(
        "profit_center",
        f.coalesce(f.col("profit_center"), f.col("profit_center_material")),
    )
    .withColumn(
        "material_group",
        f.coalesce(f.col("material_group"), f.col("mat_material_group")),
    )
    .withColumn(
        "purchasing_group",
        f.coalesce(f.col("purchasing_group"), f.col("mat_purchasing_group")),
    )
    .drop("profit_center_material", "mat_purchasing_group")
)

# COMMAND ----------

df_pr_material = df_pr_material.join(df_gold_plant, ["plant_delivered"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 – Division / Region / Site Classification
# MAGIC Target is to determine Stock_site according case here under
# MAGIC  - Case 1 : Determination with 1:1 Site / plant (only one site is linked to a plant)
# MAGIC  - Case 2 : Determination with Decopling point and MRP Controller
# MAGIC  - Case 3 : Determination with profit center affectation 
# MAGIC The finale affectation is done by respectinf the priority of case(1.2.3).  
# MAGIC If nothing is found "LAT - Mach1" is set by default 

# COMMAND ----------

# ----------------------------------------------------------------------------------
# We keep only in the mapping plant code when there are associated to a unique site
window_plant = Window.partitionBy("plant_code")
df_bronze_site_plant = (
    df_bronze_site_plant.withColumn("_tmp_count", f.count("*").over(window_plant))
    .filter(f.col("_tmp_count") == 1)
    .drop("_tmp_count")
).withColumnsRenamed({"plant_code": "plant_delivered", "site": "_tmp_site_case_1"})
# ----------------------------------------------------------------------------------
df_gold_profitcenter = df_gold_profitcenter.select(
    f.col("profit_center_short").alias("profit_center"),
    f.col("pc_attributed_site").alias("_tmp_site_case_2"),
).where(f.col("_tmp_site_case_2") == "LATE-LFR1 - Labège Systems")

# COMMAND ----------

# Determination of Branch
# -----------------------------------------------------------------
# Determination 1:1 relationship
df_material_w_site = df_pr_material.join(
    df_bronze_site_plant, ["plant_delivered"], "left"
)
# Determination DES
df_material_w_site = df_material_w_site.join(
    df_gold_profitcenter, ["profit_center"], "left"
)
# Determination dispatch plant 1000 and 2000
df_material_w_site = df_material_w_site.withColumn(
    "_tmp_site_case_3",
    f.when(
        f.col("plant_delivered") == "2000",
        f.lit("LFR1 - Labège"),
    ),
)
df_material_w_site = df_material_w_site.withColumn(
    "_tmp_site_case_4",
    f.when(
        (f.col("plant_delivered") == "1000")
        & (f.col("decopling_point").startswith("MON")),
        f.lit("LATE - Montredon"),
    )
    .when(
        ((f.col("plant_delivered") == "1000") | (f.col("plant_delivered") == "2000"))
        & (f.col("mrp_controller").startswith("DE")),
        f.lit("LATE-LFR1 - Labege Systems"),
    )
    .when(
        (f.col("plant_delivered") == "1000")
        & (f.col("decopling_point").startswith("GMT")),
        f.lit("LATE - Gimont"),
    )
    .otherwise(f.lit("LATE - Gabardie")),
)
df_material_w_site = df_material_w_site.withColumn(
    "stock_site",
    f.coalesce(
        f.col("_tmp_site_case_1"),
        f.col("_tmp_site_case_2"),
        f.col("_tmp_site_case_3"),
        f.col("_tmp_site_case_4"),
    ),
)
df_material_w_site = df_material_w_site.select(
    [col for col in df_material_w_site.columns if not col.startswith("_tmp")]
)
# -----------------------------------------------------------------
# Remove all accents in site so as to join correctly
df_material_w_site = df_material_w_site.withColumn(
    "stock_site", f.translate("stock_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
)

df_material_w_site = df_material_w_site.join(
    df_bronze_site, ["stock_site"], "left"
).drop("decopling_point", "mrp_controller")
df_material_w_site = df_material_w_site.withColumnRenamed("stock_site", "site")

# Quality check: all lines must have a site
if df_material_w_site.where(f.col("site").isNull()).count() > 0:
    raise Exception("At least 1 row with blank site")
# -----------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 – Add Supplier Information

# COMMAND ----------

df_pr_supplier = df_material_w_site.join(
    df_gold_supplier, ["supplier_code", "purchasing_organization"], "left"
)
# Management of PR non Affected
df_pr_supplier = df_pr_supplier.withColumn(
    "supplier_name", f.coalesce(f.col("supplier_name"), f.lit("Non_Affected"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr. 4 - Determination of Purchase request item status

# COMMAND ----------

# Determination of PR Status
df_pr_status = df_pr_supplier.withColumn(
    "PR_status",
    f.when(
        (f.col("PR_type") == "PROV") | (f.col("PR_type") == "WO_ST"),
        f.lit("PR_not_created"),
    )
    .when(
        (f.col("status_treatment") == "B") & (f.col("PO_quantity_ordered") > 0),
        f.lit("PR_Converted"),
    )
    .when(
        (f.col("is_deleted") == False) & (f.col("is_terminated") == False),
        f.lit("PR_Open"),
    )
    .otherwise(f.lit("PR_Cancelled")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr. 5 - Add Value Price

# COMMAND ----------

df_pr_price = df_pr_status.withColumn(
    "unit_price", f.try_divide(f.col("net_price"), f.col("price_base"))
).withColumn(
    "total_net_value_in_PR_currency",
    f.col("unit_price") * f.col("quantity_request"),
)  # .drop("price_base")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 6 – Currency Conversion
# MAGIC
# MAGIC This transformation converts key monetary fields from the document currency to a common target currency (EUR), using the appropriate rate type (`Budget`) and the PO document date as the reference for conversion.
# MAGIC
# MAGIC Ensures consistency across reporting by standardizing currency values.
# MAGIC

# COMMAND ----------

# Determination of budget_currency_conversion_date
today_str = datetime.today().strftime("%Y-%m-%d")
today = f.lit(today_str)
two_days_ago = f.lit((datetime.today() - timedelta(days=2)).strftime("%Y-%m-%d"))

df_pr_price = df_pr_price.withColumn(
    "budget_currency_conversion_date",
    f.when(f.col("delivery_date_planned") > today, two_days_ago).otherwise(
        f.col("delivery_date_planned")
    ),
).withColumn(
    "budget_currency_conversion_date_source",
    f.when(
        f.col("delivery_date_planned") > today,
        f.lit("today - 2 days"),
    ).otherwise(f.lit("delivery_date_expected")),
)

# COMMAND ----------

df_converted_currency = table_utils.currency_conversion(
    df=df_pr_price,
    document_currency_column=df_pr_price.PR_currency,
    rate_types=["Budget"],
    rate_dates=[df_pr_price.budget_currency_conversion_date],
    target_currency_value="EUR",
    document_amounts=[
        df_pr_price.unit_price,
        df_pr_price.total_net_value_in_PR_currency,
        df_pr_price.net_price,
    ],
)
# Renaming Columns Price
df_converted_currency_end = df_converted_currency.withColumnsRenamed(
    {
        "net_price": "net_order_price_per_price_base_in_PR_currency",
        "total_net_value_in_PR_currency_from_PR_currency_to_EUR_in_Budget_rate_at_budget_currency_conversion_date": "total_net_value_in_EUR_budget",
        "unit_price": "net_order_unit_price_in_PR_currency",
        "unit_price_from_PR_currency_to_EUR_in_Budget_rate_at_budget_currency_conversion_date": "net_order_unit_price_in_EUR_budget",
        "PR_currency_to_EUR_in_Budget_rate_at_budget_currency_conversion_date": "PR_currency_to_EUR_budget_rate",
        "net_price_from_PR_currency_to_EUR_in_Budget_rate_at_budget_currency_conversion_date": "net_order_price_per_price_base_in_EUR_budget",
    }
)

# COMMAND ----------

price_columns = [
    "net_order_unit_price_in_PR_currency",
    "net_order_unit_price_in_EUR_budget",
    "net_order_price_per_price_base_in_PR_currency",
    "net_order_price_per_price_base_in_EUR_budget",
    "total_net_value_in_PR_currency",
    "total_net_value_in_EUR_budget",
]

for col in price_columns:
    df_converted_currency_end = df_converted_currency_end.withColumn(
        col, f.coalesce(f.col(col), f.lit(0))
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 7 – Add WBS - information

# COMMAND ----------

df_pr_wbs = df_converted_currency_end.join(df_gold_wbs, ["WBS_element"], "left").drop(
    "WBS_element"
)

# COMMAND ----------

# Drop EBAN/EBKN technical columns + planned_order (internal field)
Begin_By = ["EBAN", "EBKN"]

selected_columns = [
    col
    for col in df_pr_wbs.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
df_pr_wbs = df_pr_wbs.select(*selected_columns)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 8 – Add Intercompany Flow

# COMMAND ----------

df_pr_interco = business_rules.add_intercompany_column(
    df_pr_wbs, "company_code", "intercompany_flow"
).drop("intercompany_flow")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 9 – Add Company Master Data

# COMMAND ----------

df_pr_company = df_pr_interco.join(df_gold_company, ["company_code"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 10 – Add Contract Information

# COMMAND ----------

df_pr_contract = df_pr_company.join(
    df_gold_contract_prepared, ["contract_number", "contract_item_number"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 11 – Add Profit_Center Information

# COMMAND ----------

df_pr_pf = df_pr_contract.join(df_gold_profitcenter_prep, ["profit_center"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 12 – Clean leading zeros Dataframe

# COMMAND ----------

df_pr_lzs = table_utils.remove_leading_zeros(
    df=df_pr_pf,
    column_names=[
        "PR_number",
        "PR_item_number",
        "material_number",
        "profit_center",
        "PO_number",
        "PO_item_number",
        "contract_number",
        "contract_item_number",
        "WO_number",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 13 – Determine Plant Buy

# COMMAND ----------

df_pr_plant = df_pr_lzs.withColumn(
    "plant_origin", f.coalesce(f.col("plant_origin"), f.col("plant_delivered"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 14 – Enrich with commodity

# COMMAND ----------

# Get (sub-)commodity from material material group first then from document material group

df_pr_commodity = df_pr_plant.withColumn(
    "material_group_join",
    f.when(
        f.col("has_material_indicator") == True,
        f.coalesce(f.col("material_group"), f.col("mat_material_group")),
    ).otherwise(f.col("merchandise_group")),
)

df_pr_commodity = df_pr_commodity.join(
    df_commodity_prepared, ["material_group_join"], "left"
).drop("material_group_join", "merchandise_group")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 15 – Add PO foreign key
# MAGIC
# MAGIC

# COMMAND ----------

df_pr_end = df_pr_commodity.withColumn(
    "PO_item_ID",
    f.when(
        f.col("PO_number").isNotNull(),
        f.concat_ws("-", f.col("PO_number"), f.col("PO_item_number")),
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_to_check = df_pr_end
col_pk = "PR_item_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for purchase requests table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="purchase_requests_gold",
    log_to_event_table=True,
    log_successes=True,
)

columns = df_pr_end.columns
columns.remove(col_pk)
new_column_order = [col_pk] + columns
df_pr_end = df_pr_end.select(new_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – LEAP Table (Gold Layer)
# MAGIC
# MAGIC This section writes the fully transformed purchase order dataset to the LEAP Gold Layer using a robust overwrite method.
# MAGIC

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "supply_chain_ordering"
DESTINATION_TABLE = "purchase_requests_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_pr_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_pr_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_pr_pk2"
TABLE_PK_COLS = "PR_item_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – Exposed Table View
# MAGIC
# MAGIC Creates a filtered view excluding low-level technical columns (EKPO, EKET, etc.) for analytics or dashboard exposure.
# MAGIC

# COMMAND ----------

dest_full_tablename = f"{DESTINATION_TABLE_FULL_PATH}_exposed"

Begin_By = ["EBAN", "EBKN"]

selected_columns = [
    col
    for col in df_pr_end.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename,
    select_statement,
    replace_view=True,
)

log.info(f"The table view {dest_full_tablename} has been successfully created")
