# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purchase Request - Bronze to silver
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC
# MAGIC This notebook processes SAP ECC6 purchase request data from raw bronze tables and enriches it for Silver layer usage.
# MAGIC Key steps include:
# MAGIC - Renaming and formatting EBAN and EBKN data using SAP header mappings
# MAGIC - Enriching with plant metadata, taxonomy, and purchasing group details
# MAGIC - Computing business statuses, values, and quality indicators
# MAGIC
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC
# MAGIC - Status logic derived from SAP flags and domain-specific rules
# MAGIC - Enrichment from multiple reference datasets (T001W, T024)
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Name of pipeline(s) the script was built for.
# MAGIC
# MAGIC **Input Pipeline Data**
# MAGIC -
# MAGIC **Inputs Reference Data**
# MAGIC
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eban_latest`  
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ebkn_latest`  
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t024_latest`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{PIPELINE_WRITE_ENV}_silver.supply_chain_ordering.purchase_requests_sap`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
import time
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils, amount_correction

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not.
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### EBAN – Purchase Request Header
# MAGIC
# MAGIC Contains line-item level data of purchase requests, including:
# MAGIC - Material number
# MAGIC - Requested quantity
# MAGIC - Delivery and pricing data
# MAGIC
# MAGIC Used as the core dataset to build the PR records.

# COMMAND ----------

df_eban_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eban_latest"
)
df_eban_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_eban"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EBKN – Account Assignments for PRs
# MAGIC
# MAGIC Contains cost object assignments for purchase requests (e.g., cost centers, internal orders).
# MAGIC Used to add accounting and traceability context.
# MAGIC

# COMMAND ----------

df_ebkn_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ebkn_latest"
)
df_ebkn_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_ebkn"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### T024 – Purchasing Group Information
# MAGIC
# MAGIC Reference data mapping `purchase_group` codes to:
# MAGIC - Descriptions
# MAGIC - Email addresses
# MAGIC
# MAGIC Enriches PRs with buyer-level metadata.

# COMMAND ----------

df_t024_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t024_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Initial cleanup and structuring of raw EBAN/EBKN/T024 datasets.
# MAGIC Includes:
# MAGIC - Prefixing technical columns
# MAGIC - Renaming columns using SAP header files
# MAGIC - Type casting of field

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – EBAN
# MAGIC
# MAGIC Applies:
# MAGIC - Column prefixing
# MAGIC - Business-name-based renaming
# MAGIC - Format casting based on SAP header metadata

# COMMAND ----------

df_eban = table_utils.add_prefix_to_columns(df_eban_raw, "EBAN")
# Call Function Delete rows null
df_name_eban = delete_null_rows(df_eban_header)
# Call Function Rename Columns according header file
df_column_eban = table_utils.rename_columns_with_sap_business_header(
    df_eban, df_name_eban
)
# Call Funtion Create Columns on Date format
df_eban = table_utils.cast_columns_with_sap_business_headers(
    df_column_eban, df_name_eban
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 – EBKN
# MAGIC
# MAGIC Same logic applied to EBKN: prefix, rename, cast

# COMMAND ----------

df_ebkn = table_utils.add_prefix_to_columns(df_ebkn_raw, "EBKN")
# Call Function Delete rows null
df_name_ebkn = delete_null_rows(df_ebkn_header)
# Call Function Rename Columns according header file
df_column_ebkn = table_utils.rename_columns_with_sap_business_header(
    df_ebkn, df_name_ebkn
)
# Call Funtion Create Columns on Date format
df_ebkn = table_utils.cast_columns_with_sap_business_headers(
    df_column_ebkn, df_name_ebkn
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 - T024 Purchasing description
# MAGIC

# COMMAND ----------

df_t024 = df_t024_raw.select(
    f.col("EKGRP").alias("purchasing_group"),
    f.col("EKNAM").alias("purchasing_group_name"),
    f.col("SMTP_ADDR").alias("purchasing_group_email"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##  Tr. 1 – Join EBAN / EKBN / T024
# MAGIC
# MAGIC Joins PR data with:
# MAGIC - Account assignments (EBKN)
# MAGIC - Purchasing group info (T024)  
# MAGIC
# MAGIC Result: A unified view of the PR line.

# COMMAND ----------

df_pr_join = df_eban.join(df_ebkn, ["PR_number", "PR_item_number"], "left").join(
    df_t024, ["purchasing_group"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 – Management of Wrong SAP decimal for spécific currency (TND, JPY,...)

# COMMAND ----------

df_pr_corrected = amount_correction.create_corrected_amounts(
    df_pr_join, "net_price", "PR_currency"
)
df_pr_corrected = df_pr_corrected.drop("net_price")
df_pr_corrected = df_pr_corrected.withColumnRenamed("net_price_corrected", "net_price")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3– Update MRP_Unit
# MAGIC
# MAGIC AS MRP_Unit had been deployed 5 years ago, we have to fullfill MRP_unit for old PO

# COMMAND ----------

df_pr_mrp = df_pr_corrected.withColumn(
    "MRP_unit", f.coalesce(f.col("MRP_unit"), f.col("plant_delivered"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 4 – Business Indicator Flags
# MAGIC
# MAGIC Adds business logic flags to help identify special or edge-case documents:
# MAGIC - Deletion indicator
# MAGIC - Has material/contract
# MAGIC - Quantity = 0
# MAGIC - Special price flags (0.01€, 1€, zero)
# MAGIC - Document completeness
# MAGIC

# COMMAND ----------

df_pr_indicator = (
    df_pr_mrp.withColumn(
        "has_material_indicator",
        f.when(f.col("material_number").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .withColumn(
        "has_contract_indicator",
        f.when(f.col("contract_number").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .withColumn(
        "has_no_quantity_planned_indicator",
        f.when(f.col("quantity_request") == 0, f.lit(True)).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_one_cent_price_indicator",
        f.when(f.col("net_price") == 0.01, f.lit(True)).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_total_value_one_indicator",
        f.when(
            f.col("net_price") * f.col("quantity_request") == 1, f.lit(True)
        ).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_zero_price_indicator",
        f.when(
            (f.col("net_price") == 0) | (f.col("net_price").isNull()), f.lit(True)
        ).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_incomplete_document_memorytype_indicator",
        f.when(f.col("EBAN_memorytype").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .withColumn(
        "is_deleted",
        f.when(f.col("deletion_indicator").isNull(), f.lit(False)).otherwise(
            f.lit(True)
        ),
    )
    .drop("deletion_indicator")
    .withColumn(
        "is_terminated",
        f.when(f.col("PR_closed").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .drop("PR_closed")
)
# Add source of data
df_pr_end = df_pr_indicator.withColumn("datasource", f.lit("SAP"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 5 - Cleaning raw data

# COMMAND ----------

df_pr_end = table_utils.remove_leading_zeros(
    df=df_pr_end, column_names=["PR_number", "PR_item_number", "material_number"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

# create primary key
df_pr_end = df_pr_end.withColumn(
    "PR_item_ID", f.concat_ws("-", f.col("PR_number"), f.col("PR_item_number"))
)

df_to_check = df_pr_end
col_pk = "PR_item_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for Purchase Requests table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="purchase_requests_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "supply_chain_ordering"
DESTINATION_TABLE = "purchase_requests_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_pr_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_pr_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "silver_pr_pk"
TABLE_PK_COLS = "PR_item_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
