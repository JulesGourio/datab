# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # SAP Purchase Orders – Final Gold Layer Transformation
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC This script processes SAP ECC6 purchasing data, preparing it for Gold Layer consumption in the LEAP environment.
# MAGIC It reads pre-transformed purchase order data (Silver layer) and enriches it with business metadata including suppliers, materials, and payment terms.
# MAGIC
# MAGIC It also computes branch assignments, traceability indicators, and due dates based on payment terms.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - Use of multiple reference enrichments (supplier, material, payment terms)
# MAGIC - Conditional logic for branch reconstruction and profit center prioritization
# MAGIC - Exposure of a clean Gold Layer table with a filtered view for external consumption
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Name of pipeline(s) the script was built for.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{PIPELINE_READ_ENV}_silver.supply_chain_ordering.purchase_orders_sap`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed`
# MAGIC - `{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed`
# MAGIC - `{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed`  
# MAGIC - `{REFERENCE_READ_ENV}_gold.finance.wbs_otp_exposed`  
# MAGIC - `{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed`   
# MAGIC - `{REFERENCE_READ_ENV}_gold.procurement_purchasing.purchasing_contract_exposed`  
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.zmmproccommod_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region` 
# MAGIC - `{REFERENCE_READ_ENV}_bronze.manual_input.mapping_plant_site`  
# MAGIC
# MAGIC
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_ordering.purchase_orders_sap`
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_ordering.purchase_orders_sap_exposed`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
import time
from pyspark.sql.utils import AnalysisException
from pyspark.sql.window import Window
from datetime import datetime, timedelta

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC Example:
# MAGIC - **Create_corrected_amounts** required for currency correction of SAP currencies with 3 digits
# MAGIC - **gx_validation** required for quality checks - **need "great-expectations" installed on the cluster**
# MAGIC - **logger** for inline logging
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils, business_rules, payment_term

# leap logger
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not.
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

log = setup_applevel_logger(log_level=LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# list of purchase order intraco types
list_intraco_po_type = ["UB", "ZUB"]
# list of 'Provider' suppliers with monthly Invoice not link on Purchase Order
list_provider_monthly_invoice = ["F04641A", "F69631A", "F04171A", "F03423A"]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### SILVER - Purchase Order 
# MAGIC
# MAGIC **df_silver_po**

# COMMAND ----------

df_silver_po = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.supply_chain_ordering.purchase_orders_sap"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - Manual Mapping division site  
# MAGIC **df_bronze_site** Mapping site-division-region  
# MAGIC **df_bronze_site_plant** Mapping site-plant 

# COMMAND ----------

df_bronze_site = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region"
)
df_bronze_site_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_plant_site"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - Commodity referential

# COMMAND ----------

df_bronze_commodity = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.zmmproccommod_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Profit Center
# MAGIC **df_gold_profitcenter** profit center master data

# COMMAND ----------

df_gold_profitcenter = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Material by plant
# MAGIC **df_gold_material** Extraction master data material

# COMMAND ----------

df_gold_material = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Supplier Master Data  
# MAGIC **df_gold_supplier**  Extraction Master Data Supplier  

# COMMAND ----------

df_gold_supplier = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.supplier_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - WBS Master Data  
# MAGIC **df_gold_wbs**  Extraction Master Data Supplier  

# COMMAND ----------

df_gold_wbs = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.wbs_otp_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Company Master Data  
# MAGIC **df_gold_company**  Extraction Master Data Company 

# COMMAND ----------

df_gold_company = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Supplier Contract Master Data  
# MAGIC **df_gold_contract**  Extraction Master Data contract 

# COMMAND ----------

df_gold_contract = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.procurement_purchasing.purchasing_contract_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – Silver PO table Filter
# MAGIC
# MAGIC This step filter the PO where :
# MAGIC - the final saving is not already done in SAP due to missing or bad information inside  
# MAGIC - The rows had been deleted on creation process.

# COMMAND ----------

df_po_filtered = df_silver_po.filter(
    (~f.col("is_PO_not_complete"))
    & (f.col("quantity_ordered") > 0)
    & f.col("plant_delivered").isNotNull()
).drop("is_PO_not_complete")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 - Select and translate Site mapping

# COMMAND ----------

df_bronze_site = df_bronze_site.withColumnRenamed("site", "stock_site").withColumn(
    "stock_site", f.translate("stock_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
).distinct()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 - Select Material Plant info

# COMMAND ----------

df_gold_material = df_gold_material.select(
    "material_number",
    f.col("plant").alias("plant_delivered"),
    f.col("profit_center").alias("profit_center_material"),
    f.col("material_group").alias("mat_material_group"),
    "decopling_point",
    "mrp_controller",
    "MRP_unit",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 4 – Supplier Masterdata
# MAGIC
# MAGIC This step joins the PO dataset with supplier and material master data to enrich the purchasing information with Supplier classification
# MAGIC

# COMMAND ----------

df_gold_supplier = df_gold_supplier.select(
    "supplier_code",
    "supplier_name",
    "supplier_country",
    "supplier_city",
    "supplier_category",
    "spend_category",
    "purchasing_organization",
    f.col("payment_term").alias("supplier_payment_term"),
    "intercompany_flow",
    "is_supplier_a_distributor",
    "merchandise_group",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 5 – Company master data

# COMMAND ----------

df_gold_company = df_gold_company.toDF(*[c.lower() for c in df_gold_company.columns])

df_gold_company = df_gold_company.select(
    f.col("company").alias("company_code"),
    f.col("company_description"),
    f.col("country").alias("company_country"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 6 – WBS master data

# COMMAND ----------

df_gold_wbs = df_gold_wbs.select(
    f.col("WBS_Code_Num").alias("WBS_element"), f.col("WBS_Code").alias("WBS_code")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 7 – Supplier Contract

# COMMAND ----------

df_gold_contract = df_gold_contract.select(
    f.col("contract_number"),
    f.col("item_number").alias("contract_item_number"),
    f.col("contract_enablement"),
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 8 – Profit Center

# COMMAND ----------

df_gold_profitcenter = df_gold_profitcenter.toDF(
    *[c.lower() for c in df_gold_profitcenter.columns]
)

df_gold_profitcenter_prep = df_gold_profitcenter.select(
    f.col("profit_center_short").alias("profit_center"),
    f.col("short_description").alias("profit_center_description"),
    f.col("customer_group"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 9 – Commodity referential

# COMMAND ----------

df_commodity_prepared = df_bronze_commodity.select(
    f.col("matkl").alias("material_group_join"),
    f.col("sens").alias("direct_indirect"),
    f.col("commodity_l1").alias("commodity"),
    f.col("commodity_l2").alias("sub_commodity")
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 – Update Quantity in DataBase
# MAGIC

# COMMAND ----------

# Add Qty remaining not include in SAP
df_po_qty = df_po_filtered.withColumn(
    "quantity_remaining",
    f.when(f.col("is_final_delivery_indicator") == True, 0).otherwise(
        f.col("quantity_planned") - f.col("quantity_delivered")
    ),
)
#  Add Unit Value not include in SAP Table
df_po_qty = df_po_qty.withColumn(
    "unit_price", f.col("global_price") / f.col("quantity_ordered")
)
# Add remaining Value not include in SAP Table   ### Changing remaining value to amount_remaining_in_document_currency
df_po_qty = df_po_qty.withColumn(
    "remaining_value",
    (f.col("quantity_remaining") * f.col("unit_price")),
)

# Convert buy unit into stock unit
df_po_qty = (
    df_po_qty.withColumn(
        "conversion_rate_into_stock_unit",
        f.when(
            f.col("numerator_for_conversion_of_order_unit_to_stock_unit") == 0,
            f.lit(1),
        ).otherwise(
            f.col("numerator_for_conversion_of_order_unit_to_stock_unit")
            / f.col("denominator_for_conversion_of_order_unit_to_stock_unit")
        ),
    )
    .withColumn(
        "quantity_ordered_in_stock_unit",
        (f.col("quantity_ordered") * f.col("conversion_rate_into_stock_unit")),
    )
    .withColumn(
        "unit_price_in_stock_unit",
        (f.col("unit_price") / f.col("conversion_rate_into_stock_unit")),
    )
).drop(
    # "conversion_rate_into_stock_unit",
    "numerator_for_conversion_of_order_unit_to_stock_unit",
    "denominator_for_conversion_of_order_unit_to_stock_unit",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr. 2 - Determination of Purchase order item status
# MAGIC - `PO_In_Progress : Item not received, still in progress` 
# MAGIC - `PO_Received : item received but not invoiced yet`
# MAGIC - `PO_Invoiced : item received and invoiced` 
# MAGIC - `PO_Returned : Item used only to return parts to supplier` 
# MAGIC - `PO_Cancelled : item cancelled in system by business` 

# COMMAND ----------

# MAGIC %md
# MAGIC ###Tr. 2.1 - Determination PO status through indicators flag

# COMMAND ----------

# Determination of PO Status
# Special case of Entrusted parts Managment (Invoices not expected)
# quantity_remaining = 0 and net_price = 0
df_po_status = df_po_qty.withColumn(
    "PO_status",
    f.when(f.col("is_deletion_indicator") == True, f.lit("PO_Cancelled"))
    .when(f.col("is_invoice_indicator") == True, f.lit("PO_Invoiced"))
    .when(f.col("is_returns_indicator") == True, f.lit("PO_Returned"))
    .when(f.col("quantity_remaining") != 0, f.lit("PO_In_Progress"))
    .when(
        (f.col("quantity_remaining") == 0) & (f.col("net_price") == 0),
        f.lit("PO_Invoiced"),
    )
    .otherwise(f.lit("TBD")),
)
# ----------------------------------------------------------------------------------
# Intraco Purchase Order (No invoices)
df_po_status = df_po_status.withColumn(
    "PO_status",
    f.when((f.col("PO_status") != "TBD"), f.col("PO_status"))
    .when(
        (f.col("quantity_remaining") == 0)
        & (f.col("PO_type").isin(list_intraco_po_type)),
        f.lit("PO_Invoiced"),
    )
    .otherwise(f.lit("TBD")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Tr. 2.2 - Update PO Status according history ekbe info 

# COMMAND ----------

# Check If Invoice is done without GR
df_po_status_ekbe = df_po_status.withColumn(
    "PO_status",
    f.when(
        (f.col("PO_status") == "PO_In_Progress")
        & (f.col("PO_status_from_history") == "PO_Invoiced")
        & (f.col("EKPO_webre").isNull() == True),
        f.lit("PO_Invoiced"),
    ).otherwise(f.col("PO_status")),
)

df_po_status_ekbe = df_po_status_ekbe.withColumn(
    "PO_status",
    f.when((f.col("PO_status") != "TBD"), f.col("PO_status"))
    .when(f.col("PO_status_from_history").isNotNull(), f.col("PO_status_from_history"))
    .otherwise(f.lit("TBD")),
).drop("PO_status_from_history")

df_po_status_final = df_po_status_ekbe.withColumn(
    "PO_status",
    f.when((f.col("PO_status") != "TBD"), f.col("PO_status"))
    .when(
        (f.col("is_final_delivery_indicator") == True)
        & (f.col("quantity_remaining") == 0),
        f.lit("PO_Cancelled"),
    )
    .when(f.col("quantity_remaining") == 0, f.lit("PO_Invoiced"))
    .otherwise(f.lit("TBD")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Tr. 2.3 - Management Purchase Order Provider with Mensual Invoice not link on Purchase Order 

# COMMAND ----------

df_po_status_final = df_po_status_final.withColumn(
    "PO_status",
    f.when(
        (f.col("supplier_code").isin(list_provider_monthly_invoice))
        & (f.col("PO_status") == "PO_Received"),
        f.lit("PO_Invoiced"),
    ).otherwise(f.col("PO_status")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr. 3 - Incoterm Management
# MAGIC
# MAGIC This logic prioritizes the incoterm from the item when available.  
# MAGIC Fallback is to the existing value from the header.
# MAGIC

# COMMAND ----------

df_po_incoterm = (
    df_po_status_final.withColumn(
        "incoterm_code", f.coalesce(f.col("incoterm_code_item"), f.col("incoterm_code"))
    )
    .withColumn(
        "incoterm_detail",
        f.coalesce(f.col("incoterm_details_item"), f.col("incoterm_details")),
    )
    .drop("incoterm_code_item", "incoterm_details_item", "incoterm_details")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr. 4 - Add Material Information
# MAGIC
# MAGIC This logic prioritizes the profit center from the material when available.  
# MAGIC Fallback is to the existing value from the po.

# COMMAND ----------

df_po_material = df_po_incoterm.join(
    df_gold_material, ["material_number", "plant_delivered", "MRP_unit"], "left"
)
df_po_material = df_po_material.withColumn(
    "profit_center", f.coalesce(f.col("profit_center_material"), f.col("profit_center"))
).drop("profit_center_material")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 5 – Division / Region / Site Classification
# MAGIC Target is to determine Stock_site according case here under
# MAGIC  - Case 1 : Determination with 1:1 Site / plant (only one site is linked to a plant)
# MAGIC  - Case 2 : Determination with Decopling point and MRP Controller
# MAGIC  - Case 3 : Determination with profit center affectation 
# MAGIC The finale affectation is done by respectinf the priority of case(1.2.3).  
# MAGIC If nothing is found "LAT - Mach1" is set by default 

# COMMAND ----------

# ----------------------------------------------------------------------------------
# We keep only in the mapping plant code when there are associated to a unique site
window_plant = Window.partitionBy("plant_code")
df_bronze_site_plant = (
    df_bronze_site_plant.withColumn("_tmp_count", f.count("*").over(window_plant))
    .filter(f.col("_tmp_count") == 1)
    .drop("_tmp_count")
).withColumnsRenamed({"plant_code": "plant_delivered", "site": "_tmp_site_case_1"})
# ----------------------------------------------------------------------------------
df_gold_profitcenter = df_gold_profitcenter.select(
    f.col("profit_center_short").alias("profit_center"),
    f.col("pc_attributed_site").alias("_tmp_site_case_2"),
).where(f.col("_tmp_site_case_2") == "LATE-LFR1 - Labège Systems")

# COMMAND ----------

# Determination of Branch
# -----------------------------------------------------------------
# Determination 1:1 relationship
df_material_w_site = df_po_material.join(
    df_bronze_site_plant, ["plant_delivered"], "left"
)
# Determination DES
df_material_w_site = df_material_w_site.join(
    df_gold_profitcenter, ["profit_center"], "left"
)
# Determination dispatch plant 1000 and 2000
df_material_w_site = df_material_w_site.withColumn(
    "_tmp_site_case_3",
    f.when(
        f.col("plant_delivered") == "2000",
        f.lit("LFR1 - Labège"),
    ),
)
df_material_w_site = df_material_w_site.withColumn(
    "_tmp_site_case_4",
    f.when(
        (f.col("plant_delivered") == "1000")
        & (f.col("decopling_point").startswith("MON")),
        f.lit("LATE - Montredon"),
    )
    .when(
        ((f.col("plant_delivered") == "1000") | (f.col("plant_delivered") == "2000"))
        & (f.col("mrp_controller").startswith("DE")),
        f.lit("LATE-LFR1 - Labege Systems"),
    )
    .when(
        (f.col("plant_delivered") == "1000")
        & (f.col("decopling_point").startswith("GMT")),
        f.lit("LATE - Gimont"),
    )
    .otherwise(f.lit("LATE - Gabardie")),
)
df_material_w_site = df_material_w_site.withColumn(
    "stock_site",
    f.coalesce(
        f.col("_tmp_site_case_1"),
        f.col("_tmp_site_case_2"),
        f.col("_tmp_site_case_3"),
        f.col("_tmp_site_case_4"),
    ),
)
df_material_w_site = df_material_w_site.select(
    [col for col in df_material_w_site.columns if not col.startswith("_tmp")]
)
# -----------------------------------------------------------------
# Remove all accents in site so as to join correctly
df_material_w_site = df_material_w_site.withColumn(
    "stock_site", f.translate("stock_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
)

df_material_w_site = df_material_w_site.join(
    df_bronze_site, ["stock_site"], "left"
).drop("decopling_point", "mrp_controller")
df_material_w_site = df_material_w_site.withColumnRenamed("stock_site", "site")

# Quality check: all lines must have a site
if df_material_w_site.where(f.col("stock_site").isNull()).count() > 0:
    raise Exception("At least 1 row with blank site")
# -----------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 6 – Add Supplier Information

# COMMAND ----------

df_po_supplier = df_material_w_site.join(
    df_gold_supplier, ["supplier_code", "purchasing_organization"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 7 – Calculate Expected Delivery Date & Source
# MAGIC Expected delivery date is based on confirmation & notice dates coming from the suppliers.

# COMMAND ----------

df_po_with_exp_date = df_po_supplier.withColumn(
    "delivery_date_expected",
    f.coalesce(
        f.col("LA_confirmation_date"),
        f.col("AB_confirmation_date"),
        f.col("delivery_date_planned"),
    ),
).withColumn(
    "delivery_date_expected_source",
    f.when(f.col("LA_confirmation_date").isNotNull(), f.lit("LA_confirmation_date"))
    .when(f.col("AB_confirmation_date").isNotNull(), f.lit("AB_confirmation_date"))
    .when(f.col("delivery_date_planned").isNotNull(), f.lit("delivery_date_planned"))
    .otherwise(f.lit(None)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 8 – Currency Conversion
# MAGIC
# MAGIC This transformation converts key monetary fields from the document currency to a common target currency (EUR), using the appropriate rate type (`Budget`) and the PO document date as the reference for conversion.
# MAGIC
# MAGIC It handles multiple financial fields, including:
# MAGIC - Net and gross total price
# MAGIC - Unit prices
# MAGIC - Stock unit prices
# MAGIC
# MAGIC Ensures consistency across reporting by standardizing currency values.

# COMMAND ----------

# Determination of budget_currency_conversion_date
today_str = datetime.today().strftime("%Y-%m-%d")
today = f.lit(today_str)
two_days_ago = f.lit((datetime.today() - timedelta(days=2)).strftime("%Y-%m-%d"))

df_po_with_exp_date = df_po_with_exp_date.withColumn(
    "budget_currency_conversion_date",
    f.when(
        f.col("delivery_date_expected") > today,
        two_days_ago,
    ).otherwise(f.col("delivery_date_expected")),
).withColumn(
    "budget_currency_conversion_date_source",
    f.when(
        f.col("delivery_date_expected") > today,
        f.lit("today - 2 days"),
    ).otherwise(f.lit("delivery_date_expected")),
)

# COMMAND ----------

df_converted_currency = table_utils.currency_conversion(
    df=df_po_with_exp_date,
    document_currency_column=df_po_with_exp_date.PO_currency,
    rate_types=["Budget"],
    rate_dates=[df_po_with_exp_date.budget_currency_conversion_date],
    target_currency_value="EUR",
    document_amounts=[
        df_po_with_exp_date.net_price,
        df_po_with_exp_date.unit_price,
        df_po_with_exp_date.unit_price_in_stock_unit,
        df_po_with_exp_date.remaining_value,
        df_po_with_exp_date.global_price,
    ],
)
# Renaming Columns Price
df_converted_currency_end = (
    df_converted_currency.withColumnRenamed(
        "remaining_value", "remaining_net_value_in_PO_currency"
    )
    .withColumnRenamed(
        "remaining_value_from_PO_currency_to_EUR_in_Budget_rate_at_budget_currency_conversion_date",
        "remaining_net_value_in_EUR_budget",
    )
    .withColumnRenamed("unit_price", "net_order_unit_price_in_PO_currency")
    .withColumnRenamed(
        "unit_price_from_PO_currency_to_EUR_in_Budget_rate_at_budget_currency_conversion_date",
        "net_order_unit_price_in_EUR_budget",
    )
    .withColumnRenamed(
        "unit_price_in_stock_unit", "net_stock_unit_price_in_PO_currency"
    )
    .withColumnRenamed(
        "unit_price_in_stock_unit_from_PO_currency_to_EUR_in_Budget_rate_at_budget_currency_conversion_date",
        "net_stock_unit_price_in_EUR_budget",
    )
    .withColumnRenamed("net_price", "net_order_price_per_price_base_in_PO_currency")
    .withColumnRenamed(
        "net_price_from_PO_currency_to_EUR_in_Budget_rate_at_budget_currency_conversion_date",
        "net_order_price_per_price_base_in_EUR_budget",
    )
    .withColumnRenamed("global_price", "total_net_value_in_PO_currency")
    .withColumnRenamed(
        "global_price_from_PO_currency_to_EUR_in_Budget_rate_at_budget_currency_conversion_date",
        "total_net_value_in_EUR_budget",
    )
    .withColumnRenamed(
        "PO_currency_to_EUR_in_Budget_rate_at_budget_currency_conversion_date",
        "PO_currency_to_EUR_budget_rate",
    )
)

# COMMAND ----------

price_columns = [
    "remaining_net_value_in_PO_currency",
    "remaining_net_value_in_EUR_budget",
    "net_order_unit_price_in_PO_currency",
    "net_order_unit_price_in_EUR_budget",
    "net_order_price_per_price_base_in_PO_currency",
    "net_order_price_per_price_base_in_EUR_budget",
    "total_net_value_in_PO_currency",
    "total_net_value_in_EUR_budget",
]

for col in price_columns:
    df_converted_currency_end = df_converted_currency_end.withColumn(
        col, f.coalesce(f.col(col), f.lit(0))
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 9 – Add WBS - information
# MAGIC

# COMMAND ----------

df_po_wbs = df_converted_currency_end.join(df_gold_wbs, ["WBS_element"], "left").drop(
    "WBS_element"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 10 – Add Intercompany Flow
# MAGIC

# COMMAND ----------

df_po_interco = business_rules.add_intercompany_column(
    df_po_wbs, "company_code", "intercompany_flow"
).drop("intercompany_flow")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 11 – Add Company Master Data

# COMMAND ----------

df_po_company = df_po_interco.join(df_gold_company, ["company_code"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 12 – Add Contract Information

# COMMAND ----------

df_po_contract = df_po_company.join(
    df_gold_contract, ["contract_number", "contract_item_number"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 13 – Add Profit_Center Information

# COMMAND ----------

df_po_pf = df_po_contract.join(df_gold_profitcenter_prep, ["profit_center"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 14 – Clean leading zeros Dataframe
# MAGIC

# COMMAND ----------

df_po_clean_lzs = table_utils.remove_leading_zeros(
    df=df_po_pf,
    column_names=[
        "PO_number",
        "PO_item_number",
        "material_number",
        "profit_center",
        "PR_number",
        "PR_item_number",
        "contract_number",
        "contract_item_number",
        "WO_number"
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 15 – Determine Plant Buy

# COMMAND ----------

df_po_plant = df_po_clean_lzs.withColumn(
    "plant_origin", f.coalesce(f.col("plant_origin"), f.col("plant_delivered"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 16 – Enrich with commodity

# COMMAND ----------

# For items with material, use document material group then material master group
# For items without material, use supplier merchandise group (business will ensure full coverage)
df_po_commodity = df_po_plant.withColumn(
  "material_group_join",
  f.when(
    f.col("has_material_indicator") == True,
    f.coalesce(f.col("material_group"), f.col("mat_material_group"))
  ).otherwise(f.col("merchandise_group"))
)

df_po_commodity = df_po_commodity.join(
  df_commodity_prepared,
  ["material_group_join"],
  "left"
).drop("material_group_join", "merchandise_group")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 17 - Add PR KEY for associated Purchase _Request_
# MAGIC note this is for associated purchase request key not purchase order
# MAGIC

# COMMAND ----------

df_po_clean_prid = df_po_commodity.withColumn(
    "PR_item_ID",
    f.when(
        f.col("PR_number").isNotNull(),
        f.concat_ws("-", f.col("PR_number"), f.col("PR_item_number")),
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

df_po_end = df_po_clean_prid

# COMMAND ----------

df_po_end = df_po_end.withColumn(
    "PO_item_ID", f.concat_ws("-", f.col("PO_number"), f.col("PO_item_number"))
)
col_pk = "PO_item_ID"
columns = df_po_end.columns
columns.remove(col_pk)
new_column_order = [col_pk] + columns
df_po_end = df_po_end.select(new_column_order)

# COMMAND ----------

df_to_check = df_po_end
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for PO Gold table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="purchase_orders_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – LEAP Table (Gold Layer)
# MAGIC
# MAGIC This section writes the fully transformed purchase order dataset to the LEAP Gold Layer using a robust overwrite method.
# MAGIC

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "supply_chain_ordering"
DESTINATION_TABLE = "purchase_orders_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_po_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_po_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_po_pk"
TABLE_PK_COLS = "PO_item_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – Exposed Table View
# MAGIC
# MAGIC Creates a filtered view excluding low-level technical columns (EKPO, EKET, etc.) for analytics or dashboard exposure.
# MAGIC

# COMMAND ----------

dest_full_tablename = f"{DESTINATION_TABLE_FULL_PATH}_exposed"
Begin_By = [
    "EKPO",
    "EKET",
    "EKBE",
    "EKES",
    "EKKN",
    "T001W",
    "EKKO",
    "LA_EKES",
    "AB_EKES",
]

selected_columns = [
    col
    for col in df_po_end.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH, dest_full_tablename, select_statement, replace_view=True
)

log.info(f"The table view {dest_full_tablename} has been successfully created")
