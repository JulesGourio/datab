# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # SAP Stack Purchase order and Purchase Request
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC
# MAGIC This notebook stack SAP ECC6 purchase requests (PR) and Purchase orders (PO) data into a final Gold Layer dataset used for reporting and analytics.
# MAGIC
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Name of pipeline(s) the script was built for.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{PIPELINE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_sap_exposed`
# MAGIC - `{PIPELINE_READ_ENV}_gold.supply_chain_ordering.purchase_requests_sap_exposed`  
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_ordering.purchase_orders_and_requests_sap_stacked`
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_ordering.purchase_orders_and_requests_sap_stacked_exposed`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import Window
from datetime import datetime, timedelta
import time
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC Example:
# MAGIC - **Create_corrected_amounts** required for currency correction of SAP currencies with 3 digits
# MAGIC - **gx_validation** required for quality checks - **need "great-expectations" installed on the cluster**
# MAGIC - **logger** for inline logging
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils, business_rules

from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not.
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual

# COMMAND ----------

# MAGIC %md
# MAGIC ### Filtering of document statuses
# MAGIC These are used to filter each individual document type before loading into the stack.

# COMMAND ----------

PO_Status_Filter_List = [
    "PO_Received",
    "PO_In_Progress",
    "PO_Invoiced",
]  ## excluded statuses: PO_Returned, PO_Cancelled
PR_Status_Filter_List = ["PR_Open","PR_not_created"]
  ## excluded statuses: PR_Converted, PR_Cancelled
  ## included PR not already created Provider Flows

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Purchase order
# MAGIC **df_gold_pr** 

# COMMAND ----------

df_gold_po = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_sap_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Purchase request
# MAGIC **df_gold_pr**  

# COMMAND ----------

df_gold_pr = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.supply_chain_ordering.purchase_requests_sap_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – Filter to stackable document types from each dataframe
# MAGIC PO dataframe with only PO in progress
# MAGIC

# COMMAND ----------

df_gold_po_filtered = df_gold_po.filter(f.col("PO_Status").isin(PO_Status_Filter_List))
df_gold_po_filtered = (
    df_gold_po_filtered.withColumn(
        "document_status",
        f.when(f.col("PO_Status") == "PO_In_Progress", f.lit("Doc_Open")).otherwise(
            f.lit("Doc_Closed")
        ),
    )
    .withColumnRenamed("PO_Status", "document_status_detail")
    .withColumn("document_type", f.lit("PO"))
)

# COMMAND ----------

df_gold_pr_filtered = df_gold_pr.filter(f.col("PR_Status").isin(PR_Status_Filter_List))
df_gold_pr_filtered = (
    df_gold_pr_filtered.withColumn("document_status", f.lit("Doc_Open"))
    .withColumnRenamed("PR_Status", "document_status_detail")
    .withColumn("document_type", f.lit("PR"))
)
# Until decision on Purchase Request indirect
# we excluded them from the stack
df_gold_pr_filtered = df_gold_pr_filtered.filter(~f.col("PR_type").isin("ZDA1", "ZDA2"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 2 - Disambiguation General columns
# MAGIC | STACK Column              | PO Source           | PR Source           |
# MAGIC | ------------------------- | ------------------- | ------------------- |
# MAGIC | document_item_id          | PO_item_ID          | PR_item_ID          |
# MAGIC | document_number           | PO_number           | PR_number           |
# MAGIC | document_item_number      | PO_item_number      | PR_item_number      |
# MAGIC | document_currency         | PO_currency         | PR_currency         |
# MAGIC | document_creator          | PO_creator          | PR_creator          |
# MAGIC | document_payment_term          | PO_payment_term           | null         |
# MAGIC | document_item_description | PO_item_description | PR_item_description |
# MAGIC | document_unit_of_measure  | PO_unit_of_measure  | PR_unit_of_measure  |
# MAGIC |stock_unit_of_measure |	stock_unit_of_measure	|PR_unit_of_measure|
# MAGIC |has_purchase_request_indicator|	has_purchase_request_indicator	|null|
# MAGIC |is_open_type |is_open_type |null |
# MAGIC |PIR_number	|PIR_number|	null |
# MAGIC |document_currency_to_EUR_budget_rate |PO_currency_to_EUR_budget_rate |PR_currency_to_EUR_budget_rate|
# MAGIC |PR_Item_ID |PR_Item_ID |null|
# MAGIC |document_specific_type |PO_type |PR_type|
# MAGIC
# MAGIC
# MAGIC
# MAGIC - PO_type / PR_type   - N.B. this is low level doc type from SAP not to be confused with "PO" or "PR". The column document_specific_type will be transformed below to include the document type ("PO"/"PR")
# MAGIC

# COMMAND ----------

# PO
df_gold_po_renamed_general_columns = df_gold_po_filtered.withColumnsRenamed(
    {
        "PO_item_ID": "document_item_ID",
        "PO_number": "document_number",
        "PO_item_number": "document_item_number",
        "PO_currency": "document_currency",
        "PO_creator": "document_creator",
        "PO_item_description": "document_item_description",
        "PO_unit_of_measure": "document_unit_of_measure",
        "PO_payment_term": "document_payment_term",
        "PO_type": "document_specific_type",
    }
)

# PR
df_gold_pr_renamed_general_columns = df_gold_pr_filtered.withColumnsRenamed(
    {
        "PR_item_ID": "document_item_ID",
        "PR_number": "document_number",
        "PR_item_number": "document_item_number",
        "PR_currency": "document_currency",
        "PR_creator": "document_creator",
        "PR_item_description": "document_item_description",
        "PR_unit_of_measure": "document_unit_of_measure",
        "PR_type": "document_specific_type",
    }
)


df_gold_pr_renamed_general_columns = (
    df_gold_pr_renamed_general_columns.withColumn(
        "stock_unit_of_measure", f.col("document_unit_of_measure")
    )
    .withColumn("has_purchase_request_indicator", f.lit(None))
    .withColumn("is_open_type", f.lit(None))
    .withColumn("PIR_number", f.lit(None))
    .withColumn("PR_item_ID", f.lit(None))
    .withColumn("document_payment_term", f.lit(None))
    .withColumnRenamed(
        "PR_currency_to_EUR_budget_rate", "document_currency_to_EUR_budget_rate"
    )
)

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Prep 3 - Disambiguation Quantities
# MAGIC note - will fill with nulls and not zeros to indicate that the field is not possible on a PR - later proj should determine whether it's nulls should be filled with zeros or not
# MAGIC
# MAGIC
# MAGIC
# MAGIC | STACK Column          | PO Source                      | PR Source           |
# MAGIC | --------------------- | ------------------------------ | ------------------- |
# MAGIC | quantity_planned      | quantity_planned               | quantity_request    |
# MAGIC | quantity_ordered      | quantity_ordered               | null                |
# MAGIC | quantity_delivered    | quantity_delivered             | null                |
# MAGIC | LA_quantity_confirmed | LA_quantity_confirmed          | null                |
# MAGIC | AB_quantity_confirmed | AB_quantity_confirmed          | null                |
# MAGIC | quantity_remaining    | quantity_remaining             | quantity_request    |
# MAGIC | quantity_ordered_in_stock_unit | quantity_ordered_in_stock_unit | quantity_request |
# MAGIC
# MAGIC
# MAGIC PO quantities not included
# MAGIC - quantity_previous 
# MAGIC - scheduled_quantity
# MAGIC
# MAGIC PR quantities not included:
# MAGIC - PO_quantity_ordered
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# Prepare the PR dataset

df_gold_pr_renamed_qty = (
    df_gold_pr_renamed_general_columns.withColumn(
        "quantity_planned", f.col("quantity_request")
    )
    .withColumnRenamed("quantity_request", "quantity_remaining")
    .withColumn("quantity_ordered", f.lit(0))
    .withColumn("quantity_delivered", f.lit(0))
    .withColumn("LA_quantity_confirmed", f.lit(0))
    .withColumn("AB_quantity_confirmed", f.lit(0))
    .withColumn("quantity_ordered_in_stock_unit", f.col("quantity_remaining"))
)

# COMMAND ----------

df_gold_po_renamed_qty = (
    df_gold_po_renamed_general_columns  ## Placeholder if needed to rename later
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 4 - Disambiguation Dates
# MAGIC
# MAGIC | STACK Column                  | PO Source                     | PR Source                    |
# MAGIC | ----------------------------- | ----------------------------- | ---------------------------- |
# MAGIC | document_creation_date        | PO_creation_date              | PR_creation_date             |
# MAGIC | delivery_date_planned         | delivery_date_planned         | delivery_date_planned        |
# MAGIC | delivery_date_expected        | delivery_date_expected        | delivery_date_planned        |
# MAGIC | delivery_date_expected_source | delivery_date_expected_source | lit("delivery_date_planned") |
# MAGIC | launching_date                | PO_launching_date             | launching_date               |
# MAGIC | currency_conversion_date   |     currency_conversion_date     |   currency_conversion_date       |
# MAGIC | currency_conversion_date_source    |      currency_conversion_date_source     |       currency_conversion_date_source   |
# MAGIC | LA_confirmation_date          | LA_confirmation_date          | _null_                       |
# MAGIC | AB_confirmation_date          | AB_confirmation_date          | _null_                       |
# MAGIC | quotation_date                | quotation_date                | _null_                       |
# MAGIC | date_of_price_determination   | date_of_price_determination   | launching_date               |
# MAGIC | lead_time                     | PO_lead_time                  | lead_time                    |
# MAGIC
# MAGIC
# MAGIC
# MAGIC ###### conversion date inclusion?
# MAGIC
# MAGIC Excluded from PO table:
# MAGIC - last_modification_date
# MAGIC
# MAGIC Excluded from PR table:
# MAGIC - PO_creation_date

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4.1 - Renaming for date columns

# COMMAND ----------

## PO
df_gold_po_renamed_date = (
    df_gold_po_renamed_qty.withColumnRenamed(
        "PO_creation_date", "document_creation_date"
    )
    .withColumnRenamed("PO_launching_date", "launching_date")
    .withColumnRenamed("PO_lead_time", "lead_time")
)

# COMMAND ----------

## PR

df_gold_pr_renamed_date = df_gold_pr_renamed_qty.withColumnRenamed(
    "PR_creation_date", "document_creation_date"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4.2 - add expected delivery date to PR dataset
# MAGIC N.B. delivery_date_expected has been added to PO base data-asset

# COMMAND ----------

del_date_source_column = "delivery_date_planned"

df_gold_pr_renamed_date = df_gold_pr_renamed_date.withColumn(
    "delivery_date_expected", f.col(del_date_source_column)
).withColumn("delivery_date_expected_source", f.lit(del_date_source_column))

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4.3 - add date cols used in POs as nulls in PRs

# COMMAND ----------

list_of_cols_to_add = [
    "LA_confirmation_date",
    "AB_confirmation_date",
    "quotation_date",
]

for col in list_of_cols_to_add:
    df_gold_pr_renamed_date = df_gold_pr_renamed_date.withColumn(col, f.lit(None))

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4.4 - match launching_date from PR to date_of_price_determination

# COMMAND ----------

df_gold_pr_renamed_date = df_gold_pr_renamed_date.withColumn(
    "date_of_price_determination", f.col("launching_date")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 5 - Disambiguation Values & Prices
# MAGIC
# MAGIC
# MAGIC | STACK Column                                        | PO Source                                     | PR Source                                     |
# MAGIC | --------------------------------------------------- | --------------------------------------------- | --------------------------------------------- |
# MAGIC | net_order_unit_price_in_document_currency           | net_order_unit_price_in_PO_currency           | net_order_unit_price_in_PR_currency           |
# MAGIC | net_stock_unit_price_in_document_currency           | net_stock_unit_price_in_PO_currency           | _null_                                        |
# MAGIC | net_order_price_per_price_base_in_document_currency | net_order_price_per_price_base_in_PO_currency | net_order_price_per_price_base_in_PR_currency |
# MAGIC | total_net_value_in_document_currency                | total_net_value_in_PO_currency                | total_net_value_in_PR_currency                |
# MAGIC | remaining_net_value_in_document_currency            | remaining_net_value_in_PO_currency            | total_net_value_in_PR_currency                |
# MAGIC | net_order_unit_price_in_EUR_budget                  | net_order_unit_price_in_EUR_budget            | net_order_unit_price_in_EUR_budget            |
# MAGIC | net_stock_unit_price_in_EUR_budget                  | net_stock_unit_price_in_EUR_budget            | _null_                                        |
# MAGIC | net_order_price_per_price_base_in_EUR_budget        | net_order_price_per_price_base_in_EUR_budget  | net_order_price_per_price_base_in_EUR_budget  |
# MAGIC | total_net_value_in_EUR_budget                       | total_net_value_in_EUR_budget                 | total_net_value_in_EUR_budget                 |
# MAGIC | remaining_net_value_in_EUR_budget                   | remaining_net_value_in_EUR_budget             | total_net_value_in_EUR_budget             |
# MAGIC

# COMMAND ----------

# PO columns mapping - chained renaming
df_gold_po_renamed_amt = df_gold_po_renamed_date.withColumnsRenamed(
    {
        "net_order_unit_price_in_PO_currency": "net_order_unit_price_in_document_currency",
        "net_stock_unit_price_in_PO_currency": "net_stock_unit_price_in_document_currency",
        "net_order_price_per_price_base_in_PO_currency": "net_order_price_per_price_base_in_document_currency",
        "total_net_value_in_PO_currency": "total_net_value_in_document_currency",
        "remaining_net_value_in_PO_currency": "remaining_net_value_in_document_currency",
    }
)


# PR columns mapping - chained renaming and add missing columns as nulls
df_gold_pr_renamed_amt = df_gold_pr_renamed_date.withColumnsRenamed(
    {
        "net_order_unit_price_in_PR_currency": "net_order_unit_price_in_document_currency",
        "net_order_price_per_price_base_in_PR_currency": "net_order_price_per_price_base_in_document_currency",
        "total_net_value_in_PR_currency": "total_net_value_in_document_currency",
        "net_order_unit_price_in_EUR_budget": "net_order_unit_price_in_EUR_budget",
        "net_order_price_per_price_base_in_EUR_budget": "net_order_price_per_price_base_in_EUR_budget",
        "total_net_value_in_EUR_budget": "total_net_value_in_EUR_budget",
    }
)

# PR unit price are directly create according stock unit
df_gold_pr_renamed_amt = (
    df_gold_pr_renamed_amt.withColumn(
        "remaining_net_value_in_EUR_budget", f.col("total_net_value_in_EUR_budget")
    )
    .withColumn(
        "net_stock_unit_price_in_document_currency",
        f.col("net_order_unit_price_in_document_currency"),
    )
    .withColumn(
        "net_stock_unit_price_in_EUR_budget",
        f.col("net_order_unit_price_in_EUR_budget"),
    )
    .withColumn(
        "remaining_net_value_in_document_currency",
        f.col("total_net_value_in_document_currency"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

df_gold_po_end = df_gold_po_renamed_amt
df_gold_pr_end = df_gold_pr_renamed_amt
common_cols = list(set(df_gold_pr_end.columns) & set(df_gold_po_end.columns))
try:
    display(common_cols)
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr. 1 - Stack PO / PR  
# MAGIC

# COMMAND ----------

common_cols = list(set(df_gold_pr_end.columns) & set(df_gold_po_end.columns))
df_stacked = df_gold_pr_end.select(common_cols).unionByName(
    df_gold_po_end.select(common_cols)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr. 2 - Compute document specific type  
# MAGIC To avoid any confusion, we stack document type and specific type inside the column document_specific_type itself. For example, if document_type = "PO" and document_specific_type = "NB", the new value will be "PO_NB".

# COMMAND ----------

df_stacked = df_stacked.withColumn(
    "document_specific_type",
    f.concat_ws("_", f.col("document_type"), f.col("document_specific_type")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – LEAP Table (Gold Layer)
# MAGIC
# MAGIC This section writes the fully transformed purchase order dataset to the LEAP Gold Layer using a robust overwrite method.
# MAGIC

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "supply_chain_ordering"
DESTINATION_TABLE = "purchase_orders_and_requests_sap_stacked"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_stacked,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_stacked.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_popr_pk"
TABLE_PK_COLS = "document_item_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
