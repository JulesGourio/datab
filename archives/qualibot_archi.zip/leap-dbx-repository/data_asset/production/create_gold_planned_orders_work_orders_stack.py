# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # GOLD STACK PLANNED ORDERS & WORK ORDERS
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC This data asset has been created to centralize and structure all relevant information related to SAP production orders.
# MAGIC The objective is to provide a trusted, historical, and unified view of manufacturing orders that can be reused across different analytical and reporting use cases.
# MAGIC
# MAGIC By consolidating data from LEAP GOLD tables Planned Orders and work orders, this dataset enables:
# MAGIC
# MAGIC 🔎 Tracking the lifecycle of production orders (from creation to completion).
# MAGIC
# MAGIC 📊 Analyzing order progress, delays, and bottlenecks.
# MAGIC
# MAGIC 🏭 Supporting manufacturing performance KPIs and operational reporting.
# MAGIC
# MAGIC 🔗 Providing a single source of truth for downstream consumers (dashboards, data science models, audits).
# MAGIC
# MAGIC This asset is part of the silver layer in the data pipeline, ensuring data is clean, incremental, and historically traceable.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Work_Orders_Daily & Planned_orders_Daily
# MAGIC
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC   - `{PIPELINE_READ_ENV}_gold.production.planned_orders_sap_exposed`
# MAGIC   - `{PIPELINE_READ_ENV}_gold.production.planned_orders_sap_exposed`  
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC   - `{PIPELINE_WRITE_ENV}_gold.production.planned_orders_and_work_order_stack_sap`  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame, Window
import time
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Planned orders
# MAGIC
# MAGIC **df_gold_plo** 

# COMMAND ----------

df_gold_plo = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.production.planned_orders_sap_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Work orders
# MAGIC
# MAGIC **df_gold_wo** 

# COMMAND ----------

df_gold_wo = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.production.work_orders_sap_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 - Planned Orders

# COMMAND ----------

df_gold_plo_prepared = df_gold_plo.withColumn(
    "document_type", f.lit("Planned Orders")
).withColumn("document_status", f.lit("Pl_O Open"))
df_gold_plo_prepared = df_gold_plo_prepared.withColumnRenamed(
    "planned_order_number", "document_number"
)
df_gold_plo_temp = df_gold_plo.select(
    f.col("planned_order_number").alias("planned_order_link")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 - Work orders

# COMMAND ----------

df_gold_wo_prepared = df_gold_wo.withColumn("document_type", f.lit("Work Orders"))
df_gold_wo_prepared = df_gold_wo_prepared.withColumnsRenamed(
    {
        "work_order_number": "document_number",
        "work_order_status": "document_status",
        "work_order_description": "material_description",
    }
).drop("is_delivered", "is_cancelled", "is_in_progress", "is_scrapped")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 - Stack Planned orders and Work orders

# COMMAND ----------

df_gold_stack = df_gold_plo_prepared.unionByName(
    df_gold_wo_prepared, allowMissingColumns=True
)

# COMMAND ----------

# Management disconnect on aquisition for Work Orders and planned orders
# We erase all planned orders already converted in Work Order
df_gold_stack_end = df_gold_stack.join(
    df_gold_plo_temp, ["planned_order_link"], "left_anti"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

df_to_check = df_gold_stack
col_pk = "document_number"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for stack planned orders and work order table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="planned_work_orders_stack_gold",
    log_to_event_table=True,
    log_successes=True,
)

columns = df_to_check.columns
columns.remove(col_pk)
new_column_order = [col_pk] + columns
df_to_check = df_to_check.select(new_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Gold Work orders table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "production"
DESTINATION_TABLE = "planned_orders_and_work_order_stack_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_to_check,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_to_check.count()} rows.")
    if result is not None:
        result.display()
