# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # [CREATE STACKED PLANNED AND WO OPE]
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The purpose of this use case is to generate a new data asset stacking planned order operation and work order operation
# MAGIC
# MAGIC The output table is generated from them
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {PIPELINE_READ_ENV}_gold.production.planned_order_operation_exposed
# MAGIC - {REFERENCE_READ_ENV}_gold.production.work_order_operation
# MAGIC - {REFERENCE_READ_ENV}_gold.production.work_orders_sap_exposed
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.production.stacked_planned_work_orders_operations
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import time

import pyspark.sql.functions as f
from pyspark.sql.utils import AnalysisException

from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("bypass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import 1: Planned Order Operation

# COMMAND ----------

df_pl_ope = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.production.planned_order_operation_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import 2: Work Order Operation

# COMMAND ----------

df_ope = spark.read.table(f"{REFERENCE_READ_ENV}_gold.production.work_order_operation")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import 3: Work Orders SAP Header
# MAGIC To retrieve priority data.

# COMMAND ----------

df_wo_header_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.production.work_orders_sap_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

NULL_STR = f.lit(None).cast("string")
NULL_DBL = f.lit(None).cast("double")
NULL_DATE = f.lit(None).cast("date")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - df_pl

# COMMAND ----------

df_pl = df_pl_ope.select(
    # =========================
    # Order & operation
    # =========================
    f.col("planned_order_number").alias("order_number"),
    f.col("PO_operation_ID").alias("operation_id"),
    f.col("planned_operation").alias("order_operation"),
    f.lit("Planned Order").alias("order_type"),
    NULL_STR.alias("work_order_type"),
    NULL_STR.alias("work_order_type_description"),
    f.lit("Pl.O Open").alias("work_order_status"),
    # =========================
    # Sales / customer context
    # =========================
    f.col("sales_orders").alias("sales_order"),
    f.col("sales_orders_item").alias("sales_order_item"),
    # =========================
    # Organizational structure
    # =========================
    "company",
    "site",
    "plant",
    "customer_group",
    "division",
    "region",
    "profit_center",
    "profit_center_description",
    (
        f.concat(f.col("profit_center"), f.lit("-"), f.col("profit_center_description"))
    ).alias("profit_center_code_desc"),
    # =========================
    # Work center
    # =========================
    "WBS_code",
    "workcenter",
    "workcenter_code",
    NULL_STR.alias("workcenter_description"),
    # =========================
    # Material
    # =========================
    "material_number",
    f.col("material_description"),
    # =========================
    # Planning – quantities, dates & effort
    # =========================
    f.col("allocated_time_in_hrs"),
    f.col("quantity_planned").alias("operation_quantity"),
    "last_scheduled_start_date",
    "last_scheduled_end_date",
    f.col("start_planned_date").alias("order_start_planned_date"),
    f.col("end_planned_date").alias("order_end_planned_date"),
    f.col("quantity_planned").alias("order_quantity_planned"),
    NULL_STR.alias("priority"),
    # =========================
    # Execution – actuals
    # =========================
    NULL_DATE.alias("actual_operation_start_date"),
    NULL_DATE.alias("actual_operation_finish_date"),
    NULL_DBL.alias("spent_time_hrs"),
    NULL_DBL.alias("spent_time_min"),
    NULL_DBL.alias("spent_time_from_hqa"),
    # =========================
    # Status
    # =========================
    NULL_STR.alias("WO_operation_status_system"),
    NULL_STR.alias("WO_operation_status_system_description"),
    f.lit("NOT STARTED").alias("operation_status"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - df_wo

# COMMAND ----------

df_wo = df_ope.select(
    # =========================
    # Order & operation
    # =========================
    f.col("work_order").alias("order_number"),
    f.col("WO_operation_id").alias("operation_id"),
    f.col("work_order_operation").alias("order_operation"),
    f.lit("Work Order").alias("order_type"),
    f.col("work_order_type"),
    f.col("work_order_type_description"),
    f.col("work_order_status"),
    # =========================
    # Sales / customer context
    # =========================
    f.col("customer_order").alias("sales_order"),
    f.col("customer_order_item").alias("sales_order_item"),
    # =========================
    # Organizational structure
    # =========================
    f.col("company"),
    f.col("customer_group"),
    f.col("division"),
    f.col("region"),
    f.col("site"),
    f.col("plant"),
    f.col("profit_center"),
    f.col("profit_center_description"),
    (
        f.concat(f.col("profit_center"), f.lit("-"), f.col("profit_center_description"))
    ).alias("profit_center_code_desc"),
    # =========================
    # Work center
    # =========================
    f.col("workcenter"),
    f.col("workcenter_code"),
    f.col("WBS_code"),
    f.col("workcenter_description"),
    # =========================
    # Material
    # =========================
    f.col("material_number"),
    NULL_STR.alias("material_description"),
    # =========================
    # Planning – quantities, dates & effort
    # =========================
    f.col("operation_quantity_ordered").alias("operation_quantity"),
    f.col("allocated_time_hrs").alias("allocated_time_in_hrs"),
    "last_scheduled_start_date",
    "last_scheduled_end_date",
    f.col("WO_start_planned_date").alias("order_start_planned_date"),
    f.col("WO_end_planned_date").alias("order_end_planned_date"),
    f.col("WO_quantity_planned").alias("order_quantity_planned"),
    # =========================
    # Execution – actuals
    # =========================
    f.col("actual_operation_start_date"),
    f.col("actual_operation_finish_date"),
    f.col("spent_time_hrs"),
    f.col("spent_time_min"),
    f.col("spent_time_from_hqa"),
    # =========================
    # Status
    # =========================
    f.col("WO_operation_status_system"),
    f.col("WO_operation_status_system_description"),
    f.col("operation_status"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - df_wo_priority

# COMMAND ----------

df_wo_priority = (
    df_wo_header_raw.select(
        f.col("work_order_number").alias("order_number"), f.col("priority")
    )
    .na.fill(5)
    .dropDuplicates(["order_number"])
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Work Order Priority

# COMMAND ----------

df_wo = df_wo.join(df_wo_priority, ["order_number"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Union

# COMMAND ----------

# We check that the schemas are the same for both before stacking
if set(df_pl.columns) != set(df_wo.columns):
    raise ValueError(
        f"Schema mismatch between planned and work orders.\n"
        f"PL only: {set(df_pl.columns) - set(df_wo.columns)}\n"
        f"WO only: {set(df_wo.columns) - set(df_pl.columns)}"
    )

df_final = df_pl.unionByName(df_wo)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Reordering the final columns

# COMMAND ----------

ordered_columns = [
    # =========================
    # Order & operation
    # =========================
    "order_number",
    "operation_id",
    "order_operation",
    "order_type",
    "work_order_type",
    "work_order_type_description",
    "work_order_status",
    # =========================
    # Sales / customer context
    # =========================
    "sales_order",
    "sales_order_item",
    # =========================
    # Organizational structure
    # =========================
    "company",
    "customer_group",
    "division",
    "region",
    "site",
    "plant",
    "profit_center",
    "profit_center_description",
    "profit_center_code_desc",
    # =========================
    # Work center
    # =========================
    "workcenter",
    "workcenter_code",
    "WBS_code",
    "workcenter_description",
    # =========================
    # Material
    # =========================
    "material_number",
    "material_description",
    # =========================
    # Planning – quantities, dates & effort
    # =========================
    "operation_quantity",
    "allocated_time_in_hrs",
    "last_scheduled_start_date",
    "last_scheduled_end_date",
    "order_start_planned_date",
    "order_end_planned_date",
    "priority",
    "order_quantity_planned",
    # =========================
    # Execution – actuals
    # =========================
    "actual_operation_start_date",
    "actual_operation_finish_date",
    "spent_time_hrs",
    "spent_time_min",
    "spent_time_from_hqa",
    # =========================
    # Status
    # =========================
    "WO_operation_status_system",
    "WO_operation_status_system_description",
    "operation_status",
]

df_final = df_final.select(ordered_columns)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx_final = SparkDFDataset(df_final, persist=False)

# CHECK ROW COUNT
row_count_pl = df_pl.count()
row_count_wo = df_wo.count()
check_count = df_gx_final.expect_table_row_count_to_equal(row_count_pl + row_count_wo)

# CHECK NON NULL
non_null_columns = [
    "order_number",
    "operation_id",
    "order_operation",
    "order_type",
]
check_non_null = []
for col in non_null_columns:
    check_non_null.append(df_gx_final.expect_column_values_to_not_be_null(col))

gx_validation.validate_and_log_gx_results(
    quality_check_results=[check_count] + check_non_null,
    validation_level=validation_level,
    info_message=f"All checks inspection",
    error_message="Quality checks failed for table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="stacked_planned_work_orders_operations",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "production"
DESTINATION_TABLE = "stacked_planned_work_orders_operations"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_final,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_final.count()} rows.")
    if result is not None:
        result.display()
