# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Silver Material Consumption
# MAGIC
# MAGIC **Description:**  
# MAGIC Silver table of material consumption postings from SAP COEP for work orders only. Each row represents a quantity of material (or labor hours) consumed against a production work order in a given fiscal period.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - Plant scope auto-detection: output table is prefixed `LMXI_` when source data covers only plant 2300.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Material Consumption
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.coep_latest
# MAGIC - {pipeline_read_env}_bronze.headers_sap.headers_sap_coep
# MAGIC
# MAGIC **Output Tables**
# MAGIC - {pipeline_write_env}_silver.production.material_consumption (or LMXI_material_consumption)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC    
# MAGIC    
# MAGIC # Technical Debt
# MAGIC
# MAGIC     -   Quality checks limited to PK: only uniqueness and null checks on PK — no validation of value ranges, row count thresholds, or completeness ratios.
# MAGIC     -   Source `coep_latest` is pre-filtered to plant 2300 (LMXI) upstream due to volume constraints. The notebook auto-detects plant scope and prefixes the output table name (`LMXI_material_consumption` vs `material_consumption`), but this naming workaround should be removed once the full multi-plant COEP extraction is available.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils

# Logging imports 
from leap_utils.common import logger

# Quality checks validation import
from leap_utils.common.validation import gx_validation



# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

#dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Plant Scope Configuration
# MAGIC %md
# MAGIC ### Plant Scope Configuration
# MAGIC
# MAGIC Automatically determines whether the COEP source data covers only the LMXI plant (2300) or multiple plants.
# MAGIC This drives the destination table name:
# MAGIC - Only plant 2300 → output: `LMXI_material_consumption`
# MAGIC - Multiple plants → output: `material_consumption`

# COMMAND ----------

COEP_SOURCE_TABLE = "coep_latest"

# Auto-detect plant scope from source data
_df_coep_tmp = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.{COEP_SOURCE_TABLE}")
_distinct_plants = [row[0] for row in _df_coep_tmp.select("werks").distinct().collect()]

LMXI_ONLY = set(_distinct_plants) == {"2300"}

if LMXI_ONLY:
    DESTINATION_TABLE = "LMXI_material_consumption"
else:
    DESTINATION_TABLE = "material_consumption"

log.info(f"Detected plants: {_distinct_plants} | LMXI only: {LMXI_ONLY} | Destination: {DESTINATION_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import 1 - COEP SAP table
# MAGIC
# MAGIC COEP is the SAP Controlling (CO) line-item table that stores detailed cost postings by object, such as cost centers, internal orders, and projects.

# COMMAND ----------

df_mat_consumption_raw = _df_coep_tmp  # already loaded during plant scope detection

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Rename columns using SAP business headers
# MAGIC
# MAGIC Read COEP headers mapping table and dynamically create business-named columns from the COEP-prefixed source fields

# COMMAND ----------

df_headers_coep = spark.read.table(f"{PIPELINE_READ_ENV}_bronze.headers_sap.headers_sap_coep")

# Add COEP_ prefix to all columns
df_mat_consumption_prefixed = table_utils.add_prefix_to_columns(df_mat_consumption_raw, "COEP")

# Uppercase Table_name in headers so it matches the COEP_ prefix convention
df_headers_upper = df_headers_coep.withColumn("Table_name", f.upper(f.col("Table_name")))

# Now the function maps COEP_werks -> plant, COEP_meinh -> unit_of_measure, etc.
df_mat_consumption_prep1 = table_utils.rename_columns_with_sap_business_header(
    df_mat_consumption_prefixed, df_headers_upper
)

# Pre-clean SAP trailing-sign numbers (e.g. '1.000-' → -1000.0) before cast
for _col in ["total_quantity", "total_value_in_transaction_currency"]:
    df_mat_consumption_prep1 = table_utils.transform_float_column(df_mat_consumption_prep1, _col)

# cast columns with SAP business header (dates and remaining types)
df_mat_consumption_prep1 = table_utils.cast_columns_with_sap_business_headers(
    df_mat_consumption_prep1, df_headers_upper
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Filters
# MAGIC  - Only work orders
# MAGIC  - Quantity > 0

# COMMAND ----------

df_mat_consumption_prep2 = df_mat_consumption_prep1.filter(f.col("unit_of_measure").isNotNull())

# filter only work orders
df_mat_consumption_prep2 = df_mat_consumption_prep2.filter(f.col("object_number").contains("OR"))

# rename object_number to work_order
df_mat_consumption_prep2 = df_mat_consumption_prep2.withColumnRenamed("object_number", "work_order")

df_mat_consumption_prep2 = df_mat_consumption_prep2.filter(f.col("total_quantity") > 0)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 - clean work_order and period columns
# MAGIC the former object_number column in sap (now work_order) is a concatenation of order type + order number
# MAGIC
# MAGIC period column has leading zeros

# COMMAND ----------

# remove first two characters (order type)
df_mat_consumption_transf1 = df_mat_consumption_prep2.withColumn("work_order", f.substring("work_order", 3, 14))
# remove leading zeros
df_mat_consumption_transf1 = table_utils.remove_leading_zeros(df_mat_consumption_transf1, ["work_order", "period", "material_number"])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2 - Extract cost center from partner_object
# MAGIC
# MAGIC the partner_object column in SAP COEP is a composite string (KL + controlling_area + cost_center + padding). Extract the clean cost center number.

# COMMAND ----------

# Extract cost center from partner_object (SAP format: KL + controlling_area + cost_center + padding)
df_mat_consumption_transf2 = df_mat_consumption_transf1.withColumn(
    "cost_center",
    f.when(
        f.col("partner_object").isNotNull(),
        f.regexp_extract(f.col("partner_object"), r"(\S+)\s*$", 1)
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Generate primary key

# COMMAND ----------

w = Window.partitionBy("plant","material_number","fiscal_year","period","work_order", "cost_center").orderBy("COEP_stack_row_id")

# rank over window
df_mat_consumption_transf3 = df_mat_consumption_transf2.withColumn("rank", f.row_number().over(w))

# format rank to string "###"
df_mat_consumption_transf3 = df_mat_consumption_transf3.withColumn("rank", f.lpad(f.col("rank"), 3, "0"))

# create primary key
df_mat_consumption_transf3 = df_mat_consumption_transf3.withColumn(
    "material_consumption_ID",
    f.concat_ws(
        "-",
        f.col("plant"),
        f.col("material_number"),
        f.col("fiscal_year"),
        f.col("period"),
        f.col("work_order"),
        f.col("cost_center"),
        f.col("rank")
    )
)

# reorder columns list to have PK in first
PK_col = "material_consumption_ID"
columns = df_mat_consumption_transf3.columns
columns.remove(PK_col)
new_column_order = [PK_col] + columns
df_mat_consumption_transf3 = df_mat_consumption_transf3.select(new_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Unitary Price

# COMMAND ----------

df_mat_consumption_transf4 = df_mat_consumption_transf3.withColumn(
    "unit_price_in_transaction_currency",
    f.when(
        (f.col("total_quantity") > 0),
        f.try_divide(f.col("total_value_in_transaction_currency"), f.col("total_quantity")),
    ).otherwise(None),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_to_check = df_mat_consumption_transf4
col_pk = "material_consumption_ID"

gx_validation.gx_check_uniqueness(
    df=df_to_check,
    col=col_pk,
    validation_level="RED",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name=DESTINATION_TABLE,
)

gx_validation.gx_check_not_null(
    df=df_to_check,
    col=col_pk,
    validation_level="RED",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name=DESTINATION_TABLE,
)


# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Silver material consumption

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "production"
# DESTINATION_TABLE is defined in the Plant Scope Configuration section
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_mat_consumption_transf4,
    mode="overwrite",
    overwrite_schema=True
)

# Adding constraint primary key in DBX
TABLE_CONSTRAINT_NAME = "material_consumption_PK"  # convention naming : tablename_PK
TABLE_PK_COLS = "material_consumption_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_PK_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_PK_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key (handle eventual consistency of information_schema)
    try:
        table_utils.add_table_primary_key(
            table_path=DESTINATION_TABLE_FULL_PATH,
            pk_name=TABLE_CONSTRAINT_NAME,
            columns=TABLE_PK_COLS,
        )
    except Exception as e:
        if "DELTA_CONSTRAINT_ALREADY_EXISTS" in str(e):
            pass
        elif "PERMISSION_DENIED" in str(e) or "UnauthorizedAccessException" in str(e):
            log.warning(f"Skipping PK constraint: insufficient permissions (MANAGE) on {DESTINATION_TABLE_FULL_PATH}")
        else:
            raise
