# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # SILVER WORK ORDERS
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC This data asset has been created to centralize and structure all relevant information related to SAP production orders.
# MAGIC The objective is to provide a trusted, historical, and unified view of manufacturing orders that can be reused across different analytical and reporting use cases.
# MAGIC
# MAGIC By consolidating data from core SAP tables such as AUFK (order master), AFKO (order header), AFPO (order items), and JEST/TJ02T (status management), this dataset enables:
# MAGIC
# MAGIC 🔎 Tracking the lifecycle of production orders (from creation to completion).
# MAGIC
# MAGIC 📊 Analyzing order progress, delays, and bottlenecks.
# MAGIC
# MAGIC 🏭 Supporting manufacturing performance KPIs and operational reporting.
# MAGIC
# MAGIC 🔗 Providing a single source of truth for downstream consumers (dashboards, data science models, audits).
# MAGIC
# MAGIC This asset is part of the silver layer in the data pipeline, ensuring data is clean, incremental, and historically traceable.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - Stack and match of extraction_timestamp of several tables
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Work_Orders_Daily
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afko_stack`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.aufk_stack`  
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afpo_stack`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_afko`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_aufk` 
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_afpo`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.jest_latest`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tj02t_latest`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC   - `{PIPELINE_WRITE_ENV}_silver.production.work_orders_sap`  
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
import time
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##Input Function

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import SAP TABLES & business headers

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - AFKO - Order Header Data for PP Orders  
# MAGIC it stores the header-level information of production orders, planned orders, and process orders in the Production Planning (PP) module

# COMMAND ----------

df_afko_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afko_latest"
)
# headers
df_afko_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_afko"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - AFPO - Order Item Data for PP Orders  
# MAGIC It stores the item-level details of production orders, planned orders, and process orders in the Production Planning (PP) module

# COMMAND ----------

df_afpo_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afpo_latest"
)
# headers
df_afpo_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_afpo"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - AUFK - Order Item Data for PP Orders  
# MAGIC It stores the item-level details of production orders, planned orders, and process orders in the Production Planning (PP) module

# COMMAND ----------

df_aufk_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.aufk_latest"
)
# headers
df_aufk_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_aufk"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - JEST - Individual Object Status  
# MAGIC It stores the current and historical status information of SAP objects (orders, notifications, projects, equipment, etc.) based on the status management system

# COMMAND ----------

df_jest_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.jest_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - TJ02T - System Status Texts  
# MAGIC It contains the descriptions of status codes (system/user statuses) in different languages

# COMMAND ----------

df_tj02t_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tj02t_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 - AFKO renaming 

# COMMAND ----------

df_afko_prepared = table_utils.add_prefix_to_columns(df_afko_raw, "AFKO")
df_name_afko = delete_null_rows(df_afko_headers)

# Call Function Rename Columns according header file
df_column_afko = table_utils.rename_columns_with_sap_business_header(
    df_afko_prepared, df_name_afko
)
# Call Funtion Create Columns on Date format
df_afko_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_afko, df_name_afko
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 - AFPO filter & renaming 

# COMMAND ----------

df_afpo_prepared = table_utils.add_prefix_to_columns(df_afpo_raw, "AFPO")
df_name_afpo = delete_null_rows(df_afpo_headers)

# Call Function Rename Columns according header file
df_column_afpo = table_utils.rename_columns_with_sap_business_header(
    df_afpo_prepared, df_name_afpo
)
# Call Funtion Create Columns on Date format
df_afpo_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_afpo, df_name_afpo
)
# Exclusion special work order co-product not used since 2016
df_afpo_renamed = df_afpo_renamed.filter(f.col("AFPO_posnr") == "0001")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 - AUFK filter and renaming 

# COMMAND ----------

df_aufk_prepared = table_utils.add_prefix_to_columns(df_aufk_raw, "AUFK")
df_name_aufk = delete_null_rows(df_aufk_headers)
# Call Function Rename Columns according header file
df_column_aufk = table_utils.rename_columns_with_sap_business_header(
    df_aufk_prepared, df_name_aufk
)
# Call Funtion Create Columns on Date format
df_aufk_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_aufk, df_name_aufk
)

# Keep only Production Orders
df_aufk_renamed = df_aufk_renamed.filter(f.col("AUFK_autyp") == "10")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 4 - JEST filter, renaming & Select

# COMMAND ----------

df_jest_prepared = df_jest_raw.filter(
    (f.substring(f.col("objnr"), 1, 2) == "OR") & (f.col("inact").isNull())
)
# Extract WO_Order_Number from objnr field
df_jest_prepared = df_jest_prepared.withColumn(
    "work_order_number", f.substring(f.col("objnr"), 8, 7)
)
df_jest_prepared = df_jest_prepared.select("work_order_number", "stat")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 5 - TJ02T filter, renaming & Select

# COMMAND ----------

# Keep only English language (spras)
df_tj02t_prepared = df_tj02t_raw.filter(f.col("spras") == "E")
df_tj02t_prepared = df_tj02t_prepared.select(f.col("istat").alias("stat"), "txt04")

# Join Status Table with description
df_join_status = df_jest_prepared.join(df_tj02t_prepared, ["stat"], "left")

# Collect all active status on one cells WO_Status
df_status_end = df_join_status.groupBy("work_order_number").agg(
    f.concat_ws(" ", f.collect_list(f.col("txt04"))).alias("WO_status_system")
)
# Remove leading zero
df_status_end = table_utils.remove_leading_zeros(
    df=df_status_end,
    column_names=[
        "work_order_number",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 - Join principal table for work orders   
# MAGIC AUFK-AFPO-AFKO

# COMMAND ----------

df_join_wo = df_aufk_renamed.join(df_afko_renamed, ["work_order_number"], "inner").join(
    df_afpo_renamed, ["work_order_number"], "inner"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 - Cleaning raw data

# COMMAND ----------

# Remove leading zero
df_wo_clean = table_utils.remove_leading_zeros(
    df=df_join_wo,
    column_names=[
        "work_order_number",
        "material_number",
        "profit_center",
        "work_order_reference",
        "sales_orders",
        "sales_orders_item",
        "WBS_element",
        "planned_order_link"
    ],
)
df_wo_clean = df_wo_clean.withColumn(
    "sales_orders_item",
    f.when(f.col("sales_orders_item") == "", f.lit(None)).otherwise(
        f.col("sales_orders_item")
    ),
)
# Due to some inconsistency in SAP raw data, we need to replace empty date
df_wo_clean = (
    df_wo_clean.withColumn(
        "end_planned_date",
        f.coalesce(f.col("end_planned_date"), f.col("start_planned_date")),
    )
    .withColumn(
        "start_planned_date",
        f.coalesce(f.col("start_planned_date"), f.col("end_planned_date")),
    )
    .withColumn(
        "start_scheduled_date",
        f.coalesce(f.col("start_scheduled_date"), f.col("end_scheduled_date")),
    )
    .withColumn(
        "end_scheduled_date",
        f.coalesce(f.col("end_scheduled_date"), f.col("start_scheduled_date")),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 - Add Status on work orders header   
# MAGIC

# COMMAND ----------

df_wo_status = df_wo_clean.join(df_status_end, ["work_order_number"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 4 – Update MRP_Unit
# MAGIC
# MAGIC AS MRP_Unit had been deployed 5 years ago, we have to fullfill MRP_unit for old WO.  
# MAGIC Need to make join with material master data.  

# COMMAND ----------

df_wo_mrp = df_wo_status.withColumn(
    "MRP_unit", f.coalesce(f.col("MRP_unit"), f.col("plant"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 5 – Business Indicator Flags

# COMMAND ----------

# Cast Columns for business Flag indicators
df_wo_business = df_wo_mrp.withColumn(
    "AUFK_idat2", f.col("AUFK_idat2").cast("float")
).withColumn("AUFK_idat3", f.col("AUFK_idat3").cast("float"))
#------------------------------------------------------------
df_wo_business = (
    df_wo_business.withColumn(
        "is_delivered",
        f.when(
            (f.col("AFPO_elikz") == "X")
            | (f.col("quantity_delivered") > 0)
            | (
                ((f.col("AUFK_idat2") > 0) | (f.col("AUFK_idat3") > 0))
                & (f.substring(f.col("work_order_type"), 4, 1) == "9")
            ),
            f.lit(True),
        ).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_cancelled",
        f.when(
            (f.col("is_delivered") == False)
            & (
                (f.col("AUFK_loekz") == "X")
                | ((f.col("AUFK_idat2") > 0) | (f.col("AUFK_idat3") > 0))
            ),
            f.lit(True),
        ).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_in_progress",
        f.when(
            (f.col("is_delivered") == False)
            & (f.col("is_cancelled") == False)
            & (f.col("real_launching_date").isNotNull())
            & (f.col("quantity_planned")!= (f.col("quantity_scrapped"))),
            f.lit(True),
        ).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_FAI_process",
        f.when(
            f.substring(f.col("AFKO_zpp_statu"), 0, 1) == "F", f.lit(True)
        ).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_scrapped",
        f.when(
            (f.col("quantity_planned") == f.col("quantity_scrapped")), f.lit(True)
        ).otherwise(f.lit(False)),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

df_to_check = df_wo_business
col_pk = "work_order_number"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for work order table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="invoice_supplier_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Work orders table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "production"
DESTINATION_TABLE = "work_orders_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_wo_business,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_wo_business.count()} rows.")
    if result is not None:
        result.display()
