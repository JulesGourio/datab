# Databricks notebook source
# MAGIC %md
# MAGIC ## Create Headers — SP2 WO Operation Status
# MAGIC
# MAGIC This notebook creates the header mapping table for `sp2_WO_operation_status` in `{PIPELINE_WRITE_ENV}_bronze.headers_others`.
# MAGIC
# MAGIC It defines the field-to-business-name mapping and data format for each column, then writes it as a Delta table.

# COMMAND ----------

from pyspark.sql import Row

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# Header creation notebooks write to the pipeline env before promotion to prod
HEADERS_TABLE = f"{PIPELINE_WRITE_ENV}_bronze.headers_others.headers_sp2_WO_operation_status"

spark.sql(f"DROP TABLE IF EXISTS {HEADERS_TABLE}")

header_rows = [
    Row(Table_name="sp2_WO_operation_status", Field="ofab",                         Business_name="work_order_ID",                   Format="String"),
    Row(Table_name="sp2_WO_operation_status", Field="oper",                         Business_name="operation_ID",                    Format="String"),
    Row(Table_name="sp2_WO_operation_status", Field="etat",                         Business_name="sp2_operation_status_code",       Format="String"),
    Row(Table_name="sp2_WO_operation_status", Field="date1",                        Business_name="sp2_operation_end_date",          Format="Date"),
    Row(Table_name="sp2_WO_operation_status", Field="datcre",                       Business_name="sp2_created_timestamp",           Format="String"),
    Row(Table_name="sp2_WO_operation_status", Field="utilcre",                      Business_name="sp2_created_by",                  Format="String"),
    Row(Table_name="sp2_WO_operation_status", Field="datmod",                       Business_name="sp2_modified_timestamp",          Format="String"),
    Row(Table_name="sp2_WO_operation_status", Field="utilmod",                      Business_name="sp2_modified_by",                 Format="String")
]

df_new_headers = spark.createDataFrame(header_rows)

df_new_headers.write.format("delta").mode("overwrite").saveAsTable(HEADERS_TABLE)

# COMMAND ----------

spark.sql(f"""
    ALTER TABLE {HEADERS_TABLE}
    SET TBLPROPERTIES ('comment' = 'Header mapping for SP2 WO operation status complete.')
""")
