# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Silver SP2 Work Order Status
# MAGIC
# MAGIC **Description:**
# MAGIC Builds the cleaned SP2 status table at work order operation grain.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - SP2 — check
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sp2_lfr_ingestion.v_data_view_op_status_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sp2_lbg_ingestion.v_data_view_op_status_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sp2_lmxa_ingestion.v_data_view_op_status_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sp2_lmxc_ingestion.v_data_view_op_status_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sp2_lmxd_ingestion.v_data_view_op_status_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sp2_ldb.v_data_view_op_status_latest`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{REFERENCE_READ_ENV}_bronze.headers_others.headers_sp2_WO_operation_status`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{PIPELINE_WRITE_ENV}_silver.production.sp2_WO_operation_status`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

from functools import reduce

import pyspark.sql.functions as f
import great_expectations as gx
from pyspark.sql import DataFrame

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger and Constants

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

DEST_TABLE = f"{PIPELINE_WRITE_ENV}_silver.production.sp2_WO_operation_status"

# Site code -> Bronze schema. Site codes must match the site prefix used in work_order_operation
SP2_SOURCES = {
    "LFR1": "sp2_lfr_ingestion",
    "LBG1": "sp2_lbg_ingestion",
    "LMXA": "sp2_lmxa_ingestion",
    "LMXC": "sp2_lmxc_ingestion",
    "LMXD": "sp2_lmxd_ingestion",
    "LDB1": "sp2_ldb",
}

log.info(f"Destination table: {DEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Header tables

# COMMAND ----------

df_header_sp2_status_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_others.headers_sp2_WO_operation_status")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze source tables

# COMMAND ----------

dfs_sp2_raw = {
    site: spark.read.table(f"{REFERENCE_READ_ENV}_bronze.{schema}.v_data_view_op_status_latest")
    for site, schema in SP2_SOURCES.items()
}

# COMMAND ----------

# MAGIC %md
# MAGIC # Functions

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## SP2 status - Merge sites
# MAGIC Each SP2 site has its own Bronze table with the same schema, so they are merged into one.
# MAGIC Work order numbers are only unique within a site, so the site code is kept and used in the PK

# COMMAND ----------

site_col = 'sp2_source_country'

df_sp2_wo_raw = reduce(
    DataFrame.unionByName,
    [df.withColumn(site_col, f.lit(site)) for site, df in dfs_sp2_raw.items()],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## SP2 status - Headers

# COMMAND ----------

prefix = "sp2_WO_operation_status"
df_sp2_wo_prep = table_utils.add_prefix_to_columns(df_sp2_wo_raw, prefix)

# Rename the prefixed site_col back to its original name
df_sp2_wo_prep = df_sp2_wo_prep.withColumnRenamed(f"{prefix}_{site_col}", site_col)

df_sp2_wo_prep = table_utils.rename_columns_with_sap_business_header(df_sp2_wo_prep, df_header_sp2_status_raw)
df_sp2_wo_prep = table_utils.trim_dataframe(df_sp2_wo_prep)
df_sp2_wo_prep = table_utils.cast_columns_with_sap_business_headers(df_sp2_wo_prep, df_header_sp2_status_raw, date_format="yyyy-MM-dd HH:mm:ss.SSS")

# COMMAND ----------

# MAGIC %md
# MAGIC ### SP2 Status - Remove leading zeroes from operation ID

# COMMAND ----------

# Remove leading zeroes
df_sp2_wo_prep = table_utils.remove_leading_zeros(df_sp2_wo_prep, ["operation_ID"])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Primary Key and Quality Checks

# COMMAND ----------

df_sp2_wo_out = df_sp2_wo_prep.withColumn(
    "WO_operation_status_ID",
    f.concat_ws("-", f.col("work_order_ID"), f.col("operation_ID"), f.col(site_col)),
)
remaining_cols = [c for c in df_sp2_wo_out.columns if c != "WO_operation_status_ID"]
df_sp2_wo_out = df_sp2_wo_out.select("WO_operation_status_ID", *remaining_cols)
if DEBUG:
    _row_count = df_sp2_wo_out.count()
    log.info(f"Silver SP2 status: {_row_count} rows")

dfgx = gx.dataset.SparkDFDataset(df_sp2_wo_out, persist=False)

# RED checks
red_results = [
    dfgx.expect_column_values_to_not_be_null(column="WO_operation_status_ID"),
    dfgx.expect_column_values_to_be_unique(column="WO_operation_status_ID")
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="RED checks passed: WO_operation_status_ID unique and not null; WO_operation_status_ID not null",
    error_message="RED check failed on SP2 status — duplicate WO_operation_status_ID items or missing WO_operation_status_ID key",
)

amber_results = []

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

table_utils.save_table(
    dest_table=DEST_TABLE,
    df=df_sp2_wo_out,
    mode="overwrite",
    overwrite_schema=True,
)

log.info(f"Saved: {DEST_TABLE}")
