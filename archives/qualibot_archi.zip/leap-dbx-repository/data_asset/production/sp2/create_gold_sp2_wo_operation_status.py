# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Gold SP2 Work Order Status
# MAGIC
# MAGIC **Description:**
# MAGIC Builds the cleaned SP2 status table at work order operation grain.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - SP2 — check
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{PIPELINE_READ_ENV}_silver.production.sp2_WO_operation_status`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.production.sp2_WO_operation_status`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC NA

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger and Constants

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

DEST_TABLE = f"{PIPELINE_WRITE_ENV}_gold.production.sp2_WO_operation_status"
DEST_VIEW = f"{PIPELINE_WRITE_ENV}_gold.production.sp2_WO_operation_status_exposed"

log.info(f"Destination table: {DEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver SP2 Work Order Operations

# COMMAND ----------

df_status_raw = spark.read.table(f"{PIPELINE_READ_ENV}_silver.production.sp2_WO_operation_status")

# COMMAND ----------

# MAGIC %md
# MAGIC # Functions

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

df_status_prep = df_status_raw.select("work_order_ID", "operation_ID", "sp2_operation_status_code",
                                      "sp2_operation_end_date", "sp2_source_country")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ### Work order operation status value mapping

# COMMAND ----------

status_mapping = {
    "0": "Not started",
    "2": "In transit (current operation started and previous operation closed)",
    "4": "In progress (at least 1 time record done on this operation)",
    "6": "Operation stopped (The operation is stopped but not closed)",
    "7": "Operation deleted",
    "8": "Operation finished",
    "9": "Operation closed",
}

mapping_expr = f.coalesce(
    *[f.when(f.col("sp2_operation_status_code") == k, f.lit(v)) for k, v in status_mapping.items()]
)

df_status_prep = df_status_prep.withColumn("sp2_operation_status_value", mapping_expr)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Primary Key and Quality Checks

# COMMAND ----------

df_status_out = df_status_prep.withColumn(
    "WO_operation_status_ID",
    f.concat_ws("-", f.col("work_order_ID"), f.col("operation_ID"), f.col('sp2_source_country')),
)
remaining_cols = [c for c in df_status_out.columns if c != "WO_operation_status_ID"]
df_status_out = df_status_out.select("WO_operation_status_ID", *remaining_cols)
if DEBUG:
    _row_count = df_status_out.count()
    log.info(f"Gold SP2 status: {_row_count} rows")

dfgx = gx.dataset.SparkDFDataset(df_status_out, persist=False)

# RED checks
red_results = [
    dfgx.expect_column_values_to_not_be_null(column="WO_operation_status_ID"),
    dfgx.expect_column_values_to_be_unique(column="WO_operation_status_ID")
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="RED checks passed: WO_operation_status_ID unique and not null; WO_operation_status_ID not null",
    error_message="RED check failed on SP2 status — duplicate WO_operation_status_ID items or missing WO_operation_status_ID key",
)

amber_results = []

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

table_utils.save_table(
    dest_table=DEST_TABLE,
    df=df_status_out,
    mode="overwrite",
    overwrite_schema=True,
)

log.info(f"Saved: {DEST_TABLE}")

# COMMAND ----------

_TECH_PREFIXES = ("sp2_WO_operation_status")
_exposed_cols = [c for c in df_status_out.columns if not c.startswith(_TECH_PREFIXES)]
table_utils.create_table_view(
    src_full_tablename=DEST_TABLE,
    dest_full_tablename=DEST_VIEW,
    select_statement=", ".join(f"`{c}`" for c in _exposed_cols),
    replace_view=True,
)
log.info(f"Created view: {DEST_VIEW} ({len(_exposed_cols)} columns)")
