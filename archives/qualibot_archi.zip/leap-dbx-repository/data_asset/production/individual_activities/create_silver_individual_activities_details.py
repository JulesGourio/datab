# Databricks notebook source
# MAGIC %md
# MAGIC    
# MAGIC    
# MAGIC # Create Silver - Individual Activities Details (Horoquartz)
# MAGIC
# MAGIC **Description:**  
# MAGIC Creates the silver table for individual activities details from Horoquartz (HQA). The notebook performs the following transformations on the bronze data:
# MAGIC 1. Filter out parasitic header rows
# MAGIC 2. Combine date and hour columns into timestamps (date_deb, date_fin)
# MAGIC 3. Cast date columns (date_jour) from string to date
# MAGIC 4. Cast numeric columns (duree_eve) to double
# MAGIC 5. Rename columns from source abbreviations to descriptive English names
# MAGIC 6. Replace empty strings with null
# MAGIC 7. Remove accented characters
# MAGIC
# MAGIC **Incremental update strategy:**  
# MAGIC On each run, the notebook compares `_meta_extraction_timestamp` in `cci_latest` against the max value already present in the silver table.  
# MAGIC - Only `date_jour` partitions that contain at least one row with a newer `_meta_extraction_timestamp` are re-read **in full** from `cci_latest` and overwritten in silver via `replace_where`.  
# MAGIC - On the first run (init), or if the silver table does not exist, the full `cci_latest` table is read and written.
# MAGIC - If no new data is found, the write is skipped entirely.
# MAGIC
# MAGIC **Primary key:** `evenement`, `matri`, `date_jour`, `ordre`
# MAGIC
# MAGIC **Input table:**  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.horoquartz_ingestion.cci_latest
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_silver.production.individual_activities_details_hqa

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import time

from pyspark.sql import DataFrame
from pyspark.sql import functions as f
from pyspark.sql.types import StringType
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Manual Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Renaming

# COMMAND ----------

DICT_TO_RENAME_HQA = {
    "matri": "employee_code",
    "evenement": "event",
    "date_jour": "clocking_date",
    "date_deb": "activity_start_date",
    "date_fin": "activity_end_date",
    "heure_deb": "activity_start_time",
    "heure_fin": "activity_end_time",
    "ordre": "clocking_order",  
    "duree_eve": "spent_time_min",
    "valeur01": "imputation_code",     # OF / IMP code / ABS / FORM
    "valeur02": "operation_number",
    "valeur03": "imputation_object_label",
    "valeur04": "employee_cost_center",
    "valeur05": "WBS_code", 
    "valeur06": "workcenter_code",
    "valeur07": "workcenter_label",
    "cle_p": "employee_group",
}

# COMMAND ----------

# MAGIC %md
# MAGIC ### Casting Date

# COMMAND ----------

DATE_COLUMNS_WITHOUT_HOUR = ["date_jour"]

# COMMAND ----------

def combine_date_hour(df: DataFrame, date_col: str, hour_col: str, output_col: str) -> DataFrame:
    """
    Combine a date column and an hour column into a single timestamp column.

    The date column is expected to follow the ``yyyyMMdd`` format (e.g. ``20260319``),
    and the hour column is expected to follow the ``Hmm`` or ``HHmm`` format
    (e.g. ``916`` or ``0916``). Both formats are handled via zero-left-padding.

    Hours >= 24 are normalised with modulo 24, and the quotient is added as
    extra days (e.g. ``2621`` → 02:21 + 1 day, ``3000`` → 06:00 + 1 day).

    If the hour column is blank, null, or non-numeric, the resulting timestamp
    defaults to ``date + 00:00``. This covers events such as ABSENCE, DECOTP,
    etc. that carry no start/end time.

    :param df: Input Spark DataFrame.
    :type df: pyspark.sql.DataFrame
    :param date_col: Name of the column containing the date in ``yyyyMMdd`` format.
    :type date_col: str
    :param hour_col: Name of the column containing the hour in ``Hmm`` / ``HHmm`` format.
    :type hour_col: str
    :param output_col: Name of the output timestamp column.
    :type output_col: str
    :return: DataFrame with the new timestamp column appended.
    :rtype: pyspark.sql.DataFrame

    :example:

    >>> df = combine_date_hour(df, "date_deb", "heure_deb", "ts_deb")
    >>> df.select("ts_deb").show()
    +-------------------+
    |              ts_deb|
    +-------------------+
    |2026-03-19 09:16:00|
    +-------------------+
    """
    # Detect blank/null hour values (e.g. events like ABSENCE that carry no time)
    is_blank = f.trim(f.col(hour_col)).isin("", " ") | f.col(hour_col).isNull()

    padded_hour = f.lpad(f.trim(f.col(hour_col)), 4, "0")

    # Extract hour (first 2 digits) and minutes (last 2 digits)
    raw_hour = f.substring(padded_hour, 1, 2).cast("int")
    minutes = f.substring(padded_hour, 3, 2)

    # Normalise hours >= 24 with modulo and compute extra days
    extra_days = (raw_hour / 24).cast("int")
    normalised_hour = f.lpad((raw_hour % 24).cast("string"), 2, "0")

    # Build the safe HHmm string and parse the base timestamp
    safe_hour = f.concat(normalised_hour, minutes)
    base_ts = f.to_timestamp(
        f.concat(f.col(date_col), safe_hour),
        "yyyyMMddHHmm"
    )

    # Add extra days when hour was >= 24
    result_ts = f.when(
        extra_days > 0,
        base_ts + f.concat(extra_days.cast("string"), f.lit(" days")).cast("interval")
    ).otherwise(base_ts)

    # For blank/null hour values, default to date + 00:00 instead of null
    default_ts = f.to_timestamp(f.col(date_col), "yyyyMMdd")
    return df.withColumn(output_col, f.when(is_blank, default_ts).otherwise(result_ts))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Casting Double

# COMMAND ----------

DOUBLE_COLUMNS = ["duree_eve"]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Indivual Activities

# COMMAND ----------

# ---------------------------------------------------------
# Read source table
# ---------------------------------------------------------
df_cci_latest = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.horoquartz_ingestion.cci_latest"
)

# ---------------------------------------------------------
# Incremental filter: only re-process affected date_jour
# partitions whose _meta_extraction_timestamp is newer than
# what the silver table already contains.
# Primary key: evenement, matri, date_jour, ordre
# ---------------------------------------------------------
_silver_table = f"{PIPELINE_WRITE_ENV}_silver.production.individual_activities_details_hqa"

try:
    _max_ts = (
        spark.read.table(_silver_table)
        .select(f.max("_meta_extraction_timestamp"))
        .collect()[0][0]
    )
except AnalysisException:
    _max_ts = None

if _max_ts is not None:
    _new_rows = df_cci_latest.filter(f.col("_meta_extraction_timestamp") > _max_ts)
    _affected_dates = [
        row["date_jour"]
        for row in _new_rows.select("date_jour").distinct().collect()
    ]
    if _affected_dates:
        # Re-read COMPLETE partitions for affected dates from cci_latest
        df_indiv_activities = df_cci_latest.filter(
            f.col("date_jour").isin(_affected_dates)
        )
        log.info(
            f"Incremental: {len(_affected_dates)} date partitions to refresh "
            f"(_meta_extraction_timestamp > {_max_ts})"
        )
    else:
        df_indiv_activities = df_cci_latest.limit(0)
        log.info("No new data since last run — nothing to process.")
else:
    df_indiv_activities = df_cci_latest
    log.info("Init mode: reading all data from cci_latest.")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 - Individual Activities

# COMMAND ----------

# DBTITLE 1,Prep 1.0 header
# MAGIC %md
# MAGIC    
# MAGIC ### Prep. 1.0 - Filter out parasitic header rows

# COMMAND ----------

# Remove rows where hour columns contain non-numeric values
# (e.g. a CSV header row leaked into the data with 'DATMOD' in heure_deb)
df_indiv_activities = df_indiv_activities.filter(
    f.trim(f.col("heure_deb")).rlike("^[0-9]+$")
    | f.trim(f.col("heure_deb")).isin("", " ")
    | f.col("heure_deb").isNull()
)

# COMMAND ----------

# DBTITLE 1,Prep 1.1 header
# MAGIC %md
# MAGIC    
# MAGIC    
# MAGIC ### Prep. 1.1 - Combine date and hour into timestamps

# COMMAND ----------

df_indiv_activities = combine_date_hour(
    df_indiv_activities, "date_deb", "heure_deb", "date_deb"
)
df_indiv_activities = combine_date_hour(
    df_indiv_activities, "date_fin", "heure_fin", "date_fin"
)

# Drop heure_deb and heure_fin
df_indiv_activities = df_indiv_activities.drop("heure_deb", "heure_fin")

# COMMAND ----------

# MAGIC %md
# MAGIC    
# MAGIC ### Prep. 1.2 - Cast date columns (that does not have hours)

# COMMAND ----------

for col_name in DATE_COLUMNS_WITHOUT_HOUR:
    if isinstance(df_indiv_activities.schema[col_name].dataType, StringType):
        df_indiv_activities = df_indiv_activities.withColumn(
            col_name, f.try_to_date(f.trim(f.col(col_name)), "yyyyMMdd")
        )

# COMMAND ----------

# MAGIC %md
# MAGIC    
# MAGIC ### Prep. 1.3 - Cast numeric columns

# COMMAND ----------

for col_name in DOUBLE_COLUMNS:
    df_indiv_activities = df_indiv_activities.withColumn(
        col_name, f.col(col_name).cast("double")
    )

# COMMAND ----------

# DBTITLE 1,Prep 4 header
# MAGIC %md
# MAGIC    
# MAGIC ### Prep. 1.4 - Rename columns

# COMMAND ----------

for old_name, new_name in DICT_TO_RENAME_HQA.items():
    df_indiv_activities = df_indiv_activities.withColumnRenamed(old_name, new_name)

# COMMAND ----------

# DBTITLE 1,Prep 1.5 header
# MAGIC %md
# MAGIC    
# MAGIC    
# MAGIC ### Prep. 1.5 - Replace empty strings with null

# COMMAND ----------

str_columns = [
    field.name
    for field in df_indiv_activities.schema.fields
    if isinstance(field.dataType, StringType)
]

for col_name in str_columns:
    df_indiv_activities = df_indiv_activities.withColumn(
        col_name,
        f.when(f.trim(f.col(col_name)) == "", None).otherwise(f.col(col_name)),
    )

# COMMAND ----------

# DBTITLE 1,Prep 1.6 header
# MAGIC %md
# MAGIC    
# MAGIC    
# MAGIC ### Prep. 1.6 - Remove accented characters

# COMMAND ----------

ACCENTED =     "àâäéèêëïîôöùûüçÀÂÄÉÈÊËÏÎÔÖÙÛÜÇ"
NON_ACCENTED = "aaaeeeeiioouuucAAAEEEEIIOOUUUC"

for col_name in str_columns:
    df_indiv_activities = df_indiv_activities.withColumn(
        col_name,
        f.translate(f.col(col_name), ACCENTED, NON_ACCENTED),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "production"
DESTINATION_TABLE = "individual_activities_details_hqa"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

# ---------------------------------------------------------
# 1. Extract distinct clocking dates from the batch
# ---------------------------------------------------------
dates_in_batch = df_indiv_activities.select("clocking_date").distinct().collect()
dates_in_batch = [row["clocking_date"] for row in dates_in_batch]

# ---------------------------------------------------------
# 2. Log replaced partitions
# ---------------------------------------------------------
if dates_in_batch:
    log.info(f"SILVER - Replacing {len(dates_in_batch)} partitions:")
    for d in dates_in_batch:
        log.debug(f"--> {d}")
else:
    log.info("SILVER - No new data to write. Skipping.")

# ---------------------------------------------------------
# 3. Build replace_where for silver
# ---------------------------------------------------------
replace_where = None
if dates_in_batch:
    quoted = ",".join([f"'{d}'" for d in dates_in_batch])
    replace_where = f"clocking_date IN ({quoted})"

# ---------------------------------------------------------
# 4. Overwrite ONLY the batch partitions (init: full write)
#    Skip entirely when there is nothing new.
# ---------------------------------------------------------
if dates_in_batch:
    try:
        startTime = time.time()
        result = table_utils.save_table(
            dest_table=DESTINATION_TABLE_FULL_PATH,
            df=df_indiv_activities,
            mode="overwrite",
            overwrite_schema=False,
            cluster_cols="clocking_date",
            merge_schema=True,
            replace_where=replace_where,
        )
    except AnalysisException as e:
        log.error(
            f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
        )
        raise
    else:
        duration = time.time() - startTime
        log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
        log.info(f"Wrote {df_indiv_activities.count()} rows.")
        if result is not None:
            result.display()
