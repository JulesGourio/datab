# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Gold - Individual Activities Details (Horoquartz)
# MAGIC
# MAGIC **Description:**  
# MAGIC Creates the gold table for individual activities details from Horoquartz (HQA) by promoting the silver table to the gold layer. Unwanted columns (`UTILCRE`, `UTILMOD`, `VALEUR08`, `VALEUR09`, `VALEUR10`) are dropped before writing. An exposed view is also created with a restricted subset of columns.
# MAGIC
# MAGIC **Input table:**  
# MAGIC   - {REFERENCE_READ_ENV}_silver.production.individual_activities_details_hqa
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.production.individual_activities_details_hqa
# MAGIC
# MAGIC **Output view:**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.production.individual_activities_details_hqa_exposed  
# MAGIC     *(columns: employee_code, event, activity_start_date, activity_end_time, work_order, spent_time_min, work_order_time_detail, imputation_object, imputation_object_label, employee_cost_center)*

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import time

from pyspark.sql import functions as F
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Manual Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Deleting

# COMMAND ----------

LIST_TO_REMOVE_HQA = ["valeur08", "valeur09", "valeur10"]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Individual Activities

# COMMAND ----------

df_indiv_activities = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.production.individual_activities_details_hqa"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 - Individual Activities

# COMMAND ----------

# MAGIC %md
# MAGIC    
# MAGIC ### Prep. 1.1 - Drop unwanted columns

# COMMAND ----------

df_indiv_activities = df_indiv_activities.drop(*LIST_TO_REMOVE_HQA)

# COMMAND ----------

# DBTITLE 1,Prep 1.2 header
# MAGIC %md
# MAGIC    
# MAGIC    
# MAGIC ### Prep. 1.2 - Split imputation_code and WBS_code

# COMMAND ----------

# Helper: classify imputation_code type for conditional logic
_imp_type = (
    F.when(F.col("imputation_code") == "FORM", F.lit("formation"))
     .when(F.col("imputation_code").isin("ABS", "ABSJ"), F.lit("absence"))
     .when(F.col("imputation_code").rlike("^IMP\\d+"), F.lit("improductivity"))
     .when(F.col("imputation_code").rlike("^\\d{9}$"), F.lit("work_order"))
)

df_indiv_activities = (
    df_indiv_activities
    .withColumn("_imp_type", _imp_type)
    .withColumns({
        "work_order":          F.when(F.col("_imp_type") == "work_order",     F.col("imputation_code")),
        "absence_code":        F.when(F.col("_imp_type") == "absence",        F.col("imputation_code")),
        "formation_code":      F.when(F.col("_imp_type") == "formation",      F.col("imputation_code")),
        "improductivity_code": F.when(F.col("_imp_type") == "improductivity", F.col("imputation_code")),
        "wbs_code":            F.when(F.col("_imp_type") == "work_order",     F.col("WBS_code")),
        "cost_center_code":    F.when(
                                   F.col("_imp_type").isin("absence", "formation") & (F.col("WBS_code") != "999"),
                                   F.col("WBS_code")),
    })
    .drop("imputation_code", "_imp_type")
)

# COMMAND ----------

# DBTITLE 1,Prep 1.3 header
# MAGIC %md
# MAGIC    
# MAGIC    
# MAGIC ### Prep. 1.3 - Remove leading zeros from work_order

# COMMAND ----------

df_indiv_activities = table_utils.remove_leading_zeros(df_indiv_activities, ["work_order"])

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "production"
DESTINATION_TABLE = "individual_activities_details_hqa"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_indiv_activities,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_indiv_activities.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Exposed Table View

# COMMAND ----------

exposed_columns = [
    "employee_code",
    "employee_cost_center",
    "event",
    "activity_start_date",
    "activity_end_date",
    "clocking_order",
    "workcenter_code",
    "workcenter_label",
    "spent_time_min",
    "operation_number",
    "work_order",
    "absence_code",
    "formation_code",
    "improductivity_code",
    "imputation_object_label",
    "wbs_code",
    "cost_center_code",
]

dest_full_tablename = f"{DESTINATION_TABLE_FULL_PATH}_exposed"

selected_columns = [col for col in exposed_columns]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename,
    select_statement,
    replace_view=True,
)

log.info(f"The table view {dest_full_tablename} has been successfully created")
