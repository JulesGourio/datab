# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Silver MES Operation Document
# MAGIC
# MAGIC **Description:**
# MAGIC The technical documents MES shows the operator on each work order operation: the PLM documents
# MAGIC propagated into the operation (`dataplm` DOCUMENTS and TRAMATIERE), plus the documents operators
# MAGIC attached by hand. One row per work order operation and document family (the shown revision);
# MAGIC operations showing no document keep one row with an empty document so they can still be
# MAGIC reconciled. Each work order carries its SAP routing, which is how MES links to PLM.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - [One Shown Revision per Family](#one-shown-revision-per-family)
# MAGIC - [Extract manually-added MES documents](#extract-manually-added-mes-documents)
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - uc60_plm_mes_reconciliation
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{pipeline_read_env}_silver.production.work_order_operation_mes`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{reference_read_env}_bronze.mes.document_links_latest`
# MAGIC - `{reference_read_env}_bronze.mes.pt_modification_latest`
# MAGIC - `{reference_read_env}_bronze.sap_latecoere_ecc6.afko_latest`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_silver.production.mes_operation_document`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC 1. The document family / revision parsing is duplicated from
# MAGIC    `create_silver_plm_routing_document.py`; both must stay identical so PLM and MES families
# MAGIC    match (see Data Preparation - Document Family and Revision).
# MAGIC 2. The work order → routing link is read from SAP Bronze (AFKO) because
# MAGIC    `work_orders_sap_exposed` doesn't expose `AFKO_plnnr` / `AFKO_plnal`; to be switched once the
# MAGIC    work orders asset exposes them (see Data Preparation - SAP Routing of Each Work Order).

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx
from pyspark.sql.window import Window
from pyspark.sql.types import (
    ArrayType,
    BooleanType,
    StringType,
    StructField,
    StructType,
)

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger and Constants

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

DEST_TABLE = f"{PIPELINE_WRITE_ENV}_silver.production.mes_operation_document"

# Same revision parsing as the PLM Silver — see create_silver_plm_routing_document.py.
REVISION_SEGMENT_REGEX = "-[A-Za-z]{1,2}-[0-9]{2}(?=-|$)"
REVISION_TRAILING_REGEX = r"-[A-Za-z]{1,2}-[0-9]{2}$"

# MES lists consumable/material references (TRAMATIERE) apart from technical documents, but PLM
# files them under the plain-text document type.
TRAMATIERE_DOCUMENT_TYPE = "TXT"
# Documents attached by hand in MES are free files (photos, scans…) with no PLM document type, so
# they get their own type — same wording as the report's "Manually corrected" status.
MANUAL_DOCUMENT_TYPE = "Manually corrected"

ACTIVE_STATUS_ACTIVE = "Active"
ACTIVE_STATUS_INACTIVE = "Inactive"
# document_links doesn't list every document shown (TRAMATIERE references mostly): no link means
# the active state is unknown, not inactive.
ACTIVE_STATUS_UNKNOWN = "Unknown"

log.info(f"Destination table: {DEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## MES - Silver (upstream pipeline)

# COMMAND ----------

df_operation_mes_raw = spark.read.table(f"{PIPELINE_READ_ENV}_silver.production.work_order_operation_mes")

# COMMAND ----------

# MAGIC %md
# MAGIC ## MES - Bronze

# COMMAND ----------

df_document_links_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.mes.document_links_latest")

# COMMAND ----------

df_pt_modification_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.mes.pt_modification_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ## SAP - Bronze

# COMMAND ----------

df_afko_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afko_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Documents Shown on Each Operation
# MAGIC `dataplm` is what MES shows the operator at the workstation: technical documents under
# MAGIC `DOCUMENTS`, consumable/material references under `TRAMATIERE`. Both lists are read as one, and
# MAGIC an operation with an empty list keeps a row with no document.

# COMMAND ----------

_shown_document_type = StructType(
    [
        StructField("Label", StringType(), True),
        StructField("ISLAST", BooleanType(), True),
        StructField("TYPEDOC", StringType(), True),
        StructField("Identifier", StringType(), True),
    ]
)
_tramatiere_type = StructType(
    [
        StructField("TITRE", StringType(), True),
        StructField("ISLAST", BooleanType(), True),
        StructField("Identifier", StringType(), True),
    ]
)
dataplm_schema = StructType(
    [
        StructField("DOCUMENTS", ArrayType(_shown_document_type), True),
        StructField("TRAMATIERE", ArrayType(_tramatiere_type), True),
    ]
)

df_operation_parsed = df_operation_mes_raw.select(
    "work_order",
    "work_order_operation",
    "operation_status",
    "operation_end_date",
    f.from_json(f.col("dataplm"), dataplm_schema).alias("parsed_data_plm"),
)

# DOCUMENTS come first so that, when the same identifier is listed in both arrays, the technical
# document entry is the one kept.
_shown_documents = f.concat(
    f.coalesce(
        f.transform(
            f.col("parsed_data_plm.DOCUMENTS"),
            lambda d: f.struct(
                f.lit(1).alias("source_order"),
                d["TYPEDOC"].alias("document_type"),
                d["Label"].alias("MES_PLM_label"),
                d["Identifier"].alias("technical_document_MES"),
                d["ISLAST"].alias("is_MES_PLM_last"),
            ),
        ),
        f.array(),
    ),
    f.coalesce(
        f.transform(
            f.col("parsed_data_plm.TRAMATIERE"),
            lambda d: f.struct(
                f.lit(2).alias("source_order"),
                f.lit(TRAMATIERE_DOCUMENT_TYPE).alias("document_type"),
                d["TITRE"].alias("MES_PLM_label"),
                d["Identifier"].alias("technical_document_MES"),
                d["ISLAST"].alias("is_MES_PLM_last"),
            ),
        ),
        f.array(),
    ),
)

df_shown_documents_prep = (
    df_operation_parsed.select(
        "work_order",
        "work_order_operation",
        "operation_status",
        "operation_end_date",
        f.explode_outer(_shown_documents).alias("doc"),
    )
    .select(
        "work_order",
        "work_order_operation",
        "operation_status",
        "operation_end_date",
        "doc.*",
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Document Family and Revision
# MAGIC The family groups every revision of the same document; the sort key ranks revisions (letter
# MAGIC length, letter, version — embedded segment first). Same rules as the PLM Silver, so a family
# MAGIC shown in MES finds its PLM counterpart even on another revision.

# COMMAND ----------

_revision_sort_key = f.expr(
    f"concat_ws('|', transform(regexp_extract_all(technical_document_MES, '{REVISION_SEGMENT_REGEX}', 0), "
    "s -> concat(length(regexp_extract(s, '-([A-Za-z]+)-', 1)), "
    "lpad(upper(regexp_extract(s, '-([A-Za-z]+)-', 1)), 2, ' '), "
    "regexp_extract(s, '([0-9]{2})$', 1))))"
)
df_shown_documents_prep = df_shown_documents_prep.withColumn(
    "document_family", f.regexp_replace(f.col("technical_document_MES"), REVISION_SEGMENT_REGEX, "")
).withColumn("revision_sort_key", _revision_sort_key)

# COMMAND ----------

# MAGIC %md
# MAGIC ## One Shown Revision per Family
# MAGIC The same identifier can appear in both DOCUMENTS and TRAMATIERE, and an operation can list
# MAGIC several revisions of one family. The reconciliation needs one shown revision per family: the
# MAGIC highest one is kept, and `has_multiple_revisions_shown` records that the operator saw more
# MAGIC than one.

# COMMAND ----------

_family_window = Window.partitionBy(
    "work_order", "work_order_operation", "document_type", "document_family"
)
df_shown_documents_prep = (
    df_shown_documents_prep.withColumn(
        "_family_revision_count", f.size(f.collect_set("technical_document_MES").over(_family_window))
    )
    .withColumn(
        "_family_rank",
        f.row_number().over(
            _family_window.orderBy(f.col("revision_sort_key").desc_nulls_last(), f.col("source_order"))
        ),
    )
    .where(f.col("_family_rank") == 1)
    .withColumn("has_multiple_revisions_shown", f.col("_family_revision_count") > 1)
    .withColumn("is_doc_added_manually", f.lit(False))
    .drop("_family_rank", "_family_revision_count", "source_order")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Extract manually-added MES documents
# MAGIC When a document mismatch is a real error rather than a normal propagation delay, an operator
# MAGIC corrects it by hand in MES — that correction is logged as a change event in
# MAGIC `pt_modification_latest.data` rather than in the operation's own `dataplm`. These are free files
# MAGIC with no PLM revision, so the file name is their family.

# COMMAND ----------

pt_modification_schema = StructType(
    [
        StructField(
            "wos",
            ArrayType(StructType([StructField("numberWO", StringType(), True)])),
            True,
        ),
        StructField(
            "docs",
            ArrayType(
                StructType(
                    [
                        StructField("fileName", StringType(), True),
                        StructField("isfromMe", BooleanType(), True),
                    ]
                )
            ),
            True,
        ),
        StructField(
            "filter_op",
            ArrayType(StructType([StructField("number", StringType(), True)])),
            True,
        ),
    ]
)

# A modification event lists every work order it was applied to (`wos`) and every document
# attached (`docs`); the operation is the first `filter_op` entry, when the operator set one.
df_mes_manual_docs_prep = (
    df_pt_modification_raw.withColumn(
        "parsed", f.from_json(f.col("data"), pt_modification_schema)
    )
    .select(
        f.explode(f.col("parsed.wos")).alias("wo"),
        f.col("parsed.docs").alias("docs"),
        f.get(f.col("parsed.filter_op"), 0).getField("number").alias("work_order_operation"),
    )
    .select("wo", f.explode(f.col("docs")).alias("doc"), "work_order_operation")
    # Manually-added documents only — a system-propagated document isn't a correction.
    .where(f.col("doc.isfromMe") & f.col("doc.fileName").isNotNull())
    .select(
        f.col("wo.numberWO").alias("work_order"),
        f.regexp_replace(f.col("doc.fileName"), r"\.pdf$", "").alias("technical_document_MES"),
        f.col("work_order_operation").try_cast("int").try_cast("string").alias("work_order_operation"),
    )
    .where(f.col("work_order").isNotNull())
    .dropDuplicates()
    .withColumn("document_type", f.lit(MANUAL_DOCUMENT_TYPE))
    .withColumn("document_family", f.col("technical_document_MES"))
    .withColumn("MES_PLM_label", f.col("technical_document_MES"))
    .withColumn("is_doc_added_manually", f.lit(True))
    .withColumn("has_multiple_revisions_shown", f.lit(False))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Active Flag From Document Links
# MAGIC MES keeps its own active/inactive flag per document link (`isactiveme`), separate from the
# MAGIC operation's `dataplm` list. The same link can carry conflicting values across MES history, so
# MAGIC only the most recently modified one is kept.

# COMMAND ----------

df_active_docs_prep = df_document_links_raw.select(
    "work_order",
    f.col("operation").try_cast("int").try_cast("string").alias("work_order_operation"),
    f.col("label").alias("MES_PLM_label"),
    f.col("isactiveme").alias("is_active_in_mes"),
    "modification_date",
)
df_active_docs_prep = table_utils.drop_duplicates_by_order(
    df=df_active_docs_prep,
    columns=["work_order", "work_order_operation", "MES_PLM_label"],
    order_col=["modification_date"],
    keep="last",
).drop("modification_date")

# COMMAND ----------

# MAGIC %md
# MAGIC ## SAP Routing of Each Work Order
# MAGIC MES doesn't carry the routing number of a work order, and PLM identifies documents by routing,
# MAGIC so the SAP work order header (AFKO) provides the link. The AFKO header table only maps
# MAGIC `aufnr`, so the three fields needed are renamed here.

# COMMAND ----------

df_work_order_routing_prep = df_afko_raw.select(
    f.col("aufnr").alias("work_order"),
    f.col("plnnr").alias("routing_number"),
    f.col("plnal").alias("routing_group_counter"),
)
df_work_order_routing_prep = table_utils.remove_leading_zeros(
    df_work_order_routing_prep, ["work_order"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Combine Shown and Manual Documents
# MAGIC Manual corrections take the operation status of the MES operation they were attached to; the
# MAGIC routing and active flag are then added to every row.

# COMMAND ----------

df_operation_context = df_operation_parsed.select(
    "work_order", "work_order_operation", "operation_status", "operation_end_date"
)
df_mes_manual_docs_prep = df_mes_manual_docs_prep.join(
    df_operation_context, ["work_order", "work_order_operation"], how="left"
)

df_mes_documents = df_shown_documents_prep.unionByName(df_mes_manual_docs_prep, allowMissingColumns=True)

df_mes_documents = df_mes_documents.join(
    df_work_order_routing_prep, ["work_order"], how="left"
)
log.info("LEFT JOIN MES -> SAP routing done: work orders without a routing can't be matched to PLM")

df_mes_documents = df_mes_documents.join(
    df_active_docs_prep, ["work_order", "work_order_operation", "MES_PLM_label"], how="left"
).withColumn(
    "active_in_mes_status",
    f.when(f.col("is_active_in_mes"), f.lit(ACTIVE_STATUS_ACTIVE))
    .when(~f.col("is_active_in_mes"), f.lit(ACTIVE_STATUS_INACTIVE))
    .otherwise(f.lit(ACTIVE_STATUS_UNKNOWN)),
)
log.info("LEFT JOIN active flag done: links missing from document_links get active_in_mes_status = Unknown")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Primary Key
# MAGIC One row per work order operation and document family (manual corrections: per file).
# MAGIC Nulls are kept as empty segments so each part stays in its position.

# COMMAND ----------

_pk_cols = ["work_order", "work_order_operation", "document_type", "document_family"]
df_mes_documents = df_mes_documents.withColumn(
    "mes_operation_document_ID",
    f.concat_ws("-", *[f.coalesce(f.col(c).try_cast("string"), f.lit("")) for c in _pk_cols]),
)

df_mes_operation_document_end = df_mes_documents.select(
    "mes_operation_document_ID",
    "work_order",
    "work_order_operation",
    "operation_status",
    "operation_end_date",
    "routing_number",
    "routing_group_counter",
    "document_type",
    "document_family",
    "technical_document_MES",
    "revision_sort_key",
    "MES_PLM_label",
    "is_MES_PLM_last",
    "has_multiple_revisions_shown",
    "is_doc_added_manually",
    "is_active_in_mes",
    "active_in_mes_status",
)

if DEBUG:
    log.debug(f"Silver mes_operation_document: {df_mes_operation_document_end.count()} rows")

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

dfgx = gx.dataset.SparkDFDataset(df_mes_operation_document_end, persist=False)

red_results = [
    dfgx.expect_column_values_to_not_be_null(column="mes_operation_document_ID"),
    dfgx.expect_column_values_to_be_unique(column="mes_operation_document_ID"),
    dfgx.expect_table_row_count_to_be_between(min_value=1),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="RED checks passed: mes_operation_document_ID unique and not null, table non-empty",
    error_message=(
        "RED check failed on mes_operation_document — duplicate/missing mes_operation_document_ID, "
        "or table came back empty"
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC A propagated MES identifier without a revision suffix would make its own family and never match
# MAGIC PLM; MES can hold legacy formats, so this warns rather than stops.

# COMMAND ----------

dfgx_propagated = gx.dataset.SparkDFDataset(
    df_mes_operation_document_end.where(
        ~f.col("is_doc_added_manually") & f.col("technical_document_MES").isNotNull()
    ),
    persist=False,
)
amber_results = [
    dfgx_propagated.expect_column_values_to_match_regex(
        column="technical_document_MES", regex=REVISION_TRAILING_REGEX, mostly=0.99
    ),
    dfgx.expect_column_values_to_not_be_null(column="routing_number", mostly=0.9),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=amber_results,
    validation_level="AMBER",
    info_message="AMBER checks passed: MES identifiers carry a revision, work orders mostly have a routing",
    error_message=(
        "AMBER warning on mes_operation_document — MES identifiers without a revision suffix, or "
        "many work orders without an SAP routing"
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

table_utils.save_table(
    dest_table=DEST_TABLE,
    df=df_mes_operation_document_end,
    mode="overwrite",
    overwrite_schema=True,
)

# An overwrite recreates the table (CREATE OR REPLACE), which drops its constraints, so the PK is
# re-applied whenever it's missing rather than only on the first run.
_dest_catalog, _dest_schema, _dest_table = DEST_TABLE.split(".")
_is_pk_missing = spark.sql(
    f"SELECT 1 FROM {_dest_catalog}.information_schema.table_constraints "
    f"WHERE table_schema = '{_dest_schema}' AND table_name = '{_dest_table}' "
    f"AND constraint_type = 'PRIMARY KEY'"
).isEmpty()

if _is_pk_missing:
    table_utils.set_table_column_not_null(table_path=DEST_TABLE, column="mes_operation_document_ID")
    table_utils.add_table_primary_key(DEST_TABLE, "mes_operation_document_PK", "mes_operation_document_ID")

log.info(f"Saved: {DEST_TABLE}")
