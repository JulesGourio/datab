# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Gold PLM MES Reconciliation
# MAGIC
# MAGIC **Description:**
# MAGIC For every work order operation, compares the technical documents PLM says the operator should
# MAGIC see (the latest Official revision of each document of the routing operation) with the documents
# MAGIC MES actually shows, in both directions, and gives each document one `reconciliation_status`:
# MAGIC OK, Wrong revision, Missing in MES, Obsolete shown, Not released in PLM, Other operation or
# MAGIC type, Unknown to PLM, or Manually added. Adds the SAP work order context the report filters on
# MAGIC (program, material, work order status and descriptions).
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - [Expected vs Shown](#expected-vs-shown)
# MAGIC - [Classify Documents Only MES Shows](#classify-documents-only-mes-shows)
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - uc60_plm_mes_reconciliation
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{pipeline_write_env}_silver.production.plm_routing_document`
# MAGIC - `{pipeline_write_env}_silver.production.mes_operation_document`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{reference_read_env}_gold.production.work_orders_sap_exposed`
# MAGIC - `{reference_read_env}_gold.production.work_order_operation`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_gold.production.plm_mes_reconciliation`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger and Constants

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

DEST_TABLE = f"{PIPELINE_WRITE_ENV}_gold.production.plm_mes_reconciliation"

PLM_DOCUMENT_STATE_OBSOLETE = "Obsolete"
PLM_DOCUMENT_STATE_OFFICIAL = "Official"

STATUS_OK = "OK"
STATUS_WRONG_REVISION = "Wrong revision"
STATUS_MISSING_IN_MES = "Missing in MES"
STATUS_OBSOLETE_SHOWN = "Obsolete shown"
STATUS_NOT_RELEASED = "Not released in PLM"
STATUS_OTHER_OPERATION_OR_TYPE = "Other operation or type"
STATUS_UNKNOWN_TO_PLM = "Unknown to PLM"
STATUS_MANUALLY_ADDED = "Manually added"
RECONCILIATION_STATUSES = {
    STATUS_OK,
    STATUS_WRONG_REVISION,
    STATUS_MISSING_IN_MES,
    STATUS_OBSOLETE_SHOWN,
    STATUS_NOT_RELEASED,
    STATUS_OTHER_OPERATION_OR_TYPE,
    STATUS_UNKNOWN_TO_PLM,
    STATUS_MANUALLY_ADDED,
}

KNOWN_DOCUMENT_TYPES = {"TXT", "TXT-REC", "ITC", "FI", "FTO", "LATECOERE", "AIRBUS", "Manually corrected"}

# Default SAP routing group counter; work orders on another group may follow a routing variant PLM
# doesn't distinguish (6.4% of expected documents on 2026-10-01).
DEFAULT_ROUTING_GROUP_COUNTER = "L0"
MIN_SHARE_DEFAULT_ROUTING_GROUP = 0.90

# Expected thresholds, measured on 2026-10-01: Missing in MES ~12% of expected documents.
MIN_SHARE_EXPECTED_SHOWN = 0.8

RECONCILIATION_KEY = ["work_order", "work_order_operation", "document_type", "document_family"]

log.info(f"Destination table: {DEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Own Pipeline - Silver

# COMMAND ----------

df_plm_routing_document_raw = spark.read.table(f"{PIPELINE_WRITE_ENV}_silver.production.plm_routing_document")

# COMMAND ----------

df_mes_operation_document_raw = spark.read.table(f"{PIPELINE_WRITE_ENV}_silver.production.mes_operation_document")

# COMMAND ----------

# MAGIC %md
# MAGIC ## SAP - Reference Data

# COMMAND ----------

df_work_orders_sap_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.production.work_orders_sap_exposed")

# COMMAND ----------

df_work_order_operation_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.production.work_order_operation")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Expected: What PLM Says Each Operation Should Show
# MAGIC The latest Official revision of every document of a routing operation, attached to every MES
# MAGIC work order operation following that routing. PLM attributes keep a `_PLM` suffix.

# COMMAND ----------

_plm_key_cols = ["routing_number", "work_order_operation", "document_type", "document_family"]
_plm_attribute_cols = [
    c
    for c in df_plm_routing_document_raw.columns
    if c not in _plm_key_cols + ["plm_routing_document_ID", "source_row_order", "revision_sort_key"]
    and not c.startswith("_")
]
df_plm_expected_prep = df_plm_routing_document_raw.where(f.col("is_latest_official")).select(
    *_plm_key_cols,
    *[f.col(c).alias(f"{c}_PLM") for c in _plm_attribute_cols],
).withColumnRenamed("technical_document_PLM_PLM", "technical_document_PLM")

# Every MES work order operation and its routing, including operations that show no document.
df_mes_operations_prep = (
    df_mes_operation_document_raw.where(~f.col("is_doc_added_manually"))
    .select(
        "work_order",
        "work_order_operation",
        "routing_number",
        "routing_group_counter",
        "operation_status",
        "operation_end_date",
    )
    .dropDuplicates(["work_order", "work_order_operation"])
)

df_expected_prep = df_plm_expected_prep.join(
    df_mes_operations_prep, ["routing_number", "work_order_operation"], how="inner"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Shown: What MES Shows, on Routings PLM Covers
# MAGIC Documents on work orders whose routing isn't in the PLM exports can't be reconciled and are left
# MAGIC out; manual corrections are kept apart and added back as their own rows.

# COMMAND ----------

df_plm_routings = df_plm_routing_document_raw.select("routing_number").distinct()

df_shown_prep = (
    df_mes_operation_document_raw.where(
        ~f.col("is_doc_added_manually") & f.col("technical_document_MES").isNotNull()
    )
    .join(df_plm_routings, ["routing_number"], how="left_semi")
    .select(
        *RECONCILIATION_KEY,
        f.col("routing_number").alias("routing_number_MES"),
        f.col("routing_group_counter").alias("routing_group_counter_MES"),
        f.col("operation_status").alias("operation_status_MES"),
        f.col("operation_end_date").alias("operation_end_date_MES"),
        "technical_document_MES",
        "MES_PLM_label",
        "is_MES_PLM_last",
        "has_multiple_revisions_shown",
        "is_active_in_mes",
        "active_in_mes_status",
    )
)

df_manual_prep = df_mes_operation_document_raw.where(f.col("is_doc_added_manually"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## PLM States per Family
# MAGIC For a document MES shows but PLM doesn't expect on that operation: is the family Official
# MAGIC elsewhere in the routing, only in an unreleased state, or absent from the routing altogether?

# COMMAND ----------

df_plm_family_states = df_plm_routing_document_raw.groupBy("routing_number", "document_family").agg(
    f.max(f.col("document_state") == PLM_DOCUMENT_STATE_OFFICIAL).alias("is_family_official_in_routing"),
    f.max(f.col("document_state") == PLM_DOCUMENT_STATE_OBSOLETE).alias("is_family_obsolete_in_routing"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## SAP Work Order Context

# COMMAND ----------

df_work_orders_sap_prep = df_work_orders_sap_raw.select(
    f.col("work_order_number").alias("work_order"),
    "material_number",
    "work_order_description",
    "work_order_status",
    "profit_center",
)

df_work_order_operation_sap_prep = df_work_order_operation_raw.select(
    "work_order", "work_order_operation", "operation_description"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Expected vs Shown
# MAGIC FULL OUTER JOIN on work order operation, document type and family: a row on both sides is a
# MAGIC document MES shows for an expected PLM document (same or other revision); a row only on the
# MAGIC expected side is a document the operator doesn't see; a row only on the shown side is a document
# MAGIC PLM doesn't expect there. Both sides are unique on the key (checked in Quality Checks).

# COMMAND ----------

df_reconciliation = df_expected_prep.join(df_shown_prep, RECONCILIATION_KEY, how="full_outer")
log.info("FULL OUTER JOIN expected vs shown done: key uniqueness of both sides is checked in Quality Checks")

df_reconciliation = (
    df_reconciliation.withColumn("routing_number", f.coalesce(f.col("routing_number"), f.col("routing_number_MES")))
    .withColumn(
        "routing_group_counter", f.coalesce(f.col("routing_group_counter"), f.col("routing_group_counter_MES"))
    )
    .withColumn("operation_status", f.coalesce(f.col("operation_status"), f.col("operation_status_MES")))
    .withColumn("operation_end_date", f.coalesce(f.col("operation_end_date"), f.col("operation_end_date_MES")))
    .drop("routing_number_MES", "routing_group_counter_MES", "operation_status_MES", "operation_end_date_MES")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Classify Documents Only MES Shows
# MAGIC Family Official elsewhere in the routing → Other operation or type; family only in an unreleased
# MAGIC state → Obsolete shown (if Obsolete) or Not released in PLM; family absent from the routing →
# MAGIC Unknown to PLM.

# COMMAND ----------

df_reconciliation = df_reconciliation.join(
    df_plm_family_states, ["routing_number", "document_family"], how="left"
).withColumn(
    "reconciliation_status",
    f.when(
        f.col("technical_document_PLM").isNotNull() & f.col("technical_document_MES").isNotNull(),
        f.when(
            f.col("technical_document_MES") == f.col("technical_document_PLM"), f.lit(STATUS_OK)
        ).otherwise(f.lit(STATUS_WRONG_REVISION)),
    )
    .when(f.col("technical_document_MES").isNull(), f.lit(STATUS_MISSING_IN_MES))
    .when(f.col("is_family_official_in_routing"), f.lit(STATUS_OTHER_OPERATION_OR_TYPE))
    .when(f.col("is_family_obsolete_in_routing"), f.lit(STATUS_OBSOLETE_SHOWN))
    .when(f.col("is_family_official_in_routing").isNotNull(), f.lit(STATUS_NOT_RELEASED))
    .otherwise(f.lit(STATUS_UNKNOWN_TO_PLM)),
).drop("is_family_official_in_routing", "is_family_obsolete_in_routing")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add Manual Corrections
# MAGIC Manual corrections have no PLM counterpart: they're kept as their own rows so the report can
# MAGIC show where operators had to work around a gap.

# COMMAND ----------

df_manual_rows = df_manual_prep.select(
    *RECONCILIATION_KEY,
    "routing_number",
    "routing_group_counter",
    "operation_status",
    "operation_end_date",
    "technical_document_MES",
    "MES_PLM_label",
    "is_MES_PLM_last",
    "has_multiple_revisions_shown",
    "is_active_in_mes",
    "active_in_mes_status",
).withColumn("reconciliation_status", f.lit(STATUS_MANUALLY_ADDED))

df_reconciliation = df_reconciliation.unionByName(df_manual_rows, allowMissingColumns=True)

df_reconciliation = (
    df_reconciliation.withColumn("is_technical_doc_OK", f.col("reconciliation_status") == STATUS_OK)
    .withColumn("is_doc_added_manually", f.col("reconciliation_status") == STATUS_MANUALLY_ADDED)
    .withColumn("active_in_mes_status", f.coalesce(f.col("active_in_mes_status"), f.lit("Unknown")))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add SAP Work Order Context
# MAGIC LEFT JOINs — a document whose work order has no SAP match is kept and only loses its
# MAGIC descriptive context.

# COMMAND ----------

df_reconciliation = df_reconciliation.join(df_work_orders_sap_prep, ["work_order"], how="left").join(
    df_work_order_operation_sap_prep, ["work_order", "work_order_operation"], how="left"
)
log.info("LEFT JOINs to SAP done: profit_center null rate is checked in Quality Checks")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Primary Key and Column Order
# MAGIC One row per work order operation, document type and family (manual corrections: per file).
# MAGIC PK first, then work order context, the reconciled documents and their status, then the PLM
# MAGIC attributes (suffixed `_PLM`).

# COMMAND ----------

df_reconciliation = df_reconciliation.withColumn(
    "plm_mes_reconciliation_ID",
    f.concat_ws("-", *[f.coalesce(f.col(c).try_cast("string"), f.lit("")) for c in RECONCILIATION_KEY]),
)

_ordered_cols = [
    "plm_mes_reconciliation_ID",
    "work_order",
    "work_order_operation",
    "operation_description",
    "operation_status",
    "operation_end_date",
    "work_order_description",
    "work_order_status",
    "material_number",
    "profit_center",
    "routing_number",
    "routing_group_counter",
    "document_type",
    "document_family",
    "technical_document_PLM",
    "technical_document_MES",
    "MES_PLM_label",
    "reconciliation_status",
    "is_technical_doc_OK",
    "is_doc_added_manually",
    "has_multiple_revisions_shown",
    "is_active_in_mes",
    "active_in_mes_status",
    "is_MES_PLM_last",
]
_plm_cols = [c for c in df_reconciliation.columns if c.endswith("_PLM") and c not in _ordered_cols]
df_plm_mes_reconciliation_end = df_reconciliation.select(*_ordered_cols, *_plm_cols)

if DEBUG:
    log.debug(f"Gold plm_mes_reconciliation: {df_plm_mes_reconciliation_end.count()} rows")

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC Both sides of the FULL OUTER JOIN must be unique on the key, otherwise one expected document
# MAGIC would be compared with several shown ones (or the reverse) and the counts would be inflated.

# COMMAND ----------

dfgx_expected = gx.dataset.SparkDFDataset(df_expected_prep, persist=False)
dfgx_shown = gx.dataset.SparkDFDataset(df_shown_prep, persist=False)
dfgx = gx.dataset.SparkDFDataset(df_plm_mes_reconciliation_end, persist=False)

red_results = [
    dfgx_expected.expect_compound_columns_to_be_unique(column_list=RECONCILIATION_KEY),
    dfgx_shown.expect_compound_columns_to_be_unique(column_list=RECONCILIATION_KEY),
    dfgx.expect_column_values_to_not_be_null(column="plm_mes_reconciliation_ID"),
    dfgx.expect_column_values_to_be_unique(column="plm_mes_reconciliation_ID"),
    dfgx.expect_table_row_count_to_be_between(min_value=1),
    dfgx.expect_column_values_to_be_in_set(column="reconciliation_status", value_set=RECONCILIATION_STATUSES),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="RED checks passed: both join sides unique on the key, PK unique and not null, statuses known",
    error_message=(
        "RED check failed on plm_mes_reconciliation — expected or shown side not unique on the key "
        "(join fan-out), duplicate/missing PK, empty table, or an unknown reconciliation_status"
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC Completeness in both directions: the share of expected documents MES shows, and the share of
# MAGIC work orders on the default routing group (PLM doesn't distinguish routing variants).

# COMMAND ----------

dfgx_expected_rows = gx.dataset.SparkDFDataset(
    df_plm_mes_reconciliation_end.where(f.col("technical_document_PLM").isNotNull()), persist=False
)
amber_results = [
    dfgx.expect_column_values_to_not_be_null(column="profit_center", mostly=0.95),
    dfgx.expect_column_distinct_values_to_be_in_set(column="document_type", value_set=KNOWN_DOCUMENT_TYPES),
    dfgx_expected_rows.expect_column_values_to_not_be_null(
        column="technical_document_MES", mostly=MIN_SHARE_EXPECTED_SHOWN
    ),
    dfgx_expected.expect_column_values_to_be_in_set(
        column="routing_group_counter",
        value_set=[DEFAULT_ROUTING_GROUP_COUNTER],
        mostly=MIN_SHARE_DEFAULT_ROUTING_GROUP,
    ),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=amber_results,
    validation_level="AMBER",
    info_message=(
        "AMBER checks passed: profit_center mostly populated, known document types, most expected "
        "documents shown in MES, work orders mostly on the default routing group"
    ),
    error_message=(
        "AMBER warning on plm_mes_reconciliation — high share of null profit_center, unknown "
        "document type, many expected documents missing in MES, or many work orders on a routing "
        "variant PLM doesn't distinguish"
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

table_utils.save_table(
    dest_table=DEST_TABLE,
    df=df_plm_mes_reconciliation_end,
    mode="overwrite",
    overwrite_schema=True,
)

# An overwrite recreates the table (CREATE OR REPLACE), which drops its constraints, so the PK is
# re-applied whenever it's missing rather than only on the first run.
_dest_catalog, _dest_schema, _dest_table = DEST_TABLE.split(".")
_is_pk_missing = spark.sql(
    f"SELECT 1 FROM {_dest_catalog}.information_schema.table_constraints "
    f"WHERE table_schema = '{_dest_schema}' AND table_name = '{_dest_table}' "
    f"AND constraint_type = 'PRIMARY KEY'"
).isEmpty()

if _is_pk_missing:
    table_utils.set_table_column_not_null(table_path=DEST_TABLE, column="plm_mes_reconciliation_ID")
    table_utils.add_table_primary_key(DEST_TABLE, "plm_mes_reconciliation_PK", "plm_mes_reconciliation_ID")

log.info(f"Saved: {DEST_TABLE}")