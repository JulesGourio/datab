# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Silver PLM Routing Document
# MAGIC
# MAGIC **Description:**
# MAGIC Governed copy of the PLM routing exports (programs A5F and A1O): one row per technical document
# MAGIC listed on a routing operation, in every document state. The export is a flattened sheet
# MAGIC (routing header row, then each operation row followed by its document rows), so each document
# MAGIC row receives the attributes of its routing header and of its operation. Documents are typed,
# MAGIC grouped into a document family (identifier without any revision segment) and flagged when they
# MAGIC are the latest officially released revision of their family.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - [Row Order Within a Routing](#row-order-within-a-routing)
# MAGIC - [Header and Operation Attributes on Document Rows](#header-and-operation-attributes-on-document-rows)
# MAGIC - [Document Family and Revision](#document-family-and-revision)
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - uc60_plm_mes_reconciliation
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{reference_read_env}_bronze.uc060_plm_mes_ingestion.uc060_plm_mes_reconciliation_a5f_latest`
# MAGIC - `{reference_read_env}_bronze.uc060_plm_mes_ingestion.uc060_plm_mes_reconciliation_a1o_latest`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_silver.production.plm_routing_document`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC 1. The document family / revision parsing is duplicated in
# MAGIC    `create_silver_mes_operation_document.py`; both must stay identical so PLM and MES families
# MAGIC    match (see Data Preparation - Document Family and Revision).

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger and Constants

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

DEST_TABLE = f"{PIPELINE_WRITE_ENV}_silver.production.plm_routing_document"

PLM_DOCUMENT_STATE_OFFICIAL = "Official"

# A revision segment is "-<letter(s)>-<2-digit version>", e.g. "-B-01". FTO identifiers carry two
# (DOC-FTO-OPE-1701841-B-01-BG-A-01): the operation sheet revision in the middle and the document
# revision at the end, so every segment is stripped for the family and ranked for the revision.
REVISION_SEGMENT_REGEX = "-[A-Za-z]{1,2}-[0-9]{2}(?=-|$)"
REVISION_TRAILING_REGEX = r"-[A-Za-z]{1,2}-[0-9]{2}$"

# PLM order_number holds an operation number only when purely numeric; the routing number is the
# numeric segment of concatenated_identifier (GAM-<routing>-<site>-<revision>).
PLM_OPERATION_NUMBER_REGEX = r"^[0-9]+$"
PLM_ROUTING_NUMBER_REGEX = r"-(\d+)-"

PLM_DATE_FORMAT = "dd/MM/yyyy"
PLM_TIMESTAMP_FORMAT = "dd/MM/yyyy HH:mm:ss"

# Attributes only filled on the routing header row, and only on the operation row, of the export.
# Measured on both exports: none of them is ever filled on a document row.
HEADER_ATTRIBUTE_COLS = [
    "designation",
    "description",
    "complementary_designation",
    "manufacturer",
    "division",
    "manufactured_quantity",
    "esb_sending_status",
    "linked_to_change_order",
    "issued_from",
    "fai_reason",
    "program_code",
    "confidential_object",
    "creation_author",
    "creation_date",
    "update_author",
    "update_date",
    "officialization_date",
    "fai_ready_date",
]
OPERATION_ATTRIBUTE_COLS = [
    "designation_operation",
    "additional_designation_operation",
    "technical_workstation_number",
    "wip_op_link_operation",
    "division_operation",
    "manufacturing_trigram",
    "setup_time_min_operation",
    "labor_unit_time_min_operation",
    "machine_unit_time_min_operation",
    "decrease_coefficient_operation",
    "rank_for_decrease_operation",
]
# Component/resource-line attributes (BOM-like rows of the export) and columns that are empty on
# every row; none of them describes a document.
NON_DOCUMENT_COLS = [
    "order_number",
    "workstation_number",
    "workstation_type",
    "quantity",
    "fixed_quantity",
    "operation_alternative",
    "formula_key",
    "number",
    "dim1_sap",
    "dim2_sap",
    "dim3_sap",
    "dst_reference",
    "dst_status",
    "dst_type",
    "comment",
    "version_comment",
    "obsolescence_date",
    "fai_refused_to_canceled",
]

DATE_COLS = ["creation_date", "update_date", "indexing_date"]
TIMESTAMP_COLS = ["officialization_date", "fai_ready_date"]
DOUBLE_COLS = [
    "manufactured_quantity",
    "setup_time_min_operation",
    "labor_unit_time_min_operation",
    "machine_unit_time_min_operation",
    "decrease_coefficient_operation",
]
BIGINT_COLS = ["rank_for_decrease_operation"]

# FI documents name their operation in the identifier (e.g. "DOC-FI-OP20-..."): an independent
# check of the operation taken from the export's row order. A few legitimate mismatches exist where
# PLM renumbered operations but kept the document name.
# Thresholds sit just under the values measured on 2026-10-01 (FI on their operation 97.6%, routings
# in two revisions 1.4%, documents before any operation 1.6%) so they only warn when it gets worse.
FI_DOCUMENT_TYPE = "FI"
FI_DOCUMENT_OPERATION_REGEX = r"-OP(\d+)-"
PLM_ROW_ORDER_MIN_CONSISTENCY = 0.95
MAX_SHARE_ROUTINGS_WITH_SEVERAL_REVISIONS = 0.03
MIN_SHARE_DOCUMENTS_ON_OPERATION = 0.97

log.info(f"Destination table: {DEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## PLM - Bronze

# COMMAND ----------

df_a5f_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.uc060_plm_mes_ingestion.uc060_plm_mes_reconciliation_a5f_latest"
)

# COMMAND ----------

df_a1o_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.uc060_plm_mes_ingestion.uc060_plm_mes_reconciliation_a1o_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stack Both Programs
# MAGIC Both programs export the same layout; `source_file_keyword` keeps each row traceable to its export.

# COMMAND ----------

df_plm_union = df_a5f_raw.withColumn("source_file_keyword", f.lit("A5F")).unionByName(
    df_a1o_raw.withColumn("source_file_keyword", f.lit("A1O")), allowMissingColumns=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Row Order Within a Routing
# MAGIC Document rows don't repeat their operation or routing attributes: they belong to the closest
# MAGIC operation row above them, under the routing header. The source has no row-order column of its
# MAGIC own, so the read-time order is kept in `source_row_order`; Quality Checks - PLM row order
# MAGIC confirms the result on every run.

# COMMAND ----------

df_plm_prep = (
    df_plm_union.withColumn("source_row_order", f.monotonically_increasing_id())
    .withColumn("is_document_row", f.col("operation_reference_configuration").isNotNull())
    .withColumn(
        "is_operation_row",
        # order_number is null on header rows
        ~f.col("is_document_row")
        & f.coalesce(f.col("order_number").rlike(PLM_OPERATION_NUMBER_REGEX), f.lit(False)),
    )
    .withColumn(
        "is_header_row",
        ~f.col("is_document_row") & ~f.col("is_operation_row") & f.col("creation_date").isNotNull(),
    )
)

# Each operation row opens a new segment; its document rows share the segment number.
_routing_order_window = (
    Window.partitionBy("concatenated_identifier")
    .orderBy("source_row_order")
    .rowsBetween(Window.unboundedPreceding, Window.currentRow)
)
df_plm_prep = df_plm_prep.withColumn(
    "_operation_segment",
    f.sum(f.col("is_operation_row").try_cast("int")).over(_routing_order_window),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Header and Operation Attributes on Document Rows
# MAGIC Gives every document the attributes of its routing header (designation, program, FAI and
# MAGIC officialization dates…) and of its operation (operation number and designation, workstation,
# MAGIC setup/labor/machine times), which the export only writes on those rows.

# COMMAND ----------

_routing_window = Window.partitionBy("concatenated_identifier")
_operation_window = Window.partitionBy("concatenated_identifier", "_operation_segment")

df_plm_prep = df_plm_prep.withColumn(
    "work_order_operation",
    f.max(f.when(f.col("is_operation_row"), f.col("order_number"))).over(_operation_window),
)
for _col in HEADER_ATTRIBUTE_COLS:
    df_plm_prep = df_plm_prep.withColumn(
        _col, f.max(f.when(f.col("is_header_row"), f.col(_col))).over(_routing_window)
    )
for _col in OPERATION_ATTRIBUTE_COLS:
    df_plm_prep = df_plm_prep.withColumn(
        _col, f.max(f.when(f.col("is_operation_row"), f.col(_col))).over(_operation_window)
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Keep Document Rows
# MAGIC Header, operation and component rows have served their purpose once their attributes sit on
# MAGIC the documents. The export repeats some document lines verbatim (378 identical repeats measured
# MAGIC on 2026-10-01), so one copy is kept per routing revision, operation and document.

# COMMAND ----------

df_plm_documents = (
    df_plm_prep.where(f.col("is_document_row"))
    .withColumnRenamed("operation_reference_configuration", "technical_document_PLM")
    .withColumn(
        "routing_number",
        f.regexp_extract(f.col("concatenated_identifier"), PLM_ROUTING_NUMBER_REGEX, 1),
    )
    .drop(*NON_DOCUMENT_COLS, "is_document_row", "is_operation_row", "is_header_row", "_operation_segment")
)
df_plm_documents = table_utils.drop_duplicates_by_order(
    df=df_plm_documents,
    columns=["concatenated_identifier", "work_order_operation", "technical_document_PLM"],
    order_col=["source_row_order"],
    keep="first",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Types

# COMMAND ----------

for _col in DATE_COLS:
    df_plm_documents = df_plm_documents.withColumn(
        _col, table_utils.safe_to_date(f.substring(f.col(_col), 1, 10), PLM_DATE_FORMAT)
    )
for _col in TIMESTAMP_COLS:
    df_plm_documents = df_plm_documents.withColumn(
        _col, f.try_to_timestamp(f.col(_col), f.lit(PLM_TIMESTAMP_FORMAT))
    )
for _col in DOUBLE_COLS:
    df_plm_documents = df_plm_documents.withColumn(_col, f.col(_col).try_cast("double"))
for _col in BIGINT_COLS:
    df_plm_documents = df_plm_documents.withColumn(_col, f.col(_col).try_cast("bigint"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Document Family and Revision
# MAGIC The family groups every revision of the same document so PLM and MES can be compared even when
# MAGIC they're on different revisions. The revision sort key orders revisions within a family: each
# MAGIC segment is ranked by letter length, then letter, then version, the embedded segment first, so
# MAGIC a revision past Z (AA…) still wins and an FTO on a newer operation sheet outranks an older one.

# COMMAND ----------

_revision_sort_key = f.expr(
    f"concat_ws('|', transform(regexp_extract_all(technical_document_PLM, '{REVISION_SEGMENT_REGEX}', 0), "
    "s -> concat(length(regexp_extract(s, '-([A-Za-z]+)-', 1)), "
    "lpad(upper(regexp_extract(s, '-([A-Za-z]+)-', 1)), 2, ' '), "
    "regexp_extract(s, '([0-9]{2})$', 1))))"
)
df_plm_documents = df_plm_documents.withColumn(
    "document_family", f.regexp_replace(f.col("technical_document_PLM"), REVISION_SEGMENT_REGEX, "")
).withColumn("revision_sort_key", _revision_sort_key)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Latest Routing Revision and Latest Official Document
# MAGIC A routing can be exported in two revisions at once (3 routings on 2026-10-01). Within a
# MAGIC routing operation, a document family may also have several Official revisions. The one MES
# MAGIC must show is the newest Official revision, preferring the latest routing revision.

# COMMAND ----------

_routing_revision_key = f.regexp_extract(f.col("concatenated_identifier"), r"-([A-Za-z]{1,2}-[0-9]{2})$", 1)
df_plm_documents = df_plm_documents.withColumn(
    "is_latest_routing_revision",
    f.dense_rank().over(
        Window.partitionBy("routing_number").orderBy(
            f.length(_routing_revision_key).desc(), _routing_revision_key.desc()
        )
    )
    == 1,
)

# Official rows are ranked ahead of every other state, so the first row of a family is Official
# whenever the family has an Official revision at all.
_latest_official_window = Window.partitionBy(
    "routing_number", "work_order_operation", "document_type", "document_family"
).orderBy(
    (f.col("document_state") == PLM_DOCUMENT_STATE_OFFICIAL).desc(),
    f.col("is_latest_routing_revision").desc(),
    f.col("revision_sort_key").desc(),
)
df_plm_documents = df_plm_documents.withColumn(
    "is_latest_official",
    (f.col("document_state") == PLM_DOCUMENT_STATE_OFFICIAL)
    & (f.row_number().over(_latest_official_window) == 1),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Primary Key
# MAGIC One row per routing revision, operation and document revision; nulls are kept as empty
# MAGIC segments so each part stays in its position.

# COMMAND ----------

_pk_cols = ["concatenated_identifier", "work_order_operation", "technical_document_PLM"]
df_plm_documents = df_plm_documents.withColumn(
    "plm_routing_document_ID",
    f.concat_ws("-", *[f.coalesce(f.col(c).try_cast("string"), f.lit("")) for c in _pk_cols]),
)

_first_cols = [
    "plm_routing_document_ID",
    "routing_number",
    "concatenated_identifier",
    "is_latest_routing_revision",
    "work_order_operation",
    "document_type",
    "document_family",
    "technical_document_PLM",
    "revision_sort_key",
    "document_state",
    "is_latest_official",
]
df_plm_routing_document_end = df_plm_documents.select(
    *_first_cols, *[c for c in df_plm_documents.columns if c not in _first_cols]
)

if DEBUG:
    log.debug(f"Silver plm_routing_document: {df_plm_routing_document_end.count()} rows")

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

dfgx = gx.dataset.SparkDFDataset(df_plm_routing_document_end, persist=False)

red_results = [
    dfgx.expect_column_values_to_not_be_null(column="plm_routing_document_ID"),
    dfgx.expect_column_values_to_be_unique(column="plm_routing_document_ID"),
    dfgx.expect_table_row_count_to_be_between(min_value=1),
    # An identifier without a revision suffix would make its own family and silently break the
    # PLM/MES match, so a new identifier format must stop the pipeline.
    dfgx.expect_column_values_to_match_regex(column="technical_document_PLM", regex=REVISION_TRAILING_REGEX),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="RED checks passed: PK unique and not null, table non-empty, every identifier has a revision",
    error_message=(
        "RED check failed on plm_routing_document — duplicate/missing PK, empty table, or a "
        "document identifier without a revision suffix"
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC Exactly one latest Official revision per routing operation and document family, so the Gold
# MAGIC "expected" side can't fan out.

# COMMAND ----------

dfgx_latest_official = gx.dataset.SparkDFDataset(
    df_plm_routing_document_end.where(f.col("is_latest_official")), persist=False
)
latest_official_results = [
    dfgx_latest_official.expect_compound_columns_to_be_unique(
        column_list=["routing_number", "work_order_operation", "document_type", "document_family"]
    ),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=latest_official_results,
    validation_level="RED",
    info_message="RED check passed: one latest Official revision per routing operation and family",
    error_message="RED check failed on plm_routing_document — several latest Official revisions in one family",
)

# COMMAND ----------

amber_results = [
    dfgx.expect_column_values_to_not_be_null(column="work_order_operation", mostly=MIN_SHARE_DOCUMENTS_ON_OPERATION),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=amber_results,
    validation_level="AMBER",
    info_message="AMBER check passed: documents sit on an operation",
    error_message="AMBER warning on plm_routing_document — documents found before any operation row",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## PLM row order
# MAGIC Checked per distinct FI document, not per row: a row-level rate is diluted by documents used on
# MAGIC many work orders downstream, while here each misplaced document counts once.

# COMMAND ----------

df_fi_operation_check = df_plm_routing_document_end.where(
    (f.col("document_type") == FI_DOCUMENT_TYPE)
    & f.col("technical_document_PLM").rlike(FI_DOCUMENT_OPERATION_REGEX)
).withColumn(
    "is_fi_operation_consistent",
    f.regexp_extract(f.col("technical_document_PLM"), FI_DOCUMENT_OPERATION_REGEX, 1).try_cast("int")
    == f.col("work_order_operation").try_cast("int"),
)
dfgx_fi_operation = gx.dataset.SparkDFDataset(df_fi_operation_check, persist=False)

df_routing_revisions = df_plm_routing_document_end.groupBy("routing_number").agg(
    f.countDistinct("concatenated_identifier").alias("routing_revision_count")
)
dfgx_routing_revisions = gx.dataset.SparkDFDataset(df_routing_revisions, persist=False)

row_order_results = [
    dfgx_fi_operation.expect_column_values_to_be_in_set(
        column="is_fi_operation_consistent", value_set=[True], mostly=PLM_ROW_ORDER_MIN_CONSISTENCY
    ),
    dfgx_routing_revisions.expect_column_values_to_be_between(
        column="routing_revision_count",
        min_value=1,
        max_value=1,
        mostly=1 - MAX_SHARE_ROUTINGS_WITH_SEVERAL_REVISIONS,
    ),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=row_order_results,
    validation_level="AMBER",
    info_message="AMBER checks passed: FI documents sit on their named operation; few routings in two revisions",
    error_message=(
        "AMBER warning on plm_routing_document — FI documents on another operation than their name "
        "(row order scrambled or operations renumbered), or many routings exported in two revisions"
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

table_utils.save_table(
    dest_table=DEST_TABLE,
    df=df_plm_routing_document_end,
    mode="overwrite",
    overwrite_schema=True,
)

# An overwrite recreates the table (CREATE OR REPLACE), which drops its constraints, so the PK is
# re-applied whenever it's missing rather than only on the first run.
_dest_catalog, _dest_schema, _dest_table = DEST_TABLE.split(".")
_is_pk_missing = spark.sql(
    f"SELECT 1 FROM {_dest_catalog}.information_schema.table_constraints "
    f"WHERE table_schema = '{_dest_schema}' AND table_name = '{_dest_table}' "
    f"AND constraint_type = 'PRIMARY KEY'"
).isEmpty()

if _is_pk_missing:
    table_utils.set_table_column_not_null(table_path=DEST_TABLE, column="plm_routing_document_ID")
    table_utils.add_table_primary_key(DEST_TABLE, "plm_routing_document_PK", "plm_routing_document_ID")

log.info(f"Saved: {DEST_TABLE}")
