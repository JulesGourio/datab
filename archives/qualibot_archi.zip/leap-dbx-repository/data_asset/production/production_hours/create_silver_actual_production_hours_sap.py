# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE SILVER ACTUAL PRODUCTION HOURS SAP
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the silver table from SAP bronze table of actual production hours. 
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Actual production hours SAP
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.afru_latest
# MAGIC - {reference_read_env}_bronze.headers_sap.headers_sap_business_afru
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.production.actual_production_hours_sap
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Imports

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f

# LEAP FUNCTION
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - **df_afru_raw** is the bronze latest AFRU SAP table 
# MAGIC - **df_headers_afru** is the header of the SAP table AFRU

# COMMAND ----------

df_afru_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afru_latest"
)
df_headers_afru = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_afru"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Inputs - Manual declaration

# COMMAND ----------

PRODUCTION_HOURS_SILVER_SAP_TABLE = (
    f"{PIPELINE_WRITE_ENV}_silver.production.actual_production_hours_sap"
)

# COMMAND ----------

ENTRY_ORIGIN = ["IRD_EXPLOIT", "TALEND"]

# COMMAND ----------

# MAGIC %md
# MAGIC #Create silver

# COMMAND ----------

df_afru_raw = table_utils.add_prefix_to_columns(df_afru_raw, "AFRU")

table_utils.check_schema_of_the_header_file(df_headers_afru)
df_afru_renamed = table_utils.rename_columns_with_sap_business_header(
    df_afru_raw, df_headers_afru
)
df_production_hours = table_utils.cast_columns_with_sap_business_headers(
    df_afru_renamed, df_headers_afru
)

df_production_hours_prep = table_utils.remove_leading_zeros(
    df=df_production_hours, column_names=["work_order", "WO_operation"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Filter on hours on work order operations

# COMMAND ----------

df_production_hours_transf = df_production_hours_prep.filter(
    f.col("work_order").isNotNull()
).filter(f.col("WO_operation").isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Filter on entry from a system (IRD_EXPLOIT or TALEND)

# COMMAND ----------

df_production_hours_transf = df_production_hours_transf.filter(
    f.col("entry_origin").isin(ENTRY_ORIGIN)
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    dest_table=PRODUCTION_HOURS_SILVER_SAP_TABLE,
    df=df_production_hours_transf,
    overwrite_schema=True,
    mode="overwrite",
)
