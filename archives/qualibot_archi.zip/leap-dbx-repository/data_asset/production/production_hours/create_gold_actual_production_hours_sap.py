# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE GOLD ACTUAL PRODUCTION HOURS SAP
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the gold table from the silver table of actual production hours. 
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Actual production hours SAP
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {pipeline_write_env}_silver.production.actual_production_hours_sap
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.production.actual_production_hours_sap
# MAGIC - {pipeline_write_env}_gold.production.actual_production_hours_sap_exposed
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

import pyspark.sql.functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

PRODUCTION_HOURS_SILVER_SAP_TABLE = f"{PIPELINE_READ_ENV}_silver.production.actual_production_hours_sap"
PRODUCTION_HOURS_GOLD_SAP_TABLE = f"{PIPELINE_WRITE_ENV}_gold.production.actual_production_hours_sap"

# COMMAND ----------

# MAGIC %md
# MAGIC #Input

# COMMAND ----------

df_silver_raw = spark.read.table(PRODUCTION_HOURS_SILVER_SAP_TABLE)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

for i in range(1, 5):
    time_col = f"clocked_activity_time_{i}"
    # Handle negative values if - at the end , bring it forward and cas to double
    df_silver_raw = df_silver_raw.withColumn(
        f"clocked_activity_time_{i}",
        f.when(
            f.col(f"clocked_activity_time_{i}").substr(-1, 1) == "-",
            f.concat(
                f.lit("-"),
                f.regexp_extract(f"clocked_activity_time_{i}", r"(\d+\.\d+)", 1),
            ),
        ).otherwise(f.col(f"clocked_activity_time_{i}")),
    )
    df_silver_raw = df_silver_raw.withColumn(
        f"clocked_activity_time_{i}", f.col(f"clocked_activity_time_{i}").cast("double")
    )

# COMMAND ----------

for i in range(1, 5):
    unit_col = f.col(f"unit_time_{i}")
    time_col = f"clocked_activity_time_{i}"
    new_time_col = f"clocked_activity_time_{i}_in_h"
    df_silver_raw = df_silver_raw.withColumn(
        new_time_col,
        f.when(unit_col.isin(["STD", "H"]), f.col(time_col)).otherwise(
            f.when(unit_col.isin(["TAG", "10"]), f.col(time_col) * 24).otherwise(
                f.when(unit_col.isin(["MIN"]), f.col(time_col) / 60).otherwise(
                    f.when(
                        unit_col.isin(["MS"]), f.col(time_col) / (3600 * 1000)
                    ).otherwise(
                        f.when(
                            unit_col.isin(["MIS"]), f.col(time_col) / (3600 * 1000000)
                        ).otherwise(f.lit(0))
                    )
                )
            )
        ),
    )

df_production_hours = df_silver_raw.withColumn(
    "spent_time",
    sum([df_silver_raw[f"clocked_activity_time_{i}"] for i in range(1, 5)]),
)

# COMMAND ----------

df_production_hours = df_production_hours.withColumn(
    "CONCAT_WO_OPE", f.concat_ws("-", f.col("work_order"), f.col("WO_operation"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    dest_table=PRODUCTION_HOURS_GOLD_SAP_TABLE,
    df=df_production_hours,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

Begin_By = "AFRU"
selected_columns = [col for col in df_production_hours.columns if not col.startswith(Begin_By)]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    PRODUCTION_HOURS_GOLD_SAP_TABLE, f"{PRODUCTION_HOURS_GOLD_SAP_TABLE}_exposed", select_statement, replace_view=True
)
