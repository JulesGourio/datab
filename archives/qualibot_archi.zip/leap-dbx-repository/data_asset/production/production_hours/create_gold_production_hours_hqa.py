# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC **CREATE GOLD PRODUCTION HOURS HQA**
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the gold table of the production hours from HQA based on the infocenter gold table.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Infocenter HQA
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {PIPELINE_READ_ENV}_gold.production.infocenter_hqa
# MAGIC - {REFERENCE_READ_ENV}_gold.production.sap_work_order_basics_latest_exposed
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.production.actual_production_hours_hqa

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

from pyspark.sql import functions as f

from leap_utils.data_asset.table_utils import save_table, remove_leading_zeros

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Input

# COMMAND ----------

# MAGIC %md
# MAGIC ##LEAP table(s)

# COMMAND ----------

df_hqa_gold = spark.read.table(f"{PIPELINE_READ_ENV}_gold.production.infocenter_hqa")

# COMMAND ----------

df_wo_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.production.sap_work_order_basics_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

OUTPUT_GOLD_TABLE_HQA_INFOCENTER = (
    f"{PIPELINE_WRITE_ENV}_gold.production.actual_production_hours_hqa"
)

# COMMAND ----------

TECHNICAL_HQA_COLUMNS = [
    "filepath",
    "filename",
    "extraction_timestamp",
    "ingestion_uid",
]

# COMMAND ----------

COL_TO_DROP = [
    col
    for col in df_hqa_gold.columns
    if col.lower().startswith("improd") or col.lower().startswith("absen")
] + ["Reason_Description"]

# COMMAND ----------

COL_TO_SELECT_WO = [
    "WO_Number",
    "Profit_Center",
    "Creation_Date",
    "Customers_Orders",
    "Customers_Orders_Item",
    "Mrp_Controller",
    "Prod_Supervisor",
    "Priority",
    "Planification_Plant",
    "Branch",
]

# COMMAND ----------

# PROD events are for operator productive hours, DEC prod for machine productive hours
PRODUCTION_EVENTS = ["PROD", "DECPROD"]

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Drop useless columns
# MAGIC - All columns relative to improductivity

# COMMAND ----------

df_hqa_prep = df_hqa_gold.drop(*COL_TO_DROP)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - Technical HQA columns

# COMMAND ----------

for col in TECHNICAL_HQA_COLUMNS:
    df_hqa_prep = df_hqa_prep.withColumnRenamed(col, f"_meta_HQA_{col}")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 3 - WO table
# MAGIC - Downselect columns 
# MAGIC - Column names cleaning 
# MAGIC - Remove leading zeros

# COMMAND ----------

df_wo_prep = df_wo_raw.select(*COL_TO_SELECT_WO)

# COMMAND ----------

for col in df_wo_prep.columns:
    if not col.startswith("WO"):
        df_wo_prep = df_wo_prep.withColumnRenamed(col, f"WO_{col}")

df_wo_prep = df_wo_prep.withColumnRenamed("WO_Description", "WO_SAP_description")

# COMMAND ----------

COL_CLEANING_LEADING_ZEROS = ["WO_Number"]

df_wo_prep = remove_leading_zeros(df_wo_prep, COL_CLEANING_LEADING_ZEROS)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Filtering on PROD event

# COMMAND ----------

df_prod_hqa_transf = df_hqa_prep.filter(f.col("Event").isin(PRODUCTION_EVENTS))

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Add WO information 

# COMMAND ----------

df_prod_hqa_transf = df_prod_hqa_transf.join(
    df_wo_prep, df_prod_hqa_transf.work_order == df_wo_prep.WO_Number, how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

save_table(OUTPUT_GOLD_TABLE_HQA_INFOCENTER, df_prod_hqa_transf, "overwrite", True)

# COMMAND ----------


