# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for previsionnal workload From SAP
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_silver.production.prev_workload
# MAGIC   
# MAGIC **Intput :**  
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.kbed_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.crhd_latest 
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.afko_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.afpo_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.plaf_latest
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_kbed
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC - Ingestion Raw SAP  
# MAGIC
# MAGIC **Things performed in this notebook:** 
# MAGIC  - Join Workload(KBED) with Master Data Orders(AFPO/AFKO/PLAF/CRHD)
# MAGIC  - Renaming Header according business rules  

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC # Previsionnal Work load

# COMMAND ----------

# MAGIC %md
# MAGIC ## Upload Tables from SAP

# COMMAND ----------

# Upload SAP Workload in comming
df_kbed = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.kbed_latest")
df_kbed = table_utils.add_prefix_to_columns(df_kbed, "KBED")
# Exclusion Simulation Workload
df_kbed = df_kbed.filter(f.col("KBED_plscn") == "000")
# Exclusion Operation already confirmed
df_kbed = df_kbed.withColumn("KBED_iendd", f.to_date(f.col("KBED_iendd"), "yyyyMMdd"))
df_kbed = df_kbed.filter(f.col("KBED_iendd").isNull())

## Upload SAP Work Center Master Data
df_crhd = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.crhd_latest")
# Keep Only Description of Work Center (arbpl)
df_crhd = df_crhd.select("objid", "arbpl")
df_crhd = table_utils.add_prefix_to_columns(df_crhd, "CRHD")


## Upload SAP Work Order Header Data
df_afko = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.afko_latest")
# Keep Only Mrp Controller (dispo) and Work Order (aufnr)
df_afko = df_afko.select("bedid", "dispo", "aufnr")
df_afko = table_utils.add_prefix_to_columns(df_afko, "AFKO")


## Upload SAP Work Order Data
df_afpo = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.afpo_latest")
# Keep Only Work Order(aufnr) Material_Number(matnr)
# Order_Type (dauat) Prod_Version (verid) Planned_Order(plnum)
df_afpo = df_afpo.select("aufnr", "matnr", "dauat", "verid", "plnum", "dwerk")
df_afpo = table_utils.add_prefix_to_columns(df_afpo, "AFPO")


# Upload SAP Planned Orders Data
df_plaf = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.plaf_latest")
# Keep Only Planned Order(aufnr) Material_Number(matnr)
# Order_Type(paart) Prod_Version(verid) Mrp Controller(dispo)
# Plant(plwerk)
df_plaf = df_plaf.select(
    "bedid",
    "plnum",
    "matnr",
    "paart",
    "verid",
    "dispo",
    "plwrk",
    "plscn",
)
df_plaf = table_utils.add_prefix_to_columns(df_plaf, "PLAF")
# Exclusion Simulation Planned Order
df_plaf = df_plaf.filter(f.col("PLAF_plscn") == "000")
df_plaf = df_plaf.drop("PLAF_plscn")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Join WorkLoad with Work Order & Planned Order tables

# COMMAND ----------

# Field 'KBED_arbid' & 'CRHD_objid' are internal number used to link table KBED and CRHD
# Field 'bedid' is internal number SAP used to link table KBED and AFKO/PLAF
# Field 'bedid' is not include in AFPO, so the link is made through Work_Order Number ('aufnr')
df_join_workload = (
    df_kbed.alias("A")
    .join(
        f.broadcast(df_crhd).alias("B"),
        f.col("A.KBED_arbid") == f.col("B.CRHD_objid"),
        "left",
    )
    .join(df_afko.alias("C"), f.col("A.KBED_bedid") == f.col("C.AFKO_bedid"), "left")
    .join(df_afpo.alias("D"), f.col("C.AFKO_aufnr") == f.col("D.AFPO_aufnr"), "left")
    .join(df_plaf.alias("E"), f.col("A.KBED_bedid") == f.col("E.PLAF_bedid"), "left")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Cleansing KBED entries

# COMMAND ----------

# In some case Entries from KBED is deleted even if Work Order is closed
# So we keep only entries where Work Order or Planned Order have been found
df_workload_filtered = df_join_workload.filter(
    (f.col("AFKO_bedid")).isNotNull() | (f.col("PLAF_bedid")).isNotNull()
)
df_workload_filtered = df_workload_filtered.drop(
    "CRHD_objid", "AFKO_bedid", "AFKO_aufnr", "PLAF_bedid"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Renaming Work Order information

# COMMAND ----------

# Ressources_Number -> Work Order(aufnr) or Planned Order(plnum)
df_workload_renamed = df_workload_filtered.withColumn(
    "Ressources_Number",
    f.when(f.col("AFPO_aufnr").isNotNull(), f.col("AFPO_aufnr")).otherwise(
        f.col("PLAF_plnum")
    ),
)
# Ressources_Type -> Work Order or Planned Order
df_workload_renamed = df_workload_renamed.withColumn(
    "Ressources_Type",
    f.when(f.col("AFPO_aufnr").isNotNull(), f.lit("Work_Order")).otherwise(
        f.lit("Planned_Order")
    ),
)
# Take informations from Work Order or Planned Order Table
df_workload_renamed = df_workload_renamed.withColumn(
    "Mrp_Controller",
    f.when(f.col("Ressources_Type") == "Work_Order", f.col("AFKO_dispo")).otherwise(
        f.col("PLAF_dispo")
    ),
)
df_workload_renamed = df_workload_renamed.withColumn(
    "Material_Number",
    f.when(f.col("Ressources_Type") == "Work_Order", f.col("AFPO_matnr")).otherwise(
        f.col("PLAF_matnr")
    ),
)
df_workload_renamed = df_workload_renamed.withColumn(
    "Production_Version",
    f.when(f.col("Ressources_Type") == "Work_Order", f.col("AFPO_verid")).otherwise(
        f.col("PLAF_verid")
    ),
)
df_workload_renamed = df_workload_renamed.withColumn(
    "Order_Type",
    f.when(f.col("Ressources_Type") == "Work_Order", f.col("AFPO_dauat")).otherwise(
        f.col("PLAF_paart")
    ),
)
df_workload_renamed = df_workload_renamed.withColumn(
    "Plant",
    f.when(f.col("Ressources_Type") == "Work_Order", f.col("AFPO_dwerk")).otherwise(
        f.col("PLAF_plwrk")
    ),
)
df_workload_renamed = df_workload_renamed.withColumn(
    "Planned_Order_Origin", f.col("AFPO_plnum")
)
df_workload_renamed = df_workload_renamed.withColumn("Work_Center", f.col("CRHD_arbpl"))
df_workload_renamed = df_workload_renamed.drop(
    "AFPO_aufnr",
    "PLAF_plnum",
    "AFKO_dispo",
    "PLAF_dispo",
    "AFPO_matnr",
    "PLAF_matnr",
    "AFPO_verid",
    "PLAF_verid",
    "AFPO_dauat",
    "PLAF_paart",
    "AFPO_dwerk",
    "PLAF_plwrk",
    "CRHD_arbpl",
    "AFPO_plnum",
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming Header with business entries

# COMMAND ----------

df_name_kbed = spark.read.table("prod_bronze.headers_sap.headers_sap_business_kbed")
# Call function Check Header files
check_schema_of_the_file(df_name_kbed)
# Call Function Delete rows null
df_name_kbed = delete_null_rows(df_name_kbed)

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_workload_renamed, df_name_kbed
)
# Call Funtion Create Columns on Date format
df_workload = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_kbed
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cleansing dataframe before saving

# COMMAND ----------

# Formatting Ressources_Number without '0' on left side
df_workload = df_workload.withColumn(
    "Ressources_Number", f.regexp_replace(df_workload.Ressources_Number, "^0+", "")
)
# Formatting Material_Number without '0' on left side
df_workload = df_workload.withColumn(
    "Material_Number", f.regexp_replace(df_workload.Material_Number, "^0+", "")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save table

# COMMAND ----------

catalog = f"{WRITE_ENV}_silver"
domain = "production"
table = "prev_workload"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_workload,
    mode="overwrite",
    overwrite_schema=True
)
