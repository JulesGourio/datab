# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # WORK ORDERS HISTORY
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a Gold & Gold exposed table for Work Order Production history and latest.
# MAGIC
# MAGIC The notebook performs the following tasks:
# MAGIC
# MAGIC - Data Loading: Loads the silver changelog history table
# MAGIC - Add WBS Codin
# MAGIC - Add Description Work Order
# MAGIC - Add Work Order Status
# MAGIC - Add plant and company information
# MAGIC - Translate Field in business description
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - Update changelog history
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Work_Orders_Daily
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - Update : Daily
# MAGIC   - History : Once (exceptionally more)
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC   - {pipeline_read_env}_silver.production.sap_work_order_basics_history  
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC   - {reference_read_env}_gold.finance.wbs_otp  
# MAGIC   - {reference_read_env}_gold.master_data.material_master_data_basics_exposed  
# MAGIC   - {reference_read_env}_gold.master_data.plant_master_data_latest_exposed
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.jest_latest 
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.tj02t_latest 
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC   - {pipeline_write_env}_gold.production.sap_work_order_basics_latest
# MAGIC   - {pipeline_write_env}_gold.production.sap_work_order_basics_latest_exposed
# MAGIC   - {pipeline_write_env}_gold.production.sap_work_order_basics_history
# MAGIC   - {pipeline_write_env}_gold.production.sap_work_order_basics_history_exposed
# MAGIC
# MAGIC
# MAGIC **Output Files Pipeline**
# MAGIC N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

from datetime import date
import pyspark.sql.functions as f
import logging
import time
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql import Window
from typing import List, Dict
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Spark
# MAGIC

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC ```
# MAGIC ```
# MAGIC #### functions used from "leap_utils.data_asset.table_utils"
# MAGIC ```
# MAGIC table_utils.UnityCatalogCheckTableExists()
# MAGIC table_utils.save_table()
# MAGIC table_utils.create_table_view()
# MAGIC table_utils.merge_into()
# MAGIC ```
# MAGIC
# MAGIC #### functions used from leap_utils.common.validation.gx_validation
# MAGIC ```
# MAGIC gx_validation.validate_and_log_gx_results()
# MAGIC ```
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("run_job_on_latest", "true")  # history/update
RUN_JOB_ON_LATEST = dbutils.widgets.get("run_job_on_latest").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "debug")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

spark.conf.set("spark.sql.ansi.enabled", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables Location
# MAGIC
# MAGIC Details on how to read the input tables

# COMMAND ----------

SILVER_SCHEMA = f"{PIPELINE_READ_ENV}_silver.production"

# Upload Work Order Gold Table
t_silver_work_order = f"{SILVER_SCHEMA}.sap_work_order_basics_history"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

GOLD_SCHEMA = f"{PIPELINE_WRITE_ENV}_gold.production"

TABLE_DEST_HCL = f"{GOLD_SCHEMA}.sap_work_order_basics_history"
TABLE_DEST_LATEST = f"{GOLD_SCHEMA}.sap_work_order_basics_latest"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# As it's a huge table, we'll cluster it by these columns, rather than partitioning
CLUSTER_COLS_STR = "WO_Number,Start_Validity,End_Validity"

PK_COLUMNS_LIST = ["WO_Number", "AFPO_posnr"]  # PRIMARY KEY OF THE LATEST (aka id_column_list)
TIMELINE_COL = "Start_Validity"
SK_COLUMNS_LIST = PK_COLUMNS_LIST + [TIMELINE_COL]  # SURROGATE KEY , PRIMARY KEY OF THE HISTORY

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs 
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"RUN_JOB_ON_LATEST is:  {RUN_JOB_ON_LATEST}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"GOLD_SCHEMA is:  {GOLD_SCHEMA}")
log.info(f"TABLE_DEST_HCL is:  {TABLE_DEST_HCL}")
log.info(f"TABLE_DEST_LATEST is:  {TABLE_DEST_LATEST}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Read tables
# MAGIC - Stack and match

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Tables TABLES & headers

# COMMAND ----------

# Upload Work Order Gold Table
log.info(f"Reading current Silver history changelog table.")
df_work_order = spark.read.table(f"{t_silver_work_order}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - If RUN_JOB_ON_LATEST Filter silver history table

# COMMAND ----------

# check job type
if (table_utils.UnityCatalogCheckTableExists(TABLE_DEST_HCL)) and (RUN_JOB_ON_LATEST == True):
    log.info(f"Filtering current silver history changelog table.")
    df_target = spark.read.table(f"{TABLE_DEST_HCL}")
    # Filter silver history for rows that are not in the target
    df_work_order_update = (
        df_work_order.alias("A")
        .join(
            df_target.alias("B"),
            (f.col("A.WO_Number") == f.col("B.WO_Number")) & (f.col("A.AFPO_posnr") == f.col("B.AFPO_posnr")) & (f.col("A.Start_Validity") == f.col("B.Start_Validity")) & (f.col("A.End_Validity") == f.col("B.End_Validity")),
            "left_anti",
        )
    )
    log.debug(f"Current history changelog to update count {df_work_order_update.count()} rows.")
    df_target.unpersist()

    if df_work_order_update.isEmpty():
        dbutils.notebook.exit(
            f"the table {TABLE_DEST_HCL} is already up to date"
        )  # Quitter le notebook sans erreur
else:
    log.info(f"Reading full silver history changelog table.")
    RUN_JOB_ON_LATEST = False
    df_work_order_update = df_work_order
    log.debug(f"Full history changelog count {df_work_order_update.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Management of WBS coding

# COMMAND ----------

## We use Gold Table WBS to translate WBS_Code_Num to Business WBS_Code
# Upload WBS Gold Table
df_otp = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.wbs_otp")
df_otp = df_otp.select("WBS_Code_Num", "WBS_Code")
# Join WBS description on Work Order Table
df_work_order_wbs = (
    df_work_order_update.alias("A")
    .join(
        df_otp.alias("B"),
        f.col("A.WBS_Element") == f.col("B.WBS_Code_Num"),
        "left",
    )
    .drop("WBS_Code_Num", "WBS_Element")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Management Description of Work Order

# COMMAND ----------

## We keep Description comming from Work order header, if description is empty we take description from Gold Material Table
# Upload Gold Master Data Material
df_material = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_master_data_basics_exposed"
)
df_material = df_material.withColumnRenamed(
    "Material_Number", "Material_Number_"
).withColumnRenamed("Description", "Description_")
df_material = df_material.select("Material_Number_", "Description_")

# Join Master Data Material and Work Orders
df_work_order_description = df_work_order_wbs.alias("A").join(
    df_material.alias("B"),
    f.col("A.Material_Number").cast("string")
    == f.col("B.Material_Number_").cast("string"),
    "left",
)
# Keep Work_Order Description first, then material description
df_work_order_description = df_work_order_description.withColumn("WO_Description",f.coalesce(f.col("WO_Description"),f.col("Description_")))

df_work_order_description = df_work_order_description.drop(
    "Material_Number_", "Description_"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Determination of Work Order Status

# COMMAND ----------

## Rules WO_Status
# AUFK_idat2 and AUFK_idat3 are fullfil only when a Work order is Technical closed or Accounticaly closed
# AUFK_ftrmi is the field for real launching date
# AUFK_loekz is the field for cancelation flag in SAP
# AFPO_elikz is the field for delivery flag in SAP
# As soon as a quantity is delivered with put WO_Delivered
# Others -> In progress

## Cast Columns for determination Status Work Orders
# Technical closed
df_work_order_status = df_work_order_description.withColumn(
    "AUFK_idat2", f.col("AUFK_idat2").cast("float")
)
# Accounticaly closed
df_work_order_status = df_work_order_status.withColumn(
    "AUFK_idat3", f.col("AUFK_idat3").cast("float")
)

df_work_order_status = df_work_order_status.withColumn(
    "WO_Status",
    f.when(f.col("AUFK_loekz") == "X", f.lit("WO_Cancelled"))
    .when(f.col("Quantity_Delivered") > 0, f.lit("WO_Delivered"))
    .when(f.col("AFPO_elikz") == "X", f.lit("WO_Delivered"))  
    .when(f.col("Quantity_Scrapped") == f.col("Quantity_Ordered"), f.lit("WO_Scrapped"))
    .when(((f.col("AUFK_idat2") > 0) | (f.col("AUFK_idat3") > 0)) & (f.substring(f.col("Order_Type"),4,1)=="9"), f.lit("WO_Delivered"))
    .when(((f.col("AUFK_idat2") > 0) | (f.col("AUFK_idat3") > 0)) ,f.lit("WO_Cancelled"))
    .when((f.col("Quantity_Delivered") == 0) & (f.col("Quantity_Scrapped") == 0) & (f.col("Real_End_Date").isNotNull()), f.lit("WO_To_Analyse"))
    .when(f.col("Real_Launching_Date").isNotNull(), f.lit("WO_In_Progress"))
    .otherwise(f.lit("WO_Open")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 5 - Determination of Work Order Reception through MSEG Table
# MAGIC

# COMMAND ----------

# Upload Mseg table in order to take last Mouvement 101
df_mseg = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mseg_latest"
)
df_mseg = df_mseg.select(
    f.col("bwart").alias("Code_Mvt"),
    f.col("aufnr").alias("WO_Number"),
    f.col("cpudt_mkpf").alias("Date_Mvt"),
    f.col("cputm_mkpf").alias("Hour_Mvt"),
).filter(
    ((f.col("Code_Mvt") == "101") | (f.col("Code_Mvt") == "102"))
    & (f.col("kzbew") == "F") # Exclusion entries on provider PO
)
df_mseg = df_mseg.withColumn("Date_Mvt", f.to_date(f.col("Date_Mvt"), "yyyyMMdd"))

# Formatting Work order without '0' on left side
df_mseg = df_mseg.withColumn(
    "WO_Number", f.regexp_replace(df_mseg.WO_Number, "^0+", "")
)

# We kept last 101 mouvement
window_spec = Window.partitionBy("WO_Number").orderBy(
    f.desc("Date_Mvt"), f.desc("Hour_Mvt")
)

df_mseg_filtered = (
    df_mseg.withColumn("row_num", f.row_number().over(window_spec))
    .filter((f.col("row_num") == 1) & (f.col("Code_Mvt") == "101"))
    .drop("row_num","Hour_Mvt","Code_Mvt")
)


# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Add information for Plant Company and branch

# COMMAND ----------

# Upload Gold Master Data Plant
df_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)
df_plant = df_plant.select("Plant", "Plant_Description_new")
df_plant = df_plant.withColumnRenamed("Plant", "Plant_").withColumnRenamed(
    "Plant_Description_new", "Production_Site"
)

# Join Plant description on Work Order Table
df_work_order_plant = (
    df_work_order_status.alias("A")
    .join(
        f.broadcast(df_plant).alias("B"),
        f.col("A.Plant") == f.col("B.Plant_"),
        "left",
    )
    .drop("Plant_")
)

# Dispatch Production Site for Plant 1000 (Gimont/Montredon/DES)
df_work_order_site = df_work_order_plant.withColumn(
    "Production_Site",
    f.when(f.col("Plant") != "1000", f.col("Production_Site"))
    .when(f.substring(f.col("Mrp_controller"), 1, 1) == "O", f.lit("LFR-Montredon"))
    .when(f.col("Mrp_Controller") == "DET", f.lit("LFR-DES"))
    .otherwise(f.lit("LFR-Gimont")),
)
# Determination Branch AS / IS
df_work_order_branch = df_work_order_site.withColumn(
    "Branch",
    f.when(
        (f.col("Production_Site") == "LFR-DES") | (f.substring(f.col("Plant"), 0, 1) == "2"),
        f.lit("IS"),
    ).otherwise(f.lit("AS")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Business traduction of SAP fields

# COMMAND ----------

# Management of Schedulling Type
df_work_order_sched = df_work_order_branch.withColumn(
    "Scheduling_Type",
    f.when(f.col("Scheduling_Type") == "1", f.lit("Forwards"))
    .when(f.col("Scheduling_Type") == "2", f.lit("Backwards"))
    .when(f.col("Scheduling_Type") == "3", f.lit("Only Capacity requirements"))
    .when(f.col("Scheduling_Type") == "4", f.lit("Current date"))
    .when(f.col("Scheduling_Type") == "5", f.lit("Forwards in time"))
    .otherwise(f.lit("Backwards in time")),
)
# Management of Order_Type
list_details = ["ZP01", "ZP05", "YP03", "YP23"]
list_assy = ["ZP03", "ZP04", "YP04", "YP24"]
df_work_order_type = df_work_order_sched.withColumn(
    "Order_Type_Description",
    f.when(
        f.col("Order_Type").isin(list_details),
        f.lit("Details Parts"),
    )
    .when(f.col("Order_Type") == "ZP02", f.lit("Kanban orders"))
    .when(
        f.col("Order_Type").isin(list_assy),
        f.lit("Assembly Parts"),
    )
    .otherwise(f.lit("Rush Orders")),
)
# Management of Routing_Status
df_work_order_routing = df_work_order_type.withColumn(
    "Routing_Status",
    f.when(f.substring(f.col("AFKO_zpp_statu"), 0, 1) == "F", "FAI").otherwise("STD"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Management Work Order Status System

# COMMAND ----------

### WARNING - Must Be replace by WO-Status when it will be available
## ----------------------------------------------------------------------------------
## Keep only activ status on production Orders and merge in one cells
# Upload SAP Object Status Table
df_wo_status = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.jest_latest")
# Keep Only Object Work Order ('OR') and active status
df_wo_status_filtered = df_wo_status.filter(
    (f.substring(f.col("objnr"), 1, 2) == "OR") & (f.col("inact").isNull())
)
# Extract WO_Order_Number from objnr field
df_wo_status_udpt = df_wo_status_filtered.withColumn(
    "WO_Order_S", f.substring(f.col("objnr"), 8, 7)
)
df_wo_status_selected = df_wo_status_udpt.select("WO_Order_S", "stat")

## Upload SAP Description Status Table
df_status_def = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tj02t_latest")
# Keep only English language (spras)
df_status_def_filtered = df_status_def.filter(f.col("spras") == "E")
df_status_def_selected = df_status_def_filtered.select("istat", "txt04")

# Join Status Table with description
df_wo_status_join = (
    df_wo_status_selected.alias("A")
    .join(
        f.broadcast(df_status_def_selected).alias("B"),
        f.col("A.stat") == f.col("B.istat"),
        "left",
    )
    .drop("istat")
)
# Collect all active status on one cells WO_Status
df_status_end = df_wo_status_join.groupBy("WO_Order_S").agg(
    f.concat_ws(" ", f.collect_list(f.col("txt04"))).alias("WO_Status_System")
)
## ----------------------------------------------------------------------------------
# Add Status list in dataFrame WorkOrder
df_work_order_status = (
    df_work_order_routing.alias("A")
    .join(
        df_status_end.alias("B"), f.col("A.WO_Number") == f.col("B.WO_Order_S"), "left"
    )
    .drop("WO_Order_S")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Management Work Order Reception

# COMMAND ----------

df_work_order_status_end = df_work_order_status.join(
    df_mseg_filtered, ["WO_Number"], "left"
)
# We kept only Reception Date when it is included in start/end validity date
df_work_order_status_end = df_work_order_status_end.withColumn(
        "Reception_Date",
        f.when(
            f.col("Start_Validity") >= f.col("Date_Mvt"),
            f.col("Date_Mvt"),
        ).otherwise(f.lit(None))
).drop("Date_Mvt")

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - 
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Gold Stacked WO history

# COMMAND ----------

df_work_order_history = df_work_order_status_end

if RUN_JOB_ON_LATEST:
    log.info(f"Merging new History Changelog into table.")
    # MERGE df_work_order_history INTO TABLE_DEST_HCL using columns of the SURROGATE KEY ("WO_Number","AFPO_posnr","Start_Validity")
    #       WHEN MATCHED AND (source.End_Validity <> target.End_Validity) THEN
    #           UPDATE SET *
    #       WHEN NOT MATCHED THEN
    #           INSERT *
    log.debug(
        f"Data to merge into history count {df_work_order_history.count()} rows."
    )
    startTime = time.time()
    try:
        table_utils.merge_into(
            df_source=df_work_order_history,
            target_table=TABLE_DEST_HCL,
            list_id_matching_columns=SK_COLUMNS_LIST,
            matched_clause="(source.End_Validity <> target.End_Validity) or (source._meta_max_extraction_date <> target._meta_max_extraction_date)",
        ).display()
    except Exception as e:
        log.error(
            f"Table {TABLE_DEST_HCL} has not been created, an error occured during MERGE INTO."
        )
        all_target_cols = [
            x[0]
            for x in spark.sql(f"DESCRIBE {TABLE_DEST_HCL}")
            .select("col_name")
            .collect()
        ]
        log.error(f"Dataframe cols : {df_work_order_history.columns}\n----\n")
        log.error(f"Tables cols : {all_target_cols}\n----\n")
        log.error(f"Error : {e}")
        raise Exception()
    else:
        duration = time.time() - startTime
        log.info(f"Table {TABLE_DEST_HCL} merged in {duration} seconds.")
else:
    log.info(f"Saving new History Changelog table.")
    try:
        table_utils.save_table(
            dest_table=TABLE_DEST_HCL,
            df=df_work_order_history,
            mode="overwrite",
            overwrite_schema=True,
            cluster_cols=CLUSTER_COLS_STR,
        )
    except Exception as e:
        log.error(
            f"Table {TABLE_DEST_HCL} has not been created, an error occured during save."
        )
        log.error(f"Error : {e}")
        raise Exception()
    else:
        log.info(
            f"Data saved into history count {df_work_order_history.count()} rows."
        )

# COMMAND ----------

ANALYZE_TABLE_SQL = f"ANALYZE TABLE {TABLE_DEST_HCL} COMPUTE STATISTICS"
spark.sql(ANALYZE_TABLE_SQL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Gold Stacked WO history exposed

# COMMAND ----------

src_full_tablename = f"{TABLE_DEST_HCL}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "AU"
Begin_By2 = "AF"
Begin_By3 = "_meta"

selected_columns = [
    col
    for col in df_work_order_history.columns
    if not col.startswith(Begin_By) and not col.startswith(Begin_By2) and not col.startswith(Begin_By3)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Gold Stacked WO latest

# COMMAND ----------

if RUN_JOB_ON_LATEST:
    # if delta update we reload the HCL and filter only on End_validity "9999-12-31" in order to have only latest value
    df_work_order_latest = spark.read.table(f"{TABLE_DEST_HCL}").filter(f.col("End_validity") == "9999-12-31")
else:
    # if initialisation we filter only on End_validity "9999-12-31" in order to have only latest value
    df_work_order_latest = df_work_order_status.filter(f.col("End_validity") == "9999-12-31")

# Add extraction date of latest 
df_work_order_latest = df_work_order_latest.withColumn("extraction_date", f.lit(date.today()))

log.info(f"Saving new gold latest table.")
result = table_utils.save_table(
    dest_table=TABLE_DEST_LATEST,
    df=df_work_order_latest,
    mode="overwrite",
    overwrite_schema=True,
)
log.info(
    f"Data saved into history count {df_work_order_latest.count()} rows."
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Gold Stacked WO latest exposed

# COMMAND ----------

src_full_tablename = f"{TABLE_DEST_LATEST}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "AU"
Begin_By2 = "AF"
Begin_By3 = "_meta"

selected_columns = [
    col
    for col in df_work_order_latest.columns
    if not col.startswith(Begin_By) and not col.startswith(Begin_By2) and not col.startswith(Begin_By3)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
