# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # WORK ORDERS HISTORY
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to create a silver history table for Work orders.
# MAGIC The notebook performs the following tasks:
# MAGIC
# MAGIC - Data Loading: Loads the bronze tables containing the raw data afko, afpo, aufk
# MAGIC - Data Filtering: Filter AUFK on Production WO
# MAGIC - Date Formatting: Formats the date column to a desired format.
# MAGIC - Column Renaming: Renames specific columns to be exposed
# MAGIC - Table Joining : Join afko to aufk, then join to afpo
# MAGIC - Silver Table Creation: Generates a silver table with the cleaned and transformed data.
# MAGIC - Historization done on field : afko_extraction_date
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - Stack and match of extraction_timestamp of several tables
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Work_Orders_Daily
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - Update : Daily
# MAGIC   - History : Once (exceptionally more)
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.afko_stack
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.aufk_stack
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.afpo_stack
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_afko
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_aufk
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_afpo
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC   - {pipeline_write_env}_silver.production.sap_work_order_basics_history
# MAGIC
# MAGIC **Output Files Pipeline**
# MAGIC N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Spark
# MAGIC

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC ```
# MAGIC ```
# MAGIC #### functions used from "leap_utils.data_asset.table_utils"
# MAGIC ```
# MAGIC table_utils.add_prefix_to_columns()
# MAGIC table_utils.UnityCatalogCheckTableExists()
# MAGIC table_utils.drop_duplicates_by_order()
# MAGIC table_utils.get_columns_for_insertion_after_column()
# MAGIC table_utils.rename_columns_with_sap_business_header()
# MAGIC table_utils.cast_columns_with_sap_business_headers()
# MAGIC table_utils.create_unity_catalog_table
# MAGIC table_utils.set_table_column_not_null()
# MAGIC table_utils.add_table_primary_key()
# MAGIC table_utils.save_table()
# MAGIC table_utils.create_table_view()
# MAGIC table_utils.merge_into()
# MAGIC ```
# MAGIC
# MAGIC #### functions used from leap_utils.common.validation.gx_validation
# MAGIC ```
# MAGIC gx_validation.validate_and_log_gx_results()
# MAGIC ```
# MAGIC
# MAGIC #### functions used from "leap_utils.data_asset.history_changelog"
# MAGIC ```
# MAGIC history_changelog.initialize_history_changelog()
# MAGIC history_changelog.calculate_history_changelog_delta_update()
# MAGIC ```

# COMMAND ----------

from leap_utils.data_asset import table_utils, history_changelog
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("run_job_on_latest", "true")  # history/update
RUN_JOB_ON_LATEST = dbutils.widgets.get("run_job_on_latest").lower() == "true"

dbutils.widgets.text("run_changelog_on_latest", "true")  # history/update
RUN_CHANGELOG_ON_LATEST = (
    dbutils.widgets.get("run_changelog_on_latest").lower() == "true"
)

dbutils.widgets.dropdown(
    "wo_use_date_add_for_latest",
    "true",
    ["true", "false"],
    "Use date_add for extraction date?",
)
WO_USE_DATE_ADD = dbutils.widgets.get("wo_use_date_add_for_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "debug")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

spark.conf.set("spark.sql.ansi.enabled", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables Location
# MAGIC
# MAGIC Details on how to read the input tables

# COMMAND ----------

BRONZE_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6"
HEADERS_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.headers_sap"

# SAP table AFKO - Header
t_afko_stack = f"{BRONZE_SCHEMA}.afko_stack"
# SAP table AFPO - Item
t_afpo_stack = f"{BRONZE_SCHEMA}.afpo_stack"
# SAP table AUFK
t_aufk_stack = f"{BRONZE_SCHEMA}.aufk_stack"


# SAP business header
t_name_afko = f"{HEADERS_SCHEMA}.headers_sap_business_afko"
t_name_afpo = f"{HEADERS_SCHEMA}.headers_sap_business_afpo"
t_name_aufk = f"{HEADERS_SCHEMA}.headers_sap_business_aufk"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_SCHEMA = f"{PIPELINE_WRITE_ENV}_silver.production"
TABLE_DEST_STACK = f"{SILVER_SCHEMA}.sap_work_order_basics_history_stacked"
TABLE_DEST_HCL = f"{SILVER_SCHEMA}.sap_work_order_basics_history"
MODE = "append" if RUN_JOB_ON_LATEST else "overwrite"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# MAGIC %md
# MAGIC #### for the History Stacked

# COMMAND ----------

# Columns needed to create the empty table at first run
TABLE_DEST_STACK_FIRST_COLS = {
    "WO_Number": "BIGINT",
    "AFPO_posnr": "STRING",
    "Start_Validity": "DATE",
}

# As it's a huge table, we'll cluster it by these columns, rather than partitioning
TABLE_DEST_STACK_CLUSTER_COLS = "WO_Number,AFPO_posnr,Start_Validity"
TABLE_DEST_STACK_PK_COLS = "WO_Number,AFPO_posnr,Start_Validity"


# COMMAND ----------

# MAGIC %md
# MAGIC #### for the History Changelog

# COMMAND ----------

TABLE_DEST_HCL_PK_COLUMNS_LIST = [
    "WO_Number",
    "AFPO_posnr",
]  # PRIMARY KEY OF THE LATEST (aka id_column_list)
TIMELINE_COL = "Start_Validity"
TABLE_DEST_HCL_SK_COLUMNS_LIST = TABLE_DEST_HCL_PK_COLUMNS_LIST + [
    TIMELINE_COL
]  # SURROGATE KEY , PRIMARY KEY OF THE HISTORY

# As it's a huge table, we'll cluster it by these columns, rather than partitioning
TABLE_DEST_HCL_CLUSTER_COLS_STR = "WO_Number,Start_Validity,End_Validity"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# Sample reference date when target table exists ans is empty
THE_ORIGIN = "1970-01-01"

# TIME DELTA ALLOWANCE in hours , for stack&match of extraction_timestamps(s)
TIME_DELTA_ALLOWANCE = f.make_dt_interval(hours=f.lit(8))

# Flag to avoid processing Empty Dataframe
EMPTY_DATAFRAME_FLAG = False

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"RUN_JOB_ON_LATEST is:  {RUN_JOB_ON_LATEST}")
log.info(f"RUN_CHANGELOG_ON_LATEST is:  {RUN_CHANGELOG_ON_LATEST}")
log.info(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"TIME_DELTA_ALLOWANCE is:  {TIME_DELTA_ALLOWANCE} hours")
log.info(f"TABLE_DEST_STACK is:  {TABLE_DEST_STACK}")
log.info(f"MODE is:  {MODE}")
log.info(f"TABLE_DEST_HCL is:  {TABLE_DEST_HCL}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Read tables
# MAGIC - Stack and match

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Tables TABLES & headers

# COMMAND ----------

# Upload SAP table AFKO - Header
df_afko = spark.read.table(f"{t_afko_stack}")
df_afko = table_utils.add_prefix_to_columns(df_afko, "AFKO")

# Upload SAP table AFPO - Item
df_afpo = spark.read.table(f"{t_afpo_stack}")
df_afpo = table_utils.add_prefix_to_columns(df_afpo, "AFPO")

# Upload SAP table AUFK
df_aufk = spark.read.table(f"{t_aufk_stack}")
df_aufk = table_utils.add_prefix_to_columns(df_aufk, "AUFK")

# Upload SAP headers
df_name_afko = spark.read.table(f"{t_name_afko}")
df_name_afpo = spark.read.table(f"{t_name_afpo}")
df_name_aufk = spark.read.table(f"{t_name_aufk}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Repartition Tables by aufnr

# COMMAND ----------

df_afko = df_afko.repartition("AFKO_aufnr")
df_afpo = df_afpo.repartition("AFPO_aufnr")
df_aufk = df_aufk.repartition("AUFK_aufnr")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - If RUN_JOB_ON_LATEST Filter all tables on needed stacks

# COMMAND ----------

# check job type - Filter all tables on needed stacks

if (table_utils.UnityCatalogCheckTableExists(TABLE_DEST_STACK)) and (
    RUN_JOB_ON_LATEST == True
):
    log.info(f"Processing Delta Dataset.")
    df_target = spark.read.table(TABLE_DEST_STACK)

    # 1) Dernière Start_Validity connue dans la silver (DATE)
    latest_in_silver = df_target.select(
        f.max("Start_Validity").alias("Max_Start_Validity")
    ).first()[0]

    if latest_in_silver is None:
        latest_in_silver = THE_ORIGIN
        log.info(
            f"latest_extraction_date is None -> using THE_ORIGIN = {latest_in_silver}"
        )
    else:
        log.info(f"latest_extraction_date in silver = {latest_in_silver}")

    # 2) Calcul des 2 derniers jours AFKO (niveau DATE)
    # Récupérer le dernier timestamp AFKO (spark utilise les stats / partitions)
    last_2_ts = spark.sql(f"select distinct(extraction_timestamp) from {t_afko_stack} order by 1 desc limit 2").collect()
    timestamps = [row[0] for row in last_2_ts]
    if len(timestamps) == 2:
        same_day_twice = (timestamps[0].date() == timestamps[1].date())
    else:
        same_day_twice = True

    # 3) Décision : +1 jour ou pas
    if same_day_twice:
        # PAS de +1 -> sinon on saute un jour complet
        effective_latest = f.lit(latest_in_silver)
        log.info("Deux dernières extractions AFKO = même journée -> pas de +1 jour.")
    else:
        # +1 jour uniquement si on change réellement de date
        effective_latest = f.date_add(f.lit(latest_in_silver), 1)
        _v = spark.range(1).select(effective_latest.alias("d")).first()["d"]
        log.info(f"Deux extractions sur jours DIFFÉRENTS -> +1 jour -> { _v }")

    # 4) Filtrage au niveau DATE (>=)
    df_afko = df_afko.filter(f.to_date("AFKO_extraction_timestamp") >= effective_latest)
    df_afpo = df_afpo.filter(f.to_date("AFPO_extraction_timestamp") >= effective_latest)
    df_aufk = df_aufk.filter(f.to_date("AUFK_extraction_timestamp") >= effective_latest)

    if df_afko.isEmpty():
        log.info(f"df_afko is empty, the table {TABLE_DEST_STACK} is probably already up to date")
        EMPTY_DATAFRAME_FLAG = True
else:
    log.info(f"Processing Full Dataset.")
    RUN_JOB_ON_LATEST = False
    MODE = "overwrite"
    log.debug(f"MODE is:  {MODE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Filter AUFK

# COMMAND ----------

# Keep only Production Orders
df_aufk_filtered = df_aufk.filter(f.col("AUFK_autyp") == "10")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Persist result

# COMMAND ----------

# Persist Dataframe if we run on full stacks
if RUN_JOB_ON_LATEST == False:
    df_afko.persist()
    df_afpo.persist()
    df_aufk_filtered.persist()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Stack & Match extraction_timestamp(s)

# COMMAND ----------

# Retrieve Extraction timestamps
afko_timestamps = (
    df_afko.select(
        f.col("AFKO_extraction_timestamp").alias("AFKO_extraction_timestamp")
    )
    .distinct()
    .sort("AFKO_extraction_timestamp")
)
afpo_timestamps = (
    df_afpo.select(
        f.col("AFPO_extraction_timestamp").alias("AFPO_extraction_timestamp")
    )
    .distinct()
    .sort("AFPO_extraction_timestamp")
)
aufk_timestamps = (
    df_aufk_filtered.select(
        f.col("AUFK_extraction_timestamp").alias("AUFK_extraction_timestamp")
    )
    .distinct()
    .sort("AUFK_extraction_timestamp")
)

# COMMAND ----------

# Join xxxx_timestamps and remove incomplete extractions (only allow a certain interval of TIME_DELTA_ALLOWANCE hours between two extractions)
wo_timestamps = (
    afko_timestamps.hint("range_join", 60)
    .join(
        afpo_timestamps,
        on=(
            afko_timestamps.AFKO_extraction_timestamp
            >= (afpo_timestamps.AFPO_extraction_timestamp - TIME_DELTA_ALLOWANCE)
        )
        & (
            afko_timestamps.AFKO_extraction_timestamp
            < (afpo_timestamps.AFPO_extraction_timestamp + TIME_DELTA_ALLOWANCE)
        ),
        how="left",
    )
    .hint("range_join", 60)
    .join(
        aufk_timestamps,
        on=(
            afko_timestamps.AFKO_extraction_timestamp
            >= (aufk_timestamps.AUFK_extraction_timestamp - TIME_DELTA_ALLOWANCE)
        )
        & (
            afko_timestamps.AFKO_extraction_timestamp
            < (aufk_timestamps.AUFK_extraction_timestamp + TIME_DELTA_ALLOWANCE)
        ),
        how="left",
    )
)
wo_timestamps = wo_timestamps.dropna()
wo_timestamps = (
    wo_timestamps.withColumn(
        "extraction_date", f.to_date(f.col("AFKO_extraction_timestamp"))
    )
    .withColumn("day_of_week", f.dayofweek("extraction_date"))
    .withColumn(
        "extraction_week",
        f.weekofyear("extraction_date"),
    )
    .withColumn(
        "extraction_month",
        f.month("extraction_date"),
    )
    .withColumn(
        "extraction_year",
        f.when(
            (f.col("extraction_week").isin(52, 53)) & (f.col("extraction_month") == 1),
            f.year("extraction_date") - 1,
        ).otherwise(f.year("extraction_date")),
    )
    .drop("day_of_week", "extraction_month")
)
# Drop dupplicates of date based on first occurence in case
wo_timestamps = table_utils.drop_duplicates_by_order(
    wo_timestamps,
    "extraction_date",
    [
        "AFKO_extraction_timestamp",
        "AFPO_extraction_timestamp",
        "AUFK_extraction_timestamp",
    ],
    keep="last",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Display Timestamps
# MAGIC
# MAGIC At this step we may want to print all timestamps, the final one being wo_timestamps
# MAGIC

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    display(wo_timestamps)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 5 - Filter AFKO on common extraction_date

# COMMAND ----------

# filter afko with incomplete extraction by doing an inner join with wo_timestamps
df_afko = (
    df_afko.join(
        f.broadcast(wo_timestamps).select(
            f.col("AFKO_extraction_timestamp"),
            f.col("extraction_date").alias("AFKO_extraction_date"),
        ),
        on="AFKO_extraction_timestamp",
        how="inner",
    )
    .withColumnRenamed("AFKO_extraction_timestamp", "AFKO_extraction_timestamp_1")
    .withColumnRenamed("AFKO_extraction_date", "AFKO_extraction_date_1")
)

# Move "AFKO_extraction_timestamp" and "AFKO_extraction_date" columns
df_afko = (
    df_afko.withColumns(
        {
            "AFKO_extraction_timestamp": f.col("AFKO_extraction_timestamp_1"),
            "AFKO_extraction_date": f.col("AFKO_extraction_date_1"),
        },
    ).select(
        *table_utils.get_columns_for_insertion_after_column(
            df_afko,
            search_column_name="AFKO_ID",
            insert_columns=["AFKO_extraction_date", "AFKO_extraction_timestamp"],
        )
    )
).drop("AFKO_extraction_timestamp_1", "AFKO_extraction_date_1")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 6 - Filter AFPO on common extraction_date

# COMMAND ----------

# filter afko with incomplete extraction by doing an inner join with wo_timestamps
df_afpo = (
    df_afpo.join(
        f.broadcast(wo_timestamps).select(
            f.col("AFPO_extraction_timestamp"),
            f.col("extraction_date").alias("AFPO_extraction_date"),
        ),
        on="AFPO_extraction_timestamp",
        how="inner",
    )
    .withColumnRenamed("AFPO_extraction_timestamp", "AFPO_extraction_timestamp_1")
    .withColumnRenamed("AFPO_extraction_date", "AFPO_extraction_date_1")
)

# Move "AFPO_extraction_timestamp" and "AFPO_extraction_date" columns
df_afpo = (
    df_afpo.withColumns(
        {
            "AFPO_extraction_timestamp": f.col("AFPO_extraction_timestamp_1"),
            "AFPO_extraction_date": f.col("AFPO_extraction_date_1"),
        },
    ).select(
        *table_utils.get_columns_for_insertion_after_column(
            df_afpo,
            search_column_name="AFPO_ID",
            insert_columns=["AFPO_extraction_date", "AFPO_extraction_timestamp"],
        )
    )
).drop("AFPO_extraction_timestamp_1", "AFPO_extraction_date_1")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 7 - Filter AUFK on common extraction_date

# COMMAND ----------

# filter aufk with incomplete extraction by doing an inner join with wo_timestamps
df_aufk_filtered = (
    df_aufk_filtered.join(
        f.broadcast(wo_timestamps).select(
            f.col("AUFK_extraction_timestamp"),
            f.col("extraction_date").alias("AUFK_extraction_date"),
        ),
        on="AUFK_extraction_timestamp",
        how="inner",
    )
    .withColumnRenamed("AUFK_extraction_timestamp", "AUFK_extraction_timestamp_1")
    .withColumnRenamed("AUFK_extraction_date", "AUFK_extraction_date_1")
)

# Move "AUFK_extraction_timestamp" and "AUFK_extraction_date" columns
df_aufk_filtered = (
    df_aufk_filtered.withColumns(
        {
            "AUFK_extraction_timestamp": f.col("AUFK_extraction_timestamp_1"),
            "AUFK_extraction_date": f.col("AUFK_extraction_date_1"),
        },
    ).select(
        *table_utils.get_columns_for_insertion_after_column(
            df_aufk_filtered,
            search_column_name="AUFK_ID",
            insert_columns=["AUFK_extraction_date", "AUFK_extraction_timestamp"],
        )
    )
).drop("AUFK_extraction_timestamp_1", "AUFK_extraction_date_1")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations for Stacked history
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------


# Check Header from Manual Input file
def check_schema_of_the_file(df_names: SparkDataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# --------------------------------------------------------------------------------------------------------------


# Delete rows when field is null
def delete_null_rows(df_names: SparkDataFrame) -> SparkDataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# --------------------------------------------------------------------------------------------------------------


# Move a List of Columns in first cols of Dataframe
def move_dataframe_cols_first(df: SparkDataFrame, cols_to_move: list) -> SparkDataFrame:
    """Move columns from the list cols_to_move in first columns of Dataframe"""
    first_cols = cols_to_move
    other_cols = [c for c in df.columns if c not in first_cols]
    df_new = df.select(*first_cols, *other_cols)
    return df_new


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Join AFKO to AUFK

# COMMAND ----------

# Join Stack AFKO inner join AUFK
df_join_afko_aufk = df_afko.join(
    df_aufk_filtered,
    on=(df_afko.AFKO_aufnr == df_aufk_filtered.AUFK_aufnr)
    & (df_afko.AFKO_extraction_date == df_aufk_filtered.AUFK_extraction_date),
    how="inner",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Join to AFPO

# COMMAND ----------

# Join Stack AFKO/AUFK inner join AFPO
df_join_afko_aufk_afpo = df_join_afko_aufk.join(
    df_afpo,
    on=(df_join_afko_aufk.AFKO_aufnr == df_afpo.AFPO_aufnr)
    & (df_join_afko_aufk.AFKO_extraction_date == df_afpo.AFPO_extraction_date),
    how="inner",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Dropping and renaming columns

# COMMAND ----------

df_join_end = df_join_afko_aufk_afpo.drop(
    "AFPO_aufnr",
    "AUFK_aufnr",
    "AFPO_extraction_date",
    "AUFK_extraction_date",
).withColumnRenamed("AFKO_extraction_date", "Start_Validity")

# COMMAND ----------

## 1st Step, keep only value comminf from SAP tables
# Drop Columns linked to ingestion process
strings_to_drop = [
    "file_name",
    "table_name",
    "file_modification_time",
    "ingestion_timestamp",
    "extraction_timestamp",
]

columns_to_drop = [
    col_name
    for col_name in df_join_end.columns
    if any(substring.lower() in col_name.lower() for substring in strings_to_drop)
]
df_join_end = df_join_end.drop(*columns_to_drop)
# Manual Drop to avoid error with string 'id'
df_join_end = df_join_end.drop("AFPO_ID", "AFKO_ID", "AUFK_ID")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Renaming Headers

# COMMAND ----------

## Renaming headers AFKO - Basic Master Data from SAP
# Call function Check Header files
check_schema_of_the_file(df_name_afko)
# Call Function Delete rows null
df_name_afko = delete_null_rows(df_name_afko)
# -----------------------------------------------------------------------------------
## Renaming headers AUFK - Master Data SAP Header Work Order
# Call function Check Header files
check_schema_of_the_file(df_name_aufk)
# Call Function Delete rows null
df_name_aufk = delete_null_rows(df_name_aufk)
# -----------------------------------------------------------------------------------
## Renaming headers AFPO - Master Data SAP Item Work Order
# Call function Check Header files
check_schema_of_the_file(df_name_afpo)
# Call Function Delete rows null
df_name_afpo = delete_null_rows(df_name_afpo)

df_names_all = df_name_afko.unionByName(df_name_aufk).unionByName(df_name_afpo)

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_join_end, df_names_all
)
# Call Funtion Create Columns on Date format
df_work_order_clean = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_names_all
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 5 - Cleansing raw data

# COMMAND ----------

# Formatting Material_Number without '0' on left side
df_work_order_format = df_work_order_clean.withColumn(
    "Material_Number", f.regexp_replace(df_work_order_clean.Material_Number, "^0+", "")
)
# Formatting WO_Number without '0' on left side
df_work_order_format = df_work_order_format.withColumn(
    "WO_Number", f.regexp_replace(df_work_order_format.WO_Number, "^0+", "")
)
# Formatting Profit_Center without '0' on left side
df_work_order_format = df_work_order_format.withColumn(
    "Profit_Center", f.regexp_replace(df_work_order_format.Profit_Center, "^0+", "")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 6 - Optimize order of Columns

# COMMAND ----------

first_cols = ["WO_Number", "AFPO_posnr", "Start_Validity"]
df_history_stacked = move_dataframe_cols_first(df_work_order_format, first_cols)

# COMMAND ----------

# MAGIC %md
# MAGIC # Persist result

# COMMAND ----------

if RUN_JOB_ON_LATEST == False:
    df_history_stacked.persist()
    df_afko.unpersist()
    df_afpo.unpersist()
    df_aufk_filtered.unpersist()

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - Uniqueness
# MAGIC
# MAGIC N/A

# COMMAND ----------

### Quality checks on the stacked table takes too long

# # Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
# dfgx_In1_prep = SparkDFDataset(df_history_stacked, persist=False)

# # Define the red quality checks
# table_dest_pk_cols_list = TABLE_DEST_STACK_PK_COLS.split(",")
# red_quality_check_results = [
#     dfgx_In1_prep.expect_compound_columns_to_be_unique(
#         column_list=table_dest_pk_cols_list
#     )
# ]

# # Validate all red quality checks, if at least one fails the job stops
# gx_validation.validate_and_log_gx_results(
#     quality_check_results=red_quality_check_results,
#     validation_level="RED",
#     info_message=f"Compound cols {TABLE_DEST_STACK_PK_COLS} are unique",
#     error_message=f"Compound cols {TABLE_DEST_STACK_PK_COLS} are not unique, check the summary of this run",
# )

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Silver Stacked WO history

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver History Stacked Table

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by TABLE_DEST_STACK_CLUSTER_COLS
if not EMPTY_DATAFRAME_FLAG:
    catalog, schema, table = TABLE_DEST_STACK.split(".")

    try:
        table_utils.create_unity_catalog_table(
            catalog,
            schema,
            table,
            force_reinitialization=False,
            cluster_cols=TABLE_DEST_STACK_CLUSTER_COLS,
            partition_col=None,
            primary_key_cols=None,
            columns=TABLE_DEST_STACK_FIRST_COLS,
            force_drop=False,
        )
    except AnalysisException as e:
        log.error(
            f"Table {TABLE_DEST_STACK} has not been created, an error occured during creation. \nError is {e}"
        )
        raise Exception()

# COMMAND ----------

# Save the table from Dataframe df_history_stacked, preserving cluster columns
if not EMPTY_DATAFRAME_FLAG:
    try:
        startTime = time.time()
        table_utils.save_table(
            dest_table=TABLE_DEST_STACK,
            df=df_history_stacked,
            mode=MODE,
            overwrite_schema=True,
            cluster_cols=TABLE_DEST_STACK_CLUSTER_COLS,
        )
    except AnalysisException as e:
        log.error(
            f"Table {TABLE_DEST_STACK} has not been created, an error occured during saveAsTable. \nError is {e}"
        )
        raise Exception()
    else:
        duration = time.time() - startTime
        log.info(f"Table {TABLE_DEST_STACK} saved in {duration} seconds.")
        log.info(f"Wrote {df_history_stacked.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations for history changelog
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read existing history changelog

# COMMAND ----------

if (
    (table_utils.UnityCatalogCheckTableExists(TABLE_DEST_HCL))
    and (RUN_JOB_ON_LATEST == True)
    and (RUN_CHANGELOG_ON_LATEST == True)
):
    log.info(f"Reading current History Changelog table.")
    # Upload Silver Work Order History filtered on valid records
    df_work_order_silver_hist = spark.read.table(f"{TABLE_DEST_HCL}")
    log.debug(
        f"Current history changelog to update count {df_work_order_silver_hist.count()} rows."
    )
else:
    log.info(f"Reading current History Stacked table.")
    df_work_order_silver_hist = None
    # Upload Silver Work Order History stacked
    df_history_stacked = spark.read.table(f"{TABLE_DEST_STACK}")
    df_history_stacked.persist()
    RUN_CHANGELOG_ON_LATEST = False

# COMMAND ----------

# MAGIC %md
# MAGIC ## History changelog tracked columns list

# COMMAND ----------

prefixes = ["AFKO", "AFPO", "AUFK"]
metadata_columns = [
    "file_name",
    "file_mode",
    "table_name",
    "file_modification_time",
    "ingestion_timestamp",
    "extraction_timestamp",
    "stack_row_id",
    "ID",
]
all_metadata_columns = [
    f"{prefix}_{column}" for prefix in prefixes for column in metadata_columns
] + metadata_columns

all_table_cols = df_history_stacked.columns
validity_cols = ["Start_Validity", "End_Validity"]
prefixed_cols = [
    column
    for column in all_table_cols
    if (any(column.startswith(f"{prefix}_") for prefix in prefixes))
]
forced_included_cols = [
    "AUFK_loekz",
    "AFPO_elikz",
    "AUFK_idat2",
    "AUFK_idat3",
    "AFKO_zpp_statu",
]
tracked_column_list = [
    column
    for column in all_table_cols
    if (column not in TABLE_DEST_HCL_PK_COLUMNS_LIST)
    and (column not in all_metadata_columns)
    and (column not in validity_cols)
    and (not column.startswith("_meta"))
    and (column not in prefixed_cols)
] + forced_included_cols

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calculate History changelog

# COMMAND ----------

df_history_stacked_meta = df_history_stacked.withColumn(
    "_meta_sort_column", f.col("Start_Validity")
).drop("Start_Validity")

if (
    (table_utils.UnityCatalogCheckTableExists(TABLE_DEST_HCL))
    and (RUN_JOB_ON_LATEST == True)
    and (RUN_CHANGELOG_ON_LATEST == True)
):
    log.info(f"Processing update of the History Changelog table.")
    df_work_order_silver_hist = df_work_order_silver_hist.withColumn(
        "_meta_sort_column", f.col("Start_Validity")
    )

    df_history_changelog = history_changelog.calculate_history_changelog_delta_update(
        df=df_history_stacked_meta,
        df_existing_history_changelog=df_work_order_silver_hist,
        id_column_list=TABLE_DEST_HCL_PK_COLUMNS_LIST,
        sort_column="_meta_sort_column",
        tracked_column_list=tracked_column_list,
        data_extraction_mode="FULL",
        calculate_discontinuities=False,
    )

    df_history_changelog = table_utils.drop_duplicates_by_order(
        df=df_history_changelog,
        columns=TABLE_DEST_HCL_SK_COLUMNS_LIST,
        order_col="End_Validity",
        keep="last",
    )
else:
    log.info(f"Processing initialization of the History Changelog table.")
    df_history_changelog = history_changelog.initialize_history_changelog(
        df=df_history_stacked_meta,
        id_column_list=TABLE_DEST_HCL_PK_COLUMNS_LIST,
        sort_column="_meta_sort_column",
        tracked_column_list=tracked_column_list,
        data_extraction_mode="FULL",
        calculate_discontinuities=False,
    )

log.debug(f"History changelog count {df_history_stacked.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optimize order of Columns

# COMMAND ----------

first_cols = [
    "WO_Number",
    "Start_Validity",
    "End_Validity",
    "Material_Number",
    "WBS_Element",
    "Company",
    "Plant",
    "Location",
    "Profit_Center",
    "WO_Description",
    "Creation_Date",
    "Customers_Orders",
    "Customers_Orders_Item",
]
df_history_changelog_ordered_cols = move_dataframe_cols_first(
    df_history_changelog, first_cols
)

# COMMAND ----------

# Replace "1900-01-01" by _meta_min_extraction_date
df_history_changelog_start = df_history_changelog_ordered_cols.withColumn(
    "Start_Validity",
    f.when(
        f.col("Start_Validity") == "1900-01-01", f.col("_meta_min_extraction_date")
    ).otherwise(f.col("Start_Validity")),
)

# Drop _meta column "_meta_sort_column" , others _meta are usefull
strings_to_drop = [
    "_meta_sort_column",
]

columns_to_drop = [
    col_name
    for col_name in df_history_changelog_start.columns
    if any(substring.lower() in col_name.lower() for substring in strings_to_drop)
]
df_history_changelog_final = df_history_changelog_start.drop(*columns_to_drop)

# COMMAND ----------

# MAGIC %md
# MAGIC #Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Silver WO history changelog

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver history changelog table

# COMMAND ----------

if (
    (table_utils.UnityCatalogCheckTableExists(TABLE_DEST_HCL))
    and (RUN_JOB_ON_LATEST == True)
    and (RUN_CHANGELOG_ON_LATEST == True)
):
    if not EMPTY_DATAFRAME_FLAG:
        # MERGE df_history_changelog_final INTO TABLE_DEST_HCL using columns of the SURROGATE KEY ("WO_Number","AFPO_posnr","Start_Validity")
        #       WHEN MATCHED AND (source.End_Validity <> target.End_Validity) THEN
        #           UPDATE SET *
        #       WHEN NOT MATCHED THEN
        #           INSERT *
        log.info(f"Merging new History Changelog into table.")
        log.debug(
            f"Data to merge into history count {df_history_changelog_final.count()} rows."
        )
        startTime = time.time()
        try:
            table_utils.merge_into(
                df_source=df_history_changelog_final,
                target_table=TABLE_DEST_HCL,
                list_id_matching_columns=TABLE_DEST_HCL_SK_COLUMNS_LIST,
                matched_clause="(source.End_Validity <> target.End_Validity) or (source._meta_max_extraction_date <> target._meta_max_extraction_date)",
            ).display()
        except Exception as e:
            log.error(
                f"Table {TABLE_DEST_HCL} has not been created, an error occured during MERGE INTO."
            )
            all_target_cols = [
                x[0]
                for x in spark.sql(f"DESCRIBE {TABLE_DEST_HCL}")
                .select("col_name")
                .collect()
            ]
            log.error(f"Dataframe cols : {df_history_changelog_final.columns}\n----\n")
            log.error(f"Tables cols : {all_target_cols}\n----\n")
            log.error(f"Error : {e}")
            raise Exception()
        else:
            duration = time.time() - startTime
            log.info(f"Table {TABLE_DEST_HCL} merged in {duration} seconds.")
    else:
        log.info(f"No change to Merge.")
else:
    log.info(f"Saving new History Changelog table.")
    try:
        table_utils.save_table(
            dest_table=TABLE_DEST_HCL,
            df=df_history_changelog_final,
            mode="overwrite",
            overwrite_schema=True,
            cluster_cols=TABLE_DEST_HCL_CLUSTER_COLS_STR,
        )
    except Exception as e:
        log.error(
            f"Table {TABLE_DEST_HCL} has not been created, an error occured during save."
        )
        log.error(f"Error : {e}")
        raise Exception()
    else:
        log.info(
            f"Data saved into history count {df_history_changelog_final.count()} rows."
        )

# COMMAND ----------

ANALYZE_TABLE_SQL = f"ANALYZE TABLE {TABLE_DEST_HCL} COMPUTE STATISTICS"
spark.sql(ANALYZE_TABLE_SQL)
