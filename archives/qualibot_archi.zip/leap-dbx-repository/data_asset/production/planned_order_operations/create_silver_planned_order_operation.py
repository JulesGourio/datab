# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE SILVER PLANNED ORDER OPERATIONS
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the silver table on planned order operations, i.e. item of planned order header (already existing gold table). Therefore, the goal of this DA is to provide relevant information relative to the operations, such as time and planning.  
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Planned order operations - SAP
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.kbed_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_kbed
# MAGIC - {REFERENCE_READ_ENV}_gold.production.planned_orders_sap_exposed
# MAGIC
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.production.planned_order_operation

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ##Config Standard Imports

# COMMAND ----------

import pyspark.sql.functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ##Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("min_year", "2022")
MIN_YEAR = int(dbutils.widgets.get("min_year"))

# COMMAND ----------

# MAGIC %md
# MAGIC #Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Inputs - LEAP tables

# COMMAND ----------

df_kbed_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.kbed_latest"
)

# COMMAND ----------

df_header_kbed_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_kbed"
)

# COMMAND ----------

df_planned_order_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.production.planned_orders_sap_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Inputs - Manual declaration

# COMMAND ----------

PLANNED_OPE_SILVER_SAP_TABLE = (
    f"{PIPELINE_WRITE_ENV}_silver.production.planned_order_operation"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep1 - Exclude simulation MRP entries

# COMMAND ----------

df_kbed_prep = df_kbed_raw.where(f.col("plscn") == "000")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep2 - Renaming columns

# COMMAND ----------

df_kbed_prep = table_utils.add_prefix_to_columns(df_kbed_prep, "kbed")

# COMMAND ----------

df_pl_ope_prep = table_utils.rename_columns_with_sap_business_header(
    df_kbed_prep, df_header_kbed_raw
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep3 - Planned order (header)

# COMMAND ----------

df_planned_order_prep = df_planned_order_raw.drop("unit")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep4 - Date formatting 

# COMMAND ----------

df_pl_ope_prep = (
    df_pl_ope_prep.withColumn(
        "earliest_scheduled_start_date",
        f.to_date(f.col("earliest_scheduled_start_date"), "yyyyMMdd"),
    )
    .withColumn(
        "last_scheduled_start_date",
        f.to_date(f.col("last_scheduled_start_date"), "yyyyMMdd"),
    )
    .withColumn(
        "last_scheduled_end_date",
        f.to_date(f.col("last_scheduled_end_date"), "yyyyMMdd"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep5 - Cleaning

# COMMAND ----------

df_pl_ope_prep = table_utils.remove_leading_zeros(
    df_pl_ope_prep, ["planned_operation", "planned_order_number"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Planned operation table
# MAGIC Remove machine time config in the SAP table

# COMMAND ----------

agg_cols = [
    "preparation_allocated_time",
    "main_allocated_time",
    "disassembly_time"
]

# Convert each agg_col to hours before aggregation
for col in agg_cols:
    df_pl_ope_prep = df_pl_ope_prep.withColumn(
        f"{col}_in_hrs",
        f.when(f.col("time_unit").isin(["H", "STD"]), f.col(col))
         .when(f.col("time_unit") == "MIN", f.col(col) / 60)
         .otherwise(None)
    )

agg_exprs = [f.sum(f.col(f"{c}_in_hrs")).alias(f"{c}_in_hrs") for c in agg_cols]

group_cols = [
    c for c in df_pl_ope_prep.columns
    if c not in agg_cols + [f"{c}_in_hrs" for c in agg_cols] + ["kbed_canum"] and not c.startswith("kbed")
]

df_pl_ope_prep = (
    df_pl_ope_prep
    .groupBy("planned_order_number", "planned_operation", *[c for c in group_cols if c not in ["planned_order_number", "planned_operation", "time_unit"]])
    .agg(*agg_exprs)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr2 - Remove old data

# COMMAND ----------

df_pl_ope_tr = df_pl_ope_prep.where(f.col("planned_order_number").isNotNull()).where(
    f.year("earliest_scheduled_start_date") > MIN_YEAR
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr3 - Join with header

# COMMAND ----------

df_pl_ope_tr = df_pl_ope_tr.join(
    df_planned_order_prep, ["planned_order_number"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr4 - Calculation of the total allocated time

# COMMAND ----------

df_pl_ope_tr = df_pl_ope_tr.withColumn(
    "allocated_time_in_hrs",
    f.col("preparation_allocated_time_in_hrs")
    + f.col("main_allocated_time_in_hrs")
    + f.col("disassembly_time_in_hrs"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(PLANNED_OPE_SILVER_SAP_TABLE, df_pl_ope_tr, "overwrite")