# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE GOLD PLANNED ORDER OPERATIONS
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the gold table on planned order operations, i.e. item of planned order header (already existing gold table). Therefore, the goal of this DA is to provide relevant information relative to the operations, such as time and planning.  
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Planned order operations - SAP
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {PIPELINE_READ_ENV}_silver.production.planned_order_operation
# MAGIC - {REFERENCE_READ_ENV}_gold.production.workcenter_exposed
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.production.planned_order_operation
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ##Config Standard Imports

# COMMAND ----------

import pyspark.sql.functions as f

from leap_utils.data_asset import table_utils
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Inputs - LEAP tables

# COMMAND ----------

df_workcenter = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.production.workcenter_exposed"
)

# COMMAND ----------

df_pl_ope = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.production.planned_order_operation"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Inputs - Manual declaration

# COMMAND ----------

PLANNED_OPE_GOLD_SAP_TABLE = (
    f"{PIPELINE_WRITE_ENV}_gold.production.planned_order_operation"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep1 - Workcenter table

# COMMAND ----------

df_workcenter = df_workcenter.select(
    "workcenter_id", "workcenter_code", "plant", "workcenter"
).distinct()

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Get workcenter information

# COMMAND ----------

df_pl_ope = df_pl_ope.join(df_workcenter, ["workcenter_id", "plant"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Profit center formatting

# COMMAND ----------

df_pl_ope = df_pl_ope.withColumn(
    "profit_center_code_desc",
    f.concat_ws("-", f.col("profit_center"), f.col("profit_center_description")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr3 - Create ID column

# COMMAND ----------

df_pl_ope = df_pl_ope.withColumn(
    "PO_operation_ID",
    f.concat_ws("-", f.col("planned_order_number"), f.col("planned_operation")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr4 - Plant 1000 affectation

# COMMAND ----------

df_pl_ope = df_pl_ope.withColumn(
        "site",
        f.when(
            (f.col("plant") == "1000") & (f.col("MRP_controller").startswith("O")),
            "LATE - Montredon",
        )
        .when(f.col("plant") == "1000", "LATE - Gimont")
        .otherwise(f.col("site")),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality Checks 

# COMMAND ----------

pk_col = "PO_operation_ID"
columns = df_pl_ope.columns
columns.remove(pk_col)
new_column_order = [pk_col] + columns
df_pl_ope = df_pl_ope.select(new_column_order)

# COMMAND ----------

df_to_check = df_pl_ope
validation_level = "RED"
df_gx_final = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx_final.expect_column_values_to_not_be_null(column=pk_col),
    df_gx_final.expect_column_values_to_be_unique(column=pk_col),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All checks inspection",
    error_message="Quality checks failed for work order operation table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="work_order_operation",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(PLANNED_OPE_GOLD_SAP_TABLE, df_pl_ope, "overwrite")

# COMMAND ----------

begin_by = "kbed"

selected_columns = [col for col in df_pl_ope.columns if not col.startswith(begin_by)]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    PLANNED_OPE_GOLD_SAP_TABLE,
    f"{PLANNED_OPE_GOLD_SAP_TABLE}_exposed",
    select_statement,
    replace_view=True,
)
