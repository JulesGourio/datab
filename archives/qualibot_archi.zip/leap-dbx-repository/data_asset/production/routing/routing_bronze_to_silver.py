# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Production version bronze to silver
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC
# MAGIC In SAP, a routing defines the sequence of operations required to manufacture a product, specifying the work centers, durations, and tools needed at each step of the production process.
# MAGIC
# MAGIC In this notebook, we work with three key routing-related tables — PLKO (routing header), PLPO (routing operations), and PLAS (routing-sequence assignments) — which we link together to reconstruct the full structure of a routing.
# MAGIC
# MAGIC In this notebook:
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC
# MAGIC - 
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.plpo_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.plko_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.plas_latest
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.production.routing

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ## 📄 SAP Table: PLKO — Task List Header
# MAGIC
# MAGIC | Element        | Description                                                                 |
# MAGIC |----------------|-----------------------------------------------------------------------------|
# MAGIC | **Role**       | Contains general information about the routing (header)                     |
# MAGIC | **Keys**       | `PLNTY` (Task List Type), `PLNNR` (Task List Number), `PLNAL` (Group Counter) |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 📄 SAP Table: PLPO — Task List Operations
# MAGIC
# MAGIC | Element        | Description                                                                 |
# MAGIC |----------------|-----------------------------------------------------------------------------|
# MAGIC | **Role**       | Contains the list of operations within the routing                          |
# MAGIC | **Keys**       | `PLNTY`, `PLNNR`, `PLNKN` (Operation Key), `PLNAL`                          |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 📄 SAP Table: PLAS — Task List Sequence Assignment
# MAGIC
# MAGIC | Element        | Description                                                                 |
# MAGIC |----------------|-----------------------------------------------------------------------------|
# MAGIC | **Role**       | Defines alternative or parallel sequences within routings                   |
# MAGIC | **Keys**       | `PLNTY`, `PLNNR`, `PLNAL`, `ZAEHL` (Sequence Number)                        |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 📄 SAP Table: MAPL — Assignment of Task List to Material
# MAGIC
# MAGIC | Element        | Description                                                                 |
# MAGIC |----------------|-----------------------------------------------------------------------------|
# MAGIC | **Role**       | Links a routing (PLKO) to a material (`MATNR`)                              |
# MAGIC | **Keys**       | `MATNR` (Material), `WERKS`, `PLNTY`, `PLNNR`, `PLNAL`                      |
# MAGIC
# MAGIC

# COMMAND ----------

df_routing_head = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.plko_latest"
)
df_routing_body = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.plpo_latest"
)
df_join = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.plas_latest"
).select(
    f.col("PLNTY").alias("task_list_type"), 
    f.col("PLNNR").cast("string").alias("task_list_number"), 
    f.col("PLNAL").cast("string").alias("task_list_group_counter"),
    f.col("PLNKN").cast("string").alias("task_list_node"),
    f.col("LOEKZ").alias("delete_indicator")
)

df_mat_task_list_assignement = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mapl_latest"
).select(
    f.col("MATNR").alias("material_number"),
    f.col("WERKS").alias("plant"),
    f.col("PLNTY").alias("task_list_type"),
    f.col("PLNNR").alias("task_list_number"),
    f.col("PLNAL").alias("task_list_group_counter"),
    f.col("ZKRIZ")
).filter(f.col("ZKRIZ")=="0000001").drop("ZKRIZ")

df_routing_head_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_plko"
)
df_routing_body_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_plpo"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data preparation - 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Rename, clean and format columns
# MAGIC

# COMMAND ----------

df_routing_head_prefix = table_utils.add_prefix_to_columns(
    df_routing_head, "PLKO"
)
table_utils.check_schema_of_the_header_file(df_routing_head_headers)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_routing_head_prefix, df_routing_head_headers
)
df_routing_head_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_routing_head_headers
).drop_duplicates(["task_list_type", "task_list_number", "task_list_group_counter"])


# COMMAND ----------

df_routing_body_prefix = table_utils.add_prefix_to_columns(
    df_routing_body, "PLPO"
)
table_utils.check_schema_of_the_header_file(df_routing_body_headers)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_routing_body_prefix, df_routing_body_headers
)
df_routing_body_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_routing_body_headers
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Join PLKO, PLAS, PLPO and MAPL
# MAGIC
# MAGIC **Why this join order matters:**
# MAGIC
# MAGIC - PLKO (header) gives us the routing definition and metadata.
# MAGIC
# MAGIC - PLAS provides the structure of operation sequences, including parallel or alternative paths.
# MAGIC
# MAGIC - PLPO contains the actual operations performed in the routing.
# MAGIC
# MAGIC - MAPL is the only table that links a routing to a material number, which is essential for connecting routings to specific products in production or planning.

# COMMAND ----------

df_prepared_routing = (
    df_routing_head_renamed.join(
        df_join,
        on=["task_list_type", "task_list_number", "task_list_group_counter"],
        how="left",
    )
    .filter(f.col("delete_indicator").isNull())
    .drop("delete_indicator")
)

df_routing_w_mat = df_prepared_routing.join(
    df_mat_task_list_assignement,
    on=["plant", "task_list_type", "task_list_number", "task_list_group_counter"],
    how="left",
)

df_routing = df_routing_w_mat.join(
    df_routing_body_renamed,
    ["task_list_type", "task_list_number", "task_list_node", "plant"],
    "left",
)

# COMMAND ----------

# take last version of each "Task_List_Type", "Task_List_Number", "Task_List_group_Counter", "operation"
partition_cols = ["task_list_type", "task_list_number", "task_list_group_counter", "operation"]
w = Window.partitionBy(*partition_cols).orderBy(f.desc("changed_on"))
df_latest_routing = df_routing.withColumn("rn", f.row_number().over(w)).filter(f.col("rn") == 1).drop("rn")


# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "production"
table = "routing"

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}", df=df_latest_routing, mode="overwrite"
)

# COMMAND ----------


