# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Production version silver to gold
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC
# MAGIC In SAP, a routing defines the sequence of operations required to manufacture a product, specifying the work centers, durations, and tools needed at each step of the production process.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {PIPELINE_READ_ENV}_silver.production.routing
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.production.routing

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------


from leap_utils.data_asset import table_utils

from leap_utils.common.validation import gx_validation


# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### DF production version silver

# COMMAND ----------

df_routing = spark.read.table(f"{PIPELINE_READ_ENV}_silver.production.routing")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data preparation
# MAGIC
# MAGIC Create business key bom_number / item_number / material_number

# COMMAND ----------

df_silver_business = df_routing.withColumn(
    "business_id",
    f.concat_ws(
        "_",
        f.col("task_list_type"),
        f.col("task_list_number"),
        f.col("task_list_group_counter"),
        f.col("operation"),
        # f.col("task_list_counter")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks
# MAGIC
# MAGIC
# MAGIC **Data Type Check:**
# MAGIC
# MAGIC created_on and changed_on Columns: We checked that these columns are of the date type to ensure that date-related operations can be performed accurately.
# MAGIC Labor_time, Cycle_Time, Machine_time, Set_UP and Process_Improvement: We checked that these columns are of the double type.
# MAGIC
# MAGIC **Unicity Check**
# MAGIC
# MAGIC business_id needs to be unique

# COMMAND ----------

# Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
dfgx = gx.dataset.SparkDFDataset(df_silver_business, persist=False)

# Define the red quality checks here
red_quality_check_results = [
    dfgx.expect_column_values_to_be_of_type(column="created_on", type_="DateType"),
    dfgx.expect_column_values_to_be_of_type(column="changed_on", type_="DateType"),
    dfgx.expect_column_values_to_be_of_type(column="set_up", type_="DoubleType"),
    dfgx.expect_column_values_to_be_of_type(column="labor_time", type_="DoubleType"),
    dfgx.expect_column_values_to_be_of_type(column="cycle_time", type_="DoubleType"),
    dfgx.expect_column_values_to_be_of_type(column="machine_time", type_="DoubleType"),
    dfgx.expect_column_values_to_be_of_type(
        column="process_improvement", type_="DoubleType"
    ),
    dfgx.expect_column_values_to_be_unique(column="business_id"),
]

# Validate all red quality checks, if at least one fails the job stops
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="Quality Checks passed for BOM table - RED",
    error_message="Quality checks failed for BOM table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="routing_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "production"
table = "routing"

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}", df=df_silver_business, mode="overwrite"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Table production_version_exposed

# COMMAND ----------

select_statement = ", ".join(
    c
    for c in df_silver_business.columns
    if not (c.startswith("PLPO") or c.startswith("PLKO"))
)

table_utils.create_table_view(
    src_full_tablename=f"{catalog}.{domain}.{table}",
    dest_full_tablename=f"{catalog}.{domain}.{table}_exposed",
    select_statement=select_statement,
    replace_view=True,
)

# COMMAND ----------
