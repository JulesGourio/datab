# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a Gold & Gold exposed table for Planned Order Production    
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_gold.production.sap_planned_order_latest
# MAGIC   - {WRITE_ENV}_gold.production.sap_planned_order_latest_exposed
# MAGIC
# MAGIC **Intput :**  
# MAGIC   - {READ_ENV}silver.production.sap_planned_order_latest
# MAGIC   - {READ_ENV}_gold.finance.wbs_otp  
# MAGIC   - {READ_ENV}_gold.master_data.material_master_data_plant_exposed 
# MAGIC   - {READ_ENV}_gold.master_data.plant_master_data_latest_exposed
# MAGIC
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Notebook create_silver_planned_order_basics_daily
# MAGIC
# MAGIC **Things performed in this notebook:** 
# MAGIC - Add WBS Coding
# MAGIC - Add Material Master Data
# MAGIC - Add plant and company information
# MAGIC - Save Gold Table

# COMMAND ----------

import logging
import time

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql import Window
from pyspark.sql.utils import AnalysisException
from leap_utils.data_asset import table_utils, history_changelog

from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.ingestion import ingestion_utils

LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")
# Get READ_TEMP environment variable
dbutils.widgets.text("ENV", "dev")
ENV = dbutils.widgets.get("ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Silver Work Order Table

# COMMAND ----------

# Upload Planned Order silver Table
df_planned_order = spark.read.table(
    f"{ENV}_silver.production.sap_planned_order_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Enrichment Gold

# COMMAND ----------

# MAGIC %md 
# MAGIC ##Management of WBS coding

# COMMAND ----------

## We use Gold Table WBS to translate WBS_Code_Num to Business WBS_Code
# Upload WBS Gold Table
df_otp = (spark.read.table(f"{READ_ENV}_gold.finance.wbs_otp")
                          .select("WBS_Code_Num", "WBS_Code")
                          .withColumnRenamed("WBS_Code_Num","WBS_Element")
)

# Join WBS description on Planned Order Table
df_planned_order_wbs = (df_planned_order.join(df_otp,["WBS_Element"],"left")
                    .drop("WBS_Element")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add Material Master information

# COMMAND ----------

# Upload Gold Master Data Material by plant
df_material = ( spark.read.table(f"{READ_ENV}_gold.master_data.material_master_data_plant_exposed")
               .select("Material_Number","Plant","Profit_Center","Description")
               .withColumnRenamed("Description","Material_Number_Description")
               .dropDuplicates()
)

# Join with Planned Gold Table
df_planned_order_material = df_planned_order_wbs.join(df_material,["Material_Number","Plant"],"left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Add information for Plant Company and branch

# COMMAND ----------

# Upload Gold Master Data Plant
df_plant = (spark.read.table(f"{READ_ENV}_gold.master_data.plant_master_data_latest_exposed")
            .select("Plant", "Plant_Description_new")
            .withColumnRenamed("Plant_Description_new", "Production_Site")
)

# Join Plant description on Planned Order Table
df_planned_order_plant = df_planned_order_material.join(df_plant,["Plant"],"left")

# Dispatch Production Site for Plant 1000 (Gimont/Montredon/DES)
df_planned_order_site = df_planned_order_plant.withColumn(
    "Production_Site",
    f.when(f.col("Plant") != "1000", f.col("Production_Site"))
    .when(f.substring(f.col("Mrp_Controller"), 1, 1) == "O", f.lit("LFR-Montredon"))
    .when(f.col("Mrp_Controller") == "DET", f.lit("LFR-DES"))
    .otherwise(f.lit("LFR-Gimont")),
)
# Determination Branch AS / IS
df_planned_order_branch = df_planned_order_site.withColumn(
    "Branch",
    f.when(
        (f.col("Production_Site") == "LFR-DES") | (f.substring(f.col("Plant"), 0, 1) == "2"),
        f.lit("IS"),
    ).otherwise(f.lit("AS")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "production"
table = "sap_planned_order_latest"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_planned_order_branch,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold Latest exposed table

# COMMAND ----------

catalog = "gold"
domain = "production"
table = "sap_planned_order_latest"
src_full_tablename = f"{WRITE_ENV}_{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "PLAF"

selected_columns = [
    col
    for col in df_planned_order_branch.columns
    if not col.startswith(Begin_By) 
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold HistoryChangeLog table

# COMMAND ----------

columns_to_exclude = [
    'PLAF_stack_row_id',
    'PLAF_ID',
    'PLAF_extraction_timestamp',
    'PLAF_ingestion_timestamp',
    'PLAF_file_name',
    'PLAF_file_mode',
    'PLAF_table_name',
    'PLAF_file_modification_time'
]

columns_to_watch = list(df_planned_order_branch.columns)

for col in columns_to_exclude:
    if col in columns_to_watch:
        columns_to_watch.remove(col)

# COMMAND ----------

def process_table(table_name: str, df_table_stack: DataFrame, df_last: DataFrame) -> str:
    """
    process ingestion of a table
    return {output_table_path} if ok, or None if not
    """
    startTime = time.time()

    # get the first_existing_timestamp_of_extraction
    first_existing_timestamp_of_extraction_in_stack = df_table_stack.select(
        f.min("PLAF_extraction_timestamp")
    ).first()["min(PLAF_extraction_timestamp)"]
    log.info(
        f"the first timestamp in Stack table is : {first_existing_timestamp_of_extraction_in_stack}"
    )

    # get the last_existing_timestamp_of_extraction
    last_existing_timestamp_of_extraction_in_stack = df_last.select(
        f.max("PLAF_extraction_timestamp")
    ).first()["max(PLAF_extraction_timestamp)"]
    log.info(
        f"the last timestamp in Stack table is : {last_existing_timestamp_of_extraction_in_stack}"
    )

    if (
        table_utils.UnityCatalogCheckTableExists(table_name)
    ):
        log.info(
            f"Computing the DELTA history changelog table {table_name}"
        )

        # Read existing history_change_log_table
        df_table_history = spark.read.table(table_name)

        # get the last_existing_timestamp in history_change_log_table
        last_existing_timestamp_in_history_change_log = df_table_history.select(
            f.max("PLAF_extraction_timestamp")
        ).first()["max(PLAF_extraction_timestamp)"]

        log.info(
            f"the last timestamp in history changelog table is : {last_existing_timestamp_in_history_change_log}"
        )

        # Do processing only if changes are detected in stack
        if (
            last_existing_timestamp_of_extraction_in_stack
            > last_existing_timestamp_in_history_change_log
        ):

            # Filter stack table with needed extraction_timestamps
            df_table_stack_from_last_run_to_current_date = df_last

            df_history_final = history_changelog.calculate_history_changelog_delta_update(
                df=df_table_stack_from_last_run_to_current_date,
                df_existing_history_changelog=df_table_history,
                id_column_list=["Planned_Order_Number"],
                sort_column="PLAF_extraction_timestamp",
                tracked_column_list=columns_to_watch,
                data_extraction_mode="FULL",
                calculate_discontinuities=False,
                # allow_duplicate=True,
            )

        else:
            log.info(f"the table {table_name} is already up to date")
            return f"{table_name}"

    else:
        # Below the computation of the full history table
        raise Exception(
            f"You need to initialize history first with data_asset/production/planned_order/INIT_create_silver_planned_order_history notebook"
        )

        df_history_final = history_changelog.initialize_history_changelog(
            df=df_table_stack,
            id_column_list=["Planned_Order_Number"],
            sort_column="PLAF_extraction_timestamp",
            tracked_column_list=columns_to_watch,
            data_extraction_mode="FULL",
            calculate_discontinuities=False,
        )

    # Save history table
    try:
        result = table_utils.save_table(
            dest_table=table_name,
            df=df_history_final,
            mode="overwrite",
            overwrite_schema=True,
            merge_schema=True,
        )
    except AnalysisException as e:
        log.error(
            f"Table {table_name} has not been created, an error occured during creation."
        )
    else:
        duration = time.time() - startTime
        log.info(
            f"Table {table_name} created in {duration} seconds."
        )

# COMMAND ----------

process_table(
    table_name=f"{WRITE_ENV}_gold.production.sap_planned_order_history",
    df_table_stack=spark.read.table(
        f"{ENV}_gold.production.sap_planned_order_history"
    ),
    df_last=df_planned_order_branch,
)
