# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to initialize with silver table the gold Gold & Gold exposed table for Planned Order Production history  
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_gold.production.sap_planned_order_latest
# MAGIC   - {WRITE_ENV}_gold.production.sap_planned_order_latest_exposed
# MAGIC
# MAGIC **Intput :**  
# MAGIC   - {READ_ENV}silver.production.sap_planned_order_history_change_log
# MAGIC   - {READ_ENV}_gold.finance.wbs_otp  
# MAGIC   - {READ_ENV}_gold.master_data.material_master_data_plant_exposed 
# MAGIC   - {READ_ENV}_gold.master_data.plant_master_data_latest_exposed
# MAGIC
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Notebook create_silver_planned_order_basics_daily
# MAGIC
# MAGIC **Things performed in this notebook:** 
# MAGIC - Add WBS Coding
# MAGIC - Add Material Master Data
# MAGIC - Add plant and company information
# MAGIC - Save Gold Table

# COMMAND ----------

from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "dev")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")
# Get READ_TEMP environment variable
dbutils.widgets.text("ENV", "dev")
ENV = dbutils.widgets.get("ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Silver Work Order Table

# COMMAND ----------

# Upload Planned Order silver Table
df_planned_order = spark.read.table(
    f"{ENV}_silver.production.sap_planned_order_history_change_log"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Enrichment Gold

# COMMAND ----------

# MAGIC %md 
# MAGIC ##Management of WBS coding

# COMMAND ----------

## We use Gold Table WBS to translate WBS_Code_Num to Business WBS_Code
# Upload WBS Gold Table
df_otp = (spark.read.table(f"{READ_ENV}_gold.finance.wbs_otp")
                          .select("WBS_Code_Num", "WBS_Code")
                          .withColumnRenamed("WBS_Code_Num","WBS_Element")
)

# Join WBS description on Planned Order Table
df_planned_order_wbs = (df_planned_order.join(df_otp,["WBS_Element"],"left")
                    .drop("WBS_Element")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add Material Master information

# COMMAND ----------

# Upload Gold Master Data Material by plant
df_material = ( spark.read.table(f"{READ_ENV}_gold.master_data.material_master_data_plant_exposed")
               .select("Material_Number","Plant","Profit_Center","Description")
               .withColumnRenamed("Description","Material_Number_Description")
               .dropDuplicates()
)

# Join with Planned Gold Table
df_planned_order_material = df_planned_order_wbs.join(df_material,["Material_Number","Plant"],"left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Add information for Plant Company and branch

# COMMAND ----------

# Upload Gold Master Data Plant
df_plant = (spark.read.table(f"{READ_ENV}_gold.master_data.plant_master_data_latest_exposed")
            .select("Plant", "Plant_Description_new")
            .withColumnRenamed("Plant_Description_new", "Production_Site")
)

# Join Plant description on Planned Order Table
df_planned_order_plant = df_planned_order_material.join(df_plant,["Plant"],"left")

# Dispatch Production Site for Plant 1000 (Gimont/Montredon/DES)
df_planned_order_site = df_planned_order_plant.withColumn(
    "Production_Site",
    f.when(f.col("Plant") != "1000", f.col("Production_Site"))
    .when(f.substring(f.col("Mrp_Controller"), 1, 1) == "O", f.lit("LFR-Montredon"))
    .when(f.col("Mrp_Controller") == "DET", f.lit("LFR-DES"))
    .otherwise(f.lit("LFR-Gimont")),
)
# Determination Branch AS / IS
df_planned_order_branch = df_planned_order_site.withColumn(
    "Branch",
    f.when(
        (f.col("Production_Site") == "LFR-DES") | (f.substring(f.col("Plant"), 0, 1) == "2"),
        f.lit("IS"),
    ).otherwise(f.lit("AS")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "production"
table = "sap_planned_order_history"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_planned_order_branch,
    mode="overwrite",
    overwrite_schema=True
)
