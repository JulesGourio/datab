# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to initialize a weekly silver history table for Planned Order History
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_silver.production.sap_planned_order_latest
# MAGIC
# MAGIC **Input :**  
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.plaf_latest
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_plaf
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC  - SAP Bronze Ingestion  
# MAGIC  
# MAGIC **Things performed in this notebook:** 
# MAGIC
# MAGIC - Cleaning data
# MAGIC - Renaming Headers  
# MAGIC - Keep only Production Planned Orders

# COMMAND ----------

import logging
import time

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql import Window
from pyspark.sql.utils import AnalysisException
from leap_utils.data_asset import table_utils, history_changelog

from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.ingestion import ingestion_utils

LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )

# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull())
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table and Renaming

# COMMAND ----------

# Upload PLAF <- Master Data SAP basics Work Planned Order
# We keep only production entries (exclusion Simulation 'plscn')
df_plaf = (spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.plaf_stack")
           .filter(f.col("plscn")=="000")
)

# Renaming // PLAFXXXX
df_plaf = table_utils.add_prefix_to_columns(df_plaf, "PLAF")

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming according Header files

# COMMAND ----------

## Renaming headers AFKO - Basic Master Data from SAP
df_name_plaf = spark.read.table("prod_bronze.headers_sap.headers_sap_business_plaf")
# Call function Check Header files
check_schema_of_the_file(df_name_plaf)
# Call Function Delete rows null
df_name_plaf = delete_null_rows(df_name_plaf)

# Call Function Rename Columns according header file
df_planned_order = table_utils.rename_columns_with_sap_business_header(
    df_plaf, df_name_plaf
)
# Call Function Create Columns on format according header file
df_planned_order_clean = table_utils.cast_columns_with_sap_business_headers(
    df_planned_order, df_name_plaf
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Cleaning raw data

# COMMAND ----------

# Formatting Material_Number without '0' on left side
df_planned_order_clean_format = df_planned_order_clean.withColumn(
    "Material_Number", f.regexp_replace(df_planned_order_clean.Material_Number, "^0+", "")
)
#Formatting WO_Number without '0' on left side
df_planned_order_clean_format = df_planned_order_clean_format.withColumn(
    "Planned_Order_Number", f.regexp_replace(df_planned_order_clean_format.Planned_Order_Number, "^0+", "")
)
# Formatting Profit_Center without '0' on left side
df_planned_order_clean_format = df_planned_order_clean_format.withColumn(
    "Reservation_Number", f.regexp_replace(df_planned_order_clean_format.Reservation_Number, "^0+", "")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Create history change log

# COMMAND ----------

columns_to_exclude = [
    'PLAF_stack_row_id',
    'PLAF_ID',
    'PLAF_extraction_timestamp',
    'PLAF_ingestion_timestamp',
    'PLAF_file_name',
    'PLAF_file_mode',
    'PLAF_table_name',
    'PLAF_file_modification_time',
    'PLAF_pstmp',
    'PLAF_puser'
]

columns_to_watch = list(df_planned_order_clean_format.columns)

for col in columns_to_exclude:
    if col in columns_to_watch:
        columns_to_watch.remove(col)

# COMMAND ----------

def process_table(table_name: str, df_table_stack: DataFrame) -> str:
    """
    process ingestion of a table
    return {output_table_path} if ok, or None if not
    """
    startTime = time.time()

    Unity_Catalog_Table_Name = f"{table_name.lower()}_history_change_log"

    # get the first_existing_timestamp_of_extraction
    first_existing_timestamp_of_extraction_in_stack = df_table_stack.select(
        f.min("PLAF_extraction_timestamp")
    ).first()["min(PLAF_extraction_timestamp)"]
    log.info(
        f"the first timestamp in Stack table is : {first_existing_timestamp_of_extraction_in_stack}"
    )

    # get the last_existing_timestamp_of_extraction
    last_existing_timestamp_of_extraction_in_stack = df_table_stack.select(
        f.max("PLAF_extraction_timestamp")
    ).first()["max(PLAF_extraction_timestamp)"]
    log.info(
        f"the last timestamp in Stack table is : {last_existing_timestamp_of_extraction_in_stack}"
    )
    log.info(
        f"Computing the FULL history changelog table {Unity_Catalog_Table_Name}"
    )

    df_history_final = history_changelog.initialize_history_changelog(
        df=df_table_stack,
        id_column_list=["Planned_Order_Number"],
        sort_column="PLAF_extraction_timestamp",
        tracked_column_list=columns_to_watch,
        data_extraction_mode="FULL",
        calculate_discontinuities=False,
    )
    
    # Save history table
    try:
        result = table_utils.save_table(
            dest_table=Unity_Catalog_Table_Name,
            df=df_history_final,
            mode="overwrite",
            overwrite_schema=True,
            merge_schema=True,
        )
    except AnalysisException as e:
        log.error(
            f"Table {Unity_Catalog_Table_Name} has not been created, an error occured during creation."
        )
    else:
        duration = time.time() - startTime
        log.info(
            f"Table {Unity_Catalog_Table_Name} created in {duration} seconds."
        )

# COMMAND ----------

catalog = f"{WRITE_ENV}_silver"
domain = "production"
table = "sap_planned_order"

process_table(table_name=f"{catalog}.{domain}.{table}", df_table_stack=df_planned_order_clean_format)
