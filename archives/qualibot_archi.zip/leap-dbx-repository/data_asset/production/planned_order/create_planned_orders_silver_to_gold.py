# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # GOLD PLANNED ORDERS
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC This data asset has been created to centralize and structure all relevant information related to SAP production orders.
# MAGIC The objective is to provide a trusted, historical, and unified view of manufacturing orders that can be reused across different analytical and reporting use cases.
# MAGIC
# MAGIC By consolidating data from LEAP GOLD Table Planned Order, Material, WBS, Profit Center,etc.. this dataset enables:
# MAGIC
# MAGIC 🔎 Tracking the lifecycle of planned orders.
# MAGIC
# MAGIC 📊 Analyzing planned order and manage workload.
# MAGIC
# MAGIC 🏭 Supporting manufacturing performance KPIs and operational reporting.
# MAGIC
# MAGIC 🔗 Providing a single source of truth for downstream consumers (dashboards, data science models, audits).
# MAGIC
# MAGIC This asset is part of the silver layer in the data pipeline, ensuring data is clean, incremental, and historically traceable.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Planned_Orders_Daily  
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC   - `{PIPELINE_READ_ENV}_silver.production.planned_orders_sap`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.manual_input.mapping_sites_division_region`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.manual_input.mapping_plant_site`  
# MAGIC   - `{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed`
# MAGIC   - `{REFERENCE_READ_ENV}_gold.finance.wbs_otp_exposed` 
# MAGIC   - `{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed`
# MAGIC   - `{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed`  
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC   - `{PIPELINE_WRITE_ENV}_gold.production.planned_orders_sap`  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame, Window
import time
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - Manual Mapping division site  
# MAGIC **df_bronze_site** Mapping site-division-region  
# MAGIC **df_bronze_site_plant** Mapping site-plant

# COMMAND ----------

df_bronze_site = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region"
)
df_bronze_site_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_plant_site"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### SILVER - Planned orders
# MAGIC
# MAGIC **df_silver_plo** 
# MAGIC
# MAGIC This is the processed Planned orders dataset from the Silver layer, already structured from raw SAP sources.
# MAGIC Used as the base for enrichment and final Gold formatting.

# COMMAND ----------

df_silver_plo = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.production.planned_orders_sap"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Material by plant
# MAGIC **df_gold_material** Extraction master data material

# COMMAND ----------

df_gold_material = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - WBS Master Data  
# MAGIC **df_gold_wbs**  Extraction Master Data Supplier 

# COMMAND ----------

df_gold_wbs = spark.read.table(f"{REFERENCE_READ_ENV}_gold.master_data.wbs_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Profit Center
# MAGIC **df_gold_profitcenter** profit center master data

# COMMAND ----------

df_gold_profitcenter = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Plant Master Data  
# MAGIC **df_gold_company**  Extraction Master Data Plant 

# COMMAND ----------

df_gold_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 - Select and translate Site mapping

# COMMAND ----------

df_bronze_site = (
    df_bronze_site.select(f.col("site").alias("stock_site"), "division", "region")
    .distinct()
    .withColumn(
        "stock_site", f.translate("stock_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
    )
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 - Select Material Plant info

# COMMAND ----------

df_gold_material = df_gold_material.select(
    "material_number",
    "plant",
    "MRP_unit",
    "material_description",
    "decopling_point",
    "profit_center",
    "standard_price_eur_budget",
    "average_price_eur_budget",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 – WBS master data

# COMMAND ----------

df_gold_wbs = df_gold_wbs.select("WBS_element", "WBS_code")
# Remove leading zero
df_gold_wbs = table_utils.remove_leading_zeros(
    df=df_gold_wbs,
    column_names=[
        "WBS_element",
        "WBS_code",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 4 – Profit Center

# COMMAND ----------

df_gold_profitcenter = df_gold_profitcenter.toDF(
    *[c.lower() for c in df_gold_profitcenter.columns]
)

df_gold_profitcenter_prep = df_gold_profitcenter.select(
    f.col("profit_center_short").alias("profit_center"),
    f.col("short_description").alias("profit_center_description"),
    f.col("customer_group"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 5 – plant master data

# COMMAND ----------

df_gold_plant = df_gold_plant.toDF(*[c.lower() for c in df_gold_plant.columns])

df_gold_company_prepared = df_gold_plant.select(
    "plant",
    "company",
    "company_description",
    f.col("country").alias("company_country"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 - Add material master data

# COMMAND ----------

df_plo_material = df_silver_plo.join(
    df_gold_material, ["material_number", "plant", "MRP_unit"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 – Division / Region / Site Classification  
# MAGIC

# COMMAND ----------

# ----------------------------------------------------------------------------------
# We keep only in the mapping plant code when there are associated to a unique site
window_plant = Window.partitionBy("plant_code")
df_bronze_site_plant = (
    df_bronze_site_plant.withColumn("_tmp_count", f.count("*").over(window_plant))
    .filter(f.col("_tmp_count") == 1)
    .drop("_tmp_count")
).withColumnsRenamed({"plant_code": "plant", "site": "_tmp_site_case_1"})
# ----------------------------------------------------------------------------------
df_gold_profitcenter = df_gold_profitcenter.select(
    f.col("profit_center_short").alias("profit_center"),
    f.col("pc_attributed_site").alias("_tmp_site_case_2"),
).where(f.col("_tmp_site_case_2") == "LATE-LFR1 - Labège Systems")

# COMMAND ----------

# Determination of Branch
# -----------------------------------------------------------------
# Determination 1:1 relationship
df_material_w_site = df_plo_material.join(df_bronze_site_plant, ["plant"], "left")
# Determination DES
df_material_w_site = df_material_w_site.join(
    df_gold_profitcenter, ["profit_center"], "left"
)
# Determination dispatch plant 1000 and 2000
df_material_w_site = df_material_w_site.withColumn(
    "_tmp_site_case_3",
    f.when(
        f.col("plant") == "2000",
        f.lit("LFR1 - Labège"),
    ),
)
df_material_w_site = df_material_w_site.withColumn(
    "_tmp_site_case_4",
    f.when(
        (f.col("plant") == "1000") & (f.col("decopling_point").startswith("MON")),
        f.lit("LATE - Montredon"),
    )
    .when(
        ((f.col("plant") == "1000") | (f.col("plant") == "2000"))
        & (f.col("mrp_controller").startswith("DE")),
        f.lit("LATE-LFR1 - Labege Systems"),
    )
    .when(
        (f.col("plant") == "1000") & (f.col("decopling_point").startswith("GMT")),
        f.lit("LATE - Gimont"),
    )
    .otherwise(f.lit("LATE - Gabardie")),
)
df_material_w_site = df_material_w_site.withColumn(
    "stock_site",
    f.coalesce(
        f.col("_tmp_site_case_1"),
        f.col("_tmp_site_case_2"),
        f.col("_tmp_site_case_3"),
        f.col("_tmp_site_case_4"),
    ),
)
df_material_w_site = df_material_w_site.select(
    [col for col in df_material_w_site.columns if not col.startswith("_tmp")]
)
# -----------------------------------------------------------------
# Remove all accents in site so as to join correctly
df_material_w_site = df_material_w_site.withColumn(
    "stock_site", f.translate("stock_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
)

df_material_w_site = df_material_w_site.join(
    df_bronze_site, ["stock_site"], "left"
)
df_material_w_site = df_material_w_site.withColumnRenamed("stock_site", "site")

# Quality check: all lines must have a site
if df_material_w_site.where(f.col("stock_site").isNull()).count() > 0:
    raise Exception("At least 1 row with blank site")
# -----------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 – Add Production_site

# COMMAND ----------

# Dispatch Production Site for Plant 1000 (Gimont/Montredon/DES)
df_planned_order_site = df_material_w_site.withColumn(
    "production_site",
    f.when(f.col("plant") != "1000", f.col("Site"))
    .when(f.substring(f.col("MRP_controller"), 1, 1) == "O", f.lit("LATE - Montredon"))
    .when(f.col("MRP_controller") == "DET", f.lit("LATE-LFR1 - Labege Systems"))
    .otherwise(f.col("Site")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 4 – Add WBS - information

# COMMAND ----------

df_planned_order_wbs = df_planned_order_site.join(
    df_gold_wbs, ["WBS_element"], "left"
).drop("WBS_element")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 5 – Add Profit Center information

# COMMAND ----------

df_planned_order_pf = df_planned_order_wbs.join(
    df_gold_profitcenter_prep, ["profit_center"], "left"
)

# Profit Center is update in Work order only since 2015
# We put unknown when this field  is null
df_planned_order_pf = df_planned_order_pf.withColumn(
    "profit_center", f.coalesce(f.col("profit_center"), f.lit("Unknown"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 6 – Add Company information

# COMMAND ----------

df_planned_order_company = df_planned_order_pf.join(
    df_gold_company_prepared, ["plant"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 7 - Valorisation Standard

# COMMAND ----------

# Management of Schedulling Type
df_planned_order_price = df_planned_order_company.withColumn(
    "amount_at_material_standard_price_in_eur",
    f.col("quantity_planned") * f.col("standard_price_eur_budget"),
)
df_planned_order_price = df_planned_order_price.withColumn(
    "amount_at_material_average_price_in_eur",
    f.col("quantity_planned") * f.col("average_price_eur_budget"),
).drop("standard_price_eur_budget", "average_price_eur_budget")

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

df_to_check = df_planned_order_price
col_pk = "planned_order_number"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for planned orders table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="planned_orders_gold",
    log_to_event_table=True,
    log_successes=True,
)

columns = df_to_check.columns
columns.remove(col_pk)
new_column_order = [col_pk] + columns
df_to_check = df_to_check.select(new_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Gold Work orders table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "production"
DESTINATION_TABLE = "planned_orders_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_to_check,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_to_check.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – Exposed Table View

# COMMAND ----------

dest_full_tablename = f"{DESTINATION_TABLE_FULL_PATH}_exposed"

Begin_By = ["PLAF"]

selected_columns = [
    col
    for col in df_to_check.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename,
    select_statement,
    replace_view=True,
)

log.info(f"The table view {dest_full_tablename} has been successfully created")
