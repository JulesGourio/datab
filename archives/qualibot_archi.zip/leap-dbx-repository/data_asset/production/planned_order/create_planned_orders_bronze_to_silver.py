# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # SILVER PLANNED ORDERS
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC This data asset has been created to centralize and structure all relevant information related to SAP planned orders.
# MAGIC The objective is to provide a trusted, historical, and unified view of manufacturing orders that can be reused across different analytical and reporting use cases.
# MAGIC
# MAGIC By consolidating data from core SAP tables such as PLAF (planned order), this dataset enables:
# MAGIC
# MAGIC 🔎 Tracking the lifecycle of planned orders.  
# MAGIC
# MAGIC 📊 Analyzing planned order to convert and anticipate workload.
# MAGIC
# MAGIC 🏭 Supporting manufacturing performance KPIs and operational reporting.
# MAGIC
# MAGIC 🔗 Providing a single source of truth for downstream consumers (dashboards, data science models, audits).
# MAGIC
# MAGIC This asset is part of the silver layer in the data pipeline, ensuring data is clean, incremental, and historically traceable.
# MAGIC
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC   - `{reference_read_env}_bronze.sap_latecoere_ecc6.plaf`
# MAGIC   - `{reference_read_env}_bronze.headers_sap.headers_sap_plaf`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC   - `{pipeline_write_env}_silver.production.planned_orders_sap`  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
import time
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##Input Function

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import SAP TABLES & business headers

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - PLAF - Planned Order Header Table
# MAGIC It stores the header-level data for planned orders in SAP. A planned order is a procurement proposal created during material requirements planning (MRP) to cover material shortages.

# COMMAND ----------

df_plaf_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.plaf_latest"
)
# headers
df_plaf_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_plaf"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 - PLAF renaming according business naming

# COMMAND ----------

df_plaf_prepared = table_utils.add_prefix_to_columns(df_plaf_raw, "PLAF")
df_name_plaf = delete_null_rows(df_plaf_headers)

# Call Function Rename Columns according header file
df_column_plaf = table_utils.rename_columns_with_sap_business_header(
    df_plaf_prepared, df_name_plaf
)
# Call Funtion Create Columns on Date format
df_plaf_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_plaf, df_name_plaf
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 - Cleaning raw data

# COMMAND ----------

# Remove leading zero
df_plaf_clean = table_utils.remove_leading_zeros(
    df=df_plaf_renamed,
    column_names=[
        "planned_order_number",
        "material_number",
        "sales_orders",
        "sales_orders_item",
        "WBS_element",
    ],
)
df_plaf_clean = df_plaf_clean.withColumn(
    "sales_orders_item",
    f.when(f.col("sales_orders_item") == "", f.lit(None)).otherwise(
        f.col("sales_orders_item")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 – Update MRP_Unit
# MAGIC
# MAGIC AS MRP_Unit had been deployed 5 years ago, we have to fullfill MRP_unit for old WO.  
# MAGIC Need to make join with material master data.  

# COMMAND ----------

df_plaf_mrp = df_plaf_clean.withColumn(
    "MRP_unit", f.coalesce(f.col("MRP_unit"), f.col("plant"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 – Exclusion simulation MRP entries

# COMMAND ----------

df_plaf_end = df_plaf_mrp.filter(f.col("PLAF_plscn") == "000")

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

df_to_check = df_plaf_end
col_pk = "planned_order_number"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for work order table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="invoice_supplier_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Work orders table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "production"
DESTINATION_TABLE = "planned_orders_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_to_check,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_to_check.count()} rows.")
    if result is not None:
        result.display()
