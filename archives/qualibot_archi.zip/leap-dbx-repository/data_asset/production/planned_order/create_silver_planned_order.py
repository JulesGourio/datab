# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for Planned Order Production
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_silver.production.sap_planned_order_latest
# MAGIC
# MAGIC **Input :**  
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.plaf_latest
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_plaf
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC  - SAP Bronze Ingestion  
# MAGIC  
# MAGIC **Things performed in this notebook:** 
# MAGIC
# MAGIC - Cleaning data
# MAGIC - Renaming Headers  
# MAGIC - Keep only Production Planned Orders

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from leap_utils.data_asset import table_utils


dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )

# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table and Renaming

# COMMAND ----------

# Upload PLAF <- Master Data SAP basics Work Planned Order
# We keep only production entries (exclusion Simulation 'plscn')

df_plaf = (spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.plaf_latest")
        .filter(f.col("plscn")=="000")
)       
# Renaming // PLAFXXXX
df_plaf = table_utils.add_prefix_to_columns(df_plaf, "PLAF")   

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming according Header files

# COMMAND ----------

## Renaming headers AFKO - Basic Master Data from SAP
df_name_plaf = spark.read.table("prod_bronze.headers_sap.headers_sap_business_plaf")
# Call function Check Header files
check_schema_of_the_file(df_name_plaf)
# Call Function Delete rows null
df_name_plaf = delete_null_rows(df_name_plaf)

# Call Function Rename Columns according header file
df_planned_order = table_utils.rename_columns_with_sap_business_header(
    df_plaf, df_name_plaf
)
# Call Funtion Create Columns on format according header file
df_planned_order_clean = table_utils.cast_columns_with_sap_business_headers(
    df_planned_order, df_name_plaf
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Cleasing raw data

# COMMAND ----------

# Formatting Material_Number without '0' on left side
df_planned_order_clean_format = df_planned_order_clean.withColumn(
    "Material_Number", f.regexp_replace(df_planned_order_clean.Material_Number, "^0+", "")
)
#Formatting WO_Number without '0' on left side
df_planned_order_clean_format = df_planned_order_clean_format.withColumn(
    "Planned_Order_Number", f.regexp_replace(df_planned_order_clean_format.Planned_Order_Number, "^0+", "")
)
# Formatting Profit_Center without '0' on left side
df_planned_order_clean_format = df_planned_order_clean_format.withColumn(
    "Reservation_Number", f.regexp_replace(df_planned_order_clean_format.Reservation_Number, "^0+", "")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Silver table

# COMMAND ----------

catalog = f"{WRITE_ENV}_silver"
domain = "production"
table = "sap_planned_order_latest"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_planned_order_clean_format,
    mode="overwrite",
    overwrite_schema=True
)
