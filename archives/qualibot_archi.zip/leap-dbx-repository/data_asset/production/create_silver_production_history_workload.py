# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for WorkLoad Historic from SAP 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_silver.production.history_workload
# MAGIC   
# MAGIC **Intput :**  
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.s022_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.afko_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.afpo_latest
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_s022
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC - Ingestion Raw SAP  
# MAGIC
# MAGIC **Things performed in this notebook:** 
# MAGIC  - Join Header and Item + Description
# MAGIC  - Correction SAP Decimal  
# MAGIC  - Renaming Header according business rules  

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC # Historic Work load

# COMMAND ----------

# MAGIC %md
# MAGIC ## Upload Tables from SAP

# COMMAND ----------

# Upload SAP Workload historic
df_s022 = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.s022_latest")
df_s022 = table_utils.add_prefix_to_columns(df_s022, "S022")

## Upload SAP Work Order Header Data
df_afko = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.afko_latest")
# Keep Only Mrp Controller (dispo) and Work Order (aufnr)
df_afko = df_afko.select("dispo", "aufnr")
df_afko = table_utils.add_prefix_to_columns(df_afko, "AFKO")


## Upload SAP Work Order Data
df_afpo = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.afpo_latest")
# Keep Only Work Order(aufnr)
# Order_Type (dauat) Prod_Version (verid) Planned_Order(plnum)
df_afpo = df_afpo.select("aufnr", "dauat", "verid", "plnum","lgort")
df_afpo = table_utils.add_prefix_to_columns(df_afpo, "AFPO")

# COMMAND ----------

# Join is performed on Work onder Number ('aufnr')
df_join_workload = (
    df_s022.alias("A")
    .join(df_afko.alias("B"), f.col("A.S022_aufnr") == f.col("B.AFKO_aufnr"), "left")
    .join(df_afpo.alias("C"), f.col("A.S022_aufnr") == f.col("C.AFPO_aufnr"), "left")
    .drop("AFKO_aufnr")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Renaming Work Order information

# COMMAND ----------

df_workload_renamed = df_join_workload.withColumnRenamed(
    "AFPO_aufnr", "Ressources_Number"
)
df_workload_renamed = df_workload_renamed.withColumnRenamed(
    "AFKO_dispo", "Mrp_Controller"
)
df_workload_renamed = df_workload_renamed.withColumnRenamed(
    "AFPO_verid", "Production_Version"
)
df_workload_renamed = df_workload_renamed.withColumnRenamed(
    "AFPO_lgort", "Storage_Location"
)
df_workload_renamed = df_workload_renamed.withColumnRenamed("AFPO_dauat", "Order_Type")
df_workload_renamed = df_workload_renamed.withColumnRenamed(
    "AFPO_plnum", "Planned_Order_Origin"
)
df_workload_renamed = df_workload_renamed.withColumn(
    "Ressources_Type", f.lit("Work_Order")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming Header with business entries

# COMMAND ----------

df_name_kbed = spark.read.table("prod_bronze.headers_sap.headers_sap_business_s022")
# Call function Check Header files
check_schema_of_the_file(df_name_kbed)
# Call Function Delete rows null
df_name_kbed = delete_null_rows(df_name_kbed)

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_workload_renamed, df_name_kbed
)
# Call Funtion Create Columns on Date format
df_workload = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_kbed
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cleansing dataframe before saving

# COMMAND ----------

# Formatting Ressources_Number without '0' on left side
df_workload = df_workload.withColumn(
    "Ressources_Number", f.regexp_replace(df_workload.Ressources_Number, "^0+", "")
)
# Formatting Planned Orders without '0' on left side
df_workload = df_workload.withColumn(
    "Planned_Order_Origin",
    f.regexp_replace(df_workload.Planned_Order_Origin, "^0+", ""),
)
# Formatting Material_Number without '0' on left side
df_workload = df_workload.withColumn(
    "Material_Number", f.regexp_replace(df_workload.Material_Number, "^0+", "")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save table

# COMMAND ----------

catalog = f"{WRITE_ENV}_silver"
domain = "production"
table = "history_workload"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_workload,
    mode="overwrite",
    overwrite_schema=True
)
