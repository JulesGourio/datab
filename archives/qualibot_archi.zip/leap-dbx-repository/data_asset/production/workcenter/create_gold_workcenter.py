# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE GOLD WORKCENTER SAP
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the gold table from the silver table of workcenter. 
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Workcenter
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {pipeline_write_env}_silver.production.workcenter
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.production.workcenter
# MAGIC - {pipeline_write_env}_gold.production.workcenter_exposed
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

import pyspark.sql.functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

WORKCENTER_SILVER_SAP_TABLE = f"{PIPELINE_READ_ENV}_silver.production.workcenter"
WORKCENTER_GOLD_SAP_TABLE = f"{PIPELINE_WRITE_ENV}_gold.production.workcenter"

# COMMAND ----------

# MAGIC %md
# MAGIC #Input

# COMMAND ----------

df_silver_raw = spark.read.table(WORKCENTER_SILVER_SAP_TABLE)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

df_workcenter_gold = df_silver_raw.withColumn(
    "workcenter",
    f.concat_ws("-", f.col("workcenter_code"), f.col("workcenter_description")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    dest_table=WORKCENTER_GOLD_SAP_TABLE,
    df=df_workcenter_gold,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

begin_by_1 = "CRHD"
begin_by_2 = "TC24"

selected_columns = [
    col
    for col in df_workcenter_gold.columns
    if not col.startswith(begin_by_1) and not col.startswith(begin_by_2)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    WORKCENTER_GOLD_SAP_TABLE,
    f"{WORKCENTER_GOLD_SAP_TABLE}_exposed",
    select_statement,
    replace_view=True,
)
