# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE SILVER WORKCENTER INFORMATION
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the silver table on workcenter. 
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Workcenter - SAP
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.tc24_latest
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.crtx_latest
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.crhd_latest
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.crco_latest
# MAGIC - {reference_read_env}_bronze.headers_sap.headers_sap_business_tc24
# MAGIC - {reference_read_env}_bronze.headers_sap.headers_sap_business_crtx
# MAGIC - {reference_read_env}_bronze.headers_sap.headers_sap_business_crhd
# MAGIC - {reference_read_env}_bronze.headers_sap.headers_sap_business_crco
# MAGIC
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.production.workcenter
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Imports

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f
from pyspark.sql.window import Window
from datetime import datetime

# LEAP FUNCTION
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - **df_crhd_raw** is the bronze latest CRHD SAP table - workcenter master data
# MAGIC - **df_tc24_raw** is the bronze latest TC24 SAP table (WC group)
# MAGIC - **df_crtx_raw** is the workcenter description SAP table
# MAGIC - **df_headers_crhd** is the header of the SAP table CRHD
# MAGIC - **df_headers_tc24** is the header of the SAP table TC24
# MAGIC - **df_headers_crtx** is the header of the SAP table CRTX
# MAGIC
# MAGIC

# COMMAND ----------

df_crhd_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.crhd_latest"
)

df_tc24_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tc24_latest"
)

df_crtx_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.crtx_latest"
).filter(f.col("objty") == "A")

df_crco_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.crco_latest"
)

# COMMAND ----------

df_headers_crtx = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_crtx"
)

df_headers_tc24 = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_tc24"
)

df_headers_crhd = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_crhd"
)

df_headers_crco = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_crco"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Inputs - Manual declaration

# COMMAND ----------

WORKCENTER_SILVER_SAP_TABLE = f"{PIPELINE_WRITE_ENV}_silver.production.workcenter"

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Renaming columns

# COMMAND ----------

df_crhd_raw = table_utils.add_prefix_to_columns(df_crhd_raw, "CRHD")
df_tc24_raw = table_utils.add_prefix_to_columns(df_tc24_raw, "TC24")
df_crtx_raw = table_utils.add_prefix_to_columns(df_crtx_raw, "CRTX")
df_crco_raw = table_utils.add_prefix_to_columns(df_crco_raw, "CRCO")

table_utils.check_schema_of_the_header_file(df_headers_crhd)
table_utils.check_schema_of_the_header_file(df_headers_tc24)
table_utils.check_schema_of_the_header_file(df_headers_crtx)
table_utils.check_schema_of_the_header_file(df_headers_crco)

df_crhd_renamed = table_utils.rename_columns_with_sap_business_header(
    df_crhd_raw, df_headers_crhd
)
df_crtx_renamed = table_utils.rename_columns_with_sap_business_header(
    df_crtx_raw, df_headers_crtx
)
df_tc24_renamed = table_utils.rename_columns_with_sap_business_header(
    df_tc24_raw, df_headers_tc24
)
df_crco_renamed = table_utils.rename_columns_with_sap_business_header(
    df_crco_raw, df_headers_crco
)
df_crco_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_crco_renamed, df_headers_crco
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - Workcenter description table

# COMMAND ----------

# Filter for English and French descriptions and then keep the last description
df_workcenter_desc_en = df_crtx_renamed.filter(f.col("workcenter_desc_language") == "E")
df_workcenter_desc_fr = df_crtx_renamed.filter(f.col("workcenter_desc_language") == "F")
df_workcenter_desc_others = df_crtx_renamed.filter(
    (f.col("workcenter_desc_language") != "F")
    & (f.col("workcenter_desc_language") != "E")
)

w0 = Window.orderBy(f.desc("workcenter_description"))
df_workcenter_desc_others = df_workcenter_desc_others.withColumn(
    "rank", f.dense_rank().over(w0)
)
df_workcenter_desc_others = df_workcenter_desc_others.filter(f.col("rank") == 1).drop(
    "rank"
)

# Rename columns to avoid ambiguity
df_workcenter_desc_en = df_workcenter_desc_en.withColumnRenamed(
    "workcenter_description", "workcenter_description_en"
).drop("workcenter_desc_language")
df_workcenter_desc_fr = df_workcenter_desc_fr.withColumnRenamed(
    "workcenter_description", "workcenter_description_fr"
).drop("workcenter_desc_language")
df_workcenter_desc_others = df_workcenter_desc_others.withColumnRenamed(
    "workcenter_description", "workcenter_description_others"
).drop("workcenter_desc_language")

# Join English and French descriptions
df_workcenter_desc_tmp = df_workcenter_desc_fr.join(
    df_workcenter_desc_en, ["workcenter_id"], "left"
).join(df_workcenter_desc_others, ["workcenter_id"], "left")
# Select the appropriate description
df_workcenter_desc_prep = df_workcenter_desc_tmp.withColumn(
    "workcenter_description",
    f.coalesce(
        f.col("workcenter_description_en"),
        f.col("workcenter_description_fr"),
        f.col("workcenter_description_others"),
    ),
).drop(
    "workcenter_description_en",
    "workcenter_description_fr",
    "workcenter_description_others",
)

col_to_select = [
    col for col in df_workcenter_desc_prep.columns if not col.startswith("CRTX")
]

df_workcenter_desc_prep = df_workcenter_desc_prep.select(*col_to_select)

current_date = datetime.today().strftime("%Y-%m-%d")

df_workcenter_costcenter = (
    df_crco_renamed.select("workcenter_id", "cost_center", "end_date", "start_date")
    .filter((f.col("end_date") >= current_date) & (f.col("start_date") <= current_date))
    .drop("end_date", "start_date")
    .distinct()
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Get workcenter description

# COMMAND ----------

df_workcenter_transf = df_crhd_renamed.join(
    df_workcenter_desc_prep, ["workcenter_id"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Get workcenter group and description

# COMMAND ----------

df_workcenter_transf = df_workcenter_transf.join(
    df_tc24_renamed, ["plant", "workcenter_group_code"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr3 - Get cost center

# COMMAND ----------

df_workcenter_transf = df_workcenter_transf.join(
    df_workcenter_costcenter, on="workcenter_id", how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    dest_table=WORKCENTER_SILVER_SAP_TABLE,
    df=df_workcenter_transf,
    overwrite_schema=True,
    mode="overwrite",
)
