# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE GOLD HOURLY RATE SAP
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The script creates the gold table from the silver table of hourly rate.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Hourly rate
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {PIPELINE_READ_ENV}_silver.production.hourly_rate
# MAGIC - {REFERENCE_READ_ENV}_gold.finance.cost_center_exposed
# MAGIC - {REFERENCE_READ_ENV}_gold.finance.currency_exchange
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.production.hourly_rate
# MAGIC - {PIPELINE_WRITE_ENV}_gold.production.hourly_rate_exposed
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

from leap_utils.data_asset import table_utils
from pyspark.sql import functions as f
import datetime

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Input

# COMMAND ----------

df_silver_hourly_rate = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.production.hourly_rate"
)

# COMMAND ----------

df_cost_center_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.cost_center_exposed"
)

# COMMAND ----------

# Upload Gold Currency to convert all prices in EUR
df_currency_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.currency_exchange"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep1 - Cost center exposed

# COMMAND ----------

df_cost_center_prep = (
    df_cost_center_raw.select("cost_center", "short_description", "is_valid")
    .withColumnRenamed("short_description", "cost_center_description")
    .filter(f.col("is_valid"))
    .drop("is_valid")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Join cost center to get cost_center_description

# COMMAND ----------

df_gold_hourly_rate = df_silver_hourly_rate.join(
    df_cost_center_prep, on="cost_center", how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Add currency column

# COMMAND ----------

today = datetime.datetime.today()

# COMMAND ----------

df_gold_hourly_rate = df_gold_hourly_rate.withColumn(
    "currency",
    f.when(f.col("analytical_scope") == "PA01", f.lit("EUR"))
    .when(f.col("analytical_scope") == "PA20", f.lit("CZK"))
    .otherwise(f.lit("EUR")),
).withColumn(
    "currency_date",
    f.when(
        f.col("fiscal_year") == str(today.year),
        f.to_date(f.lit((today - datetime.timedelta(days=1)).strftime("%Y-%m-%d"))),
    ).otherwise(
        f.to_date(
            f.concat(f.col("fiscal_year").cast("int"), f.lit("-12-01")), "yyyy-MM-dd"
        )
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr3 - Convert local currency to EUR

# COMMAND ----------

df_gold_hourly_rate = table_utils.currency_conversion(
    df=df_gold_hourly_rate,
    document_currency_column=f.col("currency"),
    rate_types=["Budget"],
    rate_dates=[f.col("currency_date")],
    target_currency_value="EUR",
    document_amounts=[
        f.col("hourly_rate_total"),
        f.col("hourly_rate_fix"),
    ],
    df_currency=df_currency_raw,
)

# COMMAND ----------

df_gold_hourly_rate = (
    df_gold_hourly_rate.withColumnsRenamed(
        {
            "hourly_rate_total_from_currency_to_EUR_in_Budget_rate_at_currency_date": "hourly_rate_total_EUR",
            "hourly_rate_FIX_from_currency_to_EUR_in_Budget_rate_at_currency_date": "hourly_rate_fix_EUR",
        }
    )
    # Here, we would like to keep th default value 0.01 for the hourly_rate_total and hourly_rate_fix after conversion
    .withColumn(
        "hourly_rate_total_EUR",
        f.when(
            f.col("hourly_rate_total") == 0.01, f.col("hourly_rate_total")
        ).otherwise(
            f.round(
                f.col("hourly_rate_total_EUR"),
                2,
            )
        ),
    )
    .withColumn(
        "hourly_rate_fix_EUR",
        f.when(f.col("hourly_rate_fix") == 0.01, f.col("hourly_rate_fix")).otherwise(
            f.round(
                f.col("hourly_rate_fix_EUR"),
                2,
            )
        ),
    )
    .drop("currency_to_EUR_in_Budget_rate_at_currency_date")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr4 - Add hourly_rate_variable column

# COMMAND ----------

df_gold_hourly_rate = df_gold_hourly_rate.withColumn(
    "hourly_rate_variable",
    f.col("hourly_rate_total") - f.col("hourly_rate_fix"),
).withColumn(
    "hourly_rate_variable_EUR",
    f.col("hourly_rate_total_EUR") - f.col("hourly_rate_fix_EUR"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality Check

# COMMAND ----------

df_to_check = df_gold_hourly_rate
col_to_check = "cost_center_description"

df_gx = SparkDFDataset(df_to_check, persist=False)

quality_check_results = [df_gx.expect_column_values_to_not_be_null(column=col_to_check)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level="RED",
    info_message=f"No null values found in {col_to_check}",
    error_message=f"Null values found in {col_to_check}, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="hourly_rate_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.production.hourly_rate",
    df=df_gold_hourly_rate,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

begin_by_1 = "COST"

selected_columns = [
    col for col in df_gold_hourly_rate.columns if not col.startswith(begin_by_1)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    f"{PIPELINE_WRITE_ENV}_gold.production.hourly_rate",
    f"{PIPELINE_WRITE_ENV}_gold.production.hourly_rate_exposed",
    select_statement,
    replace_view=True,
)
