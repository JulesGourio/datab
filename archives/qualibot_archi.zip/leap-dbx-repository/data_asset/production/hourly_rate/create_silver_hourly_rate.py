# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE SILVER HOURLY RATE
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the silver table on hourly rate for each cost center & activity type each year. Only data after 2020 are taken into acoount.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Hourly rate - SAP
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cost_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_cost
# MAGIC
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.production.hourly_rate
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Imports

# COMMAND ----------

# LEAP FUNCTION
from leap_utils.data_asset import table_utils
from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - **df_cost_raw** is a standard table in SAP. It contains all hourly rate for each couple of cost_center, activity_type, fiscal_year (and period). The value is the same for each period so we will only take the number 12 for december of every year.
# MAGIC - **df_cost_headers** is the header of the SAP table COST
# MAGIC

# COMMAND ----------

df_cost_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cost_latest"
)

# COMMAND ----------

df_cost_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_cost"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Inputs - Manual declaration

# COMMAND ----------

COST_PREFIX = "COST"

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Renaming & casting columns

# COMMAND ----------

df_cost_prep = table_utils.add_prefix_to_columns(df_cost_raw, COST_PREFIX)

table_utils.check_schema_of_the_header_file(df_cost_headers)

df_cost_prep = table_utils.rename_columns_with_sap_business_header(
    df_cost_prep, df_cost_headers
)

df_cost_prep = table_utils.cast_columns_with_sap_business_headers(
    df_cost_prep, df_cost_headers
)
df_cost_prep = table_utils.remove_leading_zeros(
    df=df_cost_prep, column_names=["price_code"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Filter data after 2020

# COMMAND ----------

df_silver_hourly_rate = df_cost_prep.filter(f.col("fiscal_year") >= 2020)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Extract analytical scope, cost center and activity type

# COMMAND ----------

df_silver_hourly_rate = df_silver_hourly_rate.withColumns({
    "analytical_scope": f.substring(f.col("object_number"), 3, 4),
    "cost_center": f.regexp_extract(f.col("object_number"), r"^.{6}([^ ]+)", 1),
    "activity_type": f.regexp_extract(f.col("object_number"), r"\s+(\S+)$", 1)
}).drop("object_number")

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_silver.production.hourly_rate",
    df=df_silver_hourly_rate,
    overwrite_schema=True,
    mode="overwrite",
)
