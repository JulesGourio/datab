# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The goal of this notebook is to create the gold table of touch up on MES lines. A touch up is a minor rework that is made on a regular work order operation (no specific WO). 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - {PIPELINE_READ_ENV}_silver.production.touchup_mes
# MAGIC - {PIPELINE_READ_ENV}_silver.production.work_order_operation
# MAGIC - {PIPELINE_WRITE_ENV}_bronze.mes.retouching_sheet_latest
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.production.touchup_mes
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

from leap_utils.data_asset import table_utils

from pyspark.sql import functions as f
from pyspark.sql.window import Window

from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    LongType,
    IntegerType,
    ArrayType,
)

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Input table

# COMMAND ----------

df_retouch_raw = spark.read.table(f"{PIPELINE_READ_ENV}_silver.production.touchup_mes")

# COMMAND ----------

df_retouch_sheet_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.mes.retouching_sheet_latest"
)

# COMMAND ----------

df_wo_ope_mes_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.production.work_order_operation_mes"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

LIST_COL_NOT_EXPOSED = [col for col in df_retouch_raw.columns if col.startswith("_")]

# COMMAND ----------

LIST_COL_OPE = ["work_order", "work_order_operation", "datatimes"]

# COMMAND ----------

# MAGIC %md
# MAGIC #Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - WO ope MES
# MAGIC Extract relevant informations relative to touch up in the work order operation. The goal is to get a dataframe that gives touch up time per work order operation. 

# COMMAND ----------

df_wo_ope_mes_prep = (
    df_wo_ope_mes_raw.where(f.col("touchup_time_sec") > 0)
    .select(*LIST_COL_OPE)
    .dropDuplicates()
)

# COMMAND ----------

event_schema = ArrayType(
    StructType(
        [
            StructField("state", StringType(), True),
            StructField("period", IntegerType(), True),
            StructField("datetime", LongType(), True),
            StructField("username", StringType(), True),
        ]
    )
)

df_parsed = df_wo_ope_mes_prep.withColumn(
    "datatimes_array", f.from_json(f.col("datatimes"), event_schema)
)

df_exploded = df_parsed.withColumn("event", f.explode(f.col("datatimes_array"))).select(
    "work_order",
    "work_order_operation",
    f.col("event.state").alias("state"),
    f.col("event.datetime").alias("datetime"),
)

# Keep only Touch up events
df_touchup = (
    df_exploded.filter(f.col("state").rlike("TOUCHUP_"))
    .withColumn(
        "event_type",
        f.when(f.col("state").like("%STARTED"), "STARTED")
        .when(f.col("state").like("%PAUSED"), "PAUSED")
        .when(f.col("state").like("%STOPPED"), "STOPPED"),
    )
    .withColumn("touchup_id", f.regexp_extract(f.col("state"), "id_(\\d+)_TOUCHUP", 1))
)

# Pairing STARTED / PAUSED or STOPPED
window_spec = Window.partitionBy("work_order", "work_order_operation").orderBy(
    "datetime"
)
df_touchup = df_touchup.withColumn("row", f.row_number().over(window_spec))

df_start = (
    df_touchup.filter(f.col("event_type") == "STARTED")
    .withColumnRenamed("datetime", "start_time")
    .withColumnRenamed("row", "start_row")
)

df_end = (
    df_touchup.filter(f.col("event_type").isin("PAUSED", "STOPPED"))
    .withColumnRenamed("datetime", "end_time")
    .withColumnRenamed("row", "end_row")
)

# joined START → PAUSED/STOPPED
df_joined = (
    df_start.join(
        df_end,
        (df_start["work_order"] == df_end["work_order"])
        & (df_start["work_order_operation"] == df_end["work_order_operation"])
        & (df_start["start_row"] < df_end["end_row"]),
        how="left",
    )
    .withColumn("row_diff", f.col("end_row") - f.col("start_row"))
    .filter(f.col("row_diff") == 1)
)

# time spend calculation between all ranges START → STOP/PAUSE
df_result = df_joined.select(
    df_start["work_order"],
    df_start["work_order_operation"],
    df_start["touchup_id"],
    f.try_divide(f.col("end_time") - f.col("start_time"), f.lit(1000)).alias(
        "touchup_duration_sec"
    ),
    f.try_divide(f.col("start_time"), f.lit(1000))
    .try_cast("timestamp")
    .alias("touchup_start_date"),
    f.try_divide(f.col("end_time"), f.lit(1000))
    .try_cast("timestamp")
    .alias("touchup_end_date"),
)

# Final aggregation
df_wo_ope_mes_prep_f = df_result.groupBy(
    "work_order", "work_order_operation", "touchup_id"
).agg(
    f.expr("sum(touchup_duration_sec)").alias("touchup_time_sec"),
    f.min("touchup_start_date").alias("touchup_start_date"),
    f.max("touchup_end_date").alias("touchup_end_date"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 1 - Get touchup information from WO Ope table

# COMMAND ----------

df_retouch_transf = df_retouch_raw.join(
    df_wo_ope_mes_prep_f,
    on=["work_order", "work_order_operation", "touchup_id"],
    how="left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 2 - Create concat WO Ope

# COMMAND ----------

df_retouch_transf = df_retouch_transf.withColumn(
    "WO_OPE_key", f.concat_ws("-", f.col("work_order"), f.col("work_order_operation"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 3 - Drop useless columns

# COMMAND ----------

df_retouch_transf = df_retouch_transf.drop(*LIST_COL_NOT_EXPOSED)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 4 - Issue type cleaning

# COMMAND ----------

df_retouch_transf = df_retouch_transf.withColumn(
    "issue_type", f.regexp_replace("issue_type", r"^(lat_tUpType_|lat_)", "")
).withColumn('issue_type', f.when(f.col('issue_type') == "", f.lit(None)).otherwise(f.col('issue_type')))

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.production.touchup_mes",
    df=df_retouch_transf,
    mode="overwrite",
    overwrite_schema=True,
)
