# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The goal of this notebook is to create the silver table of work order (header of WO) for MES lines. 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - {REFERENCE_READ_ENV}_bronze.mes.work_order_latest
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_silver.production.work_order_mes
# MAGIC   
# MAGIC **Triggered by:**  
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

from leap_utils.data_asset import table_utils

from pyspark.sql import functions as f

from pyspark.sql.types import StructType, StructField, StringType, ArrayType

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

df_wo_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.mes.work_order_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC # Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep1 - Cleaning columns
# MAGIC - Rank with 0

# COMMAND ----------

df_wo_prep = df_wo_raw.withColumn(
    "rank", f.when(f.col("rank").rlike("^0+$"), None).otherwise(f.col("rank"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep2 - Column casting
# MAGIC - Date columns
# MAGIC - priority as boolean 

# COMMAND ----------

LIST_DATE_COLUMNS = ["creation_date", "modification_date", "start_date", "end_date"]

# COMMAND ----------

for col in LIST_DATE_COLUMNS:
    df_wo_prep = df_wo_prep.withColumn(
        col, f.try_to_date(f.col(col), "yyyy-MM-dd HH:mm:ss.SSSSSS")
    )

# COMMAND ----------

df_wo_prep = df_wo_prep.withColumn(
    "priority",
    f.when(f.col("priority") == f.lit("t"), f.lit(True))
    .when(f.col("priority") == f.lit("f"), f.lit(False))
    .otherwise(f.col("priority").try_cast("boolean")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Extraction & cleaning - datasap
# MAGIC Data from SAP are stored in list or dictionnary. Therefore, we extract data from the column datasap.

# COMMAND ----------

schema_datasap_wo = StructType(
    [
        StructField("FAI", StringType()),
        StructField("LIGNE", StringType()),
        StructField("UNITY", StringType()),
        StructField("STATUS", ArrayType(StringType())),
        StructField("MANAGER", StringType()),
        StructField("DIVISION", StringType()),
        StructField("FILENAME", StringType()),
        StructField("MATERIAL", StringType()),
        StructField("PRIORITY", StringType()),
        StructField("GAMME_DATE", StringType()),
        StructField("WO_VERSION", StringType()),
        StructField("FINISH_DATE", StringType()),
        StructField("STATUT_GAMME", StringType()),
        StructField("STATUT_GAMME_TECHNIQUE", StringType()),
        StructField("MATERIAL_TEXT", StringType()),
        StructField("FIRST_LOCATION", StringType()),
        StructField("TARGET_QUANTITY", StringType()),
        StructField("AIRCRAFT_PROGRAM", StringType()),
    ]
)

# Parsing of datasap
df_datasap_parsed = df_wo_prep.withColumn(
    "datasap_struct", f.from_json("datasap", schema_datasap_wo)
)

# Extract columns from datasap
sap_columns = [
    f.col(f"datasap_struct.{field.name}").alias(f"SAP_{field.name}")
    for field in schema_datasap_wo.fields
]

df_wo_datasap_ext = df_datasap_parsed.select("*", *sap_columns)

# COMMAND ----------

df_wo_datasap_ext = df_wo_datasap_ext.withColumn(
    "SAP_AIRCRAFT_PROGRAM",
    f.when(f.col("SAP_AIRCRAFT_PROGRAM") == "-", None).otherwise(
        f.col("SAP_AIRCRAFT_PROGRAM")
    ),
)

df_wo_datasap_ext = table_utils.remove_leading_zeros(
    df_wo_datasap_ext, ["SAP_AIRCRAFT_PROGRAM"]
)

df_wo_datasap_ext = df_wo_datasap_ext.withColumn(
    "SAP_FINISH_DATE", f.try_to_date(f.col("SAP_FINISH_DATE"), "yyyy-MM-dd")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Renaming

# COMMAND ----------

COL_RENAMING_WO = {
    "number": "work_order",
    "number_parent": "parent_work_order",
    "rank": "WBS_code",
    "state": "work_order_state",
    "creation_date": "work_order_creation_date",
    "start_date": "actual_start_date",
    "end_date": "actual_end_date",
    "SAP_MANAGER": "MRP_controller",  # TBC
    "SAP_DIVISION": "plant",
    "SAP_MATERIAL": "material_number",
    "SAP_MATERIAL_TEXT": "material_description",
    "SAP_AIRCRAFT_PROGRAM": "profit_center",
    "SAP_FINISH_DATE": "planned_end_date",
    "datasap": "_datasap",
}

# COMMAND ----------

df_wo_transf = df_wo_datasap_ext.withColumnsRenamed(COL_RENAMING_WO)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr3 - ID creation

# COMMAND ----------

df_wo_transf = df_wo_transf.withColumn("WO_ID", f.col("work_order"))

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_silver.production.work_order_mes",
    df=df_wo_transf,
    mode="overwrite",
    overwrite_schema=True,
)
