# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The goal of this notebook is to create the gold table of work order operations inside MES. 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - {PIPELINE_READ_ENV}_silver.production.work_order_operation_mes
# MAGIC - {PIPELINE_READ_ENV}_gold.production.work_order_mes
# MAGIC - {REFERENCE_READ_ENV}_gold.production.allocated_time_per_wo_sap_exposed
# MAGIC - {REFERENCE_READ_ENV}_gold.production.infocenter_hqa
# MAGIC - {PIPELINE_READ_ENV}_gold.production.touchup_mes
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.production.work_order_operation_mes
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

from leap_utils.data_asset import table_utils

from pyspark.sql import functions as f
from pyspark.sql.window import Window
from datetime import datetime

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Input table

# COMMAND ----------

df_wo_ope_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.production.work_order_operation_mes"
)

# COMMAND ----------

df_wo_raw = spark.read.table(f"{PIPELINE_READ_ENV}_gold.production.work_order_mes")

# COMMAND ----------

df_hqa_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.production.infocenter_hqa")

# COMMAND ----------

df_allocated_time_per_ope = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.production.allocated_time_per_wo_sap_exposed"
)

# COMMAND ----------

df_touch_up = spark.read.table(f"{PIPELINE_READ_ENV}_gold.production.touchup_mes")

# COMMAND ----------

df_material_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
)

# COMMAND ----------

df_workcenter_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.production.workcenter_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

LIST_COL_NOT_EXPOSED = [col for col in df_wo_ope_raw.columns if col.startswith("_")] + [
    "textrec",
    "localization",
    "machineprogram",
    "comment",
    "datasap",
    "dataplm",
    "datacustom",
]

# COMMAND ----------

COL_TOUCH_UP = ["work_order", "work_order_operation", "production_status"]

# COMMAND ----------

COL_WO_MES = [
    "work_order",
    "profit_center",
    "WBS_code",
    "work_order_state",
    "work_order_creation_date",
    f.col("actual_start_date").alias("work_order_actual_start_date"),
    f.col("actual_end_date").alias("work_order_actual_end_date"),
    "WO_Status",
    "WO_Status_System",
    "program_customer",
    "Aircraft_product",
    "profit_center_description",
    "aircraft_rank",
]

# COMMAND ----------

LIST_COLUMNS_WORKCENTER = ["workcenter_code", "workcenter", "plant"]

# COMMAND ----------

# MAGIC %md
# MAGIC #Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep1 - MES WO gold table

# COMMAND ----------

df_wo_prep = df_wo_raw.select(*COL_WO_MES)

# COMMAND ----------

df_wo_prep = df_wo_prep.where(f.col("plant").isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep2 - HQA infocenter table

# COMMAND ----------

df_hqa_prep = df_hqa_raw.groupBy(
    "work_order", f.col("operation").alias("work_order_operation")
).agg(f.sum("spent_times_hc").alias("ope_spent_time_hc"))

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep3 - Allocated time per WO Ope

# COMMAND ----------

COL_OPE_SAP = [
    "work_order",
    "Material_Number",
    "Quantity_Ordered",
    "plant",
    "work_order_operation",
    "operation_description",
    "is_cancelled",
    "quantity_base",
    "actual_operation_start_date",
    "actual_operation_finish_date",
    "global_time_allocated_min",
]

# COMMAND ----------

df_allocated_time_per_ope_prep = df_allocated_time_per_ope.select(*COL_OPE_SAP)

# COMMAND ----------

DATE_COLUMNS_OPE_SAP = ["actual_operation_start_date", "actual_operation_finish_date"]

# COMMAND ----------

for col in DATE_COLUMNS_OPE_SAP:
    df_allocated_time_per_ope_prep = df_allocated_time_per_ope_prep.withColumn(
        col, f.when(f.col(col) == "00000000", f.lit(None)).otherwise(f.col(col))
    ).withColumn(col, f.try_to_date(f.col(col), "yyyyMMdd"))

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep4 - Touch up status table

# COMMAND ----------

df_touchup_prep = (
    df_touch_up.select(*COL_TOUCH_UP)
    .dropDuplicates()
    .where(f.col("production_status") == "lat_todo")
    .withColumnRenamed("production_status", "touchup_production_status")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep5 - Material Plant master data

# COMMAND ----------

df_material_plant_prep = df_material_plant.select(
    "material_number", "plant", "material_description"
).dropDuplicates()

# COMMAND ----------

assert (
    df_material_plant_prep.select("material_number", "plant").dropDuplicates().count()
    == df_material_plant_prep.count()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep6 - Workcenter table

# COMMAND ----------

df_workcenter_prep = df_workcenter_raw.select(*LIST_COLUMNS_WORKCENTER).dropDuplicates(["workcenter_code", "workcenter","plant"])

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 1 - Join to get SAP information on operations

# COMMAND ----------

df_wo_ope_transf = (
    df_wo_ope_raw.join(
        df_allocated_time_per_ope_prep,
        ["work_order", "work_order_operation"],
        how="left",
    )
).withColumn(
    "global_time_allocated_hc",
    f.try_divide(f.col("global_time_allocated_min"), f.lit(60)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 2 - Get spend time per operation

# COMMAND ----------

df_wo_ope_transf = (
    df_wo_ope_transf.join(
        df_hqa_prep, on=["work_order", "work_order_operation"], how="left"
    )
).withColumn("ope_spent_time_min", f.col("ope_spent_time_hc") * 60)

# COMMAND ----------

# MAGIC %md
# MAGIC Convert SAP time in HRS

# COMMAND ----------

df_wo_ope_transf = df_wo_ope_transf.withColumn(
    "SAP_total_time_hrs", f.try_divide(f.col("SAP_TOTAL_TIME"), f.lit(60))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 3 - Get work order (header) information

# COMMAND ----------

df_wo_ope_transf = df_wo_ope_transf.join(df_wo_prep, on="work_order", how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 4 - Create concat WO Ope 

# COMMAND ----------

df_wo_ope_transf = df_wo_ope_transf.withColumn(
    "WO_OPE_key", f.concat_ws("-", f.col("work_order"), f.col("work_order_operation"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 5 - Enrichment of "operation status" 
# MAGIC - in the data: CLOSED / STARTED / READY TO START
# MAGIC - to be added: TOUCH UP IN PROGRESS / NOT STARTED / PAUSED
# MAGIC
# MAGIC For that, creation of a column operation_status_transf that modify operation_status to get
# MAGIC - status TOUCHUP when there is a touch up in progress 
# MAGIC - keep READY TO START only for the first operation ready to start of the work order, then NOT STARTED
# MAGIC - get the status PAUSED from an other column

# COMMAND ----------

df_wo_ope_transf = df_wo_ope_transf.withColumn(
    "partition_for_rn",
    f.when(f.col("operation_status") == "READY_TO_START", f.col("work_order")),
)

window_spec = Window.partitionBy("partition_for_rn").orderBy(
    f.lpad(f.col("work_order_operation"), 3, "0")
)

df_wo_ope_transf = df_wo_ope_transf.withColumn(
    "_tmp_row_status",
    f.when(
        f.col("operation_status") == "READY_TO_START", f.row_number().over(window_spec)
    ),
)

# COMMAND ----------

df_wo_ope_transf = df_wo_ope_transf.join(
    df_touchup_prep, ["work_order", "work_order_operation"], how="left"
)

# COMMAND ----------

df_wo_ope_transf = df_wo_ope_transf.withColumn(
    "operation_status_transf",
    f.when(f.col("touchup_production_status") == "lat_todo", "TOUCHUP")
    .when(
        (f.col("_tmp_row_status") > 1) & ~(f.col("plant").startswith("2")),
        "NOT STARTED",
    )
    .otherwise(f.col("operation_status")),
).drop("_tmp_row_status", "partition_for_rn")

# COMMAND ----------

w = Window.partitionBy("work_order").orderBy("_meta_id")

df_wo_ope_transf = df_wo_ope_transf.withColumn(
    "_tmp_prior_not_closed",
    f.max(
        f.when(f.col("operation_status_transf") != "CLOSED", f.lit(1)).otherwise(
            f.lit(0)
        )
    ).over(w.rowsBetween(Window.unboundedPreceding, -1)),
)

df_wo_ope_transf = df_wo_ope_transf.withColumn(
    "operation_status_transf",
    f.when(
        (f.col("operation_status_transf") == "READY_TO_START")
        & (f.col("_tmp_prior_not_closed") > 0)
        & ~(f.col("plant").startswith("2")),
        f.lit("NOT STARTED"),
    ).otherwise(f.col("operation_status_transf")),
).drop("_tmp_prior_not_closed")

# COMMAND ----------

df_wo_ope_transf = df_wo_ope_transf.withColumn(
    "operation_status_transf",
    f.when(
        (f.col("is_operation_pause") == True)
        & (f.col("operation_status") == "STARTED"),
        f.lit("PAUSED"),
    ).otherwise(f.col("operation_status_transf")),
)

# COMMAND ----------

df_wo_ope_transf = df_wo_ope_transf.join(
    df_material_plant_prep, ["material_number", "plant"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 6 - Enrich with workcenter information

# COMMAND ----------

df_wo_ope_transf = df_wo_ope_transf.withColumnRenamed("workcenter", "workcenter_code")

# COMMAND ----------

df_wo_ope_transf = df_wo_ope_transf.join(
    df_workcenter_prep, ["workcenter_code", "plant"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

df_wo_ope_transf = df_wo_ope_transf.drop(*LIST_COL_NOT_EXPOSED)

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.production.work_order_operation_mes",
    df=df_wo_ope_transf,
    mode="overwrite",
    overwrite_schema=True,
)
