# Databricks notebook source
# MAGIC
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The goal of this notebook is to create the gold table of the object tool inside MES from the silver table. 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - {PIPELINE_READ_ENV}_silver.production.tool_mes
# MAGIC - {PIPELINE_READ_ENV}_silver.production.work_order_operation_mes
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.production.tool_mes
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

from leap_utils.data_asset import table_utils

from pyspark.sql import functions as f

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Input table

# COMMAND ----------

df_tool_raw = spark.read.table(f"{PIPELINE_READ_ENV}_silver.production.tool_mes")

# COMMAND ----------

df_wo_ope_mes = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.production.work_order_operation_mes"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

LIST_COL_NOT_EXPOSED = [col for col in df_tool_raw.columns if col.startswith("_")]

# COMMAND ----------

LIST_COL_WO_OPE_MES = ["work_order", "work_order_operation", "SAP_TOOLS"]

# COMMAND ----------

# MAGIC %md
# MAGIC #Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - WO OPE MES table

# COMMAND ----------

df_wo_ope_mes_prep = df_wo_ope_mes.select(*LIST_COL_WO_OPE_MES)

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 1 - Get SAP TOOLS information per WO OPE

# COMMAND ----------

df_tool_transf = df_tool_raw.join(
    df_wo_ope_mes_prep, ["work_order", "work_order_operation"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 2 - Create concat WO Ope

# COMMAND ----------

df_tool_transf = df_tool_transf.withColumn(
    "WO_OPE_key", f.concat_ws("-", f.col("work_order"), f.col("work_order_operation"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 3 - Drop columns

# COMMAND ----------

df_tool_transf = df_tool_transf.drop(*LIST_COL_NOT_EXPOSED)

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.production.tool_mes",
    df=df_tool_transf,
    mode="overwrite",
    overwrite_schema=True,
)
