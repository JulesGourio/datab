# Databricks notebook source
# MAGIC
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The goal of this notebook is to create the silver table of touch up made on work order operation based on MES data. 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - {REFERENCE_READ_ENV}_bronze.mes.retouch_latest
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_silver.production.retouch_mes
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

from leap_utils.data_asset import table_utils

from pyspark.sql import functions as f

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Input table

# COMMAND ----------

df_retouch_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.mes.retouch_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

DICT_COLUMN_RENAMING = {
    "id": "touchup_id",
    "operation": "work_order_operation",
}

# COMMAND ----------

LIST_DATE_COL = [
    "production_date",
    "inspection_date",
    "creation_date",
    "modification_date",
    "end_date",
]

# COMMAND ----------

# MAGIC %md
# MAGIC #Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep1 - Date casting

# COMMAND ----------

df_retouch_prep = df_retouch_raw
for col in LIST_DATE_COL:
    df_retouch_prep = df_retouch_prep.withColumn(
        col, f.try_to_timestamp(f.col(col), f.lit("yyyy-MM-dd HH:mm:ss.SSSSSS"))
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Renaming columns

# COMMAND ----------

df_retouch_transf = df_retouch_prep.withColumnsRenamed(DICT_COLUMN_RENAMING)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Cleaning

# COMMAND ----------

df_retouch_transf = table_utils.remove_leading_zeros(
    df_retouch_transf, ["work_order_operation", "operation_origin"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_silver.production.touchup_mes",
    df=df_retouch_transf,
    mode="overwrite",
    overwrite_schema=True,
)
