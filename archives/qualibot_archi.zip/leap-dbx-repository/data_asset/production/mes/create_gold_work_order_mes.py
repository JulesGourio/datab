# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The goal of this notebook is to create the gold table from the silver on work order (header) of MES line. 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - {PIPELINE_READ_ENV}_silver.production.work_order_mes
# MAGIC - {REFERENCE_READ_ENV}_gold.production.infocenter_hqa
# MAGIC - {REFERENCE_READ_ENV}_gold.finance.profit_center_exposed
# MAGIC - {REFERENCE_READ_ENV}_gold.production.workcenter_exposed
# MAGIC - {REFERENCE_READ_ENV}_gold.production.sap_work_order_basics_latest_exposed
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.production.work_order_mes
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

from leap_utils.data_asset import table_utils
from pyspark.sql import functions as f

from pyspark.sql.types import StringType

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Input table

# COMMAND ----------

df_wo_raw = spark.read.table(f"{PIPELINE_READ_ENV}_silver.production.work_order_mes")

# COMMAND ----------

df_pc_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed")

# COMMAND ----------

df_workcenter_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.production.workcenter_exposed"
)

# COMMAND ----------

df_wo_sap_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.production.sap_work_order_basics_latest_exposed"
)

# COMMAND ----------

df_hqa_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.production.infocenter_hqa")

# COMMAND ----------

df_paired_wo = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.mes.paired_wo_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

LIST_COL_NOT_EXPOSED = [col for col in df_wo_raw.columns if col.startswith("_")]

# COMMAND ----------

# MAGIC %md
# MAGIC #Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep - Functions 

# COMMAND ----------

def extract_last_5_digits(s):
    import re

    if s is None:
        return None

    digits = re.findall(r"\d+", s)
    if not digits:
        return None

    last_digits = digits[-1]

    return last_digits[-5:] if len(last_digits) >= 5 else last_digits

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep1 - SAP WO table

# COMMAND ----------

LIST_COL_WO_SAP = [
    "WO_Number",
    "End_Planned_Date",
    "Start_Planned_Date",
    "End_Scheduled_Date",
    "Start_Scheduled_Date",
    "Real_Start_Date",
    "Real_End_Date",
    "Real_Delivery_Date",
    "Real_Launching_Date",
    "Order_Type",
    "Quantity_Ordered",
    "Quantity_Delivered",
    "Quantity_Scrapped",
    "WO_Status",
    "WO_Status_System",
]

# COMMAND ----------

df_wo_sap_prep = (
    df_wo_sap_raw.select(*LIST_COL_WO_SAP)
    .withColumnsRenamed({"WO_Number": "work_order", "Order_Type": "work_order_type"})
    .dropDuplicates(["work_order"])
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep2 - Profit Center table

# COMMAND ----------

LIST_COL_PC = [
    "Profit_Center_short",
    "Customer_Group",
    "Aircraft_product",
    "Short_Description",
]
DICT_RENAMING_PC = {
    "Profit_Center_short": "profit_center",
    "Short_Description": "profit_center_description",
    "Customer_Group": "program_customer",
}

# COMMAND ----------

df_pc_prep = (
    df_pc_raw.select(*LIST_COL_PC).dropDuplicates().withColumnsRenamed(DICT_RENAMING_PC)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep3 - Workcenter table

# COMMAND ----------

LIST_COLUMNS_WORKCENTER = ["workcenter_code", "workcenter", "plant"]

# COMMAND ----------

df_workcenter_prep = (
    df_workcenter_raw.select(*LIST_COLUMNS_WORKCENTER)
    .dropDuplicates()
    .withColumnsRenamed(
        {"workcenter_code": "first_workcenter_code", "workcenter": "first_workcenter"}
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep4 - HQA infocenter table

# COMMAND ----------

df_hqa_prep = df_hqa_raw.groupBy("work_order").agg(
    f.sum("spent_times_hc").alias("WO_total_spent_time_hc")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Join with SAP WO table

# COMMAND ----------

df_wo_raw = df_wo_raw.withColumnRenamed("SAP_FIRST_LOCATION", "first_workcenter_code")

# COMMAND ----------

df_wo_transf = (
    df_wo_raw.join(df_wo_sap_prep, on="work_order", how="left")
    .join(df_pc_prep, on="profit_center", how="left")
    .join(df_hqa_prep, on="work_order", how="left")
    .join(
        df_workcenter_prep,
        ["first_workcenter_code", "plant"],
        how="left",
    )
)

# COMMAND ----------

# MAGIC %md 
# MAGIC ##Tr2 - Extraction from the OTP to get the aircraft rank. 

# COMMAND ----------

extract_udf = f.udf(extract_last_5_digits, StringType())

df_wo_transf = df_wo_transf.withColumn(
    "segment",
    f.when(
        f.col("WBS_Code").rlike(r"^\d+[A-Z]*-\d+-"),
        f.regexp_extract(f.col("WBS_Code"), r"^\d+[A-Z]*-(\d+)-", 1),
    )
    .when(
        f.col("WBS_Code").rlike(r"RA-[A-Z0-9]+/\d+"),
        f.regexp_extract(f.col("WBS_Code"), r"/(\d+)-", 1),
    )
    .when(
        f.col("WBS_Code").rlike(r"RA-[A-Z]+\d+-BG"),
        f.regexp_extract(f.col("WBS_Code"), r"RA-[A-Z]+(\d+)-BG", 1),
    )
    .when(
        # Extract the sequence between RA- and the "-" or the end
        f.col("WBS_Code").rlike(r"RA-([A-Z0-9]+)(-|$)"),
        f.regexp_extract(f.col("WBS_Code"), r"RA-([A-Z0-9]+)(-|$)", 1),
    )
    .otherwise(None),
)

df_wo_transf = df_wo_transf.withColumn(
    "aircraft_rank", extract_udf(f.col("segment"))
).drop("segment")

# COMMAND ----------

df_wo_transf = df_wo_transf.withColumn(
    "aircraft_rank", f.lpad(f.col("aircraft_rank"), 5, "0")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr3 - Get the aircraft rank of the paired work order, when exists

# COMMAND ----------

df_paired_wo_prep = df_paired_wo.select("wonum_target", "wonum_source").dropDuplicates()
df_otp_wo = df_wo_transf.select("work_order", "aircraft_rank").dropDuplicates()
df_otp_wo_source = df_otp_wo.withColumnsRenamed(
     {"work_order": "wonum_source", "aircraft_rank": "aircraft_rank_wosource"}
)
df_otp_wo_target = df_otp_wo.withColumnsRenamed(
     {"work_order": "wonum_target", "aircraft_rank": "aircraft_rank_wotarget"}
)
 
df_paired_wo_prep = df_paired_wo_prep.join(
    df_otp_wo_source, on="wonum_source", how="left"
).join(
    df_otp_wo_target, on="wonum_target", how="left"
)

df_paired_wo_prep = df_paired_wo_prep.dropDuplicates(["wonum_source"])

df_wo_transf = df_wo_transf.join(
    df_paired_wo_prep,
    df_wo_transf.work_order == df_paired_wo_prep.wonum_source,
    how="left",
)

df_wo_transf = df_wo_transf.withColumn(
    "aircraft_rank",
    f.coalesce(
        f.col("aircraft_rank"),
        f.col("aircraft_rank_wosource"),
        f.col("aircraft_rank_wotarget"),
    ),
).drop("aircraft_rank_wotarget", "aircraft_rank_wosource")

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.production.work_order_mes",
    df=df_wo_transf,
    mode="overwrite",
    overwrite_schema=True,
)
