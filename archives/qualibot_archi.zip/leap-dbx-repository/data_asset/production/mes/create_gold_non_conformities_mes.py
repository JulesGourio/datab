# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The goal of this notebook is to support the integration of eNC inside MES that allows having tracability of non conformities. 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - {REFERENCE_READ_ENV}_gold.production.work_order_mes
# MAGIC - {REFERENCE_READ_ENV}_gold.quality.non_conformities_enc
# MAGIC - {REFERENCE_READ_ENV}_bronze.mes.enonconformity_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.mes.enonconformity_tool_latest
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.production.non_conformities_enc_mes
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

from leap_utils.data_asset import table_utils

from pyspark.sql import functions as f
from pyspark.sql.window import Window
from datetime import datetime

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Input table

# COMMAND ----------

df_wo_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.production.work_order_mes")

# COMMAND ----------

df_nc_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.quality.non_conformities_enc")

# COMMAND ----------

df_enc_mes_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.mes.enonconformity_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration 

# COMMAND ----------

LIST_BRONZE_COL_ENC_MES = [
    c for c in df_enc_mes_raw.columns if c.startswith("mes_")
] + ["non_conformity_id", "product", "created_by"]

# COMMAND ----------

COL_WO_MES = ["work_order", "WO_Status", "material_number", "material_description"]

# COMMAND ----------

# MAGIC %md
# MAGIC #Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep1 - MES bronze NC table

# COMMAND ----------

df_enc_mes_prep = df_enc_mes_raw.select(*LIST_BRONZE_COL_ENC_MES).withColumnRenamed(
    "product", "work_order"
)

# COMMAND ----------

df_enc_mes_prep = df_enc_mes_prep.na.replace("", None)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep2 - MES WO table

# COMMAND ----------

df_wo_prep = df_wo_raw.select(*COL_WO_MES)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep3 - eNC gold table

# COMMAND ----------

df_nc_prep = df_nc_raw.drop('created_by')

# COMMAND ----------

# MAGIC %md
# MAGIC #Transformation

# COMMAND ----------

df_nc_transf = df_nc_prep.join(df_enc_mes_prep, ["non_conformity_id"], how="inner")

# COMMAND ----------

df_nc_transf = df_nc_transf.join(df_wo_prep, ["work_order"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.production.non_conformities_enc_mes",
    df=df_nc_transf,
    mode="overwrite",
    overwrite_schema=True,
)
