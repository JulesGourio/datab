# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The goal of this table is to clean the work order operation MES bronze table to obtain a work order operation silver table on MES line.  
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - {REFERENCE_READ_ENV}_bronze.mes.operation_latest
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_silver.production.work_order_operation_mes
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

from leap_utils.data_asset import table_utils

from pyspark.sql import functions as f
from pyspark.sql.window import Window
from datetime import datetime


from pyspark.sql.functions import udf

from pyspark.sql.functions import from_json
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    ArrayType,
    DoubleType,
    MapType,
    LongType,
)

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

df_operation = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.mes.operation_latest")


# COMMAND ----------

# MAGIC %md
# MAGIC # Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Extract information from datasap

# COMMAND ----------

schema = StructType(
    [
        StructField("STATUS", ArrayType(StringType()), True),
        StructField("OP_TYPE", StringType(), True),
        StructField("END_DATE", StringType(), True),
        StructField("BEGIN_DATE", StringType(), True),
        StructField("STAFF_TIME", DoubleType(), True),
        StructField("TOTAL_TIME", DoubleType(), True),
        StructField("DESCRIPTION", StringType(), True),
        StructField("INSTRUCTION", StringType(), True),
        StructField("WORK_CENTER", StringType(), True),
        StructField("MACHINE_TIME", DoubleType(), True),
        StructField("STAFF_TIME_MIN", DoubleType(), True),
        StructField("MACHINE_TIME_MIN", DoubleType(), True),
        StructField("PREPARATION_TIME", DoubleType(), True),
        StructField("STAFF_TIME_UNITY", StringType(), True),
        StructField("TOTAL_TIME_UNITY", StringType(), True),
        StructField("MACHINE_TIME_UNITY", StringType(), True),
        StructField("PREPARATION_TIME_MIN", DoubleType(), True),
        StructField("PREPARATION_TIME_UNITY", StringType(), True),
        StructField("PROCESS_IMPROVEMENT_TIME", DoubleType(), True),
        StructField("PROCESS_IMPROVEMENT_TIME_MIN", DoubleType(), True),
        StructField("COMPONENTS", ArrayType(MapType(StringType(), StringType())), True),
        StructField("TOOLS", ArrayType(MapType(StringType(), StringType())), True),
    ]
)

df_operation_parsed = df_operation.withColumn(
    "parsed_data_sap", from_json(f.col("datasap"), schema)
)

df_operation_extracted = df_operation_parsed.select(
    "*",
    *[
        f.col(f"parsed_data_sap.{field.name}").alias(f"SAP_{field.name}")
        for field in df_operation_parsed.schema["parsed_data_sap"].dataType.fields
    ],
).drop("parsed_data_sap")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - Extract information from datacustom

# COMMAND ----------

df_operation_extracted = df_operation_extracted.withColumn(
    "is_operation_pause",
    f.get_json_object(f.col("datacustom"), "$.isOperationPaused").try_cast("boolean"),
).withColumn(
    "is_operation_pause",
    f.when(
        ((f.col("is_operation_pause").isNull()) | (f.col("is_operation_pause") == False)),
        f.lit(False),
    ).otherwise(f.lit(True)),
)

# COMMAND ----------

df_operation_extracted = df_operation_extracted.withColumn(
    "additional_comment",
    f.get_json_object(f.col("datacustom"), "$.COMPL_INFO"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 3 - Keep only pertinent data for status

# COMMAND ----------

# MAGIC %md
# MAGIC #Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Calculate Touch up time

# COMMAND ----------

datetime_schema = ArrayType(
    StructType(
        [
            StructField("state", StringType()),
            StructField("period", LongType()),
            StructField("datetime", LongType()),
            StructField("username", StringType()),
        ]
    )
)

# COMMAND ----------

def calculate_touchup_time(events):
    if not events:
        return 0.0

    total_time = 0
    current_start = None

    for event in events:
        if event is None:
            continue

        try:
            state = event["state"]
            ts = event["datetime"]
        except (KeyError, TypeError):
            continue

        if state is None or ts is None:
            continue

        if "TOUCHUP" in state:
            if state.endswith("STARTED"):
                current_start = ts
            elif (
                state.endswith("PAUSED") or state.endswith("STOPPED")
            ) and current_start is not None:
                total_time += ts - current_start
                current_start = None

    return float(total_time) / 1000


touchup_udf = udf(calculate_touchup_time, DoubleType())

# COMMAND ----------

df_with_json = df_operation_extracted.withColumn(
    "events", from_json("datatimes", datetime_schema)
)

df_with_touchup_time = df_with_json.withColumn(
    "touchup_time_sec", touchup_udf("events")
)

# COMMAND ----------

# MAGIC %md
# MAGIC - touch up start date
# MAGIC - touch up end date 

# COMMAND ----------

df_exploded = df_with_touchup_time.withColumn("events", f.explode("events"))

df_events = df_exploded.select(
    "work_order",
    "number",
    f.col("events.state").alias("state"),
    f.col("events.datetime").alias("datetime"),
    f.col("events.username").alias("username"),
)

touchup_start = (
    df_events.filter(f.col("state").like("%TOUCHUP_STARTED"))
    .groupBy("work_order", "number")
    .agg(f.min("datetime").alias("touchup_start"))
)

touchup_end = (
    df_events.filter(f.col("state").like("%TOUCHUP_STOPPED"))
    .groupBy("work_order", "number")
    .agg(f.max("datetime").alias("touchup_end"))
)

touchup_dates = touchup_start.join(
    touchup_end, on=["work_order", "number"], how="outer"
)

df_with_touchup_dates = df_with_touchup_time.join(
    touchup_dates, on=["work_order", "number"], how="left"
)

df_with_touchup_dates = df_with_touchup_dates.withColumn(
    "touchup_start_date",
    f.from_unixtime(f.try_divide(f.col("touchup_start"), f.lit(1000))),
).withColumn(
    "touchup_end_date",
    f.from_unixtime(f.try_divide(f.col("touchup_end"), f.lit(1000))),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Cleaning

# COMMAND ----------

BOOLEAN_COLUMNS = ["isfinal", "islocked", "conveyor", "iscontrol"]

# COMMAND ----------

for col in BOOLEAN_COLUMNS:
    df_with_touchup_dates = df_with_touchup_dates.withColumn(
        col,
        f.when(f.col(col) == f.lit("t"), f.lit(True))
        .when(f.col(col) == f.lit("f"), f.lit(False))
        .otherwise(f.col(col).try_cast("boolean")),
    )

# COMMAND ----------

DATE_COLUMNS = [
    "creation_date",
    "modification_date",
    "end_date",
    "SAP_END_DATE",
    "SAP_BEGIN_DATE",
    "touchup_start_date",
    "touchup_end_date",
]

# COMMAND ----------

for col in DATE_COLUMNS:
    df_with_touchup_dates = df_with_touchup_dates.withColumn(
        col, f.try_to_date(f.col(col), "yyyy-MM-dd HH:mm:ss.SSSSSS")
    )

# COMMAND ----------

df_with_touchup_dates = table_utils.remove_leading_zeros(
    df_with_touchup_dates, ["number"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr3 - Column renaming

# COMMAND ----------

RENAME_COLUMNS = {
    "number": "work_order_operation",
    "number_parent": "parent_work_order",
    "SAP_OP_TYPE": "work_order_type",
    "state": "operation_status",
    "SAP_WORK_CENTER": "workcenter",
    "creation_date": "operation_creation_date",
    "modification_date": "operation_modification_date",
    "end_date": "operation_end_date",
}

# COMMAND ----------

df_ope_transf = df_with_touchup_dates.withColumnsRenamed(RENAME_COLUMNS)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr4 - Business ID
# MAGIC The business ID is the concatenation of work order number and work order operation. 

# COMMAND ----------

df_ope_transf = df_ope_transf.withColumn(
    "WO_operation_ID",
    f.concat_ws("-", f.col("work_order"), f.col("work_order_operation")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_silver.production.work_order_operation_mes",
    df=df_ope_transf,
    mode="overwrite",
    overwrite_schema=True,
)
