# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Production version bronze to silver
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC
# MAGIC A production version represents a specific combination of a Bill of Materials (BOM) and a Routing for producing a material. It defines how a product is to be manufactured, specifying which components (from the BOM) and which operations (from the Routing) should be used. This allows manufacturers to manage different ways of producing the same product, accommodating variations in materials, production lines, or techniques.
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC
# MAGIC - production_version_dataset
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mkal_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_mkal
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.production.production_version

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ## SAP MKAL
# MAGIC
# MAGIC MKAL is a standard SAP Table which is used to store Production Versions of Material data.
# MAGIC The MKAL table consists of various fields, each holding specific information or linking keys about Production Versions of Material data available in SAP.

# COMMAND ----------

df_production_version = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mkal_latest"
)
df_production_version_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_mkal"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data preparation - SAP MKAL
# MAGIC
# MAGIC Rename, clean and format columns
# MAGIC

# COMMAND ----------

df_production_version_prefix = table_utils.add_prefix_to_columns(
    df_production_version, "MKAL"
)
table_utils.check_schema_of_the_header_file(df_production_version_headers)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_production_version_prefix, df_production_version_headers
)
df_production_version_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_production_version_headers
)
df_production_version_cleaned = table_utils.remove_leading_zeros(
    df=df_production_version_renamed, column_names=["material_number"]
)
df_production_version_cleaned = df_production_version_cleaned.withColumn(
    "is_locked", f.when(f.col("MKAL_mksp").isNull(), f.lit(False)).otherwise(f.lit(True))
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "production"
table = "production_version"

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}", df=df_production_version_cleaned, mode="overwrite"
)

# COMMAND ----------


