# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Quotas arrangement Bronze to Silver
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC Quota arrangements in SAP are mechanisms used to distribute probabiliy to use a production version or another.
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC -  quotas_arrangement_dataset
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.equk_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.equp_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_equk
# MAGIC - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_equp
# MAGIC
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.production.quotas_arrangement

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

from leap_utils.common import logger


# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### SAP EQUK - quotas header
# MAGIC
# MAGIC The EQUK table in SAP is part of the equipment master data, storing header information about quota arrangements for procurement and production.

# COMMAND ----------

df_quotas_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.equk_latest"
)
df_quotas_header_sap_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_equk"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### SAP EQUP - quotas items
# MAGIC
# MAGIC The EQUP table in SAP contains item-level details of the equipment used in production and maintenance processes. It provides specific information about individual equipment units.

# COMMAND ----------

df_quotas_item = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.equp_latest"
)
df_quotas_item_sap_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_equp"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data preparation - quotas header
# MAGIC
# MAGIC renamed, format and clean columns

# COMMAND ----------

df_quotas_header_prefix = table_utils.add_prefix_to_columns(df_quotas_header, "EQUK")
table_utils.check_schema_of_the_header_file(df_quotas_header_sap_header)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_quotas_header_prefix, df_quotas_header_sap_header
)
df_quotas_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_quotas_header_sap_header
)
df_quotas_header_cleaned = table_utils.remove_leading_zeros(
    df=df_quotas_header_renamed, column_names=["material_number"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data preparation - quotas items
# MAGIC
# MAGIC renamed, format and clean columns

# COMMAND ----------

df_quotas_item_prefix = table_utils.add_prefix_to_columns(df_quotas_item, "EQUP")
table_utils.check_schema_of_the_header_file(df_quotas_item_sap_header)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_quotas_item_prefix, df_quotas_item_sap_header
)
df_quotas_item_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_quotas_item_sap_header
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join quota item and header

# COMMAND ----------

df_quotas = df_quotas_header_cleaned.join(
    df_quotas_item_renamed, ["quota_number"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "production"
table = "quotas_arrangement"

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}", df=df_quotas, mode="overwrite"
)

# COMMAND ----------


