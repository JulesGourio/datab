# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Quotas arrangement silver to gold
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC Quota arrangements in SAP are mechanisms used to distribute probabiliy to use a production version or another.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - quotas_arrangement_dataset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {PIPELINE_READ_ENV}_silver.production.quotas_arrangement
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.production.quotas_arrangement
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------


from leap_utils.data_asset import table_utils

from leap_utils.common.validation import gx_validation


# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declarations

# COMMAND ----------

# MAGIC %md
# MAGIC ### DF production version silver

# COMMAND ----------

df_quotas_arrangement_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.production.quotas_arrangement"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data preparation
# MAGIC
# MAGIC Create business key bom_number / item_number / material_number

# COMMAND ----------

df_silver_business = df_quotas_arrangement_silver.withColumn(
    "business_id",
    f.concat_ws(
        "_",
        f.col("quota_number"),
        f.col("quota_item"),
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks
# MAGIC
# MAGIC **Data Type Check:**
# MAGIC
# MAGIC end_validity and start_validity Columns: We checked that these columns are of the date type to ensure that date-related operations can be performed accurately.
# MAGIC
# MAGIC **Unicity Check**
# MAGIC
# MAGIC business_id needs to be unique

# COMMAND ----------

# Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
dfgx = gx.dataset.SparkDFDataset(df_silver_business, persist=False)

# Define the red quality checks here
red_quality_check_results = [
    dfgx.expect_column_values_to_be_of_type(column="end_validity", type_="DateType"),
    dfgx.expect_column_values_to_be_of_type(column="start_validity", type_="DateType"),
    dfgx.expect_column_values_to_be_unique(column="business_id"),
]

# Validate all red quality checks, if at least one fails the job stops
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="Quality Checks passed for BOM table - RED",
    error_message="Quality checks failed for BOM table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="quotas_arrangement_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "production"
table = "quotas_arrangement"

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}", df=df_silver_business, mode="overwrite"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Leap table quotas_arrangement_exposed

# COMMAND ----------

src_full_tablename = f"{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = [
    "EQUK",
    "EQUP"
]

selected_columns = [
    col
    for col in df_silver_business.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

# COMMAND ----------


