# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Gold Material Consumption
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC Enrich material consumption table with material std and avg prices, work order details, material descriptions, and hourly rates for labor components.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC Components that are actually cost centers (labor hours) get their unit price from the hourly rate table instead of material prices.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Material Consumption
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver.production.material_consumption (or LMXI_material_consumption if plant-specific)
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {reference_read_env}_gold.master_data.material_plant_price_history_exposed
# MAGIC - {reference_read_env}_gold.production.work_orders_sap_exposed
# MAGIC - {reference_read_env}_gold.master_data.material_master_data_plant_exposed
# MAGIC - {reference_read_env}_gold.production.hourly_rate_exposed
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.production.material_consumption (or LMXI_material_consumption if plant-specific)

# COMMAND ----------

# MAGIC %md   
# MAGIC    
# MAGIC # Technical Debt
# MAGIC
# MAGIC     -   Quality checks limited to PK: only uniqueness and null checks on PK — no validation of value ranges, row count thresholds, or completeness ratios.
# MAGIC     -   Source `coep_latest` is pre-filtered to plant 2300 (LMXI) upstream due to volume constraints. The notebook auto-detects plant scope and prefixes the output table name (`LMXI_material_consumption` vs `material_consumption`), but this naming workaround should be removed once the full multi-plant COEP extraction is available.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils

# Logging imports 
from leap_utils.common import logger

# Quality checks validation import
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

#dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Plant Scope Configuration
# MAGIC %md
# MAGIC ### Plant Scope Configuration
# MAGIC
# MAGIC Automatically determines whether the upstream silver material consumption table covers only the LMXI plant (2300) or multiple plants.
# MAGIC This drives the source and destination table names:
# MAGIC - Only plant 2300 → source: `LMXI_material_consumption`, output: `LMXI_material_consumption`
# MAGIC - Multiple plants → source: `material_consumption`, output: `material_consumption`

# COMMAND ----------

SOURCE_SCHEMA = f"{PIPELINE_WRITE_ENV}_silver.production"

# Auto-detect: if the general table exists, use it; otherwise fall back to LMXI-specific
if spark.catalog.tableExists(f"{SOURCE_SCHEMA}.material_consumption"):
    _df_source_check = spark.read.table(f"{SOURCE_SCHEMA}.material_consumption")
    MAT_CONSUMPTION_SOURCE_TABLE = "material_consumption"
    LMXI_ONLY = False
else:
    _df_source_check = spark.read.table(f"{SOURCE_SCHEMA}.LMXI_material_consumption")
    MAT_CONSUMPTION_SOURCE_TABLE = "LMXI_material_consumption"
    LMXI_ONLY = True

if LMXI_ONLY:
    DESTINATION_TABLE = "LMXI_material_consumption"
else:
    DESTINATION_TABLE = "material_consumption"

log.info(f"LMXI only: {LMXI_ONLY} | Source: {MAT_CONSUMPTION_SOURCE_TABLE} | Destination: {DESTINATION_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imp. 1 - (Pipeline) Material Consumption
# MAGIC
# MAGIC **df_mat_consumption** includes quantities consumed for production of material at component and periodic levels

# COMMAND ----------

df_mat_consumption_raw = _df_source_check

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imp. 2 - (Ref) Material Price History
# MAGIC
# MAGIC **df_material_prices** contains cost values of components at periodic level

# COMMAND ----------

df_mat_prices_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_price_history_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imp. 3 - (Ref) work order sap
# MAGIC
# MAGIC work order details. Used to get work order's material number

# COMMAND ----------

df_work_order_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.production.work_orders_sap_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imp. 4 - (Ref) material master data
# MAGIC
# MAGIC material number details. Used to get material and component descriptions

# COMMAND ----------

df_mat_master_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed")

# COMMAND ----------

# DBTITLE 1,Imp. 5 - (Ref) Hourly Rate
# MAGIC %md
# MAGIC ## Imp. 5 - (Ref) Hourly Rate
# MAGIC
# MAGIC Hourly rate per cost center and fiscal year. Used to fill unit prices for work-hour components (cost centers appearing as consumed components).

# COMMAND ----------

df_hourly_rate_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.production.hourly_rate_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Manual declarations

# COMMAND ----------

original_value_column_names = [
    "total_value_in_transaction_currency_from_transaction_currency_to_USD_in_Budget_rate_at_currency_date",
    "unit_price_in_transaction_currency_from_transaction_currency_to_USD_in_Budget_rate_at_currency_date",
    "average_unit_price_company_currency_from_company_currency_to_USD_in_Budget_rate_at_currency_date",
    "standard_unit_price_company_currency_from_company_currency_to_USD_in_Budget_rate_at_currency_date",
    "average_value_company_currency_from_company_currency_to_USD_in_Budget_rate_at_currency_date",
    "standard_value_company_currency_from_company_currency_to_USD_in_Budget_rate_at_currency_date",
]

new_value_column_names = [
    "total_value_USD",
    "unit_price_USD",
    "average_unit_price_USD",
    "standard_unit_price_USD",
    "average_value_USD",
    "standard_value_USD",
]

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pr. 1 - Work order table

# COMMAND ----------

df_work_order_prep = df_work_order_raw.select(
        f.col("work_order_number").alias("work_order"),
        f.col("material_number").alias("origin_material_number"),
        f.col("profit_center"),
        f.col("profit_center_description"),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pr. 2 - Material Master
# MAGIC
# MAGIC Two preps from the same source table: one to get the WO's produced material description (`origin_material_number`), another to get the consumed material description (`material_number`).

# COMMAND ----------

df_mat_master_prep = df_mat_master_raw.select(
    "plant",
    f.col("Material_Number").alias("origin_material_number"),
    f.col("Description").alias("origin_material_description"),
)

df_mat_master_prep2 = df_mat_master_raw.select(
    "plant",
    f.col("Material_Number").alias("material_number"),
    f.col("Description").alias("material_description"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pr. 3 - Material Price History

# COMMAND ----------

df_mat_price_hist_prep = df_mat_prices_raw.select(
    "plant",
    f.col("average_price_company_currency").alias("average_unit_price_company_currency"),
    f.col("standard_price_company_currency").alias("standard_unit_price_company_currency"),
    f.col("material_number").alias("material_number"),
    f.col("fiscal_year").alias("fiscal_year"),
    f.col("current_period").alias("period"),
    f.col("currency").alias("company_currency")
)

# fiscal_year and fiscal_period to text
df_mat_price_hist_prep = (
    df_mat_price_hist_prep
    .withColumn("fiscal_year", f.col("fiscal_year").try_cast("int").try_cast("string"))
    .withColumn("period", f.col("period").try_cast("int").try_cast("string"))
)

# COMMAND ----------

# DBTITLE 1,Pr. 4 - Hourly Rate
# MAGIC %md
# MAGIC ## Pr. 4 - Hourly Rate
# MAGIC
# MAGIC Filter and prepare hourly rates for cost centers. Only keep rows where `activity_type == cost_center` to avoid duplicates (e.g. activity_type "999" entries).

# COMMAND ----------

# Filter: keep only rows where activity_type matches cost_center (avoids duplicates)
df_hourly_rate_prep = (
    df_hourly_rate_raw
    .filter(f.col("activity_type") == f.col("cost_center"))
    .select(
        f.col("cost_center"),
        f.col("fiscal_year").try_cast("int").try_cast("string").alias("fiscal_year"),
        f.col("hourly_rate_total").alias("hourly_rate"),
        f.col("currency").alias("hourly_rate_currency"),
        f.col("cost_center_description").alias("hourly_rate_description"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 - Join prices
# MAGIC join material consumption and costs dfs

# COMMAND ----------

df_mat_prod_cost_transf1 = df_mat_consumption_raw.join(
    df_mat_price_hist_prep,
    ["plant","material_number","fiscal_year","period"],
    "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 - Get work order details

# COMMAND ----------

df_mat_prod_cost_transf2 = df_mat_prod_cost_transf1.join(df_work_order_prep, ["work_order"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 - Get material and component descriptions

# COMMAND ----------

df_mat_prod_cost_transf3 = df_mat_prod_cost_transf2.join(df_mat_master_prep, ["plant", "origin_material_number"], "left").join(df_mat_master_prep2, ["plant", "material_number"], "left")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 4 - Enrich work-hour components with hourly rates
# MAGIC For components that are actually cost centers (labor), the material price join (Tr.1) returns NULL.
# MAGIC Join with hourly_rate_exposed to fill unit prices, currency, and description.

# COMMAND ----------

# Join hourly rates for work-hour components (cost centers appearing as consumed components)
df_mat_prod_cost_transf4 = df_mat_prod_cost_transf3.join(
    df_hourly_rate_prep,
    ["cost_center", "fiscal_year"],
    "left"
)

# For rows where hourly_rate is available (component is a cost center),
# use it as unit price and fill description/currency from the hourly rate table
df_mat_prod_cost_transf4 = (
    df_mat_prod_cost_transf4
    .withColumn(
        "average_unit_price_company_currency",
        f.coalesce(f.col("hourly_rate"), f.col("average_unit_price_company_currency"))
    )
    .withColumn(
        "standard_unit_price_company_currency",
        f.coalesce(f.col("hourly_rate"), f.col("standard_unit_price_company_currency"))
    )
    .withColumn(
        "company_currency",
        f.coalesce(f.col("hourly_rate_currency"), f.col("company_currency"))
    )
    .withColumn(
        "material_description",
        f.coalesce(f.col("hourly_rate_description"), f.col("material_description"))
    )
    .drop("hourly_rate", "hourly_rate_currency", "hourly_rate_description")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 5 - Value columns
# MAGIC Get total values for average and standard prices

# COMMAND ----------

df_mat_prod_cost_transf5 = df_mat_prod_cost_transf4.withColumn(
    "average_value_company_currency",
    f.col("total_quantity") * f.col("average_unit_price_company_currency"),
).withColumn(
    "standard_value_company_currency",
    f.col("total_quantity") * f.col("standard_unit_price_company_currency"),
)

# round value to 2 decimal places
df_mat_prod_cost_transf5 = df_mat_prod_cost_transf5.withColumn(
    "average_value_company_currency",
    f.round(f.col("average_value_company_currency"), 2),
).withColumn(
    "standard_value_company_currency",
    f.round(f.col("standard_value_company_currency"), 2),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 6 - Convert Costs to USD

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 6.1 - Add currency date column (for currency exchage rates)

# COMMAND ----------

df_mat_prod_cost_transf6 = df_mat_prod_cost_transf5.withColumn(
    "currency_date",
    table_utils.safe_to_date(
        f.concat(
            f.col("fiscal_year").try_cast("int").try_cast("string"),
            f.lpad(f.col("period").try_cast("int").try_cast("string"), 2, "0"),
            f.lit("01")
        ),
        "yyyyMMdd"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 6.2 - Convert values in Transaction currency

# COMMAND ----------

df_mat_prod_cost_transf6 = table_utils.currency_conversion(
    df=df_mat_prod_cost_transf6,
    document_currency_column=f.col("transaction_currency"),
    rate_types=["Budget"],
    rate_dates=[f.col("currency_date")],
    target_currency_value="USD",
    document_amounts=[
        f.col(col) for col in ["total_value_in_transaction_currency", "unit_price_in_transaction_currency"]
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 6.3 - Convert values in company currency

# COMMAND ----------

df_mat_prod_cost_transf6 = table_utils.currency_conversion(
    df=df_mat_prod_cost_transf6,
    document_currency_column=f.col("company_currency"),
    rate_types=["Budget"],
    rate_dates=[f.col("currency_date")],
    target_currency_value="USD",
    document_amounts=[
        f.col(col) for col in ["average_unit_price_company_currency", "standard_unit_price_company_currency", "average_value_company_currency", "standard_value_company_currency"]
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 6.4 - Renaming and selecting columns

# COMMAND ----------

# rename and round columns
for old_name, new_name in zip(original_value_column_names, new_value_column_names):
    df_mat_prod_cost_transf6 = df_mat_prod_cost_transf6.withColumnRenamed(
        old_name, new_name
    ).withColumn(new_name, f.round(f.col(new_name), 2))

df_mat_prod_cost_transf6 = df_mat_prod_cost_transf6.drop("currency_date")

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_to_check = df_mat_prod_cost_transf6
col_PK = "material_consumption_ID"

gx_validation.gx_check_uniqueness(
    df=df_to_check,
    col=col_PK,
    validation_level="RED",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name=DESTINATION_TABLE,
)

gx_validation.gx_check_not_null(
    df=df_to_check,
    col=col_PK,
    validation_level="RED",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name=DESTINATION_TABLE,
)


# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Gold Material Consumption

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "production"
# DESTINATION_TABLE is defined in the Plant Scope Configuration section
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_mat_prod_cost_transf6,
    mode="overwrite",
    overwrite_schema=True
)

# Adding constraint primary key in DBX
TABLE_CONSTRAINT_NAME = f"{DESTINATION_TABLE}_PK"  # convention naming : tablename_PK
TABLE_PK_COLS = "material_consumption_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_PK_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_PK_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key (handle eventual consistency of information_schema)
    try:
        table_utils.add_table_primary_key(
            table_path=DESTINATION_TABLE_FULL_PATH,
            pk_name=TABLE_CONSTRAINT_NAME,
            columns=TABLE_PK_COLS,
        )
    except Exception as e:
        if "CONSTRAINT_ALREADY_EXISTS" not in str(e):
            raise

# COMMAND ----------

# Rule 8: Table description
spark.sql(f"""
    COMMENT ON TABLE {DESTINATION_TABLE_FULL_PATH} IS
    'Gold material consumption enriched with material prices, work order details, and material descriptions. Granularity: one row per plant-material_number-work_order-fiscal_year-period-rank combination.'
""")

# Rule 8: Column descriptions
column_comments = {
    "material_consumption_ID": "Primary key: plant-component-fiscal_year-fiscal_period-work_order-rank",
    "plant": "Manufacturing plant code",
    "work_order": "Production work order number",
    "material_number": "Material or component number consumed",
    "total_quantity": "Quantity of material consumed in the period",
    "unit_of_measure": "Unit of measurement for the consumed quantity",
    "fiscal_year": "Fiscal year of consumption",
    "period": "Fiscal period of consumption",
    "transaction_currency": "Original transaction currency code",
    "total_value_in_transaction_currency": "Total value in transaction currency",
    "unit_price_in_transaction_currency": "Unit price in transaction currency",
    "origin_material_number": "Material number produced by the work order",
    "profit_center": "Profit center associated with the work order",
    "profit_center_description": "Description of the profit center",
    "origin_material_description": "Description of the produced material",
    "material_description": "Description of the consumed material",
    "average_unit_price_company_currency": "Average unit price in company local currency",
    "standard_unit_price_company_currency": "Standard unit price in company local currency",
    "average_value_company_currency": "Total average value (qty x avg unit price) in company currency",
    "standard_value_company_currency": "Total standard value (qty x std unit price) in company currency",
    "company_currency": "Company local currency code",
    "total_value_USD": "Total value converted to USD at Budget rate at currency_date",
    "unit_price_USD": "Unit price converted to USD at Budget rate at currency_date",
    "average_unit_price_USD": "Average unit price converted to USD at Budget rate at currency_date",
    "standard_unit_price_USD": "Standard unit price converted to USD at Budget rate at currency_date",
    "average_value_USD": "Total average value converted to USD at Budget rate at currency_date",
    "standard_value_USD": "Total standard value converted to USD at Budget rate at currency_date",
}

for col_name, comment in column_comments.items():
    try:
        spark.sql(f"ALTER TABLE {DESTINATION_TABLE_FULL_PATH} ALTER COLUMN `{col_name}` COMMENT '{comment}'")
    except Exception as e:
        log.warning(f"Could not add comment to column {col_name}: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Save gold exposed table

# COMMAND ----------

dest_full_tablename = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}_exposed"

exclude_prefixes = ["COEP"]

selected_columns = [
    col
    for col in df_mat_prod_cost_transf6.columns
    if not any(col.startswith(prefix) for prefix in exclude_prefixes)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename,
    select_statement,
    replace_view=True,
)

log.info(f"The table view {dest_full_tablename} has been successfully created")
