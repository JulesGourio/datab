# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE SILVER INFOCENTER HQA
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The script creates the silver table of the infocenter from HQA.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - Input row-count block and spent-time tolerance check - see [Quality checks]
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Infocenter HQA
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {reference_read_env}_bronze.horoquartz_ingestion.infocenter_group_stack
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.production.infocenter_hqa
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC 1. Silver has no row-count-drop check against the previous load, unlike Gold's QC2 - only a
# MAGIC    fully-empty or all-invalid-date batch is caught here (see [Quality checks]).

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.validation import quality_checks
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("skip_quality_checks", "False")
SKIP_QUALITY_CHECKS = dbutils.widgets.get("skip_quality_checks").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC #Input

# COMMAND ----------

# MAGIC %md
# MAGIC ##LEAP table(s)

# COMMAND ----------

df_hqa_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.horoquartz_ingestion.infocenter_group_stack"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

OUTPUT_SILVER_TABLE_HQA_INFOCENTER = (
    f"{PIPELINE_WRITE_ENV}_silver.production.infocenter_hqa"
)

# COMMAND ----------

MIN_INPUT_ROWS = 1

# COMMAND ----------

DICT_TO_RENAME_HQA = {
    "roll_number": "employee_code",
    "employee_full_name": "employee_name",
    "initial_group": "employee_group",
    "worked_cost_center": "cost_center",
    "mo_father": "WO_father",
    "improd_": "improductivity_code",
    "reason": "absence_reason",
    "mo": "work_order",
    "ope": "operation",
    "ope_description": "operation_description",
    "article": "material_number",
    "emp_cost_center": "employee_cost_center",
    "emp_type_activitie": "employee_activity_type",
    "activitie_date": "activity_date",
    "mo_description": "WO_description",
    "article_description": "material_description",
    "workstation_descript": "workstation_description",
    "worked_cc_descriptio": "cost_center_description",
    "emp_cc_description": "employee_cost_center_description",
    "division": "plant",
    "payroll_categorie": "payroll_category",
    "order_type": "work_order_type",
    "_meta_extraction_timestamp": "extraction_timestamp",
    "_meta_file_name": "filename",
    "_meta_file_path": "filepath",
    "_meta_id": "ingestion_uid",
}

# COMMAND ----------

DATE_COLUMNS = ["date", "activity_date", "validation_date"]

# COMMAND ----------

COL_TO_CAST_IN_DOUBLE = [
    "spent_times_hc",
    "prod_times_hc",
    "improd_time_hc",
    "otp_time_hc",
    "absence_time_hc",
    "allocated_time_hc",
    "spent_time",
    "planned_time",
]

# COMMAND ----------

COLUMNS_TO_DROP = [
    "_rescued_data",
    "_meta_validity_check",
    "_meta_ingestion_timestamp",
    "_meta_file_mode",
]

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Columns renaming
# MAGIC - Basic renaming
# MAGIC - There is HM in the column names, which means "heure minutes", but it is hc in reality. Therefore, the column names with hours are changed.

# COMMAND ----------

df_hqa_prep = df_hqa_raw.drop(*COLUMNS_TO_DROP)
df_hqa_prep = df_hqa_prep.withColumnsRenamed(DICT_TO_RENAME_HQA)

# COMMAND ----------

renamed_columns = [
    (col, col[:-2] + "hc") if col.endswith("hm") else (col, col)
    for col in df_hqa_prep.columns
]

for old_col, new_col in renamed_columns:
    df_hqa_prep = df_hqa_prep.withColumnRenamed(old_col, new_col)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 -  String values cleaning

# COMMAND ----------

for col in df_hqa_prep.columns:
    df_hqa_prep = df_hqa_prep.withColumn(
        col,
        f.when(f.trim(f.col(col)) == "", f.lit(None)).otherwise(f.trim(f.col(col))),
    )


# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 3 - Date cleaning

# COMMAND ----------

for col in DATE_COLUMNS:
    df_hqa_prep = df_hqa_prep.withColumn(
        col, f.to_date(f.col(col), "dd/MM/yyyy").cast("date")
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 4 - Column values to upper

# COMMAND ----------

COL_TO_UPPER = [
    "improductivity_code",
    "event",
    "operation_description",
    "workstation_description",
]
for col in COL_TO_UPPER:
    df_hqa_prep = df_hqa_prep.withColumn(col, f.upper(f.col(col)))

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 5 - Double columns to cast

# COMMAND ----------

for col in COL_TO_CAST_IN_DOUBLE:
    df_hqa_prep = df_hqa_prep.withColumn(col, f.col(col).cast("double"))

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 6 - Cleaning leading zeros

# COMMAND ----------

COL_CLEANING_LEADING_ZEROS = ["work_order", "material_number", "operation"]

df_hqa_prep = table_utils.remove_leading_zeros(df_hqa_prep, COL_CLEANING_LEADING_ZEROS)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 7 - Lower case all column names

# COMMAND ----------

df_hqa_prep = df_hqa_prep.select(
    [f.col(col).alias(col.lower()) for col in df_hqa_prep.columns]
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Take the latest version of each data
# MAGIC The HQA data are extracted daily in full of the data for the last 40 days. Thus, the idea is to take the last version of each date data.

# COMMAND ----------

window = Window.partitionBy("date").orderBy(f.desc(f.col("extraction_timestamp")))
df_date_wd = (
    df_hqa_prep.select("date", "extraction_timestamp")
    .distinct()
    .withColumn("row_number", f.row_number().over(window))
    .filter(f.col("row_number") == 1)
    .withColumnRenamed("extraction_timestamp", "max_extraction_timestamp")
    .drop("row_number")
)

# COMMAND ----------

df_hqa_latest = (
    df_hqa_prep.join(df_date_wd, on="date", how="left")
    .filter(f.col("max_extraction_timestamp") == f.col("extraction_timestamp"))
    .drop("max_extraction_timestamp")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality checks

# COMMAND ----------

# MAGIC %md
# MAGIC ##QC1 - Input row count
# MAGIC This check always runs, even when skip_quality_checks is set to True, since it guards
# MAGIC against wiping the table rather than validating a business rule.

# COMMAND ----------

input_row_count = df_hqa_raw.count()
input_row_count_check = {"input_row_count_check": input_row_count >= MIN_INPUT_ROWS}

quality_checks.validate_and_log_quality_check_results(
    results_dict=input_row_count_check,
    validation_level="RED",
    info_message=f"HQA input row count check passed: {input_row_count} rows received.",
    error_message=(
        f"HQA input is empty ({input_row_count} rows) - overwrite blocked to avoid "
        "wiping the silver table."
    ),
    pipeline_write_env=PIPELINE_WRITE_ENV,
    expectation_type="check_input_row_count",
    log_to_event_table=True,
    log_successes=True,
    raw_result={
        "input_row_count_check": {
            "success": input_row_count >= MIN_INPUT_ROWS,
            "expectation_type": "check_input_row_count",
            "row_count": input_row_count,
        }
    },
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##QC2 - Valid batch dates present
# MAGIC Guards a distinct failure mode from QC1: rows can be present but still produce no usable batch
# MAGIC (e.g. every `date` value fails to parse into a real date). Always runs, not gated by
# MAGIC skip_quality_checks.

# COMMAND ----------

dates_in_batch = df_hqa_latest.select("date").distinct().collect()
dates_in_batch = [row["date"] for row in dates_in_batch if row["date"] is not None]

valid_batch_dates_check = {"valid_batch_dates_check": len(dates_in_batch) > 0}

quality_checks.validate_and_log_quality_check_results(
    results_dict=valid_batch_dates_check,
    validation_level="RED",
    info_message=f"HQA valid batch dates check passed: {len(dates_in_batch)} date(s) in batch.",
    error_message=(
        "HQA batch has no valid dates - overwrite blocked to avoid wiping the silver table."
    ),
    pipeline_write_env=PIPELINE_WRITE_ENV,
    expectation_type="check_valid_batch_dates",
    log_to_event_table=True,
    log_successes=True,
    raw_result={
        "valid_batch_dates_check": {
            "success": len(dates_in_batch) > 0,
            "expectation_type": "check_valid_batch_dates",
            "date_count": len(dates_in_batch),
        }
    },
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##QC3 - Spent time trend
# MAGIC If we acquire the data meanwhile the infocenter calculation in Horoquartz, we will receive incomplete data. Therefore, we will compare spent time to ensure the spent time of the current month is increasing after each acquisition. However, a small tolerance is added because it is possible to make corrections on clocking for the current month.\
# MAGIC Next step: the job fails only when the tolerance is not passed. A next step would be to have an orange quality check to flag when it is valid because of the tolerance set.
# MAGIC

# COMMAND ----------

if not SKIP_QUALITY_CHECKS:
    last_timestamps = (
        df_hqa_prep.select("extraction_timestamp")
        .distinct()
        .orderBy(f.col("extraction_timestamp").desc())
        .limit(2)
        .collect()
    )

    if len(last_timestamps) < 2:
        log.info("⚠️ Not enough data to compare (min 2 needed)")
    else:
        last_extract = last_timestamps[0]["extraction_timestamp"]
        previous_extract = last_timestamps[1]["extraction_timestamp"]

        df_agg_to_check = (
            df_hqa_prep.filter(
                f.col("extraction_timestamp").isin([last_extract, previous_extract])
            )
            .where(f.col("event") == "PROD")
            .where(f.month(f.col("date")) == f.month(f.date_sub(f.current_date(), 2)))
            .groupBy("extraction_timestamp", "employee_group")
            .agg(f.sum("spent_times_hc").alias("total_spent_time_hc"))
        )

        last_extract_df = df_agg_to_check.where(
            f.col("extraction_timestamp") == last_extract
        ).select(
            "employee_group", f.col("total_spent_time_hc").alias("last_spent_time")
        )
        previous_extract_df = df_agg_to_check.where(
            f.col("extraction_timestamp") == previous_extract
        ).select(
            "employee_group", f.col("total_spent_time_hc").alias("previous_spent_time")
        )

        comparison_df = (
            last_extract_df.join(
                previous_extract_df, on="employee_group", how="full_outer"
            )
            .withColumn(
                "difference", f.col("last_spent_time") - f.col("previous_spent_time")
            )
            .withColumn(
                "is_valid",
                f.when(
                    f.col("last_spent_time") >= f.col("previous_spent_time"), True
                ).otherwise(False),
            )
            .withColumn(
                "is_valid_with_tolerance",
                f.when(
                    (f.col("is_valid") == False)
                    & (
                        (f.col("previous_spent_time") - f.col("last_spent_time"))
                        / (f.col("last_spent_time"))
                        > 0.05
                    ),
                    False,
                ).otherwise(True),
            )
            .orderBy("employee_group")
        )

        invalid_groups = comparison_df.filter(f.col("is_valid") == False)
        invalid_groups_with_tolerance = comparison_df.filter(
            f.col("is_valid_with_tolerance") == False
        )
        invalid_count_with_tolerance = invalid_groups_with_tolerance.count()

        if invalid_count_with_tolerance != 0:
            dbutils.jobs.taskValues.set(key="quality_check_exception", value=True)
            invalid_groups_with_tolerance.display()
        else:
            dbutils.jobs.taskValues.set(key="quality_check_exception", value=False)

        # Préparer les résultats pour la fonction de validation
        result_tolerance_check = {
            "spent_time_increase_check": invalid_count_with_tolerance == 0
        }
        raw_result_tolerance_check = {
            "spent_time_increase_check": {
                "success": invalid_count_with_tolerance == 0,
                "expectation_type": "check_spent_time_increase_tolerance",
                "invalid_count": invalid_count_with_tolerance,
                "tolerance": "5%",
                "description": "Increase of spent time per employee group for the current month between the two last extractions",
            }
        }

        # Utiliser la fonction de validation
        validation_level = "RED"
        quality_checks.validate_and_log_quality_check_results(
            results_dict=result_tolerance_check,
            validation_level=validation_level,
            info_message="Spent time increase check passed: no abnormal increase detected (tolerance 5%)",
            error_message=f"QC not passed: increase of spent time per employee group for the current month between the two last extractions - including a tolerance of 5%. {invalid_count_with_tolerance} invalid group(s) detected.",
            pipeline_write_env=PIPELINE_WRITE_ENV,
            expectation_type="check_spent_time_increase_tolerance",
            log_to_event_table=True,
            log_successes=True,
            raw_result=raw_result_tolerance_check,
        )

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

log.info("SILVER – Replaced partitions:")
for d in dates_in_batch:
    log.info(f"   • {d}")

quoted = ",".join([f"'{d}'" for d in dates_in_batch])
replace_where = f"date IN ({quoted})"

table_utils.save_table(
    dest_table=OUTPUT_SILVER_TABLE_HQA_INFOCENTER,
    df=df_hqa_latest,
    mode="overwrite",
    overwrite_schema=False,
    cluster_cols="date",
    merge_schema=True,
    replace_where=replace_where,
)
