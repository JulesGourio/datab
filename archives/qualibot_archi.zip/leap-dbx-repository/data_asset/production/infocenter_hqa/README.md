# Infocenter HQA — Data Asset Notebooks

This folder contains the data asset notebooks for the **Horoquartz (HQA) Infocenter** production pipeline. It processes time & attendance data from the Horoquartz system, enriches it with SAP master data, and produces Silver/Gold tables for production analytics.

There are **two independent data asset flows** in this folder:

1. **Infocenter flow** (Silver + Gold, standalone jobs): `infocenter_group` → `infocenter_hqa` (Silver) → `infocenter_hqa` (Gold)
2. **ATPEVEN flow** (DLT, inside ingestion pipeline): `atpeven_latest` → `horoquartz_atpeven` (Silver) → `horoquartz_atpeven` (Gold)
3. **Bulgaria view** (proj layer): `infocenter_group_latest` → `infocenter_group_bulgaria_view`

## Architecture

```mermaid
flowchart LR
    subgraph BRONZE["BRONZE (horoquartz_ingestion)"]
        b1[/"infocenter_group_stack"/]
        b2[/"atpeven_latest"/]
        b3[/"infocenter_group_latest"/]
    end

    subgraph INFOCENTER_FLOW["Infocenter Flow (standalone job)"]
        s1{{"create_silver_infocenter_hqa"}}
        g1{{"create_gold_infocenter_hqa"}}
        s1 --> g1
    end

    subgraph ATPEVEN_FLOW["ATPEVEN Flow (inside DLT pipeline)"]
        s2{{"horoquartz_data_asset<br/>DLT_notebook"}}
    end

    subgraph BULGARIA["Bulgaria View (Job 2)"]
        s3{{"horoquartz_bulgaria_view"}}
    end

    subgraph SILVER["SILVER (production)"]
        sv1[("infocenter_hqa")]
        sv2[("horoquartz_atpeven")]
    end

    subgraph GOLD["GOLD (production)"]
        gd1[("infocenter_hqa")]
        gd2[("horoquartz_atpeven")]
    end

    subgraph PROJ["PROJ (horoquartz)"]
        pj1[/"infocenter_group<br/>_bulgaria_view"/]
    end

    b1 --> s1
    s1 --> sv1
    sv1 --> g1
    g1 --> gd1

    b2 --> s2
    s2 --> sv2
    sv2 --> s2
    s2 --> gd2

    b3 --> s3
    s3 --> pj1

    style b1 fill:#e1f5fe,stroke:#01579b,color:#1a1a1a
    style b2 fill:#e1f5fe,stroke:#01579b,color:#1a1a1a
    style b3 fill:#e1f5fe,stroke:#01579b,color:#1a1a1a
    style s1 fill:#f3e5f5,stroke:#7b1fa2,color:#1a1a1a
    style s2 fill:#f3e5f5,stroke:#7b1fa2,color:#1a1a1a
    style s3 fill:#f3e5f5,stroke:#7b1fa2,color:#1a1a1a
    style g1 fill:#f3e5f5,stroke:#7b1fa2,color:#1a1a1a
    style sv1 fill:#fff3e0,stroke:#e65100,color:#1a1a1a
    style sv2 fill:#fff3e0,stroke:#e65100,color:#1a1a1a
    style gd1 fill:#fce4ec,stroke:#c62828,color:#1a1a1a
    style gd2 fill:#fce4ec,stroke:#c62828,color:#1a1a1a
    style pj1 fill:#e8eaf6,stroke:#283593,color:#1a1a1a
```

## Data Flow — Infocenter (Silver + Gold)

```mermaid
flowchart TB
    subgraph PIPELINE[" "]
        direction TB
        b1[("infocenter_group_stack<br/>bronze")]
        s1{{"create_silver_infocenter_hqa"}}
        sv1[("infocenter_hqa<br/>silver")]
        g1{{"create_gold_infocenter_hqa"}}
        gd1[("infocenter_hqa<br/>gold")]

        b1 --> s1
        s1 --> sv1
        sv1 --> g1
        g1 --> gd1
    end

    subgraph REF["REFERENCE DATA"]
        r1[("plant_master_data<br/>_latest_exposed")]
        r2[("material_master_data<br/>_plant_exposed")]
        r3[("profit_center<br/>_exposed")]
        r4[("sap_work_order_basics<br/>_latest_exposed")]
        r5[("afru_latest")]
        r6[("afvc_latest")]
        r7[("jest_latest")]
        r8[("tj02t_latest")]
    end

    r1 -.-> g1
    r2 -.-> g1
    r3 -.-> g1
    r4 -.-> g1
    r5 -.-> g1
    r6 -.-> g1
    r7 -.-> g1
    r8 -.-> g1

    classDef dataTable fill:#e1f5fe,stroke:#01579b,stroke-width:2px,color:#1a1a1a
    classDef silver fill:#fff3e0,stroke:#e65100,stroke-width:2px,color:#1a1a1a
    classDef gold fill:#fce4ec,stroke:#c62828,stroke-width:2px,color:#1a1a1a
    classDef script fill:#f3e5f5,stroke:#7b1fa2,stroke-width:2px,color:#1a1a1a
    classDef enrichment fill:#c8e6c9,stroke:#2e7d32,stroke-width:1px,color:#1a1a1a

    class b1 dataTable
    class sv1 silver
    class gd1 gold
    class s1,g1 script
    class r1,r2,r3,r4,r5,r6,r7,r8 enrichment
```

## Data Flow — ATPEVEN (DLT)

```mermaid
flowchart TB
    subgraph PIPELINE[" "]
        direction TB
        b2[("atpeven_latest<br/>bronze")]
        s2{{"horoquartz_data_asset<br/>DLT_notebook"}}
        sv2[("horoquartz_atpeven<br/>silver")]
        gd2[("horoquartz_atpeven<br/>gold")]

        b2 --> s2
        s2 --> sv2
        sv2 --> s2
        s2 --> gd2
    end

    subgraph REF["REFERENCE DATA"]
        tz[("mapping_plant_timezone<br/>manual_input")]
    end

    tz -.-> s2

    classDef dataTable fill:#e1f5fe,stroke:#01579b,stroke-width:2px,color:#1a1a1a
    classDef silver fill:#fff3e0,stroke:#e65100,stroke-width:2px,color:#1a1a1a
    classDef gold fill:#fce4ec,stroke:#c62828,stroke-width:2px,color:#1a1a1a
    classDef script fill:#f3e5f5,stroke:#7b1fa2,stroke-width:2px,color:#1a1a1a
    classDef enrichment fill:#c8e6c9,stroke:#2e7d32,stroke-width:1px,color:#1a1a1a

    class b2 dataTable
    class sv2 silver
    class gd2 gold
    class s2 script
    class tz enrichment
```

## Notebooks

### 1. `create_silver_infocenter_hqa.py`

Creates the Silver infocenter table from the Bronze stacked data.

| Property | Value |
|----------|-------|
| **Input** | `{reference_read_env}_bronze.horoquartz_ingestion.infocenter_group_stack` |
| **Output** | `{pipeline_write_env}_silver.production.infocenter_hqa` |
| **Save mode** | Overwrite with `replace_where` on `date` partitions |
| **Cluster by** | `date` |
| **LEAP utils** | `table_utils.save_table()`, `table_utils.remove_leading_zeros()`, `quality_checks.validate_and_log_quality_check_results()` |

**Widgets:**

| Widget | Default | Description |
|--------|---------|-------------|
| `pipeline_write_env` | `dev` | Write environment |
| `pipeline_read_env` | `dev` | Read environment |
| `reference_read_env` | `dev` | Reference data environment |
| `skip_quality_checks` | `False` | Skip QC3 (spent-time trend) for backfills - QC1/QC2 (empty-input block) always run regardless |

**Transformations:**

| Step | Description |
|------|-------------|
| Prep 1 — Column renaming | 24 columns renamed (see `DICT_TO_RENAME_HQA`), `_hm` suffix → `_hc` (hours centesimals) |
| Prep 2 — String cleaning | Trim all columns, empty strings → `NULL` |
| Prep 3 — Date parsing | `dd/MM/yyyy` → DATE for `date`, `activity_date`, `validation_date` |
| Prep 4 — Upper case | `improductivity_code`, `event`, `operation_description`, `workstation_description` |
| Prep 5 — Cast to double | 8 time columns: `spent_times_hc`, `prod_times_hc`, `improd_time_hc`, `otp_time_hc`, `absence_time_hc`, `allocated_time_hc`, `spent_time`, `planned_time` |
| Prep 6 — Leading zeros | Remove from `work_order`, `material_number`, `operation` |
| Prep 7 — Lowercase | All column names to lowercase |
| Tr1 — Deduplication | Keep latest `extraction_timestamp` per `date` (window function) |
| **QC1 — Input row count** | Input (`df_hqa_raw`) must have ≥ `MIN_INPUT_ROWS` (1) row. RED, always enforced (not gated by `skip_quality_checks`). See [Quality Checks](#quality-checks). |
| **QC2 — Valid batch dates** | At least one non-null `date` must survive into the deduplicated batch (`df_hqa_latest`). RED, always enforced. See [Quality Checks](#quality-checks). |
| **QC3 — Spent time trend** | Compare `spent_times_hc` sum per `employee_group` between last 2 extractions (PROD events, current month). Fail if decrease > 5% tolerance. RED, skippable via `skip_quality_checks`. |

**Columns dropped:** `_rescued_data`, `_meta_validity_check`, `_meta_ingestion_timestamp`, `_meta_file_mode`

### 2. `create_gold_infocenter_hqa.py`

Creates the Gold infocenter table by enriching Silver with SAP master data.

| Property | Value |
|----------|-------|
| **Input** | `{pipeline_read_env}_silver.production.infocenter_hqa` |
| **Input (QC2 only)** | `{pipeline_write_env}_gold.production.infocenter_hqa` (own prior output, read for the row-count drop check) |
| **Output** | `{pipeline_write_env}_gold.production.infocenter_hqa` |
| **Save mode** | Full overwrite (`mode="overwrite"`, no `replace_where`) - recomputes from a full read of Silver every run, see the notebook's Technical Debt section |
| **Cluster by** | `date` |
| **LEAP utils** | `table_utils.save_table()`, `table_utils.remove_leading_zeros()`, `table_utils.add_week_number()`, `table_utils.UnityCatalogCheckTableExists()`, `quality_checks.validate_and_log_quality_check_results()` |

**Widgets:**

| Widget | Default | Description |
|--------|---------|-------------|
| `pipeline_write_env` | `dev` | Write environment |
| `pipeline_read_env` | `dev` | Read environment |
| `reference_read_env` | `prod` | Reference data environment |

**Reference Tables (8):**

| Table | Catalog.Schema | Join Key(s) | Columns Used |
|-------|----------------|-------------|--------------|
| `plant_master_data_latest_exposed` | `{ref}_gold.master_data` | `Plant` | `Plant_Description_new` → `plant_description` |
| `material_master_data_plant_exposed` | `{ref}_gold.master_data` | `Material_Number`, `Plant` | `Description`, `Production_Site`, `Stock_Site`, `Assy_Final` (prefixed `MAT_`) |
| `profit_center_exposed` | `{ref}_gold.finance` | `profit_center` | `Short_Description` → `PC_description`, `Product_Group` |
| `sap_work_order_basics_latest_exposed` | `{ref}_gold.production` | `work_order` | `WO_Description`, `WO_Status_System`, `WO_Status` → `work_order_status`, `material_number` |
| `afru_latest` | `{ref}_bronze.sap_latecoere_ecc6` | `aufnr` → `aufpl` | Operation confirmations |
| `afvc_latest` | `{ref}_bronze.sap_latecoere_ecc6` | `aufpl` | `objnr`, `vornr` (operation number) |
| `jest_latest` | `{ref}_bronze.sap_latecoere_ecc6` | `objnr` | `stat`, `inact`, `chgnr` |
| `tj02t_latest` | `{ref}_bronze.sap_latecoere_ecc6` | `stat` (where `spras = 'E'`) | `txt04`, `txt30` (status text) |

**Transformations:**

| Step | Description |
|------|-------------|
| Tr1 — Join material | Left join on `Material_Number` + `Plant` → adds `MAT_Description`, `MAT_Production_Site`, `MAT_Stock_Site`, `MAT_Assy_Final` |
| Tr2 — Join plant | Left join on `Plant` → adds `plant_description` |
| Tr3 — Join profit center | Left join on `profit_center` → adds `PC_description`, `Product_Group` |
| Tr4 — Concat codes+desc | Creates `improductivity_code_desc`, `profit_center_code_desc`, `employee_code_name` |
| Tr5 — Drop columns | Drops `reference`, `type_activitie_worke`, `name_firstname`, `work_mode`, `PC_Description`, `wo_description` |
| Tr6 — Operation status | Joins SAP tables (afru→afvc→jest→tj02t) to get operation confirmation status (`CONF` / `NOT CONF` for PROD/DECPROD events) |
| Tr7 — WO status | Left join with SAP WO basics → `work_order_status`, `WO_Status_System` |
| Tr8 — Week number | Adds `week_number` from `date` column |
| Tr9 — Population group | `population_group` = first 3 chars of `employee_group` |
| **QC1 — Output row count** | Output (`df_hqa_transf`) must have ≥ `MIN_OUTPUT_ROWS` (1) row. RED, blocks the overwrite. See [Quality Checks](#quality-checks). |
| **QC2 — Row count drop check** | Blocks the overwrite if the new row count drops more than `MAX_ALLOWED_ROW_COUNT_DROP_PCT` (20%) vs the current gold table. RED, skipped on first run or if the current table is empty. |

### 3. `horoquartz_data_asset_DLT_notebook.py`

DLT notebook that runs **inside the ingestion pipeline** (`F_1_horoquartz_ingestion_&_data_asset_pipeline`). Processes `atpeven` from Bronze to Silver and Gold.

| Property | Value |
|----------|-------|
| **Input** | `{bronze_catalog}.{bronze_schema}.atpeven_latest` |
| **Reference** | `{bronze_catalog}.manual_input.mapping_plant_timezone` |
| **Output Silver** | `{env}_silver.production.horoquartz_atpeven` |
| **Output Gold** | `{env}_gold.production.horoquartz_atpeven` |
| **Runs in** | DLT pipeline (not standalone) |

**DLT Objects:**

| Object | Type | Description |
|--------|------|-------------|
| `bronze_atpeven_cast` | DLT View | Casts `id_group`, `manager_id` → bigint; `operation` → bigint; `duree_eve` → double |
| `{silver}.horoquartz_atpeven` | DLT Table | Filters `_meta_validity_check == True`, drops `_rescued_data` + `_meta_validity_check` |
| `{gold}.horoquartz_atpeven` | DLT Table | Joins `mapping_plant_timezone` (on `division`), computes `datetime_deb`/`datetime_fin` (local→UTC), `tps_total_min` (handles open events where `date_fin = 1900-01-01`) |

### 4. `horoquartz_bulgaria_view.py`

Standalone notebook that creates a project-level view filtering for the Bulgaria plant (division = 5000).

| Property | Value |
|----------|-------|
| **Input** | `{read_env}_bronze.horoquartz_ingestion.infocenter_group_latest` |
| **Output** | `{write_env}_proj.horoquartz.infocenter_group_bulgaria_view` |
| **Filter** | `division = '5000'` (Bulgaria plant) |
| **Column mapping** | 43 columns renamed via `hqa_column_schema.json` |
| **Triggered by** | Job 2 (`F_2_horoquartz_infocenter_job_and_bulgaria_view`) on TABLE_UPDATE |

### 5. `hqa_column_schema.json`

JSON mapping file with 43 column pairs `[destination_name, source_name]` used by the Bulgaria view to rename columns from the raw Horoquartz format to a cleaner schema. Includes columns for employee info, time events, work orders, operations, cost centers, and descriptions.

## Tables Summary

### Pipeline Tables (written by these notebooks)

| Table | Catalog.Schema | Written by | Save strategy |
|-------|----------------|-----------|---------------|
| `infocenter_hqa` | `{env}_silver.production` | `create_silver_infocenter_hqa` | Overwrite (`replace_where` on `date`) |
| `infocenter_hqa` | `{env}_gold.production` | `create_gold_infocenter_hqa` | Full overwrite (no `replace_where`) |
| `horoquartz_atpeven` | `{env}_silver.production` | `horoquartz_data_asset_DLT_notebook` | DLT managed |
| `horoquartz_atpeven` | `{env}_gold.production` | `horoquartz_data_asset_DLT_notebook` | DLT managed |
| `infocenter_group_bulgaria_view` | `{env}_proj.horoquartz` | `horoquartz_bulgaria_view` | CREATE OR REPLACE VIEW |

### Reference Tables (read-only)

| Table | Catalog.Schema | Used by |
|-------|----------------|---------|
| `infocenter_group_stack` | `{ref}_bronze.horoquartz_ingestion` | Silver infocenter |
| `atpeven_latest` | `{env}_bronze.horoquartz_ingestion` | DLT data asset |
| `infocenter_group_latest` | `{env}_bronze.horoquartz_ingestion` | Bulgaria view |
| `mapping_plant_timezone` | `{env}_bronze.manual_input` | DLT data asset (gold) |
| `plant_master_data_latest_exposed` | `{ref}_gold.master_data` | Gold infocenter |
| `material_master_data_plant_exposed` | `{ref}_gold.master_data` | Gold infocenter |
| `profit_center_exposed` | `{ref}_gold.finance` | Gold infocenter |
| `sap_work_order_basics_latest_exposed` | `{ref}_gold.production` | Gold infocenter |
| `afru_latest` | `{ref}_bronze.sap_latecoere_ecc6` | Gold infocenter |
| `afvc_latest` | `{ref}_bronze.sap_latecoere_ecc6` | Gold infocenter |
| `jest_latest` | `{ref}_bronze.sap_latecoere_ecc6` | Gold infocenter |
| `tj02t_latest` | `{ref}_bronze.sap_latecoere_ecc6` | Gold infocenter |

## Execution Context

### Infocenter Flow (Silver → Gold)

The Silver and Gold infocenter notebooks run as a **standalone Databricks job** (`F_1_HQA_Production_Infocenter_Data_Asset`, prod job ID: `414455958110188`), triggered by `trigger_optional_job` in Job 2 of the `horoquartz_ingestion` bundle.

```mermaid
sequenceDiagram
    participant Ingestion as Job 1 (Ingestion)
    participant DLT as DLT Pipeline
    participant TU as Table Update Trigger
    participant Job2 as Job 2 (Infocenter)
    participant Bulgaria as Bulgaria View
    participant DA as Data Asset Job (F_3)
    participant Silver as Silver Notebook
    participant Gold as Gold Notebook

    Ingestion->>DLT: refresh pipeline
    DLT->>DLT: Ingest 4 tables + atpeven Silver/Gold

    DLT-->>TU: infocenter_group tables updated
    TU->>Job2: TABLE_UPDATE trigger (5min wait)

    par Parallel tasks
        Job2->>Bulgaria: Task 1: Bulgaria view
        Job2->>DA: Task 2: trigger_optional_job
    end

    DA->>Silver: create_silver_infocenter_hqa
    Silver->>Gold: create_gold_infocenter_hqa
```

### ATPEVEN Flow (DLT)

The ATPEVEN data asset runs **inside the DLT pipeline** alongside ingestion — no separate job needed.

## Quality Checks

QC1/QC2 below (Silver and Gold) guard against a fully-empty upstream write and are never skippable
via `skip_quality_checks` - only QC3 (the pre-existing spent-time trend check) can be skipped.

### Silver Infocenter — QC1: Input Row Count

| Property | Value |
|----------|-------|
| **Level** | RED (blocks pipeline, not gated by `skip_quality_checks`) |
| **Type** | `check_input_row_count` |
| **Logic** | Input (`df_hqa_raw`) row count must be ≥ `MIN_INPUT_ROWS` (1) |

### Silver Infocenter — QC2: Valid Batch Dates

| Property | Value |
|----------|-------|
| **Level** | RED (blocks pipeline, not gated by `skip_quality_checks`) |
| **Type** | `check_valid_batch_dates` |
| **Logic** | Guards a distinct failure mode from QC1: rows can be present but every `date` value fails to parse. At least one non-null `date` must survive into the deduplicated batch (`df_hqa_latest`) |

### Silver Infocenter — QC3: Spent Time Increase Check

| Property | Value |
|----------|-------|
| **Level** | RED (blocks pipeline) |
| **Type** | `check_spent_time_increase_tolerance` |
| **Logic** | Compare sum of `spent_times_hc` per `employee_group` between last 2 extractions, for PROD events in the current month |
| **Tolerance** | 5% decrease allowed |
| **Skip** | Set `skip_quality_checks = True` for backfills |
| **Task value** | Sets `quality_check_exception = True/False` for downstream tasks |

### Gold Infocenter — QC1: Output Row Count

| Property | Value |
|----------|-------|
| **Level** | RED (blocks pipeline) |
| **Type** | `check_output_row_count` |
| **Logic** | Output (`df_hqa_transf`) row count must be ≥ `MIN_OUTPUT_ROWS` (1) |

### Gold Infocenter — QC2: Row Count Drop vs Current Table

| Property | Value |
|----------|-------|
| **Level** | RED (blocks pipeline) |
| **Type** | `check_row_count_drop` |
| **Logic** | Catches a partial/corrupted upstream load, not just a fully empty one: blocks the overwrite if the new row count drops more than `MAX_ALLOWED_ROW_COUNT_DROP_PCT` (20%) vs the current gold table |
| **Skip condition** | Skipped when there's no meaningful current row count to compare against - table doesn't exist yet (first run), or is already empty |

## Useful Queries

```sql
-- Check Silver infocenter row count and date range
SELECT min(date) as min_date, max(date) as max_date, count(*) as rows
FROM {env}_silver.production.infocenter_hqa;

-- Check Gold infocenter enrichment
SELECT plant, plant_description, count(*) as rows
FROM {env}_gold.production.infocenter_hqa
GROUP BY 1, 2 ORDER BY 3 DESC;

-- Check Gold atpeven (DLT)
SELECT division, timezone, count(*) as rows
FROM {env}_gold.production.horoquartz_atpeven
GROUP BY 1, 2;

-- Check Bulgaria view
SELECT count(*) as rows
FROM {env}_proj.horoquartz.infocenter_group_bulgaria_view;

-- Quality check: compare spent time between extractions
SELECT extraction_timestamp, employee_group, sum(spent_times_hc) as total
FROM {env}_silver.production.infocenter_hqa
WHERE event = 'PROD'
  AND month(date) = month(current_date() - interval 2 days)
GROUP BY 1, 2
ORDER BY 2, 1 DESC;

-- Check operation statuses in Gold
SELECT operation_status, count(*) as rows
FROM {env}_gold.production.infocenter_hqa
WHERE event IN ('PROD', 'DECPROD')
GROUP BY 1;
```

## Folder Structure

```
data_asset/production/infocenter_hqa/
├── create_silver_infocenter_hqa.py         # Silver: bronze stack → silver (standalone job)
├── create_gold_infocenter_hqa.py           # Gold: silver → gold with SAP enrichment (standalone job)
├── horoquartz_data_asset_DLT_notebook.py   # DLT: atpeven bronze → silver → gold (inside pipeline)
├── horoquartz_bulgaria_view.py             # Proj: Bulgaria view (division=5000)
├── hqa_column_schema.json                  # Column mapping for Bulgaria view (43 columns)
└── README.md
```

## Related Documentation

- **Ingestion Bundle:** `platform/asset_bundle/horoquartz_ingestion/README.md`
- **Generic Ingestion:** `ingestion/dlt/Generic_table_ingestion_DLT_notebook.py`
- **LEAP table_utils:** `leap_utils/data_asset/table_utils.py`
- **LEAP quality_checks:** `leap_utils/common/validation/quality_checks.py`
- **Plant Timezone Mapping:** `{env}_bronze.manual_input.mapping_plant_timezone`
