# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # ONE-SHOT INFOCENTER HQA BACKFILL
# MAGIC
# MAGIC **Description:**
# MAGIC Restores silver dates from the raw S3 archive once they have aged out of the bronze stack
# MAGIC rolling window and can no longer be replayed by the recurring pipeline. Applies the same
# MAGIC preparation and latest-extraction rules as create_silver_infocenter_hqa.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - The write replaces whole dates, so the batch must carry every site - see [Quality Checks]
# MAGIC - Ingestion metadata columns are rebuilt from the file path - see [Preparation - metadata]
# MAGIC
# MAGIC Run once per incident, then re-run Gold to propagate.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Infocenter HQA (manual, outside the scheduled job)
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - s3://leap-s3-raw-weeu1-{reference_read_env}/archive/apps/horoquartz
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver.production.infocenter_hqa
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.production.infocenter_hqa

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC 1. ingestion_uid is recomputed rather than carried over; nothing downstream joins on it.
# MAGIC 2. Expected sites come from days around the gap; one absent on both sides is unchecked.

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.validation import quality_checks
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("backfill_start_date", "2026-06-01")
BACKFILL_START_DATE = dbutils.widgets.get("backfill_start_date")

dbutils.widgets.text("backfill_end_date", "2026-06-06")
BACKFILL_END_DATE = dbutils.widgets.get("backfill_end_date")

dbutils.widgets.text("archive_file_pattern", "20260709_015255_HQA-INF-*.parquet")
ARCHIVE_FILE_PATTERN = dbutils.widgets.get("archive_file_pattern")

dbutils.widgets.text("dry_run", "True")
DRY_RUN = dbutils.widgets.get("dry_run").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Other config

# COMMAND ----------

RAW_BUCKET = f"leap-s3-raw-weeu1-{REFERENCE_READ_ENV}"
ARCHIVE_PREFIX = "archive/apps/horoquartz"
ARCHIVE_PATH = f"s3://{RAW_BUCKET}/{ARCHIVE_PREFIX}/{ARCHIVE_FILE_PATTERN}"

TARGET_SILVER_TABLE = f"{PIPELINE_WRITE_ENV}_silver.production.infocenter_hqa"
SOURCE_SILVER_TABLE = f"{PIPELINE_READ_ENV}_silver.production.infocenter_hqa"

# Days either side of the gap used to establish which sites are expected in the batch.
SITE_REFERENCE_WINDOW_DAYS = 7

# A site is only treated as expected if it clears this share of its own reference-window daily
# average, so a site winding down before a closure does not fail the check.
SITE_EXPECTED_MIN_RATIO = 0.20

# Site identity is the leading segment of the employee group (e.g. CAS, LEM, SEA).
SITE_CODE_LENGTH = 3

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## File reads
# MAGIC Names are lower-cased to match the ingestion notebook, which the renaming below relies on.

# COMMAND ----------

log.info(f"Reading archived extracts from {ARCHIVE_PATH}")

df_archive_source = spark.read.parquet(ARCHIVE_PATH)

df_archive_raw = df_archive_source.select(
    *[f.col(f"`{col}`").alias(col.lower()) for col in df_archive_source.columns],
    f.col("_metadata.file_path").alias("_meta_file_path"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## LEAP tables

# COMMAND ----------

df_silver_current = spark.read.table(SOURCE_SILVER_TABLE)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Manual declarations

# COMMAND ----------

DICT_TO_RENAME_HQA = {
    "roll_number": "employee_code",
    "employee_full_name": "employee_name",
    "initial_group": "employee_group",
    "worked_cost_center": "cost_center",
    "mo_father": "WO_father",
    "improd_": "improductivity_code",
    "reason": "absence_reason",
    "mo": "work_order",
    "ope": "operation",
    "ope_description": "operation_description",
    "article": "material_number",
    "emp_cost_center": "employee_cost_center",
    "emp_type_activitie": "employee_activity_type",
    "activitie_date": "activity_date",
    "mo_description": "WO_description",
    "article_description": "material_description",
    "workstation_descript": "workstation_description",
    "worked_cc_descriptio": "cost_center_description",
    "emp_cc_description": "employee_cost_center_description",
    "division": "plant",
    "payroll_categorie": "payroll_category",
    "order_type": "work_order_type",
    "_meta_extraction_timestamp": "extraction_timestamp",
    "_meta_file_name": "filename",
    "_meta_file_path": "filepath",
    "_meta_id": "ingestion_uid",
}

DATE_COLUMNS = ["date", "activity_date", "validation_date"]

COL_TO_UPPER = [
    "improductivity_code",
    "event",
    "operation_description",
    "workstation_description",
]

COL_TO_CAST_IN_DOUBLE = [
    "spent_times_hc",
    "prod_times_hc",
    "improd_time_hc",
    "otp_time_hc",
    "absence_time_hc",
    "allocated_time_hc",
    "spent_time",
    "planned_time",
]

COL_CLEANING_LEADING_ZEROS = ["work_order", "material_number", "operation"]

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - metadata
# MAGIC The archive holds raw supplier extracts, so ingestion metadata is rebuilt here: extraction
# MAGIC timestamp from the file name, row id as a row hash since this source has no natural key.

# COMMAND ----------

data_columns = [col for col in df_archive_raw.columns if col != "_meta_file_path"]

df_hqa_prep = (
    df_archive_raw.withColumn(
        "_meta_id", f.sha2(f.concat_ws("-", *[f.col(c) for c in data_columns]), 256)
    )
    .withColumn(
        "_meta_extraction_timestamp",
        f.try_to_timestamp(
            f.regexp_extract(f.col("_meta_file_path"), r"(\d{8}_\d{6})", 1),
            f.lit("yyyyMMdd_HHmmss"),
        ),
    )
    .withColumn(
        "_meta_file_name", f.regexp_extract(f.col("_meta_file_path"), r"([^/]+)$", 1)
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - column renaming
# MAGIC The source names the hour columns hm, for "heures minutes", but the values are decimal.

# COMMAND ----------

df_hqa_prep = df_hqa_prep.withColumnsRenamed(DICT_TO_RENAME_HQA)

renamed_columns = [
    (col, col[:-2] + "hc") if col.endswith("hm") else (col, col)
    for col in df_hqa_prep.columns
]

for old_col, new_col in renamed_columns:
    df_hqa_prep = df_hqa_prep.withColumnRenamed(old_col, new_col)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - string values cleaning

# COMMAND ----------

for col in df_hqa_prep.columns:
    df_hqa_prep = df_hqa_prep.withColumn(
        col,
        f.when(f.trim(f.col(col)) == "", f.lit(None)).otherwise(f.trim(f.col(col))),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - date cleaning

# COMMAND ----------

for col in DATE_COLUMNS:
    df_hqa_prep = df_hqa_prep.withColumn(col, f.try_to_date(f.col(col), "dd/MM/yyyy"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - column values to upper

# COMMAND ----------

for col in COL_TO_UPPER:
    df_hqa_prep = df_hqa_prep.withColumn(col, f.upper(f.col(col)))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - double columns to cast

# COMMAND ----------

for col in COL_TO_CAST_IN_DOUBLE:
    df_hqa_prep = df_hqa_prep.withColumn(col, f.col(col).try_cast("double"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - cleaning leading zeros

# COMMAND ----------

df_hqa_prep = table_utils.remove_leading_zeros(df_hqa_prep, COL_CLEANING_LEADING_ZEROS)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - lower case all column names

# COMMAND ----------

df_hqa_prep = df_hqa_prep.select(
    [f.col(col).alias(col.lower()) for col in df_hqa_prep.columns]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Restrict to the backfill window

# COMMAND ----------

df_hqa_window = df_hqa_prep.filter(
    f.col("date").between(f.lit(BACKFILL_START_DATE), f.lit(BACKFILL_END_DATE))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Take the latest extraction of each date
# MAGIC Each file is a full snapshot of a rolling window, so a date recurs; only the latest counts.

# COMMAND ----------

window = Window.partitionBy("date").orderBy(f.desc(f.col("extraction_timestamp")))

df_date_wd = (
    df_hqa_window.select("date", "extraction_timestamp")
    .distinct()
    .withColumn("row_number", f.row_number().over(window))
    .filter(f.col("row_number") == 1)
    .withColumnRenamed("extraction_timestamp", "max_extraction_timestamp")
    .drop("row_number")
)

df_hqa_latest = (
    df_hqa_window.join(df_date_wd, on="date", how="left")
    .filter(f.col("max_extraction_timestamp") == f.col("extraction_timestamp"))
    .drop("max_extraction_timestamp")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Align to the target schema
# MAGIC The write replaces whole dates, so the batch must present target columns in target order.

# COMMAND ----------

target_columns = spark.read.table(TARGET_SILVER_TABLE).columns

missing_columns = [c for c in target_columns if c not in df_hqa_latest.columns]
extra_columns = [c for c in df_hqa_latest.columns if c not in target_columns]

log.info(f"Columns missing from the batch: {missing_columns}")
log.info(f"Columns dropped from the batch: {extra_columns}")

if missing_columns:
    df_hqa_end = df_hqa_latest
else:
    df_hqa_end = df_hqa_latest.select(*[f.col(c) for c in target_columns])

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## QC1 - Schema alignment
# MAGIC A missing column would be written as a silent null over good data.

# COMMAND ----------

schema_check = {"schema_alignment_check": len(missing_columns) == 0}

quality_checks.validate_and_log_quality_check_results(
    results_dict=schema_check,
    validation_level="RED",
    info_message=f"Backfill batch matches the {len(target_columns)} target columns.",
    error_message=f"Backfill batch is missing target columns: {missing_columns}",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    expectation_type="check_schema_alignment",
    log_to_event_table=True,
    log_successes=True,
    raw_result={
        "schema_alignment_check": {
            "success": len(missing_columns) == 0,
            "expectation_type": "check_schema_alignment",
            "missing_columns": missing_columns,
        }
    },
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## QC2 - Every targeted date is present
# MAGIC A partial date set would leave the gap half open while reporting success.

# COMMAND ----------

expected_dates = [
    row["date"]
    for row in spark.sql(
        f"SELECT explode(sequence(to_date('{BACKFILL_START_DATE}'), "
        f"to_date('{BACKFILL_END_DATE}'))) AS date"
    ).collect()
]

dates_in_batch = sorted(
    row["date"]
    for row in df_hqa_end.select("date").distinct().collect()
    if row["date"] is not None
)

dates_missing = [d for d in expected_dates if d not in dates_in_batch]

dates_check = {"backfill_dates_check": len(dates_missing) == 0}

quality_checks.validate_and_log_quality_check_results(
    results_dict=dates_check,
    validation_level="RED",
    info_message=f"Backfill covers all {len(expected_dates)} targeted date(s).",
    error_message=(
        f"Archived extracts do not cover every targeted date. Missing: {dates_missing}. "
        "Point archive_file_pattern at an earlier snapshot."
    ),
    pipeline_write_env=PIPELINE_WRITE_ENV,
    expectation_type="check_backfill_dates",
    log_to_event_table=True,
    log_successes=True,
    raw_result={
        "backfill_dates_check": {
            "success": len(dates_missing) == 0,
            "expectation_type": "check_backfill_dates",
            "missing_dates": [str(d) for d in dates_missing],
        }
    },
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## QC3 - Every expected site is present
# MAGIC The write replaces whole dates, so a batch with only the lost site would erase the others.
# MAGIC A site is required only where it was active around the gap, so a closure does not block it.

# COMMAND ----------

site_col = f.substring(f.col("employee_group"), 1, SITE_CODE_LENGTH)

df_reference = df_silver_current.filter(
    f.col("date").between(
        f.date_sub(f.lit(BACKFILL_START_DATE).cast("date"), SITE_REFERENCE_WINDOW_DAYS),
        f.date_add(f.lit(BACKFILL_END_DATE).cast("date"), SITE_REFERENCE_WINDOW_DAYS),
    )
    & f.col("employee_group").isNotNull()
)

df_reference_daily = (
    df_reference.groupBy(site_col.alias("site"), f.col("date"))
    .agg(f.count(f.lit(1)).alias("rows_per_day"))
    .groupBy("site")
    .agg(f.avg("rows_per_day").alias("avg_rows_per_day"))
)

df_batch_sites = (
    df_hqa_end.filter(f.col("employee_group").isNotNull())
    .groupBy(site_col.alias("site"), f.col("date"))
    .agg(f.count(f.lit(1)).alias("rows_per_day"))
    .groupBy("site")
    .agg(f.avg("rows_per_day").alias("batch_avg_rows_per_day"))
)

df_site_coverage = df_reference_daily.join(
    df_batch_sites, on="site", how="left"
).withColumn(
    "is_covered",
    f.coalesce(f.col("batch_avg_rows_per_day"), f.lit(0))
    >= f.col("avg_rows_per_day") * f.lit(SITE_EXPECTED_MIN_RATIO),
)

sites_not_covered = [
    row["site"] for row in df_site_coverage.filter(~f.col("is_covered")).collect()
]

site_coverage_check = {"site_coverage_check": len(sites_not_covered) == 0}

quality_checks.validate_and_log_quality_check_results(
    results_dict=site_coverage_check,
    validation_level="RED",
    info_message="Backfill batch carries every site active around the gap.",
    error_message=(
        f"Backfill batch is missing or thin for site(s) {sites_not_covered}. Writing it would "
        "erase them for the targeted dates."
    ),
    pipeline_write_env=PIPELINE_WRITE_ENV,
    expectation_type="check_site_coverage",
    log_to_event_table=True,
    log_successes=True,
    raw_result={
        "site_coverage_check": {
            "success": len(sites_not_covered) == 0,
            "expectation_type": "check_site_coverage",
            "sites_not_covered": sites_not_covered,
        }
    },
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## QC4 - Backfill summary
# MAGIC Logged so the recovered volumes can be reconciled against the source before publishing.

# COMMAND ----------

df_summary = (
    df_hqa_end.groupBy(f.col("date"), site_col.alias("site"))
    .agg(
        f.count(f.lit(1)).alias("rows"),
        f.round(f.sum("spent_times_hc"), 0).alias("spent_hours"),
    )
    .orderBy("date", "site")
)

for row in df_summary.collect():
    log.info(
        f"   {row['date']} | {row['site']} | {row['rows']} rows | {row['spent_hours']} h"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

quoted = ",".join([f"'{d}'" for d in dates_in_batch])
replace_where = f"date IN ({quoted})"

log.info(f"Backfill target: {TARGET_SILVER_TABLE}")
log.info(f"Replace predicate: {replace_where}")

if DRY_RUN:
    log.warning("dry_run is True - nothing written. Set dry_run to False to apply.")
else:
    table_utils.save_table(
        dest_table=TARGET_SILVER_TABLE,
        df=df_hqa_end,
        mode="overwrite",
        overwrite_schema=False,
        cluster_cols="date",
        merge_schema=True,
        replace_where=replace_where,
    )
    log.info("Backfill written. Re-run the Gold task to propagate.")
