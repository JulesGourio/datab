# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC **CREATE GOLD INFOCENTER HQA**
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The script creates the gold table of the infocenter from the silver table. The idea is to have a clean gold table of HQA full scope in order, from it, to create more specific gold tables.
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Infocenter HQA
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {pipeline_read_env}_silver.production.infocenter_hqa
# MAGIC - {pipeline_write_env}_gold.production.infocenter_hqa
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.production.infocenter_hqa
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC 1. This notebook recomputes from a full read of the silver table on every run (not an incremental
# MAGIC    batch), so the write stays a full `mode="overwrite"` rather than a partition-scoped
# MAGIC    `replace_where` - the row-count checks in [Quality Checks] are the safety net for that.

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.validation import quality_checks
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC #Input

# COMMAND ----------

# MAGIC %md
# MAGIC ##LEAP table(s)
# MAGIC - **df_hqa_silver** is the silver table of the infocenter
# MAGIC - **df_plant_raw** is the plant master data table
# MAGIC - **df_material_raw** is the material-plant master data table
# MAGIC - **df_pc_raw** is the profit center master data table

# COMMAND ----------

df_hqa_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.production.infocenter_hqa"
)

# COMMAND ----------

df_plant_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)

# COMMAND ----------

df_material_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed"
)

# COMMAND ----------

df_pc_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed")

# COMMAND ----------

df_wo_sap = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.production.sap_work_order_basics_latest_exposed"
)

df_afko_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afru_latest"
)
df_afvc_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afvc_latest"
)
df_jest_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.jest_latest"
)
df_tj02t_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tj02t_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

COLUMNS_TO_DROP = [
    "reference",
    "type_activitie_worke",
    "name_firstname",
    "work_mode",
    "PC_Description",
    "wo_description",
]

# COMMAND ----------

OUTPUT_GOLD_TABLE_HQA_INFOCENTER = (
    f"{PIPELINE_WRITE_ENV}_gold.production.infocenter_hqa"
)

# COMMAND ----------

MIN_OUTPUT_ROWS = 1
MAX_ALLOWED_ROW_COUNT_DROP_PCT = 0.20

# COMMAND ----------

GOLD_TABLE_EXISTS = table_utils.UnityCatalogCheckTableExists(OUTPUT_GOLD_TABLE_HQA_INFOCENTER)
df_hqa_gold_current_raw = (
    spark.read.table(OUTPUT_GOLD_TABLE_HQA_INFOCENTER) if GOLD_TABLE_EXISTS else None
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Plant master data

# COMMAND ----------

df_plant_prep = (
    df_plant_raw.select("Plant", "Plant_Description_new")
    .distinct()
    .withColumnRenamed("Plant_Description_new", "plant_description")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - Material master data

# COMMAND ----------

MAT_COL_TO_SELECT = [
    "Material_Number",
    "Plant",
    "Description",
    "Production_Site",
    "Stock_Site",
    "Assy_Final",
]

# COMMAND ----------

df_material_prep = df_material_raw.select(*MAT_COL_TO_SELECT).distinct()

# COMMAND ----------

for col in df_material_prep.columns:
    if col not in ["Material_Number", "Plant"]:
        df_material_prep = df_material_prep.withColumnRenamed(col, f"MAT_{col}")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 3 - Profit center master data

# COMMAND ----------

PC_COL_TO_SELECT = ["Profit_Center_short", "Short_Description", "Product_Group"]

# COMMAND ----------

df_pc_prep = df_pc_raw.select(*PC_COL_TO_SELECT).withColumnsRenamed(
    {"Profit_Center_short": "profit_center", "Short_Description": "PC_description"}
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 4 - Get operation status

# COMMAND ----------

df_afko = df_afko_raw.select("aufnr", "aufpl").dropDuplicates()
df_afvc = df_afvc_raw.select("aufpl", "objnr", "vornr").dropDuplicates()
df_jest = df_jest_raw.select("objnr", "stat", "inact", "chgnr").dropDuplicates()
df_tj02t = (
    df_tj02t_raw.select("istat", "spras", "txt04", "txt30")
    .where(f.col("spras") == "E")
    .drop("spras")
    .withColumnRenamed("istat", "stat")
)

df_wo_ope_status = (
    df_afko.join(df_afvc, ["aufpl"], "left")
    .join(df_jest, ["objnr"], "left")
    .join(df_tj02t, ["stat"], how="left")
)

df_wo_ope_status = table_utils.remove_leading_zeros(
    df_wo_ope_status, ["aufnr", "aufpl", "vornr"]
)

CONF_STATUS = ["CNF"]
df_wo_ope_conf = (
    df_wo_ope_status.where(f.col("txt04").isin(CONF_STATUS))
    .withColumn("operation_status", f.lit("CONF"))
    .withColumnsRenamed({"aufnr": "work_order", "vornr": "operation"})
    .select("work_order", "operation", "operation_status")
    .distinct()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 5 - Work Order status from SAP

# COMMAND ----------

df_wo_status = df_wo_sap.select(
    f.col("WO_Number").alias("work_order"),
    f.col("WO_Description").alias("wo_description"),
    f.col("WO_Status_System"),
    f.col("WO_Status").alias("work_order_status"),
    f.col("material_number"),
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC #Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Join with material

# COMMAND ----------

df_hqa_transf = df_hqa_silver.join(
    df_material_prep, ["Material_Number", "Plant"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Get plant description

# COMMAND ----------

df_hqa_transf = df_hqa_transf.join(df_plant_prep, ["Plant"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr3 - Get program information
# MAGIC Get profit center description and product group

# COMMAND ----------

df_hqa_transf = df_hqa_transf.join(df_pc_prep, ["profit_center"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr4 - Concatenation codes and descriptions
# MAGIC - Improductivity code + desc
# MAGIC - Profit center code + desc

# COMMAND ----------

df_hqa_transf = df_hqa_transf.withColumn(
    "improductivity_code_desc",
    f.concat_ws("-", f.col("improductivity_code"), f.col("improd_description")),
)

# COMMAND ----------

df_hqa_transf = df_hqa_transf.withColumn(
    "profit_center_code_desc",
    f.concat_ws("-", f.col("profit_center"), f.col("PC_description")),
)

# COMMAND ----------

df_hqa_transf = df_hqa_transf.withColumn(
    "employee_code_name",
    f.concat_ws("-", f.col("employee_code"), f.col("employee_name")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr5 - Drop columns
# MAGIC - The column Reference is equal to the column OTP
# MAGIC - The column Type_activitie_worke is equal to the column employee_activity_type
# MAGIC - The column Name_Firstname is equal to the column employee_name
# MAGIC - The column Work_mode is empty

# COMMAND ----------

df_hqa_transf = df_hqa_transf.drop(*COLUMNS_TO_DROP)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr6 - Get operation and WO status

# COMMAND ----------

df_hqa_transf = df_hqa_transf.join(
    df_wo_ope_conf, ["work_order", "operation"], how="left"
).drop("material_number")

# COMMAND ----------

df_hqa_transf = df_hqa_transf.join(df_wo_status, ["work_order"], how="left").withColumn(
    "operation_status",
    f.when(
        f.col("operation_status").isNull() & f.col("event").isin(["PROD", "DECPROD"]),
        f.lit("NOT CONF"),
    ).otherwise(f.lit("CONF")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr7 - Add week number

# COMMAND ----------

df_hqa_transf = table_utils.add_week_number(df_hqa_transf, "date").withColumnRenamed(
    "date_week_number", "week_number"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr8 - Population group
# MAGIC To have the population group, it is the first 3 characters of employee_group.

# COMMAND ----------

df_hqa_transf = df_hqa_transf.withColumn(
    "population_group", f.substring(f.col("employee_group"), 0, 3)
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ##QC1 - Output row count
# MAGIC A zero-row write here would silently blank the gold table for every downstream report. This
# MAGIC check blocks the overwrite outright when the transformed dataset about to be written is empty.

# COMMAND ----------

output_row_count = df_hqa_transf.count()
output_row_count_check = {"output_row_count_check": output_row_count >= MIN_OUTPUT_ROWS}

quality_checks.validate_and_log_quality_check_results(
    results_dict=output_row_count_check,
    validation_level="RED",
    info_message=f"HQA gold output row count check passed: {output_row_count} rows.",
    error_message=(
        f"HQA gold output is empty ({output_row_count} rows) - overwrite blocked to avoid "
        "wiping the gold table."
    ),
    pipeline_write_env=PIPELINE_WRITE_ENV,
    expectation_type="check_output_row_count",
    log_to_event_table=True,
    log_successes=True,
    raw_result={
        "output_row_count_check": {
            "success": output_row_count >= MIN_OUTPUT_ROWS,
            "expectation_type": "check_output_row_count",
            "row_count": output_row_count,
        }
    },
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##QC2 - Output row count vs current table
# MAGIC Catches a partial/corrupted upstream load, not just a fully empty one.

# COMMAND ----------

current_gold_row_count = df_hqa_gold_current_raw.count() if GOLD_TABLE_EXISTS else 0

if current_gold_row_count > 0:
    row_count_drop_pct = (
        current_gold_row_count - output_row_count
    ) / current_gold_row_count
    row_count_drop_check = {
        "row_count_drop_check": row_count_drop_pct <= MAX_ALLOWED_ROW_COUNT_DROP_PCT
    }

    quality_checks.validate_and_log_quality_check_results(
        results_dict=row_count_drop_check,
        validation_level="RED",
        info_message=(
            f"HQA gold row count drop check passed: {row_count_drop_pct:.1%} vs current table."
        ),
        error_message=(
            f"HQA gold row count dropped by {row_count_drop_pct:.1%} vs the current table "
            f"(max allowed {MAX_ALLOWED_ROW_COUNT_DROP_PCT:.0%}) - overwrite blocked."
        ),
        pipeline_write_env=PIPELINE_WRITE_ENV,
        expectation_type="check_row_count_drop",
        log_to_event_table=True,
        log_successes=True,
        raw_result={
            "row_count_drop_check": {
                "success": row_count_drop_pct <= MAX_ALLOWED_ROW_COUNT_DROP_PCT,
                "expectation_type": "check_row_count_drop",
                "current_row_count": current_gold_row_count,
                "new_row_count": output_row_count,
                "drop_pct": row_count_drop_pct,
            }
        },
    )
else:
    log.info(
        "HQA gold table does not exist yet or is currently empty - skipping row "
        "count drop check."
    )

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    dest_table=OUTPUT_GOLD_TABLE_HQA_INFOCENTER,
    df=df_hqa_transf,
    mode="overwrite",
    overwrite_schema=False,
    cluster_cols="date",
    merge_schema=True,
)
