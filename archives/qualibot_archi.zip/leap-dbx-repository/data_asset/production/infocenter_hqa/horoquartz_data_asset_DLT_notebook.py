# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # horoquartz data_asset
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to create a gold table and gold exposed views for horoquartz data asset
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC Know how to use DLT features
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Production
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{pipeline_read_env}_bronze.horoquartz_ingestion.atpeven_latest`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC -
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_silver.production.horoquartz_atpeven`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import dlt
import pyspark.sql.functions as f
import logging
from pyspark.sql import DataFrame as DataFrame

# COMMAND ----------

# Add bundle_root to sys.path for leap_utils imports (when running from Asset Bundle)
import sys

bundle_root = spark.conf.get("bundle_root", "")
if bundle_root and bundle_root not in sys.path:
    sys.path.insert(0, bundle_root)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

pipeline_read_env_param = spark.conf.get("pipeline_read_env", "default_value")
pipeline_write_env_param = spark.conf.get("pipeline_write_env", "default_value")
reference_read_env_param = spark.conf.get("reference_read_env", "default_value")
bronze_catalog_param = spark.conf.get("bronze_catalog", "default_value")
target_schema_param = spark.conf.get("target_schema", "default_value")
log_level_param = spark.conf.get("log_level", "info")

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", pipeline_write_env_param)
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", pipeline_read_env_param)
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", reference_read_env_param)
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("bronze_catalog", bronze_catalog_param)
BRONZE_CATALOG = dbutils.widgets.get("bronze_catalog")

dbutils.widgets.text("target_schema", target_schema_param)
BRONZE_SCHEMA = dbutils.widgets.get("target_schema")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue=log_level_param,
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

TABLE_ATPEVEN_LATEST = f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.atpeven_latest"
TABLE_PLANT_TIMEZONE = f"{BRONZE_CATALOG}.manual_input.mapping_plant_timezone"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SILVER_SCHEMA = "production"

GOLD_CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
GOLD_SCHEMA = "production"

TABLE_ATPEVEN_SILVER = f"{SILVER_CATALOG}.{SILVER_SCHEMA}.horoquartz_atpeven"
TABLE_ATPEVEN_GOLD = f"{GOLD_CATALOG}.{GOLD_SCHEMA}.horoquartz_atpeven"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.info(f"GOLD_SCHEMA is:  {GOLD_SCHEMA}")
log.info(f"TABLE_ATPEVEN_SILVER is:  {TABLE_ATPEVEN_SILVER}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Read Bronze Input Tables & Cast types
# MAGIC

# COMMAND ----------


@dlt.view(
    name="bronze_atpeven_cast",
    comment="ATPEVEN bronze table cast",
)
def df_bronze_atpeven_cast():
    df_bronze_atpeven = dlt.read(f"{TABLE_ATPEVEN_LATEST}")
    try:
        df_bronze_atpeven_cast = (
            df_bronze_atpeven.withColumn("id_group", f.col("id_group").cast("bigint"))
            .withColumn("manager_id", f.col("manager_id").cast("bigint"))
            .withColumn("operation", f.col("operation").cast("bigint"))
            .withColumn("duree_eve", f.col("duree_eve").cast("double"))
        )
    except Exception as e:
        log.warning(f"Erreur dans bronze_atpeven_cast: {e}")
        return df_bronze_atpeven

    return df_bronze_atpeven_cast


# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 -
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2 -

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------


@dlt.table(
    name=f"{TABLE_ATPEVEN_SILVER}",
    comment="atpeven silver view",
    table_properties={"quality": "silver"},
)
def atpeven_silver():
    # Lire bronze_atpeven_cast
    df_atpeven_silver = (
        dlt.read("bronze_atpeven_cast")
        .filter(f.col("_meta_validity_check") == True)
        .drop("_rescued_data", "_meta_validity_check")
    )

    # Retourner le DataFrame avec les colonnes sélectionnées
    return df_atpeven_silver


# COMMAND ----------
@dlt.table(
    name=f"{TABLE_ATPEVEN_GOLD}",
    comment="atpeven gold view",
    table_properties={"quality": "gold"},
)
def atpeven_gold():
    # Lire silver table
    df_plant_timezone = spark.table(TABLE_PLANT_TIMEZONE).withColumnRenamed(
        "plant_code", "division"
    )

    df_atpeven_gold = (
        dlt.read(f"{TABLE_ATPEVEN_SILVER}")
        .join(df_plant_timezone, on="division", how="inner")
        .withColumn(
            "datetime_deb_local",
            f.to_timestamp(
                f.concat_ws(
                    " ",
                    f.col("date_deb"),
                    f.date_format(f.col("heure_deb"), "HH:mm:ss.SSSSSS"),
                ),
                "yyyy-MM-dd HH:mm:ss.SSSSSS",
            ),
        )
        .withColumn(
            "datetime_fin_local",
            f.to_timestamp(
                f.concat_ws(
                    " ",
                    f.col("date_fin"),
                    f.date_format(f.col("heure_fin"), "HH:mm:ss.SSSSSS"),
                ),
                "yyyy-MM-dd HH:mm:ss.SSSSSS",
            ),
        )
        .withColumn(
            "datetime_deb",
            f.to_utc_timestamp(f.col("datetime_deb_local"), f.col("timezone")),
        )
        .withColumn(
            "datetime_fin",
            f.when(f.col("date_fin") == f.lit("1900-01-01"), None).otherwise(
                f.to_utc_timestamp(f.col("datetime_fin_local"), f.col("timezone"))
            ),
        )
        .withColumn(
            "tps_total_min",
            f.when(
                f.col("date_fin") == f.lit("1900-01-01"),
                f.round(
                    (
                        f.unix_timestamp(f.current_timestamp())
                        - f.unix_timestamp(f.col("datetime_deb"))
                    )
                    / 60,
                    2,
                ),
            ).otherwise(
                f.round(
                    (
                        f.unix_timestamp(f.col("datetime_fin"))
                        - f.unix_timestamp(f.col("datetime_deb"))
                    )
                    / 60,
                    2,
                )
            ),
        )
    )

    # Retourner le DataFrame avec les colonnes sélectionnées
    return df_atpeven_gold


# COMMAND ----------

# MAGIC %md
# MAGIC # Hooks

# COMMAND ----------

# N/A
