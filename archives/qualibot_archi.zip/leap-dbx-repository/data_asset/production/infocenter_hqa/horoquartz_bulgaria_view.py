# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The goal of this notebook is to create the Bulgaria view of the latest HQA data ingested in bronze. (Project table)
# MAGIC
# MAGIC **Input table(s):**
# MAGIC   - `{read_env}_bronze.horoquartz.infocenter_group`
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - `{write_env}_proj.horoquartz.infocenter_group_bulgaria_view`
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - `HQA pipeline` when `unity_catalog/Ingestion/Horoquartz/horoquartz_ingestion.py` is finished.
# MAGIC
# MAGIC **Things to do:**

# COMMAND ----------

# MAGIC %md
# MAGIC # Code

# COMMAND ----------

# DBTITLE 1,Widgets
# Get read environment variable
dbutils.widgets.text("read_env", "dev")
read_env = dbutils.widgets.get("read_env")

# Get write environment variable
dbutils.widgets.text("write_env", "dev")
write_env = dbutils.widgets.get("write_env")

# COMMAND ----------

spark

# COMMAND ----------

# MAGIC %md
# MAGIC # Functions

# COMMAND ----------


# DBTITLE 1,Get common names for database and table definition
def get_catalog_name(env: str, zone: str):
    """Return the catalog name using the environment and the medalion zone."""
    return f"{env}_{zone}"


def get_database_name(env: str, zone: str, domain: str):
    """Return the fully qualified catalog name using the environment, medalion zone and database domain."""

    return f"{get_catalog_name(env, zone)}.{domain}"


def get_table_name(env: str, zone: str, domain: str, tablename: str):
    """Return the fully qualified table name using the environment, medalion zone and database domain and table name."""

    return f"{get_database_name(env, zone, domain)}.{tablename}"


def get_common_data_names(env: str, zone: str, domain: str, tablename: str):
    """Return all three fully qualified names : catalog name, database name and table name."""
    return (
        get_catalog_name(env, zone),
        get_database_name(env, zone, domain),
        get_table_name(env, zone, domain, tablename),
    )


# COMMAND ----------


# DBTITLE 1,Create database if not exists
def create_database_if_not_exists(env: str, zone: str, domain: str):
    """
    Create a database if it does not exist.
    """
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {get_database_name(env, zone, domain)}")


# COMMAND ----------

# DBTITLE 1,Open hqa column names
import json


def open_hqa_column_mapping():
    """
    Lit le JSON contenant les paires : [destination_name, source_name].
    Retourne la liste de tuples (dest, source).
    """
    with open("./hqa_column_schema.json") as f:
        return json.load(f)


# COMMAND ----------


# DBTITLE 1,Get old column names to create view with SQL select statement
def get_hqa_view_select_statement():
    mapping = open_hqa_column_mapping()

    select_parts = [f"{src} AS `{dest}`" for dest, src in mapping]

    return ",\n        ".join(select_parts)


# COMMAND ----------


# DBTITLE 1,Create bulgaria view statement from bronze table
# TODO type inting and docstrings + explain business rule for HQA
def create_hqa_bulgaria_view(
    src_full_tablename: str, dest_full_tablename: str, debug: bool = False
):
    """
    Create the HQA bulgaria table view :
    - by filtering the rows that have a Division of 5000 (which is the code for the Bulgaria plant)
    - and keeping only rows that have the latest extraction timestamp to output only the rows of the latest source HQA file.

    Runs the create or replace view SQL statement for the HQA bulgaria view.
    """
    hqa_view_select_statement = get_hqa_view_select_statement()

    hqa_view_sql_statement = f"""
CREATE OR REPLACE VIEW {dest_full_tablename}
AS (
    SELECT {hqa_view_select_statement}
    FROM {src_full_tablename} AS hqa
    WHERE hqa.division = '5000'
)
"""

    if debug:
        print(hqa_view_sql_statement)

    spark.sql(hqa_view_sql_statement)


# COMMAND ----------

# MAGIC %md
# MAGIC # Run

# COMMAND ----------

# DBTITLE 1,Run
read_zone = "bronze"
write_zone = "proj"

read_domain = "horoquartz_ingestion"
write_domain = "horoquartz"

src_tablename = "infocenter_group_latest"
dest_tablename = "infocenter_group_bulgaria_view"

create_database_if_not_exists(write_env, write_zone, write_domain)

src_full_tablename = get_table_name(read_env, read_zone, read_domain, src_tablename)
dest_full_tablename = get_table_name(
    write_env, write_zone, write_domain, dest_tablename
)

create_hqa_bulgaria_view(src_full_tablename, dest_full_tablename, debug=False)
