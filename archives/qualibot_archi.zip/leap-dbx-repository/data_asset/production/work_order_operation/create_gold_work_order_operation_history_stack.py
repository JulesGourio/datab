# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # [WORK ORDER OPERATION HISTORY STACK]
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim of this notebook is to create a daily historisation of work order operation data asset.
# MAGIC
# MAGIC **Input Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_gold.production.work_order_operation
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.production.work_order_operation_history_stack

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("max_days_history", "90")
try:
    MAX_DAYS_HISTORY = int(dbutils.widgets.get("max_days_history"))
except ValueError:
    raise ValueError("Widget parameter 'max_days_history' must be an integer.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not.

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import 1 - work_order_operation

# COMMAND ----------

df_wo_ope = spark.read.table(f"{REFERENCE_READ_ENV}_gold.production.work_order_operation")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 1 - Add extraction metadata

# COMMAND ----------

extraction_timestamp = f.current_timestamp()
extraction_date = f.current_date()

extraction_date_str = (
    spark.range(1).select(extraction_date.alias("d")).first()["d"]
).isoformat()

df_wo_ope_prep = df_wo_ope.withColumn(
    "extraction_timestamp", extraction_timestamp
).withColumn("extraction_date", extraction_date)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

wo_ope_history_stack_path = (
    f"{PIPELINE_WRITE_ENV}_gold.production.work_order_operation_history_stack"
)

table_exists = table_utils.UnityCatalogCheckTableExists(wo_ope_history_stack_path)

# Schema evolution: add new columns if the source schema has changed
if table_exists:
    existing_cols = set(spark.read.table(wo_ope_history_stack_path).columns)
    new_cols = [
        (name, dtype)
        for name, dtype in df_wo_ope_prep.dtypes
        if name not in existing_cols
    ]
    if new_cols:
        print(
            f"Schema evolution detected — adding {len(new_cols)} new column(s): "
            f"{[c[0] for c in new_cols]}"
        )
        cols_query = ", ".join(f"`{name}` {dtype}" for name, dtype in new_cols)
        spark.sql(f"ALTER TABLE {wo_ope_history_stack_path} ADD COLUMNS ({cols_query})")
    else:
        print("Schema unchanged — no new columns detected.")

# History logic

if table_exists:
    dates_df = spark.sql(
        f"""
    SELECT DISTINCT extraction_date
    FROM {wo_ope_history_stack_path}
    ORDER BY extraction_date ASC
    LIMIT 91
    """
    )
    dates_already_in_table = [
        r["extraction_date"].isoformat() for r in dates_df.collect()
    ]
else:
    dates_already_in_table = None

if (
    dates_already_in_table is not None
    and len(dates_already_in_table) >= MAX_DAYS_HISTORY
    and extraction_date_str not in dates_already_in_table
):
    # If we reach the MAX_DAYS_HISTORY, we delete the oldest extraction_date.
    # If current extraction_date is in the table, we don't want to delete anything since we are going to replace it.
    oldest_date_str = dates_already_in_table[0]
    spark.sql(
        f"DELETE FROM {wo_ope_history_stack_path} WHERE extraction_date = '{oldest_date_str}'"
    )

replace_where = f"extraction_date = '{extraction_date_str}'"

table_utils.save_table(
    dest_table=wo_ope_history_stack_path,
    df=df_wo_ope_prep,
    mode="overwrite",  # we want to append here but the use of replace_where should always be with overwrite mode
    replace_where=replace_where,
)
