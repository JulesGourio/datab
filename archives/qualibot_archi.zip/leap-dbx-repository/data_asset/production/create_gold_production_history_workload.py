# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table & Gold_explosed for history Workload
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_gold.production.history_workload
# MAGIC   - {WRITE_ENV}_gold.production.history_workload_explosed
# MAGIC
# MAGIC **Intput :**  
# MAGIC   - {READ_ENV}_silver.production.history_workload
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Notebook create_silver_production_history_workload
# MAGIC
# MAGIC **Things performed in this notebook:**  
# MAGIC
# MAGIC - Add Material master data information
# MAGIC - Business translation
# MAGIC - Management Time unit

# COMMAND ----------

from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Silver Historic Workload

# COMMAND ----------

# Upload Work Order Gold Table
df_workload = spark.read.table(f"{READ_ENV}_silver.production.history_workload")

# COMMAND ----------

# MAGIC %md
# MAGIC # Enrichment Gold

# COMMAND ----------

# MAGIC %md
# MAGIC ##Management Material Description of Workload

# COMMAND ----------

## We keep Description comming from Work order header, if description is empty we take description from Gold Material Table
# Upload Gold Master Data Material
df_material = spark.read.table(
    f"prod_gold.master_data.material_master_data_basics_exposed"
)
df_material = df_material.withColumnRenamed("Material_Number", "Material_Number_")
df_material = df_material.select("Material_Number_", "Description")

# Join Master Data Material and WorkLoad
df_workload_description = df_workload.alias("A").join(
    df_material.alias("B"),
    f.col("A.Material_Number").cast("string")
    == f.col("B.Material_Number_").cast("string"),
    "left",
)
df_workload_description = df_workload_description.drop("Material_Number_", "Work_Order")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Determination of Profit center Planification type & Material status

# COMMAND ----------

## WARNING - Must be replace by Gold_exposed Material-Supply data asset  when it will be available
# -------------------------------------------------------------------------------------------------
df_marc = spark.read.table(f"prod_bronze.sap_latecoere_ecc6.marc_latest")
df_marc = df_marc.select("matnr", "werks", "prctr", "dismm", "mmsta")
df_marc = (
    df_marc.withColumnRenamed("prctr", "Profit_Center")
    .withColumnRenamed("dismm", "Planification_Type")
    .withColumnRenamed("mmsta", "Material_Status")
)
# Formatting Material_Number without '0' on left side
df_marc = df_marc.withColumn("matnr", f.regexp_replace(df_marc.matnr, "^0+", ""))

# Join Master Data Material and WorkLoad
df_workload = (
    df_workload_description.alias("A")
    .join(
        df_marc.alias("B"),
        (f.col("A.Material_Number") == f.col("B.matnr"))
        & (f.col("A.Plant") == f.col("B.werks")),
        "left",
    )
    .drop("matnr", "werks")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Add information for Plant Company and Production Plant

# COMMAND ----------

# Upload Gold Master Data Plant
df_plant = spark.read.table(f"prod_gold.master_data.plant_master_data_latest_exposed")
df_plant = df_plant.select("Plant", "Plant_Description_new")
df_plant = df_plant.withColumnRenamed("Plant", "Plant_").withColumnRenamed(
    "Plant_Description_new", "Production_Site"
)

# Join Plant description on Workload Table
df_workload_plant = (
    df_workload.alias("A")
    .join(
        f.broadcast(df_plant).alias("B"),
        f.col("A.Plant") == f.col("B.Plant_"),
        "left",
    )
    .drop("Plant_")
)
# Dispatch Production Site for Plant 1000 (Gimont/Montredon/DES)
df_workload_site = df_workload_plant.withColumn(
    "Production_Site",
    f.when(f.col("Plant") != "1000", f.col("Production_Site"))
    .when(f.substring(f.col("Mrp_controller"), 1, 1) == "O", f.lit("LFR-Montredon"))
    .when(f.col("Mrp_Controller") == "DET", f.lit("LFR-DES"))
    .otherwise(f.lit("LFR-Gimont")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Business traduction of SAP fields

# COMMAND ----------

# Determination of Description Order_Type
df_workload_end = df_workload_site.withColumn(
    "Order_Type_Description",
    f.when(
        (f.col("Order_Type") == "ZP01") | (f.col("Order_Type") == "ZP05"),
        f.lit("Detail Parts"),
    )
    .when(f.col("Order_Type") == "ZP02", f.lit("Kanban orders"))
    .when(
        (f.col("Order_Type") == "ZP03") | (f.col("Order_Type") == "ZP04"),
        f.lit("Assembly Parts"),
    )
    .otherwise(f.lit("Rush Orders")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Management Time unit

# COMMAND ----------

# We decide to Convert everything in Minutes
df_workload_end = df_workload_end.withColumn(
    "Hours_Real",
    f.when(f.col("Unit_Time") == "MIN", f.col("Hours_Real")).otherwise(
        f.col("Hours_Real") * 60
    ),
)
df_workload_end = df_workload_end.withColumn(
    "Hours_Theo",
    f.when(f.col("Unit_Time") == "MIN", f.col("Hours_Theo")).otherwise(
        f.col("Hours_Theo") * 60
    ),
)
df_workload_end = df_workload_end.withColumn("Unit_Time", f.lit("MIN"))

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "production"
table = "history_workload"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_workload_end,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold exposed table

# COMMAND ----------

catalog = "gold"
domain = "production"
table = "history_workload"
src_full_tablename = f"{WRITE_ENV}_{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "S022"
selected_columns = [
    col for col in df_workload_end.columns if not col.startswith(Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
