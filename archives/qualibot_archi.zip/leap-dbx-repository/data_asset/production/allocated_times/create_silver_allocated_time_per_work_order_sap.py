# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for allocated time on operation in Work order. 
# MAGIC - Cleaning of data format
# MAGIC - Join with dimension table 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afvc_latest
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afvv_latest
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.aufk_latest
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.crhd_latest
# MAGIC   - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_afvc
# MAGIC   - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_afvv
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_silver.production.allocated_time_per_WO_sap
# MAGIC   
# MAGIC **Triggered by:**  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Tech Debt

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - **df_afvc_raw** is the SAP master data table of operation in work order
# MAGIC - **df_afvv_raw** is the SAP table that gives the allocated time per operation
# MAGIC - **df_afko_raw** is the work order (header) SAP table
# MAGIC - **df_crhd_raw** is the SAP table for workcenter
# MAGIC   

# COMMAND ----------

df_afvc_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afvc_latest"
)
df_header_afvc = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_afvc"
)

# COMMAND ----------

df_afvv_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afvv_latest"
)
df_header_afvv = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_afvv"
)

# COMMAND ----------

# We keep only work order with routing id to link with operation
df_afko_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afko_latest"
).select(f.col("aufnr").alias("work_order"), f.col("aufpl").alias("routing_id"))

# COMMAND ----------

df_crhd_raw = (
    spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.crhd_latest")
    .select(
        f.col("objid").alias("work_center_code"),
        f.col("arbpl").alias("work_center"),
        f.col("werks").alias("plant"),
    )
    .dropDuplicates()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Columns renaming

# COMMAND ----------

# Renaming AFVC columns
df_afvc_prep = table_utils.add_prefix_to_columns(df_afvc_raw, "afvc")

df_afvc_prep = table_utils.rename_columns_with_sap_business_header(
    df_afvc_prep, df_header_afvc
)
# Renaming AFVV columns
df_afvv_prep = table_utils.add_prefix_to_columns(df_afvv_raw, "afvv")

df_afvv_prep = table_utils.rename_columns_with_sap_business_header(
    df_afvv_prep, df_header_afvv
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - Removing leading zeros

# COMMAND ----------

df_afvv_end = table_utils.remove_leading_zeros(
    df_afvv_prep,
    ["routing_id", "routing_id_item"],
)
df_afvc_end = table_utils.remove_leading_zeros(
    df_afvc_prep, ["routing_id", "routing_id_item", "work_order_operation"]
)
df_afko_end = table_utils.remove_leading_zeros(
    df_afko_raw, ["routing_id", "work_order"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 1 - Join all tables 
# MAGIC To create an understandable table of allocated times per work orders.

# COMMAND ----------

df_allocated_time = (
    df_afko_end.join(df_afvc_end, ["routing_id"], how="left")
    .join(df_afvv_end, ["routing_id", "routing_id_item"], how="left")
    .join(df_crhd_raw, ["work_center_code", "plant"], how="left")
    .drop("work_center_code")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

OUTPUT_PATH_NAME = f"{PIPELINE_WRITE_ENV}_silver.production.allocated_time_per_WO_sap"

table_utils.save_table(
    dest_table=OUTPUT_PATH_NAME,
    df=df_allocated_time,
    mode="overwrite",
)
