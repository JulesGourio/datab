# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table with allocated time per work order / operations. It is specified "sap" because this information can also be catched from horoquartz. 
# MAGIC
# MAGIC **Performed in this notebook:**
# MAGIC - Enrichments with WO information 
# MAGIC - Conversion of all time columns in minutes
# MAGIC - Calculation of the total allocated time 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.production.allocated_time_per_WO_sap
# MAGIC   
# MAGIC **Inputs:**  
# MAGIC   - {REFERENCE_READ_ENV}_gold.production.allocated_time_per_WO_sap
# MAGIC   - {REFERENCE_READ_ENV}_gold.production.sap_work_order_basics_latest_exposed
# MAGIC
# MAGIC **Used by:**  
# MAGIC Production use cases

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import DataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - **df_allocated_time_silver_raw** is the silver table of this data asset of allocated hours per work order
# MAGIC - **df_wo_gold_raw** is the gold table of work orders

# COMMAND ----------

df_allocated_time_silver_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.production.allocated_time_per_WO_sap"
)

# COMMAND ----------

df_wo_gold_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.production.sap_work_order_basics_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

COLUMNS_TO_SELECT_WO = [
    "WO_Number",
    "Material_Number",
    "WO_Description",
    "Profit_Center",
    "End_Planned_Date",
    "Mrp_Controller",
    "Order_Type",
    "Quantity_Ordered",
    "WBS_Code",
    "WO_Status",
    "Production_Site",
    "Branch",
    "Creation_Date",
]

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Work order gold table

# COMMAND ----------

df_wo_gold = df_wo_gold_raw.select(COLUMNS_TO_SELECT_WO).withColumnRenamed(
    "WO_Number", "work_order"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 1 - Join with gold work order table

# COMMAND ----------

df_gold_allocated = df_wo_gold.join(
    df_allocated_time_silver_raw, ["work_order"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 2 - Calcul Allocated Time

# COMMAND ----------

def calculate_time_to_minutes(
    df: DataFrame,
    new_time_column_name: str,
    time_column_name: str,
    time_unit_column_name: str,
    quantity_ordered_col_name: str,
    quantity_base_col_name: str,
) -> DataFrame:
    """
    Add a column that calculated, based on the unit, the time and the quantity, the time in minutes

    :param df: Input Spark dataframe.
    :type df: pyspark.sql.DataFrame
    :param new_time_column_name: Name of the calculated column.
    :type new_time_column_name: str
    :param time_column_name: Column name of the time which is the reference for the calculation.
    :type time_column_name: str
    :param time_unit_column_name: Column name of the unit of the time column.
    :type time_unit_column_name: str
    :param quantity_ordered_col_name: Column name of the quantity ordered.
    :type quantity_ordered_col_name: str
    :param quantity_base_col_name: Column name of the unit of the quantity ordered.
    :type quantity_base_col_name: str
    :return: Dataframe with the additional time in minute column.
    :rtype: pyspark.sql.DataFrame
    """
    time_col = f.col(time_column_name).try_cast("double")
    quantity_ordered_col = f.col(quantity_ordered_col_name).try_cast("double")
    quantity_base_col = f.col(quantity_base_col_name).try_cast("double")

    df_calculated = df.withColumn(
        new_time_column_name,
        f.when(
            f.col(time_unit_column_name) == "MIN",
            f.try_divide(time_col * quantity_ordered_col, quantity_base_col),
        )
        .when(
            (f.col(time_unit_column_name) == "JRS")
            | (f.col(time_unit_column_name) == "JR"),
            f.try_divide(time_col * f.lit(720) * quantity_ordered_col, quantity_base_col),
        )
        .when(
            (f.col(time_unit_column_name) == "HRE")
            | (f.col(time_unit_column_name) == "H")
            | (f.col(time_unit_column_name) == "STD"),
            f.try_divide(time_col * f.lit(60) * quantity_ordered_col, quantity_base_col),
        )
        .otherwise(
            f.try_divide(time_col * quantity_ordered_col, quantity_base_col)
        ),
    )
    return df_calculated


def calculate_time_spend_to_minutes(
    df: DataFrame,
    new_time_column_name: str,
    time_column_name: str,
    time_unit_column_name: str,
) -> DataFrame:
    """
    Add a column that calculated, based on the unit, the time and the quantity, the time in minutes

    :param df: Input Spark dataframe.
    :type df: pyspark.sql.DataFrame
    :param new_time_column_name: Name of the calculated column.
    :type new_time_column_name: str
    :param time_column_name: Column name of the time which is the reference for the calculation.
    :type time_column_name: str
    :param time_unit_column_name: Column name of the unit of the time column.
    :type time_unit_column_name: str
    :return: Dataframe with the additional time in minute column.
    :rtype: pyspark.sql.DataFrame
    """
    time_col = f.col(time_column_name).try_cast("double")

    df_calculated = df.withColumn(
        new_time_column_name,
        f.when(
            f.col(time_unit_column_name) == "MIN",
            time_col,
        )
        .when(
            (f.col(time_unit_column_name) == "JRS")
            | (f.col(time_unit_column_name) == "JR"),
            time_col * f.lit(720),
        )
        .when(
            (f.col(time_unit_column_name) == "HRE")
            | (f.col(time_unit_column_name) == "H")
            | (f.col(time_unit_column_name) == "STD"),
            time_col * f.lit(60),
        )
        .otherwise(
            time_col
        ),
    )
    return df_calculated


def convert_preparation_time_to_minutes(
    df: DataFrame,
    new_time_column_name: str,
    time_column_name: str,
    time_unit_column_name: str,
) -> DataFrame:
    """
    Add a column that convert the preparation time in minutes.
    It is different than the previous function because the quantity is not taken into account for this time calculation.

    :param df: Input Spark dataframe.
    :type df: pyspark.sql.DataFrame
    :param new_time_column_name: Name of the calculated column.
    :type new_time_column_name: str
    :param time_column_name: Column name of the time which is the reference for the calculation.
    :type time_column_name: str
    :param time_unit_column_name: Column name of the unit of the time column.
    :type time_unit_column_name: str
    :return: Dataframe with the additional time in minute column.
    :rtype: pyspark.sql.DataFrame
    """
    time_col = f.col(time_column_name).try_cast("double")

    df_converted = df.withColumn(
        new_time_column_name,
        f.when(f.col(time_unit_column_name) == "MIN", time_col)
        .when(
            (f.col(time_unit_column_name) == "JRS")
            | (f.col(time_unit_column_name) == "JR"),
            time_col * f.lit(720),
        )
        .when(
            (f.col(time_unit_column_name) == "HRE")
            | (f.col(time_unit_column_name) == "H")
            | (f.col(time_unit_column_name) == "STD"),
            time_col * f.lit(60),
        )
        .otherwise(time_col),
    )
    return df_converted

# COMMAND ----------

# Decision was take to convert all allocated time in Minutes
# Preparation time calcul
df_gold_allocated_calcul = convert_preparation_time_to_minutes(
    df_gold_allocated,
    "preparation_time_min",
    "preparation_time",
    "preparation_time_unit",
)
df_gold_allocated_calcul = convert_preparation_time_to_minutes(
    df_gold_allocated_calcul,
    "preparation_time_spend_min",
    "preparation_time_spend",
    "preparation_time_unit",
)
# -----------------------------------------------------------------------------------------------------------------
# Others calcul
df_gold_allocated_calcul = calculate_time_to_minutes(
    df_gold_allocated_calcul,
    "labor_time_min",
    "labor_time",
    "labor_time_unit",
    "Quantity_Ordered",
    "quantity_base",
)
df_gold_allocated_calcul = calculate_time_to_minutes(
    df_gold_allocated_calcul,
    "machine_time_min",
    "machine_time",
    "machine_time_unit",
    "Quantity_Ordered",
    "quantity_base",
)
df_gold_allocated_calcul = calculate_time_to_minutes(
    df_gold_allocated_calcul,
    "lean_time_min",
    "lean_time",
    "lean_time_unit",
    "Quantity_Ordered",
    "quantity_base",
)
df_gold_allocated_calcul = calculate_time_spend_to_minutes(
    df_gold_allocated_calcul,
    "labor_time_spend_min",
    "labor_time_spend",
    "labor_time_unit",
)
df_gold_allocated_calcul = calculate_time_spend_to_minutes(
    df_gold_allocated_calcul,
    "machine_time_spend_min",
    "machine_time_spend",
    "machine_time_unit",
)
df_gold_allocated_calcul = calculate_time_spend_to_minutes(
    df_gold_allocated_calcul,
    "lean_time_spend_min",
    "lean_time_spend",
    "lean_time_unit",
)
# Cycle time is only used for scheduling not take in account for time allocated

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 3 - Calcul Global Allocated Time

# COMMAND ----------

# Calculation - Global Allocated time by Operation
df_gold_allocated_end = df_gold_allocated_calcul.withColumn(
    "global_time_allocated_min",
    f.col("preparation_time_min")
    + f.col("labor_time_min")
    + f.col("machine_time_min")
    + f.col("lean_time_min"),
)

# Calculation - Global Spend time by Operation
df_gold_allocated_end = df_gold_allocated_end.withColumn(
    "global_time_spend_min",
    f.col("preparation_time_spend_min")
    + f.col("labor_time_spend_min")
    + f.col("machine_time_spend_min")
    + f.col("lean_time_spend_min"),
)
# --------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC #Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold table 

# COMMAND ----------

OUTPUT_PATH_NAME = f"{PIPELINE_WRITE_ENV}_gold.production.allocated_time_per_wo_sap"
table_utils.save_table(
    dest_table=OUTPUT_PATH_NAME, df=df_gold_allocated_end, mode="overwrite"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Exposed table

# COMMAND ----------

Begin_By = "afv"
selected_columns = [
    col for col in df_gold_allocated_end.columns if not col.startswith(Begin_By)
]
select_statement = ", ".join(selected_columns)

src_full_tablename = OUTPUT_PATH_NAME
dest_full_tablename = f"{src_full_tablename}_exposed"

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
