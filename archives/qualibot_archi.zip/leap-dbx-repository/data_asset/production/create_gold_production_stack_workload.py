# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table for stack History & previsionnal Workload
# MAGIC
# MAGIC **Output table:**  
# MAGIC   - {WRITE_ENV}_gold.production.full_workload
# MAGIC
# MAGIC **Intput :**  
# MAGIC   - {READ_ENV}_gold.production.prev_workload_explosed
# MAGIC   - {READ_ENV}_gold.production.history_workload_explosed
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Notebook create_gold_production_prev_workload  
# MAGIC Notebook create_gold_production_history_workload  
# MAGIC
# MAGIC **Things performed in this notebook:**  
# MAGIC
# MAGIC - Stack Previsionnal & History
# MAGIC - Determine Workload Category 
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Gold Workload Previsionnal & Historic

# COMMAND ----------

# Upload Workload Gold Table
df_workload_previsionnal = spark.read.table(
    f"{READ_ENV}_gold.production.prev_workload_exposed"
)
df_workload_history = spark.read.table(
    f"{READ_ENV}_gold.production.history_workload_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Creation Workload Category and union Prev & Histo

# COMMAND ----------

# Determine Workload Category
df_workload_previsionnal = df_workload_previsionnal.withColumn(
    "WorkLoad_Type", f.lit("WL_Prev")
)
df_workload_history = df_workload_history.withColumn("WorkLoad_Type", f.lit("WL_Real"))
# Union Historic and Previsionnal
df_workload_full = df_workload_previsionnal.unionByName(
    df_workload_history, allowMissingColumns=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "production"
table = "full_workload"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_workload_full,
    mode="overwrite",
    overwrite_schema=True
)
