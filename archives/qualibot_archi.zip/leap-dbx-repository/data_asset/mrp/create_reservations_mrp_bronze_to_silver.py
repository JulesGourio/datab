# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose of SILVER MRP reservation table
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for Needs Reservation
# MAGIC
# MAGIC This database was created to centralize and structure reservation data 
# MAGIC from the MRP (Material Requirements Planning) system in SAP.  
# MAGIC The main goals are:  
# MAGIC  - to analyze procurement requirements,  
# MAGIC  - to track the evolution of reservations,  
# MAGIC  - to facilitate controls and reporting,  
# MAGIC  - to support decision-making in stock management and planning.  
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - `{PIPELINE_WRITE_ENV}_silver.mrp.reservation_mrp_sap`
# MAGIC
# MAGIC **Input :**  
# MAGIC - `{REFERENCE_READ_ENV}__bronze.sap_latecoere_ecc6.resb_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_resb`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afpo_latest`  
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.plaf_latest`  
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekpo_latest` 
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eban_latest`  
# MAGIC
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC  - SAP Bronze Ingestion  
# MAGIC  
# MAGIC **Things performed in this notebook:** 
# MAGIC
# MAGIC - Cleaning data
# MAGIC - Renaming Headers 
# MAGIC - Add Mrp Unit 
# MAGIC - Saving

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame, Window
import time
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils, amount_correction

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull())
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### RESB – Dependent requirements
# MAGIC
# MAGIC The RESB table shows what is reserved and what remains to be delivered according to quantities, dates, statuses, etc.

# COMMAND ----------

df_resb_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.resb_latest"
)
df_resb_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_resb"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### AFPO – Work order items 
# MAGIC This table will be use only to catch MRP unit that is not in Resb table

# COMMAND ----------

df_afpo_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.afpo_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### PLAF – Planned order items 
# MAGIC This table will be use only to catch MRP unit that is not in Resb table

# COMMAND ----------

df_plaf_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.plaf_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EKPO – Purchase Order Items  
# MAGIC This table will be use only to catch MRP unit that is not in Resb table

# COMMAND ----------

df_ekpo_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekpo_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EBAN – Purchase Request Items  
# MAGIC This table will be use only to catch MRP unit that is not in Resb table

# COMMAND ----------

df_eban_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eban_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – RESB    
# MAGIC Applies:
# MAGIC - Column prefixing
# MAGIC - Business-name-based renaming
# MAGIC - Format casting based on SAP header metadata

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 1.1 – Management quantity due to specific unit PC2 in SAP

# COMMAND ----------

# Due to specific implementation of Latecoere rules in SAP
# we have to switch quantity needed according specific unit PC2
# It only concerns planification
 
df_resb = df_resb_raw.withColumn(
    "bdmng",
    f.when(
        (f.col("erfme") == "PC2")
        & (f.col("meins") == "U")
        & (f.col("alpos") == "X")
        & (f.col("bdart") == "SB"),
        f.col("ewahr") * f.col("nomng") / 100,
    )
    .when(
        (f.col("erfme") == "PC2")
        & (f.col("meins") == "U")
        & (f.col("bdart") == "SB")
        & (f.col("alpos").isNull()),
        f.col("nomng"),
    )
    .otherwise(f.col("bdmng")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prep. 1.2 – RESB  Renaming headers

# COMMAND ----------

df_resb_end = table_utils.add_prefix_to_columns(df_resb, "RESB")
# Call Function Delete rows null
df_name_resb= delete_null_rows(df_resb_header)
# Call Function Rename Columns according header file
df_column_resb = table_utils.rename_columns_with_sap_business_header(
    df_resb_end, df_name_resb
)
# Call Funtion Create Columns on Date format
df_resb_end = table_utils.cast_columns_with_sap_business_headers(
    df_column_resb, df_name_resb
)

df_resb_cleaned = table_utils.remove_leading_zeros(
    df=df_resb_end,
    column_names=[
        "material_number",
        "reservation_number",
        "reservation_item_number",
        "material_number",
        "material_number_origin",
        "work_order_origin",
        "planned_order_origin",
        "PO_number_origin",
        "PO_item_number_origin",
        "PR_number_origin",
        "PR_item_number_origin",
        "sales_order_origin",
        "sales_order_item_origin",
        "WBS_element",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 – AFPO

# COMMAND ----------

df_afpo_prep = df_afpo_raw.select(
    f.col("aufnr").alias("work_order_origin"), f.col("berid").alias("MRP_unit_WO")
)
df_afpof_clean = table_utils.remove_leading_zeros(
    df=df_afpo_prep,
    column_names=[
        "work_order_origin",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 – PLAF

# COMMAND ----------

df_plaf_prep = df_plaf_raw.select(
    f.col("plnum").alias("planned_order_origin"), f.col("berid").alias("MRP_unit_PLO")
)
df_plaf_clean = table_utils.remove_leading_zeros(
    df=df_plaf_prep,
    column_names=[
        "planned_order_origin",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 4 – EKPO

# COMMAND ----------

df_ekpo_prep = df_ekpo_raw.select(
    f.col("ebeln").alias("PO_number_origin"),
    f.col("ebelp").alias("PO_item_number_origin"),
    f.col("berid").alias("MRP_unit_PO"),
)
df_ekpo_clean = table_utils.remove_leading_zeros(
    df=df_ekpo_prep,
    column_names=[
        "PO_number_origin",
        "PO_item_number_origin",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 5 – EBAN

# COMMAND ----------

df_eban_prep = df_eban_raw.select(
    f.col("banfn").alias("PR_number_origin"),
    f.col("bnfpo").alias("PR_item_number_origin"),
    f.col("berid").alias("MRP_unit_PR"),
)
df_eban_clean = table_utils.remove_leading_zeros(
    df=df_eban_prep,
    column_names=[
        "PR_number_origin",
        "PR_item_number_origin",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 - Add MRP unit to reservation

# COMMAND ----------

df_reservation = (
    df_resb_cleaned.join(df_afpof_clean, ["work_order_origin"], "left")
    .join(df_plaf_clean, ["planned_order_origin"], "left")
    .join(df_ekpo_clean, ["PO_number_origin", "PO_item_number_origin"], "left")
    .join(df_eban_clean, ["PR_number_origin", "PR_item_number_origin"], "left")
)
df_reservation_end = df_reservation.withColumn(
    "MRP_unit",
    f.coalesce(
        f.col("MRP_unit_PLO"),
        f.col("MRP_unit_PO"),
        f.col("MRP_unit_PR"),
        f.col("MRP_unit_WO"),
        f.col("plant"),
    ),
).drop("MRP_unit_PLO", "MRP_unit_PO", "MRP_unit_PR", "MRP_unit_WO")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 – Business Indicator Flags

# COMMAND ----------

df_reservation_end = (
    df_reservation_end.withColumn(
        "is_cancelled_item",
        f.when(f.col("item_cancel").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .withColumn(
        "is_closed_item",
        f.when(f.col("item_closed").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .withColumn(
        "is_bulk_item",
        f.when(
            (f.col("phantom_item").isNull()) & (f.col("bulk_item").isNull()),
            f.lit(False),
        ).otherwise(f.lit(True)),
    )
    .withColumn(
        "is_manual_item",
        f.when(f.col("reservation_type") == "M", f.lit(True)).otherwise(f.lit(False)),
    ).withColumn(
        "is_mrp_relevant",
        f.when(f.col("movement_type").like("3%"), f.lit(False)).otherwise(f.lit(True)),
    )
    .drop("item_cancel", "item_closed", "phantom_item", "bulk_item", "reservation_type")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_reservation_end = df_reservation_end.withColumn(
    "reservation_mrp_sap_ID",
    f.concat_ws(
        "-",
        f.col("reservation_number"),
        f.col("reservation_item_number"),
        f.col("register_type"),
    ),
)

# COMMAND ----------

df_to_check = df_reservation_end
col_pk = "reservation_mrp_sap_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for mrp reservation table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="reservation_mrp_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "mrp"
DESTINATION_TABLE = "reservation_mrp_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_reservation_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_reservation_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "silver_reservation_mrp_sap_pk"
TABLE_PK_COLS = "reservation_mrp_sap_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
