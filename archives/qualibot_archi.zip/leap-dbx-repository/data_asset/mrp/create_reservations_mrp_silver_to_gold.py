# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose of GOLD MRP reservation table
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table for Needs Reservation
# MAGIC
# MAGIC This database was created to centralize and structure reservation data 
# MAGIC from the MRP (Material Requirements Planning) system in SAP.  
# MAGIC The main goals are:  
# MAGIC  - to analyze procurement requirements,  
# MAGIC  - to track the evolution of reservations,  
# MAGIC  - to facilitate controls and reporting,  
# MAGIC  - to support decision-making in stock management and planning.  
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.mrp.reservation_mrp_sap`
# MAGIC
# MAGIC **Input :**  
# MAGIC - `{PIPELINE_READ_ENV}_silver.mrp.reservation_mrp_sap`  
# MAGIC - `{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed`
# MAGIC - `{REFERENCE_READ_ENV}_gold.finance.wbs_otp_exposed`  
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC  - N/A 
# MAGIC  
# MAGIC **Things performed in this notebook:** 
# MAGIC
# MAGIC - Add WBS information  
# MAGIC - Add Material Master data  
# MAGIC - Add Business Rules  

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame, Window
import time
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### SILVER – MRP Reservations

# COMMAND ----------

df_silver_reservation = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.mrp.reservation_mrp_sap"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Material by plant
# MAGIC **df_gold_material** Extraction master data material

# COMMAND ----------

df_gold_material = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - WBS Master Data  
# MAGIC **df_gold_wbs**  Extraction Master Data Supplier 

# COMMAND ----------

df_gold_wbs = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.wbs_otp_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – Material Master data

# COMMAND ----------

df_gold_material_prepared = df_gold_material.select(
    "material_number",
    "material_description",
    "plant",
    "MRP_unit",
    "profit_center",
    "mrp_controller",
    "buyer",
    "division",
    "region",
    "company",
    "company_description",
    "stock_site",
    "standard_price_eur_budget",
    "average_price_eur_budget",
)
df_gold_material_usage = df_gold_material.select(
    f.col("material_number").alias("material_number_origin"),
    "plant",
    "MRP_unit",
    f.col("profit_center").alias("profit_center_origin"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 – WBS

# COMMAND ----------

df_gold_wbs = df_gold_wbs.select(
    f.col("WBS_Code_Num").alias("WBS_element"), f.col("WBS_Code").alias("WBS_code")
)
#Cleaning data
df_gold_wbs = table_utils.remove_leading_zeros(
    df=df_gold_wbs,
    column_names=[
        "WBS_element",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 - Add remaining quantity & update item_closed

# COMMAND ----------

df_gold_reservation_rules = df_silver_reservation.withColumn(
    "quantity_remaining", f.col("quantity_needed") - f.col("quantity_consumed")
).withColumn(
    "is_closed_item",
    f.when(f.col("quantity_remaining") <= 0, f.lit(True)).otherwise(
        f.col("is_closed_item")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 – Add WBS - information

# COMMAND ----------

df_reservation_wbs = df_gold_reservation_rules.join(df_gold_wbs, ["WBS_element"], "left").drop(
    "WBS_element"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 – Add Material Information

# COMMAND ----------

df_reservation_material = df_reservation_wbs.join(
    df_gold_material_prepared, ["material_number", "plant", "MRP_unit"], "left"
).join(df_gold_material_usage, ["material_number_origin", "plant", "MRP_unit"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 4 – Add status of reservation

# COMMAND ----------

df_reservation_mrp_end = df_reservation_material.withColumn(
    "reservation_status",
    f.when(f.col("is_cancelled_item") == "true", f.lit("Reservation_cancelled"))
    .when(f.col("is_closed_item") == "true", f.lit("Reservation_closed"))
    .when(f.col("is_bulk_item") == "true", f.lit("Reservation_bulk"))
    .otherwise(f.lit("Reservation_open")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_to_check = df_reservation_mrp_end
col_pk = "reservation_mrp_sap_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for mrp reservation table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="reservation_mrp_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "mrp"
DESTINATION_TABLE = "reservation_mrp_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_reservation_mrp_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_reservation_mrp_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – Exposed Table View

# COMMAND ----------

dest_full_tablename = f"{DESTINATION_TABLE_FULL_PATH}_exposed"
Begin_By = [
    "RESB",
]

selected_columns = [
    col
    for col in df_reservation_mrp_end.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH, dest_full_tablename, select_statement, replace_view=True
)

log.info(f"The table view {dest_full_tablename} has been successfully created")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_reservation_mrp_sap_pk"
TABLE_PK_COLS = "reservation_mrp_sap_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
