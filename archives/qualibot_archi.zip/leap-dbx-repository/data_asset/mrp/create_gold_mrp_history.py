# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # MRP LIST WEEKLY HISTORY GOLD and GOLD_EXPOSED
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The purpose of this notebook is to create a gold history table for MRP List (Ressources / Needs).
# MAGIC The notebook performs the following tasks:
# MAGIC
# MAGIC - Data Loading: Loads the silver history table 
# MAGIC - Data Loading: Loads the tfacs bronze latest table
# MAGIC - Preparation : Prepare the calendar from tfacs input
# MAGIC - Data Filtering: N/A
# MAGIC - Date Formatting: N/A
# MAGIC - Column Renaming: Renames specific columns to be exposed
# MAGIC - Table Joining : Join MRP history to cal
# MAGIC - Gold Table Creation: Generates a gold table with the cleaned and transformed data and a gold exposed view
# MAGIC - Historization done on field : extraction_date
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - Calendar preparation
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - MRP-list_mrp_full-Asset-Weekly
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - Update : Daily
# MAGIC   - History : Once (exceptionally more)
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC   - {reference_read_env}__silver.mrp.list_mrp_full_history
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.tfacs_latest
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.mrp.list_mrp_full_history
# MAGIC - {pipeline_write_env}_gold.mrp.list_mrp_full_history_exposed
# MAGIC
# MAGIC **Output Files Pipeline**
# MAGIC N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. Quality checks to be defined if needed
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
import datetime
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.window import Window
from typing import List, Dict, Iterable

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Spark
# MAGIC

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC ```
# MAGIC ```
# MAGIC #### functions used from "leap_utils.data_asset.table_utils"
# MAGIC ```
# MAGIC table_utils.UnityCatalogCheckTableExists()
# MAGIC table_utils.create_unity_catalog_table
# MAGIC table_utils.set_table_column_not_null()
# MAGIC table_utils.add_table_primary_key()
# MAGIC table_utils.create_table_view()
# MAGIC ```

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("run_job_on_latest", "true")  # history/update
RUN_JOB_ON_LATEST = dbutils.widgets.get("run_job_on_latest").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "debug")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables Location
# MAGIC
# MAGIC Details on how to read the input tables

# COMMAND ----------

BRONZE_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6"
SILVER_SCHEMA = f"{PIPELINE_READ_ENV}_silver.mrp"

# SAP table TFACS
t_tfacs_latest = f"{BRONZE_SCHEMA}.tfacs_latest"

# Silver MRP history
t_silver_mrp_history = f"{SILVER_SCHEMA}.list_mrp_full_history"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

GOLD_SCHEMA = f"{PIPELINE_WRITE_ENV}_gold.mrp"
TABLE_DEST = f"{GOLD_SCHEMA}.list_mrp_full_history"
TABLE_DEST_PK = "list_mrp_full_history_PK"
MODE = "append" if RUN_JOB_ON_LATEST else "overwrite"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# Columns needed to create the empty table at first run
TABLE_DEST_FIRST_COLS = {
    "mdkp_stack_row_id": "BIGINT",
    "mdkp_ID": "STRING",
    "extraction_date": "DATE",
    "mdkp_extraction_timestamp": "TIMESTAMP",
    "mdkp_ingestion_timestamp": "TIMESTAMP",
    "mdkp_file_name": "STRING",
    "mdkp_file_mode": "STRING",
    "mdkp_table_name": "STRING",
    "mdkp_file_modification_time": "TIMESTAMP",
    "mdkp_mandt": "STRING",
    "mdkp_dtart": "STRING",
    "Material_Number": "STRING",
    "Plant": "STRING",
}

# As it's a huge table, we'll cluster it by these columns, rather than partitioning
TABLE_DEST_CLUSTER_COLS = "extraction_date,Material_Number,Plant"

# As a best practice, we'll define a Primary Key on the output table, below are the PK columns
TABLE_DEST_PK_COLS = "extraction_date,mdkp_ID,mdtb_ID"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# Sample reference date when target table exists ans is empty
THE_ORIGIN = "1970-01-01"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs 
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.debug(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.debug(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.debug(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.debug(f"RUN_JOB_ON_LATEST is:  {RUN_JOB_ON_LATEST}")
log.debug(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.debug(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.debug(f"GOLD_SCHEMA is:  {GOLD_SCHEMA}")
log.debug(f"TABLE_DEST is:  {TABLE_DEST}")
log.debug(f"MODE is:  {MODE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Read tables
# MAGIC - Stack and match

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Tables MRP & headers

# COMMAND ----------

# Upload SAP table TFACS
df_tfacs = spark.read.table(f"{t_tfacs_latest}")

# Upload MRP history
df_silver_mrp_history = spark.read.table(f"{t_silver_mrp_history}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Repartition Tables by 'Rescheduling_Date','ID_Calendar','Reception_Time'

# COMMAND ----------

df_silver_mrp_history = df_silver_mrp_history.repartition(
    "Rescheduling_Date", "ID_Calendar", "Reception_Time"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# Standard MELT function
def melt(
    df: SparkDataFrame,
    id_vars: Iterable[str],
    value_vars: Iterable[str],
    var_name: str = "variable",
    value_name: str = "value",
) -> SparkDataFrame:
    """Convert :class:`SparkDataFrame` from wide to long format."""

    # Create array<struct<variable: str, value: ...>>
    _vars_and_vals = f.array(
        *(
            f.struct(f.lit(c).alias(var_name), f.col(c).alias(value_name))
            for c in value_vars
        )
    )

    # Add to the DataFrame and explode
    _tmp = df.withColumn("_vars_and_vals", f.explode(_vars_and_vals))

    cols = id_vars + [
        f.col("_vars_and_vals")[x].alias(x) for x in [var_name, value_name]
    ]
    return _tmp.select(*cols)


# Converts TFACs to Calendar dataframe
def ConvertTFACsToCal(df_TFACs: SparkDataFrame):

    # Rename TFACs Columns -> This section can be replaces if TFACs is pre-processed
    rename_dict = {
        "ident": "CountryCode",
        "jahr": "Year",
        "mon01": "01",
        "mon02": "02",
        "mon03": "03",
        "mon04": "04",
        "mon05": "05",
        "mon06": "06",
        "mon07": "07",
        "mon08": "08",
        "mon09": "09",
        "mon10": "10",
        "mon11": "11",
        "mon12": "12",
    }

    for key in rename_dict.keys():
        df_TFACs = df_TFACs.withColumnRenamed(key, rename_dict[key])

    # Melt TFACs
    df_melt = (
        melt(
            df_TFACs,
            id_vars=["CountryCode", "Year"],
            value_vars=df_TFACs.columns[10:22],
        )
        .withColumnRenamed("variable", "Month")
        .withColumnRenamed("value", "WorkingDayString")
    ).withColumn("WorkingDayArray", f.split("WorkingDayString", "(?!$)"))

    # Explode the melted TFACs
    df_cal = (
        df_melt.select(
            df_melt.CountryCode,
            df_melt.Year,
            df_melt.Month,
            f.posexplode_outer("WorkingDayArray").alias("rank", "listitem"),
        )
        .withColumn("rank", f.col("rank") + 1)
        .withColumnRenamed("listitem", "WorkingDay")
        .withColumn("Day", f.lpad(f.col("rank"), 2, "0"))
        .withColumn(
            "DateString", f.concat_ws("-", f.col("Year"), f.col("Month"), f.col("Day"))
        )
        .drop("rank")
    )
    return df_cal

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - If RUN_JOB_ON_LATEST Filter all tables on needed stacks

# COMMAND ----------

# check job type - Filter all tables on needed stacks - exit notebook if target is up to date
if (table_utils.UnityCatalogCheckTableExists(TABLE_DEST)) and (
    RUN_JOB_ON_LATEST == True
):
    df_target = spark.read.table(TABLE_DEST)
    latest_target_extraction_date = df_target.select(
        f.max("mdkp_extraction_timestamp")
    ).first()[0]

    latest_source_extraction_date = df_silver_mrp_history.select(
        f.max("mdkp_extraction_timestamp")
    ).first()[0]

    if latest_target_extraction_date is None:
        latest_target_extraction_date = THE_ORIGIN
        log.info(
            f"the latest extraction date in {TABLE_DEST} is None, taking : {latest_target_extraction_date}"
        )
    else:
        log.info(
            f"the latest extraction date in {TABLE_DEST} is : {latest_target_extraction_date}"
        )
        log.info(
            f"the latest extraction date in {t_silver_mrp_history} is : {latest_source_extraction_date}"
        )
        if latest_source_extraction_date == latest_target_extraction_date:
            log.info(f"the table {TABLE_DEST} is already up to date")
            dbutils.notebook.exit(
                f"the table {TABLE_DEST} is already up to date"
            )  # Quitter le notebook sans erreur

    df_silver_mrp_history = df_silver_mrp_history.filter(
        f.col("mdkp_extraction_timestamp") > latest_target_extraction_date
    )
else:
    MODE = "overwrite"
    log.debug(f"MODE is:  {MODE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Convert tfacs to calendar dataframe

# COMMAND ----------

df_cal = ConvertTFACsToCal(df_tfacs)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Display calandar dataframe
# MAGIC
# MAGIC At this step we may want to print the calendar dataframe

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    display(df_cal)
log.debug(f"Nombre de jours dans le calendrier df_cal : {df_cal.count()}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Management Rescheduling Date 

# COMMAND ----------

# Filter TFACS (SAP Calendar - open days) with min_Value and Max Value to optimize performance
min_dte = (
    df_silver_mrp_history.select(f.col("Rescheduling_Date"))
    .agg({"Rescheduling_Date": "min"})
    .collect()[0][0]
)
min_dte = min_dte - datetime.timedelta(days=99)
max_dte = (
    df_silver_mrp_history.select(f.col("Rescheduling_Date"))
    .agg({"Rescheduling_Date": "max"})
    .collect()[0][0]
)

df_cal = df_cal.filter(
    (f.col("DateString") > min_dte) & (f.col("DateString") <= max_dte)
)

# COMMAND ----------

# Add UID Column to Input Dataframe - UID is arbitarty but must be unique per row in the input file.
df_cal2 = (
    df_cal.select("CountryCode", "WorkingDay", "DateString")
    .withColumnRenamed("CountryCode", "CountryCode_")
    .withColumnRenamed("WorkingDay", "WorkingDay_")
    .withColumnRenamed("DateString", "DateString_")
)
df_cal_join = df_cal.join(
    df_cal2,
    (df_cal.CountryCode == df_cal2.CountryCode_)
    & (df_cal.DateString >= df_cal2.DateString_),
    how="left",
)
# Order by Unique ID from InputValues
w = (
    Window()
    .partitionBy("CountryCode", "DateString")
    .orderBy(f.col("DateString_").desc())
)
df_cal_join_calc = df_cal_join.withColumn("summ", f.sum("WorkingDay_").over(w))
#  Minus 1 to not take in account actual day
df_cal_join_calc = df_cal_join_calc.withColumn("summ", f.col("summ") - 1)
# Exlcusion of non working day
df_cal_join_calc = df_cal_join_calc.filter(f.col("WorkingDay_") != 0)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Display calandar dataframe
# MAGIC
# MAGIC At this step we may want to print the calendar dataframe
# MAGIC

# COMMAND ----------

log.debug(f"Nombre de jours dans le calendrier df_cal : {df_cal.count()}")
log.debug(f"Nombre de jours dans le calendrier df_cal2 : {df_cal2.count()}")
log.debug(f"Nombre de jours dans le calendrier df_cal_join : {df_cal_join.count()}")
log.debug(
    f"Nombre de jours dans le calendrier df_cal_join_calc : {df_cal_join_calc.count()}"
)

if LOG_LEVEL == logging.DEBUG:
    display(df_cal_join_calc)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Join MRP history to cal

# COMMAND ----------

df_final = df_silver_mrp_history.join(
    df_cal_join_calc,
    (df_silver_mrp_history.Rescheduling_Date == df_cal_join_calc.DateString)
    & (df_silver_mrp_history.ID_Calendar == df_cal_join_calc.CountryCode)
    & (df_silver_mrp_history.Reception_Time == df_cal_join_calc.summ),
    how="left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Management Subcontracted needs from SAP

# COMMAND ----------

# SAP reduce quantity on BB Elements (Subcontracted needs) according qty available in Stock Supplier.
# Here we decide to cancel this calculation in order to keep real needs
df_final = df_final.withColumn(
    "Quantity",
    f.when(
        (f.col("MRP_Element") == "BB") & (f.col("Segment_planif") != "26"),
        f.col("mdtb_mng03"),
    ).otherwise(f.col("Quantity")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Cleaning data

# COMMAND ----------

df_final = df_final.withColumnRenamed("DateString_", "PO_Resch_Date")

# Cast Quantity to string to match Gold table schema (was implicit in DBR 15.4, strict in 17.3)
df_final = df_final.withColumn("Quantity", f.col("Quantity").cast("string"))

df_final = df_final.drop(
    "Plant_",
    "ID_Calendar",
    "Year",
    "Month",
    "WorkingDay",
    "Day",
    "DateString",
    "CountryCode_",
    "WorkingDay_",
    "summ",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - Uniqueness
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Quality checks are done in Silver

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Gold MRP List history

# COMMAND ----------

# MAGIC %md
# MAGIC ### Gold Table

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by TABLE_DEST_CLUSTER_COLS
catalog, schema, table = TABLE_DEST.split(".")

try:
    table_utils.create_unity_catalog_table(
        catalog,
        schema,
        table,
        force_reinitialization=False,
        cluster_cols=TABLE_DEST_CLUSTER_COLS,
        partition_col=None,
        primary_key_cols=None,
        columns=TABLE_DEST_FIRST_COLS,
        force_drop=False,
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_DEST} has not been created, an error occured during creation. \nError is {e}"
    )
    raise Exception()

# COMMAND ----------

# Save the table from Dataframe df_final, preserving cluster columns
table_dest_cluster_cols_cleaned = TABLE_DEST_CLUSTER_COLS.replace(" ", "")
try:
    startTime = time.time()

    result = table_utils.save_table(
        dest_table=TABLE_DEST,
        df=df_final,
        mode=MODE,
        overwrite_schema=True,
        merge_schema=True,
        cluster_cols=table_dest_cluster_cols_cleaned
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_DEST} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {TABLE_DEST} saved in {duration} seconds.")
    log.info(f"Wrote {df_final.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Constraints

# COMMAND ----------

# Add Primary Key if not exists
catalog, schema, table = TABLE_DEST.split(".")
pk_name = TABLE_DEST_PK.lower()
nb_cons = spark.sql(
    f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_DEST_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(table_path=TABLE_DEST, column=col.strip())

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=TABLE_DEST,
        pk_name=TABLE_DEST_PK,
        columns=TABLE_DEST_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Gold Exposed View

# COMMAND ----------

src_full_tablename = f"{TABLE_DEST}"
dest_full_tablename = f"{TABLE_DEST}_exposed"

Begin_By = "mdtb"
Begin_By2 = "mdkp"
selected_columns = [
    col
    for col in df_final.columns
    if not col.startswith(Begin_By) and not col.startswith(Begin_By2)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
