# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for MRP List (Ressources / Needs)  
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_silver.mrp.list_mrp_full
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.mdkp_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.mdkpdb_latest  
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.mdtb_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.makt_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.marc_latest
# MAGIC   - {READ_ENV}_gold.master_data.plant_master_data_latest_exposed
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_mdkp
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_mdtb
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC   - Ingestion SAP Bronze / NoteBook Masterdata plant
# MAGIC
# MAGIC **Things to do:** 
# MAGIC   - Renaming headers
# MAGIC   - Stack MDKP-MDKPDB
# MAGIC   - Join Header / Item Mrp List
# MAGIC
# MAGIC   

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC #Import Tables MRP & Plant Master

# COMMAND ----------

# Upload SAP table MDKP - Header Mrp List
df_mdkp = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.mdkp_latest")
df_mdkp = table_utils.add_prefix_to_columns(df_mdkp, "mdkp")
# Upload SAP table MDTB - Item Mrp List
df_mdtb = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.mdtb_latest")
df_mdtb = table_utils.add_prefix_to_columns(df_mdtb, "mdtb")
# Upload SAP table MDKPDB - Header Mrp List unit planif
df_mdkpdb = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.mdkpdb_latest")
df_mdkpdb = table_utils.add_prefix_to_columns(df_mdkpdb, "mdkp")

# COMMAND ----------

# MAGIC %md
# MAGIC #Fusion Table MDKP / MDKPDB

# COMMAND ----------

df_stack_mdkp = df_mdkp.unionByName(df_mdkpdb, allowMissingColumns=True)
# Management Unit_planification
df_stack_mdkp = df_stack_mdkp.withColumn(
    "Planif_unit",
    f.when(f.col("mdkp_berid").isNull(), f.col("mdkp_plwrk")).otherwise(
        f.col("mdkp_berid")
    ),
)
df_stack_mdkp = df_stack_mdkp.drop("mdkp_berid")

# COMMAND ----------

# MAGIC %md
# MAGIC #Filter MRP List

# COMMAND ----------

## Keep only Production MRP List (ie-> Exclusion Simulation)
# Filter Production Mrp List & Production Planification Mrp List
df_mdkp_filtered = df_stack_mdkp.filter(
    (f.col("mdkp_dtart") == "MD") & (f.col("mdkp_plscn") == "000")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Header / Item MRP List

# COMMAND ----------

df_join_mrp = df_mdkp_filtered.alias("A").join(
    df_mdtb.alias("B"), f.col("A.mdkp_dtnum") == f.col("B.mdtb_dtnum"), "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Add Profit Center and Material Description

# COMMAND ----------

# Upload SAP table MAKT for Descritpion
df_makt = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.makt_latest")
# Keep only English Language
df_makt = df_makt.filter(f.col("spras") == "E")
df_makt = df_makt.withColumnRenamed("maktx", "Material_Description")
df_makt = df_makt.select("matnr", "Material_Description")

# Upload SAP table MARC for Profit Center
df_marc = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.marc_latest")
# Keep only Profit_Center Information
df_marc = df_marc.select("matnr", "werks", "prctr")
df_marc = df_marc.withColumnRenamed("matnr", "matnr_1").withColumnRenamed(
    "prctr", "Profit_Center"
)

# Upload Manual table for Plant Master Data
df_plant = spark.read.table(
    f"{READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)
df_plant = df_plant.select("Plant", "Plant_Description_new", "ID_Calendar")
df_plant = df_plant.withColumnRenamed("Plant", "Plant_").withColumnRenamed(
    "Plant_Description_new", "Plant_Description"
)
# Join MRP List with Master Data Material and plant
df_join_end = (
    df_join_mrp.alias("A")
    .join(
        f.broadcast(df_plant).alias("B"),
        f.col("A.mdkp_plwrk") == f.col("B.Plant_"),
        "left",
    )
    .join(df_makt.alias("C"), f.col("A.mdkp_matnr") == f.col("C.matnr"), "left")
    .join(
        df_marc.alias("D"),
        (f.col("A.mdkp_matnr") == f.col("D.matnr_1"))
        & (f.col("A.mdkp_plwrk") == f.col("D.werks")),
        "left",
    )
)
df_join_end = df_join_end.drop("matnr", "matnr_1", "werks")

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming Headers

# COMMAND ----------

# Upload Header Business MDKP
df_name_mdkp = spark.read.table("prod_bronze.headers_sap.headers_sap_business_mdkp")
# Call function Check Header files
check_schema_of_the_file(df_name_mdkp)
# Call Function Delete rows null
df_name_mdkp = delete_null_rows(df_name_mdkp)

# Upload Header Business MDTB
df_name_mdtb = spark.read.table("prod_bronze.headers_sap.headers_sap_business_mdtb")
# Call function Check Header files
check_schema_of_the_file(df_name_mdtb)
# Call Function Delete rows null
df_name_mdtb = delete_null_rows(df_name_mdtb)

# Union Headers-Item
df_names_all = df_name_mdkp.unionByName(df_name_mdtb)

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_join_end, df_names_all
)
# Call Funtion Create Columns on Date format
df_mrp_list = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_names_all
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Cleansing raw data

# COMMAND ----------

# Formatting Material_Number without '0' on left side
df_mrp_end = df_mrp_list.withColumn(
    "Material_Number", f.regexp_replace(df_mrp_list.Material_Number, "^0+", "")
)
# Formatting Profit_Center without '0' on left side
df_mrp_end = df_mrp_end.withColumn(
    "Profit_Center", f.regexp_replace(df_mrp_end.Profit_Center, "^0+", "")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Silver Table Exception Message

# COMMAND ----------

# Save the silver purchase order table
catalog = f"{WRITE_ENV}_silver"
domain = "mrp"
table = "list_mrp_full"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_mrp_end,
    mode="overwrite",
    overwrite_schema=True
)
