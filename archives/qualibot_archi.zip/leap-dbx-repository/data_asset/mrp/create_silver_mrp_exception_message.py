# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC This script creates the silver table for all exception Message from SAP MRP. 
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - SAP Ingestion
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdkp_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdkpdb_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdtb_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t458a_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t458b_latest
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.mrp.exception_message
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Tech Debt

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import DataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC
# MAGIC - **convert_currency** required for currency conversion of amounts
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

def remove_leading_zeros_multiple_columns(
    df: DataFrame, column_names: list
) -> DataFrame:
    """
    This function removes leading zeros from the specified columns in a DataFrame.

    Parameters:
    df (DataFrame): The input DataFrame.
    column_names (list): A list of column names from which to remove leading zeros.

    Returns:
    DataFrame: A new DataFrame with leading zeros removed from the specified columns.
    """
    for column_name in column_names:
        df = df.withColumn(column_name, f.regexp_replace(df[column_name], "^0+", ""))
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Upload SAP table MDKP - Header Mrp List by Planif unit
# MAGIC
# MAGIC **df_mdkp** is the bronze table for header MRP List. 
# MAGIC

# COMMAND ----------

df_mdkp = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdkp_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Upload SAP table MDKPDB - Header Mrp List by Planif unit
# MAGIC
# MAGIC **df_mdkpdb** is the bronze table for header MRP List by Planif_unit

# COMMAND ----------

df_mdkpdb = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdkpdb_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Upload SAP table MDTB - Item Mrp List
# MAGIC
# MAGIC **df_mdtb** is the bronze table for item MRP List

# COMMAND ----------

# Upload SAP table MDTB - Item Mrp List
df_mdtb = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdtb_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Upload SAP table T458A & T458B - Exception Message description

# COMMAND ----------

# Upload SAP table T458a & T458b - Exception Message description
df_t458a = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t458a_latest"
)
df_t458b = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t458b_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 1 - MDKP Renaming Headers and cleaning
# MAGIC
# MAGIC

# COMMAND ----------

# Upload manual table for headers naming MDKP
df_name_mdkp = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_mdkp_new"
)
# -----------------------------------------------------------------------
# Renaming header with starting mdkp_
df_mdkp_ = table_utils.add_prefix_to_columns(df_mdkp, "mdkp")
# -----------------------------------------------------------------------
# Call Function Rename Columns according Business header file
df_mdkp_renamed = table_utils.rename_columns_with_sap_business_header(
    df_mdkp_, df_name_mdkp
)
# -----------------------------------------------------------------------
#  Call Funtion Cast Column according Business header file
df_mdkp_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_mdkp_renamed, df_name_mdkp
)
# -----------------------------------------------------------------------
# Call function to remove leading Zero
columns_to_process = ["material_number", "mdkp_dtnum"]
df_mdkp_end = remove_leading_zeros_multiple_columns(df_mdkp_renamed, columns_to_process)
# -----------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 2 - MDKPDB Renaming Headers and cleaning

# COMMAND ----------

# Upload manual table for headers naming MDKP
df_name_mdkp = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_mdkp_new"
)
# -----------------------------------------------------------------------
# Renaming header with starting mdkp_
df_mdkpdb_ = table_utils.add_prefix_to_columns(df_mdkpdb, "mdkp")
# -----------------------------------------------------------------------
# Call Function Rename Columns according Business header file
df_mdkpdb_renamed = table_utils.rename_columns_with_sap_business_header(
    df_mdkpdb_, df_name_mdkp
)
# -----------------------------------------------------------------------
#  Call Funtion Cast Column according Business header file
df_mdkpdb_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_mdkpdb_renamed, df_name_mdkp
)
# -----------------------------------------------------------------------
# Call function to remove leading Zero
columns_to_process = ["material_number", "mdkp_dtnum"]
df_mdkpdb_end = remove_leading_zeros_multiple_columns(
    df_mdkpdb_renamed, columns_to_process
)
# -----------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 3 - Merge MDKP & MDKPDB + Exclusion MRP Simulation

# COMMAND ----------

# Merge Mdkp and Mdkpdb
df_stack_mdkp = df_mdkp_end.unionByName(df_mdkpdb_end, allowMissingColumns=True)
# ------------------------------------------------------------------------
# Management Unit_planification
df_stack_mdkp = df_stack_mdkp.withColumn(
    "planif_unit",
    f.when(f.col("mdkp_berid").isNull(), f.col("plant")).otherwise(f.col("mdkp_berid")),
)
df_stack_mdkp = df_stack_mdkp.drop("mdkp_berid")

# -----------------------------------------------------------------------
# Keep Only Planification MRP (Exclusion Simulation)
df_stack_mdkp = df_stack_mdkp.filter(
    (f.col("mdkp_dtart") == "MD") & (f.col("mdkp_plscn") == "000")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 4 - MDTB Renaming Headers and cleaning

# COMMAND ----------

# Upload manual table for headers naming MDKP
df_name_mdtb = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_mdtb_new"
)
# -----------------------------------------------------------------------
# Renaming header with starting mdkp_
df_mdtb_ = table_utils.add_prefix_to_columns(df_mdtb, "mdtb")
# -----------------------------------------------------------------------
# Call Function Rename Columns according Business header file
df_mdtb_renamed = table_utils.rename_columns_with_sap_business_header(
    df_mdtb_, df_name_mdtb
)
# -----------------------------------------------------------------------
#  Call Funtion Cast Column according Business header file
df_mdtb_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_mdtb_renamed, df_name_mdtb
)
# -----------------------------------------------------------------------
# Call function to remove leading Zero
columns_to_process = [
    "mdtb_dtnum",
    "mdtb_dtpos",
    "MRP_element_item",
    "MRP_element_number",
    "material_number_origin",
]
df_mdtb_end = remove_leading_zeros_multiple_columns(df_mdtb_renamed, columns_to_process)
# -----------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 5 - Join T458A & T458B and selection description

# COMMAND ----------

# Keep Only English Description(spras)
df_t458 = (
    df_t458a.join(df_t458b, ["aussl"], "left")
    .filter(f.col("spras") == "E")
    .select(
        f.col("aussl").alias("exception_message"),
        f.col("auslt").alias("exception_message_description"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr 1 - Join Header and Item MRP List

# COMMAND ----------

df_mrp_list = df_stack_mdkp.join(
    df_mdtb_end, df_stack_mdkp.mdkp_dtnum == df_mdtb_end.mdtb_dtnum, "left"
).join(df_t458, ["exception_message"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr 2 - Keep only MRP List with Exception Message

# COMMAND ----------

df_exception_message = df_mrp_list.filter(f.col("exception_message").isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr 3 - Creation Business ID

# COMMAND ----------

df_exception_message = df_exception_message.withColumn(
    "business_ID",
    f.concat_ws(
        "_", f.col("material_number"), f.col("mdtb_dtnum"), f.col("mdtb_dtpos")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ##QC 1 - No rows duplicated

# COMMAND ----------

df_id = df_exception_message.groupBy(f.col("business_ID")).count()
duplicated_ids = df_id.filter(f.col("count") > 1)
if duplicated_ids.count() > 0:
    raise Exception("Warning: Some values have been duplicated in a join")

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold revenue

# COMMAND ----------

df_coverage_path = f"{PIPELINE_WRITE_ENV}_silver.mrp.exception_message"
table_utils.save_table(
    dest_table=df_coverage_path, df=df_exception_message, mode="overwrite"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
