# Databricks notebook source
# MAGIC %md
# MAGIC    
# MAGIC # Purpose of Silver MRP List table
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for MRP List
# MAGIC
# MAGIC This database was created to consolidate MRP (Material Requirements Planning) list data 
# MAGIC from SAP, specifically using the MDKP (MRP document header) and MDTB (MRP document items) tables.  
# MAGIC
# MAGIC The main objectives are:  
# MAGIC  - to centralize planning data in a single, structured location,  
# MAGIC  - to facilitate analysis of material requirements and reservations,  
# MAGIC  - to track and report on MRP list evolution over time,  
# MAGIC  - to support decision-making in procurement, stock management, and production planning.  
# MAGIC  
# MAGIC **Output table(s):**  
# MAGIC - `{PIPELINE_WRITE_ENV}_silver.mrp.mrp_list_sap`
# MAGIC
# MAGIC **Input :**  
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdkp_latest`  
# MAGIC - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_mdkp`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdkpdb_latest`  
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdtb_latest`  
# MAGIC - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_mdtb`  
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdma_latest`
# MAGIC
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC  - SAP Bronze Ingestion  
# MAGIC  
# MAGIC **Things performed in this notebook:** 
# MAGIC
# MAGIC - Cleaning data
# MAGIC - Renaming Headers 
# MAGIC - Add Mrp Unit 
# MAGIC - Remove deleted MRP areas (MDMA LOEKZ indicator)
# MAGIC - Saving

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame, Window
import time
import datetime
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils, amount_correction

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull())
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### MDKP – Header Data for MRP Document
# MAGIC
# MAGIC MDKP is a standard table in SAP that stores the header-level information for MRP (Material Requirements Planning) documents. It contains metadata and control fields that describe how MRP planning is performed for each material‐plant combination

# COMMAND ----------

df_mdkp_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdkp_latest"
)
df_mdkp_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_mdkp"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### MDKPDB – Header Data for MRP Document (MRP_UNIT)
# MAGIC
# MAGIC MDKPDB is an extension of MDKP standard table in SAP that stores the header-level information for MRP (Material Requirements Planning) documentson MRP unit level.

# COMMAND ----------

df_mdkpdb_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdkpdb_latest"
)

# COMMAND ----------

# DBTITLE 1,MDMA header
# MAGIC %md
# MAGIC    
# MAGIC ### MDMA – MRP Area Data (Deletion Indicator)
# MAGIC
# MAGIC MDMA stores MRP area-level planning parameters. We use it to identify MRP areas marked for deletion (`LOEKZ = 'X'`) and exclude their entries from the MRP list.

# COMMAND ----------

df_mdma_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdma_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### MDTB – Details Data for MRP Document
# MAGIC This table stores detailed entries from the MRP (Material Requirements Planning) “table” or “list” for requirement/receipt planning in SAP

# COMMAND ----------

df_mdtb_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdtb_latest"
)
df_mdtb_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_mdtb"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – MDKP/MDKPDB    
# MAGIC - Union Header table 
# MAGIC - Business-name-based renaming 

# COMMAND ----------

df_stack_mdkp = df_mdkp_raw.unionByName(df_mdkpdb_raw, allowMissingColumns=True)

df_mrp_prep = table_utils.add_prefix_to_columns(df_stack_mdkp, "MDKP")
# Call Function Delete rows null
df_name_mrp = delete_null_rows(df_mdkp_header)
# Call Function Rename Columns according header file
df_column_mrp = table_utils.rename_columns_with_sap_business_header(
    df_mrp_prep, df_name_mrp
)
# Call Funtion Create Columns on Date format
df_mrp_prep = table_utils.cast_columns_with_sap_business_headers(
    df_column_mrp, df_name_mrp
)
# Management of MRP_unit empty
df_mrp_prep = df_mrp_prep.withColumn(
    "MRP_unit", f.coalesce(f.col("MDKP_berid"), f.col("plant"))
).drop("MDKP_berid")

# Cleaning data
df_mrp_cleaned = table_utils.remove_leading_zeros(
    df=df_mrp_prep,
    column_names=[
        "material_number",
        "plant",
        "MRP_list_scenario",
        "MRP_list_number",
        "BOM_level",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 – MDTB    
# MAGIC
# MAGIC - Business-name-based renaming 

# COMMAND ----------

df_mdtb_prep = table_utils.add_prefix_to_columns(df_mdtb_raw, "MDTB")
# Call Function Delete rows null
df_name_mdtb = delete_null_rows(df_mdtb_header)
# Call Function Rename Columns according header file
df_column_mdtb = table_utils.rename_columns_with_sap_business_header(
    df_mdtb_prep, df_name_mdtb
)
# Call Funtion Create Columns on Date format
df_mdtb_prep = table_utils.cast_columns_with_sap_business_headers(
    df_column_mdtb, df_name_mdtb
)
df_mdtb_cleaned = table_utils.remove_leading_zeros(
    df=df_mdtb_prep,
    column_names=[
        "MRP_list_number",
        "MRP_list_item_number",
        "MRP_element_number",
        "MRP_element_item_number",
        "MRP_element_number_ressources",
        "material_number_origin",
        "segment_number",
        "MRP_segment",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 – MDMA

# COMMAND ----------

# Build list of deleted MRP areas (material + MRP_unit) to exclude
df_mdma_prepared = (
    df_mdma_raw.filter(f.col("loekz").isNotNull())
    .select(
        f.col("matnr").alias("material_number"),
        f.col("berid").alias("MRP_unit"),
    )
    .distinct()
)
df_mdma_prepared = table_utils.remove_leading_zeros(
    df_mdma_prepared, ["material_number"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 - Join Header and item MRP List

# COMMAND ----------

df_mrp_join = df_mrp_cleaned.join(df_mdtb_cleaned, ["MRP_list_number"], "inner")

# COMMAND ----------

# DBTITLE 1,Tr.1b header
# MAGIC %md
# MAGIC    
# MAGIC ## Tr. 2 – Remove Deleted MRP Areas
# MAGIC
# MAGIC Exclude MRP list entries where the MRP area (material + MRP_unit) is marked for deletion in MDMA (`LOEKZ = 'X'`). These are ghost entries that should no longer appear in planning.

# COMMAND ----------

# Anti-join: remove entries matching deleted MRP areas
df_mrp_join = df_mrp_join.join(
    df_mdma_prepared,
    on=["material_number", "MRP_unit"],
    how="left_anti",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 - Management of Subcontracted needs
# MAGIC SAP reduce quantity on BB Elements (Subcontracted needs) according qty available in Stock Supplier.  
# MAGIC Here we decide to cancel this calculation in order to keep real needs

# COMMAND ----------

df_mrp_qty = df_mrp_join.withColumn(
    "quantity",
    f.when(
        (f.col("MRP_element") == "BB") & (f.col("segment_number") != "26"),
        f.col("mdtb_mng03"),
    ).otherwise(f.col("quantity")),
)
df_mrp_qty = df_mrp_join.withColumn("quantity", f.col("quantity").cast("double"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 4 – Business Indicator Flags

# COMMAND ----------

df_mrp_end = df_mrp_qty.withColumn(
    "is_production_mrp",
    f.when(
        (f.col("MRP_list_type") == "MD") & (f.col("MRP_list_scenario") == ""),
        f.lit(True),
    ).otherwise(f.lit(False)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_mrp_end = df_mrp_end.withColumn(
    "MRP_list_sap_ID",
    f.concat_ws(
        "-",
        f.col("MRP_list_number"),
        f.col("MRP_list_item_number"),
        f.col("material_number"),
        f.col("plant"),
        f.col("MRP_list_scenario"),
    ),
)

# COMMAND ----------

df_to_check = df_mrp_end
col_pk = "MRP_list_sap_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for mrp list table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="MRP_list_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "mrp"
DESTINATION_TABLE = "mrp_list_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_mrp_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_mrp_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "silver_MRP_list_sap_pk"
TABLE_PK_COLS = "MRP_list_sap_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
