# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for Exception messages based on MRP List 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_silver.mrp.exception_message_plannif
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - {READ_ENV}_silver.sap.pp_mdkp
# MAGIC   - {READ_ENV}_silver.sap.pp_mdkpdb
# MAGIC   - {READ_ENV}_silver.sap.pp_mdtb
# MAGIC   - {READ_ENV}_gold.master_data.plant_master_data_latest_exposed
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_mdkp
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_mdtb
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC   - Ingestion SAP Bronze / NoteBook Masterdata plant
# MAGIC
# MAGIC **Things to do:** 
# MAGIC   - Renaming headers
# MAGIC   - Join Header / Item / Plant Master Data
# MAGIC   - Filter Exception message
# MAGIC   

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

## Upload LEAP Utils
# Add prefix on table
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# --------------------------------------------------------------------------------------------------------------

# Rename Columns according with Imput file 'Header Renaming
def rename_sap_column_names(df: DataFrame, df_names: DataFrame) -> DataFrame:
    dfp_names = df_names.toPandas()
    dfp_names["table_field"] = dfp_names["Table_name"] + "_" + dfp_names["Field"]
    for i, r in dfp_names.iterrows():

        df = df.withColumnRenamed(
            r["table_field"], r["Business_name"].replace(" ", "_")
        )
    return df


# --------------------------------------------------------------------------------------------------------------

# Create date format columns when indicated in the headers file
def modificate_format_column(df: DataFrame, df_names: DataFrame) -> DataFrame:
    """
    Create a date column when it is asked in the column name config file
    """
    for col in df.columns:
        if df_names.filter(f.col("Business_name") == col).count() > 0:
            if (
                df_names.filter(f.col("Business_name") == col)
                .select("Format")
                .first()[0]
                == "date"
            ):
                df = df.withColumn(f"{col}", f.to_date(f.col(f"{col}"), "yyyyMMdd"))
            else:
                if (
                    df_names.filter(f.col("Business_name") == col)
                    .select("Format")
                    .first()[0]
                    == "float"
                ):
                    df = df.withColumn(f"{col}", f.col(f"{col}").cast("float"))
    return df


# --------------------------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC #Import Tables MRP & Plant Master

# COMMAND ----------

# Upload SAP table MDKP - Header Mrp List
df_mdkp = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.mdkp_latest")
# Upload SAP table MDKP - Header Mrp List by Planif unit
df_mdkpdb = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.mdkpdb_latest")
# Upload SAP table MDTB - Item Mrp List
df_mdtb = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.mdtb_latest")
# Upload table for Plant Master Data
df_plant = spark.read.table(
    f"prod_gold.master_data.plant_master_data_latest_exposed"
)
# Upload Manual table for Material Master Data by Plant
df_material = (spark.read.table(
    f"prod_gold.master_data.material_master_data_plant_exposed")
            .select("Material_Number","Plant","Profit_Center")
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming Headers

# COMMAND ----------

# Upload manual table for headers naming MDKP
df_name_mdkp = spark.read.table("prod_bronze.headers_sap.headers_sap_business_mdkp")
# Call function Check Header files
check_schema_of_the_file(df_name_mdkp)
# Renaming starting with mdkp_
df_mdkp_ = table_utils.add_prefix_to_columns(df_mdkp, "mdkp")
# Call Function Rename Columns according header file
df_mdkp_renamed = rename_sap_column_names(df_mdkp_, df_name_mdkp)
#  Call Funtion Create Columns on Date format
df_mdkp_renamed = modificate_format_column(df_mdkp_renamed, df_name_mdkp)

# Renaming starting with mdkpdb_
df_mdkpdb_ = table_utils.add_prefix_to_columns(df_mdkpdb, "mdkp")
# Call Function Rename Columns according header file
df_mdkpdb_renamed = rename_sap_column_names(df_mdkpdb_, df_name_mdkp)
#  Call Funtion Create Columns on Date format
df_mdkpdb_renamed = modificate_format_column(df_mdkpdb_renamed, df_name_mdkp)


# Upload manual table for headers naming MDTB
df_name_mdtb = spark.read.table("prod_bronze.headers_sap.headers_sap_business_mdtb")
# Call function Check Header files
check_schema_of_the_file(df_name_mdtb)
# Renaming starting with mdtb_
df_mdtb_ = table_utils.add_prefix_to_columns(df_mdtb, "mdtb")
# Call Function Rename Columns according header file
df_mdtb_renamed = rename_sap_column_names(df_mdtb_, df_name_mdtb)
# Call Funtion Create Columns on Date format
df_mdtb_renamed = modificate_format_column(df_mdtb_renamed, df_name_mdtb)

# COMMAND ----------

# MAGIC %md
# MAGIC #Fusion Table MDKP / MDKPDB

# COMMAND ----------

df_stack_mdkp = df_mdkp_renamed.unionByName(df_mdkpdb_renamed, allowMissingColumns=True)
# Management Unit_planification
df_stack_mdkp = df_stack_mdkp.withColumn(
    "Planif_unit",
    f.when(f.col("mdkp_berid").isNull(), f.col("Plant")).otherwise(f.col("mdkp_berid")),
)
df_stack_mdkp = df_stack_mdkp.drop("mdkp_berid")

# COMMAND ----------

# MAGIC %md
# MAGIC #Filter on Production MRP List Header (i.e -> Exclusion simulation)

# COMMAND ----------

# Filter Production Mrp List
df_mdkp_filt = df_stack_mdkp.filter(f.col("mdkp_dtart") == "MD")
# Filter Production Planification Mrp List
df_mdkp_filt = df_mdkp_filt.filter(f.col("mdkp_plscn") == "000")

# COMMAND ----------

# MAGIC %md
# MAGIC #Filter on Exception Message MRP List Item

# COMMAND ----------

# Filter only on exception messages U1, U2 and U3 (Postpone, Foward, Cancel)
df_mdtb_filt = df_mdtb_renamed.filter(
    f.col("Exception_Message").isin(["U1", "U2", "U3"])
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Header / Item / Plant description

# COMMAND ----------

df_join = (
    df_mdkp_filt
    .join(
        df_mdtb_filt, f.col("mdkp_dtnum") == f.col("mdtb_dtnum"), "left"
    )
    .join(df_plant, ["Plant"], "left")
    .join(df_material,["Material_Number","Plant"],"left")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Silver Table Exception Message

# COMMAND ----------

# Save the silver purchase order table
catalog = f"{WRITE_ENV}_silver"
domain = "mrp"
table = "exception_message_planif"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_join,
    mode="overwrite",
    overwrite_schema=True
)
