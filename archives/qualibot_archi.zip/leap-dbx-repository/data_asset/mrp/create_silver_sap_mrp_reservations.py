# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for Needs Reservation
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_silver.mrp.sap_mrp_reservation_latest
# MAGIC
# MAGIC **Input :**  
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.resb_latest
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_resb
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC  - SAP Bronze Ingestion  
# MAGIC  
# MAGIC **Things performed in this notebook:** 
# MAGIC
# MAGIC - Cleaning data
# MAGIC - Renaming Headers  
# MAGIC - Saving

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql import Window
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )

# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC #DownLoad RESB Table from SAP - MRP Reservation

# COMMAND ----------

# Upload RESB <- Reservations MRP Planification
# We keep only reservations not cancelled("xloek")
df_resb_history = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.resb_latest")
df_resb = table_utils.add_prefix_to_columns(df_resb_history, "RESB")

# COMMAND ----------

# MAGIC %md
# MAGIC #Management quantity due to specific unit PC2 in SAP
# MAGIC

# COMMAND ----------

# Due to specific implementation of Latecoere rules in SAP
# we have to switch quantity needed according specific unit PC2
# It only concerns planif 
df_resb = df_resb.withColumn(
    "RESB_bdmng",
    f.when(
        (f.col("RESB_erfme") == "PC2")
        & (f.col("RESB_meins") == "U")
        & (f.col("RESB_alpos") == "X")
        & (f.col("RESB_bdart") == "SB"),
        f.col("RESB_ewahr") * f.col("RESB_nomng") / 100,
    )
    .when(
        (f.col("RESB_erfme") == "PC2")
        & (f.col("RESB_meins") == "U")
        & (f.col("RESB_bdart") == "SB")
        & (f.col("RESB_alpos").isNull()),
        f.col("RESB_nomng"),
    )
    .otherwise(f.col("RESB_bdmng")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming according Header files

# COMMAND ----------

## Renaming headers RESB - MRP Reservation 
df_name_resb = spark.read.table("prod_bronze.headers_sap.headers_sap_business_resb")
# Call function Check Header files
check_schema_of_the_file(df_name_resb)
# Call Function Delete rows null
df_name_resb = delete_null_rows(df_name_resb)

# Call Function Rename Columns according header file
df_reservation = table_utils.rename_columns_with_sap_business_header(
    df_resb, df_name_resb
)
# Call Funtion Create Columns on format according headers file
df_reservation_clean = table_utils.cast_columns_with_sap_business_headers(
    df_reservation, df_name_resb
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Cleasing raw data

# COMMAND ----------

# Formatting Material_Number without '0' on left side
df_reservation_format = df_reservation_clean.withColumn(
    "Material_Number", f.regexp_replace(df_reservation_clean.Material_Number, "^0+", "")
)
# Formatting Profit_Center without '0' on left side
df_reservation_format = df_reservation_format.withColumn(
    "Reservation_Number", f.regexp_replace(df_reservation_format.Reservation_Number, "^0+", "")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Silver table

# COMMAND ----------

catalog = f"{WRITE_ENV}_silver"
domain = "mrp"
table = "sap_mrp_reservation_latest"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_reservation_format,
    mode="overwrite",
    overwrite_schema=True
)
