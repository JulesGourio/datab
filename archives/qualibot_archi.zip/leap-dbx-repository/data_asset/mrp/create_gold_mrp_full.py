# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold  & Gold Exposed table for Exception messages based on MRP List 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_gold.mrp.list_mrp_full
# MAGIC   - {WRITE_ENV}_gold.mrp.list_mrp_full_exposed
# MAGIC
# MAGIC **Input :**  
# MAGIC   - {READ_ENV}_silver.mrp.list_mrp_full
# MAGIC   
# MAGIC **Triggered by:**  
# MAGIC   - NoteBook Silver_MRP_Message
# MAGIC
# MAGIC **Things to do:** 
# MAGIC
# MAGIC   - Management offset rescheduling date according reception time
# MAGIC   - Cleaning raw data
# MAGIC   - Save Gold/Gold_exposed tables

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from typing import Iterable
import datetime
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable 
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable 
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV") 

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions 

# COMMAND ----------

#Standard MELT function
def melt(
    df: DataFrame,
    id_vars: Iterable[str],
    value_vars: Iterable[str],
    var_name: str = "variable",
    value_name: str = "value",
) -> DataFrame:
    """Convert :class:`DataFrame` from wide to long format."""

    # Create array<struct<variable: str, value: ...>>
    _vars_and_vals = f.array(
        *(f.struct(f.lit(c).alias(var_name), f.col(c).alias(value_name)) for c in value_vars)
    )

    # Add to the DataFrame and explode
    _tmp = df.withColumn("_vars_and_vals", f.explode(_vars_and_vals))

    cols = id_vars + [f.col("_vars_and_vals")[x].alias(x) for x in [var_name, value_name]]
    return _tmp.select(*cols)




# Converts TFACs to Calendar dataframe
def ConvertTFACsToCal(df_TFACs:DataFrame):

    # Rename TFACs Columns -> This section can be replaces if TFACs is pre-processed
    rename_dict = {
        "ident": "CountryCode",
        "jahr": "Year",
        "mon01": "01",
        "mon02": "02",
        "mon03": "03",
        "mon04": "04",
        "mon05": "05",
        "mon06": "06",
        "mon07": "07",
        "mon08": "08",
        "mon09": "09",
        "mon10": "10",
        "mon11": "11",
        "mon12": "12",
    }

    for key in rename_dict.keys():
        df_TFACs = df_TFACs.withColumnRenamed(key, rename_dict[key])

    # Melt TFACs
    df_melt = (
        melt(
            df_TFACs, id_vars=["CountryCode", "Year"], value_vars=df_TFACs.columns[2:14]
        )
        .withColumnRenamed("variable", "Month")
        .withColumnRenamed("value", "WorkingDayString")
    ).withColumn("WorkingDayArray", f.split("WorkingDayString", "(?!$)"))

    # Explode the melted TFACs
    df_cal = (
        df_melt.select(
            df_melt.CountryCode,
            df_melt.Year,
            df_melt.Month,
            f.posexplode_outer("WorkingDayArray").alias("rank", "listitem"),
        )
        .withColumn("rank", f.col("rank") + 1)
        .withColumnRenamed("listitem", "WorkingDay")
        .withColumn("Day", f.lpad(f.col("rank"), 2, "0"))
        .withColumn("DateString", f.concat_ws("-", f.col("Year"), f.col("Month"), f.col("Day")))
        .drop("rank")
    )
    return df_cal

# COMMAND ----------

#Calendrier Creation according MELT functions
df_TFACS = spark.read.table("prod_bronze.sap_latecoere_ecc6.tfacs_latest") 
df_cal = ConvertTFACsToCal(df_TFACS)

# COMMAND ----------

# MAGIC %md 
# MAGIC #Import Data-Asset silver

# COMMAND ----------

#  Upload silver table for MRP LIST
df_mrp = spark.read.table(
    f"{READ_ENV}_silver.mrp.list_mrp_full"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Management Rescheduling Date 

# COMMAND ----------

# Filter TFACS (SAP Calendar - open days) with min_Value and Max Value to optimize performance
min_dte = (
    df_mrp.select(f.col("Rescheduling_Date"))
    .agg({"Rescheduling_Date": "min"})
    .collect()[0][0]
)
min_dte = min_dte - datetime.timedelta(days=99)
max_dte = (
    df_mrp.select(f.col("Rescheduling_Date"))
    .agg({"Rescheduling_Date": "max"})
    .collect()[0][0]
)

df_cal = df_cal.filter(
    (f.col("DateString") > min_dte) & (f.col("DateString") <= max_dte)
)

# COMMAND ----------

# Add UID Column to Input Dataframe - UID is arbitarty but must be unique per row in the input file.
df_cal2 = (
    df_cal.select("CountryCode", "WorkingDay", "DateString")
    .withColumnRenamed("CountryCode", "CountryCode_")
    .withColumnRenamed("WorkingDay", "WorkingDay_")
    .withColumnRenamed("DateString", "DateString_")
)
df_cal_join = df_cal.join(
    df_cal2,
    (df_cal.CountryCode == df_cal2.CountryCode_)
    & (df_cal.DateString >= df_cal2.DateString_),
    how="left",
)
# Order by Unique ID from InputValues
w = (
    Window()
    .partitionBy("CountryCode", "DateString")
    .orderBy(f.col("DateString_").desc())
)  
df_cal_join_calc = df_cal_join.withColumn("summ", f.sum("WorkingDay_").over(w))
#  Minus 1 to not take in account actual day
df_cal_join_calc = df_cal_join_calc.withColumn(
    "summ", f.col("summ") - 1
)  
# Exlcusion of non working day
df_cal_join_calc = df_cal_join_calc.filter(
    f.col("WorkingDay_") != 0
)  
df_final = df_mrp.join(
    df_cal_join_calc,
    (df_mrp.Rescheduling_Date == df_cal_join_calc.DateString)
    & (df_mrp.ID_Calendar == df_cal_join_calc.CountryCode)
    & (df_mrp.Reception_Time == df_cal_join_calc.summ),
    how="left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Management Subcontracted needs from SAP

# COMMAND ----------

# SAP reduce quantity on BB Elements (Subcontracted needs) according qty available in Stock Supplier.
# Here we decide to cancel this calculation in order to keep real needs
df_final = df_final.withColumn(
    "Quantity",
    f.when(
        (f.col("MRP_Element") == "BB") & (f.col("Segment_planif") != "26"),
        f.col("mdtb_mng03"),
    ).otherwise(f.col("Quantity")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Cleaning raw data

# COMMAND ----------

df_final = df_final.withColumnRenamed("DateString_", "PO_Resch_Date")
df_final = df_final.drop(
    "Plant_",
    "ID_Calendar",
    "Year",
    "Month",
    "WorkingDay",
    "Day",
    "DateString",
    "CountryCode_",
    "WorkingDay_",
    "summ",
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold MRP Table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "mrp"
table = "list_mrp_full"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_final,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold exposed table

# COMMAND ----------

catalog = "gold"
domain = "mrp"
table = "list_mrp_full"
src_full_tablename = f"{WRITE_ENV}_{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"

Begin_By = "mdtb"
Begin_By2 = "mdkp"
selected_columns = [col for col in df_final.columns if not col.startswith(Begin_By)and not col.startswith(Begin_By2)]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
