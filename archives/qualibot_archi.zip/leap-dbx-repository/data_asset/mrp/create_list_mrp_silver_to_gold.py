# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose of Gold MRP List table
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table for MRP List
# MAGIC
# MAGIC This database was created to consolidate MRP (Material Requirements Planning) list data 
# MAGIC from SAP, specifically using the MDKP (MRP document header) and MDTB (MRP document items) tables.  
# MAGIC
# MAGIC The main objectives are:  
# MAGIC  - to centralize planning data in a single, structured location,  
# MAGIC  - to facilitate analysis of material requirements and reservations,  
# MAGIC  - to track and report on MRP list evolution over time,  
# MAGIC  - to support decision-making in procurement, stock management, and production planning.  
# MAGIC  
# MAGIC **Output table(s):**  
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.mrp.mrp_list_sap`
# MAGIC
# MAGIC **Input :**  
# MAGIC - `{PIPELINE_READ_ENV}_silver.mrp.mrp_list_sap`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tfacs_latest`  
# MAGIC - `{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed`  
# MAGIC - `{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed`  
# MAGIC
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC  - N/A  
# MAGIC  
# MAGIC **Things performed in this notebook:** 
# MAGIC
# MAGIC - Dispatch MRP Element
# MAGIC - Add Material master data
# MAGIC - Calculation ressources rescheduling date
# MAGIC - Saving

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame, Window
import time
import datetime
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils, amount_correction

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

def convert_tfacs_to_cal(df_TFACs: DataFrame) -> DataFrame:
    """
    Converts TFACs to Calendar dataframe

    Args:
        df_TFACs (DataFrame): TFACs dataframe from tfacs_latest table.

    Returns:
        Dataframe: The new unpivoted dataframe.
    """
    # Rename TFACs Columns -> This section can be replaces if TFACs is pre-processed
    rename_dict = {
        "ident": "country_code",
        "jahr": "year",
        "mon01": "01",
        "mon02": "02",
        "mon03": "03",
        "mon04": "04",
        "mon05": "05",
        "mon06": "06",
        "mon07": "07",
        "mon08": "08",
        "mon09": "09",
        "mon10": "10",
        "mon11": "11",
        "mon12": "12",
    }

    df_TFACs = df_TFACs.withColumnsRenamed(rename_dict)

    # Unpivot TFACs
    df_unpivot = (
        df_TFACs.unpivot(
            ids=["country_code", "year"],
            values=df_TFACs.columns[10:22],
            variableColumnName="month",
            valueColumnName="working_day_string",
        )
    ).withColumn("working_day_array", f.split("working_day_string", "(?!$)"))

    # Explode the df_unpivot TFACs
    df_cal = (
        df_unpivot.select(
            df_unpivot.country_code,
            df_unpivot.year,
            df_unpivot.month,
            f.posexplode_outer("working_day_array").alias("rank", "listitem"),
        )
        .withColumn("rank", f.col("rank") + 1)
        .withColumnRenamed("listitem", "working_day")
        .withColumn("day", f.lpad(f.col("rank"), 2, "0"))
        .withColumn(
            "date_string", f.concat_ws("-", f.col("year"), f.col("month"), f.col("day"))
        )
        .drop("rank")
    )
    return df_cal


# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### TFACS – Factory calendar
# MAGIC
# MAGIC TFACS is a standard SAP table that stores year-by-year display data for factory calendars

# COMMAND ----------

df_tfacs_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tfacs_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### SILVER – MRP list

# COMMAND ----------

df_silver_mrp_list = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.mrp.mrp_list_sap"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Material by plant
# MAGIC **df_gold_material** Extraction master data material

# COMMAND ----------

df_gold_material = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD – Plant Master Data

# COMMAND ----------

# Upload Manual table for Plant Master Data
df_gold_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 – Silver MRP List
# MAGIC We keep only production MRP List

# COMMAND ----------

# Exclusion of double needs from S&OP process
df_mrp_list_prepared = df_silver_mrp_list.filter(
    ~((f.col("MRP_Segment") == 4) & (f.col("code_mvt") == "-"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 – Material Master data

# COMMAND ----------

df_gold_material_prepared = df_gold_material.select(
    "material_number",
    "material_description",
    "plant",
    "MRP_unit",
    "profit_center",
    "mrp_controller",
    "buyer",
    "division",
    "region",
    "company",
    "company_description",
    "stock_site",
    "standard_price_eur_budget",
    "average_price_eur_budget",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 – Create calendar table between minimum date and maximum date from TFACS table

# COMMAND ----------

df_calendar_prep = convert_tfacs_to_cal(df_tfacs_raw)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 4 – Plant Master Data  

# COMMAND ----------

df_gold_plant_prepared = df_gold_plant.toDF(*[c.lower() for c in df_gold_plant.columns])
df_gold_plant_prepared = df_gold_plant_prepared.select("plant", "id_calendar")

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 - Join Header and item MRP List

# COMMAND ----------

df_mrp_list_join = df_mrp_list_prepared.join(
    df_gold_material_prepared,
    ["material_number","plant","MRP_unit"],"left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 - Add Calendar ID

# COMMAND ----------

df_mrp_list_cal = df_mrp_list_join.join(df_gold_plant_prepared, ["plant"], "inner")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 - Management of Rescheduling data in MRP List
# MAGIC SAP gives the Rescheduling date with GR_processing lead time included, we need to substract this value in order to have the rescheduling date to provide on our supplier or internal production. We need also to considerate calendar linked to the plant production.

# COMMAND ----------

min_max = df_mrp_list_cal.agg(
    f.min("rescheduling_date").alias("min_dte"),
    f.max("rescheduling_date").alias("max_dte")
).first()

min_dte = min_max["min_dte"] - datetime.timedelta(days=99)
max_dte = min_max["max_dte"]

df_cal = df_calendar_prep.filter(
    (f.col("date_string") > min_dte) & (f.col("date_string") <= max_dte)
)

# COMMAND ----------

# Keep only working days
df_working_days = df_calendar_prep.filter(f.col("working_day") == 1)

# Also prepare a version with the reversed index (useful for subtraction)
w_desc = Window.partitionBy("country_code").orderBy(f.col("date_string").desc())

df_working_days = df_working_days.withColumn(
    "reverse_index", f.row_number().over(w_desc)
).select("country_code", "date_string", "reverse_index")

# For each rescheduling_date, find its index and add GR_processing_time
df_mrp_enriched = (
    df_mrp_list_cal.alias("mrp")
    .join(
        df_working_days.alias("cal"),
        (f.col("mrp.rescheduling_date") == f.col("cal.date_string"))
        & (f.col("mrp.id_calendar") == f.col("cal.country_code")),
        "left",
    )
    .withColumn(
        "target_index", f.col("cal.reverse_index") + f.col("mrp.GR_processing_time")
    )
).drop("date_string", "reverse_index", "country_code")
# Join again to find the real date corresponding to target_index
df_result = (
    df_mrp_enriched.alias("mrp")
    .join(
        df_working_days.alias("cal2"),
        (f.col("mrp.id_calendar") == f.col("cal2.country_code"))
        & (f.col("mrp.target_index") == f.col("cal2.reverse_index")),
        "left",
    )
    .drop("country_code", "reverse_index")
)

df_result = df_result.withColumnRenamed(
    "date_string", "ressources_rescheduling_date"
).withColumnRenamed("rescheduling_date", "planned_rescheduling_date")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 4 - Dispatch MRP Element by category

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 4.1 - Displatch Consumption

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.1.1 - Reservation Number Information

# COMMAND ----------

list_mvt_reservation = ["MR", "SB", "AR", "BB"]
df_mrp_list_resa = df_result.withColumn(
    "reservation_number",
    f.when(
        (f.col("code_mvt") == "-") & (f.col("MRP_element").isin(list_mvt_reservation)),
        f.col("MRP_element_number"),
    ).otherwise(f.lit(None)),
).withColumn(
    "reservation_item_number",
    f.when(
        (f.col("code_mvt") == "-") & (f.col("MRP_element").isin(list_mvt_reservation)),
        f.col("MRP_element_item_number"),
    ).otherwise(f.lit(None)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.1.2 - Sales order information
# MAGIC Element MRP = VC

# COMMAND ----------

df_mrp_list_sales = df_mrp_list_resa.withColumn(
    "sales_order_number",
    f.when(
        (f.col("code_mvt") == "-") & (f.col("MRP_element") == "VC"),
        f.col("MRP_element_number"),
    ).otherwise(f.lit(None)),
).withColumn(
    "sales_order_item_number",
    f.when(
        (f.col("code_mvt") == "-") & (f.col("MRP_element") == "VC"),
        f.col("MRP_element_item_number"),
    ).otherwise(f.lit(None)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.1.3 - Delivery note information
# MAGIC Element MRP = VJ

# COMMAND ----------

df_mrp_list_dl = df_mrp_list_sales.withColumn(
    "delivery_note_number",
    f.when(
        (f.col("code_mvt") == "-") & (f.col("MRP_element") == "VJ"),
        f.col("MRP_element_number"),
    ).otherwise(f.lit(None)),
).withColumn(
    "delivery_note_item_number",
    f.when(
        (f.col("code_mvt") == "-") & (f.col("MRP_element") == "VJ"),
        f.col("MRP_element_item_number"),
    ).otherwise(f.lit(None)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.1.4 - Independant needs
# MAGIC Element MRP = PP

# COMMAND ----------

df_mrp_list_bip = df_mrp_list_dl.withColumn(
    "BIP_number",
    f.when(
        (f.col("code_mvt") == "-") & (f.col("MRP_element") == "PP"),
        f.col("MRP_element_number"),
    ).otherwise(f.lit(None)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.1.5 - Interco needs
# MAGIC Element MRP = U1/U2/U3

# COMMAND ----------

df_mrp_list_interco = df_mrp_list_bip.withColumn(
    "interco_flow_number",
    f.when(
        (f.col("code_mvt") == "-") & (f.col("MRP_element") == "U1"),
        f.concat_ws(
            "_",
            f.lit("PO"),
            f.col("MRP_element_number"),
            f.col("MRP_element_item_number"),
        ),
    )
    .when(
        (f.col("code_mvt") == "-") & (f.col("MRP_element") == "U2"),
        f.concat_ws(
            "_",
            f.lit("PR"),
            f.col("MRP_element_number"),
            f.col("MRP_element_item_number"),
        ),
    )
    .when(
        (f.col("code_mvt") == "-") & (f.col("MRP_element") == "U3"),
        f.concat_ws(
            "_",
            f.lit("Pl.o"),
            f.col("MRP_element_number"),
        ),
    )
    .otherwise(f.lit(None)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.1.6 - Return PO
# MAGIC Element MRP = RP

# COMMAND ----------

df_mrp_list_return = df_mrp_list_interco.withColumn(
    "PO_return",
    f.when(
        (f.col("code_mvt") == "-") & (f.col("MRP_element") == "RP"),
        f.concat_ws(
            "_",
            f.lit("PO-return"),
            f.col("MRP_element_number"),
            f.col("MRP_element_item_number"),
        ),
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.1.7 - Planned order origin
# MAGIC Element MRP = SB

# COMMAND ----------

df_mrp_list_plo = df_mrp_list_return.withColumn(
    "planned_order_number",
    f.when((f.col("code_mvt") == "-") & (f.col("MRP_element") == "SB"),
        f.col("MDTB_aufvr"),
    ).otherwise(f.lit(None)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.1.8 - Work order origin
# MAGIC Element MRP = AR

# COMMAND ----------

df_mrp_list_wo = df_mrp_list_plo.withColumn(
    "work_order_number",
    f.when((f.col("code_mvt") == "-") & (f.col("MRP_element") == "AR"),
        f.col("MRP_element_number_ressources"),
    ).otherwise(f.lit(None)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.1.9 - Purchase order origin
# MAGIC Element MRP = BB

# COMMAND ----------

# Remove leading zero
df_mrp_list_wo = table_utils.remove_leading_zeros(
    df=df_mrp_list_wo,
    column_names=[
        "MDTB_aufvr",
        "MDTB_posvr",
    ],
)
list_mvt_po = ["BE", "LA"]
df_mrp_list_po = df_mrp_list_wo.withColumn(
    "PO_number",
    f.when(
        (f.col("code_mvt") == "-")
        & (f.col("MRP_element") == "BB")
        & (f.col("MDTB_delvr").isin(list_mvt_po)),
        f.col("MDTB_aufvr"),
    ).otherwise(f.lit(None)),
).withColumn(
    "PO_item_number",
    f.when(
        (f.col("code_mvt") == "-")
        & (f.col("MRP_element") == "BB")
        & (f.col("MDTB_delvr").isin(list_mvt_po)),
        f.col("MDTB_posvr"),
    ).otherwise(f.lit(None)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.1.10 - Purchase Request origin
# MAGIC Element MRP = BB

# COMMAND ----------

df_mrp_list_pr = df_mrp_list_po.withColumn(
    "PR_number",
    f.when(
        (f.col("code_mvt") == "-")
        & (f.col("MRP_element") == "BB")
        & (f.col("MDTB_delvr")=="BA"),
        f.col("MDTB_aufvr"),
    ).otherwise(f.lit(None)),
).withColumn(
    "PR_item_number",
    f.when(
        (f.col("code_mvt") == "-")
        & (f.col("MRP_element") == "BB")
        & (f.col("MDTB_delvr")=="BA"),
        f.col("MDTB_posvr"),
    ).otherwise(f.lit(None)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 4.2 - Dispatch Ressources

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.2.1 - Work Order
# MAGIC Element MRP = FE

# COMMAND ----------

df_mrp_list_wo_r = df_mrp_list_pr.withColumn(
    "work_order_number",
    f.when((f.col("code_mvt") == "+") & (f.col("MRP_element") == "FE"),
        f.col("MRP_element_number_ressources")
    ).otherwise(f.col("work_order_number")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.2.2 - Planned Order
# MAGIC Element MRP = PA

# COMMAND ----------

df_mrp_list_plo_r = df_mrp_list_wo_r.withColumn(
    "planned_order_number",
    f.when(
        ((f.col("code_mvt") == "+") & (f.col("MRP_element") == "PA")),
        f.col("MRP_element_number"),
    ).otherwise(f.col("planned_order_number")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.2.3 - Purchase orders
# MAGIC Element MRP = BE/LA

# COMMAND ----------

list_mvt_po = ["BE", "LA"]
df_mrp_list_po_r = df_mrp_list_plo_r.withColumn(
    "PO_number",
    f.when(
        (f.col("code_mvt") == "+") & (f.col("MRP_element").isin(list_mvt_po)),
        f.col("MRP_element_number"),
    ).otherwise(f.col("PO_number")),
).withColumn(
    "PO_item_number",
    f.when(
        (f.col("code_mvt") == "+") & (f.col("MRP_element").isin(list_mvt_po)),
        f.col("MRP_element_item_number"),
    ).otherwise(f.col("PO_item_number")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.2.4 - Purchase request
# MAGIC Element MRP = BA

# COMMAND ----------

df_mrp_list_pr_r = df_mrp_list_po_r.withColumn(
    "PR_number",
    f.when(
        (f.col("code_mvt") == "+") & (f.col("MRP_element")=="BA"),
        f.col("MRP_element_number"),
    ).otherwise(f.col("PR_number")),
).withColumn(
    "PR_item_number",
    f.when(
        (f.col("code_mvt") == "+") & (f.col("MRP_element")=="BA"),
        f.col("MRP_element_item_number"),
    ).otherwise(f.col("PR_item_number")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr. 4.2.6 - Inspection Lot 
# MAGIC Element MRP = QM

# COMMAND ----------

df_mrp_list_qm = df_mrp_list_pr_r.withColumn(
    "quality_inspection_number",
    f.when(
        (f.col("code_mvt") == "+") & (f.col("MRP_element")=="QM"),
        f.col("MRP_element_number_ressources"),
    ).otherwise(f.lit(None)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_to_check = df_mrp_list_qm
col_pk = "MRP_list_sap_ID"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for mrp list table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="MRP_list_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

df_mrp_end = df_mrp_list_qm.filter(f.col("is_production_mrp")=="True")
df_mrp_plt = df_mrp_list_qm

# COMMAND ----------

# MAGIC %md
# MAGIC ###Save 1.1 - Production MRP List

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "mrp"
DESTINATION_TABLE = "mrp_list_sap"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_mrp_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_mrp_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save 1.2 – Exposed Table View Production

# COMMAND ----------

dest_full_tablename = f"{DESTINATION_TABLE_FULL_PATH}_exposed"
Begin_By = [
    "MDKP",
    "MDTB",
]

selected_columns = [
    col
    for col in df_mrp_end.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH, dest_full_tablename, select_statement, replace_view=True
)

log.info(f"The table view {dest_full_tablename} has been successfully created")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Save 2.1 - MRP List with MRP Scenario

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "mrp"
DESTINATION_TABLE_2 = "mrp_list_simulation_sap"
DESTINATION_TABLE_FULL_PATH_2 = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE_2}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH_2,
        df=df_mrp_plt,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH_2} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH_2} saved in {duration} seconds.")
    log.info(f"Wrote {df_mrp_plt.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save 2.2 – Exposed Table View with MRP scenario

# COMMAND ----------

dest_full_tablename_2 = f"{DESTINATION_TABLE_FULL_PATH_2}_exposed"
Begin_By = [
    "MDKP",
    "MDTB",
]

selected_columns = [
    col
    for col in df_mrp_plt.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH_2, dest_full_tablename_2, select_statement, replace_view=True
)

log.info(f"The table view {dest_full_tablename_2} has been successfully created")

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_MRP_list_sap_pk"
TABLE_PK_COLS = "MRP_list_sap_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
