# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # MRP LIST WEEKLY HISTORY
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to create a silver history table for MRP List (Ressources / Needs).
# MAGIC The notebook performs the following tasks:
# MAGIC
# MAGIC - Data Loading: Loads the bronze tables containing the raw data mdkp, mdkpdb, mdtb, makt, marc
# MAGIC - Table Stacking: Stacks two tables  "mdkp" and "mdkpdb" respectively.
# MAGIC - Data Filtering: Filter MDKP on Production Mrp List & Production Planification Mrp List
# MAGIC - Date Formatting: Formats the date column to a desired format.
# MAGIC - Column Renaming: Renames specific columns to be exposed
# MAGIC - Table Joining : Join mdtb to the stack of mdkp,mdkpdb, then join to marc and makt, then to Plant master data
# MAGIC - Silver Table Creation: Generates a silver table with the cleaned and transformed data.
# MAGIC - Historization done on field : extraction_date
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - Stack and match of extraction_timestamp of several tables
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - MRP-list_mrp_full-Asset-Weekly
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - Update : Weekly
# MAGIC   - History : Once (exceptionally more)
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.mdkp_stack
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.mdkpdb_stack
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.mdtb_stack
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.makt_stack
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.marc_stack
# MAGIC   - {reference_read_env}_gold.master_data.plant_master_data_latest_exposed
# MAGIC   - {reference_read_env}_bronze.headers_sap.headers_sap_business_mdkp
# MAGIC   - {reference_read_env}_bronze.headers_sap.headers_sap_business_mdtb
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.mrp.list_mrp_full_history
# MAGIC
# MAGIC **Output Files Pipeline**
# MAGIC N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Spark
# MAGIC

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC ```
# MAGIC ```
# MAGIC #### functions used from "leap_utils.data_asset.table_utils"
# MAGIC ```
# MAGIC table_utils.add_prefix_to_columns()
# MAGIC table_utils.UnityCatalogCheckTableExists()
# MAGIC table_utils.drop_duplicates_by_order()
# MAGIC table_utils.get_columns_for_insertion_after_column()
# MAGIC table_utils.rename_columns_with_sap_business_header()
# MAGIC table_utils.cast_columns_with_sap_business_headers()
# MAGIC table_utils.create_unity_catalog_table
# MAGIC table_utils.set_table_column_not_null()
# MAGIC table_utils.add_table_primary_key()
# MAGIC ```
# MAGIC
# MAGIC #### functions used from leap_utils.common.validation.gx_validation
# MAGIC ```
# MAGIC gx_validation.validate_and_log_gx_results()
# MAGIC ```

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("run_job_on_latest", "true")  # history/update
RUN_JOB_ON_LATEST = dbutils.widgets.get("run_job_on_latest").lower() == "true"

dbutils.widgets.text("time_delta_allowance_hours", "8")  # hours for stack&match
TIME_DELTA_ALLOWANCE_HOURS = int(dbutils.widgets.get("time_delta_allowance_hours"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "debug")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables Location
# MAGIC
# MAGIC Details on how to read the input tables

# COMMAND ----------

BRONZE_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6"
HEADERS_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.headers_sap"

# SAP table MDKP - Header Mrp List
t_mdkp_stack = f"{BRONZE_SCHEMA}.mdkp_stack"
# SAP table MDTB - Item Mrp List
t_mdtb_stack = f"{BRONZE_SCHEMA}.mdtb_stack"
# SAP table MDKPDB - Header Mrp List unit planif
t_mdkpdb_stack = f"{BRONZE_SCHEMA}.mdkpdb_stack"
# SAP table MAKT for Description enrichment
t_makt_stack = f"{BRONZE_SCHEMA}.makt_stack"
# SAP table MARC for profit center enrichment
t_marc_stack = f"{BRONZE_SCHEMA}.marc_stack"
# Upload Manual table for Plant Master Data
t_plant_master_data = (
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)


# SAP business header
t_name_mdkp = f"{HEADERS_SCHEMA}.headers_sap_business_mdkp"
t_name_mdtb = f"{HEADERS_SCHEMA}.headers_sap_business_mdtb"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_SCHEMA = f"{PIPELINE_WRITE_ENV}_silver.mrp"
TABLE_DEST = f"{SILVER_SCHEMA}.list_mrp_full_history"
TABLE_DEST_PK = "list_mrp_full_history_PK"
MODE = "append" if RUN_JOB_ON_LATEST else "overwrite"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# Columns needed to create the empty table at first run
TABLE_DEST_FIRST_COLS = {
    "mdkp_stack_row_id": "BIGINT",
    "mdkp_ID": "STRING",
    "extraction_date": "DATE",
    "mdkp_extraction_timestamp": "TIMESTAMP",
    "mdkp_ingestion_timestamp": "TIMESTAMP",
    "mdkp_file_name": "STRING",
    "mdkp_file_mode": "STRING",
    "mdkp_table_name": "STRING",
    "mdkp_file_modification_time": "TIMESTAMP",
    "mdkp_mandt": "STRING",
    "mdkp_dtart": "STRING",
    "Material_Number": "STRING",
    "Plant": "STRING",
}

# As it's a huge table, we'll cluster it by these columns, rather than partitioning
TABLE_DEST_CLUSTER_COLS = "extraction_date,Material_Number,Plant"

# As a best practice, we'll define a Primary Key on the output table, below are the PK columns
TABLE_DEST_PK_COLS = "extraction_date,mdkp_ID,mdtb_ID"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# Sample reference date when target table exists ans is empty
THE_ORIGIN = "1970-01-01"

# TIME DELTA ALLOWANCE in hours , for stack&match of extraction_timestamps(s)
TIME_DELTA_ALLOWANCE = f.make_dt_interval(hours=f.lit(TIME_DELTA_ALLOWANCE_HOURS))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.debug(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.debug(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.debug(f"RUN_JOB_ON_LATEST is:  {RUN_JOB_ON_LATEST}")
log.debug(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.debug(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.debug(f"TIME_DELTA_ALLOWANCE is:  {TIME_DELTA_ALLOWANCE} hours")
log.debug(f"TABLE_DEST is:  {TABLE_DEST}")
log.debug(f"MODE is:  {MODE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Read tables
# MAGIC - Stack and match

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Tables MRP & headers

# COMMAND ----------

# Upload SAP table MDKP - Header Mrp List
df_mdkp = spark.read.table(f"{t_mdkp_stack}")
df_mdkp = table_utils.add_prefix_to_columns(df_mdkp, "mdkp")

# Upload SAP table MDTB - Item Mrp List
df_mdtb = spark.read.table(f"{t_mdtb_stack}")
df_mdtb = table_utils.add_prefix_to_columns(df_mdtb, "mdtb")
# Upload SAP table MDKPDB - Header Mrp List unit planif
df_mdkpdb = spark.read.table(f"{t_mdkpdb_stack}")
df_mdkpdb = table_utils.add_prefix_to_columns(df_mdkpdb, "mdkp")

# Upload SAP table MAKT
df_makt = spark.read.table(f"{t_makt_stack}")
df_makt = table_utils.add_prefix_to_columns(df_makt, "makt")

# Upload SAP table MARC
df_marc = spark.read.table(f"{t_marc_stack}")
df_marc = table_utils.add_prefix_to_columns(df_marc, "marc")

# Upload Manual table for Plant Master Data
df_plant = spark.read.table(f"{t_plant_master_data}")

# Upload SAP headers
df_name_mdkp = spark.read.table(f"{t_name_mdkp}")
df_name_mdtb = spark.read.table(f"{t_name_mdtb}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Repartition Tables by dtnum

# COMMAND ----------

df_mdkp = df_mdkp.repartition("mdkp_dtnum")
df_mdkpdb = df_mdkpdb.repartition("mdkp_dtnum")
df_mdtb = df_mdtb.repartition("mdtb_dtnum")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - If RUN_JOB_ON_LATEST Filter all tables on needed stacks

# COMMAND ----------

# check job type - Filter all tables on needed stacks - exit notebook if target is up to date
if (table_utils.UnityCatalogCheckTableExists(TABLE_DEST)) and (
    RUN_JOB_ON_LATEST == True
):
    df_target = spark.read.table(TABLE_DEST)
    latest_extraction_date = df_target.select(
        f.greatest(
            f.max("mdkp_extraction_timestamp"), f.max("mdtb_extraction_timestamp")
        )
    ).first()[0]

    if latest_extraction_date is None:
        latest_extraction_date = THE_ORIGIN
        log.info(
            f"the latest_extraction_date in {TABLE_DEST} is None, taking : {latest_extraction_date}"
        )
    else:
        log.info(
            f"the latest_extraction_date in {TABLE_DEST} is : {latest_extraction_date}"
        )

    df_mdkp = df_mdkp.filter(
        f.col("mdkp_extraction_timestamp") > latest_extraction_date
    )

    df_mdkpdb = df_mdkpdb.filter(
        f.col("mdkp_extraction_timestamp") > latest_extraction_date
    )

    df_mdtb = df_mdtb.filter(
        f.col("mdtb_extraction_timestamp") > latest_extraction_date
    )

    df_makt = df_makt.filter(
        f.col("makt_extraction_timestamp") > latest_extraction_date
    )

    df_marc = df_marc.filter(
        f.col("marc_extraction_timestamp") > latest_extraction_date
    )
else:
    MODE = "overwrite"
    log.debug(f"MODE is:  {MODE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Filter MDTB on FULL loads

# COMMAND ----------

df_mdtb_filtered = df_mdtb.filter((f.col("file_mode") == "FULL"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Filter MAKT

# COMMAND ----------

# Keep only English Language
df_makt_filtered = (
    df_makt.filter(f.col("makt_spras") == "E")
    .withColumnRenamed("makt_maktx", "Material_Description")
    .select("makt_matnr", "Material_Description", "makt_extraction_timestamp")
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Filter MARC

# COMMAND ----------

# Keep only Profit_Center Information
df_marc_filtered = (
    df_marc.select(
        "marc_matnr", "marc_werks", "marc_prctr", "marc_extraction_timestamp"
    )
    .withColumnRenamed("marc_matnr", "marc_matnr_1")
    .withColumnRenamed("marc_prctr", "Profit_Center")
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 5 - Filter Plant Master Data

# COMMAND ----------

df_plant = df_plant.select("Plant", "Plant_Description_new", "ID_Calendar")
df_plant = (
    df_plant.withColumnRenamed("Plant", "Plant_")
    .withColumnRenamed("Plant_Description_new", "Plant_Description")
    .dropDuplicates()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 6 - Stack & Match extraction_timestamp(s)

# COMMAND ----------

# Retrieve Extraction timestamps (mdkp/mdkpdb/mdtb)
mdkp_timestamps = (
    df_mdkp.select(
        f.col("mdkp_extraction_timestamp").alias("mdkp_extraction_timestamp")
    )
    .distinct()
    .sort("mdkp_extraction_timestamp")
)
mdkpdb_timestamps = (
    df_mdkpdb.select(
        f.col("mdkp_extraction_timestamp").alias("mdkpdb_extraction_timestamp")
    )
    .distinct()
    .sort("mdkpdb_extraction_timestamp")
)
mdtb_timestamps = (
    df_mdtb_filtered.select(
        f.col("mdtb_extraction_timestamp").alias("mdtb_extraction_timestamp")
    )
    .distinct()
    .sort("mdtb_extraction_timestamp")
)

# Join both mdkp_timestamps and mdkpdb_timestamps to drop multiple extraction and remove incomplete extractions (only allow a certain interval of TIME_DELTA_ALLOWANCE hours between two extractions)
mdkpxx_timestamps = mdkp_timestamps.hint("range_join", 60).join(
    mdkpdb_timestamps,
    on=(
        mdkp_timestamps.mdkp_extraction_timestamp
        >= (mdkpdb_timestamps.mdkpdb_extraction_timestamp - TIME_DELTA_ALLOWANCE)
    )
    & (
        mdkp_timestamps.mdkp_extraction_timestamp
        < (mdkpdb_timestamps.mdkpdb_extraction_timestamp + TIME_DELTA_ALLOWANCE)
    ),
    how="left",
)
mdkpxx_timestamps = mdkpxx_timestamps.dropna()

# COMMAND ----------

# Retrieve Extraction timestamps (makt)
makt_timestamps = (
    df_makt_filtered.select(
        f.col("makt_extraction_timestamp").alias("makt_extraction_timestamp")
    )
    .distinct()
    .sort("makt_extraction_timestamp")
)

# COMMAND ----------

# Retrieve Extraction timestamps (marc)
marc_timestamps = (
    df_marc_filtered.select(
        f.col("marc_extraction_timestamp").alias("marc_extraction_timestamp")
    )
    .distinct()
    .sort("marc_extraction_timestamp")
)

# COMMAND ----------

# Join mdtb_timestamps with mdtb_timestamps,makt_timestamps,marc_timestamps and remove incomplete extractions (only allow a certain interval of TIME_DELTA_ALLOWANCE hours between two extractions)
mrp_timestamps = (
    mdtb_timestamps.hint("range_join", 60)
    .join(
        mdkpxx_timestamps,
        on=(
            mdtb_timestamps.mdtb_extraction_timestamp
            >= (mdkpxx_timestamps.mdkp_extraction_timestamp - TIME_DELTA_ALLOWANCE)
        )
        & (
            mdtb_timestamps.mdtb_extraction_timestamp
            < (mdkpxx_timestamps.mdkp_extraction_timestamp + TIME_DELTA_ALLOWANCE)
        ),
        how="left",
    )
    .hint("range_join", 60)
    .join(
        makt_timestamps,
        on=(
            mdtb_timestamps.mdtb_extraction_timestamp
            >= (makt_timestamps.makt_extraction_timestamp - TIME_DELTA_ALLOWANCE)
        )
        & (
            mdtb_timestamps.mdtb_extraction_timestamp
            < (makt_timestamps.makt_extraction_timestamp + TIME_DELTA_ALLOWANCE)
        ),
        how="left",
    )
    .hint("range_join", 60)
    .join(
        marc_timestamps,
        on=(
            mdtb_timestamps.mdtb_extraction_timestamp
            >= (marc_timestamps.marc_extraction_timestamp - TIME_DELTA_ALLOWANCE)
        )
        & (
            mdtb_timestamps.mdtb_extraction_timestamp
            < (marc_timestamps.marc_extraction_timestamp + TIME_DELTA_ALLOWANCE)
        ),
        how="left",
    )
)
mrp_timestamps = mrp_timestamps.dropna()
mrp_timestamps = (
    mrp_timestamps.withColumn(
        "extraction_date", f.to_date(f.col("mdtb_extraction_timestamp"))
    )
    .withColumn("day_of_week", f.dayofweek("extraction_date"))
    .withColumn(
        "extraction_week",
        f.when(
            f.col("day_of_week").isin(2, 3),
            f.weekofyear("extraction_date") - f.col("day_of_week") + 1,
        ).otherwise(f.weekofyear("extraction_date")),
    )
    .withColumn(
        "extraction_month",
        f.month("extraction_date"),
    )
    .withColumn(
        "extraction_year",
        f.when(
            (f.col("extraction_week").isin(52, 53)) & (f.col("extraction_month") == 1),
            f.year("extraction_date") - 1,
        ).otherwise(f.year("extraction_date")),
    )
    .drop("day_of_week", "extraction_month")
)
# Drop dupplicates of date based on first occurence in case
mrp_timestamps = table_utils.drop_duplicates_by_order(
    mrp_timestamps,
    "extraction_date",
    [
        "mdtb_extraction_timestamp",
        "mdkp_extraction_timestamp",
        "mdkpdb_extraction_timestamp",
    ],
    keep="last",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Display Timestamps
# MAGIC
# MAGIC At this step we may want to print all timestamps, the final one being mrp_timestamps
# MAGIC

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    display(mdkpxx_timestamps)
    display(mdtb_timestamps)
    display(makt_timestamps)
    display(marc_timestamps)
    display(mrp_timestamps)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 7 - Filter MDKP on common extraction_date

# COMMAND ----------

# filter mdkp with incomplete extraction by doing an inner join with mrp_timestamps
df_mdkp = (
    df_mdkp.join(
        f.broadcast(mrp_timestamps).select(
            f.col("mdkp_extraction_timestamp"),
            f.col("extraction_date").alias("mdkp_extraction_date"),
        ),
        on="mdkp_extraction_timestamp",
        how="inner",
    )
    .withColumnRenamed("mdkp_extraction_timestamp", "mdkp_extraction_timestamp_1")
    .withColumnRenamed("mdkp_extraction_date", "mdkp_extraction_date_1")
)

# Move "mdkp_extraction_timestamp" and "mdkp_extraction_date" columns
df_mdkp = (
    df_mdkp.withColumns(
        {
            "mdkp_extraction_timestamp": f.col("mdkp_extraction_timestamp_1"),
            "extraction_date": f.col("mdkp_extraction_date_1"),
        },
    ).select(
        *table_utils.get_columns_for_insertion_after_column(
            df_mdkp,
            search_column_name="mdkp_ID",
            insert_columns=["extraction_date", "mdkp_extraction_timestamp"],
        )
    )
).drop("mdkp_extraction_timestamp_1", "mdkp_extraction_date_1")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 8 - Filter MDKPDB on common extraction_date

# COMMAND ----------

# filter mdkpdb with incomplete extraction by doing an inner join with mrp_timestamps
df_mdkpdb = (
    df_mdkpdb.join(
        f.broadcast(mrp_timestamps).select(
            f.col("mdkpdb_extraction_timestamp").alias("mdkp_extraction_timestamp"),
            f.col("extraction_date").alias("mdkp_extraction_date"),
        ),
        on="mdkp_extraction_timestamp",
        how="inner",
    )
    .withColumnRenamed("mdkp_extraction_timestamp", "mdkp_extraction_timestamp_1")
    .withColumnRenamed("mdkp_extraction_date", "mdkp_extraction_date_1")
)

# Move "mdkp_extraction_timestamp" and "mdkp_extraction_date" columns
df_mdkpdb = (
    df_mdkpdb.withColumns(
        {
            "mdkp_extraction_timestamp": f.col("mdkp_extraction_timestamp_1"),
            "extraction_date": f.col("mdkp_extraction_date_1"),
        },
    ).select(
        *table_utils.get_columns_for_insertion_after_column(
            df_mdkpdb,
            search_column_name="mdkp_ID",
            insert_columns=["extraction_date", "mdkp_extraction_timestamp"],
        )
    )
).drop("mdkp_extraction_timestamp_1", "mdkp_extraction_date_1")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 9 - Filter MDTB on common extraction_date

# COMMAND ----------

# filter mdtb with incomplete extraction by doing an inner join with mrp_timestamps
df_mdtb_filtered = (
    df_mdtb_filtered.join(
        f.broadcast(mrp_timestamps).select(
            f.col("mdtb_extraction_timestamp"),
            f.col("extraction_date").alias("mdtb_extraction_date"),
        ),
        on="mdtb_extraction_timestamp",
        how="inner",
    )
    .withColumnRenamed("mdtb_extraction_timestamp", "mdtb_extraction_timestamp_1")
    .withColumnRenamed("mdtb_extraction_date", "mdtb_extraction_date_1")
)

# Move "mdtb_extraction_timestamp" and "mdtb_extraction_date" columns
df_mdtb_filtered = (
    df_mdtb_filtered.withColumns(
        {
            "mdtb_extraction_timestamp": f.col("mdtb_extraction_timestamp_1"),
            "mdtb_extraction_date": f.col("mdtb_extraction_date_1"),
        },
    ).select(
        *table_utils.get_columns_for_insertion_after_column(
            df_mdtb_filtered,
            search_column_name="mdtb_ID",
            insert_columns=["mdtb_extraction_timestamp", "mdtb_extraction_date"],
        )
    )
).drop("mdtb_extraction_timestamp_1", "mdtb_extraction_date_1")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 10 - Filter MAKT on common extraction_date

# COMMAND ----------

# filter makt with incomplete extraction by doing an inner join with mrp_timestamps
df_makt_filtered = df_makt_filtered.join(
    f.broadcast(mrp_timestamps).select(
        f.col("makt_extraction_timestamp"),
        f.col("extraction_date").alias("makt_extraction_date"),
    ),
    on="makt_extraction_timestamp",
    how="inner",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 11 - Filter MARC on common extraction_date

# COMMAND ----------

# filter marc with incomplete extraction by doing an inner join with mrp_timestamps
df_marc_filtered = df_marc_filtered.join(
    f.broadcast(mrp_timestamps).select(
        f.col("marc_extraction_timestamp"),
        f.col("extraction_date").alias("marc_extraction_date"),
    ),
    on="marc_extraction_timestamp",
    how="inner",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 12 - Fusion Tables MDKP / MDKPDB

# COMMAND ----------

df_stack_mdkp = df_mdkp.unionByName(df_mdkpdb, allowMissingColumns=True)
# Management Unit_planification
df_stack_mdkp = df_stack_mdkp.withColumn(
    "Planif_unit",
    f.when(f.col("mdkp_berid").isNull(), f.col("mdkp_plwrk")).otherwise(
        f.col("mdkp_berid")
    ),
)
df_stack_mdkp = df_stack_mdkp.drop("mdkp_berid")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 13 - Filter MDKP on Production Mrp List & Production Planification Mrp List

# COMMAND ----------

## Keep only Production MRP List (ie-> Exclusion Simulation)
# Filter Production Mrp List & Production Planification Mrp List
df_stack_mdkp_filtered = df_stack_mdkp.filter(
    (f.col("mdkp_dtart") == "MD") & (f.col("mdkp_plscn") == "000")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------


# Check Header from Manual Input file
def check_schema_of_the_file(df_names: SparkDataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# --------------------------------------------------------------------------------------------------------------


# Delete rows when field is null
def delete_null_rows(df_names: SparkDataFrame) -> SparkDataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Join MDKP/MDKPDB with MDTB to Build MRP List

# COMMAND ----------

# Stack MDKP/MDKPDB inner join MDTB
df_join_mrp = df_stack_mdkp_filtered.join(
    df_mdtb_filtered,
    on=(df_stack_mdkp_filtered.mdkp_dtnum == df_mdtb_filtered.mdtb_dtnum)
    & (df_stack_mdkp_filtered.extraction_date == df_mdtb_filtered.mdtb_extraction_date),
    how="inner",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Join MRP List with Plant, MAKT, MARC

# COMMAND ----------

# Join MRP List with Master Data Material and plant
df_join_end = (
    df_join_mrp.join(
        f.broadcast(df_plant),
        on=(df_join_mrp.mdkp_plwrk == df_plant.Plant_),
        how="left",
    )
    .join(
        df_makt_filtered,
        on=(df_join_mrp.mdkp_matnr == df_makt_filtered.makt_matnr)
        & (df_join_mrp.extraction_date == df_makt_filtered.makt_extraction_date),
        how="left",
    )
    .join(
        df_marc_filtered,
        on=(df_join_mrp.mdkp_matnr == df_marc_filtered.marc_matnr_1)
        & (df_join_mrp.mdkp_plwrk == df_marc_filtered.marc_werks)
        & (df_join_mrp.extraction_date == df_marc_filtered.marc_extraction_date),
        how="left",
    )
    .drop(
        "makt_matnr",
        "marc_matnr_1",
        "marc_werks",
        "mdtb_extraction_date",
        "makt_extraction_timestamp",
        "makt_extraction_date",
        "marc_extraction_timestamp",
        "marc_extraction_date",
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Renaming Headers

# COMMAND ----------

# Call function Check Header files
check_schema_of_the_file(df_name_mdkp)
# Call Function Delete rows null
df_name_mdkp = delete_null_rows(df_name_mdkp)

# Call function Check Header files
check_schema_of_the_file(df_name_mdtb)
# Call Function Delete rows null
df_name_mdtb = delete_null_rows(df_name_mdtb)

# Union Headers-Item
df_names_all = df_name_mdkp.unionByName(df_name_mdtb)

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_join_end, df_names_all
)
# Call Funtion Create Columns on Date format
df_mrp_list = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_names_all
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Cleansing raw data

# COMMAND ----------

# Formatting Material_Number without '0' on left side
df_mrp_end = df_mrp_list.withColumn(
    "Material_Number", f.regexp_replace(df_mrp_list.Material_Number, "^0+", "")
)
# Formatting Profit_Center without '0' on left side
df_mrp_end = df_mrp_end.withColumn(
    "Profit_Center", f.regexp_replace(df_mrp_end.Profit_Center, "^0+", "")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - Did we found new Data
# MAGIC
# MAGIC N/A

# COMMAND ----------

if df_mrp_end.isEmpty():
    assert (
        False
    ), "Aucune donnée trouvée. Exécuter en mode debug et vérifier le stack & match des extraction_timestamp"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 2 - Uniqueness
# MAGIC
# MAGIC N/A

# COMMAND ----------

# Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
dfgx_In1_prep = SparkDFDataset(df_mrp_end, persist=False)

# Define the red quality checks
table_dest_pk_cols_list = TABLE_DEST_PK_COLS.split(",")
red_quality_check_results = [
    dfgx_In1_prep.expect_compound_columns_to_be_unique(
        column_list=table_dest_pk_cols_list
    )
]

# Validate all red quality checks, if at least one fails the job stops
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message=f"Compound cols {TABLE_DEST_PK_COLS} are unique",
    error_message=f"Compound cols {TABLE_DEST_PK_COLS} are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="mrp_history_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Silver MRP List history

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Table

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by TABLE_DEST_CLUSTER_COLS
catalog, schema, table = TABLE_DEST.split(".")

try:
    table_utils.create_unity_catalog_table(
        catalog,
        schema,
        table,
        force_reinitialization=False,
        cluster_cols=TABLE_DEST_CLUSTER_COLS,
        partition_col=None,
        primary_key_cols=None,
        columns=TABLE_DEST_FIRST_COLS,
        force_drop=False,
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_DEST} has not been created, an error occured during creation. \nError is {e}"
    )
    raise Exception()

# COMMAND ----------

# Save the table from Dataframe df_mrp_end, preserving cluster columns
table_dest_cluster_cols_cleaned = TABLE_DEST_CLUSTER_COLS.replace(" ", "")
try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=TABLE_DEST,
        df=df_mrp_end,
        mode=MODE,
        overwrite_schema=True,
        merge_schema=True,
        cluster_cols=table_dest_cluster_cols_cleaned,
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_DEST} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {TABLE_DEST} saved in {duration} seconds.")
    log.info(f"Wrote {df_mrp_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Constraints

# COMMAND ----------

# Add Primary Key if not exists
catalog, schema, table = TABLE_DEST.split(".")
pk_name = TABLE_DEST_PK.lower()
nb_cons = spark.sql(
    f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_DEST_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(table_path=TABLE_DEST, column=col.strip())

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=TABLE_DEST,
        pk_name=TABLE_DEST_PK,
        columns=TABLE_DEST_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
