# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a Gold & Gold exposed table for MRP Reservation 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_gold.mrp.sap_mrp_reservation_latest
# MAGIC   - {WRITE_ENV}_gold.mrp.sap_mrp_reservation_latest_exposed
# MAGIC
# MAGIC **Intput :**  
# MAGIC   - {ENV}_silver.mrp.sap_mrp_reservation_latest
# MAGIC   - {READ_ENV}_gold.finance.wbs_otp  
# MAGIC   - {READ_ENV}_gold.master_data.material_master_data_plant_exposed 
# MAGIC   - {READ_ENV}_gold.master_data.plant_master_data_latest_exposed
# MAGIC
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Notebook create_silver_mrp_reservation_daily
# MAGIC
# MAGIC **Things performed in this notebook:** 
# MAGIC - Add WBS Coding
# MAGIC - Add Material Master Data
# MAGIC - Add plant and company information
# MAGIC - Save Gold Table

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql import Window
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")
# Get READ_TEMP environment variable
dbutils.widgets.text("ENV", "prod")
ENV = dbutils.widgets.get("ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC # DownLoad Silver MRP reservation Table

# COMMAND ----------

# Upload Reservations silver Table
df_reservations = spark.read.table(f"{ENV}_silver.mrp.sap_mrp_reservation_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC # Enrichment Gold

# COMMAND ----------

# MAGIC %md 
# MAGIC ##Management of WBS coding

# COMMAND ----------

## We use Gold Table WBS to translate WBS_Code_Num to Business WBS_Code
# Upload WBS Gold Table
df_otp = (
    spark.read.table(f"{READ_ENV}_gold.finance.wbs_otp")
    .select("WBS_Code_Num", "WBS_Code")
    .withColumnRenamed("WBS_Code_Num", "WBS_Element")
)

# Join WBS description with Mrp reservation Table
df_reservation_wbs = df_reservations.join(df_otp, ["WBS_Element"], "left").drop(
    "WBS_Element"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add Unif Planif from Work Order

# COMMAND ----------

df_work_order = (
    spark.read.table(f"{READ_ENV}_gold.production.sap_work_order_basics_latest_exposed")
    .select(f.col("WO_Number").alias("XX_number"), "Unit_planif")
    .withColumn("XX_Item_Number", f.lit(""))
)

df_planned_order = (
    spark.read.table(f"{READ_ENV}_gold.production.sap_planned_order_latest_exposed")
    .select(
        f.col("Planned_Order_Number").alias("XX_number"),
        "Unit_planif",
    )
    .withColumn("XX_Item_Number", f.lit(""))
)

df_purchase_orders = spark.read.table(
    f"{READ_ENV}_gold.supply_chain_procurement.purchase_orders"
).select(
    f.col("MRP_Unit").alias("Unit_Planif"),
    f.col("PO_Number").alias("XX_Number"),
    f.col("PO_Item_Number").alias("XX_Item_Number"),
)

df_purchase_request = spark.read.table(
    f"{READ_ENV}_gold.supply_chain_procurement.purchase_request_sap"
).select(
    f.col("PR_Number").alias("XX_Number"),
    f.col("PR_Item_Number").alias("XX_Item_Number"),
    f.col("MRP_Unit").alias("Unit_planif"),
)


df_union_orders_all = (
    df_planned_order.unionByName(df_work_order)
    .unionByName(df_purchase_orders)
    .unionByName(df_purchase_request)
)
df_union_orders_all = table_utils.remove_leading_zeros(
    df=df_union_orders_all,
    column_names=["XX_Number", "XX_Item_Number"],
)


df_reservation_unit_planif = df_reservation_wbs.withColumn(
    "XX_Number",
    f.coalesce(
        f.col("Work_Order_Origin"),
        f.col("Planned_Order_Origin"),
        f.col("RESB_ebeln"),
        f.col("RESB_banfn"),
    ),
)

df_reservation_unit_planif = df_reservation_unit_planif.withColumn(
    "XX_Item_Number",
    f.when(f.col("RESB_ebeln").isNotNull(), f.col("RESB_ebelp")).otherwise(f.lit("")),
)
df_reservation_unit_planif = df_reservation_unit_planif.withColumn(
    "XX_Item_Number",
    f.when(f.col("RESB_banfn").isNotNull(), f.col("RESB_bnfpo")).otherwise(
        f.col("XX_Item_Number")
    ),
)

df_reservation_unit_planif_clean = table_utils.remove_leading_zeros(
    df=df_reservation_unit_planif,
    column_names=["XX_Number", "XX_Item_Number"],
)

df_reservation_unit_planif = df_reservation_unit_planif_clean.join(
    df_work_order,
    ["XX_number", "XX_Item_Number"],
    "left",
).drop("XX_number", "XX_Item_Number")

df_reservation_unit_planif_end = df_reservation_unit_planif.withColumn(
    "MRP_Unit",
    f.when(
        f.col("Unit_planif").isNull(),
        f.col("Plant"),
    ).otherwise(f.col("Unit_planif")),
).drop("Unit_planif")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add Material Master information

# COMMAND ----------

## We add profit center, mrp controller, and description
# Upload Gold Master Data Material by plant
df_material = (
    spark.read.table(f"{READ_ENV}_gold.master_data.material_master_data_plant_exposed")
    .select(
        "Material_Number", "Plant", "Profit_Center", "Description", "Mrp_Controller", "MRP_Unit"
    )
    .withColumnRenamed("Description", "Material_Number_Description")
    .dropDuplicates()
)

# Join Material infos with Mrp reservation Table
df_reservation_material = df_reservation_unit_planif_end.join(
    df_material, ["Material_Number", "Plant", "MRP_Unit"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Add information for Plant Company and branch

# COMMAND ----------

# Upload Gold Master Data Plant
df_plant = (
    spark.read.table(f"{READ_ENV}_gold.master_data.plant_master_data_latest_exposed")
    .select("Plant", "Plant_Description_new")
    .withColumnRenamed("Plant_Description_new", "Production_Site")
)

# Join Plant description on Work Order Table
df_reservation_plant = df_reservation_material.join(df_plant, ["Plant"], "left")

# Dispatch Production Site for Plant 1000 (Gimont/Montredon/DES)
df_reservation_site = df_reservation_plant.withColumn(
    "Production_Site",
    f.when(f.col("Plant") != "1000", f.col("Production_Site"))
    .when(f.substring(f.col("Mrp_Controller"), 1, 1) == "O", f.lit("LFR-Montredon"))
    .when(f.col("Mrp_Controller") == "DET", f.lit("LFR-DES"))
    .otherwise(f.lit("LFR-Gimont")),
)
# Determination Branch AS / IS
df_reservation_branch = df_reservation_site.withColumn(
    "Branch",
    f.when(
        (f.col("Production_Site") == "LFR-DES")
        | (f.substring(f.col("Plant"), 0, 1) == "2"),
        f.lit("IS"),
    ).otherwise(f.lit("AS")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Add Status Reservations

# COMMAND ----------

df_reservation_branch = df_reservation_branch.withColumn(
    "Status",
    f.when(f.col("Item_Closed") == "X",f.lit("Res. Closed"))
    .when(f.col("Item_Cancel") == "X",f.lit("Res. Cancel"))
    .when((f.col("RESB_dumps") == "X")|(f.col("RESB_schgt") == "X"),f.lit("Res. Phantom"))
    .otherwise(f.lit("Res. Open")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "mrp"
table = "sap_mrp_reservation_latest"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_reservation_branch,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold Latest exposed table

# COMMAND ----------

catalog = "gold"
domain = "mrp"
table = "sap_mrp_reservation_latest"
src_full_tablename = f"{WRITE_ENV}_{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "RESB"

selected_columns = [
    col for col in df_reservation_branch.columns if not col.startswith(Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
