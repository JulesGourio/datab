# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC This script creates the gold and gold exposed table for Exception Message from SAP MRP. 
# MAGIC
# MAGIC **Inputs Table Data**
# MAGIC - {PIPELINE_READ_ENV}_silver.mrp.exception_message
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tfacs_latest
# MAGIC
# MAGIC **Output Tables (Pipeline)**  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.mrp.exception_message  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.mrp.exception_message_exposed
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Tech Debt

# COMMAND ----------

# Use Fonction lowerCase to modify all column naming -> before complete refacto of data asset

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import DataFrame
from typing import Iterable
from pyspark.sql.window import Window
import datetime

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC
# MAGIC - **convert_currency** required for currency conversion of amounts
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

  
#n.a

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config spark

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Upload Silver Exception Message
# MAGIC
# MAGIC **df_mess** is the silver table for MRP exception messages. 
# MAGIC

# COMMAND ----------

df_mess = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.mrp.exception_message"
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Upload Gold Material Master data by Plant

# COMMAND ----------

df_material = spark.read.table(f"{REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Upload Gold Plant Master data

# COMMAND ----------

df_plant = spark.read.table(f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Upload SAP table Tfacs - SAP calendars with working days
# MAGIC

# COMMAND ----------

df_TFACS = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tfacs_latest") 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# Standard MELT function
def melt(
    df: DataFrame,
    id_vars: Iterable[str],
    value_vars: Iterable[str],
    var_name: str = "variable",
    value_name: str = "value",
) -> DataFrame:
    """Convert :class:`DataFrame` from wide to long format."""

    # Create array<struct<variable: str, value: ...>>
    _vars_and_vals = f.array(
        *(f.struct(f.lit(c).alias(var_name), f.col(c).alias(value_name)) for c in value_vars)
    )

    # Add to the DataFrame and explode
    _tmp = df.withColumn("_vars_and_vals", f.explode(_vars_and_vals))

    cols = id_vars + [f.col("_vars_and_vals")[x].alias(x) for x in [var_name, value_name]]
    return _tmp.select(*cols)
#-------------------------------------------------------------------------------------------
# Converts TFACs to Calendar dataframe
def ConvertTFACsToCal(df_TFACs:DataFrame):

    # Rename TFACs Columns -> This section can be replaces if TFACs is pre-processed
    rename_dict = {
        "ident": "Country_Code",
        "jahr": "Year",
        "mon01": "01",
        "mon02": "02",
        "mon03": "03",
        "mon04": "04",
        "mon05": "05",
        "mon06": "06",
        "mon07": "07",
        "mon08": "08",
        "mon09": "09",
        "mon10": "10",
        "mon11": "11",
        "mon12": "12",
    }

    for key in rename_dict.keys():
        df_TFACs = df_TFACs.withColumnRenamed(key, rename_dict[key])

    # Melt TFACs
    df_melt = (
        melt(
            df_TFACs, id_vars=["Country_Code", "Year"], value_vars=df_TFACs.columns[10:22]
        )
        .withColumnRenamed("variable", "Month")
        .withColumnRenamed("value", "WorkingDayString")
    ).withColumn("WorkingDayArray", f.split("WorkingDayString", "(?!$)"))

    # Explode the melted TFACs
    df_cal = (
        df_melt.select(
            df_melt.Country_Code,
            df_melt.Year,
            df_melt.Month,
            f.posexplode_outer("WorkingDayArray").alias("rank", "listitem"),
        )
        .withColumn("rank", f.col("rank") + 1)
        .withColumnRenamed("listitem", "WorkingDay")
        .withColumn("Day", f.lpad(f.col("rank"), 2, "0"))
        .withColumn("DateString", f.concat_ws("-", f.col("Year"), f.col("Month"), f.col("Day")))
        .drop("rank")
    )
    return df_cal

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 1 - Creation Calendars with Working days
# MAGIC
# MAGIC

# COMMAND ----------

df_cal = ConvertTFACsToCal(df_TFACS)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 2 - Material Master Data Selection

# COMMAND ----------

# Upload manual table for headers naming MDKP
df_material_seleted = df_material.select(
    "Material_Number",
    f.col("Description").alias("material_description"),
    "Standard_Price_EUR_Budget",
    "Plant",
    "Branch",
    "Profit_Center",
    f.col("MRP_Unit").alias("planif_unit"),
)
# -----------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 3 - Plant Master Data Selection

# COMMAND ----------

# Upload manual table for headers naming MDKP
df_plant_seleted = df_plant.select(
    "Plant", "Plant_Description_new", "Id_Calendar","Company"
)
# -----------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr 1 - Join Exception Message & Material Master data & Plant Master Data

# COMMAND ----------

df_join_mess = df_mess.join(
    df_material_seleted, ["material_number", "plant","planif_unit"], "left"
).join(df_plant_seleted, ["plant"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr 2 - Management Rescheduling date
# MAGIC - Need to substract GR receipt time in open days to Delivery date

# COMMAND ----------

# Limit Calendar to use for optimization process
# Filter TFACS with min_Value and Max Value
# -----------------------------------------------------------------------
min_dte = (
    df_mess.select(f.col("Rescheduling_Date"))
    .agg({"Rescheduling_Date": "min"})
    .collect()[0][0]
)
min_dte = min_dte - datetime.timedelta(days=99)
# -----------------------------------------------------------------------
max_dte = (
    df_mess.select(f.col("Rescheduling_Date"))
    .agg({"Rescheduling_Date": "max"})
    .collect()[0][0]
)
# -----------------------------------------------------------------------
df_cal = df_cal.filter(
    (f.col("DateString") > min_dte) & (f.col("DateString") <= max_dte)
)
# -----------------------------------------------------------------------

# COMMAND ----------

# Add UID Column to Input Dataframe - UID is arbitarty but must be unique per row in the input file.
df_cal2 = (
    df_cal.select("Country_Code", "WorkingDay", "DateString")
    .withColumnRenamed("Country_Code", "Country_Code_")
    .withColumnRenamed("WorkingDay", "WorkingDay_")
    .withColumnRenamed("DateString", "DateString_")
)
df_cal_join = df_cal.join(
    df_cal2,
    (df_cal.Country_Code == df_cal2.Country_Code_)
    & (df_cal.DateString >= df_cal2.DateString_),
    how="left",
)
# Order by Unique ID from InputValues
w = (
    Window()
    .partitionBy("Country_Code", "DateString")
    .orderBy(f.col("DateString_").desc())
)  
df_cal_join_calc = df_cal_join.withColumn("summ", f.sum("WorkingDay_").over(w))
#  Minus 1 to not take in account actual day
df_cal_join_calc = df_cal_join_calc.withColumn(
    "summ", f.col("summ") - 1
)  
# Exclusion of non working day
df_cal_join_calc = df_cal_join_calc.filter(
    f.col("WorkingDay_") != 0
)  
# -----------------------------------------------------------------------
df_final = df_join_mess.join(
    df_cal_join_calc,
    (df_join_mess.rescheduling_date == df_cal_join_calc.DateString)
    & (df_join_mess.Id_Calendar == df_cal_join_calc.Country_Code)
    & (df_join_mess.GR_processing_time == df_cal_join_calc.summ),
    how="left",
)
# -----------------------------------------------------------------------
# Cleaning Data Asset before saving
df_final = df_final.withColumn(
    "plant_description", f.col("Plant_Description_new")
).drop(
    "Plant_Supplier",
    "Plant_Customer",
    "Plant_",
    "Customers_Orga",
    "Currency",
    "Country_Code_",
    "DateString",
    "Day",
    "WorkingDay",
    "Year",
    "Month",
    "WorkingDay_",
    "summ",
    "Country",
    "Id_Calendar",
    "Plant_Description_new",
    "rescheduling_date",
)
df_final = df_final.withColumnRenamed("DateString_", "rescheduling_date")
# -----------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# NA

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold Exception Message

# COMMAND ----------

# Technical Debt => Fonction lowerCase before complete refacto of data asset
df_final = df_final.toDF(*[c.lower() for c in df_final.columns])

# COMMAND ----------

df_message_path = f"{PIPELINE_WRITE_ENV}_gold.mrp.exception_message"
table_utils.save_table(dest_table=df_message_path, df=df_final, mode="overwrite")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold Exception Message Exposed

# COMMAND ----------

dest_full_tablename = f"{PIPELINE_WRITE_ENV}_gold.mrp.exception_message_exposed"
src_full_tablename = f"{PIPELINE_WRITE_ENV}_gold.mrp.exception_message"
# -------------------------------------------------------------------------------
Begin_By = "mdtb"
Begin_By2 = "mdkp"
selected_columns = [
    col
    for col in df_final.columns
    if not col.startswith(Begin_By) and not col.startswith(Begin_By2)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
