# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook mimecast data_asset silver
# MAGIC #  Purpose
# MAGIC
# MAGIC  **Description:**
# MAGIC  The aim is to create a silver table for mimecast awareness data asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{pipeline_read_env}_bronze.mimecast_ingestion.insights_userperformance_latest`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `"sd_{pipeline_read_env}_bronze.hr.v_report_rh_leap_latest"`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `sd_{pipeline_write_env}_silver.it_security.insights_userperformance`


# COMMAND ----------

# MAGIC %md
# MAGIC # Change Log
# MAGIC  05/11/2025:
# MAGIC  - Notebook creation by Patrice PUNTIS
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Packages load

# COMMAND ----------

import time
import logging
from pyspark.sql import functions as f

# leap table utils
from leap_utils.data_asset import table_utils

# leap logger
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC # Widget setup

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("bypass_quality_checks", "false")  # history/update
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC #Log_level setup
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

TABLE_INSIGHTS_LATEST = (
    f"sd_{PIPELINE_READ_ENV}_bronze.mimecast_ingestion.insights_userperformance_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_CATALOG = f"sd_{PIPELINE_WRITE_ENV}_silver"
SILVER_SCHEMA = "it_security"

GOVERNANCE_CATALOG = f"{PIPELINE_WRITE_ENV}_governance"
GOVERNANCE_SCHEMA = "it_security"

TABLE_INSIGHTS_SILVER = "insights_userperformance"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"TABLE_INSIGHTS_SILVER is:  {TABLE_INSIGHTS_SILVER}")

# COMMAND ----------

# MAGIC %md
# MAGIC  #Functions
# MAGIC -

# COMMAND ----------


# N/A


# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Input Tables
# MAGIC
# MAGIC

# COMMAND ----------

# Upload insights bronze latest
df_bronze_insights_userperformance = spark.read.table(f"{TABLE_INSIGHTS_LATEST}")


# COMMAND ----------


# MAGIC %md
# MAGIC #Preparation 1 - Cleansing bronze data
# MAGIC
# MAGIC

# COMMAND ----------

df_bronze_insights_userperformance_cast = (
    (
        df_bronze_insights_userperformance.withColumn("name", f.trim(f.col("name")))
        .withColumn("email", f.trim(f.col("email")))
        .withColumn("department", f.trim(f.col("department")))
        .withColumn("training_title", f.trim(f.col("training_title")))
        .withColumn("training_category", f.trim(f.col("training_category")))
        .withColumn(
            "date_sent_clean",
            f.translate(f.col("date_sent"), "éèêàâûùçôáí", "eeeaaauucoi"),
        )
        .withColumn(
            "date_viewed_clean",
            f.translate(f.col("date_viewed"), "éèêàâûùçôáí", "eeeaaauucoi"),
        )
        .withColumn(
            "date_sent",
            f.to_timestamp(f.trim(f.col("date_sent_clean")), "yyyy-MM-dd HH:mm:ss.SSS"),
        )
        .withColumn(
            "date_viewed",
            f.to_timestamp(
                f.trim(f.col("date_viewed_clean")), "yyyy-MM-dd HH:mm:ss.SSS"
            ),
        )
    )
    .filter(f.col("_meta_validity_check") == True)
    .drop(
        "_rescued_data",
        "_meta_validity_check",
        "date_sent_clean",
        "date_viewed_clean",
        "department",
    )
)


# COMMAND ----------

# MAGIC %md
# MAGIC # Creating primary key for this dataset on _meta_id


# COMMAND ----------

# MAGIC %md
# MAGIC ### Check if pk contains nulls

# COMMAND ----------

df_to_check = df_bronze_insights_userperformance_cast
col_to_check = "_meta_id"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

quality_check_results = [df_gx.expect_column_values_to_not_be_null(column=col_to_check)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"No null values found in {col_to_check}",
    error_message=f"Null values found in {col_to_check}, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name=TABLE_INSIGHTS_SILVER,
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###  Check if pk is unique

# COMMAND ----------

df_to_check = df_bronze_insights_userperformance_cast
col_pk = "_meta_id"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

quality_check_results = [df_gx.expect_column_values_to_be_unique(column=col_pk)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique",
    error_message=f"{col_pk}(s) are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name=TABLE_INSIGHTS_SILVER,
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Silver table

# COMMAND ----------

CATALOG = SILVER_CATALOG
SCHEMA = SILVER_SCHEMA
DESTINATION_TABLE = TABLE_INSIGHTS_SILVER
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{TABLE_INSIGHTS_SILVER}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_bronze_insights_userperformance_cast,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_bronze_insights_userperformance_cast.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "silver_insights_userperformance_pk"
TABLE_PK_COLS = "_meta_id"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding PII tags

# COMMAND ----------

# Ajout du tag "class.email_address" sur la colonne _meta_id
spark.sql(
    f"""
ALTER TABLE {DESTINATION_TABLE_FULL_PATH}
ALTER COLUMN _meta_id
SET TAGS ('class.email_address');
"""
).display()

# Ajout du tag "class.email_address" sur la colonne email
spark.sql(
    f"""
ALTER TABLE {DESTINATION_TABLE_FULL_PATH}
ALTER COLUMN email
SET TAGS ('class.email_address');
"""
).display()

# Ajout du tag "class.name" sur la colonne name
spark.sql(
    f"""
ALTER TABLE {DESTINATION_TABLE_FULL_PATH}
ALTER COLUMN name
SET TAGS ('class.name');
"""
).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding PII masking functions

# COMMAND ----------

spark.sql(
    f"""
create schema if not exists {GOVERNANCE_CATALOG}.{GOVERNANCE_SCHEMA};
"""
).display()

spark.sql(
    f"""
CREATE OR REPLACE FUNCTION {GOVERNANCE_CATALOG}.{GOVERNANCE_SCHEMA}.fn_it_mask_name(name STRING)
RETURNS STRING
DETERMINISTIC
RETURN CASE
  WHEN name IS NULL THEN NULL
  WHEN LENGTH(name) >= 4 THEN CONCAT('XXX-XX-', RIGHT(name, 4))
  ELSE 'MASKED'
END;
"""
).display()

spark.sql(
    f"""
CREATE OR REPLACE FUNCTION {GOVERNANCE_CATALOG}.{GOVERNANCE_SCHEMA}.fn_it_mask_email_address(email STRING)
RETURNS STRING
DETERMINISTIC
RETURN
  CASE
    WHEN email IS NULL THEN NULL
    WHEN POSITION('@' IN email) = 0 THEN 'INVALID_EMAIL'
    ELSE
      -- split the email
      CONCAT(
        LEFT(SPLIT(email, '@')[0], 1),                           -- 1ère lettre avant le @
        'XXX',                                                   -- masque central
        RIGHT(SPLIT(email, '@')[0], 1),                          -- dernière lettre avant le @
        '@',
        SPLIT(email, '@')[1]                                     -- domaine complet visible
      )
  END;
"""
).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding PII policies

# COMMAND ----------

spark.sql(
    f"""
CREATE OR REPLACE POLICY `abac_cm_it_name`
ON SCHEMA {CATALOG}.{SCHEMA}
COMMENT 'column masking on columns tagged 
class.name'
COLUMN MASK {GOVERNANCE_CATALOG}.{GOVERNANCE_SCHEMA}.fn_it_mask_name
TO `account users`
EXCEPT `leap-core-service_accounts-sd-dev`,`leap-core-service_accounts-sd-uat`,`leap-core-service_accounts-sd-prod`, `Role-Project-LEAP-Product-Owner-IT-Ciso`, `patrice.puntis@latecoere.aero`
FOR TABLES
MATCH COLUMNS hasTag('class.name') AS m
ON COLUMN m
"""
).display()

spark.sql(
    f"""
CREATE OR REPLACE POLICY `abac_cm_it_email_address`
ON SCHEMA {CATALOG}.{SCHEMA}
COMMENT 'column masking on columns tagged 
class.email_address'
COLUMN MASK {GOVERNANCE_CATALOG}.{GOVERNANCE_SCHEMA}.fn_it_mask_email_address
TO `account users`
EXCEPT `leap-core-service_accounts-sd-dev`,`leap-core-service_accounts-sd-uat`,`leap-core-service_accounts-sd-prod`, `Role-Project-LEAP-Product-Owner-IT-Ciso`, `patrice.puntis@latecoere.aero`
FOR TABLES
MATCH COLUMNS hasTag('class.email_address') AS m
ON COLUMN m
"""
).display()
