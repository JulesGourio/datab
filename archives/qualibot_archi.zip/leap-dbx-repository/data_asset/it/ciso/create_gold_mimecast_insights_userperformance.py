# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook mimecast data_asset gold
# MAGIC #  Purpose
# MAGIC
# MAGIC  **Description:**
# MAGIC  The aim is to create a gold table and gold exposed views for mimecast awareness data asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `sd_{PIPELINE_READ_ENV}_silver.it_security.insights_userperformance`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `"sd_{REFERENCE_READ_ENV}_bronze.hr.v_report_rh_leap_latest"`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `sd_{pipeline_write_env}_gold.it_security.insights_userperformance`

# COMMAND ----------

# MAGIC %md
# MAGIC # Change Log
# MAGIC  05/11/2025:
# MAGIC  - Notebook creation by Patrice PUNTIS
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Packages load

# COMMAND ----------

import time
import logging
from pyspark.sql import functions as f

# leap table utils
from leap_utils.data_asset import table_utils

# leap logger
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC # Widget setup

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("bypass_quality_checks", "false")  # history/update
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC #Log_level setup
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

TABLE_INSIGHTS_SILVER = (
    f"sd_{PIPELINE_READ_ENV}_silver.it_security.insights_userperformance"
)
TABLE_IMMAT_LATEST = f"sd_{REFERENCE_READ_ENV}_bronze.hr.v_report_rh_leap_latest"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

GOLD_CATALOG = f"sd_{PIPELINE_WRITE_ENV}_gold"
GOLD_SCHEMA = "it_security"

GOVERNANCE_CATALOG = f"{PIPELINE_WRITE_ENV}_governance"
GOVERNANCE_SCHEMA = "it_security"

TABLE_INSIGHTS_GOLD = "insights_userperformance"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"GOLD_SCHEMA is:  {GOLD_SCHEMA}")
log.info(f"TABLE_INSIGHTS_SILVER is:  {TABLE_INSIGHTS_SILVER}")
log.info(f"TABLE_INSIGHTS_GOLD is:  {TABLE_INSIGHTS_GOLD}")

# COMMAND ----------

# MAGIC %md
# MAGIC  #Functions
# MAGIC -

# COMMAND ----------


# N/A


# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Input Tables
# MAGIC
# MAGIC

# COMMAND ----------

# Upload insights silver
df_silver_insights_userperformance = spark.read.table(TABLE_INSIGHTS_SILVER)

# Upload immat latest silver
df_immat_latest = spark.read.table(TABLE_IMMAT_LATEST).select(
    f.col("Email").alias("email"),
    f.col("User_ID").alias("user_id"),
    f.col("ID_Manager").alias("user_id_manager"),
    f.col("First_name"),
    f.col("Last_name"),
    f.col("Status"),
    f.col("Company"),
    f.col("Company_Code"),
    f.col("Workplace_country"),
    f.col("Workplace"),
    f.col("Organization"),
    f.col("Department"),
    f.col("Service"),
    f.col("Category"),
)

# COMMAND ----------


# MAGIC %md
# MAGIC #Preparation 1 - Clean immat
# MAGIC
# MAGIC

# COMMAND ----------

df_immat_lower = df_immat_latest.toDF(*[c.lower() for c in df_immat_latest.columns])

# COMMAND ----------


# MAGIC %md
# MAGIC #Transformation 1 - Join silver with immat for enrichment
# MAGIC
# MAGIC

# COMMAND ----------

df_insights_immat = df_silver_insights_userperformance.join(
    df_immat_lower, on="email", how="left"
)

# COMMAND ----------


# MAGIC %md
# MAGIC #Transformation 2 - Join silver with immat for getting manager attributes
# MAGIC
# MAGIC

# COMMAND ----------

df_immat_manager = df_immat_lower.select(
    f.col("email").alias("email_manager"), f.col("user_id").alias("user_id_manager")
)

df_insights_manager = df_insights_immat.join(
    df_immat_manager, on="user_id_manager", how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Transformation 3 - reorder columns
# MAGIC
# MAGIC

# COMMAND ----------

metadatas_cols = [
    "_meta_id",
    "_meta_extraction_timestamp",
    "_meta_ingestion_timestamp",
    "_meta_file_name",
    "_meta_file_mode",
    "_meta_file_path",
]

# Get non metadata columns
data_cols = [col for col in df_insights_manager.columns if col not in metadatas_cols]

# try Reordering columns
try:
    df_reordered = df_insights_manager.select(*(metadatas_cols + data_cols))
    cols = [c for c in df_reordered.columns if c != "user_id_manager"] + [
        "user_id_manager"
    ]
    df_insights_gold = df_reordered.select(*cols)
except:
    df_insights_gold = df_insights_manager

# COMMAND ----------

# MAGIC %md
# MAGIC # Creating primary key for this dataset on _meta_id


# COMMAND ----------

# MAGIC %md
# MAGIC ### Check if pk contains nulls

# COMMAND ----------

df_to_check = df_insights_gold
col_to_check = "_meta_id"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

quality_check_results = [df_gx.expect_column_values_to_not_be_null(column=col_to_check)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"No null values found in {col_to_check}",
    error_message=f"Null values found in {col_to_check}, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name=TABLE_INSIGHTS_GOLD,
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###  Check if pk is unique

# COMMAND ----------

df_to_check = df_insights_gold
col_pk = "_meta_id"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

quality_check_results = [df_gx.expect_column_values_to_be_unique(column=col_pk)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique",
    error_message=f"{col_pk}(s) are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name=TABLE_INSIGHTS_GOLD,
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

CATALOG = GOLD_CATALOG
SCHEMA = GOLD_SCHEMA
DESTINATION_TABLE = TABLE_INSIGHTS_GOLD
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{TABLE_INSIGHTS_GOLD}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_insights_gold,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_insights_gold.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_insights_userperformance_pk"
TABLE_PK_COLS = "_meta_id"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding PII tags

# COMMAND ----------

# Ajout du tag "class.email_address" sur la colonne _meta_id
spark.sql(
    f"""
ALTER TABLE {DESTINATION_TABLE_FULL_PATH}
ALTER COLUMN _meta_id
SET TAGS ('class.email_address');
"""
).display()

# Ajout du tag "class.email_address" sur la colonne email
spark.sql(
    f"""
ALTER TABLE {DESTINATION_TABLE_FULL_PATH}
ALTER COLUMN email
SET TAGS ('class.email_address');
"""
).display()

# Ajout du tag "class.email_address" sur la colonne email_manager
spark.sql(
    f"""
ALTER TABLE {DESTINATION_TABLE_FULL_PATH}
ALTER COLUMN email_manager
SET TAGS ('class.email_address');
"""
).display()

# Ajout du tag "class.name" sur la colonne name
spark.sql(
    f"""
ALTER TABLE {DESTINATION_TABLE_FULL_PATH}
ALTER COLUMN name
SET TAGS ('class.name');
"""
).display()

# Ajout du tag "class.name" sur la colonne first_name
spark.sql(
    f"""
ALTER TABLE {DESTINATION_TABLE_FULL_PATH}
ALTER COLUMN first_name
SET TAGS ('class.name');
"""
).display()

# Ajout du tag "class.name" sur la colonne last_name
spark.sql(
    f"""
ALTER TABLE {DESTINATION_TABLE_FULL_PATH}
ALTER COLUMN last_name
SET TAGS ('class.name');
"""
).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding PII masking functions

# COMMAND ----------

spark.sql(
    f"""
create schema if not exists {GOVERNANCE_CATALOG}.{GOVERNANCE_SCHEMA};
"""
).display()

spark.sql(
    f"""
CREATE OR REPLACE FUNCTION {GOVERNANCE_CATALOG}.{GOVERNANCE_SCHEMA}.fn_it_mask_name(name STRING)
RETURNS STRING
DETERMINISTIC
RETURN CASE
  WHEN name IS NULL THEN NULL
  WHEN LENGTH(name) >= 4 THEN CONCAT('XXX-XX-', RIGHT(name, 4))
  ELSE 'MASKED'
END;
"""
).display()

spark.sql(
    f"""
CREATE OR REPLACE FUNCTION {GOVERNANCE_CATALOG}.{GOVERNANCE_SCHEMA}.fn_it_mask_email_address(email STRING)
RETURNS STRING
DETERMINISTIC
RETURN
  CASE
    WHEN email IS NULL THEN NULL
    WHEN POSITION('@' IN email) = 0 THEN 'INVALID_EMAIL'
    ELSE
      -- split the email
      CONCAT(
        LEFT(SPLIT(email, '@')[0], 1),                           -- 1ère lettre avant le @
        'XXX',                                                   -- masque central
        RIGHT(SPLIT(email, '@')[0], 1),                          -- dernière lettre avant le @
        '@',
        SPLIT(email, '@')[1]                                     -- domaine complet visible
      )
  END;
"""
).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding PII policies

# COMMAND ----------

spark.sql(
    f"""
CREATE OR REPLACE POLICY `abac_cm_it_name`
ON SCHEMA {CATALOG}.{SCHEMA}
COMMENT 'column masking on columns tagged 
class.name'
COLUMN MASK {GOVERNANCE_CATALOG}.{GOVERNANCE_SCHEMA}.fn_it_mask_name
TO `account users`
EXCEPT `leap-core-service_accounts-sd-dev`,`leap-core-service_accounts-sd-uat`,`leap-core-service_accounts-sd-prod`, `Role-Project-LEAP-Product-Owner-IT-Ciso`, `patrice.puntis@latecoere.aero`
FOR TABLES
MATCH COLUMNS hasTag('class.name') AS m
ON COLUMN m
"""
).display()

spark.sql(
    f"""
CREATE OR REPLACE POLICY `abac_cm_it_email_address`
ON SCHEMA {CATALOG}.{SCHEMA}
COMMENT 'column masking on columns tagged 
class.email_address'
COLUMN MASK {GOVERNANCE_CATALOG}.{GOVERNANCE_SCHEMA}.fn_it_mask_email_address
TO `account users`
EXCEPT `leap-core-service_accounts-sd-dev`,`leap-core-service_accounts-sd-uat`,`leap-core-service_accounts-sd-prod`, `Role-Project-LEAP-Product-Owner-IT-Ciso`, `patrice.puntis@latecoere.aero`
FOR TABLES
MATCH COLUMNS hasTag('class.email_address') AS m
ON COLUMN m
"""
).display()
