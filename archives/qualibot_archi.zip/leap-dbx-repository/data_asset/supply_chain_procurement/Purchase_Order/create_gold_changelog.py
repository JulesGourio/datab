# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # POs changelog gold data asset 
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table for purchase orders changelog based on silver po changelog.
# MAGIC
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {pipeline_write_env}_gold.supply_chain_procurement.purchase_orders_history_change_log
# MAGIC
# MAGIC **Input :**  
# MAGIC   - {pipeline_read_env}_silver.supply_chain_procurement.purchase_orders_history_change_log
# MAGIC   - {reference_read_env}_gold.supply_chain.supplier_master_data_latest_exposed
# MAGIC   - {reference_read_env}_gold.finance.wbs_otp"
# MAGIC   - {reference_read_env}_bronze.ap_latecoere_ecc6.ekbe_latest
# MAGIC   - {reference_read_env}_bronze.headers_sap.headers_sap_business_ekbe
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC   Notebook -> create_silver_changelog
# MAGIC
# MAGIC **Things to do:** 
# MAGIC Some major refactoring to do later 

# COMMAND ----------

from pyspark.sql import DataFrame, functions as f
from pyspark.sql.window import Window

## Import LEAP Utils
from leap_utils.data_asset import table_utils 

# Widgets
dbutils.widgets.removeAll()
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "false")
DEBUG = (dbutils.widgets.get("debug").capitalize() == "True")

# Global Params
HISTORY_DOMAIN = "sap_latecoere_ecc6"
OUTPUT_TABLE_PATH = f"{PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.purchase_orders_history_change_log"
INPUT_TABLE_PATH = f"{PIPELINE_READ_ENV}_silver.supply_chain_procurement.purchase_orders_history_change_log"
TESTING_EXTRACTION_DATE = "2024-02-10"

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# for testing purposes
def filter_dataframe_on_date(df: DataFrame, extraction_date: str) -> DataFrame:
    """
    Extracts the validity dates from the DataFrame change log history.
    It assumes one interval is available

    Args:
    - df (DataFrame): The DataFrame containing the change log history.
    - extraction_date (str): The date to extract versions for.

    Returns:
    - DataFrame: Filtered DataFrame with valid version entries for the given extraction date.
    """
    start_columns = [col for col in df.columns if "start_validity" in col.lower()]
    end_columns = [col for col in df.columns if "end_validity" in col.lower()]
    df = df.withColumn("join_start_validity", f.col(start_columns[0]))
    df = df.withColumn("join_end_validity", f.col(end_columns[0]))

    return df.filter(
        (
            (f.col("join_end_validity") > extraction_date)
            & (f.col("join_start_validity") <= extraction_date)
        )
    )

# COMMAND ----------

# MAGIC %md
# MAGIC #Processing

# COMMAND ----------

# MAGIC %md - Upload Table from PO & Supplier Master Data

# COMMAND ----------

# Silver Purchase Order
df_silver_po = spark.read.table(INPUT_TABLE_PATH)

# Gold_Supplier: Supplier Master Data
df_Supplier = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed"
)
# WBS: WBS Master Data
df_prps = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.wbs_otp")

# History per Purchasing Document
df_ekbe = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.{HISTORY_DOMAIN}.ekbe_latest")
# ekbe business header
df_name_ekbe = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekbe"
)

# COMMAND ----------

if DEBUG:
    assert (
        filter_dataframe_on_date(df_silver_po, TESTING_EXTRACTION_DATE).count() == 6405687
    )

# COMMAND ----------

# MAGIC %md - Join Table PO / Supplier_Master / Company_Master / WBS

# COMMAND ----------

# Join PO / Supplier_Master / Company_Master / WBS
df_join_po = (
    df_silver_po.alias("A")
    .join(
        df_Supplier.alias("B"),
        (f.col("A.Supplier_Code") == f.col("B.Supplier_Code"))
        & (f.col("A.Company_Code") == f.col("B.Company_Code"))
        & (f.col("A.Purchase_Org") == f.col("B.Purch_Organization")),
        "left",
    )
    .join(
        df_prps.alias("C"), (f.col("A.WBS_Element") == f.col("C.WBS_Code_Num")), "left"
    )
    .select(
        f.col("A.*"),
        f.col("B.Supplier_name"),
        f.col("B.Supplier_Category"),
        f.col("B.Payment_Term").alias("Supplier_Payment_Term"),
        f.col("B.Intercompany_flow"),
        f.col("B.Spend_category"),
        f.col("B.Supplier_country"),
        f.col("B.Supplier_city"),
        f.col("C.WBS_Code").alias("WBS"),
    )
    .drop("WBS_Element")
)

# COMMAND ----------

# MAGIC %md - PO Gold enrichments 

# COMMAND ----------

# MAGIC %md
# MAGIC - Cast quantities

# COMMAND ----------

# Cast string colonne Quantity (TODO corrrect error in header )
df_po_ec = df_join_po.withColumn(
    "Scheduled_Quantity", f.col("Scheduled_Quantity").cast("double")
)

# COMMAND ----------

# MAGIC %md - Apply extra filters :  Exclusion Return PO & Bad entries

# COMMAND ----------

df_po_ec = df_po_ec.filter(f.col("EKKO_memorytype").isNull() == True)
df_po_ec = df_po_ec.filter(f.col("Quantity_Planned") != 0)
df_po_ec = df_po_ec.filter(
    (f.col("Return_Item") != "X") | (f.col("Return_Item").isNull())
)

# COMMAND ----------

# MAGIC %md
# MAGIC - Create new enrichements

# COMMAND ----------

# Incoterm Managment - First comming from item(EKPO) then from Header (EKKO)
df_po_ec = (
    df_po_ec.withColumn(
        "Incoterm_Code",
        f.when(f.col("Incoterm1_ekpo").isNull(), f.col("Incoterm_Code")).otherwise(
            f.col("Incoterm1_ekpo")
        ),
    )
    .withColumn(
        "Incoterm_Detail",
        f.when(f.col("Incoterm2_ekpo").isNull(), f.col("Incoterm_Detail")).otherwise(
            f.col("Incoterm2_ekpo")
        ),
    )
    .drop("Incoterm1_ekpo", "Incoterm2_ekpo")
)


## Calcul Remaining qty & value

# Add Qty remaining not include in SAP
df_po_ec = df_po_ec.withColumn(
    "Qty_Remaining",
    f.when(f.col("Final_Delivery") == "X", 0)
    .otherwise(f.col("Quantity_Planned") - f.col("Quantity_Delivered"))
    .cast("double"),
)
#  Add Unit Value not include in SAP Table
df_po_ec = df_po_ec.withColumn(
    "Unit_Price", f.col("Global_Price") / f.col("Quantity_Ordered")
)
# Add remaining Value not include in SAP Table
df_po_ec = df_po_ec.withColumn(
    "Remaining_Value",
    (f.col("Qty_Remaining") * f.col("Unit_Price")),
)

# Treatement Empty Field
df_po_ec = df_po_ec.withColumn(
    "Unit_Of_Measure_PO",
    f.when(f.col("Unit_Of_Measure_PO").isNull() == True, f.lit("U")).otherwise(
        f.col("Unit_Of_Measure_PO")
    ),
).withColumn(
    "Unit_Of_Measure_Supplier",
    f.when(f.col("Unit_Of_Measure_Supplier").isNull() == True, f.lit("U")).otherwise(
        f.col("Unit_Of_Measure_Supplier")
    ),
)

df_po_ec = df_po_ec.withColumn(
    "Down_Payment_percentage",
    f.when(f.col("Down_Payment_percentage").isNull() == True, f.lit(0)).otherwise(
        f.col("Down_Payment_percentage")
    ),
)
# ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  Translation of SAP Field
df_po_ec = df_po_ec.withColumn(
    "PO_Input_Type",
    f.when(f.col("PO_Origin") == "9", f.lit("Manual_Input")).otherwise(
        f.lit("System_Input")
    ),
)
df_po_ec = df_po_ec.withColumn(
    "Deletion_Mark",
    f.when(f.col("Deletion_Mark") == "L", f.lit("Deleted"))
    .when(f.col("Deletion_Mark") == "S", f.lit("Locked"))
    .otherwise(f.col("Deletion_Mark")),
)

# ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Determination of PO Blocked & Cancelled
df_po_ec = df_po_ec.withColumn(
    "PO_Status",
    f.when(
        (f.col("Deletion_Mark") == "Deleted") | (f.col("Deletion_Mark") == "Locked"),
        f.lit("PO_Cancelled"),
    ).otherwise(f.lit("TBD")),
)
# Determination of PO invoiced according Final Invoicing
df_po_ec = df_po_ec.withColumn(
    "PO_Status",
    f.when((f.col("PO_Status") != "TBD"), f.col("PO_Status"))
    .when(f.col("Associated_Invoice") == "X", f.lit("PO_Invoiced"))
    .otherwise(f.lit("TBD")),
)
# Determination of PO in progress
df_po_ec = df_po_ec.withColumn(
    "PO_Status",
    f.when((f.col("PO_Status") != "TBD"), f.col("PO_Status"))
    .when(f.col("Qty_Remaining") != 0, f.lit("PO_In_Progress"))
    .otherwise(f.lit("TBD")),
)
# Entrusted parts Managment (Invoices not expected)
df_po_ec = df_po_ec.withColumn(
    "PO_Status",
    f.when((f.col("PO_Status") != "TBD"), f.col("PO_Status"))
    .when(
        (f.col("Qty_Remaining") == 0) & (f.col("Net_price") == 0), f.lit("PO_Invoiced")
    )
    .otherwise(f.lit("TBD")),
)
# Interdiv Purchase Order
cde = ["UB", "ZUB"]
df_po_ec = df_po_ec.withColumn(
    "PO_Status",
    f.when((f.col("PO_Status") != "TBD"), f.col("PO_Status"))
    .when(
        (f.col("Qty_Remaining") == 0) & (f.col("PO_Type").isin(cde)),
        f.lit("PO_Invoiced"),
    )
    .otherwise(f.lit("TBD")),
)

# COMMAND ----------

if DEBUG:
    assert filter_dataframe_on_date(df_po_ec, TESTING_EXTRACTION_DATE).count() == 6386957

# COMMAND ----------

# MAGIC %md - Determination of PO status according EKBE Table (Historic - BEM - Invoice)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Prepare EKBE

# COMMAND ----------

# Renaming starting with EKBE_
df_ekbe = table_utils.add_prefix_to_columns(df_ekbe, "EKBE")
# Call function Check Header files
table_utils.check_schema_of_the_header_file(df_name_ekbe)
# Call Function Delete rows null
df_name_ekbe = delete_null_rows(df_name_ekbe)
# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(df_ekbe, df_name_ekbe)
# Call Funtion Create Columns on Date format
df = table_utils.cast_columns_with_sap_business_headers(df_column_names, df_name_ekbe)

# COMMAND ----------

# MAGIC %md
# MAGIC #### EKBE / PO Selection and cleaning

# COMMAND ----------

# EKBE Cleaning and Select
df_ekbe_temp = df.select(
    "Purchase_Doc",
    "Purchase_Item",
    "Operation_Type",
    "Debit_Credit",
    "Quantity",
    "Posting_Date",
    "EKBE_lfgja",
    "EKBE_lfbnr",
    "EKBE_lfpos",
)
df_ekbe_temp = df_ekbe_temp.withColumn("Quantity", f.col("Quantity").cast("double"))
df_ekbe_temp = df_ekbe_temp.withColumn(
    "Posting_Date", f.to_date(f.col("Posting_Date"), "yyyyMMdd")
)
df_ekbe_temp = df_ekbe_temp.where(f.col("Operation_Type").isin("1", "2"))
df_ekbe_temp = df_ekbe_temp.withColumn(
    "New_Operation_Type",
    f.when(f.col("Operation_Type") == 2, 2).otherwise(f.col("Operation_Type")),
)
df_ekbe_temp = df_ekbe_temp.cache()

# ---------------------------------------------------------------------------------------------------------------------------------------------------------
# PO_Order select
df_po_temp = df_po_ec.where(f.col("Deletion_Mark").isNull())  # Remove deleted PO
df_po_temp = df_po_temp.select(
    "PO_Number", "PO_Item_Number", "Delivery_Date_Planned", "Qty_Remaining"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1 : Remove EKBE from deleted PO
# MAGIC

# COMMAND ----------

po_for_filtering_df = df_po_temp.select("PO_Number", "PO_Item_Number")
step_1_df = df_ekbe_temp.join(
    po_for_filtering_df,
    (df_ekbe_temp["Purchase_Doc"] == po_for_filtering_df["PO_Number"])
    & (df_ekbe_temp["Purchase_Item"] == po_for_filtering_df["PO_Item_Number"]),
    "inner",
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2 : Remove Cancelled rows and associated entry rows

# COMMAND ----------

# Explanations on the choice of ordering or not the window : https://stackoverflow.com/questions/63951725/get-the-max-value-over-the-window-in-pyspark
window_1 = Window.partitionBy(
    "Purchase_Doc", "Purchase_Item", "New_Operation_Type", "Quantity"
)
window_2 = Window.partitionBy(
    "Purchase_Doc",
    "Purchase_Item",
    "New_Operation_Type",
    "Quantity",
    "Debit_Credit",
).orderBy("Posting_Date")

window_3 = Window.partitionBy("Purchase_Doc", "Purchase_Item", "New_Operation_Type")
window_4 = (
    Window.partitionBy(
        "Purchase_Doc", "Purchase_Item", "New_Operation_Type", "Debit_Credit"
    )
    .orderBy("Posting_Date")
    .rowsBetween(Window.unboundedPreceding, 0)
)

# First window is to calculate the number of canceled row per document_id ("EKBE_lfgja", "EKBE_lfbnr", "EKBE_lfpos")
step_2_df = step_1_df.withColumn(
    "Nb_H_per_key", f.count(f.when(f.col("Debit_Credit") == "H", 1)).over(window_1)
)
step_2_df = step_2_df.withColumn(
    "Nb_H_per_key", f.max(f.col("Nb_H_per_key")).over(window_1)
)

step_2_df = step_2_df.withColumn(
    "Nb_S_per_key", f.count(f.when(f.col("Debit_Credit") == "S", 1)).over(window_1)
)
step_2_df = step_2_df.withColumn(
    "Nb_S_per_key", f.max(f.col("Nb_S_per_key")).over(window_1)
)

# Second window is for ordering and adding an ordered row number depending the date
step_2_df = step_2_df.withColumn("Row_Number", f.row_number().over(window_2))

# Keep only Entries that have not been canceled
# Entries to keep are those that have a row number strictly greater than the number of total canceled row
step_2_df = step_2_df.where(
    ((f.col("Debit_Credit") == "S") & (f.col("Row_Number") > f.col("Nb_H_per_key")))
    | ((f.col("Debit_Credit") == "H") & (f.col("Nb_S_per_key") == 0))
)

# First window is to calculate the number of canceled row per document_id ("EKBE_lfgja", "EKBE_lfbnr", "EKBE_lfpos")
step_2_df = step_2_df.withColumn(
    "Total_Quantity_H_per_key_2",
    f.sum(f.when(f.col("Debit_Credit") == "H", f.col("Quantity"))).over(window_3),
)
step_2_df = step_2_df.withColumn(
    "Cumulative_Quantity_Per_Operation_Type_2", f.sum("Quantity").over(window_4)
)
step_2_df = step_2_df.withColumn(
    "Quantity_Remaining_S",
    f.when(
        f.col("Cumulative_Quantity_Per_Operation_Type_2")
        <= f.col("Total_Quantity_H_per_key_2"),
        0,
    ).otherwise(
        f.when(
            (
                f.col("Cumulative_Quantity_Per_Operation_Type_2")
                - f.col("Total_Quantity_H_per_key_2")
            )
            < f.col("Quantity"),
            f.col("Cumulative_Quantity_Per_Operation_Type_2")
            - f.col("Total_Quantity_H_per_key_2"),
        ).otherwise(f.col("Quantity"))
    ),
)


step_2_df = step_2_df.where(
    (f.col("Debit_Credit") == "S") & (f.col("Quantity_Remaining_S") != 0)
)
step_2_df = step_2_df.withColumn("Quantity", f.col("Quantity_Remaining_S"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3 : Adjust GRs quantity
# MAGIC 1. Retrieve how many are in invoices statut
# MAGIC 2. Delete GRs that became Invoice
# MAGIC 3. Adjust GRs with quantity changed

# COMMAND ----------

# Use of unbounded preceding to get a cumulative sum depending on the window order : https://stackoverflow.com/questions/45946349/python-spark-cumulative-sum-by-group-using-dataframe
window_1 = (
    Window()
    .partitionBy(
        "Purchase_Doc",
        "Purchase_Item",
        "New_Operation_Type",
        "EKBE_lfgja",
        "EKBE_lfbnr",
        "EKBE_lfpos",
    )
    .orderBy("Posting_Date")
    .rowsBetween(Window.unboundedPreceding, 0)
)
window_2 = Window().partitionBy(
    "Purchase_Doc", "Purchase_Item", "EKBE_lfgja", "EKBE_lfbnr", "EKBE_lfpos"
)
# Use of unbounded preceding to get a cumulative sum depending on the window order : https://stackoverflow.com/questions/45946349/python-spark-cumulative-sum-by-group-using-dataframe
window_3 = (
    Window()
    .partitionBy("Purchase_Doc", "Purchase_Item", "New_Operation_Type")
    .orderBy("Posting_Date")
    .rowsBetween(Window.unboundedPreceding, 0)
)
window_4 = Window().partitionBy("Purchase_Doc", "Purchase_Item")

# Delete GR that became Invoice
# 1. Calculate the cumulative sum quantity per operation type in an ordered way (from oldest to newest)
# 2. Calculate the total quantity of Invoices and GR
# 3. Calculate the quantity of remaining GR:
#   - If cumulative quantity is less thant the total invoice then there are GR becomes an Invoice
#   - Else there are GR remaining (a specific case is handled when quantity of GR should be adjusted)
step_3_df = step_2_df.withColumn(
    "Cumulative_Quantity_Per_Operation_Type_1", f.sum("Quantity").over(window_1)
)
step_3_df = step_3_df.withColumn(
    "Total_Quantity_Invoices_1",
    f.max(
        f.when(
            f.col("New_Operation_Type") == 2,
            f.col("Cumulative_Quantity_Per_Operation_Type_1"),
        )
    ).over(window_2),
)
step_3_df = step_3_df.withColumn(
    "Total_Quantity_GR_1",
    f.max(
        f.when(
            f.col("New_Operation_Type") == 1,
            f.col("Cumulative_Quantity_Per_Operation_Type_1"),
        )
    ).over(window_2),
)
step_3_df = step_3_df.withColumn(
    "Quantity_Remaining_GR_1",
    f.when(
        f.col("Cumulative_Quantity_Per_Operation_Type_1")
        <= f.col("Total_Quantity_Invoices_1"),
        0,
    ).otherwise(
        f.when(
            (
                f.col("Cumulative_Quantity_Per_Operation_Type_1")
                - f.col("Total_Quantity_Invoices_1")
            )
            < f.col("Quantity"),
            f.col("Quantity") - f.col("Total_Quantity_Invoices_1"),
        ).otherwise(f.col("Quantity"))
    ),
)
step_3_df = step_3_df.withColumn(
    "Quantity_Remaining_INV_1",
    f.when(
        f.col("Cumulative_Quantity_Per_Operation_Type_1")
        <= f.col("Total_Quantity_GR_1"),
        0,
    ).otherwise(
        f.when(
            (
                f.col("Cumulative_Quantity_Per_Operation_Type_1")
                - f.col("Total_Quantity_GR_1")
            )
            < f.col("Quantity"),
            f.col("Cumulative_Quantity_Per_Operation_Type_1")
            - f.col("Total_Quantity_GR_1"),
        ).otherwise(f.col("Quantity"))
    ),
)

step_3_df = step_3_df.where(
    (f.col("New_Operation_Type") == 2) | (f.col("Quantity_Remaining_GR_1") != 0)
)
step_3_df = step_3_df.withColumn(
    "Quantity",
    f.when(
        f.col("New_Operation_Type") == 1, f.col("Quantity_Remaining_GR_1")
    ).otherwise(f.col("Quantity")),
)
step_3_df = step_3_df.withColumn("Quantity", f.round(f.col("Quantity"), 4))

step_3_df = step_3_df.withColumn(
    "Cumulative_Quantity_Per_Operation_Type_2", f.sum("Quantity").over(window_3)
)
step_3_df = step_3_df.withColumn(
    "Total_Quantity_Invoices_2",
    f.sum(
        f.when((f.col("New_Operation_Type") == 2), f.col("Quantity_Remaining_INV_1"))
    ).over(window_4),
)
step_3_df = step_3_df.withColumn(
    "Quantity_Remaining_GR_2",
    f.when(
        f.col("Cumulative_Quantity_Per_Operation_Type_2")
        <= f.col("Total_Quantity_Invoices_2"),
        0,
    ).otherwise(
        f.when(
            (
                f.col("Cumulative_Quantity_Per_Operation_Type_2")
                - f.col("Total_Quantity_Invoices_2")
            )
            < f.col("Quantity"),
            f.col("Cumulative_Quantity_Per_Operation_Type_2")
            - f.col("Total_Quantity_Invoices_2"),
        ).otherwise(f.col("Quantity"))
    ),
)
step_3_df = step_3_df.withColumn("Quantity", f.round(f.col("Quantity"), 4))

step_3_df = step_3_df.where(
    (f.col("New_Operation_Type") == 2) | (f.col("Quantity_Remaining_GR_2") != 0)
)
step_3_df = step_3_df.withColumn(
    "Quantity",
    f.when(
        f.col("New_Operation_Type") == 1, f.col("Quantity_Remaining_GR_2")
    ).otherwise(f.col("Quantity")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 4 : Append PO In progress and select columns for final table (drop columns created for calculations)

# COMMAND ----------

ekbe_final_df = step_3_df.select(
    "Purchase_Doc", "Purchase_Item", "New_Operation_Type", "Posting_Date", "Quantity"
)
ekbe_final_df = ekbe_final_df.withColumn(
    "Statut", f.when(f.col("New_Operation_Type") == 1, "GR").otherwise("INV")
).drop("New_Operation_Type")
ekbe_final_df = ekbe_final_df.withColumnRenamed("Posting_Date", "Date")

# COMMAND ----------

# MAGIC %md 
# MAGIC - Define Status of PO/GR

# COMMAND ----------

df_statut = ekbe_final_df.withColumn(
    "Inv", f.when(f.col("Statut") == "INV", (f.col("Quantity"))).otherwise(0)
)
df_statut = df_statut.withColumn(
    "GR", f.when(f.col("Statut") == "GR", (f.col("Quantity"))).otherwise(0)
)
df_statut = df_statut.groupBy("Purchase_Doc", "Purchase_Item").agg(
    f.sum("Inv").alias("sum_Inv"), f.sum("GR").alias("sum_GR")
)
df_statut = df_statut.withColumn(
    "klx",
    f.when((f.col("sum_GR") == 0) & (f.col("sum_Inv") > 0), (f.lit("PO_Invoiced")))
    .when((f.col("sum_GR") > 0) & (f.col("sum_Inv") >= 0), (f.lit("PO_Received")))
    .otherwise("TBD"),
)

df_join_Status = (
    df_po_ec.alias("A")
    .join(
        df_statut.alias("B"),
        (f.col("A.PO_Number") == f.col("B.Purchase_Doc"))
        & (f.col("A.PO_Item_Number") == f.col("B.Purchase_Item")),
        "left",
    )
    .select(
        f.col("A.*"),
        f.col("B.klx"),
    )
)
# Check If Invoice is done without GR
df_po_ec = df_join_Status.withColumn(
    "PO_Status",
    f.when(
        (f.col("PO_Status") == "PO_In_Progress")
        & (f.col("klx") == "PO_Invoiced")
        & (f.col("EKPO_webre").isNull() == True),
        f.lit("PO_Invoiced"),
    ).otherwise(f.col("PO_Status")),
)

df_po_ec = df_po_ec.withColumn(
    "PO_Status",
    f.when((f.col("PO_Status") != "TBD"), f.col("PO_Status"))
    .when(f.col("klx").isNotNull(), f.col("klx"))
    .otherwise(f.lit("TBD")),
)


df_po_ec = df_po_ec.withColumn(
    "PO_Status",
    f.when((f.col("PO_Status") != "TBD"), f.col("PO_Status"))
    .when(
        (f.col("Final_Delivery") == "X") & (f.col("Qty_Remaining") == 0),
        f.lit("PO_Cancelled"),
    )
    .otherwise(f.lit("TBD")),
)
df_po_ec = df_po_ec.drop("klx")


# Gestion Purchase Order Provider with Mensual Invoice not link on Purchase Order
# <- Provider SCAF F04641A // Provider PSD  F69631A // Provider AMI  F04171A // TW METALS F03423A
df_po_ec = df_po_ec.withColumn(
    "Provider",
    f.when(
        (f.col("Supplier_Code") == "F04641A")
        | (f.col("Supplier_Code") == "F69631A")
        | (f.col("Supplier_Code") == "F04171A")
        | (f.col("Supplier_Code") == "F03423A"),
        f.lit("Yes"),
    ).otherwise(f.lit("No")),
)
df_po_ec = df_po_ec.withColumn(
    "PO_Status",
    f.when(
        (f.col("Provider") == "Yes") & (f.col("PO_Status") == "PO_Received"),
        f.lit("PO_Invoiced"),
    ).otherwise(f.col("PO_Status")),
).drop("Provider")

# COMMAND ----------

# Replace all null value by Unknown
columns_to_replace = [
    "Company_Entity",
    "Incoterm_Code",
    "Incoterm_Detail",
    "Supplier_Code",
    "Supplier_name",
    "Spend_category",
    "Supplier_country",
    "Supplier_Category",
]
replacement_value = "Unknown"
replacement_values = {col_name: replacement_value for col_name in columns_to_replace}
df_po_ec = df_po_ec.fillna(replacement_values)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save GR Gold Table 

# COMMAND ----------

#TODO remove it or add it, for now Commented as it is not part of the current spec
# df_gr = ekbe_final_df.filter((f.col("Statut") == "GR") & (f.col("Quantity") != 0))
# # Join PO / Supplier_Master / Company_Master / WBS
# df_gr_gold = (
#     df_gr.alias("A")
#     .join(
#         df_po_ec.alias("B"),
#         (f.col("A.Purchase_Doc") == f.col("B.PO_Number"))
#         & (f.col("A.Purchase_Item") == f.col("B.PO_Item_Number")),
#         "left",
#     )
#     .select(
#         f.col("A.*"),
#         f.col("B.*"),
#     )
# )
# df_gr_gold = df_gr_gold.filter(
#     (f.col("PO_Status") == "PO_Received") | (f.col("PO_Status") == "PO_In_Progress")
# )
# df_gr_gold = df_gr_gold.withColumn("Delivery_Date_Planned", f.col("Date")).drop("Date")
# # Exclusion colonne commencant  par **
# Begin_By = "EK"
# df_gr_gold = df_gr_gold.select(
#     [col for col in df_gr_gold.columns if not col.startswith(Begin_By)]
# )
# # Saving Gold Table for Good Receipt
# df_gr_gold.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Changelog Gold Purchase orders Table

# COMMAND ----------

table_utils.save_table(
    dest_table=OUTPUT_TABLE_PATH, df=df_po_ec, mode="overwrite", overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Gold exposed table

# COMMAND ----------

src_full_tablename = OUTPUT_TABLE_PATH
dest_full_tablename = OUTPUT_TABLE_PATH + "_exposed"

Begin_By = "EK"
selected_columns = [col for col in df_po_ec.columns if not col.startswith(Begin_By)]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
