# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # PO Silver Changelog
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for purchase orders changelog based on bronze sap EK** tables. 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_silver.supply_chain_procurements.purchase_orders_latest
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap.ekpo_history_change_log
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap.ekko_history_change_log
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap.eket_history_change_log
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap.ekkn_history_change_log
# MAGIC   - {REFERENCE_READ_ENV}_silver.sap.ekes_history_change_log
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.profit_center_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed 
# MAGIC   - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekpo
# MAGIC   - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekko
# MAGIC   - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekes
# MAGIC   - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_eket
# MAGIC   - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekkn
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC   - Launching checks
# MAGIC  
# MAGIC **Things to do:** 
# MAGIC - A major refactoring was done on the previous version (latest pipeline), we still need to refactor some elements in the code  
# MAGIC - Add logger

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from functools import reduce
from datetime import datetime
import re

# Import Leap utils
from leap_utils.data_asset import table_utils

# Correction Amount for SAP currency with 3 digits
from leap_utils.data_asset import amount_correction

# Ingestion : header file
from ingestion.sap_latecoere_ecc6.sap_ingestion.common import (
    FILE_HEADER_PATH,
    extract_information_from_header_file,
)

# Widgets
dbutils.widgets.removeAll()
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "false")
DEBUG = (dbutils.widgets.get("debug").capitalize() == "True")

# COMMAND ----------

# MAGIC %md
# MAGIC ### parameters

# COMMAND ----------

# DF and tables utils
CATALOG = f"{REFERENCE_READ_ENV}_bronze"
SUFFIX = "_history_change_log"
HISTORY_DOMAIN = "sap_latecoere_ecc6"
OUTPUT_TABLE_PATH = f"{PIPELINE_WRITE_ENV}_silver.supply_chain_procurement.purchase_orders_history_change_log"
# Ids
ID = ["EKPO_ebeln", "EKPO_ebelp"]
EKET_ID = ["EKET_ebeln", "EKET_ebelp"]
EKES_ID = ["EKES_ebeln", "EKES_ebelp", "EKES_ebtyp"]
EKKN_ID = ["EKKN_ebeln", "EKKN_ebelp"]
# For testing purposes
TESTING_EXTRACTION_DATE = "2024-02-10"
PO_TABLES = ["eket", "ekpo", "ekkn", "ekko", "ekes"]

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

def adapt_changelog(df: DataFrame, table_id_columns: list, table: str):
    """
    Adapt changelog dataframe by updating chganglog to follow the changes of the new ID lpocated in table_id_columns
    Parameters:
    - df (DataFrame): The main DataFrame containing changelog information.
    - table_id_column (list): List of column names to partition by.
    - table (str): The name of the table for which to adapt the changelog.

    Returns:
    - DataFrame: The adapted changelog DataFrame.
    """

    window_spec = Window.partitionBy(table_id_columns).orderBy("validity_date")

    # Create intervals as all possible intervals from both dataframes
    intervals = df.select(
        *table_id_columns,
        f.explode(
            f.array(f.col(f"{table}_start_validity"), f.col(f"{table}_end_validity"))
        ).alias("validity_date"),
    )
    intervals = intervals.drop_duplicates()

    intervals = (
        intervals.withColumn("new_end", f.lead("validity_date").over(window_spec))
        .withColumn("new_start", f.col("validity_date"))
        .filter(f.col("new_end").isNotNull())
    )

    # Business condition joining the two tables
    condition_on_id = reduce(
        lambda x, y: x & y,
        [
            f.col(f"B.{id_elem}") == f.col(f"A.{id_elem}")
            for id_elem in table_id_columns
        ],
    )
    # join with the left table in order to split its intervals
    df_inter = df.alias("A").join(
        f.broadcast(intervals).alias("B"),
        on=(
            f.col("B.new_start").between(
                f.col(f"{table}_start_validity"),
                f.date_add(f.col(f"A.{table}_end_validity"), -1),
            )
        )
        & (
            f.col("B.new_end").between(
                f.date_add(f.col(f"{table}_start_validity"), 1),
                f.col(f"A.{table}_end_validity"),
            )
        )
        & condition_on_id,
        how="left",
    )
    drop_columns = [f.col(f"B.{id_elem}") for id_elem in table_id_columns]
    df_inter = df_inter.drop(*drop_columns)
    df_inter = df_inter.withColumn(f"{table}_end_validity", f.col("new_end"))
    df_inter = df_inter.withColumn(f"{table}_start_validity", f.col("new_start"))
    return df_inter


# TODO refactor this function with the previous one
def adapt_ekpo_changelog(df: DataFrame, df_right: DataFrame, table_right: str):
    """
    Adapt  EKPO changelog DataFrame based on intervals from another DataFrame.
    Adaptation process is designed to integrate interval data from df_right into the main changelog DataFrame df(ekpo), enhancing its information with interval-based context.

    Parameters:
    - df (DataFrame): The main DataFrame containing changelog information.
    - df_right (DataFrame): The DataFrame containing intervals.
    - table_right (str): The name of the table for intervals.

    Returns:
    - DataFrame: The adapted changelog DataFrame.
    """
    # create intervals
    joined_inetrvals = df_right.select(
        f.col(f"{table_right}_ebeln").alias("EKPO_ebeln"),
        f.col(f"{table_right}_ebelp").alias("EKPO_ebelp"),
        f.col(f"{table_right}_start_validity").alias("EKPO_start_validity"),
        f.col(f"{table_right}_end_validity").alias("EKPO_end_validity"),
    )

    # get all intervals between join and ekes temp
    window_spec = Window.partitionBy(ID).orderBy("validity_date")
    intervals = joined_inetrvals.select(
        *ID, f.col(f"EKPO_start_validity"), f.col(f"EKPO_end_validity")
    ).union(df.select(*ID, f.col(f"EKPO_start_validity"), f.col(f"EKPO_end_validity")))
    intervals = intervals.select(
        *ID, f.col(f"EKPO_start_validity").alias("validity_date")
    ).union(intervals.select(*ID, f.col(f"EKPO_end_validity").alias("validity_date")))
    intervals = (
        intervals.drop_duplicates()
        .withColumn(f"EKPO_end_validity", f.lead("validity_date").over(window_spec))
        .withColumn(f"EKPO_start_validity", f.col("validity_date"))
        .filter(f.col(f"EKPO_end_validity").isNotNull())
    )

    condition_on_id = reduce(
        lambda x, y: x & y,
        [f.col(f"B.{id_elem}") == f.col(f"A.{id_elem}") for id_elem in ID],
    )
    # join
    df_adapted = (
        df.alias("A")
        .join(
            f.broadcast(intervals).alias("B"),
            on=(condition_on_id)
            & (
                intervals["EKPO_start_validity"].between(
                    df["EKPO_start_validity"], df["EKPO_end_validity"]
                )
            )
            & (
                intervals["EKPO_end_validity"].between(
                    df["EKPO_start_validity"], df["EKPO_end_validity"]
                )
            ),
            how="left",
        )
        .drop(
            "validity_date",
            intervals["EKPO_ebeln"],
            intervals["EKPO_ebelp"],
            df["EKPO_start_validity"],
            df["EKPO_end_validity"],
        )
    )

    return df_adapted


# TODO remove this after handling all the headers typing issues
#  Redefinition  ofthe utils function cast_columns in order to take into consideration the case of a wrong header type (float instead of double)
def _cleanup_column_name(column_name: str) -> str:
    """
    **For internal module use only**

    Remove special characters except underscores and spaces, and replace spaces with underscores.
    For example, `Release date (actual)` would become `Release_date_actual`.

    :param column_name: The column name to clean up.
    :return: The cleaned-up column name.
    """
    return re.sub(" ", "_", str.strip(re.sub(r"[^a-zA-Z0-9_ ]*", "", column_name)))


def cast_columns_with_sap_business_headers(
    df: DataFrame,
    df_sap_business_header: DataFrame,
    date_format: str | None = "yyyyMMdd",
) -> DataFrame:
    """
    Cast dataframe's columns with provided format from the provided sap business header file.
    Applies casting to business column names only, so renaming of the dataframe's columns needs to be done first.
    This function takes into consideration the specific case when column is float and cast it to double

    :param df: The dataframe in which columns should be cast according to the business header file.
    :param df_sap_business_header: The sap business header file to use to cast columns of the given dataframe.
    :param date_format: The date format specifier to use to cast dates.
        Defaults to "yyyyMMdd" for SAP. Can be None.
    :return: The input dataframe with columns cast according to the sap business header file.
    """
    dfp_sap_business_header = df_sap_business_header.toPandas()

    cast_dict = {}
    for _, row in dfp_sap_business_header.iterrows():
        column_name = _cleanup_column_name(row["Business_name"])

        if column_name in df.columns:
            cast_format = row["Format"].lower()
            cast_expression = None

            # TODO could be done using the match statement, but when we will globally use Python 3.10+
            #  (DBX runtime 13.3+)
            # TODO long term we should turn these cast format literals into enumerations
            if cast_format == "string":
                pass
            elif cast_format == "date":
                cast_expression = f.to_date(f.col(column_name), date_format)
            elif cast_format in ["int", "bigint", "double"]:
                cast_expression = f.col(column_name).cast(cast_format)
            elif cast_format == "float":
                cast_expression = f.col(column_name).cast("double")
            elif cast_format == "timestamp":
                cast_expression = f.to_timestamp(f.col(column_name), date_format)
            else:
                raise Exception(
                    f"Format provided in business header is incorrect: {cast_format}"
                )

            if cast_expression is not None:
                cast_dict[column_name] = cast_expression

    if cast_dict:
        df = df.withColumns(cast_dict)

    return df

# COMMAND ----------

# Testing function
def filter_dataframe_on_date(df: DataFrame, extraction_date: str) -> DataFrame:
    """
    Extracts the validity dates from the DataFrame change log history.
    It assumes one interval is available

    Args:
    - df (DataFrame): The DataFrame containing the change log history.
    - extraction_date (str): The date to extract versions for.

    Returns:
    - DataFrame: Filtered DataFrame with valid version entries for the given extraction date.
    """
    start_columns = [col for col in df.columns if "start_validity" in col.lower()]
    end_columns = [col for col in df.columns if "end_validity" in col.lower()]
    df = df.withColumn("join_start_validity", f.col(start_columns[0]))
    df = df.withColumn("join_end_validity", f.col(end_columns[0]))

    return df.filter(
        (
            (f.col("join_end_validity") > extraction_date)
            & (f.col("join_start_validity") <= extraction_date)
        )
    )


# Joining condition between inner join of two changelogs
def get_join_condition_on_period(table_left, table_right):
    """
    Defines join condition to match the changelogs between two tables.
    make sure that right includes the left

    Args:
    - table_left (str): Name of the left table.
    - table_right (str): Name of the right table.

    Returns:
    - Column: Join condition for the two tables.
    """
    right_start, left_start, right_end, left_end = (
        f.col(f"{table_right}_Start_Validity"),
        f.col(f"{table_left}_Start_Validity"),
        f.col(f"{table_right}_End_Validity"),
        f.col(f"{table_left}_End_Validity"),
    )
    join_condition = (
        (left_start.between(right_start, f.date_add(right_end, -1)))
        | (left_end.between(f.date_add(right_start, 1), right_end))
        | (right_start.between(left_start, f.date_add(left_end, -1)))
        | (right_end.between(f.date_add(left_start, 1), left_end))
    )
    return join_condition


# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


def select_columns_based_on_header(table, df_names):
    """
    Select columns based on table and DataFrame containing column names (header+meta data).

    Parameters:
    - table (str): The name of the table.
    - df_names (DataFrame): DataFrame containing column names.

    Returns:
    - list: List of selected columns.
    """

    sap_schema_ordered_list, column_uid_list = extract_information_from_header_file(
        df_header, table
    )
    meta_data = ["ID", "start_validity", "end_validity"]
    business_columns = list(
        map(
            lambda x: x["column"],
            df_names.select(f.col("Field").alias("column")).collect(),
        )
    )
    if table == "EKPO":
        meta_data.append("webre")
    if table == "EKKO":
        business_columns.remove("budg_tyoe")
        business_columns += ["memorytype"]
    return list(set(meta_data + column_uid_list + business_columns))


def process_header(table_name: str):
    """Read Header file check schema and delete null rows"""
    # Read table
    df = spark.read.table(table_name)
    # Check schema
    table_utils.check_schema_of_the_header_file(df)
    # Delete null rows
    df = delete_null_rows(df)
    return df

# COMMAND ----------

# MAGIC %md ### Test the history change log 
# MAGIC

# COMMAND ----------

if DEBUG:
    for table in PO_TABLES:
        history_changelog = spark.read.table(
            f"{REFERENCE_READ_ENV}_bronze.{HISTORY_DOMAIN}.{table}_history_change_log"
        ).filter(f.col("stack_row_id").isNotNull())
        history_changelog_one = filter_dataframe_on_date(
            history_changelog, TESTING_EXTRACTION_DATE
        )
        table_stack = spark.read.table(
            f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.{table}_stack"
        ).filter(f.to_date(f.col("extraction_timestamp")) == TESTING_EXTRACTION_DATE)
        print(table, ": test passed")
        assert history_changelog_one.count() == table_stack.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Inputs

# COMMAND ----------

# EKKO: Headers
df_ekko = spark.read.table(f"{CATALOG}.{HISTORY_DOMAIN}.ekko{SUFFIX}").filter(
    f.col("stack_row_id").isNotNull()
)
# EKPO: Item
df_ekpo = spark.read.table(f"{CATALOG}.{HISTORY_DOMAIN}.ekpo{SUFFIX}").filter(
    f.col("stack_row_id").isNotNull()
)

# EKET : Delievries
df_eket = spark.read.table(f"{CATALOG}.{HISTORY_DOMAIN}.eket{SUFFIX}").filter(
    f.col("stack_row_id").isNotNull()
)

# EKKN: Imputations
df_ekkn = spark.read.table(f"{CATALOG}.{HISTORY_DOMAIN}.ekkn{SUFFIX}").filter(
    f.col("stack_row_id").isNotNull()
)

# EKES - Confirmations
df_ekes = spark.read.table(f"{CATALOG}.{HISTORY_DOMAIN}.ekes{SUFFIX}").filter(
    f.col("stack_row_id").isNotNull()
)

# Upload Gold Company Master Data
df_comp = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)

# Upload Master Data Profit Center
df_cepc = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed")

# Material Master Date
df_material = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed"
)
# business headers
df_name_ekpo = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekpo"
)
df_name_ekko = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekko"
)
df_name_eket = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_eket"
)
df_name_ekkn = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekkn"
)
df_name_ekes = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekes"
)

# Ingestion header
df_header = spark.read.options(header="True", delimiter=";").csv(FILE_HEADER_PATH)

# COMMAND ----------

# MAGIC %md
# MAGIC Relevant Columns selection for performance enhancement purposes 

# COMMAND ----------

df_ekko = df_ekko.select(select_columns_based_on_header("EKKO", df_name_ekko))
df_ekpo = df_ekpo.select(select_columns_based_on_header("EKPO", df_name_ekpo))
df_ekkn = df_ekkn.select(select_columns_based_on_header("EKKN", df_name_ekkn))
df_eket = df_eket.select(select_columns_based_on_header("EKET", df_name_eket))
df_ekes = df_ekes.select(select_columns_based_on_header("EKES", df_name_ekes))

print(
    "there are",
    len(df_ekpo.columns)
    + len(df_ekko.columns)
    + len(df_eket.columns)
    + len(df_ekkn.columns)
    + len(df_ekes.columns),
    "columns",
)

# COMMAND ----------

# MAGIC %md Prefix to add Business fileds later
# MAGIC

# COMMAND ----------

df_ekko = table_utils.add_prefix_to_columns(
    df_ekko, "EKKO"
)  # <- Renaming starting with EKKO_
df_ekpo = table_utils.add_prefix_to_columns(
    df_ekpo, "EKPO"
)  # <- Renaming starting with EKPO_
df_eket = table_utils.add_prefix_to_columns(
    df_eket, "EKET"
)  # <- Renaming starting with EKET_
df_ekkn = table_utils.add_prefix_to_columns(
    df_ekkn, "EKKN"
)  # <- Renaming starting with EKKN_
df_ekes = table_utils.add_prefix_to_columns(
    df_ekes, "EKES"
)  # <- Renaming starting with EKES_

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Filter on Purchasing Document Category (F)
# MAGIC The document category F (= Purchase Order) is used in most cases, furthermore the document types A (= Inquiry), K (= Contract) as well as L (= Scheduling Agreement) our focus is on POs

# COMMAND ----------

# filter on PO category
df_ekko = df_ekko.filter(f.col("EKKO_bstyp") == "F")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Join Tables EKXX from SAP + Master data for profit center

# COMMAND ----------

# MAGIC %md - Join EKKO(Header) with EKPO (Item)

# COMMAND ----------

# Join EKKO(Header) & EKPO(Item)
df_ekko = df_ekko.repartition("EKKO_ebeln")
df_ekpo = df_ekpo.repartition("EKPO_ebeln")
df_join = df_ekko.join(
    df_ekpo,
    (df_ekko.EKKO_ebeln == df_ekpo.EKPO_ebeln)
    & (get_join_condition_on_period("EKPO", "EKKO")),
    how="inner",
).drop("EKKO_mandt", "EKKO_ebeln")

# trim client
df_join = df_join.withColumn("EKPO_bukrs", f.trim(f.col("EKPO_bukrs")))

# COMMAND ----------

# Kkeep the common validity intervals after an inner join
df_join = df_join.withColumn(
    "ekpo_start_validity", f.greatest("ekpo_start_validity", "ekko_start_validity")
)
df_join = df_join.withColumn(
    "ekpo_end_validity", f.least("ekpo_end_validity", "ekko_end_validity")
)
df_join = df_join.drop("ekko_start_validity", "ekko_end_validity")

# COMMAND ----------

if DEBUG:
    assert (
        filter_dataframe_on_date(df_ekko, TESTING_EXTRACTION_DATE).count(),
        filter_dataframe_on_date(df_ekpo, TESTING_EXTRACTION_DATE).count(),
        filter_dataframe_on_date(df_join, TESTING_EXTRACTION_DATE).count(),
    ) == (1549618, 6789232, 6405687)

# COMMAND ----------

# MAGIC %md - Join with EKET(deliveries forecast)

# COMMAND ----------

# Prepare eket : Aggregate Eket changelog
df_eket_temp = adapt_changelog(df_eket, EKET_ID, "eket")
window_spec = Window.partitionBy(
    *EKET_ID, "eket_end_validity", "eket_start_validity"
).orderBy(f.desc("eket_eindt"))
# aggregate
df_eket_temp = (
    df_eket_temp.withColumn("EKET_menge", f.sum("EKET_menge").over(window_spec))
    .withColumn("EKET_wemng", f.sum("EKET_wemng").over(window_spec))
    .withColumn("Nb_Due_Date", f.count("EKET_ebeln").over(window_spec))
    .withColumn("rn", f.row_number().over(window_spec))
    .filter(f.col("rn") == 1)
    .drop("rn", "new_end", "new_start", "validity_date")
)
# For one row in ekpo, ie one (material; PO), it may have multiple rows of EKET, which means multiple delivery dates. It is not allowed in SAP but it happens sometime. It has been decided to keep only first row of eket and to red flag when there are multiples deliveries.
df_eket_warning = df_eket_temp.filter(f.col("Nb_Due_Date") > 1)

# COMMAND ----------

if DEBUG:
    assert (
        filter_dataframe_on_date(df_eket_temp, TESTING_EXTRACTION_DATE).count(),
        filter_dataframe_on_date(df_eket_warning, TESTING_EXTRACTION_DATE).count(),
    ) == (6410474, 809)

# COMMAND ----------

# repartition ekpo to match the intervals of eket
df_join_adapted = adapt_ekpo_changelog(df_join, df_eket_temp, "EKET")

# COMMAND ----------

# Join EKKO(Header) & EKPO(Item) & EKET(deliveries forecast)
df_eket_temp = df_eket_temp.repartition(*EKET_ID) 
df_join_eket = df_join_adapted.join(
    df_eket_temp,
    on=(df_join_adapted.EKPO_ebeln == df_eket_temp.EKET_ebeln)
    & (df_join_adapted.EKPO_ebelp == df_eket_temp.EKET_ebelp)
    & (
        df_join_adapted["EKPO_start_Validity"].between(
            df_eket_temp["EKET_start_validity"], df_eket_temp["EKET_end_validity"]
        )
    )
    & (
        df_join_adapted["EKPO_end_Validity"].between(
            df_eket_temp["EKET_start_validity"], df_eket_temp["EKET_end_validity"]
        )
    ),
    how="left",
).drop(
    "EKET_ebeln", "EKET_ebelp", "EKET_mandt", "EKET_start_validity", "EKET_end_validity"
)

# COMMAND ----------

if DEBUG:
    assert (
        filter_dataframe_on_date(df_join_eket, TESTING_EXTRACTION_DATE).count() == 6405687
    )

# COMMAND ----------

# MAGIC %md - Join with EKKN(Imputation)

# COMMAND ----------

# Adapt changelog to follow the changes of the new defined ID
df_ekkn_temp = adapt_changelog(df_ekkn, EKKN_ID, "ekkn")
# In case of multiple rows, keep the highest imputed quantity
window_spec = Window.partitionBy(
    *EKKN_ID, "ekkn_end_validity", "ekkn_start_validity"
).orderBy(f.desc("ekkn_menge"))
# Drop duplicates
df_ekkn_temp = (
    df_ekkn_temp.withColumn("rn", f.row_number().over(window_spec))
    .filter(f.col("rn") == 1)
    .drop("rn", "new_end", "new_start", "validity_date")
)

# COMMAND ----------

if DEBUG:
    assert (
        filter_dataframe_on_date(df_ekkn, TESTING_EXTRACTION_DATE).count(),
        filter_dataframe_on_date(df_ekkn_temp, TESTING_EXTRACTION_DATE).count(),
        round(
            filter_dataframe_on_date(df_ekkn_temp, TESTING_EXTRACTION_DATE)
            .select(f.sum("EKKN_menge"))
            .collect()[0][0]
        ),
    ) == (2068974, 2065533, 508461958032)

# COMMAND ----------

# repartition ekpo to match the intervals of ekkn
df_join_eket_adapted = adapt_ekpo_changelog(df_join_eket, df_ekkn_temp, "EKKN")

# COMMAND ----------

#  Repartition (spark ) for perf and join
df_ekkn_temp = df_ekkn_temp.repartition(*EKKN_ID)
df_join_ekkn = df_join_eket_adapted.join(
    df_ekkn_temp,
    (df_join_eket.EKPO_ebeln == df_ekkn_temp.EKKN_ebeln)
    & (df_join_eket_adapted.EKPO_ebelp == df_ekkn_temp.EKKN_ebelp)
    & (
        df_join_eket_adapted["EKPO_start_Validity"].between(
            df_ekkn_temp["EKKN_start_validity"], df_ekkn_temp["EKKN_end_validity"]
        )
    )
    & (
        df_join_eket_adapted["EKPO_end_Validity"].between(
            df_ekkn_temp["EKKN_start_validity"], df_ekkn_temp["EKKN_end_validity"]
        )
    ),
    how="left",
).drop(
    "EKKN_ebeln", "EKKN_ebelp", "EKKN_mandt", "EKKN_start_validity", "EKKN_end_validity"
)

# COMMAND ----------

if DEBUG:
    assert (
        filter_dataframe_on_date(df_join_ekkn, TESTING_EXTRACTION_DATE).count() == 6405687
    )

# COMMAND ----------

# MAGIC %md - Join with EKES(Confirmation)

# COMMAND ----------

# Adapt changelog to follow the changes of the new defined ID
df_ekes_temp = adapt_changelog(df_ekes, EKES_ID, "ekes")

window_spec = Window.partitionBy(*EKES_ID, "EKES_end_validity", "EKES_start_validity")
# Similar to deliveris dates, confirmation dates cometimes in SAP can occur multiple times for the same PO/ PO item for the same confirmation type (AB: order confirmation , LA: delivery notice)
df_ekes_temp = df_ekes_temp.withColumn(
    "Nb_Conf_Date", f.count("EKES_ebeln").over(window_spec)
)
# Keep the highest quantity confirmed in case of duplicates
window_spec = Window.partitionBy(
    *EKES_ID, "EKES_end_validity", "EKES_start_validity"
).orderBy(f.desc("ekes_eindt"))
df_ekes_temp = (
    df_ekes_temp.withColumn("EKES_menge", f.sum("EKES_menge").over(window_spec))
    .withColumn("rn", f.row_number().over(window_spec))
    .filter(f.col("rn") == 1)
    .drop("rn")
)
# Flag red when there are multiple confirmation dates for the same confirmation type
df_ekes_warning = df_ekes_temp.filter(f.col("Nb_Conf_Date") > 1)

# COMMAND ----------

# repartition ekpo to match the intervals of ekes
df_join_ekkn_adapted = adapt_ekpo_changelog(df_join_ekkn, df_ekes_temp, "EKES")

# COMMAND ----------

# Join with LA confirmations
df_join_ekes = (
    df_join_ekkn_adapted.alias("A")
    .join(
        df_ekes_temp.alias("B"),
        (f.col("A.EKPO_ebeln") == f.col("B.EKES_ebeln"))
        & (f.col("A.EKPO_ebelp") == f.col("B.EKES_ebelp"))
        & (f.col("B.EKES_ebtyp") == "LA")
        & (
            df_join_ekkn_adapted["EKPO_start_Validity"].between(
                df_ekes_temp["EKES_start_validity"], df_ekes_temp["EKES_end_validity"]
            )
        )
        & (
            df_join_ekkn_adapted["EKPO_end_Validity"].between(
                df_ekes_temp["EKES_start_validity"], df_ekes_temp["EKES_end_validity"]
            )
        ),
        "left",
    )
    .select(
        f.col("A.*"),
        f.col("B.Nb_conf_date").alias("Nb_conf_date_LA"),
        f.col("B.EKES_eindt").alias("Date_Conf_LA"),
        f.col("B.EKES_menge").alias("Qty_Conf_LA"),
        f.col("B.EKES_xblnr").alias("Text_Conf_LA"),
    )
)
# Join with AB confirmations
df_join_ekes_2 = (
    df_join_ekes.alias("A")
    .join(
        df_ekes_temp.alias("B"),
        (f.col("A.EKPO_ebeln") == f.col("B.EKES_ebeln"))
        & (f.col("A.EKPO_ebelp") == f.col("B.EKES_ebelp"))
        & (f.col("B.EKES_ebtyp") == "AB")
        & (
            df_join_ekes["EKPO_start_Validity"].between(
                df_ekes_temp["EKES_start_validity"], df_ekes_temp["EKES_end_validity"]
            )
        )
        & (
            df_join_ekes["EKPO_end_Validity"].between(
                df_ekes_temp["EKES_start_validity"], df_ekes_temp["EKES_end_validity"]
            )
        ),
        "left",
    )
    .select(
        f.col("A.*"),
        f.col("B.Nb_conf_date").alias("Nb_conf_date_AB"),
        f.col("B.EKES_eindt").alias("Date_Conf_AB"),
        f.col("B.EKES_menge").alias("Qty_Conf_AB"),
        f.col("B.EKES_xblnr").alias("Text_Conf_AB"),
    )
)

# COMMAND ----------

# MAGIC %md - Join with Profit center

# COMMAND ----------

# Join EKKO(Header) & EKPO(Item) & EKET(deliveries forecast) & EKKN(Imputation) & EKES(Confimation) & Material Master Date
df_material = df_material.select(
    "Material_Number",
    "Plant",
    "Profit_Center",
).dropDuplicates()

df_join_marc = (
    df_join_ekes_2.alias("A")
    .join(
        df_material.alias("B"),
        (f.col("A.EKPO_matnr") == f.col("B.Material_Number"))
        & (f.col("A.EKPO_werks") == f.col("B.Plant")),
        "left",
    )
    .select(f.col("A.*"), f.col("B.Profit_Center").alias("Profit_Center"))
)

# COMMAND ----------

# MAGIC %md - Join with Master Data Company
# MAGIC

# COMMAND ----------

df_join_end = (
    df_join_marc.alias("A")
    .join(df_comp.alias("B"), f.col("A.EKKO_bukrs") == f.col("B.Company"), "left")
    .select(
        f.col("A.*"),
        f.col("B.Company_Description"),
        f.col("B.Company_Entity"),
        f.col("B.Currency").alias("Company_Currency"),
        f.col("B.Country").alias("Company_Land"),
    )
)

# COMMAND ----------

# MAGIC %md - Join with Warnings 

# COMMAND ----------

# Join Table Warning
df_join_Warning = df_join_end.withColumn(
    "Multi_Ech",
    f.when(f.col("Nb_Due_Date") <= 1, f.lit("No")).otherwise(f.lit("Yes")),
)
df_join_Warning = df_join_Warning.withColumn(
    "Multi_Conf",
    f.when(
        (f.col("Nb_Conf_Date_LA") <= 1) | (f.col("Nb_Conf_Date_AB") <= 1), f.lit("No")
    ).otherwise(f.lit("Yes")),
)
df_join_last = df_join_Warning.withColumn(
    "EKKN_prctr",
    f.when(f.col("Profit_Center").isNull(), f.col("EKKN_prctr")).otherwise(
        f.col("Profit_Center")
    ),
)
df_join_last = df_join_last.drop("Profit_Center", "Nb_Due_Date", "Nb_Conf_Date")

# COMMAND ----------

# MAGIC %md - Managment Profit Center - Creation Company_Entity
# MAGIC

# COMMAND ----------

# Managment Profit Center - Creation Company_Entity
df_join_last = df_join_last.withColumn("EKKN_prctr", f.trim(f.col("EKKN_prctr")))
df_join_last = df_join_last.withColumn(
    "EKKN_prctr",
    f.when(f.col("EKKN_prctr") == "", f.lit("Unknown")).otherwise(f.col("EKKN_prctr")),
)
df_branch = (
    df_cepc.select("Profit_Center", "Branch")
    .filter(f.col("Branch").isNotNull() == True)
    .dropDuplicates(["Profit_Center"])
)

df_join_last = (
    df_join_last.join(
        df_branch, df_join_last.EKKN_prctr == df_branch.Profit_Center, how="left"
    )
    .withColumnRenamed("Branch", "Company_Entity_")
    .drop("Profit_Center")
)

df_join_last = df_join_last.withColumn(
    "Company_Entity_",
    f.when(f.col("Company_Entity_").isNull() == True, f.lit("Unknown")).otherwise(
        f.col("Company_Entity_")
    ),
)
df_join_last = df_join_last.withColumn(
    "Company_Entity_",
    f.when(f.col("Company_Entity_") == "ND", f.lit("Unknown")).otherwise(
        f.col("Company_Entity_")
    ),
)
df_join_last = df_join_last.withColumn(
    "Company_Entity",
    f.when(f.col("Company_Entity_") == "Unknown", f.col("Company_Entity")).otherwise(
        f.col("Company_Entity_")
    ),
).drop("Company_Entity_")

# COMMAND ----------

# MAGIC %md
# MAGIC - Renaming Headers according Business entries

# COMMAND ----------

# Union all header dataframes
df_names_all = (
    df_name_ekpo.unionByName(df_name_ekko)
    .unionByName(df_name_eket)
    .unionByName(df_name_ekkn)
    .unionByName(df_name_ekes)
)

# Rename columns according to header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_join_last, df_names_all
)

# Cast columns to SAP business headers format
df = cast_columns_with_sap_business_headers(df_column_names, df_names_all)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Management of Wrong SAP decimal for spécific currency (TND, JPY,...)

# COMMAND ----------

df_po_corrected = amount_correction.create_corrected_amounts(
    df, "Net_Price", "Currency_PO"
)
df_po_corrected = amount_correction.create_corrected_amounts(
    df_po_corrected, "Global_price", "Currency_PO"
)
df_po_corrected = amount_correction.create_corrected_amounts(
    df_po_corrected, "Gross_Value", "Currency_PO"
)
df_po_corrected = df_po_corrected.drop("Net_Price", "Global_price", "Gross_Value")
df_po_corrected = (
    df_po_corrected.withColumnRenamed("Net_Price_corrected", "Net_Price")
    .withColumnRenamed("Global_price_corrected", "Global_price")
    .withColumnRenamed("Gross_Value_corrected", "Gross_Value")
)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Identify the Validity interval as EKPO validity interval 

# COMMAND ----------

changelog = df_po_corrected.withColumnRenamed(
    "EKPO_end_validity", "end_validity"
).withColumnRenamed("EKPO_start_validity", "start_validity")

# COMMAND ----------

if DEBUG:
    assert (
        filter_dataframe_on_date(df_po_corrected, TESTING_EXTRACTION_DATE).count()
        == 6405687
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save output

# COMMAND ----------

table_utils.save_table(
    dest_table=OUTPUT_TABLE_PATH, df=changelog, mode="overwrite", overwrite_schema=True
)
