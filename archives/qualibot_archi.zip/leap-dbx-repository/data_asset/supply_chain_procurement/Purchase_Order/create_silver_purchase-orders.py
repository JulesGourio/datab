# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for purchase orders based on bronze sap EK** tables. 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_silver.supply_chain_procurements.purchase_orders_latest
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.ekpo_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.ekko_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.eket_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.ekkn_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.ekes_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.marc_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.cepc_latest
# MAGIC   - {READ_ENV}_gold.master_data.company_master_data_latest_exposed 
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_ekpo
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_ekko
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_ekes
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_eket
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_ekkn
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC   - Ingestion Bronze 
# MAGIC
# MAGIC **Things to do:** 
# MAGIC   - Add Master data Profit center
# MAGIC   - Warning Multi-deliveries
# MAGIC   - Renaming headers
# MAGIC   - Filter PO
# MAGIC   

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

## Upload LEAP Utils
from leap_utils.data_asset import table_utils, amount_correction

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# --------------------------------------------------------------------------------------------------------------

# Rename Columns according with Imput file 'Header Renaming
def rename_sap_column_names(df: DataFrame, df_names: DataFrame) -> DataFrame:
    dfp_names = df_names.toPandas()
    dfp_names["table_field"] = dfp_names["Table_name"] + "_" + dfp_names["Field"]
    for i, r in dfp_names.iterrows():

        df = df.withColumnRenamed(
            r["table_field"], r["Business_name"].replace(" ", "_")
        )
    return df


# --------------------------------------------------------------------------------------------------------------

# Create date format columns when indicated in the headers file
def modificate_format_column(df: DataFrame, df_names: DataFrame) -> DataFrame:
    """
    Create a date column when it is asked in the column name config file
    """
    for col in df.columns:
        if df_names.filter(f.col("Business_name") == col).count() > 0:
            if (
                df_names.filter(f.col("Business_name") == col)
                .select("Format")
                .first()[0]
                == "date"
            ):
                df = df.withColumn(f"{col}", f.to_date(f.col(f"{col}"), "yyyyMMdd"))
            else:
                if (
                    df_names.filter(f.col("Business_name") == col)
                    .select("Format")
                    .first()[0]
                    == "float"
                ):
                    df = df.withColumn(f"{col}", f.col(f"{col}").cast("float"))
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table fom SAP & Renaming Headers

# COMMAND ----------

# EKKO: Headers
df_ekko = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.ekko_latest")
df_ekko = table_utils.add_prefix_to_columns(df_ekko, "EKKO")  # <- Renaming starting with EKKO_
# -------------------------------------------------------------------------
# EKPO: Item
df_ekpo = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.ekpo_latest")
df_ekpo = table_utils.add_prefix_to_columns(df_ekpo, "EKPO")  # <- Renaming starting with EKPO_
# -------------------------------------------------------------------------
# EKET: Date & deliveries
df_eket = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.eket_latest")
df_eket = table_utils.add_prefix_to_columns(df_eket, "EKET")  # <- Renaming starting with EKET_
# -------------------------------------------------------------------------
# EKKN: Imputations
df_ekkn = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.ekkn_latest")
df_ekkn = table_utils.add_prefix_to_columns(df_ekkn, "EKKN")  # <- Renaming starting with EKKN_
# -------------------------------------------------------------------------
# EKES - Confirmations
df_ekes = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.ekes_latest")
df_ekes = table_utils.add_prefix_to_columns(df_ekes, "EKES")  # <- Renaming starting with EKES_
# -------------------------------------------------------------------------
# MARC - Master Data Material to catch Profit Center
df_marc = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.marc_latest")
# -----------------------------------------------------
# Upload Gold Company Master Data
df_comp = spark.read.table(
    f"{READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)
# Upload Master Data Profit Center
df_cepc = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.cepc_latest")

# COMMAND ----------

display(df_comp)

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Tables EKXX from SAP + Master data for profit center

# COMMAND ----------

# Join EKKO(Header) & EKPO(Item)
df_join = df_ekko.join(
    df_ekpo, (df_ekko.EKKO_ebeln == df_ekpo.EKPO_ebeln), how="left"
).drop("EKKO_mandt", "EKKO_ebeln")
df_join = df_join.filter(f.col("EKPO_ebeln").isNotNull())  # <- Cancel PO without Item
df_join = df_join.withColumn("EKPO_bukrs", f.trim(f.col("EKPO_bukrs")))
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Join EKKO(Header) & EKPO(Item) & EKET(deliveries forecast)
""" For one row in ekpo, ie one (material; PO), it may have multiple rows of EKET, which means multiple delivery dates. It is not allowed in SAP but it happens sometime. It has been decided to keep only first row of eket and to red flag when there are multiples deliveries. """

w = Window.partitionBy("EKET_ebeln", "EKET_ebelp").orderBy(f.desc("EKET_eindt"))

df_eket_temp = (
    df_eket.withColumn("EKET_menge", f.sum("EKET_menge").over(w))
    .withColumn("EKET_wemng", f.sum("EKET_wemng").over(w))
    .withColumn("Nb_Due_Date", f.count("EKET_ebeln").over(w))
    .withColumn("rn", f.row_number().over(w))
    .filter(f.col("rn") == 1)
    .drop("rn")
)

df_eket_warning = df_eket_temp.filter(f.col("Nb_Due_Date") > 1)

df_join_eket = df_join.join(
    df_eket_temp,
    (df_join.EKPO_ebeln == df_eket_temp.EKET_ebeln)
    & (df_join.EKPO_ebelp == df_eket_temp.EKET_ebelp),
    how="left",
).drop("EKET_ebeln", "EKET_ebelp", "EKET_mandt")
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Join EKKO(Header) & EKPO(Item) & EKET(deliveries forecast) & EKKN(Imputation)
"""Keep the imputation with the highest quantity in case of multiple delivery dates."""
w = Window.partitionBy("EKKN_ebeln", "EKKN_ebelp").orderBy(f.desc("EKKN_menge"))

df_ekkn_temp = (
    df_ekkn.withColumn("rn", f.row_number().over(w)).filter(f.col("rn") == 1).drop("rn")
)
df_join_ekkn = df_join_eket.join(
    df_ekkn_temp,
    (df_join_eket.EKPO_ebeln == df_ekkn_temp.EKKN_ebeln)
    & (df_join_eket.EKPO_ebelp == df_ekkn_temp.EKKN_ebelp),
    how="left",
).drop("EKKN_ebeln", "EKKN_ebelp", "EKKN_mandt")
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Join EKKO(Header) & EKPO(Item) & EKET(deliveries forecast) & EKKN(Imputation) & EKES(Confimation)
""" For one row in ekpo, ie one (material; PO), it may have multiple rows of EKES, which means multiple delivery dates. It is not allowed in SAP but it happens sometime. It has been decided to keep first row of ekes and to red flag when there are multiples deliveries. """

w0 = Window.partitionBy("EKES_ebeln", "EKES_ebelp", "EKES_ebtyp")
df_ekes_temp = df_ekes.withColumn("Nb_Conf_Date", f.count("EKES_ebeln").over(w0))
w1 = Window.partitionBy("EKES_ebeln", "EKES_ebelp", "EKES_ebtyp").orderBy(
    f.desc("EKES_eindt")
)

df_ekes_temp = (
    df_ekes_temp.withColumn("EKES_menge", f.sum("EKES_menge").over(w1))
    .withColumn("rn", f.row_number().over(w1))
    .filter(f.col("rn") == 1)
    .drop("rn")
)

df_join_ekes = (
    df_join_ekkn.alias("A")
    .join(
        df_ekes_temp.alias("B"),
        (f.col("A.EKPO_ebeln") == f.col("B.EKES_ebeln"))
        & (f.col("A.EKPO_ebelp") == f.col("B.EKES_ebelp"))
        & (f.col("B.EKES_ebtyp") == "LA"),
        "left",
    )
    .select(
        f.col("A.*"),
        f.col("B.EKES_eindt").alias("Date_Conf_LA"),
        f.col("B.EKES_menge").alias("Qty_Conf_LA"),
        f.col("B.EKES_xblnr").alias("Text_Conf_LA"),
    )
)
df_join_ekes_2 = (
    df_join_ekes.alias("A")
    .join(
        df_ekes_temp.alias("B"),
        (f.col("A.EKPO_ebeln") == f.col("B.EKES_ebeln"))
        & (f.col("A.EKPO_ebelp") == f.col("B.EKES_ebelp"))
        & (f.col("B.EKES_ebtyp") == "AB"),
        "left",
    )
    .select(
        f.col("A.*"),
        f.col("B.EKES_eindt").alias("Date_Conf_AB"),
        f.col("B.EKES_menge").alias("Qty_Conf_AB"),
        f.col("B.EKES_xblnr").alias("Text_Conf_AB"),
    )
)
df_ekes_warning = df_ekes_temp.filter(f.col("Nb_Conf_Date") > 1)

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Join EKKO(Header) & EKPO(Item) & EKET(deliveries forecast) & EKKN(Imputation) & EKES(Confimation) & MARC(Profit_center)
df_join_marc = (
    df_join_ekes_2.alias("A")
    .join(
        df_marc.alias("B"),
        (f.col("A.EKPO_matnr") == f.col("B.matnr"))
        & (f.col("A.EKPO_werks") == f.col("B.werks")),
        "left",
    )
    .select(f.col("A.*"), f.col("B.prctr").alias("MARC_prctr"))
)
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Join EKKO(Header) & EKPO(Item) & EKET(deliveries forecast) & EKKN(Imputation) & EKES(Confimation) & MARC(Profit_center) & Master_Data_Company
df_join_end = (
    df_join_marc.alias("A")
    .join(df_comp.alias("B"), f.col("A.EKKO_bukrs") == f.col("B.Company"), "left")
    .select(
        f.col("A.*"),
        f.col("B.Company_Description"),
        f.col("B.Company_Entity"),
        f.col("B.Currency").alias("Company_Currency"),
        f.col("B.Country").alias("Company_Land"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Tables EKXX Warning for Multi deliveries

# COMMAND ----------

# Join Table Warning
df_join_Warning = (
    df_join_end.alias("A")
    .join(
        df_eket_warning.alias("B"),
        (f.col("A.EKPO_ebeln") == f.col("B.EKET_ebeln"))
        & (f.col("A.EKPO_ebelp") == f.col("B.EKET_ebeln")),
        "left",
    )
    .join(
        df_ekes_warning.alias("C"),
        (f.col("A.EKPO_ebeln") == f.col("C.EKES_ebeln"))
        & (f.col("A.EKPO_ebelp") == f.col("C.EKES_ebeln")),
        "left",
    )
    .select(
        f.col("A.*"),
        f.col("B.EKET_mandt").alias("Multi_Ech"),
        f.col("C.EKES_mandt").alias("Multi_Conf"),
    )
)
df_join_Warning = df_join_Warning.withColumn(
    "Multi_Ech",
    f.when(f.col("Multi_Ech").isNull() == True, f.lit("No")).otherwise(f.lit("Yes")),
)
df_join_Warning = df_join_Warning.withColumn(
    "Multi_Conf",
    f.when(f.col("Multi_Conf").isNull() == True, f.lit("No")).otherwise(f.lit("Yes")),
)
df_join_Last = df_join_Warning.withColumn(
    "EKKN_prctr",
    f.when(f.col("MARC_prctr").isNull(), f.col("EKKN_prctr")).otherwise(
        f.col("MARC_prctr")
    ),
)
df_join_Last = df_join_Last.drop("MARC_prctr", "Nb_Due_Date", "Nb_Conf_Date")

# COMMAND ----------

# Managment Profit Center - Creation Company_Entity
df_join_Last = df_join_Last.withColumn("EKKN_prctr", f.trim(f.col("EKKN_prctr")))
df_join_Last = df_join_Last.withColumn(
    "EKKN_prctr",
    f.when(f.col("EKKN_prctr") == "", f.lit("Unknown")).otherwise(f.col("EKKN_prctr")),
)
df_branch = (
    df_cepc.select("prctr", "ort01")
    .filter(f.col("ort01").isNotNull() == True)
    .dropDuplicates(["prctr"])
)

df_join_Last = (
    df_join_Last.join(df_branch, df_join_Last.EKKN_prctr == df_branch.prctr, how="left")
    .withColumnRenamed("ort01", "Company_Entity_")
    .drop("prctr")
)

df_join_Last = df_join_Last.withColumn(
    "Company_Entity_",
    f.when(f.col("Company_Entity_").isNull() == True, f.lit("Unknown")).otherwise(
        f.col("Company_Entity_")
    ),
)
df_join_Last = df_join_Last.withColumn(
    "Company_Entity_",
    f.when(f.col("Company_Entity_") == "ND", f.lit("Unknown")).otherwise(
        f.col("Company_Entity_")
    ),
)
df_join_Last = df_join_Last.withColumn(
    "Company_Entity",
    f.when(f.col("Company_Entity_") == "Unknown", f.col("Company_Entity")).otherwise(
        f.col("Company_Entity_")
    ),
).drop("Company_Entity_")

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming Headers according Business entries

# COMMAND ----------

df_name_ekpo = spark.read.table("prod_bronze.headers_sap.headers_sap_business_ekpo")
check_schema_of_the_file(df_name_ekpo)  # <- call function Check Header files
df_name_ekpo = delete_null_rows(df_name_ekpo)  # <- Call Function Delete rows null

df_name_ekko = spark.read.table("prod_bronze.headers_sap.headers_sap_business_ekko")
check_schema_of_the_file(df_name_ekko)  # <- call function Check Header files
df_name_ekko = delete_null_rows(df_name_ekko)  # <- Call Function Delete rows null

df_name_eket = spark.read.table("prod_bronze.headers_sap.headers_sap_business_eket")
check_schema_of_the_file(df_name_eket)  # <- call function Check Header files
df_name_eket = delete_null_rows(df_name_eket)  # <- Call Function Delete rows null

df_name_ekkn = spark.read.table("prod_bronze.headers_sap.headers_sap_business_ekkn")
check_schema_of_the_file(df_name_ekkn)  # <- call function Check Header files
df_name_ekkn = delete_null_rows(df_name_ekkn)  # <- Call Function Delete rows null

df_name_ekes = spark.read.table("prod_bronze.headers_sap.headers_sap_business_ekes")
check_schema_of_the_file(df_name_ekes)  # <- call function Check Header files
df_name_ekes = delete_null_rows(df_name_ekes)  # <- Call Function Delete rows null

df_names_all = (
    df_name_ekpo.unionByName(df_name_ekko)
    .unionByName(df_name_eket)
    .unionByName(df_name_ekkn)
    .unionByName(df_name_ekes)
)
# Call Function Rename Columns according header file
df_column_names = rename_sap_column_names(df_join_Last, df_names_all)
# Call Funtion Create Columns on Date format
df = modificate_format_column(df_column_names, df_names_all)

# COMMAND ----------

# MAGIC %md
# MAGIC #Filter PO_Category on PO

# COMMAND ----------

df_po = df.filter(f.col("PO_Category") == "F")

# COMMAND ----------

# MAGIC %md
# MAGIC # Management of Wrong SAP decimal for spécific currency (TND, JPY,...)

# COMMAND ----------

df_po_corrected = amount_correction.create_corrected_amounts(df_po, "Net_Price", "Currency_PO")
df_po_corrected = amount_correction.create_corrected_amounts(
    df_po_corrected, "Global_price", "Currency_PO"
)
df_po_corrected = amount_correction.create_corrected_amounts(
    df_po_corrected, "Gross_Value", "Currency_PO"
)
df_po_corrected = df_po_corrected.drop("Net_Price", "Global_price", "Gross_Value")
df_po_corrected = (
    df_po_corrected.withColumnRenamed("Net_Price_corrected", "Net_Price")
    .withColumnRenamed("Global_price_corrected", "Global_price")
    .withColumnRenamed("Gross_Value_corrected", "Gross_Value")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save silver purchase order table

# COMMAND ----------

# Save the silver purchase order table
catalog = f"{WRITE_ENV}_silver"
domain = "supply_chain_procurement"
table = "purchase_orders"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_po_corrected,
    mode="overwrite",
    overwrite_schema=True
)
