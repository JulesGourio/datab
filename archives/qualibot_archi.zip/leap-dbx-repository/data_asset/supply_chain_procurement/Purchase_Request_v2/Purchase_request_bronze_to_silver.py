# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purchase Request - Bronze to silver
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC
# MAGIC This notebook processes SAP ECC6 purchase request data from raw bronze tables and enriches it for Silver layer usage.
# MAGIC Key steps include:
# MAGIC - Renaming and formatting EBAN and EBKN data using SAP header mappings
# MAGIC - Enriching with plant metadata, taxonomy, and purchasing group details
# MAGIC - Computing business statuses, values, and quality indicators
# MAGIC
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC
# MAGIC - Status logic derived from SAP flags and domain-specific rules
# MAGIC - Enrichment from multiple reference datasets (T001W, T024)
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Name of pipeline(s) the script was built for.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eban_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ebkn_latest`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t024_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.manual_input.taxonomy`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t001w_latest`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{PIPELINE_WRITE_ENV}_silver.supply_chain_procurement.purchase_requests_new`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils  # and then call leap_utils.save_table?

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not.
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------


# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### EBAN – Purchase Request Header
# MAGIC
# MAGIC Contains line-item level data of purchase requests, including:
# MAGIC - Material number
# MAGIC - Requested quantity
# MAGIC - Delivery and pricing data
# MAGIC
# MAGIC Used as the core dataset to build the PR records.

# COMMAND ----------

df_eban = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eban_latest"
)
df_eban_header_sap = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_eban_v2"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EBKN – Account Assignments for PRs
# MAGIC
# MAGIC Contains cost object assignments for purchase requests (e.g., cost centers, internal orders).
# MAGIC Used to add accounting and traceability context.
# MAGIC

# COMMAND ----------

df_ebkn = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ebkn_latest"
)
df_ebkn_header_sap = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ebkn_v2"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### T024 – Purchasing Group Information
# MAGIC
# MAGIC Reference data mapping `purchase_group` codes to:
# MAGIC - Descriptions
# MAGIC - Email addresses
# MAGIC
# MAGIC Enriches PRs with buyer-level metadata.

# COMMAND ----------

df_purchasing_info = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t024_latest"
).select(
    f.col("ekgrp").alias("purchase_group"),
    f.col("eknam").alias("description_of_purchasing_group"),
    f.col("smtp_addr").alias("email_address"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### T001W – Plant Metadata
# MAGIC
# MAGIC Contains master data for SAP plants (locations where materials are stored or services are delivered).
# MAGIC Includes:
# MAGIC - Plant descriptions
# MAGIC - Customer/supplier linkages
# MAGIC - Organizational mappings
# MAGIC
# MAGIC Used for contextualizing PO deliveries and site-based reporting.

# COMMAND ----------

df_t001w = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t001w_latest"
)
df_t001w_header_sap = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_t001w"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Initial cleanup and structuring of raw EBAN/EBKN/T001W datasets.
# MAGIC Includes:
# MAGIC - Prefixing technical columns
# MAGIC - Renaming columns using SAP header files
# MAGIC - Type casting of field

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation – EBAN
# MAGIC
# MAGIC Applies:
# MAGIC - Column prefixing
# MAGIC - Business-name-based renaming
# MAGIC - Format casting based on SAP header metadata

# COMMAND ----------

df_eban_header_prefix = table_utils.add_prefix_to_columns(df_eban, "EBAN")
table_utils.check_schema_of_the_header_file(df_eban_header_sap)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_eban_header_prefix, df_eban_header_sap
)
df_eban_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_eban_header_sap
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation – EBKN
# MAGIC
# MAGIC Same logic applied to EBKN: prefix, rename, cast

# COMMAND ----------

df_ebkn_header_prefix = table_utils.add_prefix_to_columns(df_ebkn, "EBKN")
table_utils.check_schema_of_the_header_file(df_ebkn_header_sap)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_ebkn_header_prefix, df_ebkn_header_sap
)
df_ebkn_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_ebkn_header_sap
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - T001W Dataset
# MAGIC
# MAGIC This cell prepares plant-level master data:
# MAGIC - Adds a prefix to all columns
# MAGIC - Applies renaming and format casting via SAP header metadata

# COMMAND ----------

df_t001w_header_prefix = table_utils.add_prefix_to_columns(df_t001w, "T001W")
table_utils.check_schema_of_the_header_file(df_t001w_header_sap)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_t001w_header_prefix, df_t001w_header_sap
)
df_t001w_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_t001w_header_sap
).select(
    f.col("Plant").alias("plant_delivered"),
    f.col("Plant_Description").alias("plant_name"),
    f.concat(f.col("Plant"), f.lit(" - "), f.col("Plant_Description")).alias(
        "plant_long_name"
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##  Transformation 1 – Enrich PRs with Related Dimensions
# MAGIC
# MAGIC Joins PR data with:
# MAGIC - Account assignments (EBKN)
# MAGIC - Purchasing group info (T024)
# MAGIC - Plant metadata (T001W)
# MAGIC - Material taxonomy
# MAGIC
# MAGIC Result: A unified view of the PR line.

# COMMAND ----------

df_pr_joined = (
    df_eban_header_renamed.join(
        df_ebkn_header_renamed, ["PR_number", "PR_item_number"], "left"
    )
    .join(df_purchasing_info, ["purchase_group"], "left")
    .join(df_t001w_header_renamed, ["plant_delivered"], "left")
)

df_pr_joined = table_utils.remove_leading_zeros(
    df=df_pr_joined, column_names=["PR_number", "PR_item_number", "material_number"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 – Status and Value Calculations
# MAGIC
# MAGIC Creates key fields such as:
# MAGIC - `document_status`: derived from SAP flags (B, deletion, conversion)
# MAGIC - `net_unit_price` and `net_value`
# MAGIC - `launching_year`
# MAGIC - `most_accurate_date`: for analytics alignment

# COMMAND ----------

df_pr_info = (
    df_pr_joined.withColumn(
        "document_status",
        f.when(
            (f.col("status_treatment") == "B") & (f.col("quantity_request") > 0),
            f.lit("02 - PR_Converted"),
        )
        .when(
            (f.col("deletion_indicator").isNull()) & (f.col("PR_closed").isNull()),
            f.lit("01 - PR_Open"),
        )
        .otherwise(f.lit("00 - PR_Cancelled")),
    )
    .withColumn(
        "net_unit_price",
        f.col("net_price") / f.col("price_base"),
    )
    .withColumn(
        "net_value",
        f.col("net_unit_price") * f.col("quantity_request"),
    )
    .withColumn(
        "launching_year",
        f.year(f.col("launching_date")),
    )
    .withColumn(
        "most_accurate_date",
        f.col("planned_delivery_date"),
    )
    .withColumn(
        "most_accurate_date_selected",
        f.lit("planned_delivery_date"),
    )
    # .withColumn(
    #     "T024_Purchasing_Group_Full_Name",
    #     f.concat(
    #         f.col("purchase_group"),
    #         f.lit(" - "),
    #         f.initcap(
    #             f.regexp_replace(
    #                 f.split(f.col("email_address_|_SMTP_ADDR"), "@")[0],
    #                 "\\.",
    #                 " "
    #             )
    #         )
    #     )
    # )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 – Business Indicator Flags
# MAGIC
# MAGIC Adds business logic flags to help identify special or edge-case documents:
# MAGIC - Deletion indicator
# MAGIC - Has material/contract
# MAGIC - Quantity = 0
# MAGIC - Special price flags (0.01€, 1€, zero)
# MAGIC - Document completeness
# MAGIC

# COMMAND ----------

df_pr_indicator = (
    df_pr_info.withColumn(
        "has_deletion_indicator",
        f.when(
            f.col("deletion_indicator").isNull(),
            f.lit(False),
        ).otherwise(f.lit(True)),
    )
    .withColumn(
        "has_material_indicator",
        f.when(f.col("material_number").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .withColumn(
        "has_contract_indicator",
        f.when(f.col("contract_number").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .withColumn(
        "has_no_quantity_planned_indicator",
        f.when(f.col("quantity_request") == 0, f.lit(True)).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_one_cent_price_indicator",
        f.when(f.col("net_price") == 0.01, f.lit(True)).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_one_currency_value_indicator",
        f.when(
            f.col("net_price") * f.col("quantity_request") == 1, f.lit(True)
        ).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_zero_price_indicator",
        f.when(
            (f.col("net_price") == 0) | (f.col("net_price").isNull()), f.lit(True)
        ).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_incomplete_document_memorytype_indicator",
        f.when(f.col("EBAN_memorytype").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

# create primary key
df_w_pk = df_pr_indicator.withColumn(
    "PR_item", f.concat_ws("-", f.col("PR_number"), f.col("PR_item_number"))
)

df_to_check = df_w_pk
col_pk = "PR_item"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for BOM table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="purchase_requests_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "supply_chain_procurement"
table = "purchase_requests_new"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_w_pk,
    mode="overwrite",
    overwrite_schema=True,
)
