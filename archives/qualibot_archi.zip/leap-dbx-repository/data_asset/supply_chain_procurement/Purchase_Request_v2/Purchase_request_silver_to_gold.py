# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # SAP Request Orders – Final Gold Layer Transformation
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC
# MAGIC This notebook transforms SAP ECC6 purchase request (PR) data into a final Gold Layer dataset used for reporting and analytics.
# MAGIC It enriches the PR data with:
# MAGIC - Supplier and material master metadata
# MAGIC - Commodity hierarchy and direct/indirect classification
# MAGIC - Derived financial and traceability information
# MAGIC - Currency conversion into EUR
# MAGIC
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC
# MAGIC - Currency conversion with time-based rate logic
# MAGIC - Prioritization logic between material master and document-level metadata
# MAGIC - Indicator logic for traceability and classification
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Name of pipeline(s) the script was built for.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{PIPELINE_READ_ENV}_silver.supply_chain_procurement.purchase_requests_new`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed`
# MAGIC - `dev_gold.master_data.material_plant_exposed`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.purchase_requests_new`
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.purchase_requests_new_exposed`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC Example:
# MAGIC - **Create_corrected_amounts** required for currency correction of SAP currencies with 3 digits
# MAGIC - **gx_validation** required for quality checks - **need "great-expectations" installed on the cluster**
# MAGIC - **logger** for inline logging
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils

from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not.
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------


# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Purchase Request – Silver Layer
# MAGIC
# MAGIC This is the processed PR dataset from the Silver layer, already structured from raw EBAN/EBKN sources.
# MAGIC Used as the base for enrichment and final Gold formatting.

# COMMAND ----------

df_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.supply_chain_procurement.purchase_requests_new"
)

# COMMAND ----------

df_silver.display()

# COMMAND ----------

df_silver.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Material Master Data
# MAGIC
# MAGIC Provides enriched material-level attributes such as:
# MAGIC - Description
# MAGIC - Branch
# MAGIC - Direct/Indirect classification
# MAGIC - Commodity and sub-commodity groupings
# MAGIC
# MAGIC Used to enhance the purchasing dataset with product metadata.

# COMMAND ----------

df_mat = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
).select(
    "material_number",
    f.col("plant").alias("plant_delivered"),
    "material_description",
    f.col("profit_center").alias("MMD_profit_center"),
    #   "Plant_Buy",
    #   "PF_pourcentage_affectation",
    #   "Plant_Buy_Name",
    #   "Plant_Buy_Long_Name",
    "branch",
    #   "Material_Division",
    "material_direct_indirect_pur",
    "material_commodity_pur",
    "material_sub_commodity_pur",
    "min_lot_size",
    # "Region",
    #   "Enablement",
    #   "Client",
    #   "Program",
    #   "Program_Detail",
    #   "Indicator_Automatic_Purchase_Order_Allowed",
)  # diff column in common is improvment in palantir

# COMMAND ----------

# MAGIC %md
# MAGIC ### Supplier Master Data
# MAGIC
# MAGIC Provides vendor-level attributes like:
# MAGIC - Country and city
# MAGIC - Intercompany flow indicator
# MAGIC - Spend category
# MAGIC
# MAGIC Used to contextualize supplier behavior and classification.

# COMMAND ----------

df_supplier = (
    spark.read.table(
        f"{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed"
    )
    .select(
        "supplier_code",
        "supplier_name",
        "intercompany_flow",  # TODO: add indicator
        "spend_category",
        "supplier_country",
        "supplier_city",
        #   "Supplier_contact",
        #   "Supplier_full_name",
        #   "KCP",
        #   "Panel_Status",
        #   "Indicator_Automatic_Purchase_Order_Allowed_For_Supplier",
        #   "Distributor_Indicator",
    )
    .drop_duplicates()
)  # colun in common is improvment in palantir

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 – Supplier and Material Information
# MAGIC
# MAGIC This step joins the PO dataset with supplier and material master data to enrich the purchasing information with:
# MAGIC - Supplier classification
# MAGIC - Material branch and commodity
# MAGIC - Profit center details

# COMMAND ----------

df_supplier.groupBy("supplier_code").count().filter(f.col("count") > 1).display()

# COMMAND ----------

df_silver_clean = df_silver.withColumn(
    "supplier_code",
    f.when(f.col("supplier_code").isNull(), f.col("EBAN_lifnr")).otherwise(
        f.col("supplier_code")
    ),
)

df_po_w_supplier = df_silver_clean.join(
    df_supplier,
    ["supplier_code"],
    "left",
).join(df_mat, ["plant_delivered", "material_number"], "left")

# COMMAND ----------

df_po_w_supplier.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 – Profit Center Prioritization
# MAGIC
# MAGIC Replaces missing document-level `profit_center` values using material master (`MMD_profit_center`) when available.

# COMMAND ----------

df_pf = df_po_w_supplier.withColumn(
    "profit_center",
    f.when(f.col("MMD_profit_center").isNull(), f.col("profit_center")).otherwise(
        f.col("MMD_profit_center")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 – Traceability Assignment Indicator
# MAGIC
# MAGIC Adds a boolean indicator to identify PR lines with traceability-relevant account assignments (`account_type = D`).

# COMMAND ----------

traceability_assignment_values = ["D"]
df_tracability = df_pf.withColumn(
    "traceability_assignment_indicator",
    f.when(f.col("EBAN_knttp").isin(traceability_assignment_values), "yes").otherwise(
        "no"
    ),
)


# COMMAND ----------

# MAGIC %md
# MAGIC ##  Transformation 3 – Currency Conversion
# MAGIC
# MAGIC Converts monetary amounts from document currency to EUR using:
# MAGIC - `Budget` exchange rate type
# MAGIC - `launching_date` as reference for historical rates
# MAGIC
# MAGIC Converted fields:
# MAGIC - Net unit price
# MAGIC - Net value
# MAGIC

# COMMAND ----------

df_converted_currency = table_utils.currency_conversion(
    df=df_tracability,
    document_currency_column=df_tracability.document_currency,
    rate_types=["Budget"],
    rate_dates=[df_tracability.launching_date],
    target_currency_value="EUR",
    document_amounts=[df_tracability.net_unit_price, df_tracability.net_value],
)

df_converted_currency = df_converted_currency.withColumn(
    "document_currency_to_EUR_in_Budget_rate_at_launching_date",
    f.col("document_currency_to_EUR_in_Budget_rate_at_launching_date").cast("double"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_to_check = df_converted_currency
col_pk = "PR_item"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for BOM table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="purchase_requests_gold",
    log_to_event_table=True,
    log_successes=True,
)

columns = df_converted_currency.columns
columns.remove(col_pk)
new_column_order = [col_pk] + columns
df_converted_currency = df_converted_currency.select(new_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – LEAP Table (Gold Layer)
# MAGIC
# MAGIC This section writes the fully transformed purchase order dataset to the LEAP Gold Layer using a robust overwrite method.
# MAGIC
# MAGIC Target:
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.purchase_orders_new`

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "supply_chain_procurement"
table = "purchase_requests_new"

DESTINATION_TABLE_FULL_PATH = f"{catalog}.{domain}.{table}"
DESTINATION_TABLE = table
TABLE_CONSTRAINT_NAME = "PR_item_PK"
TABLE_PK_COLS = col_pk

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_converted_currency,
    mode="overwrite",
    overwrite_schema=True,
)


# COMMAND ----------

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{catalog}' and table_SCHEMA='{domain}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – Exposed Table View
# MAGIC
# MAGIC Creates a filtered view excluding low-level technical columns (EKPO, EKET, etc.) for analytics or dashboard exposure.
# MAGIC
# MAGIC Target:
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.purchase_orders_new_exposed`

# COMMAND ----------

src_full_tablename = f"{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = ["EBAN", "EBKN", "T001W"]

selected_columns = [
    col
    for col in df_converted_currency.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

log.info(f"The table view {dest_full_tablename} has been successfully created")
