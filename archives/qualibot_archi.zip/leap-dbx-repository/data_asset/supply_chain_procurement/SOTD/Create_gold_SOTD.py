# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table & Gold_Exposed for Supplier OTD. 
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.sotd_latest
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.sotd_latest_exposed
# MAGIC
# MAGIC **Input :**
# MAGIC   - {PIPELINE_READ_ENV}_gold.supply_chain_procurement.sotd_history
# MAGIC   - {PIPELINE_READ_ENV}_gold.supply_chain_procurement.sotd_history_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.supply_chain_procurement.purchase_orders_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.supply_chain.good_receipt_po_latest_exposed
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ausp_latest
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBooks -> Create_Gold_Purchase-orders & Create_gold_good-receipt-PO
# MAGIC
# MAGIC **Things to do:** 
# MAGIC
# MAGIC - Join PO // Receptions // SOTD Rules
# MAGIC - Management Exwork delivery
# MAGIC - Calcul Gross S-OTD according business rules                                                      
# MAGIC - Cleaning data
# MAGIC
# MAGIC **Things to keep in mind:**
# MAGIC
# MAGIC This notebook has been modified to retrieve supplier information from the SAP table "ausp_latest" instead of a manually entered table. Consequently, the history of gold_SOTD had to be modified as well; this adjustment is made in the "History Creation" notebook.
# MAGIC
# MAGIC Before applying any edits to the SOTD columns, please ensure they are also applied to the History dataset. If not, run the job with is_init parameter as *true* (*false* by default)
# MAGIC
# MAGIC This notebook calculates all types of S-OTD (Gross, Latecoere, Last-Confirmation). Previously, these three calculations were separated into three notebooks: "Create_gold_SOTD_Gross", "Create_gold_SOTD_Latecoere", and "Create_gold_SOTD_Last_Confirmation". The output of this notebook is the union of these three calculations.
# MAGIC
# MAGIC **Job:**
# MAGIC
# MAGIC This dataset is used in job S-OTD (job_id = 466314488076638)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import ast
import pyspark.sql.functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from datetime import date, timedelta

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC  
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read reference environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")
# Get read pipeline environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Is initialization Parameter
# MAGIC
# MAGIC If is_init
# MAGIC - True: the new table is built on sotd_history table,
# MAGIC - False: the new table is built on sotd_latest

# COMMAND ----------

dbutils.widgets.text("is_init", "false")
IS_INITIALIZATION = dbutils.widgets.get("is_init").lower() == "true"

# COMMAND ----------

# MAGIC %md 
# MAGIC # Process

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table from PO & Good receipt

# COMMAND ----------

df_gold_po = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain_procurement.purchase_orders_exposed"
)  # <- Upload Purchase Order Gold exposed
df_gold_gr = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain.good_receipt_po_latest_exposed"
)  # <- Upload Good_receipt Gold exposed
df_otd_collab = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ausp_latest"
)  # <- Upload the SAP dataset containing Supplier characteristics

# COMMAND ----------

# MAGIC %md
# MAGIC #Treatment Good Receipt Purchase Order

# COMMAND ----------

# First partition to sum quantity on key PO / Item
window_1 = Window().partitionBy("Purchase_Doc", "Purchase_Item")
df_gold_gr = df_gold_gr.withColumn(
    "Cumulative_Quantity", f.sum("Quantity").over(window_1)
)
df_gold_gr = df_gold_gr.filter(
    f.col("Movement_Type") != "122"
)  # <- We need to keep only Positive mvt for reception // mvt 122 -> Mvt Cancel Reception

# 2nd partition to keep only max date
window_2 = (
    Window()
    .partitionBy("Purchase_Doc", "Purchase_Item")
    .orderBy(f.col("Delivery_Date").desc())
)
df_gold_gr = df_gold_gr.withColumn("rank", f.row_number().over(window_2))
df_gold_gr = df_gold_gr.filter(df_gold_gr["rank"] == 1).drop("rank")

df_gold_gr = df_gold_gr.select(
    "Purchase_Doc",
    "Purchase_Item",
    "Cumulative_Quantity",
    "Delivery_Date",
    "Doc_Number",
    "Doc_Item_Number",
)
df_gold_gr = df_gold_gr.filter(
    f.col("Cumulative_Quantity") > 0
)  # <- Keep only reception greater than 0

# COMMAND ----------

# MAGIC %md
# MAGIC # Selection of OTD_COLLABORATION

# COMMAND ----------

# In SAP table ausp keep only user specified values in column "atinn" == OTD_COLLABORATION"
list_collab = ["0000000442", "0000000443", "0000000444", "0000000445", "0000000446"]
df_otd_collab = (
    df_otd_collab.select("objek", "atinn", "klart", "atwrt", "atflv")
    .filter(f.col("klart") == "010")  # Supplier Classification
    .filter(f.col("atinn").isin(list_collab))
)
df_otd_collab = (
    df_otd_collab.withColumn(
        "Limit_Neg",
        f.when(f.col("atinn") == "0000000445", f.col("atflv").cast("double")).otherwise(
            f.lit(None)
        ),
    )
    .withColumn(
        "Limit_Pos",
        f.when(f.col("atinn") == "0000000446", f.col("atflv").cast("double")).otherwise(
            f.lit(None)
        ),
    )
    .withColumn(
        "KCP", f.when(f.col("atinn") == "0000000443", f.col("atwrt")).otherwise(None)
    )
    .withColumn(
        "SQAL", f.when(f.col("atinn") == "0000000442", f.col("atwrt")).otherwise(None)
    )
    .withColumn(
        "OTD_COLLABORED",
        f.when(f.col("atinn") == "0000000444", f.col("atwrt")).otherwise(None),
    )
    .drop("atinn", "atwrt", "atflv", "klart")
)

# Use group by to aggregate all information for each supplier into one row.
df_otd_collab = df_otd_collab.groupBy("objek").agg(
    f.first("Limit_Neg", ignorenulls=True).alias("Limit_Neg"),
    f.first("Limit_Pos", ignorenulls=True).alias("Limit_Pos"),
    f.first("KCP", ignorenulls=True).alias("KCP"),
    f.first("SQAL", ignorenulls=True).alias("SQAL"),
    f.first("OTD_COLLABORED", ignorenulls=True).alias("OTD_COLLABORED"),
)

# A column for the user to retrieve whether supplier information is recorded in SAP.
df_otd_collab = df_otd_collab.withColumn(
    "Supplier_in_SAP",
    f.when(
        (f.col("KCP").isNull())
        | (f.col("OTD_COLLABORED").isNull())
        | (f.col("SQAL").isNull()),
        f.lit(False),
    )
    .when(
        f.col("OTD_COLLABORED") == "Y",
        (f.col("Limit_Neg").isNotNull()) & (f.col("Limit_Pos").isNotNull()),
    )
    .otherwise(f.lit(True)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Selection of PO - General

# COMMAND ----------

df_gold_po = df_gold_po.filter(
    f.col("Deletion_Mark").isNull()
)  # <- Exclusion Item Cancelled
df_gold_po = df_gold_po.filter(
    f.col("Return_Item").isNull()
)  # <- Exclusion Return Item.

df_gold_po = table_utils.remove_leading_zeros(
    df_gold_po, ["Material_Number"]
)  # <- Elimination of leading zero in Material_Number Column

dte_max = date.today().replace(day=1) - timedelta(
    days=1
)  # <- Determine last day of previous month
dte_min = date.today().replace(day=1) - timedelta(
    days=dte_max.day
)  # <- Determine first day of previous month

df_gold_po = df_gold_po.withColumn(
    "Date_Conf_AB", f.to_date(f.col("Date_Conf_AB"), "yyyyMMdd")
)
df_gold_po = df_gold_po.withColumn(
    "Delivery_Date_Planned", f.to_date(f.col("Delivery_Date_Planned"), "yyyyMMdd")
)
df_gold_po = df_gold_po.withColumn(
    "Qty_Remaining", f.col("Qty_Remaining").cast("float")
)
df_gold_gr = df_gold_gr.withColumn(
    "Delivery_Date", f.to_date(f.col("Delivery_Date"), "yyyyMMdd")
)

# For OTD Type = "Last Confirmation", if we don't have confirmation date, we take delivery planned date
df_gold_po = df_gold_po.withColumn(
    "Delivery_Date_Conf",
    f.when(f.col("Date_Conf_AB").isNull(), f.col("Delivery_Date_Planned")).otherwise(
        f.col("Date_Conf_AB")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Selection of PO from Last month - OTD Gross

# COMMAND ----------

# Application of different rules for each OTD Type
df_gold_po_gr = df_gold_po.filter(
    (f.col("Delivery_Date_Planned") >= dte_min)
    & (f.col("Delivery_Date_Planned") <= dte_max)
)
df_gold_po_1_latecoere = df_gold_po.filter(
    (f.col("Delivery_Date_Planned") >= dte_min)
    & (f.col("Delivery_Date_Planned") <= dte_max)
)
df_gold_po_1_last_confirmation = df_gold_po.filter(
    (f.col("Delivery_Date_Conf") >= dte_min) & (f.col("Delivery_Date_Conf") <= dte_max)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Selection of PO to take in consideration for SOTD Confirmation - OTD Latecoere
# MAGIC

# COMMAND ----------

# Code for OTD Latecoere and Latest Confirmation

# We take all purchase order in the backlog (M-2 to M-9999) that have either a Planned Delivery Date (not received) for OTD_Type = Latecoere or a Confirmation Date (not received) for OTD_Type = Last Confirmation.
df_gold_po_2_latecoere = df_gold_po.filter(
    (f.col("Delivery_Date_Planned") < dte_min) & (f.col("Qty_Remaining") > 0)
)
df_gold_po_2_latecoere = df_gold_po_2_latecoere.filter(f.col("Final_Delivery").isNull())

df_gold_po_2_last_confirmation = df_gold_po.filter(
    (f.col("Delivery_Date_Conf") < dte_min) & (f.col("Qty_Remaining") > 0)
)
df_gold_po_2_last_confirmation = df_gold_po_2_last_confirmation.filter(
    f.col("Final_Delivery").isNull()
)

# We take PO received in previous month where delivery wasn't expected in previous month
df_gold_gr_temp = df_gold_gr.filter(
    (f.col("Delivery_Date") >= dte_min) & (f.col("Delivery_Date") <= dte_max)
)

df_gold_po_3 = (
    df_gold_po.alias("A")
    .join(
        df_gold_gr_temp.alias("B"),
        (f.col("A.PO_Number") == f.col("B.Purchase_Doc"))
        & (f.col("A.PO_Item_Number") == f.col("B.Purchase_Item")),
        "left",
    )
    .select(f.col("A.*"), f.col("B.Doc_Number"))
)
df_gold_po_3 = df_gold_po_3.filter((f.col("Doc_Number").isNotNull())).drop("Doc_Number")
df_gold_po_3_latecoere = df_gold_po_3.filter(f.col("Delivery_Date_Planned") < dte_min)
df_gold_po_3_last_confirmation = df_gold_po_3.filter(
    f.col("Delivery_Date_Conf") < dte_min
)

# create list of dataframes for each OTD Type
df_gold_po_end_gross = df_gold_po_gr.withColumn("OTD_Type", f.lit("Gross"))
df_gold_po_end_latecoere = (
    df_gold_po_1_latecoere.unionByName(df_gold_po_2_latecoere)
    .unionByName(df_gold_po_3_latecoere)
    .drop_duplicates()
    .withColumn("OTD_Type", f.lit("Latecoere"))
)
df_gold_po_end_last_confirmation = (
    df_gold_po_1_last_confirmation.unionByName(df_gold_po_2_last_confirmation)
    .unionByName(df_gold_po_3_last_confirmation)
    .drop_duplicates()
    .withColumn("OTD_Type", f.lit("Last Confirmation"))
)

df_gold_po_end = df_gold_po_end_gross.unionByName(df_gold_po_end_latecoere).unionByName(
    df_gold_po_end_last_confirmation
)  # <- Unify all the three datasets

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Purchase Order / Receptions / SOTD Rules / Collab

# COMMAND ----------

# Join PO / Reception - For all OTD Types
df_join_pogr = (
    df_gold_po_end.alias("A")
    .join(
        df_gold_gr.alias("B"),
        (f.col("A.PO_Number") == f.col("B.Purchase_Doc"))
        & (f.col("A.PO_Item_Number") == f.col("B.Purchase_Item")),
        "left",
    )
    .drop("Purchase_Doc", "Purchase_Item", "werks")
)

# Join information related to the Supplier
df_join_pogr_collab = (
    df_join_pogr.alias("A")
    .join(
        df_otd_collab.alias("B"), f.col("A.Supplier_Code") == f.col("B.objek"), "left"
    )
    .drop("objek", "OTD_Collaboration")
)

# Push standard value for DEFAULT supplier
df_join_pogr_collab = df_join_pogr_collab.fillna({"Limit_Neg": -7})
df_join_pogr_collab = df_join_pogr_collab.fillna({"Limit_Pos": 0})

# COMMAND ----------

# MAGIC %md
# MAGIC #Gold Enrichment

# COMMAND ----------

# MAGIC %md
# MAGIC ##Conversion all dates to yyyyMMdd format

# COMMAND ----------

columns_to_format = [
    "PO_CreationDate",
    "Document_Date",
    "Delivery_Date_Stat",
    "Date_Conf_LA",
    "Delivery_Date_Conf",
]
for column_name in columns_to_format:
    df_join_pogr_collab = df_join_pogr_collab.withColumn(
        column_name, f.to_date(f.col(column_name), "yyyyMMdd")
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ##Management of Exwork delivery date

# COMMAND ----------

# For Exwork incoterm we take the LA confirmation date as delivery date for SOTD calculation
df_delivery = df_join_pogr_collab.withColumn(
    "Incoterm_Code", f.trim(f.col("Incoterm_Code"))
)  # <- NEW
List_Incoterm = ["EXW", "FCA", "FAS", "FOB"]
# Managment Delivery Date for Exwork
df_delivery = df_delivery.withColumn(
    "Delivery_Date_OTD",
    f.when(~f.col("Incoterm_Code").isin(List_Incoterm), f.col("Delivery_Date"))
    .when(f.col("Date_Conf_LA").isNotNull(), f.col("Date_Conf_LA"))
    .otherwise(f.lit(None)),
)

# Managment Quantity for Exwork
df_delivery = df_delivery.withColumn(
    "Quantity_OTD",
    f.when(~f.col("Incoterm_Code").isin(List_Incoterm), f.col("Cumulative_Quantity"))
    .when(f.col("Qty_Conf_LA").isNotNull(), f.col("Qty_Conf_LA"))
    .otherwise(f.lit(None)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Calcul GROSS S-OTD

# COMMAND ----------

# Calculate Gap between 2 dates
df_sotd = df_delivery.withColumn(
    "Gap_Date",
    f.datediff(
        f.col("Delivery_Date_OTD"),
        f.when(
            f.col("OTD_Type") == "Last Confirmation", f.col("Delivery_Date_Conf")
        ).otherwise(f.col("Delivery_Date_Planned")),
    ),
)
# Take in consideration Delivery tolerance quantity
df_sotd = df_sotd.withColumn(
    "Quantity_Target",
    f.col("Quantity_Ordered")
    - f.col("Quantity_Ordered") * f.col("Delivery_Tolerance_neg") / 100,
)

df_sotd = df_sotd.withColumn(
    "SOTD",
    f.when(f.col("Delivery_Date_OTD").isNull(), f.lit(0))
    .when(f.col("Quantity_OTD") < f.col("Quantity_Target"), f.lit(0))
    .when(
        (f.col("Gap_Date") < f.col("Limit_Neg"))
        | (f.col("Gap_Date") > f.col("Limit_Pos")),
        f.lit(0),
    )
    .otherwise(f.lit(1)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Management Month acquisition

# COMMAND ----------

df_sotd = df_sotd.withColumn("Nb_month", f.lit(dte_min))
df_sotd = df_sotd.withColumn(
    "Nb_month", f.date_format(df_sotd["Nb_month"], "dd/MM/yyyy")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Cast Quantity value

# COMMAND ----------

df_sotd = df_sotd.withColumn("Net_Price", f.col("Net_Price").cast("double"))
df_sotd = df_sotd.withColumn(
    "Quantity_Ordered", f.col("Quantity_Ordered").cast("double")
)
df_sotd = df_sotd.withColumn(
    "Quantity_Delivered", f.col("Cumulative_Quantity").cast("double")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Management Null value

# COMMAND ----------

# Replace all null value by Unknown
columns_to_replace = [
    "Company_Entity",
    "Incoterm_Code",
    "Incoterm_Detail",
    "Supplier_Code",
    "Supplier_name",
]
replacement_value = "Unknown"
replacement_values = {col_name: replacement_value for col_name in columns_to_replace}
df_sotd = df_sotd.fillna(replacement_values)

# Fill null in "Supplier_in_SAP"
df_sotd = df_sotd.withColumn(
    "Supplier_in_SAP",
    f.when(f.col("Supplier_in_SAP").isNull(), f.lit(False)).otherwise(
        f.col("Supplier_in_SAP")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Select Columns for Exposed table

# COMMAND ----------

exposed_cols = [
    "Company_Entity",
    "Company_Code",
    "Company_Description",
    "Plant_Delivered",
    "Supplier_Code",
    "Supplier_Name",
    "Profit_Center",
    "Incoterm_Code",
    "Purchase_Org",
    "Purchase_Group",
    "PO_Number",
    "PO_Item_Number",
    "Material_Number",
    "PO_Item_Description",
    "Storage_Location",
    "Quantity_Ordered",
    "Unit_Of_Measure_PO",
    "Delivery_Date_Planned",
    "Date_Conf_LA",
    "Date_Conf_AB",
    "Quantity_Delivered",
    "Delivery_Date",
    "Doc_Number",
    "Doc_Item_Number",
    "SOTD",
    "Gap_Date",
    "Delivery_Date_Conf",
    "Delivery_Date_OTD",
    "Work_Order",
    "Contract_Number",
    "Net_Price",
    "Limit_Neg",
    "Limit_Pos",
    "PO_Type",
    "Nb_month",
    "Currency_PO",
    "Supplier_in_SAP",
    "KCP",
    "SQAL",
    "OTD_COLLABORED",
    "OTD_Type",
    "Unit_Price"
]

# COMMAND ----------

# MAGIC %md
# MAGIC #Save dataset for Supplier details

# COMMAND ----------

# These filters on the purchase orders are applied in the project notebook (create_proj_SOTD).
# Here, they are applied to consider only suppliers with relevant purchase orders.
List_po = ["NB", "ZOTH", "ZEDI"]
df_po = (
    df_gold_po.filter(
        f.col("PO_Type").isin(List_po)
    )  # <- Take only these kind of purchase Order
    .filter(
        f.col("PO_Status") == "PO_In_Progress"
    )  # <- Take in progress purchase Order
    .filter(
        (f.col("Net_Price") != "0") | (f.col("Supplier_Code") == "F01286A")
    )  # <- Exclusion Free Item -- Except For KAL Supplier"
    .drop("PO_Type")
)

df_supplier_details = df_otd_collab.withColumnRenamed("objek", "Supplier_Code")
df_supplier = (
    df_po.select("Supplier_Code", "Supplier_Name")
    .drop_duplicates()
    .filter(f.col("Supplier_Name") != "Unknown")
)
df_supplier_details = df_supplier.join(
    df_supplier_details, "Supplier_Code", "left"
).withColumn(
    "Supplier_in_SAP",
    f.when(f.col("Supplier_in_SAP").isNull(), f.lit(False)).otherwise(
        f.col("Supplier_in_SAP")
    ),
)

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "supply_chain_procurement"
table = "sotd_supplier_details_latest"
df_coverage_path = f"{catalog}.{domain}.{table}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=df_coverage_path, df=df_supplier_details, mode="overwrite"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save the gold view

# COMMAND ----------

if IS_INITIALIZATION == True:
    df_history = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.supply_chain_procurement.sotd_history"
    )
else:
    df_history = spark.read.table(
        f"{PIPELINE_READ_ENV}_gold.supply_chain_procurement.sotd_latest"
    )

id_ = df_sotd.select("Nb_month").collect()[0][0]
df_history_filter = df_history.filter(f.col("Nb_month") != id_)
df_union = df_history_filter.unionByName(df_sotd, allowMissingColumns=True)

# Subsitute Supplier_Name with latest value
df_union = df_union.withColumn("Nb_month2", f.to_date("Nb_month", "dd/MM/yyyy"))
window_spec = (
    Window.partitionBy("Supplier_Code")
    .orderBy(f.col("Nb_month2"))
    .rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
)

df_union = (
    df_union.withColumn("Supplier_Name", f.last("Supplier_Name").over(window_spec))
    .withColumn("OTD_COLLABORED", f.last("OTD_COLLABORED").over(window_spec))
    .withColumn("Supplier_in_SAP", f.last("Supplier_in_SAP").over(window_spec))
    .withColumn("KCP", f.last("KCP").over(window_spec))
    .withColumn("SQAL", f.last("SQAL").over(window_spec))
    .withColumn("Limit_Neg", f.last("Limit_Neg").over(window_spec))
    .withColumn("Limit_Pos", f.last("Limit_Pos").over(window_spec))
)


catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "supply_chain_procurement"
table = "sotd_latest"
df_coverage_path = f"{catalog}.{domain}.{table}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(dest_table=df_coverage_path, df=df_union, mode="overwrite")

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold exposed table

# COMMAND ----------

src_full_tablename = f"{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"

select_statement = ", ".join(exposed_cols)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
