# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table to retreive information about SOTD Suppliers. 
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.sotd_supplier_details_latest
# MAGIC
# MAGIC **Input :**
# MAGIC   - {REFERENCE_READ_ENV}_gold.supply_chain_procurement.purchase_orders_exposed
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ausp_latest
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBooks -> Create_Gold_Purchase-orders & Create_gold_good-receipt-PO
# MAGIC
# MAGIC **Things to do:** 
# MAGIC
# MAGIC - Join PO // Suppliers information OTD_Collab  
# MAGIC
# MAGIC **Things to keep in mind:**
# MAGIC
# MAGIC This notebook aims to retrieve information from the AUSP SAP table, which contains supplier characteristics. The final dataset will include details on suppliers who have a purchase order currently "in progress".
# MAGIC
# MAGIC **Job:**
# MAGIC
# MAGIC This dataset is used in job S-OTD (job_id = 466314488076638)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC  
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read reference environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md 
# MAGIC # Process

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table from PO & Good receipt

# COMMAND ----------

df_gold_po = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain_procurement.purchase_orders_exposed"
)  # <- Upload Purchase Order Gold exposed
df_otd_collab = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ausp_latest"
)  # <- Upload the SAP dataset containing Supplier characteristics

# COMMAND ----------

# MAGIC %md
# MAGIC # Selection of OTD_COLLABORATION

# COMMAND ----------

# In SAP table ausp keep only user specified values in column "atinn" == OTD_COLLABORATION"
list_collab = ["0000000442", "0000000443", "0000000444", "0000000445", "0000000446"]
df_otd_collab = (
    df_otd_collab.select("objek", "atinn", "klart", "atwrt", "atflv")
    .filter(f.col("klart") == "010")  # Supplier Classification
    .filter(f.col("atinn").isin(list_collab))
)
df_otd_collab = (
    df_otd_collab.withColumn(
        "Limit_Neg",
        f.when(f.col("atinn") == "0000000445", f.col("atflv").cast("double")).otherwise(
            f.lit(None)
        ),
    )
    .withColumn(
        "Limit_Pos",
        f.when(f.col("atinn") == "0000000446", f.col("atflv").cast("double")).otherwise(
            f.lit(None)
        ),
    )
    .withColumn(
        "KCP", f.when(f.col("atinn") == "0000000443", f.col("atwrt")).otherwise(None)
    )
    .withColumn(
        "SQAL", f.when(f.col("atinn") == "0000000442", f.col("atwrt")).otherwise(None)
    )
    .withColumn(
        "OTD_COLLABORED",
        f.when(f.col("atinn") == "0000000444", f.col("atwrt")).otherwise(None),
    )
    .drop("atinn", "atwrt", "atflv", "klart")
)

# Use group by to aggregate all information for each supplier into one row.
df_otd_collab = df_otd_collab.groupBy("objek").agg(
    f.first("Limit_Neg", ignorenulls=True).alias("Limit_Neg"),
    f.first("Limit_Pos", ignorenulls=True).alias("Limit_Pos"),
    f.first("KCP", ignorenulls=True).alias("KCP"),
    f.first("SQAL", ignorenulls=True).alias("SQAL"),
    f.first("OTD_COLLABORED", ignorenulls=True).alias("OTD_COLLABORED"),
)

# A column for the user to retrieve whether supplier information is recorded in SAP.
df_otd_collab = df_otd_collab.withColumn(
    "Supplier_in_SAP",
    f.when(
        (f.col("KCP").isNull())
        | (f.col("OTD_COLLABORED").isNull())
        | (f.col("SQAL").isNull()),
        f.lit(False),
    )
    .when(
        f.col("OTD_COLLABORED") == "Y",
        (f.col("Limit_Neg").isNotNull()) & (f.col("Limit_Pos").isNotNull()),
    )
    .otherwise(f.lit(True)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Filter relevant Purchase Orders with In progress status

# COMMAND ----------

# These filters on the purchase orders are applied in the project notebook (create_proj_SOTD).
# Here, they are applied to consider only suppliers with relevant purchase orders.
List_po = ["NB", "ZOTH", "ZEDI"]
df_po = (
    df_gold_po.filter(
        f.col("PO_Type").isin(List_po)
    )  # <- Take only these kind of purchase Order
    .filter(
        f.col("PO_Status") == "PO_In_Progress"
    )  # <- Take in progress purchase Order
    .filter(
        (f.col("Net_Price") != "0") | (f.col("Supplier_Code") == "F01286A")
    )  # <- Exclusion Free Item -- Except For KAL Supplier"
    .drop("PO_Type")
)

df_supplier_details = df_otd_collab.withColumnRenamed("objek", "Supplier_Code")
df_supplier = (
    df_po.select("Supplier_Code", "Supplier_Name")
    .drop_duplicates()
    .filter(f.col("Supplier_Name") != "Unknown")
)
df_supplier_details = df_supplier.join(
    df_supplier_details, "Supplier_Code", "left"
).withColumn(
    "Supplier_in_SAP",
    f.when(f.col("Supplier_in_SAP").isNull(), f.lit(False)).otherwise(
        f.col("Supplier_in_SAP")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Save Supplier Parameters Dataset

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "supply_chain_procurement"
table = "sotd_supplier_details_latest"
df_coverage_path = f"{catalog}.{domain}.{table}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=df_coverage_path, df=df_supplier_details, mode="overwrite"
)
