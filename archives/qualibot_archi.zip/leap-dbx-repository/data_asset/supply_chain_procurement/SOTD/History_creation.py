# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create the history for the Gold table and Gold_Exposed for Gross Supplier OTD.
# MAGIC This action is necessary because a dependency on the SAP table "ausp_latest" has been added to retrieve supplier information. Previously, this information was sourced from a manually entered table. As a result, the history must be updated through this notebook.
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.sotd_history
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.sotd_history_exposed
# MAGIC
# MAGIC **Input :**
# MAGIC   - {REFERENCE_READ_ENV}_gold.supply_chain_procurement.sotd_gross_latest
# MAGIC   - {REFERENCE_READ_ENV}_gold.supply_chain_procurement.sotd_latecoere_latest
# MAGIC   - {REFERENCE_READ_ENV}_gold.supply_chain_procurement.sotd_last_confirmation_latest
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC Manually triggered each time some columns modifications are peformed on sotd_latest
# MAGIC
# MAGIC **Things to do:** 
# MAGIC
# MAGIC - Join PO // Receptions // SOTD Rules
# MAGIC - Management Exwork delivery
# MAGIC - Calcul Gross S-OTD according business rules                                                      
# MAGIC - Cleaning data
# MAGIC
# MAGIC **Things to keep in mind:**
# MAGIC
# MAGIC This notebook has been modified to retrieve supplier information from the SAP table "ausp_latest" instead of a manually entered table. Consequently, the history of gold_SOTD had to be modified as well; this adjustment is made in the "History Creation" notebook.
# MAGIC
# MAGIC Before applying any edits to the SOTD columns, please ensure they are also applied to the History dataset. However, this doesm't require to be updated every time as it doesn't change.
# MAGIC
# MAGIC **Job:**
# MAGIC
# MAGIC This dataset is used in job S-OTD (job_id = 466314488076638)

# COMMAND ----------

from leap_utils.data_asset import table_utils
import pyspark.sql.functions as f
from pyspark.sql import DataFrame

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read reference environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")
# Get read pipeline environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# COMMAND ----------

df_history_gross = (
    spark.read.table(
        f"{REFERENCE_READ_ENV}_gold.supply_chain_procurement.sotd_gross_latest"
    )
    .withColumn("OTD_Type", f.lit("Gross"))
    .withColumn(
        "Delivery_Date_Conf",
        f.when(
            f.col("Date_Conf_AB").isNull(), f.col("Delivery_Date_Planned")
        ).otherwise(f.col("Date_Conf_AB")),
    )
)
df_history_latecoere = (
    spark.read.table(
        f"{REFERENCE_READ_ENV}_gold.supply_chain_procurement.sotd_latecoere_latest"
    )
    .withColumn("OTD_Type", f.lit("Latecoere"))
    .withColumn(
        "Delivery_Date_Conf",
        f.when(
            f.col("Date_Conf_AB").isNull(), f.col("Delivery_Date_Planned")
        ).otherwise(f.col("Date_Conf_AB")),
    )
)
df_history_last_confirmation = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain_procurement.sotd_last_confirmation_latest"
).withColumn("OTD_Type", f.lit("Last Confirmation"))

# Create an union dataset by stacking all S-OTD type history tables
df_history = (
    df_history_gross.unionByName(df_history_latecoere)
    .unionByName(df_history_last_confirmation)
    .drop_duplicates()
    .drop("Limit_Neg", "Limit_Pos")
)

# Remove leading zeros from Material_Number
df_history = df_history.withColumn(
    "Material_Number", f.regexp_replace("Material_Number", r"^0*", "")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Selection of OTD_COLLABORATION

# COMMAND ----------

# In SAP table ausp keep only user specified values in column "atinn" == OTD_COLLABORATION"
df_otd_collab = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ausp_latest"
)  # <- NEW

list_collab = ["0000000442", "0000000443", "0000000444", "0000000445", "0000000446"]
df_otd_collab = (
    df_otd_collab.select("objek", "atinn", "klart", "atwrt", "atflv")
    .filter(f.col("klart") == "010")
    .filter(f.col("atinn").isin(list_collab))
)
df_otd_collab = (
    df_otd_collab.withColumn(
        "Limit_Neg",
        f.when(f.col("atinn") == "0000000445", f.col("atflv").cast("double")).otherwise(
            f.lit(None)
        ),
    )
    .withColumn(
        "Limit_Pos",
        f.when(f.col("atinn") == "0000000446", f.col("atflv").cast("double")).otherwise(
            f.lit(None)
        ),
    )
    .withColumn(
        "KCP", f.when(f.col("atinn") == "0000000443", f.col("atwrt")).otherwise(None)
    )
    .withColumn(
        "SQAL", f.when(f.col("atinn") == "0000000442", f.col("atwrt")).otherwise(None)
    )
    .withColumn(
        "OTD_COLLABORED",
        f.when(f.col("atinn") == "0000000444", f.col("atwrt")).otherwise(None),
    )
    .drop("atinn", "atwrt", "atflv", "klart")
)

# Use group by to aggregate all information for each supplier into one row.
df_otd_collab = df_otd_collab.groupBy("objek").agg(
    f.first("Limit_Neg", ignorenulls=True).alias("Limit_Neg"),
    f.first("Limit_Pos", ignorenulls=True).alias("Limit_Pos"),
    f.first("KCP", ignorenulls=True).alias("KCP"),
    f.first("SQAL", ignorenulls=True).alias("SQAL"),
    f.first("OTD_COLLABORED", ignorenulls=True).alias("OTD_COLLABORED"),
)

# A column for the user to retrieve whether supplier information is recorded in SAP.
df_otd_collab = df_otd_collab.withColumn(
    "Supplier_in_SAP",
    f.when(
        (f.col("KCP").isNull())
        | (f.col("OTD_COLLABORED").isNull())
        | (f.col("SQAL").isNull()),
        f.lit(False),
    )
    .when(
        f.col("OTD_COLLABORED") == "Y",
        (f.col("Limit_Neg").isNotNull()) & (f.col("Limit_Pos").isNotNull()),
    )
    .otherwise(f.lit(True)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Join OTD_Collaboration avec History

# COMMAND ----------

# Join and filter otd_collabored and push standard value for DEFAULT supplier                                                    #<- NEW
df_history = (
    df_history.alias("A")
    .join(
        df_otd_collab.alias("B"), f.col("A.Supplier_Code") == f.col("B.objek"), "left"
    )
    .drop("objek", "OTD_Collaboration")
)

# Push standard value for DEFAULT supplier
df_history = df_history.fillna({"Limit_Neg": -7})
df_history = df_history.fillna({"Limit_Pos": 0})

# Remove leading zeros from Material_Number
df_history = table_utils.remove_leading_zeros(df_history, ["Material_Number"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Save history table

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "supply_chain_procurement"
table = "sotd_history"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

df_coverage_path = f"{catalog}.{domain}.{table}"
table_utils.save_table(dest_table=df_coverage_path, df=df_history, mode="overwrite")

# COMMAND ----------

# MAGIC %md
# MAGIC # Save history exposed table

# COMMAND ----------

df_history_exposed = df_history.select(
    "Company_Entity",
    "Company_Code",
    "Company_Description",
    "Plant_Delivered",
    "Supplier_Code",
    "Supplier_Name",
    "Profit_Center",
    "Incoterm_Code",
    "Purchase_Org",
    "Purchase_Group",
    "PO_Number",
    "PO_Item_Number",
    "Material_Number",
    "PO_Item_Description",
    "Storage_Location",
    "Quantity_Ordered",
    "Unit_Of_Measure_PO",
    "Delivery_Date_Planned",
    "Date_Conf_LA",
    "Date_Conf_AB",
    "Quantity_Delivered",
    "Delivery_Date",
    "Doc_Number",
    "Doc_Item_Number",
    "SOTD",
    "Gap_Date",
    "Delivery_Date_Conf",
    "Delivery_Date_OTD",
    "Work_Order",
    "Contract_Number",
    "Net_Price",
    "Limit_Neg",
    "Limit_Pos",
    "PO_Type",
    "Nb_month",
    "Currency_PO",
    "Supplier_in_SAP",
    "KCP",
    "SQAL",
    "OTD_COLLABORED",
    "OTD_Type",
    "Unit_Price"
)

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "supply_chain_procurement"
table = "sotd_history_exposed"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

df_coverage_path = f"{catalog}.{domain}.{table}"
table_utils.save_table(
    dest_table=df_coverage_path, df=df_history_exposed, mode="overwrite"
)
