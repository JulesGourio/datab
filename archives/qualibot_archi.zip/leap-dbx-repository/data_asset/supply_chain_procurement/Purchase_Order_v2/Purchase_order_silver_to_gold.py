# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # SAP Purchase Orders – Final Gold Layer Transformation
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC This script processes SAP ECC6 purchasing data, preparing it for Gold Layer consumption in the LEAP environment.
# MAGIC It reads pre-transformed purchase order data (Silver layer) and enriches it with business metadata including suppliers, materials, and payment terms.
# MAGIC
# MAGIC It also computes branch assignments, traceability indicators, and due dates based on payment terms.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - Use of multiple reference enrichments (supplier, material, payment terms)
# MAGIC - Conditional logic for branch reconstruction and profit center prioritization
# MAGIC - Exposure of a clean Gold Layer table with a filtered view for external consumption
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Name of pipeline(s) the script was built for.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{PIPELINE_READ_ENV}_silver.supply_chain_procurement.purchase_orders_new`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_stack`
# MAGIC - `dev_gold.master_data.material_plant_exposed`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.purchase_orders_new`
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.purchase_orders_new_exposed`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC Example:
# MAGIC - **Create_corrected_amounts** required for currency correction of SAP currencies with 3 digits
# MAGIC - **gx_validation** required for quality checks - **need "great-expectations" installed on the cluster**
# MAGIC - **logger** for inline logging
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils, payment_term

from leap_utils.common import logger

from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not.
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# list of profit centers (from EKKN) that HQ division / branch
list_pc_hq = ["A02", "S05", "S06", "S07", "S08", "F01", "F02", "N02"]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Purchase Orders – Silver Layer
# MAGIC
# MAGIC This table contains pre-cleaned purchase order data ready for final transformation. It’s the Silver output of prior SAP preprocessing.

# COMMAND ----------

df_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.supply_chain_procurement.purchase_orders_new"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Material Master Data
# MAGIC
# MAGIC Provides enriched material-level attributes such as:
# MAGIC - Description
# MAGIC - Branch
# MAGIC - Direct/Indirect classification
# MAGIC - Commodity and sub-commodity groupings
# MAGIC
# MAGIC Used to enhance the purchasing dataset with product metadata.

# COMMAND ----------

df_mat = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
).select(
    "material_number",
    f.col("plant").alias("plant_delivered"),
    "material_description",
    f.col("profit_center").alias("MMD_profit_center"),
    #   "Plant_Buy",
    #   "PF_pourcentage_affectation",
    #   "Plant_Buy_Name",
    #   "Plant_Buy_Long_Name",
    "branch",
    #   "Material_Division",
    "material_direct_indirect_pur",
    "material_commodity_pur",
    "material_sub_commodity_pur",
    "min_lot_size",
    # "Region",
    #   "Enablement",
    #   "Client",
    #   "Program",
    #   "Program_Detail",
    #   "Indicator_Automatic_Purchase_Order_Allowed",
)  # diff column in common is improvment in palantir

# COMMAND ----------

# MAGIC %md
# MAGIC ### Supplier Master Data
# MAGIC
# MAGIC Provides vendor-level attributes like:
# MAGIC - Country and city
# MAGIC - Intercompany flow indicator
# MAGIC - Spend category
# MAGIC
# MAGIC Used to contextualize supplier behavior and classification.

# COMMAND ----------

df_supplier = (
    spark.read.table(
        f"{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed"
    )
    .select(
        "supplier_code",
        "supplier_name",
        "intercompany_flow",  # TODO: add indicator
        "spend_category",
        "supplier_country",
        "supplier_city",
        #   "Supplier_contact",
        #   "Supplier_full_name",
        #   "KCP",
        #   "Panel_Status",
        #   "Indicator_Automatic_Purchase_Order_Allowed_For_Supplier",
        #   "Distributor_Indicator",
    )
    .drop_duplicates()
)  # colun in common is improvment in palantir

# COMMAND ----------

# MAGIC %md
# MAGIC ### Payment Term (T052)
# MAGIC
# MAGIC Contains payment term configurations and rules used to compute expected due dates.
# MAGIC Joined later to determine expected payment timelines for purchase orders.
# MAGIC

# COMMAND ----------

df_t052 = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest"
).drop_duplicates(subset=["zterm"])

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 – Supplier and Material Information
# MAGIC
# MAGIC This step joins the PO dataset with supplier and material master data to enrich the purchasing information with:
# MAGIC - Supplier classification
# MAGIC - Material branch and commodity
# MAGIC - Profit center details

# COMMAND ----------

df_po_w_supplier = df_silver.join(
    df_supplier,
    ["supplier_code"],
    "left",
).join(df_mat, ["plant_delivered", "material_number"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation – Quality Note & Purchasing Info Record
# MAGIC
# MAGIC TODO: Define and implement a join or enrichment using Quality Note or purchasing info.
# MAGIC The object is planned but not implemented in this iteration.

# COMMAND ----------


# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 – Profit Center Prioritization
# MAGIC
# MAGIC This logic prioritizes the profit center from the material master data (MMD) when available.
# MAGIC Fallback is to the existing value from the PO.
# MAGIC

# COMMAND ----------

df_pf = df_po_w_supplier.withColumn(
    "profit_center",
    f.when(f.col("MMD_profit_center").isNull(), f.col("profit_center")).otherwise(
        f.col("MMD_profit_center")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 – Branch Classification
# MAGIC
# MAGIC Assigns branch value based on:
# MAGIC - Profit center membership (HQ list)
# MAGIC - Purchasing organization code pattern
# MAGIC - Fallback to `"No value"` if all logic fails
# MAGIC
# MAGIC Ensures branch classification is present for all records.

# COMMAND ----------

# Complete branch with HQ from Profit Center condition list
# Then if branch from MARC is null then retrieve Branch from purch org: IS if OA2x
condition_pc_hq = f.col("profit_center").isin(list_pc_hq)
condition_po_is = f.substring(f.col("purchasing_organization"), 3, 1) == "2"
condition_branch_null = f.col("Branch").isNull()

df_branch = df_pf.withColumn(
    "branch",
    f.when(condition_pc_hq, "HQ").otherwise(
        f.when((condition_branch_null & condition_po_is), "IS").otherwise(
            f.col("branch")
        )
    ),
).withColumn(
    "branch", f.when(f.col("branch").isNull(), "No value").otherwise(f.col("branch"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 – Traceability Assignment Indicator
# MAGIC
# MAGIC Adds a boolean-like flag that indicates whether the purchase order line is linked to a traceability account assignment (based on `account_type`).

# COMMAND ----------

traceability_assignment_values = ["D"]
df_tracability = df_branch.withColumn(
    "traceability_assignment_indicator",
    f.when(
        f.col("account_type").isin(traceability_assignment_values), f.lit(True)
    ).otherwise(f.lit(False)),
)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 – Payment Term Due Date Calculation
# MAGIC
# MAGIC Uses T052 payment term rules to compute:
# MAGIC - `Expected_Payment_Term_Due_Date` based on the base date and the PO’s `zterm`.
# MAGIC
# MAGIC Requires broadcasting the payment term table for join efficiency.
# MAGIC

# COMMAND ----------

df_payment_term = payment_term.calculate_payment_term_due_date(
    df=df_tracability,
    df_payment_term=f.broadcast(df_t052),
    df_payment_term_column=df_tracability["EKKO_zterm"],
    base_date_column=df_tracability["delivery_date_planned"],
    output_column_name="expected_payment_term_due_date",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 5 – Currency Conversion
# MAGIC
# MAGIC This transformation converts key monetary fields from the document currency to a common target currency (EUR), using the appropriate rate type (`Budget`) and the PO document date as the reference for conversion.
# MAGIC
# MAGIC It handles multiple financial fields, including:
# MAGIC - Net and gross total price
# MAGIC - Unit prices
# MAGIC - Stock unit prices
# MAGIC
# MAGIC Ensures consistency across reporting by standardizing currency values.

# COMMAND ----------

df_converted_currency = table_utils.currency_conversion(
    df=df_payment_term,
    document_currency_column=df_payment_term.currency_key,
    rate_types=["Budget"],
    rate_dates=[df_payment_term.purchasing_document_date],  # TODO confirm with martin
    target_currency_value="EUR",
    document_amounts=[
        df_payment_term.net_price,
        df_payment_term.gross_value,
        df_payment_term.net_unit_price,
        df_payment_term.gross_unit_price,
        df_payment_term.gross_stock_unit_price,
        df_payment_term.net_stock_unit_price,
    ],
)

df_converted_currency = df_converted_currency.withColumn(
    "currency_key_to_EUR_in_Budget_rate_at_purchasing_document_date",
    f.col("currency_key_to_EUR_in_Budget_rate_at_purchasing_document_date").cast(
        "double"
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

df_to_check = df_converted_currency
col_pk = "PO_item"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for BOM table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="purchase_orders_silver",
    log_to_event_table=True,
    log_successes=True,
)

columns = df_converted_currency.columns
columns.remove(col_pk)
new_column_order = [col_pk] + columns
df_converted_currency = df_converted_currency.select(new_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – LEAP Table (Gold Layer)
# MAGIC
# MAGIC This section writes the fully transformed purchase order dataset to the LEAP Gold Layer using a robust overwrite method.
# MAGIC
# MAGIC Target:
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.purchase_orders_new`

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "supply_chain_procurement"
table = "purchase_orders_new"

DESTINATION_TABLE_FULL_PATH = f"{catalog}.{domain}.{table}"
TABLE_CONSTRAINT_NAME = "PO_item_PK"
TABLE_PK_COLS = col_pk

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_converted_currency,
    mode="overwrite",
    overwrite_schema=True,
)


# COMMAND ----------

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{catalog}' and table_SCHEMA='{domain}' and table_name='{table}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – Exposed Table View
# MAGIC
# MAGIC Creates a filtered view excluding low-level technical columns (EKPO, EKET, etc.) for analytics or dashboard exposure.
# MAGIC
# MAGIC Target:
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.supply_chain_procurement.purchase_orders_new_exposed`

# COMMAND ----------

src_full_tablename = f"{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = [
    "EKPO",
    "EKET",
    "EKBE",
    "EKES",
    "EKKN",
    "T001W",
    "EKKO",
    "LA_EKES",
    "AB_EKES",
]

selected_columns = [
    col
    for col in df_converted_currency.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

log.info(f"The table view {dest_full_tablename} has been successfully created")
