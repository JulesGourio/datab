# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purchase Order - Bronze to silver
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC This notebook performs the preparation and transformation of SAP ECC6 purchasing data for analytical and reporting use.
# MAGIC The process includes:
# MAGIC - Loading and renaming raw input tables from EKPO, EKKO, EKET, EKES, EKKN, EKBE, and T001W
# MAGIC - Applying business-friendly column names and data types
# MAGIC - Joining relevant tables to construct a unified PO dataset enriched with delivery, confirmation, assignment, and history information
# MAGIC - Computing key purchasing KPIs such as remaining quantities, net/gross values, unit prices, and conversion rates
# MAGIC - Deriving PO statuses based on document and transactional history (goods/invoice receipts)
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - **[Transformations → PO Status Derivation]**: Logic combining both document flags and movement history to determine the current PO lifecycle status
# MAGIC - **[Transformations → Accurate Date Selection]**: Multiple date sources (invoice, goods receipt, confirmation) prioritized to compute the most reliable PO activity date
# MAGIC - **[Currency Handling]**: Decimal and currency conversions performed using TCURX/TCURR reference tables with dynamic year-based logic
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Name of pipeline(s) the script was built for.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_zone.domain.table
# MAGIC - {pipeline_read_env}_zone.domain.table
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {reference_read_env}_zone.domain.table
# MAGIC - {reference_read_env}_zone.domain.table
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_zone.domain.table
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# EXAMPLE
import pyspark.sql.functions as f
from pyspark.sql.window import Window


# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils  # and then call leap_utils.save_table?

# Logging imports
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not.
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC
# MAGIC

# COMMAND ----------

# list of VBUND not been interco
list_not_interco = ["", "X000", "000500", "S400", "S200", "001200"]

# list of document type BSART been open
list_open_doc = ["FOP", "FOA", "FO", "FOTS", "FOF"]

# list of interdivision or intraco sub-type of purchase order
list_intraco_po_type = ["UB", "ZUB"]

# list of 'Provider' suppliers with monthly Invoice not link on Purchase Order
list_provider_monthly_invoice = ["F04641A", "F69631A", "F04171A", "F03423A"]

# dictionary of supplier status harmonization
status_dict = {
    "P": "PANEL",
    "p": "PANEL",
    "PANEL+": "PANEL",
    "I": "INVESTIGATION",
    "PH": "PHASE OUT",
    "F": "FORBIDDEN",
    "C": "CUSTOMER",
    "O": "ON HOLD",
    "*Not Monitored*": "NOT MONITORED",
}

# list columns to take from: T024 for PO Header transformed
list_t024_col = [
    "primary_key",
    "description_of_purchasing_group_|_EKNAM",
    "email_address_|_SMTP_ADDR",
]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### EKPO – Purchase Order Items
# MAGIC
# MAGIC This table contains line-level details of each purchase order (PO).
# MAGIC Each row represents a specific item or service being procured. It includes information such as:
# MAGIC - Material number
# MAGIC - Quantity ordered
# MAGIC - Net price
# MAGIC - Delivery date
# MAGIC - Final delivery and invoice flags
# MAGIC
# MAGIC Used to analyze what was ordered, in what quantity, and at what price.

# COMMAND ----------

df_ekpo = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekpo_latest"
)
df_ekpo_header_sap = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekpo_v2"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EKKO – Purchase Order Header
# MAGIC
# MAGIC This table contains header-level metadata for purchase orders.
# MAGIC It includes:
# MAGIC - PO number
# MAGIC - Vendor account
# MAGIC - Document type
# MAGIC - Purchasing organization
# MAGIC - Currency
# MAGIC - Order creation dates
# MAGIC
# MAGIC Used to provide context for all associated EKPO line items.

# COMMAND ----------

df_ekko = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekko_latest"
).filter(f.col("bstyp") == "F")
df_ekko_header_sap = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekko_v2"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EKET – Schedule Lines (Delivery Planning)
# MAGIC
# MAGIC Contains scheduling data for each purchase order item, including:
# MAGIC - Planned delivery dates
# MAGIC - Quantities to be delivered
# MAGIC - Actual delivered quantities
# MAGIC
# MAGIC This table supports tracking of delivery planning vs actuals, and enables computation of delivery progress.

# COMMAND ----------

df_eket = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eket_latest"
)
df_eket_header_sap = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_eket_v2"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EKES – Service Entry Sheets
# MAGIC
# MAGIC This table holds information about services rendered by vendors and confirmed in SAP.
# MAGIC It includes:
# MAGIC - Quantities of service accepted
# MAGIC - Reference numbers (external confirmations)
# MAGIC - Confirmation dates and types (e.g., LA = noticed, AB = confirmed)
# MAGIC
# MAGIC Essential for service procurement tracking and confirmation reconciliation.

# COMMAND ----------

df_ekes = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekes_latest"
)
df_ekes_header_sap = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekes_v2"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EKKN – Account Assignment
# MAGIC
# MAGIC Links PO items to their cost objects (e.g., cost centers, internal orders, WBS elements).
# MAGIC Fields include:
# MAGIC - Quantity assigned per cost object
# MAGIC - Account assignment category (e.g., K = cost center)
# MAGIC
# MAGIC Used for cost traceability and budgeting analysis.

# COMMAND ----------

df_ekkn = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekkn_latest"
)
df_ekkn_header_sap = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekkn_v2"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EKBE – PO History (Goods and Invoice Movements)
# MAGIC
# MAGIC Tracks historical transactions against each PO item, including:
# MAGIC - Goods receipts
# MAGIC - Invoice receipts
# MAGIC - Returns and cancellations
# MAGIC
# MAGIC Each record reflects a movement type (e.g., 101 = GR, 105 = Return) and the corresponding quantity/value.
# MAGIC Key for determining PO execution and current status.
# MAGIC
# MAGIC

# COMMAND ----------

df_ekbe = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekbe_latest"
)
df_ekbe_header_sap = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekbe_v2"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### T001W – Plant Metadata
# MAGIC
# MAGIC Contains master data for SAP plants (locations where materials are stored or services are delivered).
# MAGIC Includes:
# MAGIC - Plant descriptions
# MAGIC - Customer/supplier linkages
# MAGIC - Organizational mappings
# MAGIC
# MAGIC Used for contextualizing PO deliveries and site-based reporting.

# COMMAND ----------

df_t001w = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t001w_latest"
)
df_t001w_header_sap = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_t001w"
).withColumn("Business_name", f.lower(f.col("Business_name")))

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC This notebook section handles the initial preparation of "raw" SAP datasets for downstream transformations.
# MAGIC
# MAGIC ✅ This includes:
# MAGIC - Column renaming using business metadata
# MAGIC - Column filtering or selection
# MAGIC - Dataset-specific enrichments (without joins)
# MAGIC
# MAGIC ⚠️ Note: These are preparatory steps to enable consistency, clarity, and clean structure across datasets before more complex processing.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - EKPO Dataset
# MAGIC
# MAGIC This cell applies:
# MAGIC - Prefixing column names with `EKPO_`
# MAGIC - Renaming columns using SAP business headers
# MAGIC - Casting column formats
# MAGIC - Overriding technical fields with business-friendly names (`document_number` → `PO_number`, `item_number` → `PO_item_number`)

# COMMAND ----------

df_ekpo_header_prefix = table_utils.add_prefix_to_columns(df_ekpo, "EKPO")
table_utils.check_schema_of_the_header_file(df_ekpo_header_sap)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_ekpo_header_prefix, df_ekpo_header_sap
)
df_ekpo_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_ekpo_header_sap
).withColumnsRenamed({"document_number": "PO_number", "item_number": "PO_item_number"})

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - EKKO Dataset
# MAGIC
# MAGIC This cell:
# MAGIC - Prefixes columns with `EKKO_`
# MAGIC - Applies business name mappings from headers
# MAGIC - Casts data types accordingly
# MAGIC - Renames `document_number` to `PO_number` for consistency

# COMMAND ----------

df_ekko_header_prefix = table_utils.add_prefix_to_columns(df_ekko, "EKKO")
table_utils.check_schema_of_the_header_file(df_ekko_header_sap)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_ekko_header_prefix, df_ekko_header_sap
)
df_ekko_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_ekko_header_sap
).withColumnRenamed("document_number", "PO_number")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - EKET Dataset
# MAGIC
# MAGIC This cell prepares and enriches the EKET data by:
# MAGIC - Prefixing and renaming columns
# MAGIC - Applying type casting
# MAGIC - Computing delivery quantities using window functions
# MAGIC - Retaining only the latest planned delivery record (`row_number == 1`)

# COMMAND ----------

df_eket_header_prefix = table_utils.add_prefix_to_columns(df_eket, "EKET")
table_utils.check_schema_of_the_header_file(df_eket_header_sap)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_eket_header_prefix, df_eket_header_sap
)
df_eket_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_eket_header_sap
)
eket_partition_col = ["PO_number", "PO_item_number"]
eket_ordering_col = ["delivery_date_planned"]
eket_sum_col = [
    "quantity_planned",
    "quantity_delivered",
]
w = Window.partitionBy(*eket_partition_col).orderBy(f.desc(*eket_ordering_col))
eket_df = (
    df_eket_header_renamed.withColumn(eket_sum_col[0], f.sum(eket_sum_col[0]).over(w))
    .withColumn(eket_sum_col[1], f.sum(eket_sum_col[1]).over(w))
    .withColumn("number_due_date", f.count(eket_ordering_col[0]).over(w))
    .withColumn("rn", f.row_number().over(w))
    .filter(f.col("rn") == 1)
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - EKES Dataset
# MAGIC
# MAGIC This cell:
# MAGIC - Prefixes and renames EKES columns using metadata
# MAGIC - Casts types based on headers
# MAGIC - Uses windowing to capture only the latest confirmation record per PO item

# COMMAND ----------

df_ekes_header_prefix = table_utils.add_prefix_to_columns(df_ekes, "EKES")
table_utils.check_schema_of_the_header_file(df_ekes_header_sap)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_ekes_header_prefix, df_ekes_header_sap
)
df_ekes_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_ekes_header_sap
)
ekes_partition_col = ["PO_number", "PO_item_number"]
ekes_ordering_col = ["confirmation_date"]
w = Window.partitionBy(*ekes_partition_col).orderBy(f.desc(*ekes_ordering_col))
ekes_df = (
    df_ekes_header_renamed.withColumn(
        "number_conf_date", f.count(ekes_ordering_col[0]).over(w)
    )
    .withColumn("rn", f.row_number().over(w))
    .filter(f.col("rn") == 1)
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - EKKN Dataset
# MAGIC
# MAGIC This cell:
# MAGIC - Applies consistent renaming and type casting to EKKN fields
# MAGIC - Uses windowing to count and retain only the top-ranked assignment entry (based on assigned quantity)

# COMMAND ----------

df_ekkn_header_prefix = table_utils.add_prefix_to_columns(df_ekkn, "EKKN")
table_utils.check_schema_of_the_header_file(df_ekkn_header_sap)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_ekkn_header_prefix, df_ekkn_header_sap
)
df_ekkn_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_ekkn_header_sap
)
ekkn_partition_col = ["PO_number", "PO_item_number"]
ekkn_ordering_col = ["assigned_quantity"]
w = Window.partitionBy(*ekkn_partition_col).orderBy(f.desc(*ekkn_ordering_col))
ekkn_df = (
    df_ekkn_header_renamed.withColumn(
        "number_assignement", f.count(ekkn_ordering_col[0]).over(w)
    )
    .withColumn("rn", f.row_number().over(w))
    .filter(f.col("rn") == 1)
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - EKBE Dataset
# MAGIC
# MAGIC This complex transformation:
# MAGIC - Renames and casts EKBE columns
# MAGIC - Maps operation types (1 → `Goods_Receipt`, 2 → `Invoice_Receipt`)
# MAGIC - Adjusts quantity signs based on debit/credit indicator
# MAGIC - Pivots and aggregates history by PO and item
# MAGIC - Derives status fields to reflect invoicing progress (completed/uncompleted) and enriches the dataset accordingly

# COMMAND ----------

df_ekbe_header_prefix = table_utils.add_prefix_to_columns(df_ekbe, "EKBE")
table_utils.check_schema_of_the_header_file(df_ekbe_header_sap)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_ekbe_header_prefix, df_ekbe_header_sap
)
df_ekbe_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_ekbe_header_sap
).where(f.col("operation_type").isin(["1", "2"]))

ekbe_df = df_ekbe_header_renamed.withColumn(
    "operation_type",
    f.when(f.col("operation_type") == "1", "goods_receipt").when(
        f.col("operation_type") == "2", "invoice_receipt"
    ),
).withColumn(
    "quantity",
    f.when(f.col("debitcredit_indicator") == "H", -1 * f.col("quantity")).otherwise(
        f.col("quantity")
    ),
)

group_col = ["purchase_doc", "purchase_item"]
pivot_col = "operation_type"
order_col = ["posting_date", "EKBE_cputm"]
ekbe_df = (
    ekbe_df.orderBy(order_col)
    .groupBy(*group_col)
    .pivot(pivot_col)
    .agg(
        f.sum(f.col("quantity")).alias("quantity"),
        f.max(f.col("document_date")).alias("document_date"),
        f.last(f.col("delivery_completed_indicator"), ignorenulls=True).alias(
            "delivery_completed_indicator"
        ),
        f.concat_ws("|", f.collect_list("debitcredit_indicator")).alias(
            "debitcredit_indicator"
        ),
        f.sum(f.when(f.col("debitcredit_indicator") == "H", 1).otherwise(0)).alias(
            "EKBE_H_credit_movements"
        ),
        f.sum(f.when(f.col("debitcredit_indicator") == "S", 1).otherwise(0)).alias(
            "EKBE_S_debit_movements"
        ),
        f.count_distinct(
            f.when(f.col("debitcredit_indicator") == "S", f.col("document_date"))
        ).alias("EKBE_distinct_S_debit_movements"),
    )
)

ekbe_df = ekbe_df.withColumn(
    "goods_receipt_quantity", f.coalesce(f.col("goods_receipt_quantity"), f.lit(0))
).withColumn(
    "invoice_receipt_quantity", f.coalesce(f.col("invoice_receipt_quantity"), f.lit(0))
)

invoice_complete_cond = (
    f.col("invoice_receipt_quantity") >= f.col("goods_receipt_quantity")
) & (f.col("invoice_receipt_quantity") > 0)
invoice_uncomplete_cond = (
    f.col("goods_receipt_quantity") > f.col("invoice_receipt_quantity")
) & (f.col("goods_receipt_quantity") > 0)

ekbe_df = ekbe_df.withColumn(
    "status_from_history_as_today_detailed",
    f.when(invoice_complete_cond, f.lit("Invoice Completed on Received so far"))
    .when(invoice_uncomplete_cond, f.lit("Invoice Uncomplete on Received so far"))
    .otherwise(f.lit("TBD")),
).withColumn(
    "status_from_history_as_today",
    f.when(invoice_complete_cond, f.lit("13 - PO_Invoiced"))
    .when(invoice_uncomplete_cond, f.lit("12 - PO_Received"))
    .otherwise(f.lit("TBD")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - T001W Dataset
# MAGIC
# MAGIC This cell prepares plant-level master data:
# MAGIC - Adds a prefix to all columns
# MAGIC - Applies renaming and format casting via SAP header metadata

# COMMAND ----------

df_t001w_header_prefix = table_utils.add_prefix_to_columns(df_t001w, "T001W")
table_utils.check_schema_of_the_header_file(df_t001w_header_sap)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_t001w_header_prefix, df_t001w_header_sap
)
df_t001w_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_t001w_header_sap
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC This section performs the core transformations on the SAP datasets. It includes logic such as:
# MAGIC - Multi-table joins
# MAGIC - Business logic derivation
# MAGIC - Status enrichment
# MAGIC - Field prioritization
# MAGIC - Metric calculation (e.g. quantities, prices, flags)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 – Combine PO with Headers, Agreements, Assignments, Confirmations
# MAGIC
# MAGIC This transformation progressively joins together:
# MAGIC - EKPO (PO items) with EKKO (PO header)
# MAGIC - EKET (delivery schedule)
# MAGIC - EKKN (account assignments)
# MAGIC - EKES (vendor confirmations: LA & AB categories)
# MAGIC
# MAGIC It creates a unified view of each PO line enriched with all relevant dimensions.

# COMMAND ----------

# Join EKKO - Header
po_w_headers = df_ekpo_header_renamed.join(
    df_ekko_header_renamed,
    ["PO_number"],
    "left",
)

# Join EKET - Agreement
po_w_agreement = po_w_headers.join(
    eket_df,
    on=["PO_number", "PO_item_number"],
    how="left",
)

#   Join EKKN - Assignment
po_w_assignment = po_w_agreement.join(
    ekkn_df,
    ["PO_number", "PO_item_number"],
    "left",
)

#   Join EKES - Confirmation
ekes_la_df = ekes_df.filter(f.col("confirmation_category") == "LA").drop(
    "confirmation_category"
)
ekes_la_df = table_utils.add_prefix_to_columns(ekes_la_df, "LA").withColumnsRenamed(
    {
        "LA_PO_number": "PO_number",
        "LA_PO_item_number": "PO_item_number",
    }
)
po_w_confirmation = po_w_assignment.join(
    ekes_la_df,
    ["PO_number", "PO_item_number"],
    "left",
)
ekes_ab_df = ekes_df.filter(f.col("confirmation_category") == "AB").drop(
    "confirmation_category"
)
ekes_ab_df = table_utils.add_prefix_to_columns(ekes_ab_df, "AB").withColumnsRenamed(
    {
        "AB_PO_number": "PO_number",
        "AB_PO_item_number": "PO_item_number",
    }
)
po_complete = po_w_confirmation.join(
    ekes_ab_df,
    ["PO_number", "PO_item_number"],
    "left",
)

po_complete = table_utils.remove_leading_zeros(
    df=po_complete,
    column_names=[
        "PO_number",
        "PO_item_number",
        "material_number",
        "supplier_material_number",
    ],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 – Add Plant Information and Material Group Taxonomy
# MAGIC
# MAGIC This step:
# MAGIC - Joins with T001W to bring plant metadata
# MAGIC - Joins with a manually curated taxonomy to map material group codes to business labels

# COMMAND ----------

#   Join [TOO1W] for plant description
po_w_plant = po_complete.join(
    df_t001w_header_renamed.select(
        f.col("plant").alias("plant_delivered"),
        "plant_description",
        "plant_customer",
        "plant_supplier",
        "purchase_orga",
        "customers_orga",
    ),
    ["plant_delivered"],
    "left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 – Add Derived Quantities, Prices, and Identifiers
# MAGIC
# MAGIC This step calculates:
# MAGIC - Remaining quantities and values
# MAGIC - Net/gross unit prices
# MAGIC - Stock-unit price conversion
# MAGIC - PO item compound key
# MAGIC - Incoterm prioritization

# COMMAND ----------

# Create columns: prioritized: incoterm
po_prioritized = po_w_plant.withColumn(
    "intercom_code",
    f.when(
        f.col("incoterms_part_1").isNull(),
        f.col("incoterms_part_1"),
    ).otherwise(f.col("incoterms_part_1")),
).withColumn(
    "intercom_detail",
    f.when(
        f.col("incoterms_part_2").isNull(),
        f.col("incoterms_part_2"),
    ).otherwise(f.col("incoterms_part_2")),
)

# Create columns: transformed: remaining qty & value, unit price, stock unit qty, po item
po_info = (
    po_prioritized.withColumn(
        "qty_remaining",
        f.when(f.col("final_delivery_indicator") == "X", 0)
        .otherwise(f.col("quantity_planned") - f.col("quantity_delivered"))
        .cast("double"),
    )
    .withColumn(
        "net_unit_price",
        f.col("global_price") / f.col("quantity_ordered"),
    )
    .withColumn(
        "gross_unit_price",
        f.col("gross_value") / f.col("quantity_ordered"),
    )
    .withColumn(
        "net_remaing_value",
        (f.col("qty_remaining") * f.col("net_unit_price")),
    )
    .withColumn(
        "gross_remaining_value",
        (f.col("qty_remaining") * f.col("gross_unit_price")),
    )
    .withColumn(
        "conversion_rate_into_stock_unit",
        f.when(
            f.col("numerator_for_conversion_of_order_unit_to_stock_unit") == 0,
            f.lit(1),
        ).otherwise(
            f.col("numerator_for_conversion_of_order_unit_to_stock_unit")
            / f.col("denominator_for_conversion_of_order_unit_to_stock_unit")
        ),
    )
    .withColumn(
        "quantity_ordered_in_stock_unit",
        (f.col("quantity_ordered") * f.col("conversion_rate_into_stock_unit")),
    )
    .withColumn(
        "gross_stock_unit_price",
        (f.col("gross_value") / f.col("quantity_ordered_in_stock_unit")),
    )
    .withColumn(
        "net_stock_unit_price",
        (f.col("global_price") / f.col("quantity_ordered_in_stock_unit")),
    )
    .withColumn(
        "purchasing_document_date_year",
        f.year(f.col("purchasing_document_date")),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 – Add Indicators on Materials, Contracts, Returns, and Quantity Planning
# MAGIC
# MAGIC This enrichment introduces business logic flags such as:
# MAGIC - Material presence
# MAGIC - Contract/Purchase request link
# MAGIC - Return flags
# MAGIC - Quantity planning validation
# MAGIC - Multi-due or confirmation detection
# MAGIC - Price or currency anomalies

# COMMAND ----------

# Create columns: indicators: material, return, multi ech, multi conf, quantity planned (1)
# Deletion indicator to be done after status definition
# (1) Quantity Planned flag = Order used to invoice an additional service (no marchandise)
po_info_final = (
    po_info.withColumn(
        "has_material_indicator",
        f.when(f.col("material_number").isNull(), f.lit(False)).otherwise(f.lit(True)),
    )
    .withColumn(
        "has_contract_indicator",
        f.when(
            f.col("number_of_principal_purchase_agreement").isNull(), f.lit(False)
        ).otherwise(f.lit(True)),
    )
    .withColumn(
        "has_purchase_request_indicator",
        f.when(f.col("purchase_request_number").isNull(), f.lit(False)).otherwise(
            f.lit(True)
        ),
    )
    .withColumn(
        "is_returns_indicator",
        f.when(f.col("return_item_indicator") == "X", f.lit(True)).otherwise(
            f.lit(False)
        ),
    )
    .withColumn(
        "is_multi_due",
        f.when(f.col("number_due_date") > 1, f.lit(True)).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_multi_conf",
        f.when(
            (f.col("LA_number_conf_date") > 1) | (f.col("AB_number_conf_date") > 1),
            f.lit(True),
        ).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_no_quantity_planned_indicator",
        f.when(f.col("quantity_planned") == 0, f.lit(True)).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_one_cent_price_indicator",
        f.when(f.col("net_price") == 0.01, f.lit(True)).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_one_currency_value_indicator",
        f.when(f.col("gross_value") == 1, f.lit(True)).otherwise(f.lit(False)),
    )
    .withColumn(
        "is_zero_price_indicator",
        f.when(
            (f.col("net_price") == 0) | (f.col("net_price").isNull()), f.lit(True)
        ).otherwise(f.lit(False)),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ### Transformation 5 PO Status Definition – Based on Document & History
# MAGIC
# MAGIC This logic builds the purchasing document status using:
# MAGIC - Internal document info (cancellation, final invoice, intraco, etc.)
# MAGIC - Delivery/invoice history from EKBE
# MAGIC - It handles nuanced cases and aligns with business status categories used in reporting

# COMMAND ----------

# STEP 1: Define status & sub status based on PO item internal information
# It concerns CANCELLED #1, IN PROGRESS #1, INVOICED #1, INVOICED #2, INVOICED #3 and TBD #1
po_status = po_info_final.withColumn(
    "status_from_document",
    f.when(f.col("deletion_indicator").isNotNull(), f.lit("10 - PO_Cancelled"))
    .when(f.col("qty_remaining") != 0, f.lit("11 - PO_Open"))
    .when(
        (
            (f.col("qty_remaining") == 0)
            & (f.col("is_zero_price_indicator") == f.lit(True))
        )
        | (f.col("associated_invoice_indicator") == "X")
        | (f.col("purchasing_document_type").isin(list_intraco_po_type)),
        f.lit("13 - PO_Invoiced"),
    )
    .otherwise(f.lit("TBD")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 6 - Merge PO Status with EKBE History
# MAGIC
# MAGIC This step merges the previously derived document-based status with the EKBE status.
# MAGIC It resolves conflicts and edge cases to produce the final `document_status` field used across reports.
# MAGIC

# COMMAND ----------

# STEP 3: Define a globe PO status and substatus mixing the 2
df_po_w_status = po_status.join(
    ekbe_df.withColumnsRenamed(
        {"Purchase_Doc": "PO_number", "Purchase_Item": "PO_item_number"}
    ),
    ["PO_number", "PO_item_number"],
    "left",
)

source_df = (
    df_po_w_status.withColumn(
        "document_status",
        f.when(
            (f.col("Status_from_Document") == "11 - PO_Open")
            & (f.col("status_from_history_as_today") == "13 - PO_Invoiced")
            & (f.col("EKPO_webre").isNull()),
            f.lit("13 - PO_Invoiced"),
        )
        .when(
            (f.col("Status_from_Document") == "TBD")
            & (f.col("status_from_history_as_today").isNotNull()),
            f.col("status_from_history_as_today"),
        )
        .otherwise(f.col("Status_from_Document")),
    )
    .withColumn(
        "document_status",
        f.when(
            (f.col("document_status") == "TBD")
            & (f.col("final_delivery_indicator") == "X"),
            f.lit("10 - PO_Cancelled"),
        ).otherwise(f.col("document_status")),
    )
    .withColumn(
        "document_status",
        f.when(
            (f.col("supplier_code").isin(list_provider_monthly_invoice))
            & (f.col("document_status") == "12 - PO_Received"),
            f.lit("13 - PO_Invoiced"),
        ).otherwise(f.col("document_status")),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 7 - Derive the Most Accurate Delivery/Completion Date
# MAGIC
# MAGIC This logic selects the most reliable date field among:
# MAGIC - Invoice/receipt from EKBE
# MAGIC - Confirmed delivery (EKES)
# MAGIC - Planned delivery (EKET)
# MAGIC
# MAGIC It also labels which source the selected date came from for transparency.

# COMMAND ----------

# STEP 4: Derive most accurate delivery or closing date for PO
# IMPROVE Factorize condition
source_df_accuracy = (
    source_df.withColumn(
        "most_accurate_date",
        f.when(
            f.col("Invoice_Receipt_document_date").isNotNull(),
            f.col("Invoice_Receipt_document_date"),
        )
        .when(
            f.col("goods_receipt_document_date").isNotNull(),
            f.col("goods_receipt_document_date"),
        )
        .when(f.col("LA_confirmation_date").isNotNull(), f.col("LA_confirmation_date"))
        .when(f.col("AB_confirmation_date").isNotNull(), f.col("AB_confirmation_date"))
        .when(
            f.col("delivery_date_planned").isNotNull(), f.col("delivery_date_planned")
        ),
    )
    .withColumn(
        "most_accurate_date_year",
        f.year(f.col("most_accurate_date")),
    )
    .withColumn(
        "most_accurate_date_selected",
        f.when(
            f.col("document_status") == "13 - PO_Invoiced",
            f.lit("invoice_receipt_date"),
        )
        .when(
            f.col("document_status") == "12 - PO_Received", f.lit("Goods_Receipt_Date")
        )
        .when(
            f.col("LA_confirmation_date").isNotNull(), f.lit("Noticed_Delivery_Date_LA")
        )
        .when(
            f.col("AB_confirmation_date").isNotNull(),
            f.lit("Confirmed_Delivery_Date_AB"),
        )
        .when(
            f.col("delivery_date_planned").isNotNull(), f.lit("Planned_Delivery_Date")
        )
        .otherwise(f.lit("No_Delivery_Date_Planned")),
    )
)

# Create columns from new dates and status:
# - delta in days between planned delivery dates and latest effective delivery date
# - deletion indicators
df_po_w_date = source_df_accuracy.withColumn(
    "planned_v_effective_delivery_date_delta",
    f.date_diff(f.col("goods_receipt_document_date"), f.col("delivery_date_planned")),
).withColumn(
    "is_simplified_deletion_indicator",
    f.when(
        f.col("document_status") == "10 - PO_Cancelled",
        f.lit(True),
    ).otherwise(f.lit(False)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# create primary key
df_w_pk = df_po_w_date.withColumn(
    "PO_item", f.concat_ws("-", f.col("PO_number"), f.col("PO_item_number"))
)

df_to_check = df_w_pk
col_pk = "PO_item"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for BOM table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="purchase_orders_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "supply_chain_procurement"
table = "purchase_orders_new"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_w_pk,
    mode="overwrite",
    overwrite_schema=True,
)
