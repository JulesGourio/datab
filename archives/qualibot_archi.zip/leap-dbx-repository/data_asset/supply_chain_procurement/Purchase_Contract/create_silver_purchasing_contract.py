# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE SILVER PURCHASING CONTRACT SAP
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the silver table on purchasing contract items with conditions. 
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Contract - SAP
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.a016_latest
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.konp_latest
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.ekko_latest
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.ekpo_latest
# MAGIC - {reference_read_env}_bronze.headers_sap.headers_sap_business_a016
# MAGIC - {reference_read_env}_bronze.headers_sap.headers_sap_business_konp
# MAGIC - {reference_read_env}_bronze.headers_sap.headers_sap_business_ekko
# MAGIC - {reference_read_env}_bronze.headers_sap.headers_sap_business_ekpo
# MAGIC
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.procurement_purchasing.purchasing_contract
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Imports

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f

# LEAP FUNCTION
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - **df_a016_raw** is the bronze latest A016 SAP table - Contract item
# MAGIC - **df_konp_raw** is the bronze latest KONP SAP table - Contract condition
# MAGIC - **df_ekko_raw** is the bronze latest EKKO SAP table - Purchasing document header (incl. contract document)
# MAGIC - **df_ekpo_raw** is the bronze latest EKPO SAP table - Purchasing document item (incl. contract document)
# MAGIC - **df_headers_a016** is the header of the SAP table A016
# MAGIC - **df_headers_konp** is the header of the SAP table KONP
# MAGIC - **df_headers_ekko** is the header of the SAP table EKKO
# MAGIC - **df_headers_ekpo** is the header of the SAP table EKPO
# MAGIC
# MAGIC

# COMMAND ----------

df_a016_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.a016_latest"
)

df_konp_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.konp_latest"
)

# Filter on bstyp = "K" to keep only contract as purchasing document 
df_ekko_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekko_latest"
).where(f.col("bstyp") == "K")

# Filter on bstyp = "K" to keep only contract as purchasing document 
df_ekpo_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekpo_latest"
).where(f.col("bstyp") == "K")

# COMMAND ----------

df_headers_a016 = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_a016"
)

df_headers_konp = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_konp"
)

df_headers_ekko = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekko_v2"
)

df_headers_ekpo = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_ekpo_v2"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 0 - Cleaning raw data

# COMMAND ----------

# Some date columns can have '00000000' as value (as yyyymmdd). This is not managed by table_utils.cast_columns_with_sap_business_headers, so we create a dedicated function.
# Define function
def replace_zeros_with_none(df, column_names):
    for col_name in column_names:
        df = df.withColumn(col_name, f.when(f.col(col_name) == '00000000', None).otherwise(f.col(col_name)))
    return df

def get_column_values_as_list(df, column_name):
    return [row[column_name] for row in df.select(column_name).collect()]

# COMMAND ----------

# Define variables with dataset to clean
headers_list = [df_headers_a016, df_headers_konp, df_headers_ekko, df_headers_ekpo]
df_row_list = [df_a016_raw, df_konp_raw, df_ekko_raw, df_ekpo_raw]

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Clean date like '00000000'

# COMMAND ----------

# Clean date like '00000000'
for i, header in enumerate(headers_list):
    date_cols = get_column_values_as_list(header.where(f.col("Format") == "date"), "Field")
    df_row_list[i] = replace_zeros_with_none(df_row_list[i], date_cols)

df_a016_raw = df_row_list[0]
df_konp_raw = df_row_list[1]
df_ekko_raw = df_row_list[2]
df_ekpo_raw = df_row_list[3]

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Clean double column regarding minus sign and delimitors

# COMMAND ----------

# Clean double column regarding minus sign and delimitors
for i, header in enumerate(headers_list):
    double_cols = get_column_values_as_list(header.where(f.col("Format") == "double"), "Field")
    for col in double_cols:
        df_row_list[i] = table_utils.transform_float_column(df_row_list[i], col)

df_a016_raw = df_row_list[0]
df_konp_raw = df_row_list[1]
df_ekko_raw = df_row_list[2]
df_ekpo_raw = df_row_list[3]

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Renaming columns

# COMMAND ----------

# add table name as prefix
df_a016_raw = table_utils.add_prefix_to_columns(df_a016_raw, "A016")
df_konp_raw = table_utils.add_prefix_to_columns(df_konp_raw, "KONP")
df_ekko_raw = table_utils.add_prefix_to_columns(df_ekko_raw, "EKKO")
df_ekpo_raw = table_utils.add_prefix_to_columns(df_ekpo_raw, "EKPO")

# check header schema
table_utils.check_schema_of_the_header_file(df_headers_a016)
table_utils.check_schema_of_the_header_file(df_headers_konp)
table_utils.check_schema_of_the_header_file(df_headers_ekko)
table_utils.check_schema_of_the_header_file(df_headers_ekpo)

# Rename from headers
df_a016_renamed = table_utils.rename_columns_with_sap_business_header(
    df_a016_raw, df_headers_a016
)
df_konp_renamed = table_utils.rename_columns_with_sap_business_header(
    df_konp_raw, df_headers_konp
)
df_ekko_renamed = table_utils.rename_columns_with_sap_business_header(
    df_ekko_raw, df_headers_ekko
)
df_ekpo_renamed = table_utils.rename_columns_with_sap_business_header(
    df_ekpo_raw, df_headers_ekpo
)

# Cast columns according to header
df_a016_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_a016_renamed, df_headers_a016
)
df_konp_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_konp_renamed, df_headers_konp
)
df_ekko_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_ekko_renamed, df_headers_ekko
)
df_ekpo_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_ekpo_renamed, df_headers_ekpo
)

# Rename ekko & ekpo for contract specifities as containing both contract & po
# adding payment term from EKKO and renaming it to contract_payment_term
df_ekko_renamed = df_ekko_renamed.withColumnsRenamed({
    'document_number': 'contract_number',
    'purchasing_document_date': 'contract_date',
    'purchasing_document_type': 'contract_type',
    'document_payment_term': 'contract_payment_term',
})
df_ekpo_renamed = df_ekpo_renamed.withColumnsRenamed({
    'document_number': 'contract_number',
    'document_material_group': 'contract_material_group',
})

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - Selecting columns

# COMMAND ----------

# Select columns to join from a016
col_to_select = [col for col in df_a016_renamed.columns if not col.startswith("A016")]
df_a016_renamed = df_a016_renamed.select(*col_to_select)

# Select columns to join from ekko
col_to_select = [col for col in df_ekko_renamed.columns if not col.startswith("EKKO")]
df_ekko_renamed = df_ekko_renamed.select(*col_to_select)

# Select columns to join from ekpo
col_to_select = [col for col in df_ekpo_renamed.columns if not col.startswith("EKPO")]
df_ekpo_renamed = df_ekpo_renamed.select(*col_to_select)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 3 - Cleaning renamed columns

# COMMAND ----------

# Remove leading zeros from material_number
df_ekpo_renamed = table_utils.remove_leading_zeros(df_ekpo_renamed, ["material_number"])

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Get contract item information

# COMMAND ----------

# Inner join with a016 is requested as we only want conditions attached to existing contract items
df_konp_transf = df_konp_renamed.join(
    df_a016_renamed,
    on=["condition_type", "condition_record_number"],
    how="inner"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Get purchasing document item information

# COMMAND ----------

# Inner join with ekpo as we only want conditions attached to existing contract in purchasing document
df_konp_transf = df_konp_transf.join(
    df_ekpo_renamed,
    on=["contract_number", "item_number"],
    how="inner"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr3 - Get purchasing document header information

# COMMAND ----------

df_konp_transf = df_konp_transf.join(
    df_ekko_renamed,
    on=["contract_number"],
    how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr4 - Add contract title and primary_key

# COMMAND ----------

# Define pk col name
pk_col = "purchasing_contract_id"

df_konp_transf = df_konp_transf.withColumn(
    "condition_title",
    f.concat_ws(
        "-",
        f.col("contract_number"),
        f.col("item_number"),
        f.col("material_number"),
        f.col("purchasing_organization"),
    ),
).withColumn(
    pk_col,
    f.concat_ws(
        "-",
        f.col("condition_title"),
        f.col("condition_record_number"),
        f.col("sequential_number_of_the_condition"),
        f.col("validity_end_date_of_the_condition_record"),
    ),
)

# Position pk in first position
new_order = [pk_col] + [c for c in df_konp_transf.columns if c != pk_col]
df_konp_transf = df_konp_transf.select(new_order)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "procurement_purchasing"
DESTINATION_TABLE = "purchasing_contract"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_konp_transf,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "silver_purchasing_contract_pk"
TABLE_PK_COLS = pk_col

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Change Log
# MAGIC 3Jul25 : retrieving payment term from EKKO and renaming it  to contract payment term
