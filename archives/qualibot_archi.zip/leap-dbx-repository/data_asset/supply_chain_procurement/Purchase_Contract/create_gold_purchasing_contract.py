# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE GOLD PURCHASING CONTRACT SAP
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the gold table from the silver table of purchasing contract items with conditions. 
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Purchasing contract
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.zmmproccommod_latest
# MAGIC - {pipeline_read_env}_silver.procurement_purchasing.purchasing_contract
# MAGIC - {reference_read_env}_gold.supply_chain.supplier_master_data_latest
# MAGIC - {reference_read_env}_gold.master_data.material
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.production.purchasing_contract
# MAGIC - {pipeline_write_env}_gold.production.purchasing_contract_exposed
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f

# LEAP FUNCTION
from leap_utils.data_asset import table_utils
from leap_utils.data_asset import amount_correction

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Input

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - **df_contract** is the silver Contract data asset
# MAGIC - **df_supplier** is the supplier master data exposed table (master_data domain)
# MAGIC - **df_material** is the gold latest exposed material master data

# COMMAND ----------

# MAGIC %md
# MAGIC ### DF purchasing contract version silver

# COMMAND ----------

df_contract = spark.read.table(
        f"{PIPELINE_READ_ENV}_silver.procurement_purchasing.purchasing_contract"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### DF supplier master data version gold

# COMMAND ----------

df_supplier = spark.read.table(
        f"{REFERENCE_READ_ENV}_gold.master_data.supplier_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### DF material master data version gold

# COMMAND ----------

df_material = spark.read.table(
        f"{REFERENCE_READ_ENV}_gold.master_data.material"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### DF commodity referential

# COMMAND ----------

df_bronze_commodity = spark.read.table(
  f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.zmmproccommod_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ### DP1 - Prepare commodity

# COMMAND ----------

df_commodity_prepared = df_bronze_commodity.select(
    f.col("matkl").alias("material_group_join"),
    f.col("sens").alias("direct_indirect"),
    f.col("commodity_l1").alias("commodity"),
    f.col("commodity_l2").alias("sub_commodity")
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr1 - Enrich: Enablement

# COMMAND ----------

df_contract = df_contract.withColumn(
    "contract_enablement",
    f.when(f.col("contract_type") == "ENAB", "ENABLE").otherwise("NOT ENABLE")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr2 - Enrich: Contract status

# COMMAND ----------

df_contract = (
    df_contract
    .withColumn(
        "contract_status",
        f.when(
            f.col("end_of_validity_period") < f.current_date(),
            "Obsolete"
        )
        .when(
            f.year(f.col("end_of_validity_period")) > (f.year(f.current_date()) + 5),
            "Over 5 next years"
        )
        .otherwise("Valid")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr3 - Enrich: Condition status

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 1. Year of validity

# COMMAND ----------

df_contract = df_contract.withColumns({
    "year_validity_end": f.year(f.col("validity_end_date_of_the_condition_record")),
    "year_validity_start": f.year(f.col("validity_start_date_of_the_condition_record")),
})

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 2. Deletion indicators as booleans

# COMMAND ----------

df_contract = (
  df_contract
  .withColumns({
    "is_condition_item_deleted": f.col("deletion_indicator_for_condition_item").isNotNull(),
    "is_contract_item_deleted": f.col("deletion_indicator").isNotNull(),
  })
  .drop(
    "deletion_indicator_for_condition_item",
    "deletion_indicator"
  )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 3. Condition status rule
# MAGIC Condition is valid if end year is within next 5 years otherwhise it is price comtinuity

# COMMAND ----------

df_contract = df_contract.withColumn(
    "condition_record_status",
    f.when(
        f.col("is_condition_item_deleted") |
        f.col("is_contract_item_deleted"),
        "Deleted",
    )
    .when(
        f.col("validity_end_date_of_the_condition_record") < f.current_date(),
        "Obsolete",
    )
    .when(
        (f.col("validity_start_date_of_the_condition_record") > f.current_date()) &
        (f.col("year_validity_end") <= f.year(f.current_date()) + 5),
        "Not yet valid",
    )
    .when(
        f.col("year_validity_end") > f.year(f.current_date()) + 5,
        "Price continuity"
    )
    .otherwise("Valid")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr4 - Enrich: Unit conversion
# MAGIC
# MAGIC We are calculating condition unit price in base or stock unit to be able to compare contract condition price with PO price in the same unit.
# MAGIC - condition_pricing_unit (KPEIN) is a ratio to manage decimal precision in SAP
# MAGIC - converting ratios (KUMNE & KUMZA and UMREN & UNREZ) are used to convert condition unit (eg, kg) to base or stock unit (eg, m²)

# COMMAND ----------

df_contract = df_contract.withColumn(
    "condition_unit_price",
    (
        f.col("condition_amount")
        / 
        f.when(
            f.col("condition_pricing_unit") == 0,
            1
        )
        .otherwise(
            f.col("condition_pricing_unit")
        )
        * 
        f.when(
            f.col("denominator_for_converting_condition_units_to_base_units") == 0,
            1,
        )
        .otherwise(
            f.col("denominator_for_converting_condition_units_to_base_units")
        )
        / 
        f.when(
            f.col("numerator_for_converting_condition_units_to_base_units") == 0,
            1,
        )
        .otherwise(
            f.col("numerator_for_converting_condition_units_to_base_units")
        )
        *
        f.when(
            f.col("denominator_for_conversion_of_order_unit_to_stock_unit") == 0,
            1
        )
        .otherwise(
            f.col("denominator_for_conversion_of_order_unit_to_stock_unit")
        )
        /
        f.when(
            f.col("numerator_for_conversion_of_order_unit_to_stock_unit") == 0,
            1
        )
        .otherwise(
            f.col("numerator_for_conversion_of_order_unit_to_stock_unit")
        )
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr5 - Enrich:  Correct amounts
# MAGIC In SAP, amounts have two decimals. However, amounts in some currencies have 3 digits.
# MAGIC In such case, the output table gives the wrong amount as it treats like if all amounts
# MAGIC have 2 digits. For example, an amount of 10,242TND is written 102,42 in the table we
# MAGIC extract from SAP. The number of digits per currency are in the table TCURX in SAP.
# MAGIC The aim of this function is to correct a column with amounts based on its currency
# MAGIC associated column and TCURX.

# COMMAND ----------

# Define amount and currency columns for amount correction and conversion
amount_col = "condition_unit_price"
currency_col = "document_currency"

# COMMAND ----------

df_contract = amount_correction.create_corrected_amounts(
    df=df_contract,
    amount_col=amount_col,
    currency_col=currency_col
).drop(
    amount_col
).withColumnRenamed(
    f"{amount_col}_corrected", amount_col
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr6 - Enrich: Currency conversion
# MAGIC As contract conditions can last over several years and to insure we can compare all prices in same currency we will convert Prices with EUR budget rate for the current year disregarding the period when the contract condition price was effective.

# COMMAND ----------

# Upload Gold Currency to convert all prices in EUR and search for the latest date available
df_currency = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.currency_exchange")
max_validity_date = df_currency.agg({"Validity_Date_DateFormat": "max"}).collect()[0][0]

# Create currency_conversion_date column in df_contract to be used in currency conversion
df_contract = df_contract.withColumn(
    "currency_conversion_date",
    f.lit(max_validity_date)
)

# Uses try_cast to safely cast the column to double, returning NULL for any malformed input
df_contract = df_contract.withColumn(
    "condition_unit_price",
    f.expr("try_cast(`condition_unit_price` AS float)")
)

# COMMAND ----------

# Define conversion parameters
rate_types = ["Budget"]
rate_dates = ["currency_conversion_date"]
target_currency_value = "EUR"

# Apply currency conversion
df_contract = table_utils.currency_conversion(
        df=df_contract,
        document_currency_column=f.col(currency_col),
        rate_types=rate_types,
        rate_dates=[f.col(col) for col in rate_dates],
        target_currency_value=target_currency_value,
        document_amounts=[f.col(amount_col)],
        df_currency=df_currency,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr7 - Join: Material information
# MAGIC - Description
# MAGIC - Material_group
# MAGIC - Commodity
# MAGIC - Sub-Commodity
# MAGIC - Direct/Indirect

# COMMAND ----------

select_material_cols = [
    "material_number",
    "material_description",
    f.col("material_group").alias("mat_material_group")
]

df_contract = df_contract.join(
    df_material.select(select_material_cols),
    on="material_number",
    how="left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr8 - Join: Supplier information
# MAGIC - Name
# MAGIC - Long Name
# MAGIC - intercompany_flow_indicator

# COMMAND ----------

select_supplier_cols = [
    "supplier_code",
    "supplier_name",
    "intercompany_flow",
    "merchandise_group",
]

df_contract = df_contract.join(
    df_supplier
    .select(select_supplier_cols)
    .dropDuplicates(["supplier_code"]),
    on=["supplier_code"],
    how="left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr9 - Enrich with commodity

# COMMAND ----------

# For items with material, use document material group then material master group
# For items without material, use supplier merchandise group (business will ensure full coverage)
df_contract = df_contract.withColumn(
  "material_group_join",
  f.when(
    f.col("material_number").isNotNull(),
    f.coalesce(f.col("contract_material_group"), f.col("mat_material_group"))
  ).otherwise(f.col("merchandise_group"))
)

df_contract = df_contract.join(
  df_commodity_prepared,
  ["material_group_join"],
  "left"
).drop("material_group_join", "merchandise_group")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr10 - Enrich: Contract gold primary_key and order

# COMMAND ----------

# Define pk col name
pk_col = "purchasing_contract_id"

# Position pk in first position
new_order = [pk_col] + [c for c in df_contract.columns if c != pk_col]
df_contract = df_contract.select(new_order)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "procurement_purchasing"
DESTINATION_TABLE = "purchasing_contract"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_contract,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

# Select columns for exposed
select_statement =  ', '.join(c for c in df_contract.columns if not (c.startswith('KONP')))

table_utils.create_table_view(
    src_full_tablename=DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename=f"{DESTINATION_TABLE_FULL_PATH}_exposed",
    select_statement=select_statement,
    replace_view=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_purchasing_contract_pk"
TABLE_PK_COLS = pk_col

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
