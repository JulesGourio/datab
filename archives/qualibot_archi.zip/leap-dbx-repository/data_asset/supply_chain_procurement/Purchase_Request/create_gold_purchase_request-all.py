# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a stack gold for Purchase Request
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_gold.master_data.purchase_request_all 
# MAGIC
# MAGIC **Input :**  
# MAGIC   - {READ_ENV}_gold.master_data.purchase_request_sap_exposed   
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC   - Create_gold_purchase_request_sap
# MAGIC
# MAGIC **Things to do:** 
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable 
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable 
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md 
# MAGIC #Import Gold Table

# COMMAND ----------

#  Upload Gold table for Purchase Requisition from SAP
df_gold_pr = spark.read.table(
    f"{READ_ENV}_gold.supply_chain_procurement.purchase_request_sap_exposed"
)  
#  Upload Gold table for Purchase Requisition from DA/DI
#df_plant = spark.read.table(
    #f"{READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
#)  
df_gold_pr = df_gold_pr.withColumn("DataSource",f.lit("SAP"))

# COMMAND ----------

# MAGIC %md 
# MAGIC #Stack Gold Table Purchase Request

# COMMAND ----------

#Nothing to do // Waiting aquisition DA/DI from Sharepoint

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold Company Master Data Table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "supply_chain_procurement"
table = "purchase_request_all"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_gold_pr,
    mode="overwrite",
    overwrite_schema=True
)
