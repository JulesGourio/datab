# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # PURCHASE ORDERS HISTORY
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to create a silver history table for Purchase orders.
# MAGIC The notebook performs the following tasks:
# MAGIC
# MAGIC - Data Loading: Loads the bronze tables containing the raw data eban, ebkn, marc
# MAGIC - Data Loading : Loads the gold table wbs_otp_exposed
# MAGIC - Date Formatting: Formats the date column to a desired format.
# MAGIC - Column Renaming: Renames specific columns to be exposed
# MAGIC - Stack & Match of extraction_timestamp column for tables eban, ebkn, marc
# MAGIC - if run_mode = delta , stack&match on all extraction_timestamp , else stack&match on one extraction_timestamp per week
# MAGIC - Table Joining : Join eban to ebkn, then join to marc and wbs_otp_exposed
# MAGIC - Silver Table Creation: Generates a silver table with the cleaned and transformed data.
# MAGIC - Historization done on field : extraction_date based on EBAN_extraction_timestamp
# MAGIC
# MAGIC **widgets:**
# MAGIC - "run_mode", default="delta", possibles_values=["init_complete", "init_partial", "delta"]
# MAGIC -      when run_mode is ["delta"] then processing stack history in delta update
# MAGIC -      when run_mode is ["init_partial"] then stack history is appended based on init_from and init_to widgets and history changelog is initialized
# MAGIC -      when run_mode in ["init_complete"] then stack history and history changelog are initialized
# MAGIC - "run_changelog", default="delta", possibles_values=["init", "delta", "none"]
# MAGIC -      when run_changelog is ["none"] then notebook is exited without processing history changelog
# MAGIC -      when run_changelog is ["delta"] and run_mode is ["delta"] then processing history changelog in delta update
# MAGIC -      when run_changelog is ["init"] or when run_mode in ["init_complete", "init_partial"] then initialize history changelog
# MAGIC - "init_from", default="1970-01-01"  - used when run_mode is ["init_partial"] or ["delta"]
# MAGIC - "init_to", default="2099-12-31"  - used when run_mode is ["init_partial"] or ["delta"]
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - Stack and match of extraction_timestamp of several tables
# MAGIC - Join stacks, write/append the stack_history
# MAGIC - calculate history_changelog and save/merge to final table
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Purchase_Requests_Daily
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - Update : Daily
# MAGIC   - History : Once (exceptionally more)
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.eban_stack
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.ebkn_stack
# MAGIC   - {reference_read_env}_bronze.sap_latecoere_ecc6.marc_stack
# MAGIC   - {reference_read_env}_gold.finance.wbs_otp_exposed
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_eban
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_ebkn
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC   - {pipeline_write_env}_silver.supply_chain_procurement.purchase_request_sap_stack_history
# MAGIC   - {pipeline_write_env}_silver.supply_chain_procurement.purchase_request_sap_history_changelog
# MAGIC
# MAGIC **Output Files Pipeline**
# MAGIC N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC - renaming column WBS_Code to WBS for compatibility with old PR Data Asset while it is WBS_Code in WBS data asset
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
from pyspark.sql.utils import AnalysisException
from pyspark.sql.window import Window
from pyspark.sql import DataFrame as SparkDataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Spark
# MAGIC

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC ```
# MAGIC ```
# MAGIC #### functions used from "leap_utils.data_asset.table_utils"
# MAGIC ```
# MAGIC table_utils.add_prefix_to_columns()
# MAGIC table_utils.UnityCatalogCheckTableExists()
# MAGIC table_utils.drop_duplicates_by_order()
# MAGIC table_utils.get_columns_for_insertion_after_column()
# MAGIC table_utils.rename_columns_with_sap_business_header()
# MAGIC table_utils.cast_columns_with_sap_business_headers()
# MAGIC table_utils.create_unity_catalog_table
# MAGIC table_utils.set_table_column_not_null()
# MAGIC table_utils.add_table_primary_key()
# MAGIC table_utils.save_table()
# MAGIC table_utils.create_table_view()
# MAGIC table_utils.merge_into()
# MAGIC ```
# MAGIC
# MAGIC #### functions used from leap_utils.common.validation.gx_validation
# MAGIC ```
# MAGIC gx_validation.validate_and_log_gx_results()
# MAGIC ```
# MAGIC
# MAGIC #### functions used from "leap_utils.data_asset.history_changelog"
# MAGIC ```
# MAGIC history_changelog.initialize_history_changelog()
# MAGIC history_changelog.calculate_history_changelog_delta_update()
# MAGIC ```

# COMMAND ----------

from leap_utils.data_asset import table_utils, history_changelog
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.data_asset import amount_correction

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("init_from", "1970-01-01")  # history/update
INIT_FROM = dbutils.widgets.get("init_from")

dbutils.widgets.text("init_to", "2099-12-31")  # history/update
INIT_TO = dbutils.widgets.get("init_to")

dbutils.widgets.dropdown(
    "run_mode", "delta", ["init_complete", "init_partial", "delta"]
)
RUN_MODE = dbutils.widgets.get("run_mode")

dbutils.widgets.dropdown(
    "run_changelog", "delta", ["init", "delta", "none"]
)  # init, delta update or don't do
RUN_CHANGELOG = dbutils.widgets.get("run_changelog")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "debug")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables Location
# MAGIC
# MAGIC Details on how to read the input tables

# COMMAND ----------

BRONZE_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6"
HEADERS_SCHEMA = f"{REFERENCE_READ_ENV}_bronze.headers_sap"
GOLD_FINANCE_SCHEMA = f"{REFERENCE_READ_ENV}_gold.finance"

# SAP table EBAN - Purchase Request
t_eban_stack = f"{BRONZE_SCHEMA}.eban_stack"
# SAP table EBKN - Purchase Request Imputation
t_ebkn_stack = f"{BRONZE_SCHEMA}.ebkn_stack"
# SAP table MARC - Material Master Data
t_marc_stack = f"{BRONZE_SCHEMA}.marc_stack"
#  SAP table PRPS - WBS Master Data
t_wbs_latest = f"{GOLD_FINANCE_SCHEMA}.wbs_otp_exposed"

# SAP business header
t_name_eban = f"{HEADERS_SCHEMA}.headers_sap_business_eban"
t_name_ebkn = f"{HEADERS_SCHEMA}.headers_sap_business_ebkn"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_SCHEMA = f"{PIPELINE_WRITE_ENV}_silver.supply_chain_procurement"
TABLE_DEST_STACK = f"{SILVER_SCHEMA}.purchase_request_sap_stack_history"
TABLE_DEST_HCL = f"{SILVER_SCHEMA}.purchase_request_sap_history_changelog"


# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# MAGIC %md
# MAGIC #### for the History Stacked

# COMMAND ----------

# Columns needed to create the empty table at first run
TABLE_DEST_STACK_FIRST_COLS = {
    "PR_Number": "STRING",
    "PR_Item_Number": "STRING",
    "Start_Validity": "DATE",
}

# As it's a huge table, we'll cluster it by these columns, rather than partitioning
TABLE_DEST_STACK_CLUSTER_COLS = "PR_Number,PR_Item_Number,Start_Validity"
TABLE_DEST_STACK_PK_COLS = "PR_Number,PR_Item_Number,Start_Validity"


# COMMAND ----------

# MAGIC %md
# MAGIC #### for the History Changelog

# COMMAND ----------

TABLE_DEST_HCL_PK_COLUMNS_LIST = [
    "PR_Number",
    "PR_Item_Number",
]  # PRIMARY KEY OF THE LATEST (aka id_column_list)
TIMELINE_COL = "Start_Validity"
TABLE_DEST_HCL_SK_COLUMNS_LIST = TABLE_DEST_HCL_PK_COLUMNS_LIST + [
    TIMELINE_COL
]  # SURROGATE KEY , PRIMARY KEY OF THE HISTORY

# As it's a huge table, we'll cluster it by these columns, rather than partitioning
TABLE_DEST_HCL_CLUSTER_COLS_STR = "PR_Number,PR_Item_Number,Start_Validity,End_Validity"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# MAGIC %md
# MAGIC #### Common global variables

# COMMAND ----------

# Sample reference date when target table exists ans is empty
THE_ORIGIN = "1970-01-01"
THE_MAX_DATE = "2099-12-31"

# TIME DELTA ALLOWANCE in hours , for stack&match of extraction_timestamps(s)
TIME_DELTA_ALLOWANCE = f.make_dt_interval(hours=f.lit(8))

# DAYS DELTA ALLOWANCE in days , for stack&match of extraction_timestamps(s)
DAYS_DELTA_ALLOWANCE = f.make_dt_interval(days=f.lit(7))

# Flag to avoid processing Empty Dataframe
EMPTY_DATAFRAME_FLAG = False

# COMMAND ----------

# MAGIC %md
# MAGIC #### Analyzing widget RUN_MODE and set global variables

# COMMAND ----------

if (table_utils.UnityCatalogCheckTableExists(TABLE_DEST_STACK)) and (
    RUN_MODE == "delta"
):
    MODE = "append"
    # INIT_FROM and INIT_TO taken from widgets
    RUN_JOB_ON_LATEST = True
elif (table_utils.UnityCatalogCheckTableExists(TABLE_DEST_STACK)) and (
    RUN_MODE == "init_partial"
):
    MODE = "append"
    # INIT_FROM and INIT_TO taken from widgets
    RUN_JOB_ON_LATEST = False
elif RUN_MODE == "init_partial":
    MODE = "overwrite"
    # INIT_FROM and INIT_TO taken from widgets
    RUN_JOB_ON_LATEST = False
elif RUN_MODE == "init_complete":
    MODE = "overwrite"
    RUN_JOB_ON_LATEST = False
    INIT_FROM = THE_ORIGIN
    INIT_TO = THE_MAX_DATE
else:
    MODE = "overwrite"
    RUN_JOB_ON_LATEST = False
    INIT_FROM = THE_ORIGIN
    INIT_TO = THE_MAX_DATE


# COMMAND ----------

# MAGIC %md
# MAGIC #### Analyzing widget RUN_CHANGELOG and set global variables

# COMMAND ----------

if RUN_CHANGELOG not in ["init", "delta", "none"] or RUN_CHANGELOG == "none":
    DO_CHANGELOG = False
    RUN_CHANGELOG_ON_LATEST = None
elif RUN_CHANGELOG == "delta":
    DO_CHANGELOG = True
    RUN_CHANGELOG_ON_LATEST = True
else:
    DO_CHANGELOG = True
    RUN_CHANGELOG_ON_LATEST = False

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"RUN_MODE is:  {RUN_MODE}")
log.info(f"RUN_CHANGELOG is:  {RUN_CHANGELOG}")
log.info(f"RUN_JOB_ON_LATEST is:  {RUN_JOB_ON_LATEST}")
log.info(f"DO_CHANGELOG is:  {DO_CHANGELOG}")
log.info(f"RUN_CHANGELOG_ON_LATEST is:  {RUN_CHANGELOG_ON_LATEST}")
log.info(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"TIME_DELTA_ALLOWANCE is:  {TIME_DELTA_ALLOWANCE} hours")
log.info(f"DAYS_DELTA_ALLOWANCE is:  {DAYS_DELTA_ALLOWANCE} days")
log.info(f"TABLE_DEST_STACK is:  {TABLE_DEST_STACK}")
log.info(f"MODE is:  {MODE}")
log.info(f"TABLE_DEST_HCL is:  {TABLE_DEST_HCL}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Read tables
# MAGIC - Stack and match

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Tables TABLES & headers

# COMMAND ----------

# Upload SAP table EBAN - Purchase Request
df_eban = (
    spark.read.table(f"{t_eban_stack}")
    .filter(f.col("extraction_timestamp") >= INIT_FROM)
    .filter(f.col("extraction_timestamp") <= INIT_TO)
)
df_eban = table_utils.add_prefix_to_columns(df_eban, "EBAN")

# Upload SAP table EBKN - Purchase Request Imputation
df_ebkn = (
    spark.read.table(f"{t_ebkn_stack}")
    .filter(f.col("extraction_timestamp") >= INIT_FROM)
    .filter(f.col("extraction_timestamp") <= INIT_TO)
)
df_ebkn = table_utils.add_prefix_to_columns(df_ebkn, "EBKN")

# Upload SAP table MARC - Material Master Data
df_marc = (
    spark.read.table(f"{t_marc_stack}")
    .filter(f.col("extraction_timestamp") >= INIT_FROM)
    .filter(f.col("extraction_timestamp") <= INIT_TO)
)
df_marc = table_utils.add_prefix_to_columns(df_marc, "MARC")

# Upload table - WBS Master Data
df_wbs = spark.read.table(f"{t_wbs_latest}")

# Upload SAP headers
df_name_eban = spark.read.table(f"{t_name_eban}")
df_name_ebkn = spark.read.table(f"{t_name_ebkn}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Repartition Tables by aufnr

# COMMAND ----------

df_eban = df_eban.repartition("EBAN_banfn")
df_ebkn = df_ebkn.repartition("EBKN_banfn")
df_marc = df_marc.repartition("MARC_matnr")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - If RUN_JOB_ON_LATEST Filter all tables on needed stacks

# COMMAND ----------

# check job type - Filter all tables on needed stacks
if RUN_JOB_ON_LATEST:
    log.info(f"Processing Delta Dataset.")
    df_target = spark.read.table(TABLE_DEST_STACK)

    # 1) Dernière Start_Validity connue dans la silver (DATE)
    latest_in_silver = df_target.select(
        f.max("Start_Validity").alias("Max_Start_Validity")
    ).first()[0]

    if latest_in_silver is None:
        latest_in_silver = THE_ORIGIN
        log.info(
            f"latest_extraction_date is None -> using THE_ORIGIN = {latest_in_silver}"
        )
    else:
        log.info(f"latest_extraction_date in silver = {latest_in_silver}")

    # 2) Calcul des 2 derniers jours EBAN (niveau DATE)
    # Récupérer le dernier timestamp EBAN (spark utilise les stats / partitions)
    last_2_ts = spark.sql(
        f"select distinct(extraction_timestamp) from {t_eban_stack} order by 1 desc limit 2"
    ).collect()
    timestamps = [row[0] for row in last_2_ts]
    if len(timestamps) == 2:
        same_day_twice = timestamps[0].date() == timestamps[1].date()
    else:
        same_day_twice = True

    # 3) Décision : +1 jour ou pas
    if same_day_twice:
        # PAS de +1 -> sinon on saute un jour complet
        effective_latest = f.lit(latest_in_silver)
        log.info("Deux dernières extractions EBAN = même journée -> pas de +1 jour.")
    else:
        # +1 jour uniquement si on change réellement de date
        effective_latest = f.date_add(f.lit(latest_in_silver), 1)
        _v = spark.range(1).select(effective_latest.alias("d")).first()["d"]
        log.info(f"Deux extractions sur jours DIFFÉRENTS -> +1 jour -> { _v }")

    # Filter EBAN & EBKN  on delta loads , not MARC because is weekly and we may miss loads
    df_eban = df_eban.filter(f.col("EBAN_extraction_timestamp") > effective_latest)
    df_ebkn = df_ebkn.filter(f.col("EBKN_extraction_timestamp") > effective_latest)

    if df_eban.isEmpty():
        log.info(f"the table {TABLE_DEST_STACK} is already up to date")
        EMPTY_DATAFRAME_FLAG = True
else:
    log.info(f"Processing {RUN_MODE} from {INIT_FROM} to {INIT_TO}.")

log.debug(f"STACK HISTORY WRITE MODE is:  {MODE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Filter MARC cols

# COMMAND ----------

# Filter cols of MARC
df_marc_filtered = df_marc.select(
    "MARC_extraction_timestamp", "MARC_ID", "MARC_matnr", "MARC_werks", "MARC_prctr"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Persist result

# COMMAND ----------

# Persist Dataframe if we run on full stacks
# if (not RUN_JOB_ON_LATEST):
#     df_eban.persist()
#     df_ebkn.persist()
#     df_marc_filtered.persist()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Stack & Match extraction_timestamp(s)

# COMMAND ----------

# Retrieve Extraction timestamps
eban_timestamps = (
    df_eban.select(
        f.col("EBAN_extraction_timestamp").alias("EBAN_extraction_timestamp")
    )
    .distinct()
    .sort("EBAN_extraction_timestamp")
)
ebkn_timestamps = (
    df_ebkn.select(
        f.col("EBKN_extraction_timestamp").alias("EBKN_extraction_timestamp")
    )
    .distinct()
    .sort("EBKN_extraction_timestamp")
)
marc_timestamps = (
    df_marc_filtered.select(
        f.col("MARC_extraction_timestamp").alias("MARC_extraction_timestamp")
    )
    .distinct()
    .sort("MARC_extraction_timestamp")
)

# COMMAND ----------

# Join xxxx_timestamps and remove incomplete extractions (only allow a certain interval of TIME_DELTA_ALLOWANCE hours between two extractions)
pr_timestamps = eban_timestamps.hint("range_join", 60).join(
    ebkn_timestamps,
    on=(
        eban_timestamps.EBAN_extraction_timestamp
        >= (ebkn_timestamps.EBKN_extraction_timestamp - TIME_DELTA_ALLOWANCE)
    )
    & (
        eban_timestamps.EBAN_extraction_timestamp
        < (ebkn_timestamps.EBKN_extraction_timestamp + TIME_DELTA_ALLOWANCE)
    ),
    how="left",
)
pr_timestamps = pr_timestamps.dropna()

# Add extraction_date
pr_timestamps = pr_timestamps.withColumn(
    "extraction_date", f.to_date(f.col("EBAN_extraction_timestamp"))
)

# Add extraction_date_week_number
pr_timestamps = table_utils.add_week_number(pr_timestamps, "extraction_date")

# Drop dupplicates of date based on last occurence in case
pr_timestamps = table_utils.drop_duplicates_by_order(
    pr_timestamps,
    "extraction_date",
    [
        "EBAN_extraction_timestamp",
        "EBKN_extraction_timestamp",
    ],
    keep="last",
)

# Join xxxx_timestamps and remove incomplete extractions (only allow a certain interval of DAYS_DELTA_ALLOWANCE days between two extractions)
pr_timestamps = pr_timestamps.hint("range_join", 60).join(
    marc_timestamps,
    on=(
        pr_timestamps.EBAN_extraction_timestamp
        >= (marc_timestamps.MARC_extraction_timestamp - DAYS_DELTA_ALLOWANCE)
    )
    & (
        pr_timestamps.EBAN_extraction_timestamp
        < (marc_timestamps.MARC_extraction_timestamp + DAYS_DELTA_ALLOWANCE)
    ),
    how="left",
)

# Drop dupplicates of date based on first occurence in case
pr_timestamps = table_utils.drop_duplicates_by_order(
    pr_timestamps,
    "extraction_date",
    [
        "MARC_extraction_timestamp",
        "EBAN_extraction_timestamp",
        "EBKN_extraction_timestamp",
    ],
    keep="first",
)

if not RUN_JOB_ON_LATEST:
    # Keep one extraction_date per extraction_date_week_number , the last one that should fit the Sunday
    log.info(f"RUN_JOB_ON_LATEST is {RUN_JOB_ON_LATEST}, filter on weekly timestamps.")
    window_spec = Window.partitionBy("extraction_date_week_number").orderBy(
        f.col("extraction_date").desc()
    )
    pr_timestamps = pr_timestamps.withColumn("rank", f.row_number().over(window_spec))
    pr_timestamps = pr_timestamps.filter(f.col("rank") == 1).drop("rank")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Display Timestamps
# MAGIC
# MAGIC At this step we may want to print all timestamps, the final one being pr_timestamps
# MAGIC

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    display(pr_timestamps)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 5 - Filter EBAN on common extraction_date

# COMMAND ----------

# filter eban with incomplete extraction by doing an inner join with pr_timestamps
df_eban = (
    df_eban.join(
        f.broadcast(pr_timestamps).select(
            f.col("EBAN_extraction_timestamp"),
            f.col("extraction_date").alias("EBAN_extraction_date"),
        ),
        on="EBAN_extraction_timestamp",
        how="inner",
    )
    .withColumnRenamed("EBAN_extraction_timestamp", "EBAN_extraction_timestamp_1")
    .withColumnRenamed("EBAN_extraction_date", "EBAN_extraction_date_1")
)

# Move "EBAN_extraction_timestamp" and "EBAN_extraction_date" columns
df_eban = (
    df_eban.withColumns(
        {
            "EBAN_extraction_timestamp": f.col("EBAN_extraction_timestamp_1"),
            "EBAN_extraction_date": f.col("EBAN_extraction_date_1"),
        },
    ).select(
        *table_utils.get_columns_for_insertion_after_column(
            df_eban,
            search_column_name="EBAN_ID",
            insert_columns=["EBAN_extraction_date", "EBAN_extraction_timestamp"],
        )
    )
).drop("EBAN_extraction_timestamp_1", "EBAN_extraction_date_1")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 6 - Filter EBKN on common extraction_date

# COMMAND ----------

# filter ebkn with incomplete extraction by doing an inner join with pr_timestamps
df_ebkn = (
    df_ebkn.join(
        f.broadcast(pr_timestamps).select(
            f.col("EBKN_extraction_timestamp"),
            f.col("extraction_date").alias("EBKN_extraction_date"),
        ),
        on="EBKN_extraction_timestamp",
        how="inner",
    )
    .withColumnRenamed("EBKN_extraction_timestamp", "EBKN_extraction_timestamp_1")
    .withColumnRenamed("EBKN_extraction_date", "EBKN_extraction_date_1")
)

# Move "EBKN_extraction_timestamp" and "EBKN_extraction_date" columns
df_ebkn = (
    df_ebkn.withColumns(
        {
            "EBKN_extraction_timestamp": f.col("EBKN_extraction_timestamp_1"),
            "EBKN_extraction_date": f.col("EBKN_extraction_date_1"),
        },
    ).select(
        *table_utils.get_columns_for_insertion_after_column(
            df_ebkn,
            search_column_name="EBKN_ID",
            insert_columns=["EBKN_extraction_date", "EBKN_extraction_timestamp"],
        )
    )
).drop("EBKN_extraction_timestamp_1", "EBKN_extraction_date_1")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 7 - Filter MARC on common extraction_date

# COMMAND ----------

# filter marc with incomplete extraction by doing an inner join with pr_timestamps
df_marc_filtered = (
    df_marc_filtered.join(
        f.broadcast(pr_timestamps).select(
            f.col("MARC_extraction_timestamp"),
            f.col("extraction_date").alias("MARC_extraction_date"),
        ),
        on="MARC_extraction_timestamp",
        how="inner",
    )
    .withColumnRenamed("MARC_extraction_timestamp", "MARC_extraction_timestamp_1")
    .withColumnRenamed("MARC_extraction_date", "MARC_extraction_date_1")
)

# Move "MARC_extraction_timestamp" and "MARC_extraction_date" columns
df_marc_filtered = (
    df_marc_filtered.withColumns(
        {
            "MARC_extraction_timestamp": f.col("MARC_extraction_timestamp_1"),
            "MARC_extraction_date": f.col("MARC_extraction_date_1"),
        },
    ).select(
        *table_utils.get_columns_for_insertion_after_column(
            df_marc_filtered,
            search_column_name="MARC_ID",
            insert_columns=["MARC_extraction_date", "MARC_extraction_timestamp"],
        )
    )
).drop("MARC_extraction_timestamp_1", "MARC_extraction_date_1")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 8 - Filter WBS fields

# COMMAND ----------

# Filtering table WBS before join - renaming WBS_Code for compatibility with old PR Data Asset
df_wbs = df_wbs.select("WBS_Code_Num", "WBS_Code").withColumnRenamed("WBS_Code", "WBS")


# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations for Stacked history
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------


# Delete rows when field is null
def delete_null_rows(df_names: SparkDataFrame) -> SparkDataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# --------------------------------------------------------------------------------------------------------------


# Move a List of Columns in first cols of Dataframe
def move_dataframe_cols_first(df: SparkDataFrame, cols_to_move: list) -> SparkDataFrame:
    """Move columns from the list cols_to_move in first columns of Dataframe"""
    first_cols = cols_to_move
    other_cols = [c for c in df.columns if c not in first_cols]
    df_new = df.select(*first_cols, *other_cols)
    return df_new


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Renaming Headers

# COMMAND ----------

## Renaming headers EBAN
# Call function Check Header files
table_utils.check_schema_of_the_header_file(df_name_eban)
# Call Function Delete rows null
df_name_eban = delete_null_rows(df_name_eban)
# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_eban, df_name_eban
)
# Call Funtion Create Columns on Date format
df_eban = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_eban
)
# -----------------------------------------------------------------------------------
## Renaming headers EBKN
# Call function Check Header files
table_utils.check_schema_of_the_header_file(df_name_ebkn)
# Call Function Delete rows null
df_name_ebkn = delete_null_rows(df_name_ebkn)
# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_ebkn, df_name_ebkn
)
# Call Funtion Create Columns on Date format
df_ebkn = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_ebkn
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Join EBAN to EBKN

# COMMAND ----------

# Join Stack EBAN left join EBKN
df_join_eban_ebkn = df_eban.join(
    df_ebkn,
    on=(df_eban.PR_Number == df_ebkn.Purchase_Request)
    & (df_eban.PR_Item_Number == df_ebkn.Purchase_Request_Item)
    & (df_eban.EBAN_extraction_date == df_ebkn.EBKN_extraction_date),
    how="left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Join to MARC

# COMMAND ----------

# Join Stack EBAN/EBKN left join MARC
df_join_eban_ebkn_marc = df_join_eban_ebkn.join(
    df_marc_filtered,
    on=(df_join_eban_ebkn.Material_Number == df_marc_filtered.MARC_matnr)
    & (df_join_eban_ebkn.Plant_Delivered == df_marc_filtered.MARC_werks)
    & (df_join_eban_ebkn.EBAN_extraction_date == df_marc_filtered.MARC_extraction_date),
    how="left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Join to WBS

# COMMAND ----------

# Join Stack EBAN/EBKN/MARC left join WBS
df_join_pr = df_join_eban_ebkn_marc.join(
    df_wbs,
    on=(df_join_eban_ebkn_marc.WBS_Element == df_wbs.WBS_Code_Num),
    how="left",
)
df_join_pr = (
    df_join_pr.drop(
        "Purchase_Request",
        "Purchase_Request_Item",
        "MARC_matnr",
        "MARC_werks",
        "WBS_Element",
        "WBS_Code_Num",
    ).withColumn(
        "Profit_Center",
        f.when(f.col("MARC_prctr").isNull(), f.col("Profit_Center")).otherwise(
            f.col("MARC_prctr")
        ),
    )
).drop("MARC_prctr")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 5 - Using function in order to make correction on Net_Price

# COMMAND ----------

df_join_pr = amount_correction.create_corrected_amounts(
    df_join_pr, "Net_Price", "Document_Currency"
)
df_join_pr = df_join_pr.drop("Net_Price")
df_join_pr = df_join_pr.withColumnRenamed("Net_Price_corrected", "Net_Price")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 6 - Dropping and renaming columns

# COMMAND ----------

df_join_end = df_join_pr.drop(
    "EBKN_extraction_date",
    "MARC_extraction_date",
).withColumnRenamed("EBAN_extraction_date", "Start_Validity")

# COMMAND ----------

## 1st Step, keep only value comminf from SAP tables
# Drop Columns linked to ingestion process
strings_to_drop = [
    "file_name",
    "file_mode",
    "table_name",
    "file_modification_time",
    "ingestion_timestamp",
    "extraction_timestamp",
]

columns_to_drop = [
    col_name
    for col_name in df_join_end.columns
    if any(substring.lower() in col_name.lower() for substring in strings_to_drop)
]
df_join_end = df_join_end.drop(*columns_to_drop)
# Manual Drop to avoid error with string 'id'
df_join_end = df_join_end.drop("EBKN_ID", "EBAN_ID", "MARC_ID")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 7 - Cleansing raw data

# COMMAND ----------

# Formatting Material_Number without '0' on left side
df_purchase_request_format = df_join_end.withColumn(
    "Material_Number", f.regexp_replace(df_join_end.Material_Number, "^0+", "")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 8 - Optimize order of Columns

# COMMAND ----------

first_cols = ["PR_Number", "PR_Item_Number", "Start_Validity"]
df_stack_history = move_dataframe_cols_first(df_purchase_request_format, first_cols)

# COMMAND ----------

# MAGIC %md
# MAGIC # Persist result

# COMMAND ----------

if RUN_JOB_ON_LATEST == False:
    df_stack_history.persist()
    df_eban.unpersist()
    df_ebkn.unpersist()
    df_marc_filtered.unpersist()

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - Uniqueness
# MAGIC
# MAGIC N/A

# COMMAND ----------

### Quality checks on the stacked table takes too long

# # Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
# dfgx_In1_prep = SparkDFDataset(df_stack_history, persist=False)

# # Define the red quality checks
# table_dest_pk_cols_list = TABLE_DEST_STACK_PK_COLS.split(",")
# red_quality_check_results = [
#     dfgx_In1_prep.expect_compound_columns_to_be_unique(
#         column_list=table_dest_pk_cols_list
#     )
# ]

# # Validate all red quality checks, if at least one fails the job stops
# gx_validation.validate_and_log_gx_results(
#     quality_check_results=red_quality_check_results,
#     validation_level="RED",
#     info_message=f"Compound cols {TABLE_DEST_STACK_PK_COLS} are unique",
#     error_message=f"Compound cols {TABLE_DEST_STACK_PK_COLS} are not unique, check the summary of this run",
# )

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Silver Stacked PR history

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver History Stacked Table

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by TABLE_DEST_STACK_CLUSTER_COLS
if not EMPTY_DATAFRAME_FLAG:
    catalog, schema, table = TABLE_DEST_STACK.split(".")

    try:
        table_utils.create_unity_catalog_table(
            catalog,
            schema,
            table,
            force_reinitialization=False,
            cluster_cols=TABLE_DEST_STACK_CLUSTER_COLS,
            partition_col=None,
            primary_key_cols=None,
            columns=TABLE_DEST_STACK_FIRST_COLS,
            force_drop=False,
        )
    except AnalysisException as e:
        log.error(
            f"Table {TABLE_DEST_STACK} has not been created, an error occured during creation. \nError is {e}"
        )
        raise Exception()

# COMMAND ----------

# Save the table from Dataframe df_stack_history, preserving cluster columns
if not EMPTY_DATAFRAME_FLAG:
    try:
        startTime = time.time()
        table_utils.save_table(
            dest_table=TABLE_DEST_STACK,
            df=df_stack_history,
            mode=MODE,
            overwrite_schema=True,
            cluster_cols=TABLE_DEST_STACK_CLUSTER_COLS,
            merge_schema=True,
        )
    except AnalysisException as e:
        log.error(
            f"Table {TABLE_DEST_STACK} has not been created, an error occured during table_utils.save_table . \nError is {e}"
        )
        raise Exception()
    else:
        duration = time.time() - startTime
        log.info(f"Table {TABLE_DEST_STACK} saved in {duration} seconds.")
        log.info(f"Wrote {df_stack_history.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations for history changelog
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exit if history changelog not asked

# COMMAND ----------

if not DO_CHANGELOG:
    dbutils.notebook.exit(
        f"Exiting without processing history changelog."
    )  # Quitter le notebook sans erreur

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read existing history changelog

# COMMAND ----------

if (
    (table_utils.UnityCatalogCheckTableExists(TABLE_DEST_HCL))
    and (RUN_JOB_ON_LATEST == True)
    and (RUN_CHANGELOG_ON_LATEST == True)
):
    log.info(f"Reading current history changelog table.")
    # Upload Silver Purchase Request History filtered on valid records
    df_purchase_request_silver_hist = spark.read.table(f"{TABLE_DEST_HCL}")
    log.debug(
        f"Current history changelog to update count {df_purchase_request_silver_hist.count()} rows."
    )
else:
    log.info(f"Reading current stacked history table.")
    df_purchase_request_silver_hist = None
    # Upload Silver Purchase Request History stacked
    df_stack_history = spark.read.table(f"{TABLE_DEST_STACK}")
    df_stack_history.persist()
    RUN_CHANGELOG_ON_LATEST = False

# COMMAND ----------

# MAGIC %md
# MAGIC ## Determine history changelog tracked columns list

# COMMAND ----------

prefixes = ["EBAN", "EBKN", "MARC"]
metadata_columns = [
    "file_name",
    "file_mode",
    "table_name",
    "file_modification_time",
    "ingestion_timestamp",
    "extraction_timestamp",
    "stack_row_id",
    "ID",
]
all_metadata_columns = [
    f"{prefix}_{column}" for prefix in prefixes for column in metadata_columns
] + metadata_columns

all_table_cols = df_stack_history.columns
validity_cols = ["Start_Validity", "End_Validity"]
prefixed_cols = [
    column
    for column in all_table_cols
    if (any(column.startswith(f"{prefix}_") for prefix in prefixes))
]
forced_included_cols = []
tracked_column_list = [
    column
    for column in all_table_cols
    if (column not in TABLE_DEST_HCL_PK_COLUMNS_LIST)
    and (column not in all_metadata_columns)
    and (column not in validity_cols)
    and (not column.startswith("_meta"))
    and (column not in prefixed_cols)
] + forced_included_cols

# COMMAND ----------

# MAGIC %md
# MAGIC ## Initialize or update history changelog

# COMMAND ----------

df_stack_history_meta = df_stack_history.withColumn(
    "_meta_sort_column", f.col("Start_Validity")
).drop("Start_Validity")

if (
    (table_utils.UnityCatalogCheckTableExists(TABLE_DEST_HCL))
    and (RUN_JOB_ON_LATEST == True)
    and (RUN_CHANGELOG_ON_LATEST == True)
):
    log.info(f"Processing update of the history changelog table.")
    df_purchase_request_silver_hist = df_purchase_request_silver_hist.withColumn(
        "_meta_sort_column", f.col("Start_Validity")
    )

    df_history_changelog = history_changelog.calculate_history_changelog_delta_update(
        df=df_stack_history_meta,
        df_existing_history_changelog=df_purchase_request_silver_hist,
        id_column_list=TABLE_DEST_HCL_PK_COLUMNS_LIST,
        sort_column="_meta_sort_column",
        tracked_column_list=tracked_column_list,
        data_extraction_mode="FULL",
        calculate_discontinuities=False,
    )

    df_history_changelog = table_utils.drop_duplicates_by_order(
        df=df_history_changelog,
        columns=TABLE_DEST_HCL_SK_COLUMNS_LIST,
        order_col="End_Validity",
        keep="last",
    )
else:
    log.info(f"Processing initialization of the history changelog table.")
    df_history_changelog = history_changelog.initialize_history_changelog(
        df=df_stack_history_meta,
        id_column_list=TABLE_DEST_HCL_PK_COLUMNS_LIST,
        sort_column="_meta_sort_column",
        tracked_column_list=tracked_column_list,
        data_extraction_mode="FULL",
        calculate_discontinuities=False,
    )

log.debug(f"History changelog count {df_stack_history.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optimize order of columns

# COMMAND ----------

first_cols = [
    "PR_Number",
    "PR_Item_Number",
    "Start_Validity",
    "End_Validity",
    "Deletion_Mark",
    "Status_treatment",
    "PO_Item_Description",
    "Material_Number",
    "Plant_Delivered",
    "Storage_Location",
    "from_plant",
    "Quantity_Request",
    "Delivery_Date",
    "Launching_Date",
    "Reception_Time",
]
df_history_changelog_ordered_cols = move_dataframe_cols_first(
    df_history_changelog, first_cols
)

# COMMAND ----------

# Replace "1900-01-01" by _meta_min_extraction_date
df_history_changelog_start = df_history_changelog_ordered_cols.withColumn(
    "Start_Validity",
    f.when(
        f.col("Start_Validity") == "1900-01-01", f.col("_meta_min_extraction_date")
    ).otherwise(f.col("Start_Validity")),
)

# Drop _meta column "_meta_sort_column" , others _meta are usefull
strings_to_drop = [
    "_meta_sort_column",
]

columns_to_drop = [
    col_name
    for col_name in df_history_changelog_start.columns
    if any(substring.lower() in col_name.lower() for substring in strings_to_drop)
]
df_history_changelog_final = df_history_changelog_start.drop(*columns_to_drop)

# COMMAND ----------

# MAGIC %md
# MAGIC #Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Silver Purchase Request history changelog

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver history changelog table

# COMMAND ----------

if (
    (table_utils.UnityCatalogCheckTableExists(TABLE_DEST_HCL))
    and (RUN_JOB_ON_LATEST == True)
    and (RUN_CHANGELOG_ON_LATEST == True)
):
    if not EMPTY_DATAFRAME_FLAG:
        # MERGE df_history_changelog_final INTO TABLE_DEST_HCL using columns of the SURROGATE KEY ("PR_Number","PR_Item_Number","Start_Validity")
        #       WHEN MATCHED AND (source.End_Validity <> target.End_Validity) THEN
        #           UPDATE SET *
        #       WHEN NOT MATCHED THEN
        #           INSERT *
        log.info(f"Merging new history changelog into table.")
        log.debug(
            f"Data to merge into history count {df_history_changelog_final.count()} rows."
        )
        startTime = time.time()
        try:
            table_utils.merge_into(
                df_source=df_history_changelog_final,
                target_table=TABLE_DEST_HCL,
                list_id_matching_columns=TABLE_DEST_HCL_SK_COLUMNS_LIST,
                matched_clause="(source.End_Validity <> target.End_Validity) or (source._meta_max_extraction_date <> target._meta_max_extraction_date)",
            ).display()
        except Exception as e:
            log.error(
                f"Table {TABLE_DEST_HCL} has not been created, an error occured during MERGE INTO."
            )
            all_target_cols = [
                x[0]
                for x in spark.sql(f"DESCRIBE {TABLE_DEST_HCL}")
                .select("col_name")
                .collect()
            ]
            log.error(f"Dataframe cols : {df_history_changelog_final.columns}\n----\n")
            log.error(f"Tables cols : {all_target_cols}\n----\n")
            log.error(f"Error : {e}")
            raise Exception()
        else:
            duration = time.time() - startTime
            log.info(f"Table {TABLE_DEST_HCL} merged in {duration} seconds.")
    else:
        log.info(f"No change to merge.")
else:
    log.info(f"Saving new history changelog table.")
    try:
        table_utils.save_table(
            dest_table=TABLE_DEST_HCL,
            df=df_history_changelog_final,
            mode="overwrite",
            overwrite_schema=True,
            cluster_cols=TABLE_DEST_HCL_CLUSTER_COLS_STR,
            merge_schema=True,
        )
    except Exception as e:
        log.error(
            f"Table {TABLE_DEST_HCL} has not been created, an error occured during save."
        )
        log.error(f"Error : {e}")
        raise Exception()
    else:
        log.info(
            f"Data saved into history count {df_history_changelog_final.count()} rows."
        )

# COMMAND ----------

ANALYZE_TABLE_SQL = f"ANALYZE TABLE {TABLE_DEST_HCL} COMPUTE STATISTICS"
spark.sql(ANALYZE_TABLE_SQL)
