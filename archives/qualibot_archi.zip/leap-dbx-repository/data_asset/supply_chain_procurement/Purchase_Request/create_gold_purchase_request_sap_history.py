# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # PURCHASE ORDERS HISTORY
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a Gold & Gold exposed table for Purchase Request history and latest.
# MAGIC
# MAGIC The notebook performs the following tasks:
# MAGIC
# MAGIC - Data Loading: Loads the silver changelog history table
# MAGIC - Add plant, company and supplier information
# MAGIC - Apply business rules
# MAGIC
# MAGIC **widgets:**
# MAGIC - "run_mode", default="delta", possibles_values=["init", "delta"]
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - Update changelog history
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Purchase_Requests_Daily
# MAGIC
# MAGIC **Triggered by:**
# MAGIC   - Update : Daily
# MAGIC   - History : Once (exceptionally more)
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC   - {pipeline_read_env}_silver.supply_chain_procurement.purchase_request_sap_history_changelog
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC   - {reference_read_env}_gold.master_data.company_master_data_latest_exposed  
# MAGIC   - {reference_read_env}_gold.master_data.plant_master_data_latest_exposed
# MAGIC   - {reference_read_env}_gold.supply_chain.supplier_master_data_latest_exposed
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC   - {pipeline_write_env}_gold.supply_chain_procurement.purchase_request_sap
# MAGIC   - {pipeline_write_env}_gold.supply_chain_procurement.purchase_request_sap_exposed
# MAGIC   - {pipeline_write_env}_gold.supply_chain_procurement.purchase_request_sap_history_changelog
# MAGIC   - {pipeline_write_env}_gold.supply_chain_procurement.purchase_request_sap_history_changelog_exposed
# MAGIC
# MAGIC
# MAGIC **Output Files Pipeline**
# MAGIC N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql import Window
from typing import List, Dict
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Spark
# MAGIC

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC ```
# MAGIC ```
# MAGIC #### functions used from "leap_utils.data_asset.table_utils"
# MAGIC ```
# MAGIC table_utils.UnityCatalogCheckTableExists()
# MAGIC table_utils.save_table()
# MAGIC table_utils.create_table_view()
# MAGIC table_utils.merge_into()
# MAGIC ```
# MAGIC
# MAGIC #### functions used from leap_utils.common.validation.gx_validation
# MAGIC ```
# MAGIC gx_validation.validate_and_log_gx_results()
# MAGIC ```
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.dropdown("run_mode", "delta", ["init", "delta"])
RUN_MODE = dbutils.widgets.get("run_mode")

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "debug")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables Location
# MAGIC
# MAGIC Details on how to read the input tables

# COMMAND ----------

SILVER_SCHEMA = f"{PIPELINE_READ_ENV}_silver.supply_chain_procurement"
GOLD_MASTER_DATA_SCHEMA = f"{PIPELINE_READ_ENV}_gold.master_data"
GOLD_SUPPLY_CHAIN_SCHEMA = f"{PIPELINE_READ_ENV}_gold.supply_chain"

# Upload PR Silver Table
t_silver_purchase_request = f"{SILVER_SCHEMA}.purchase_request_sap_history_changelog"

# Upload Gold Table for Plant Master Data
t_plant = f"{GOLD_MASTER_DATA_SCHEMA}.plant_master_data_latest_exposed"

#  Upload Gold Table for Supplier Master Data
t_supplier = f"{GOLD_SUPPLY_CHAIN_SCHEMA}.supplier_master_data_latest_exposed"

# Upload Gold Table for Company Master Data
t_company = f"{GOLD_MASTER_DATA_SCHEMA}.company_master_data_latest_exposed"


# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

GOLD_SCHEMA = f"{PIPELINE_WRITE_ENV}_gold.supply_chain_procurement"

TABLE_DEST_HCL = f"{GOLD_SCHEMA}.purchase_request_sap_history_changelog"
TABLE_DEST_LATEST = f"{GOLD_SCHEMA}.purchase_request_sap"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# As it's a huge table, we'll cluster it by these columns, rather than partitioning
CLUSTER_COLS_STR = "PR_Number,PR_Item_Number,Start_Validity,End_Validity"

PK_COLUMNS_LIST = ["PR_Number", "PR_Item_Number"]  # PRIMARY KEY OF THE LATEST (aka id_column_list)
TIMELINE_COL = "Start_Validity"
SK_COLUMNS_LIST = PK_COLUMNS_LIST + [TIMELINE_COL]  # SURROGATE KEY , PRIMARY KEY OF THE HISTORY

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

if (table_utils.UnityCatalogCheckTableExists(TABLE_DEST_HCL)) and (
    RUN_MODE == "delta"
):
    RUN_JOB_ON_LATEST = True
else:
    RUN_JOB_ON_LATEST = False

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs 
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.info(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")
log.info(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.info(f"RUN_MODE is:  {RUN_MODE}")
log.info(f"RUN_JOB_ON_LATEST is:  {RUN_JOB_ON_LATEST}")
log.info(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.info(f"GOLD_SCHEMA is:  {GOLD_SCHEMA}")
log.info(f"TABLE_DEST_HCL is:  {TABLE_DEST_HCL}")
log.info(f"TABLE_DEST_LATEST is:  {TABLE_DEST_LATEST}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Read tables
# MAGIC - Stack and match

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Tables TABLES & headers

# COMMAND ----------

# Upload purchase_request Silver Table
log.info(f"Reading current Silver history changelog table.")
df_silver_purchase_request = spark.read.table(f"{t_silver_purchase_request}")

# Upload Gold Table for Plant Master Data
df_plant = spark.read.table(f"{t_plant}")

#  Upload Gold Table for Supplier Master Data
df_supplier = spark.read.table(f"{t_supplier}")

# Upload Gold Table for Company Master Data
df_company = spark.read.table(f"{t_company}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - If RUN_JOB_ON_LATEST Filter silver history table

# COMMAND ----------

# check job type
if RUN_JOB_ON_LATEST == True:
    log.info(f"Filtering current silver history changelog table.")
    df_target = spark.read.table(f"{TABLE_DEST_HCL}")
    # Filter silver history for rows that are not in the target
    df_silver_purchase_request_update = (
        df_silver_purchase_request.alias("A")
        .join(
            df_target.alias("B"),
            (f.col("A.PR_Number") == f.col("B.PR_Number")) & (f.col("A.PR_Item_Number") == f.col("B.PR_Item_Number")) & (f.col("A.Start_Validity") == f.col("B.Start_Validity")) & (f.col("A.End_Validity") == f.col("B.End_Validity")),
            "left_anti",
        )
    )
    log.debug(f"Current history changelog to update count {df_silver_purchase_request_update.count()} rows.")
    df_target.unpersist()

    if df_silver_purchase_request_update.isEmpty():
        dbutils.notebook.exit(
            f"the table {TABLE_DEST_HCL} is already up to date"
        )  # Quitter le notebook sans erreur
else:
    log.info(f"Reading full silver history changelog table.")
    RUN_JOB_ON_LATEST = False
    df_silver_purchase_request_update = df_silver_purchase_request
    log.debug(f"Full history changelog count {df_silver_purchase_request_update.count()} rows.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Management of Company MD

# COMMAND ----------

# Add Company Master Data
df_company = df_company.select(
    "Company",
    "Company_Description",
    "Currency",
    "Company_Entity",
    "Country_Code",
    "Country",
)
df_company = (
    df_company.withColumnRenamed("Company", "Company_")
    .withColumnRenamed("Currency", "Company_Currency")
    .withColumnRenamed("Country_Code", "Company_Country_Code")
    .withColumnRenamed("Country", "Company_Country")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Management of Plant MD

# COMMAND ----------

df_plant = df_plant.select("Plant", "Company", "Plant_Description_new", "Id_Calendar")
df_plant = df_plant.withColumnRenamed("Plant_Description_new", "Plant_Description")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Management of Supplier MD

# COMMAND ----------

# Add Supplier Master Data
df_supplier = df_supplier.select(
    "Supplier_Code",
    "Supplier_Name",
    "Spend_Category",
    "Purch_Organization",
    "Payment_Term",
    "Intercompany_flow",
    "Incoterm_Code",
    "Incoterm_Detail",
    "Supplier_Category",
    "Supplier_country",
)
df_supplier = df_supplier.withColumnRenamed(
    "Supplier_Code", "Supplier_Code_"
).withColumnRenamed("Purch_Organization", "Purch_Organization_")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Add information for Plant Company and Supplier

# COMMAND ----------

df_join_silver = (
    df_silver_purchase_request_update.alias("A")
    .join(df_plant.alias("B"), f.col("A.Plant_Delivered") == f.col("B.Plant"), "left")
    .join(df_company.alias("C"), f.col("B.Company") == f.col("C.Company_"), "left")
    .drop("Plant_Delivered", "Company_")
)

df_join_end = (
    df_join_silver.alias("A")
    .join(
        df_supplier.alias("B"),
        (
            (f.col("A.Supplier_Code") == f.col("B.Supplier_Code_"))
            & (f.col("A.Purchase_Organization") == f.col("B.Purch_Organization_"))
        ),
        "left",
    )
    .drop("Supplier_Code_", "Purch_Organization_")
)
df_join_end = df_join_end.withColumnRenamed("Company", "Company_Code")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Business enrichment

# COMMAND ----------

# Determination of PR Status
df_end = df_join_end.withColumn(
    "Status",
    f.when(
        (f.col("Status_treatment") == "B") & (f.col("PO_Quantity_Creation") > 0),
        f.lit("PR_Converted"),
    )
    .when(
        (f.col("Deletion_Mark").isNull()) & (f.col("PR_Closed").isNull()),
        f.lit("PR_Open"),
    )
    .otherwise(f.lit("PR_Cancelled")),
)

# Management of PR non Affected
df_end = df_end.withColumn(
    "Supplier_Name",
    f.when(f.col("Supplier_Name").isNull(), f.lit("Non_Affected")).otherwise(
        f.col("Supplier_Name")
    ),
)

# Calcul Of Amount in Standard price
df_end = df_end.withColumn(
    "Amount_Standard_Price",
    f.col("Net_Price") / f.col("Price_Base") * f.col("Quantity_Request"),
)

df_end = df_end.withColumn(
    "Material_Number", f.regexp_replace(df_end.Material_Number, "^0+", "")
)  # <-Cleansing Material Number
df_end = df_end.withColumn(
    "Profit_Center", f.regexp_replace(df_end.Profit_Center, "^0+", "")
)  # <-Cleansing Material Number

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - 
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Gold PR history changelog

# COMMAND ----------

df_purchase_request_history = df_end

if RUN_JOB_ON_LATEST:
    log.info(f"Merging new History Changelog into table.")
    # MERGE df_purchase_request_history INTO TABLE_DEST_HCL using columns of the SURROGATE KEY ("PR_Number","PR_Item_Number","Start_Validity")
    #       WHEN MATCHED AND (source.End_Validity <> target.End_Validity) THEN
    #           UPDATE SET *
    #       WHEN NOT MATCHED THEN
    #           INSERT *
    log.debug(
        f"Data to merge into history count {df_purchase_request_history.count()} rows."
    )
    startTime = time.time()
    try:
        table_utils.merge_into(
            df_source=df_purchase_request_history,
            target_table=TABLE_DEST_HCL,
            list_id_matching_columns=SK_COLUMNS_LIST,
            matched_clause="(source.End_Validity <> target.End_Validity) or (source._meta_max_extraction_date <> target._meta_max_extraction_date)",
        ).display()
    except Exception as e:
        log.error(
            f"Table {TABLE_DEST_HCL} has not been created, an error occured during MERGE INTO."
        )
        all_target_cols = [
            x[0]
            for x in spark.sql(f"DESCRIBE {TABLE_DEST_HCL}")
            .select("col_name")
            .collect()
        ]
        log.error(f"Dataframe cols : {df_purchase_request_history.columns}\n----\n")
        log.error(f"Tables cols : {all_target_cols}\n----\n")
        log.error(f"Error : {e}")
        raise Exception()
    else:
        duration = time.time() - startTime
        log.info(f"Table {TABLE_DEST_HCL} merged in {duration} seconds.")
else:
    log.info(f"Saving new History Changelog table.")
    try:
        table_utils.save_table(
            dest_table=TABLE_DEST_HCL,
            df=df_purchase_request_history,
            mode="overwrite",
            overwrite_schema=True,
            cluster_cols=CLUSTER_COLS_STR,
            merge_schema=True,
        )
    except Exception as e:
        log.error(
            f"Table {TABLE_DEST_HCL} has not been created, an error occured during save."
        )
        log.error(f"Error : {e}")
        raise Exception()
    else:
        log.info(
            f"Data saved into history count {df_purchase_request_history.count()} rows."
        )

# COMMAND ----------

ANALYZE_TABLE_SQL = f"ANALYZE TABLE {TABLE_DEST_HCL} COMPUTE STATISTICS"
spark.sql(ANALYZE_TABLE_SQL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Gold PR history changelog exposed

# COMMAND ----------

src_full_tablename = f"{TABLE_DEST_HCL}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "EBAN"
Begin_By2 = "EBKN"
Begin_By3 = "_meta"

selected_columns = [
    col
    for col in df_purchase_request_history.columns
    if not col.startswith(Begin_By) and not col.startswith(Begin_By2) and not col.startswith(Begin_By3)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Gold PR latest

# COMMAND ----------

if RUN_JOB_ON_LATEST:
    # if delta update we reload the HCL and filter only on End_validity "9999-12-31" in order to have only latest value
    df_purchase_request_latest = spark.read.table(f"{TABLE_DEST_HCL}").filter(f.col("End_validity") == "9999-12-31")
else:
    # if initialisation we filter only on End_validity "9999-12-31" in order to have only latest value
    df_purchase_request_latest = df_end.filter(f.col("End_validity") == "9999-12-31")

# dropping "Start_Validity", "End_validity" for compatibility with old PR Data asset
df_purchase_request_latest = df_purchase_request_latest.drop("Start_Validity", "End_validity")

log.info(f"Saving new gold latest table.")
result = table_utils.save_table(
    dest_table=TABLE_DEST_LATEST,
    df=df_purchase_request_latest,
    mode="overwrite",
    overwrite_schema=True,
    merge_schema=True,
)
log.info(
    f"Data saved into latest count {df_purchase_request_latest.count()} rows."
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Create Gold PR latest exposed

# COMMAND ----------

src_full_tablename = f"{TABLE_DEST_LATEST}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "EBAN"
Begin_By2 = "EBKN"
Begin_By3 = "_meta"

selected_columns = [
    col
    for col in df_purchase_request_latest.columns
    if not col.startswith(Begin_By) and not col.startswith(Begin_By2) and not col.startswith(Begin_By3)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced
