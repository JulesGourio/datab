# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The purpose of this notebook is to build silver dadi dataset 
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - `{WRITE_ENV}_silver.supply_chain_procurement.dadi_{table_name}`
# MAGIC
# MAGIC **Input :**  
# MAGIC   - `{WRITE_ENV}_bronze.dadi.{table_name}_latest` 
# MAGIC   - `{HEADER_READ_ENV}_bronze.headers_others.headers_business_dadi` 
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> Ingestion raw data dadi
# MAGIC
# MAGIC **Things done:** 
# MAGIC - rename fields
# MAGIC - clean fields
# MAGIC

# COMMAND ----------

# DBTITLE 1,Input variables
dbutils.widgets.text("pipeline_write_env", "dev")
WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
READ_ENV = dbutils.widgets.get("pipeline_read_env")

# COMMAND ----------

# DBTITLE 1,Librairies
import logging
from pyspark.sql.types import StructType, StructField, StringType
from typing import List
from pyspark.sql import SparkSession
from pyspark.sql import DataFrame as SparkDataFrame
import pyspark.sql.functions as f

## Upload LEAP Utils
from leap_utils.data_asset import table_utils

# COMMAND ----------

# DBTITLE 1,Global variables
# Global variables
DEBUG = False
BRONZE_SCHEMA = f"{READ_ENV}_bronze.dadi"
SILVER_SCHEMA = f"{WRITE_ENV}_silver.supply_chain_procurement"
HEADER_READ_ENV = "prod"

# COMMAND ----------

# DBTITLE 1,Set up logger
import logging
from pyspark.sql.utils import AnalysisException
from leap_utils.common.logger import get_logger, setup_applevel_logger

setup_applevel_logger(log_level=logging.INFO, file_log_level=logging.INFO)

log = get_logger(module_name=__name__)

# COMMAND ----------

# MAGIC %md 
# MAGIC #Functions

# COMMAND ----------

# DBTITLE 0,Functions
# Check Header from Manual Input file
def check_schema_of_the_file(df_names: SparkDataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: SparkDataFrame) -> SparkDataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# --------------------------------------------------------------------------------------------------------------

# Rename Columns according to a word to replace by another
def rename_column_names(df, old_word, new_word):
    for col_name in df.columns:
        if old_word in col_name:
            new_col_name = col_name.replace(old_word, new_word)
            df = df.withColumnRenamed(col_name, new_col_name)
    return df


# --------------------------------------------------------------------------------------------------------------

# Explode column values when containing key;#value in a string format
def extract_column_values(
    df: SparkDataFrame, column_dict: dict, separator=";#"
) -> SparkDataFrame:
    """
    Explode column values when containing key;#value in a string format
    Clean special characters in values
    """
    for old_col, new_col in column_dict.items():
        # Vérifie que la nouvelle colonne n'existe pas déjà
        if new_col in df.columns:
            continue

        if not old_col in df.columns:
            continue

        # Ceci supprime la clé et le séparateur en début de colonne
        df = df.withColumn(
            new_col,
            f.when(f.col(old_col).isNull(), f.col(old_col)).otherwise(
                f.regexp_replace(f.col(old_col), rf"^\d+{separator}", "")
            ),
        )

        # Ceci supprime les clés suivantes et sépare les différentes valeurs par un "|"
        df = df.withColumn(
            new_col,
            f.when(
                f.col(new_col) != "NULL",
                f.regexp_replace(f.col(new_col), rf"{separator}(\d+{separator})", "|"),
            ).otherwise(f.col(new_col)),
        )

        # Ceci supprime les caractères spéciaux : "string", ";", ","
        df = df.withColumn(
            new_col,
            f.when(
                f.col(new_col) != "NULL",
                f.regexp_replace(
                    f.regexp_replace(f.col(new_col), rf"string{separator}", ""),
                    rf"[,;]",
                    "",
                ),
            ).otherwise(f.col(new_col)),
        )

        # Supprime la colonne d'origine
        df = df.drop(old_col)

    return df

# COMMAND ----------

# DBTITLE 0,Function to save table
def create_unity_catalog_table(table_path: str, force_reinitialization: bool) -> None:
    """
    Function for creating a unity catalog if it does not exist. Also possible to reinitialize the table
    if :param force_reinitialization: is set to True

    :param table_path: Unity catalog path
    :type table_path: str
    :param force_reinitialization: Whether to reinitialize the table or not
    :type force_reinitialization: bool
    """
    # Create table if it does not exist
    spark.sql(f"CREATE TABLE IF NOT EXISTS {table_path} USING DELTA")

    # Force reinitialization is param is True
    if force_reinitialization == True:
        spark.sql(f"DELETE FROM {table_path} ")
        log.info(f"Table {table_path} has been reinitialized")

# COMMAND ----------

# MAGIC %md
# MAGIC # Upload business headers

# COMMAND ----------

table_headers = f"{HEADER_READ_ENV}_bronze.headers_others.headers_business_dadi"
df_headers = spark.read.table(f"{table_headers}")

# Check header table
check_schema_of_the_file(df_headers)  # <- call function Check Header files
df_headers = delete_null_rows(df_headers)  # <- Call Function Delete rows null

# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Applications Table

# COMMAND ----------

table_applications = f"{BRONZE_SCHEMA}.applications_latest"
df_applications = spark.read.table(
    f"{table_applications}"
)  # <- Upload DADI Applications table

# COMMAND ----------

# MAGIC %md
# MAGIC # Renaming Applications Table columns

# COMMAND ----------

# Remove unwanted prefix
df_applications = rename_column_names(df_applications, "LAT_WFDA_", "")

# Add table prefix to columns
df_applications = table_utils.add_prefix_to_columns(
    df_applications, "APPL"
)  # <- Renaming starting with APPL_

# COMMAND ----------

# MAGIC %md
# MAGIC # Cleaning raw data
# MAGIC ## Extract Applications columns values
# MAGIC - remove sharepoint internal keys and keeping values
# MAGIC - remove "string", ","
# MAGIC ## Clean column LinkTitle : 
# MAGIC - keep 2 first Characters only (DA, DP)

# COMMAND ----------

# Columns to extract
column_dict = {
    "APPL_UniqueId": "UniqueId",
    "APPL_Division": "Division",
    "APPL_Branche": "Branche",
    "APPL_Societe": "Societe",
    "APPL_GroupeMarch": "GroupeMarch",
    "APPL_Perimetre": "Perimetre",
    "APPL_StatutCode": "StatutCode",
    "APPL_StatutLib": "StatutLib",
    "APPL_Author": "Author",
    "APPL_ApprobCourant": "ApprobCourant",
    "APPL_Approvisionneur": "Approvisionneur",
    "APPL_Invites": "Invites",
    "APPL_FSObjType": "FSObjType",
    "APPL_FileLeafRef": "FileLeafRef",
    "APPL_FileRef": "FileRef",
}
df_applications_new = extract_column_values(df_applications, column_dict)

# Remove unwanted prefix
df_applications_new = rename_column_names(df_applications_new, "APPL_", "")

# Add table prefix to columns
df_applications_new = table_utils.add_prefix_to_columns(
    df_applications_new, "APPL"
)  # <- Renaming starting with APPL_
df_applications_new = rename_column_names(df_applications_new, "APPL__", "APPL_")

# Clean column LinkTitle : keep 2 first Characters only
df_applications_new = df_applications_new.withColumn(
    "APPL_LinkTitle", f.substring(f.col("APPL_LinkTitle"), 1, 2)
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding business headers to Application table

# COMMAND ----------

# Call Function Rename Columns according header file
df_applications_column_names = table_utils.rename_columns_with_sap_business_header(
    df_applications_new, df_headers
)

# COMMAND ----------

# Cast columns to desired type
df_applications_silver = table_utils.cast_columns_with_sap_business_headers(
    df_applications_column_names, df_headers
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Items Table

# COMMAND ----------

table_items = f"{BRONZE_SCHEMA}.items_latest"
df_items = spark.read.table(f"{table_items}")  # <- Upload DADI Items table

# COMMAND ----------

# MAGIC %md
# MAGIC # Renaming Items Table columns

# COMMAND ----------

# Remove unwanted prefix
df_items = rename_column_names(df_items, "LAT_WFDA_", "")

# COMMAND ----------

# Add table prefix to columns
df_items = table_utils.add_prefix_to_columns(
    df_items, "ITEM"
)  # <- Renaming starting with ITEM_

# COMMAND ----------

# MAGIC %md
# MAGIC # Cleaning raw data
# MAGIC ## Extract Items columns values
# MAGIC ## remove sharepoint internal keys and keeping values
# MAGIC ## remove "string", ","

# COMMAND ----------

# Convert and cast the column "Demande" to bigint as new column DA_ID

# Columns to extract
column_dict = {
    "ITEM_Demande": "ITEM_Demande_str",
}
df_items_new = extract_column_values(df_items, column_dict)

df_items_new = df_items_new.withColumn(
    "ITEM_DA_ID", f.col("ITEM_Demande_str").cast("bigint")
)
df_items_new = df_items_new.drop("ITEM_Demande_str")

# COMMAND ----------

# Convert other columns

# Columns to extract
column_dict = {
    "ITEM_UniqueId": "UniqueId",
    "ITEM_CentreCout": "CentreCout",
    "ITEM_CompteCompt": "CompteCompt",
    "ITEM_Monnaie": "Devise",
    "ITEM_UniteGest": "UniteGest",
    "ITEM_Libelle": "Libelle",
    "ITEM_OetCode": "OetCode",
    "ITEM_OtpCode": "OtpCode",
    "ITEM_Commentaire": "Commentaire",
    "ITEM_FSObjType": "FSObjType",
    "ITEM_FileRef": "FileRef",
    "ITEM_MetaInfo": "MetaInfo",
}
df_items_new = extract_column_values(df_items_new, column_dict)

# Remove unwanted prefix
df_items_new = rename_column_names(df_items_new, "ITEM_", "")

# Add table prefix to columns
df_items_new = table_utils.add_prefix_to_columns(
    df_items_new, "ITEM"
)  # <- Renaming starting with ITEM_
df_items_new = rename_column_names(df_items_new, "ITEM__", "ITEM_")

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding business headers to Items table

# COMMAND ----------

# Call Function Rename Columns according header file
df_items_column_names = table_utils.rename_columns_with_sap_business_header(
    df_items_new, df_headers
)

# COMMAND ----------

# Cast columns to desired type
df_items_silver = table_utils.cast_columns_with_sap_business_headers(
    df_items_column_names, df_headers, "yyyy-MM-dd HH:mm:ss"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Save Silver Tables

# COMMAND ----------

# Save as delta table
table_applications_silver = f"{SILVER_SCHEMA}.dadi_applications"
create_unity_catalog_table(
    table_path=table_applications_silver, force_reinitialization=False
)

table_utils.save_table(
    dest_table=table_applications_silver,
    df=df_applications_silver,
    mode="overwrite",
    overwrite_schema=True
)

log.info(f"Table {table_applications_silver} saved.\n--")

# COMMAND ----------

# Save as delta table
table_items_silver = f"{SILVER_SCHEMA}.dadi_items"
create_unity_catalog_table(table_path=table_items_silver, force_reinitialization=False)

table_utils.save_table(
    dest_table=table_items_silver,
    df=df_items_silver,
    mode="overwrite",
    overwrite_schema=True
)

log.info(f"Table {table_items_silver} saved.\n--")
