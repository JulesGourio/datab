# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose  
# MAGIC
# MAGIC **Description:**  
# MAGIC The purpose of this notebook is to build the gold dadi dataset 
# MAGIC  
# MAGIC **Output tables:**  
# MAGIC   - `{WRITE_ENV}_gold.supply_chain_procurement.dadi`
# MAGIC   - `{WRITE_ENV}_gold.supply_chain_procurement.dadi_exposed`
# MAGIC
# MAGIC **Input :**  
# MAGIC   - `{WRITE_ENV}_silver.supply_chain_procurement.dadi_{table_name}`
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC NoteBook -> Ingestion raw data dadi
# MAGIC
# MAGIC **Things done:** 
# MAGIC - join tables Applications and Items
# MAGIC

# COMMAND ----------

# DBTITLE 1,Input variables
dbutils.widgets.text("pipeline_write_env", "dev")
WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "prod")
READ_ENV = dbutils.widgets.get("pipeline_read_env")

# COMMAND ----------

# DBTITLE 1,Librairies
import logging
from pyspark.sql.types import StructType, StructField, StringType
from typing import List
from pyspark.sql import SparkSession
from pyspark.sql import DataFrame as SparkDataFrame
import pyspark.sql.functions as f
from leap_utils.data_asset import table_utils
from itertools import chain


# Global variables
DEBUG = False
SILVER_SCHEMA = f"{READ_ENV}_silver.supply_chain_procurement"
GOLD_SCHEMA = f"{WRITE_ENV}_gold.supply_chain_procurement"

# COMMAND ----------

# DBTITLE 1,Set up logger
import logging
from pyspark.sql.utils import AnalysisException
from leap_utils.common.logger import get_logger, setup_applevel_logger

setup_applevel_logger(log_level=logging.INFO, file_log_level=logging.INFO)

log = get_logger(module_name=__name__)

# COMMAND ----------

# MAGIC %md 
# MAGIC #Functions

# COMMAND ----------

# DBTITLE 1,Function to save table
def create_unity_catalog_table(table_path: str, force_reinitialization: bool) -> None:
    """
    Function for creating a unity catalog if it does not exist. Also possible to reinitialize the table
    if :param force_reinitialization: is set to True

    :param table_path: Unity catalog path
    :type table_path: str
    :param force_reinitialization: Whether to reinitialize the table or not
    :type force_reinitialization: bool
    """
    # Create table if it does not exist
    spark.sql(f"CREATE TABLE IF NOT EXISTS {table_path} USING DELTA")

    # Force reinitialization is param is True
    if force_reinitialization == True:
        spark.sql(f"DELETE FROM {table_path} ")
        log.info(f"Table {table_path} has been reinitialized")

# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Applications Table

# COMMAND ----------

table_applications = f"{SILVER_SCHEMA}.dadi_applications"
df_applications = spark.read.table(
    f"{table_applications}"
)  # <- Upload DADI Applications silver table

# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Items Table

# COMMAND ----------

table_items = f"{SILVER_SCHEMA}.dadi_items"
df_items = spark.read.table(f"{table_items}")  # <- Upload DADI Items silver table

# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Account group table

# COMMAND ----------

df_account_group = spark.read.table(f"{READ_ENV}_gold.finance.account_groups_exposed").select("Account_Number", "Account_Description")

# COMMAND ----------

# MAGIC %md
# MAGIC #Gold Enrichment

# COMMAND ----------

# applications inner join items 
# on applications.Id_DA (aka ID in the xml) = items.ITEM_DA_ID (aka LAT_WFDA_Demande in the xml)
df_join_dadi = df_applications.alias("A").join(
    df_items.alias("B"), (f.col("A.Id_DA") == f.col("B.ITEM_DA_ID")), "inner"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Translate code status, status description

# COMMAND ----------

translation_mapping_status_description = {
    "AN": "Cancelled",
    "AP": "To be approved for payment",
    "AR": "Acknowledged",
    "AVD": "To be approved by Management",
    "BES": "Need validated",
    "BP": "Ready to pay",
    "BUY": "To be approved for expense",
    "CL": "Closed",
    "DAG": "DAGG Done",
    "DEP": "Expense validated",
    "EC": "Handled",
    "NEW": "Approval pending",
    "REF": "Refused request",
    "SU": "Suspended",
    "TE": "Done",
    "VAL": "Validated request",
}

df_status_translated = df_join_dadi.withColumn(
    "status_description_translated", f.col("Status_Code")
).replace(
    to_replace=translation_mapping_status_description,
    subset=["status_description_translated"],
)

df_dadi_account = df_status_translated.withColumn(
    "Account_Number", f.split(f.col("Accounting_group"), " - ")[0]
)
df_account_group_clean = table_utils.remove_leading_zeros(
    df=df_account_group,
    column_names=[
        "Account_Number",
    ],
)

df_account_translated = (
    df_dadi_account.join(df_account_group_clean, on=["Account_Number"], how="left")
    .withColumn(
        "Accounting_group_translated",
        f.concat_ws(" - ", f.col("Account_Number"), f.col("Account_Description")),
    )
    .drop("Account_Description")
).withColumn(
    "Creation_date_DateFormat",
    f.to_date(
        f.to_timestamp(f.col("Creation_date"), "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Convert amount in Euro

# COMMAND ----------

df_dadi_currency_converted = table_utils.currency_conversion(
    df=df_account_translated,
    document_currency_column=f.col("Currency"),
    rate_types=["Budget"],
    rate_dates=["Creation_date_DateFormat"],
    target_currency_value="EUR",
    document_amounts=[f.col("Unit_price"), f.col("Budget")],
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Save Gold Table

# COMMAND ----------

# Save as delta table
table_dadi_gold = f"{GOLD_SCHEMA}.dadi"
create_unity_catalog_table(table_path=table_dadi_gold, force_reinitialization=False)

table_utils.save_table(
    dest_table=table_dadi_gold,
    df=df_dadi_currency_converted,
    mode="overwrite",
    overwrite_schema=True
)

log.info(f"Table {table_dadi_gold} saved.\n--")

# COMMAND ----------

# MAGIC %md
# MAGIC #Save gold_exposed view

# COMMAND ----------

def exposed_gold_table_latest(goldColumns):
    query = "CREATE OR REPLACE VIEW {}_gold.supply_chain_procurement.dadi_exposed as select {} from {}_gold.supply_chain_procurement.dadi;".format(
        WRITE_ENV, ", ".join(goldColumns), WRITE_ENV
    )

    print(query)

    query_results = spark.sql(str(query))

    display(query_results)
    return None

# COMMAND ----------

prefixes = ("APPL", "ITEM")
goldColumns = [col for col in df_dadi_currency_converted.columns if not col.startswith(prefixes)]

exposed_gold_table_latest(goldColumns)
