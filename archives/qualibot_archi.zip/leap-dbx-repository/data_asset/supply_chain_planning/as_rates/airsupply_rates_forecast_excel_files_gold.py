# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # AirSupply rates forecast excel files Gold
# MAGIC
# MAGIC **Description:**
# MAGIC The goal is to transform the silver table into a gold table by enriching it with data from another table.
# MAGIC
# MAGIC **gold goals**
# MAGIC - Join Profit Centres table
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC AS Rates Pipeline
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC   - {reference_read_env}_silver.airsupply.as_rates_forecast_silver
# MAGIC   - prod_gold.finance.profit_center_exposed
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC N/A
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.supply_chain_planning.as_rates_gold
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC     NA

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.window import Window


# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from leap_utils.common.validation import quality_checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Level

# COMMAND ----------

dbutils.widgets.text("bypass_quality_checks", "false")  # history/update
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = logger.LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# log = logger.get_logger(module_name=__name__)
# logger.setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logger.logging.INFO)

# log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}") #excluded because extraction isn't from pipeline

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "airsupply_rates_forecast_project"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Used to specify which folder Input data is housed in
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ####Input Files Config
# MAGIC Definition of files to ingest

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables Location
# MAGIC
# MAGIC Details on how to read the input tables

# COMMAND ----------

# Silver as rates forecast
t_silver_as_rates = f"{PIPELINE_READ_ENV}_silver.supply_chain_planning.as_rates_silver"

# Profit center data
df_profit_center = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables Location

# COMMAND ----------

TABLE_DEST = f"{PIPELINE_WRITE_ENV}_gold.supply_chain_planning.as_rates_gold"

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# Read landing zone table
df_silver_as_rates = spark.read.table(f"{t_silver_as_rates}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# MAGIC %md
# MAGIC ### S3 files import from folder
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# MAGIC %md
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Join profit centers data

# COMMAND ----------

df_gold = df_silver_as_rates.join(
    df_profit_center,
    df_silver_as_rates["Profit_Center"] == df_profit_center["profit_center"],
    "left",
).drop(
    "profit_center"
)  # Drops the duplicate column after the join


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Clean pc_attributed site column

# COMMAND ----------

df_gold = df_gold.withColumn(
    "PC_Attributed_Site",
    f.trim(
        f.regexp_replace(f.col("PC_Attributed_Site"), "\u00a0", " ")
    ),  # Replace the weird space with a regular one and trim
)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Add shortened metric column and column ranking

# COMMAND ----------

df_gold = df_gold.withColumn(
    "Metric_short",
    f.when(df_gold["metric"] == "Customer Forecast (CF)", "CF")
    .when(df_gold["metric"] == "Customer Orders (CO)", "CO")
    .when(df_gold["metric"] == "Consensus Demand Plan (CDP)", "CDP")
    .when(df_gold["metric"] == "Production Plan (PP)", "PP")
    .when(df_gold["metric"] == "MPS (SAP)", "SAP")
    .when(df_gold["metric"] == "Invoicing", "Inv")  # Shortened 'Invoicing'
    .when(df_gold["metric"] == "Budget", "Bud")  # Shortened 'Budget'
    .otherwise(None),
)

# COMMAND ----------

df_gold = df_gold.withColumn(
    "Metric_sort",
    f.when(df_gold["metric"] == "Customer Forecast (CF)", 1)
    .when(df_gold["metric"] == "Customer Orders (CO)", 2)
    .when(df_gold["metric"] == "Consensus Demand Plan (CDP)", 3)
    .when(df_gold["metric"] == "Production Plan (PP)", 4)
    .when(df_gold["metric"] == "MPS (SAP)", 5)
    .when(df_gold["metric"] == "Invoicing", 6)
    .when(df_gold["metric"] == "Budget", 7)
    .otherwise(None),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Cumulative values column

# COMMAND ----------

# Define the window to partition by upload_week, metric, and profit_center
window_spec = (
    Window.partitionBy("upload_year_week", "metric", "Profit_Center_short")
    .orderBy("date")
    .rowsBetween(Window.unboundedPreceding, 0)
)

# COMMAND ----------

df_gold = df_gold.withColumn("cumulative_quantity", f.sum("quantity").over(window_spec))


# COMMAND ----------

log.debug(display(df_gold))

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Check 1 -Row Count
# MAGIC Row count is expected to remain the same from silver.

# COMMAND ----------

# Validate row count remains the same
results_dict = {}
results_dict["airsupply_rates_forecast_excel_files_gold"] = (
    df_gold.count() == df_silver_as_rates.count()
)

# Log the results
validation_level = "RED" if not BYPASS_QUALITY_CHECKS else "AMBER"

quality_checks.validate_and_log_quality_check_results(
    results_dict=results_dict,
    validation_level=validation_level,
    info_message="The number of rows remains the same after the left join.",
    error_message="Row count mismatch after the left join, check the data sources.",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    expectation_type="validate_row_count_after_join",
    log_to_event_table=True,
    log_successes=True,
)


# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

table_utils.save_table(
    TABLE_DEST,
    df_gold,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
