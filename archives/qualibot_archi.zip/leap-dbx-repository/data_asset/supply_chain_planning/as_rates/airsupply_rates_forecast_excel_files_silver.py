# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # AirSupply rates forecast excel files Silver
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to transform bronze table into silver tables.
# MAGIC
# MAGIC **silver goals**
# MAGIC - Drop product column
# MAGIC - fix column types
# MAGIC - delete 'TOTAL' yearly columns
# MAGIC - melt table with month-year column
# MAGIC - delete unwanted metrics
# MAGIC - extract week number from file name
# MAGIC - reorder columns
# MAGIC
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC AS Rates Pipeline
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC   - {reference_read_env}_bronze.leap_depot_uc37_as_rates.as_rates_bronze
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC N/A
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.supply_chain_planning.as_rates_silver
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC     # Have only date_parsed and not date_mon_year

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# EXAMPLE
import pyspark.sql.functions as f
from great_expectations.dataset import SparkDFDataset


# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common import logger

from leap_utils.common.validation import quality_checks, gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Level

# COMMAND ----------

dbutils.widgets.text("bypass_quality_checks", "false")  # history/update
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = logger.LOGGER_MAPPING[dbutils.widgets.get("log_level")]

# log = logger.get_logger(module_name=__name__)
# logger.setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logger.logging.INFO)

# log.info(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}") #excluded because extraction isn't from pipeline

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

# TODO refactor leap_utils logger someday, we should not need to check if the logger is setup, etc etc
if not locals().get("is_logger_setup"):
    print("Currently creating logger...")
    root_log = logger.setup_applevel_logger(log_level=LOG_LEVEL)
    is_logger_setup = True
    print("Created logger.")

APP_NAME = "airsupply_rates_forecast_project"
log = logger.get_logger(APP_NAME)
log.setLevel(LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Used to specify which folder Input data is housed in
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ####Input Files Config
# MAGIC Definition of files to ingest

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables Location
# MAGIC
# MAGIC Details on how to read the input tables

# COMMAND ----------

t_bronze_as_rates = (
    f"{PIPELINE_READ_ENV}_bronze.leap_depot_uc37_as_rates.as_rates_bronze"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC
# MAGIC Definition of folder Archived input data is stored in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables Location

# COMMAND ----------

TABLE_DEST = f"{PIPELINE_WRITE_ENV}_silver.supply_chain_planning.as_rates_silver"

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# Read landing zone table
df_bronze_as_rates = spark.read.table(f"{t_bronze_as_rates}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# MAGIC %md
# MAGIC ### S3 files import from folder
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# MAGIC %md
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Drop profit_center_name column
# MAGIC Is inconsistent across files and it will be re-added in gold by joining a prod table, so there's no use in fixing it

# COMMAND ----------

# Create a new DataFrame to hold the transformations
df_silver = df_bronze_as_rates

# Drop product column
df_silver = df_silver.drop("profit_center_name")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Fix column types

# COMMAND ----------

# Month columns to set as floats
month_year_cols = df_bronze_as_rates.columns[4:-4]

# Convert each column to float
for column in month_year_cols:
    df_silver = df_silver.withColumn(column, f.col(column).cast("float"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Delete 'TOTAL' yearly columns

# COMMAND ----------

# Filter columns that do not contain 'TOTAL'
columns_to_keep = [c for c in df_silver.columns if "total" not in c]

# Select columns explicitly, passing them as individual arguments
df_silver = df_silver.select(
    *columns_to_keep
)  # * used to unpack list into separate argument

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Melt

# COMMAND ----------

# MAGIC %md
# MAGIC table is 'melted' and select columns are chosen, dropping metadata columns

# COMMAND ----------

# melt
month_year_cols = df_silver.columns[4:-4]

df_silver_melt = df_silver.melt(
    ids=[
        "profit_center",
        "metric_category",
        "metric",
        "path",
    ],  # Columns to keep
    values=month_year_cols,  # Columns to melt
    variableColumnName="date_month_year",  # New column for melted variable names
    valueColumnName="quantity",  # New column for melted values
)

# COMMAND ----------

log.debug(display(df_silver_melt))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 5 - Select relevant types of forecast

# COMMAND ----------

select_metrics = [
    "Customer Forecast (CF)",
    "Customer Orders (CO)",
    "Consensus Demand Plan (CDP)",
    "Production Plan (PP)",
    "MPS (SAP)",
    "Invoicing",
    "Budget",
]

# Filter rows where 'Type of Forecast' column contains any of the select_metrics
df_silver_melt = df_silver_melt.filter(f.col("`metric`").isin(select_metrics))


# COMMAND ----------

# Convert date_month_year to a full date format in new column
df_silver_melt = df_silver_melt.withColumn(
    "date",
    f.to_date(f.concat(f.lit("01_"), df_silver_melt["date_month_year"]), "dd_MMM_yy"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 6 - Get week number and drop file_path column

# COMMAND ----------

df_silver_melt = df_silver_melt.withColumn(
    "upload_year_week",  # Name of the new column being added to the DataFrame
    f.concat(  # Concatenates multiple strings or values into one
        f.regexp_extract(
            df_silver_melt["path"],  # Column 'path' where the regex will be applied
            r"(\d{4})-w(\d{2})",  # Regex pattern to match a year-week format (e.g., "2023-w04")
            1,  # Extracts the first capture group (the year, e.g., "2023")
        ),
        f.lit("-"),  # Adds a literal dash ("-") between the year and week
        f.regexp_extract(
            df_silver_melt["path"],  # Column 'path' where the regex will be applied
            r"(\d{4})-w(\d{2})",  # Regex pattern to match a year-week format (e.g., "2023-w04")
            2,  # Extracts the second capture group (the week number, e.g., "04")
        ),
    ),
)


# COMMAND ----------

# drop file_path column
df_silver_melt = df_silver_melt.drop("path")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 7 - Reorder columns

# COMMAND ----------

new_column_order = [
    "upload_year_week",
    "profit_center",
    "metric_category",
    "metric",
    "date",  # dropped date_month_year from selection
    "quantity",
]

df_silver_reordered = df_silver_melt.select(new_column_order)

# COMMAND ----------

log.debug(display(df_silver_reordered))

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

## N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Check 1 - Unique compound columns
# MAGIC Compound columns "ye-we_of_forecast", "profit_center", "type_of_forecast", "date_parsed" should be unique

# COMMAND ----------

# Define dataset to check
df_to_check = df_silver_reordered

# Define the columns for uniqueness check
cols_to_check = ["upload_year_week", "profit_center", "metric", "date"]

# Set the validation level
validation_level = "RED" if not BYPASS_QUALITY_CHECKS else "AMBER"

# Create a Great Expectations dataset from the filtered DataFrame
df_gx = SparkDFDataset(df_to_check, persist=True)

# Apply the uniqueness expectation
quality_check_results = [df_gx.expect_compound_columns_to_be_unique(cols_to_check)]

# Log the results
gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"All combinations of {', '.join(cols_to_check)} are unique",
    error_message=f"Combinations of {', '.join(cols_to_check)} are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="airsupply_rates_forecast_excel_files_silver",
    log_to_event_table=True,
    log_successes=True,
)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Check 2 - Set Membership
# MAGIC to check if the values of categorical columns belong to the expected set of values

# COMMAND ----------

# Define columns to check
cols_to_check = {
    "metric": [
        "Customer Orders (CO)",
        "Consensus Demand Plan (CDP)",
        "Invoicing",
        "Production Plan (PP)",
        "Budget",
        "MPS (SAP)",
        "Customer Forecast (CF)",
    ],
    "metric_category": [
        "LATECOERE - Operations",
        "STOP",
        "REF",
        "LATECOERE - S&OP decision",
        "CUSTOMER DEMAND",
    ],
}

# Set the validation level
validation_level = "RED" if not BYPASS_QUALITY_CHECKS else "AMBER"

# Apply the in set expectation
quality_check_results = [
    df_gx.expect_column_values_to_be_in_set(
        column="metric", value_set=cols_to_check["metric"]
    ),
    df_gx.expect_column_values_to_be_in_set(
        column="metric_category", value_set=cols_to_check["metric_category"]
    ),
]

# Log the results
gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message="The columns 'metric' and 'metric_category' have valid values",
    error_message="Some rows have invalid values in 'metric' or 'metric_category', check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="airsupply_rates_forecast_excel_files_silver",
    log_to_event_table=True,
    log_successes=True,
)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Check 3 - No null values
# MAGIC

# COMMAND ----------

# Set the validation level
validation_level = "RED" if not BYPASS_QUALITY_CHECKS else "AMBER"

# Initialize SparkDFDataset for validations
df_gx = SparkDFDataset(df_to_check, persist=True)

# Columns to check for missing values
columns_to_check = ["upload_year_week", "profit_center", "metric", "date"]

# Expect that these columns do not have any null/missing values
# Assuming columns_to_check is a list of column names like ['column1', 'column2', 'column3']
for column in columns_to_check:
    # Apply the not null expectation
    quality_check_results = [df_gx.expect_column_values_to_not_be_null(column=column)]

    # Log the results
    gx_validation.validate_and_log_gx_results(
        quality_check_results=quality_check_results,
        validation_level=validation_level,
        info_message=f"Column '{column}' does not contain null values.",
        error_message=f"Some values in column '{column}' are null, check the summary of this run.",
        pipeline_write_env=PIPELINE_WRITE_ENV,
        table_name="airsupply_rates_forecast_excel_files_silver",
        log_to_event_table=True,
        log_successes=True,
    )


# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Check 4 - Range Validation
# MAGIC Check quantity are non-negatives

# COMMAND ----------

# Set the validation level
validation_level = "RED" if not BYPASS_QUALITY_CHECKS else "AMBER"

# Check if 'Quantity' values are non-negative
negative_values = df_to_check.filter(df_to_check["Quantity"] < 0)

# Log the results
results_dict = {}
results_dict["airsupply_rates_forecast_excel_files_silver"] = (
    negative_values.count() == 0
)

# Validate and log results
quality_checks.validate_and_log_quality_check_results(
    results_dict=results_dict,
    validation_level=validation_level,
    info_message="The 'Quantity' column has no negative values.",
    error_message="Some 'Quantity' values are negative, check the summary of this run.",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    expectation_type="expect_column_values_to_be_in_set:Quantity",
    log_to_event_table=True,
    log_successes=True,
)


# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

table_utils.save_table(
    TABLE_DEST,
    df_silver_reordered,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
