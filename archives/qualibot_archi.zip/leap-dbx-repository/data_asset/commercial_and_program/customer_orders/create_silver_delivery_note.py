# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Silver DeliveryNote
# MAGIC
# MAGIC **Description:**
# MAGIC Builds the cleaned delivery note view at delivery item grain. Joins LIPS (delivery items) to
# MAGIC LIKP (delivery header) for goods issue dates, then to pre-aggregated VBRP (invoiced amounts
# MAGIC summed per order item to prevent fan-out) and VBRK (invoice date). Preserves
# MAGIC `sales_order_number` and `SO_item` (from LIPS.VBELV / POSNV) as the join keys to Gold.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - VBRP can produce up to 127 rows per order item (partial invoices + credit memos). It is
# MAGIC   pre-aggregated by AUBEL + AUPOS with SUM(NETWR) before the join to prevent fan-out.
# MAGIC   Credits automatically cancel debits in the sum.
# MAGIC - `cast_sap_float_column()` must be applied to VBRP.NETWR before aggregation; the SAP
# MAGIC   trailing-minus format causes NULL on a plain cast.
# MAGIC - SAP stores VBELN (LIPS, LIKP) and AUBEL (VBRP) zero-padded. All must be stripped before
# MAGIC   joins — see Leading Zero Normalization.
# MAGIC - ~98% of LIPS rows have NULL `sales_order_number` (VBELV) — most deliveries are internal/
# MAGIC   transfer movements, not linked to customer orders. This is expected; see corrections log C2.
# MAGIC - `invoiced_amount` is the **order item total** (VBRP aggregated at AUBEL+AUPOS), not a
# MAGIC   per-delivery amount. One order item can have multiple deliveries — each delivery row
# MAGIC   carries the same full invoiced amount. Summing `invoiced_amount` at delivery grain inflates
# MAGIC   the total. Downstream consumers must dedup at `(sales_order_number, SO_item)` grain using
# MAGIC   `MAX(invoiced_amount)` before summing.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Customer Orders — Daily
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - *(none — all sources are reference/Bronze)*
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{reference_read_env}_bronze.sap_latecoere_ecc6.lips_latest`
# MAGIC - `{reference_read_env}_bronze.sap_latecoere_ecc6.likp_latest`
# MAGIC - `{reference_read_env}_bronze.sap_latecoere_ecc6.vbrp_latest`
# MAGIC - `{reference_read_env}_bronze.sap_latecoere_ecc6.vbrk_latest`
# MAGIC - `{reference_read_env}_bronze.headers_sap.headers_sap_lips`
# MAGIC - `{reference_read_env}_bronze.headers_sap.headers_sap_likp`
# MAGIC - `{reference_read_env}_bronze.headers_sap.headers_sap_vbrk`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_silver.commercial_and_program.delivery_note`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. VBRP is aggregated using raw technical column names (AUBEL, AUPOS, NETWR, VBELN) before
# MAGIC        header renaming. If VBRP header Business_Names change, update the groupBy/agg keys
# MAGIC        and the join condition in the Data Transformations section.

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger and Constants

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

DEST_TABLE = f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program.delivery_note"

log.info(f"Destination table: {DEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## SAP Header Tables

# COMMAND ----------

df_header_lips_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_lips")
df_header_likp_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_likp")
df_header_vbrk_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_vbrk")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze Source Tables

# COMMAND ----------

df_lips_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.lips_latest")

df_likp_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.likp_latest")

# VBRP is read raw; SAP float fix and aggregation happen in Data Preparation
df_vbrp_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.vbrp_latest")

df_vbrk_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.vbrk_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## LIPS — Delivery Items

# COMMAND ----------

df_lips_prep = table_utils.add_prefix_to_columns(df_lips_raw, "lips")
df_lips_prep = table_utils.rename_columns_with_sap_business_header(df_lips_prep, df_header_lips_raw)

for row in df_header_lips_raw.filter(f.col("Format").isin("float", "double")).select("Business_name").collect():
    col_name = row["Business_name"]
    if col_name in df_lips_prep.columns:
        df_lips_prep = table_utils.transform_float_column(df_lips_prep, col_name)

df_lips_prep = table_utils.cast_columns_with_sap_business_headers(df_lips_prep, df_header_lips_raw)

# Strip leading zeros: delivery_number (VBELN) for LIKP join; delivery_item_ID (POSNR),
# sales_order_number (VBELV) and SO_item (POSNV) for downstream Gold join to silver.customer_orders;
# lips_vgbel and lips_vgpos for the VGBEL fallback below (not in headers — never exposed as output columns);
# material_number (MATNR) to align with customer_orders Silver where MATNR is also stripped.
# Note: POSNV='000000' strips to '' (empty string) for EDI/B2B rows — handled in VGBEL fallback below.
df_lips_prep = table_utils.remove_leading_zeros(
    df_lips_prep,
    [c for c in ["delivery_number", "delivery_item_ID", "sales_order_number", "SO_item",
                 "lips_vgbel", "lips_vgpos", "material_number"] if c in df_lips_prep.columns]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## VGBEL Fallback — Sales Order Back-Reference
# MAGIC
# MAGIC `lips_vgbel` and `lips_vgpos` retain their prefixed technical names throughout — they are not
# MAGIC in `headers_sap_lips` and are never exposed as output columns. They exist solely to populate
# MAGIC `sales_order_number` and `SO_item` for deliveries created via non-standard flows (EDI, B2B)
# MAGIC where VBELV is NULL but VGBEL carries the sales order reference (`delivery_ref_document_type = 'C'`).

# COMMAND ----------

# VGBEL fallback: when VBELV (sales_order_number) is NULL and the preceding document
# is a sales order (VGTYP='C'), use VGBEL/VGPOS as the back-reference.
df_lips_prep = df_lips_prep.withColumn(
    "sales_order_number",
    f.when(
        f.col("sales_order_number").isNull() & (f.col("delivery_ref_document_type") == "C"),
        f.col("lips_vgbel")
    ).otherwise(f.col("sales_order_number"))
).withColumn(
    "SO_item",
    f.when(
        (f.col("SO_item").isNull() | (f.col("SO_item") == "")) & (f.col("delivery_ref_document_type") == "C"),
        f.col("lips_vgpos")
    ).otherwise(f.col("SO_item"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## LIKP — Delivery Header

# COMMAND ----------

df_likp_prep = table_utils.add_prefix_to_columns(df_likp_raw, "likp")
df_likp_prep = table_utils.rename_columns_with_sap_business_header(df_likp_prep, df_header_likp_raw)

for row in df_header_likp_raw.filter(f.col("Format").isin("float", "double")).select("Business_name").collect():
    col_name = row["Business_name"]
    if col_name in df_likp_prep.columns:
        df_likp_prep = table_utils.transform_float_column(df_likp_prep, col_name)

df_likp_prep = table_utils.cast_columns_with_sap_business_headers(df_likp_prep, df_header_likp_raw)

# LIKP VBELN and KUNAG are zero-padded in SAP; strip to match LIPS and customer order Silver
df_likp_prep = table_utils.remove_leading_zeros(
    df_likp_prep,
    [c for c in ["delivery", "customer_code", "customer_code_ship_to"] if c in df_likp_prep.columns]
)

# Drop plant — duplicates LIPS field (delivery item level is more specific)
df_likp_prep = df_likp_prep.drop("plant")

# COMMAND ----------

# MAGIC %md
# MAGIC ## VBRP — Invoice Items (SAP Float Fix and Pre-Aggregation)
# MAGIC
# MAGIC VBRP is aggregated before header renaming to keep the raw technical keys (AUBEL, AUPOS, VBELN)
# MAGIC available for the groupBy and the invoice_number. f.max(VBELN) is used for invoice_number —
# MAGIC this deterministically picks the most recent invoice document, and provides a single string
# MAGIC value for the VBRK join.

# COMMAND ----------

# cast_sap_float_column must run on the raw technical column name before any renaming or aggregation
df_vbrp_float_fixed = table_utils.cast_sap_float_column(df_vbrp_raw, "NETWR")

df_vbrp_agg = (
    df_vbrp_float_fixed
    .groupBy("AUBEL", "AUPOS")
    .agg(
        f.sum("NETWR").alias("invoiced_amount"),
        f.max("VBELN").alias("invoice_number"),
    )
)

# Strip leading zeros on AUBEL (= customer order VBELN) and AUPOS (= customer order POSNR)
# before joining to LIPS where they have already been stripped
df_vbrp_agg = table_utils.remove_leading_zeros(df_vbrp_agg, ["AUBEL", "AUPOS"])

# COMMAND ----------

# MAGIC %md
# MAGIC ## VBRK — Invoice Header

# COMMAND ----------

df_vbrk_prep = table_utils.add_prefix_to_columns(df_vbrk_raw, "vbrk")
df_vbrk_prep = table_utils.rename_columns_with_sap_business_header(df_vbrk_prep, df_header_vbrk_raw)

for row in df_header_vbrk_raw.filter(f.col("Format").isin("float", "double")).select("Business_name").collect():
    col_name = row["Business_name"]
    if col_name in df_vbrk_prep.columns:
        df_vbrk_prep = table_utils.transform_float_column(df_vbrk_prep, col_name)

df_vbrk_prep = table_utils.cast_columns_with_sap_business_headers(df_vbrk_prep, df_header_vbrk_raw)

# Drop columns that duplicate fields already in the LIPS+LIKP chain
# customer_code: LIKP has sold-to (kunag, kept), VBRK has payer — same Business_Name, different SAP concept
df_vbrk_prep = df_vbrk_prep.drop("customer_code", "creation_date")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join Delivery Header (LIKP)

# COMMAND ----------

df_lips_likp = df_lips_prep.alias("lips").join(
    df_likp_prep.alias("likp"),
    on=f.col("lips.delivery_number") == f.col("likp.delivery"),
    how="left",
).drop(f.col("likp.delivery"))

if DEBUG:
    null_likp = df_lips_likp.filter(f.col("planned_delivery_date").isNull()).count()
    log.debug(f"Rows with NULL planned_delivery_date after LIKP join: {null_likp}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join Invoiced Amount (VBRP)
# MAGIC
# MAGIC No fan-out risk here — VBRP was pre-aggregated to one row per AUBEL + AUPOS before the join.

# COMMAND ----------

df_lips_vbrp = df_lips_likp.alias("base").join(
    df_vbrp_agg.alias("vbrp"),
    on=[
        f.col("base.sales_order_number") == f.col("vbrp.AUBEL"),
        f.col("base.SO_item") == f.col("vbrp.AUPOS"),
    ],
    how="left",
).drop(f.col("vbrp.AUBEL")).drop(f.col("vbrp.AUPOS"))

if DEBUG:
    null_invoiced = df_lips_vbrp.filter(f.col("invoiced_amount").isNull()).count()
    log.debug(f"Rows with NULL invoiced_amount (uninvoiced deliveries): {null_invoiced}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join Invoice Date (VBRK)
# MAGIC
# MAGIC invoice_number comes from f.max(VBRP.VBELN) in the pre-aggregation above.
# MAGIC Rows with no invoice will have NULL invoice_number and no VBRK match — expected.

# COMMAND ----------

df_delivery_note_joined = df_lips_vbrp.join(
    df_vbrk_prep,
    on="invoice_number",
    how="left",
)

if DEBUG:
    null_invoice_date = df_delivery_note_joined.filter(f.col("invoice_date").isNull()).count()
    log.debug(f"Rows with NULL invoice_date: {null_invoice_date}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Primary Key and Quality Checks

# COMMAND ----------

df_delivery_note_end = df_delivery_note_joined.withColumn(
    "business_id",
    f.concat_ws("-", f.col("delivery_number"), f.col("delivery_item_ID")),
)
remaining_cols = [c for c in df_delivery_note_end.columns if c != "business_id"]
df_delivery_note_end = df_delivery_note_end.select("business_id", *remaining_cols)
df_delivery_note_end.cache()
_row_count = df_delivery_note_end.count()
log.info(f"Silver delivery_note: {_row_count} rows")

dfgx = gx.dataset.SparkDFDataset(df_delivery_note_end, persist=False)

red_results = [
    dfgx.expect_column_values_to_not_be_null(column="business_id"),
    dfgx.expect_column_values_to_be_unique(column="business_id"),
    dfgx.expect_column_values_to_not_be_null(column="delivery_number"),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="RED checks passed: business_id unique and not null; delivery_number not null",
    error_message="RED check failed on delivery_note — duplicate delivery items or missing delivery key",
)

amber_results = [
    # sales_order_number (VBELV) NULL ~98% — most deliveries are internal movements not linked to a customer order
    dfgx.expect_column_values_to_not_be_null(column="sales_order_number", mostly=0.005),
    dfgx.expect_column_values_to_not_be_null(column="invoiced_amount"),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=amber_results,
    validation_level="AMBER",
    info_message="AMBER checks passed: sales_order_number coverage >=0.5%; invoiced_amount coverage acceptable",
    error_message="AMBER warning on delivery_note — sales_order_number fully absent (VBELV/VGBEL ingestion issue?) or unexpected invoiced_amount nulls",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

table_utils.save_table(
    dest_table=DEST_TABLE,
    df=df_delivery_note_end,
    mode="overwrite",
    overwrite_schema=True,
)

log.info(f"Saved: {DEST_TABLE}")
