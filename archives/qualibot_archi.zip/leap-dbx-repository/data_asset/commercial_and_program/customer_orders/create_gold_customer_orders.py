# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Gold CustomerOrders
# MAGIC
# MAGIC **Description:**
# MAGIC Builds the analytical customer orders table at schedule-line grain by enriching the Silver
# MAGIC order book with organisational hierarchy (material_plant_exposed — including mrp_controller),
# MAGIC customer name, profit center ownership and description, and EUR currency conversion.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - `net_amount_eur` is NULL for orders where the Consolidation exchange rate is missing for
# MAGIC   the order currency on the conversion date (typically < 5%; see corrections log C3).
# MAGIC - `profit_center` is resolved via a coalesce: order-level PRCTR (from wb2, sparse ~17%)
# MAGIC   falls back to the material-plant master default. `profit_center_ID` is dropped after
# MAGIC   the coalesce to avoid ambiguity.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Customer Orders — Daily
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{pipeline_write_env}_silver.commercial_and_program.customer_orders`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{reference_read_env}_gold.master_data.material_plant_exposed`
# MAGIC - `{reference_read_env}_gold.finance.customer_master_data_latest_exposed`
# MAGIC - `{reference_read_env}_gold.finance.profit_center_exposed`
# MAGIC - `{reference_read_env}_gold.master_data.wbs_exposed`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_gold.commercial_and_program.customer_orders`
# MAGIC - `{pipeline_write_env}_gold.commercial_and_program.customer_orders_exposed`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. currency_conversion() returns a column named with the full rate/amount/date combination.
# MAGIC        The rename pattern in the Currency Conversion section must be updated if the column
# MAGIC        naming convention inside leap_utils changes.

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger and Constants

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

DEST_TABLE = f"{PIPELINE_WRITE_ENV}_gold.commercial_and_program.customer_orders"
DEST_VIEW = f"{PIPELINE_WRITE_ENV}_gold.commercial_and_program.customer_orders_exposed"

log.info(f"Destination table: {DEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Customer Orders

# COMMAND ----------

# Same-pipeline read: Gold reads its own Silver output (PIPELINE_WRITE_ENV)
df_customer_orders_raw = spark.read.table(f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program.customer_orders")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Reference Data

# COMMAND ----------

df_matplant_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed")

df_customer_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.customer_master_data_latest_exposed")

df_pc_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed")

df_wbs_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.master_data.wbs_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## material_plant_exposed

# COMMAND ----------

MATPLANT_COLS = ["plant", "stock_site", "production_site", "profit_center", "division", "region", "assy_final", "mrp_controller"]
_available = [c for c in MATPLANT_COLS if c in df_matplant_raw.columns]
_missing = [c for c in MATPLANT_COLS if c not in df_matplant_raw.columns]
if _missing:
    log.warning(f"material_plant_exposed: expected columns not found: {_missing}")
df_matplant_prep = df_matplant_raw.select(*_available).dropDuplicates(["plant"])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Master

# COMMAND ----------

CUSTOMER_COLS = {
    "Customer_Code": "customer_code",
    "Customer_name": "customer_name",
    "Intercompany_flow": "intercompany_flow",
    "Customer_group": "customer_group",
}
_missing_cust = [c for c in CUSTOMER_COLS if c not in df_customer_raw.columns]
if _missing_cust:
    log.warning(f"customer_master_data_latest_exposed: expected columns not found: {_missing_cust}")
df_customer_prep = (
    df_customer_raw
    .select(*[f.col(src).alias(dst) for src, dst in CUSTOMER_COLS.items() if src in df_customer_raw.columns])
    .dropDuplicates(["customer_code"])
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Profit Center

# COMMAND ----------

# Keep only valid profit centers; one row per profit center code
df_pc_prep = (
    df_pc_raw
    .filter(f.col("Is_valid") == True)
    .select(
        "Profit_Center",
        f.col("PC_Responsible").alias("PC_responsible"),
        f.col("Long_Description").alias("profit_center_description"),
    )
    .dropDuplicates(["Profit_Center"])
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## WBS

# COMMAND ----------

df_wbs_prep = df_wbs_raw.select("WBS_element", "WBS_code")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join Hierarchy (material_plant_exposed)

# COMMAND ----------

# Drop Silver columns that material_plant_exposed now provides to avoid ambiguous references
_matplant_override = [c for c in _available if c != "plant" and c in df_customer_orders_raw.columns]
_base = df_customer_orders_raw.drop(*_matplant_override) if _matplant_override else df_customer_orders_raw

df_with_hierarchy = _base.join(
    df_matplant_prep,
    on="plant",
    how="left",
)

# Prefer order-level profit center (sparse ~17% populated in SAP) over material master default.
# Drop profit_center_ID after coalesce — profit_center is now the single resolved field.
df_with_hierarchy = (
    df_with_hierarchy
    .withColumn("profit_center", f.coalesce(f.col("profit_center_ID"), f.col("profit_center")))
    .drop("profit_center_ID")
)

if DEBUG:
    null_site = df_with_hierarchy.filter(f.col("stock_site").isNull()).count()
    null_pc = df_with_hierarchy.filter(f.col("profit_center").isNull()).count()
    log.debug(f"NULL stock_site: {null_site} | NULL profit_center: {null_pc}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join Customer Name

# COMMAND ----------

df_with_customer = df_with_hierarchy.join(
    df_customer_prep,
    on="customer_code",
    how="left",
)

if DEBUG:
    null_cust = df_with_customer.filter(f.col("customer_name").isNull()).count()
    log.debug(f"NULL customer_name: {null_cust}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join Profit Center Ownership

# COMMAND ----------

df_with_pc = df_with_customer.join(
    df_pc_prep.withColumnRenamed("Profit_Center", "_pc_key"),
    on=df_with_customer["profit_center"] == f.col("_pc_key"),
    how="left",
).drop("_pc_key")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join WBS Code

# COMMAND ----------

df_with_wbs = df_with_pc.join(df_wbs_prep, on="WBS_element", how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Currency Conversion

# COMMAND ----------

# Convert net_amount (order currency, mixed USD/EUR) to EUR for cross-plant aggregation.
# -2 day offset on conversion_date: rate table lags by 1 day; -2 ensures a rate is always found.
df_with_currency = df_with_wbs.withColumn("conversion_date", f.date_sub(f.current_date(), 2))

_RATE_COL = "SO_currency_to_EUR_in_Consolidation_rate_at_conversion_date"
_AMT_COL = f"SO_net_value_from_{_RATE_COL}"

df_with_currency = table_utils.currency_conversion(
    df=df_with_currency,
    document_currency_column=f.col("SO_currency"),
    rate_types=["Consolidation"],
    rate_dates=[f.col("conversion_date")],
    target_currency_value="EUR",
    document_amounts=[f.col("SO_net_value")],
    reference_read_env="prod",
)
df_with_currency = (
    df_with_currency
    .withColumnRenamed(_AMT_COL, "net_amount_eur")
    .drop(_RATE_COL, "conversion_date")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Primary Key and Quality Checks

# COMMAND ----------

df_customer_orders_end = df_with_currency.withColumn(
    "business_id",
    f.concat_ws("-", f.col("sales_order_number"), f.col("SO_item"), f.col("schedule_line_number")),
)
remaining_cols = [c for c in df_customer_orders_end.columns if c != "business_id"]
df_customer_orders_end = df_customer_orders_end.select("business_id", *remaining_cols)
df_customer_orders_end.cache()
_total = df_customer_orders_end.count()
_eur_nulls = df_customer_orders_end.filter(f.col("net_amount_eur").isNull()).count()
log.info(f"net_amount_eur: {_eur_nulls} NULLs ({_eur_nulls * 100 / _total:.1f}% missing Consolidation rate)")

if DEBUG:
    df_customer_orders_end.select(
        "business_id", "sales_order_number", "SO_item", "schedule_line_number",
        "schedule_line_date", "stock_site", "region", "customer_name", "net_amount_eur"
    ).limit(5).display()

dfgx = gx.dataset.SparkDFDataset(df_customer_orders_end, persist=False)

red_results = [
    dfgx.expect_column_values_to_not_be_null(column="business_id"),
    dfgx.expect_column_values_to_be_unique(column="business_id"),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="RED checks passed: business_id unique and not null",
    error_message="RED check failed on customer_orders — duplicate or missing schedule line key",
)

amber_results = [
    dfgx.expect_column_values_to_not_be_null(column="profit_center"),
    dfgx.expect_column_distinct_values_to_be_in_set(
        column="SO_type",
        value_set={
            "G2", "L2", "ZATV", "ZBDC", "ZBOE", "ZBR1", "ZBRI",
            "ZCDC", "ZCDI", "ZCDR", "ZCDT", "ZCQ", "ZDCS", "ZDOC",
            "ZKB", "ZKEV", "ZOFC", "ZRE", "ZRE1", "ZTVA", "ZZZ",
            "ZCRM", "ZAS", "ZCOD",
        },
    ),
    dfgx.expect_column_values_to_not_be_null(column="net_amount_eur"),
    # ~30% NULL on mrp_controller is expected — service items and cancelled lines have no material_plant entry.
    dfgx.expect_column_values_to_not_be_null(column="mrp_controller", mostly=0.5),
    # WBS_element is sparse in SAP — null WBS_code is expected for orders without a project reference.
    dfgx.expect_column_values_to_not_be_null(column="WBS_code", mostly=0.5),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=amber_results,
    validation_level="AMBER",
    info_message="AMBER checks passed: profit_center coverage, SO_type set, net_amount_eur coverage, mrp_controller coverage",
    error_message="AMBER warning on customer_orders — profit_center NULLs, unexpected SO_type, high EUR miss rate, or mrp_controller below 50%",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

table_utils.save_table(
    dest_table=DEST_TABLE,
    df=df_customer_orders_end,
    mode="overwrite",
    overwrite_schema=True,
)
log.info(f"Saved: {DEST_TABLE}")

# COMMAND ----------

_TECH_PREFIXES = ("wb2vvbakvbap2_", "vbep_", "vbup_", "vbkd_")
_exposed_cols = [c for c in df_customer_orders_end.columns if not c.startswith(_TECH_PREFIXES)]
table_utils.create_table_view(
    src_full_tablename=DEST_TABLE,
    dest_full_tablename=DEST_VIEW,
    select_statement=", ".join(_exposed_cols),
    replace_view=True,
)
log.info(f"Created view: {DEST_VIEW} ({len(_exposed_cols)} columns)")
