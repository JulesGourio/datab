# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create.Headers.SAP.CustomerOrders
# MAGIC
# MAGIC **Description:**
# MAGIC One-time setup script. Creates or replaces all SAP header tables required by the Customer Orders
# MAGIC pipeline (Silver and Gold). Each header maps SAP technical field names to business names and
# MAGIC defines the expected data type for casting.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - *(none)*
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - One-time setup only — not included in any scheduled job
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - *(none)*
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - *(none)*
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_bronze.headers_sap.headers_sap_wb2vvbakvbap2`
# MAGIC - `{pipeline_write_env}_bronze.headers_sap.headers_sap_vbep`
# MAGIC - `{pipeline_write_env}_bronze.headers_sap.headers_sap_vbup`
# MAGIC - `{pipeline_write_env}_bronze.headers_sap.headers_sap_vbkd`
# MAGIC - `{pipeline_write_env}_bronze.headers_sap.headers_sap_lips`
# MAGIC - `{pipeline_write_env}_bronze.headers_sap.headers_sap_likp`
# MAGIC - `{pipeline_write_env}_bronze.headers_sap.headers_sap_vbrp`
# MAGIC - `{pipeline_write_env}_bronze.headers_sap.headers_sap_vbrk`

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType

from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Constants

# COMMAND ----------

HEADER_SCHEMA = StructType([
    StructField("Table_name", StringType(), True),
    StructField("Field", StringType(), True),
    StructField("Business_name", StringType(), True),
    StructField("Format", StringType(), True),
])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## WB2VVBAKVBAP2 — Sales Order View (Header + Item)

# COMMAND ----------

data_wb2vvbakvbap2 = [
    ("wb2vvbakvbap2", "abgru_i",  "SO_rejection_reason",      "string"),
    ("wb2vvbakvbap2", "arktx_i",  "material_description",     "string"),
    ("wb2vvbakvbap2", "auart",    "SO_type",                  "string"),
    ("wb2vvbakvbap2", "erdat",    "SO_creation_date",         "date"),
    ("wb2vvbakvbap2", "kdmat_i",  "customer_material_number", "string"),
    ("wb2vvbakvbap2", "kostl",    "cost_center_ID",           "string"),
    ("wb2vvbakvbap2", "kunnr",    "customer_code",            "string"),
    ("wb2vvbakvbap2", "kwmeng_i", "quantity",                 "float"),
    ("wb2vvbakvbap2", "lifsk",    "delivery_block",           "string"),
    ("wb2vvbakvbap2", "matnr_i",  "material_number",          "string"),
    ("wb2vvbakvbap2", "netwr_i",  "SO_net_value",             "float"),
    ("wb2vvbakvbap2", "posnr_i",  "SO_item",                  "string"),
    ("wb2vvbakvbap2", "prctr_i",  "profit_center_ID",         "string"),
    ("wb2vvbakvbap2", "ps_psp_pnr_i", "WBS_element",           "string"),
    ("wb2vvbakvbap2", "pstyv_i",  "SO_item_category",         "string"),
    ("wb2vvbakvbap2", "vbeln",    "sales_order_number",       "string"),
    ("wb2vvbakvbap2", "vdatu",    "requested_delivery_date",  "date"),
    ("wb2vvbakvbap2", "vkorg",    "sales_org",                "string"),
    ("wb2vvbakvbap2", "vrkme_i",  "sales_unit",               "string"),
    ("wb2vvbakvbap2", "waerk",    "SO_currency",              "string"),
    ("wb2vvbakvbap2", "werks_i",  "plant",                    "string"),
]

# COMMAND ----------

# MAGIC %md
# MAGIC ## VBEP — Schedule Lines

# COMMAND ----------

data_vbep = [
    ("vbep", "bmeng", "confirmed_quantity",    "double"),
    ("vbep", "edatu", "schedule_line_date",    "date"),
    ("vbep", "etenr", "schedule_line_number",  "string"),
    ("vbep", "lddat", "loading_date",          "date"),
    ("vbep", "lifsp", "line_delivery_block",   "string"),
    ("vbep", "lmeng", "delivered_quantity",    "double"),
    ("vbep", "posnr", "SO_item",               "string"),
    ("vbep", "vbeln", "sales_order_number",    "string"),
    ("vbep", "wmeng", "order_quantity",        "double"),
]

# COMMAND ----------

# MAGIC %md
# MAGIC ## VBUP — Item Status

# COMMAND ----------

data_vbup = [
    ("vbup", "fksta", "invoice_status",             "string"),
    ("vbup", "gbsta", "overall_processing_status", "string"),
    ("vbup", "lfsta", "delivery_status",           "string"),
    ("vbup", "posnr", "SO_item",                   "string"),
    ("vbup", "vbeln", "sales_order_number",        "string"),
]

# COMMAND ----------

# MAGIC %md
# MAGIC ## VBKD — Sales Business Data (Payment Terms, PO Number)

# COMMAND ----------

data_vbkd = [
    ("vbkd", "bstkd", "customer_PO_number", "string"),
    ("vbkd", "delco", "delivery_priority",  "string"),
    ("vbkd", "vbeln", "sales_order_number", "string"),
]

# COMMAND ----------

# MAGIC %md
# MAGIC ## LIPS — Delivery Items

# COMMAND ----------

data_lips = [
    ("lips", "charg",  "batch",                        "string"),
    ("lips", "erdat",  "creation_date",                "date"),
    ("lips", "erzet",  "creation_time",                "string"),
    ("lips", "vbelv",  "sales_order_number",           "string"),
    ("lips", "posnv",  "SO_item",                      "string"),
    ("lips", "lfimg",  "delivered_qty",                "double"),
    ("lips", "lgmng",  "actual_delivery_qty",          "double"),
    ("lips", "lgort",  "storage_location",             "string"),
    ("lips", "matnr",  "material_number",              "string"),
    ("lips", "meins",  "base_unit_of_measure",         "string"),
    ("lips", "posnr",  "delivery_item_ID",             "string"),
    ("lips", "pstyv",  "delivery_item_type",           "string"),
    ("lips", "vbeln",  "delivery_number",              "string"),
    ("lips", "vgtyp",  "delivery_ref_document_type",   "string"),
    ("lips", "werks",  "plant",                        "string"),
]

# COMMAND ----------

# MAGIC %md
# MAGIC ## LIKP — Delivery Header

# COMMAND ----------

data_likp = [
    ("likp", "anzpk",    "number_of_packages",           "string"),
    ("likp", "erdat",    "delivery_note_creation_date",  "date"),
    ("likp", "inco1",    "incoterms",                    "string"),
    ("likp", "kodat",    "picking_date",                 "date"),
    ("likp", "kunag",    "customer_code",                "string"),
    ("likp", "kunnr",    "customer_code_ship_to",        "string"),
    ("likp", "lddat",    "loading_date",                 "date"),
    ("likp", "lfart",    "delivery_type",                "string"),
    ("likp", "tddat",    "transportation_planning_date", "date"),
    ("likp", "vbeln",    "delivery",                     "string"),
    ("likp", "vstel",    "shipping_point",               "string"),
    ("likp", "wadat",    "planned_delivery_date",        "date"),
    ("likp", "wadat_ist","actual_GI_date",               "date"),
    ("likp", "werks",    "plant",                        "string"),
]

# COMMAND ----------

# MAGIC %md
# MAGIC ## VBRP — Invoice Items

# COMMAND ----------

data_vbrp = [
    ("vbrp", "arktx", "item_description",     "string"),
    ("vbrp", "aubel", "sales_order_number",   "string"),
    ("vbrp", "aupos", "SO_item",              "string"),
    ("vbrp", "fkimg", "invoice_qty",          "double"),
    ("vbrp", "matnr", "material_number",      "string"),
    ("vbrp", "meins", "base_unit_of_measure", "string"),
    ("vbrp", "mwsbp", "tax_amount",           "double"),
    ("vbrp", "netwr", "invoice_net_value",    "double"),
    ("vbrp", "posnr", "invoice_item_ID",      "string"),
    ("vbrp", "prctr", "profit_center",        "string"),
    ("vbrp", "pstyv", "invoice_item_type",    "string"),
    ("vbrp", "vbeln", "invoice_number",       "string"),
    ("vbrp", "vgbel", "delivery_number",      "string"),
    ("vbrp", "vgpos", "delivery_item_ID",     "string"),
    ("vbrp", "werks", "plant",                "string"),
]

# COMMAND ----------

# MAGIC %md
# MAGIC ## VBRK — Invoice Header

# COMMAND ----------

data_vbrk = [
    ("vbrk", "bukrs", "company_code",            "string"),
    ("vbrk", "erdat", "creation_date",            "date"),
    ("vbrk", "fkart", "invoice_type",             "string"),
    ("vbrk", "fkdat", "invoice_date",             "date"),
    ("vbrk", "fksto", "invoice_cancelled",        "string"),
    ("vbrk", "kunnr", "customer_code",            "string"),
    ("vbrk", "netwr", "invoice_net_value",        "double"),
    ("vbrk", "rfbsk", "accounting_status",        "string"),
    ("vbrk", "sfakn", "cancelled_invoice_doc",    "string"),
    ("vbrk", "spart", "division",                 "string"),
    ("vbrk", "vbeln", "invoice_number",           "string"),
    ("vbrk", "vbtyp", "invoice_document_type",    "string"),
    ("vbrk", "vkorg", "sales_organisation",       "string"),
    ("vbrk", "waerk", "invoice_currency",         "string"),
    ("vbrk", "zuonr", "assignment_number",        "string"),
]

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

headers = [
    ("wb2vvbakvbap2", data_wb2vvbakvbap2),
    ("vbep",          data_vbep),
    ("vbup",          data_vbup),
    ("vbkd",          data_vbkd),
    ("lips",          data_lips),
    ("likp",          data_likp),
    ("vbrp",          data_vbrp),
    ("vbrk",          data_vbrk),
]

for table_name, data in headers:
    dest = f"{PIPELINE_WRITE_ENV}_bronze.headers_sap.headers_sap_{table_name}"
    df = spark.createDataFrame(data, schema=HEADER_SCHEMA)
    table_utils.save_table(dest_table=dest, df=df, mode="overwrite", overwrite_schema=True)
    log.info(f"Saved: {dest}")
