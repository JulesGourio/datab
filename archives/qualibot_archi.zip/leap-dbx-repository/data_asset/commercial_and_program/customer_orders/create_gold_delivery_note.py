# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Gold DeliveryNote
# MAGIC
# MAGIC **Description:**
# MAGIC Builds the analytical delivery note table at delivery item grain by enriching Silver delivery note
# MAGIC with EUR currency conversion on invoiced_amount, material attributes from material_plant_exposed
# MAGIC (material_description, stock_site, production_site, profit_center, division, region, assy_final),
# MAGIC and customer attributes from customer_master_data_latest_exposed (customer_name, customer_group).
# MAGIC No aggregation — downstream consumers aggregate to the required grain as needed.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - `invoiced_amount_eur` is NULL for ~94% of rows — internal/transfer deliveries carry no
# MAGIC   invoice amount in Silver, so no EUR conversion is possible. This is expected.
# MAGIC - ~91% of rows have NULL `sales_order_number` (KDAUF) — most deliveries are internal/transfer
# MAGIC   movements not linked to a customer order. This is expected; see corrections log C2.
# MAGIC - ~10% of rows have no matplant match (internal movements, materials not in master) — those
# MAGIC   rows carry NULLs for material/site attributes, which is expected.
# MAGIC - ~25% of rows have no customer match — internal/transfer deliveries have no customer code.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Customer Orders — Daily
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{pipeline_write_env}_silver.commercial_and_program.delivery_note`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{reference_read_env}_gold.master_data.material_plant_exposed`
# MAGIC - `{reference_read_env}_gold.finance.customer_master_data_latest_exposed`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_gold.commercial_and_program.delivery_note`
# MAGIC - `{pipeline_write_env}_gold.commercial_and_program.delivery_note_exposed`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. currency_conversion() returns a column named with the full rate/amount/date combination.
# MAGIC        The rename pattern in the Currency Conversion section must be updated if the column
# MAGIC        naming convention inside leap_utils changes.
# MAGIC     2. Invoice currency column name depends on headers_sap_vbrk Business_Name for
# MAGIC        WAERS. Verify that it maps to `invoice_currency` in the header table before running.

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger and Constants

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

DEST_TABLE = f"{PIPELINE_WRITE_ENV}_gold.commercial_and_program.delivery_note"
DEST_VIEW = f"{PIPELINE_WRITE_ENV}_gold.commercial_and_program.delivery_note_exposed"

log.info(f"Destination table: {DEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Delivery Note

# COMMAND ----------

df_delivery_note_raw = spark.read.table(f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program.delivery_note")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Material Plant

# COMMAND ----------

df_matplant_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Master

# COMMAND ----------

df_customer_raw = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.customer_master_data_latest_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Material Plant

# COMMAND ----------

MATPLANT_COLS = ["material_number", "plant", "material_description", "stock_site",
                 "production_site", "profit_center", "division", "region", "assy_final"]
_available_mp = [c for c in MATPLANT_COLS if c in df_matplant_raw.columns]

df_matplant_prep = (
    df_matplant_raw
    .select(*_available_mp)
    .dropDuplicates(["material_number", "plant"])
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Master

# COMMAND ----------

df_customer_prep = (
    df_customer_raw
    .select(
        f.col("Customer_Code").alias("customer_code"),
        f.col("Customer_name").alias("customer_name"),
        f.col("Customer_group").alias("customer_group"),
    )
    .dropDuplicates(["customer_code"])
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join Material Plant

# COMMAND ----------

# Drop Silver columns that overlap with material_plant_exposed to avoid ambiguous references on join.
_matplant_override = [c for c in _available_mp if c not in ("material_number", "plant") and c in df_delivery_note_raw.columns]
_base = df_delivery_note_raw.drop(*_matplant_override) if _matplant_override else df_delivery_note_raw

# ~4.6% of rows have no matplant match (internal movements, materials not in master) — NULLs expected.
df_enriched = _base.join(
    df_matplant_prep,
    on=["material_number", "plant"],
    how="left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join Customer Master

# COMMAND ----------

# Rows with NULL customer_code in Silver (~5.4%) will carry NULLs — expected for internal movements.
df_enriched = df_enriched.join(
    df_customer_prep,
    on="customer_code",
    how="left",
)

if DEBUG:
    null_site = df_enriched.filter(f.col("stock_site").isNull() & f.col("material_number").isNotNull()).count()
    null_customer = df_enriched.filter(f.col("customer_name").isNull() & f.col("customer_code").isNotNull()).count()
    log.debug(f"Rows with material but NULL stock_site: {null_site}")
    log.debug(f"Rows with customer_code but NULL customer_name: {null_customer}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Currency Conversion

# COMMAND ----------

# Convert invoiced_amount (invoice currency) to EUR for cross-plant aggregation.
# -2 day offset: rate table lags by 1 day; -2 ensures a rate is always available.
# invoice_currency is the Business_Name for WAERS in headers_sap_vbrk; update if name differs.
df_enriched = df_enriched.withColumn("conversion_date", f.date_sub(f.current_date(), 2))

_RATE_COL = "invoice_currency_to_EUR_in_Consolidation_rate_at_conversion_date"
_AMT_COL = f"invoiced_amount_from_{_RATE_COL}"

df_enriched = table_utils.currency_conversion(
    df=df_enriched,
    document_currency_column=f.col("invoice_currency"),
    rate_types=["Consolidation"],
    rate_dates=[f.col("conversion_date")],
    target_currency_value="EUR",
    document_amounts=[f.col("invoiced_amount")],
    reference_read_env="prod",
)
df_enriched = (
    df_enriched
    .withColumnRenamed(_AMT_COL, "invoiced_amount_eur")
    .drop(_RATE_COL, "conversion_date")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Primary Key and Quality Checks
# MAGIC
# MAGIC PK inherits from Silver: delivery_number + delivery_item_ID (one row per delivery line).

# COMMAND ----------

df_delivery_note_end = df_enriched.withColumn(
    "business_id",
    f.concat_ws("-", f.col("delivery_number"), f.col("delivery_item_ID")),
)
remaining_cols = [c for c in df_delivery_note_end.columns if c != "business_id"]
df_delivery_note_end = df_delivery_note_end.select("business_id", *remaining_cols)
df_delivery_note_end.cache()
_total = df_delivery_note_end.count()
_eur_nulls = df_delivery_note_end.filter(f.col("invoiced_amount_eur").isNull()).count()
_matplant_nulls = df_delivery_note_end.filter(f.col("stock_site").isNull()).count()
_customer_nulls = df_delivery_note_end.filter(f.col("customer_name").isNull()).count()
log.info(f"invoiced_amount_eur: {_eur_nulls} NULLs ({_eur_nulls * 100 / _total:.1f}% missing Consolidation rate)")
log.info(f"stock_site: {_matplant_nulls} NULLs ({_matplant_nulls * 100 / _total:.1f}% no matplant match)")
log.info(f"customer_name: {_customer_nulls} NULLs ({_customer_nulls * 100 / _total:.1f}% no customer match)")

if DEBUG:
    df_delivery_note_end.select(
        "business_id", "delivery_number", "delivery_item_ID",
        "sales_order_number", "SO_item", "invoiced_amount", "invoiced_amount_eur",
        "stock_site", "customer_name",
    ).limit(5).display()

dfgx = gx.dataset.SparkDFDataset(df_delivery_note_end, persist=False)

red_results = [
    dfgx.expect_column_values_to_not_be_null(column="business_id"),
    dfgx.expect_column_values_to_be_unique(column="business_id"),
    dfgx.expect_column_values_to_not_be_null(column="delivery_number"),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="RED checks passed: business_id unique and not null; delivery_number not null",
    error_message="RED check failed on gold.delivery_note — duplicate delivery items or missing delivery key",
)

amber_results = [
    # ~91% NULL on sales_order_number is expected — most deliveries are internal movements
    dfgx.expect_column_values_to_not_be_null(column="sales_order_number", mostly=0.005),
    # ~94% NULL on invoiced_amount_eur is expected — internal movements have no invoice
    dfgx.expect_column_values_to_not_be_null(column="invoiced_amount_eur", mostly=0.05),
    # ~10% no matplant match is expected — internal movements, materials not in master
    dfgx.expect_column_values_to_not_be_null(column="stock_site", mostly=0.85),
    # ~25% NULL customer_name is expected — internal/transfer deliveries have no customer code
    dfgx.expect_column_values_to_not_be_null(column="customer_name", mostly=0.70),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=amber_results,
    validation_level="AMBER",
    info_message="AMBER checks passed: sales_order_number coverage, invoiced_amount_eur coverage, matplant match >=85%, customer match >=70%",
    error_message="AMBER warning on gold.delivery_note — check matplant/customer match rates or invoiced_amount_eur null rate",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

table_utils.save_table(
    dest_table=DEST_TABLE,
    df=df_delivery_note_end,
    mode="overwrite",
    overwrite_schema=True,
)
log.info(f"Saved: {DEST_TABLE}")

# COMMAND ----------

_TECH_PREFIXES = ("lips_", "likp_", "vbrk_")
_exposed_cols = [c for c in df_delivery_note_end.columns if not c.startswith(_TECH_PREFIXES)]
table_utils.create_table_view(
    src_full_tablename=DEST_TABLE,
    dest_full_tablename=DEST_VIEW,
    select_statement=", ".join(_exposed_cols),
    replace_view=True,
)
log.info(f"Created view: {DEST_VIEW} ({len(_exposed_cols)} columns)")
