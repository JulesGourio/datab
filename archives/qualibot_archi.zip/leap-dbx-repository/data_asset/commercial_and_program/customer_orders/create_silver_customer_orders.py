# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Silver CustomerOrders
# MAGIC
# MAGIC **Description:**
# MAGIC Builds the cleaned sales order book at schedule-line grain by joining SAP sales order data
# MAGIC (wb2vvbakvbap2), schedule lines (VBEP), item status (VBUP), and customer PO references
# MAGIC (VBKD). Applies SAP header renaming and casting.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - SAP stores document identifiers (VBELN, KUNNR, MATNR, PRCTR) with leading zeros; these
# MAGIC   must be stripped before any cross-table join or downstream use — see Leading Zero Normalization.
# MAGIC - VBKD is filtered to header-level rows (POSNR = 000000) in Data Preparation; item-level rows
# MAGIC   duplicate the customer PO number without adding information.
# MAGIC - ~50% of rows will have a NULL schedule_line_date after the VBEP LEFT JOIN — this is expected
# MAGIC   for order items without confirmed schedule lines in SAP. See corrections log C1.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Customer Orders — Daily
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - *(none — all sources are reference/Bronze)*
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{reference_read_env}_bronze.sap_latecoere_ecc6.wb2vvbakvbap2_latest`
# MAGIC - `{reference_read_env}_bronze.sap_latecoere_ecc6.vbep_latest`
# MAGIC - `{reference_read_env}_bronze.sap_latecoere_ecc6.vbup_latest`
# MAGIC - `{reference_read_env}_bronze.sap_latecoere_ecc6.vbkd_latest`
# MAGIC - `{reference_read_env}_bronze.headers_sap.headers_sap_wb2vvbakvbap2`
# MAGIC - `{reference_read_env}_bronze.headers_sap.headers_sap_vbep`
# MAGIC - `{reference_read_env}_bronze.headers_sap.headers_sap_vbup`
# MAGIC - `{reference_read_env}_bronze.headers_sap.headers_sap_vbkd`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_silver.commercial_and_program.customer_orders`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. KNOWN_ORDER_TYPES [Primary Key and Quality Checks]: the SO_type allowed-value set is
# MAGIC        hardcoded. If a new order type is introduced in SAP, the AMBER GX check will fire until
# MAGIC        the set is updated here.

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger and Constants

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

DEST_TABLE = f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program.customer_orders"

log.info(f"Destination table: {DEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## SAP Header Tables

# COMMAND ----------

df_header_wb2_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_wb2vvbakvbap2")
df_header_vbep_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_vbep")
df_header_vbup_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_vbup")
df_header_vbkd_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_vbkd")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze Source Tables

# COMMAND ----------

df_wb2_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.wb2vvbakvbap2_latest")

df_vbep_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.vbep_latest")

df_vbup_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.vbup_latest")

df_vbkd_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.vbkd_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## wb2vvbakvbap2

# COMMAND ----------

df_wb2_prep = table_utils.add_prefix_to_columns(df_wb2_raw, "wb2vvbakvbap2")
df_wb2_prep = table_utils.rename_columns_with_sap_business_header(df_wb2_prep, df_header_wb2_raw)

for row in df_header_wb2_raw.filter(f.col("Format").isin("float", "double")).select("Business_name").collect():
    col_name = row["Business_name"]
    if col_name in df_wb2_prep.columns:
        df_wb2_prep = table_utils.transform_float_column(df_wb2_prep, col_name)

df_wb2_prep = table_utils.cast_columns_with_sap_business_headers(df_wb2_prep, df_header_wb2_raw)

# COMMAND ----------

# MAGIC %md
# MAGIC ## VBEP — Schedule Lines

# COMMAND ----------

df_vbep_prep = table_utils.add_prefix_to_columns(df_vbep_raw, "vbep")
df_vbep_prep = table_utils.rename_columns_with_sap_business_header(df_vbep_prep, df_header_vbep_raw)

for row in df_header_vbep_raw.filter(f.col("Format").isin("float", "double")).select("Business_name").collect():
    col_name = row["Business_name"]
    if col_name in df_vbep_prep.columns:
        df_vbep_prep = table_utils.transform_float_column(df_vbep_prep, col_name)

df_vbep_prep = table_utils.cast_columns_with_sap_business_headers(df_vbep_prep, df_header_vbep_raw)

# VBEP stores VBELN and POSNR zero-padded; strip before join with wb2
df_vbep_prep = table_utils.remove_leading_zeros(df_vbep_prep, ["sales_order_number", "SO_item"])

# COMMAND ----------

# MAGIC %md
# MAGIC ## VBUP — Item Status

# COMMAND ----------

df_vbup_prep = table_utils.add_prefix_to_columns(df_vbup_raw, "vbup")
df_vbup_prep = table_utils.rename_columns_with_sap_business_header(df_vbup_prep, df_header_vbup_raw)

for row in df_header_vbup_raw.filter(f.col("Format").isin("float", "double")).select("Business_name").collect():
    col_name = row["Business_name"]
    if col_name in df_vbup_prep.columns:
        df_vbup_prep = table_utils.transform_float_column(df_vbup_prep, col_name)

df_vbup_prep = table_utils.cast_columns_with_sap_business_headers(df_vbup_prep, df_header_vbup_raw)

# VBUP stores VBELN and POSNR zero-padded; strip before join with wb2
df_vbup_prep = table_utils.remove_leading_zeros(df_vbup_prep, ["sales_order_number", "SO_item"])

# COMMAND ----------

# MAGIC %md
# MAGIC ## VBKD — Customer PO Reference

# COMMAND ----------

# Header-level rows only; item-level rows (POSNR != 000000) duplicate the customer PO number
df_vbkd_raw = df_vbkd_raw.filter(f.col("posnr") == "000000")

df_vbkd_prep = table_utils.add_prefix_to_columns(df_vbkd_raw, "vbkd")
df_vbkd_prep = table_utils.rename_columns_with_sap_business_header(df_vbkd_prep, df_header_vbkd_raw)

for row in df_header_vbkd_raw.filter(f.col("Format").isin("float", "double")).select("Business_name").collect():
    col_name = row["Business_name"]
    if col_name in df_vbkd_prep.columns:
        df_vbkd_prep = table_utils.transform_float_column(df_vbkd_prep, col_name)

df_vbkd_prep = table_utils.cast_columns_with_sap_business_headers(df_vbkd_prep, df_header_vbkd_raw)

# VBKD stores VBELN zero-padded; strip before join with wb2
df_vbkd_prep = table_utils.remove_leading_zeros(df_vbkd_prep, ["sales_order_number"])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Leading Zero Normalization — wb2vvbakvbap2

# COMMAND ----------

# SAP stores identifiers zero-padded; must strip before any join or downstream comparison
_wb2_zero_cols = [c for c in ["sales_order_number", "SO_item", "customer_code", "material_number", "profit_center", "WBS_element"] if c in df_wb2_prep.columns]
df_wb2_prep = table_utils.remove_leading_zeros(df_wb2_prep, _wb2_zero_cols)
log.info(f"Leading zeros stripped from wb2: {_wb2_zero_cols}")

# SAP uses "00000000" as a null placeholder for WBS; after stripping zeros it becomes "0" — nullify it
if "WBS_element" in df_wb2_prep.columns:
    df_wb2_prep = df_wb2_prep.withColumn(
        "WBS_element",
        f.when(f.col("WBS_element") == "0", f.lit(None)).otherwise(f.col("WBS_element")),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join Schedule Lines (VBEP)
# MAGIC
# MAGIC Grain changes here: one row per schedule line per sales order item after this join.
# MAGIC ~50% of rows will have NULL schedule_line_date — expected for items without confirmed ATP dates.

# COMMAND ----------

df_order_vbep = df_wb2_prep.join(
    df_vbep_prep,
    on=["sales_order_number", "SO_item"],
    how="left",
)

if DEBUG:
    null_sched = df_order_vbep.filter(f.col("schedule_line_number").isNull()).count()
    log.debug(f"Rows with NULL schedule_line_number: {null_sched}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join Item Status (VBUP)

# COMMAND ----------

df_order_vbup = df_order_vbep.join(
    df_vbup_prep,
    on=["sales_order_number", "SO_item"],
    how="left",
)

if DEBUG:
    null_status = df_order_vbup.filter(f.col("overall_processing_status").isNull()).count()
    log.debug(f"Rows with NULL overall_processing_status: {null_status}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join Customer PO Reference (VBKD)
# MAGIC
# MAGIC Header-level join on sales_order_number only — VBKD was pre-filtered to POSNR = 000000.
# MAGIC High NULL rate on customer_PO_number is expected; many Latecoere orders have no customer PO.

# COMMAND ----------

df_order_vbkd = df_order_vbup.join(
    df_vbkd_prep,
    on="sales_order_number",
    how="left",
)

if DEBUG:
    null_po = df_order_vbkd.filter(f.col("customer_PO_number").isNull()).count()
    log.debug(f"Rows with NULL customer_PO_number: {null_po}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Primary Key and Quality Checks

# COMMAND ----------

df_customer_orders_end = df_order_vbkd.withColumn(
    "business_id",
    f.concat_ws("-", f.col("sales_order_number"), f.col("SO_item"), f.col("schedule_line_number")),
)
remaining_cols = [c for c in df_customer_orders_end.columns if c != "business_id"]
df_customer_orders_end = df_customer_orders_end.select("business_id", *remaining_cols)
df_customer_orders_end.cache()
_row_count = df_customer_orders_end.count()
log.info(f"Silver customer_orders: {_row_count} rows")

dfgx = gx.dataset.SparkDFDataset(df_customer_orders_end, persist=False)

red_results = [
    dfgx.expect_column_values_to_not_be_null(column="business_id"),
    dfgx.expect_column_values_to_be_unique(column="business_id"),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="RED checks passed: business_id unique and not null",
    error_message="RED check failed on customer_orders — duplicate or missing schedule line key",
)

KNOWN_ORDER_TYPES = {
    "G2", "L2", "ZATV", "ZBDC", "ZBOE", "ZBR1", "ZBRI",
    "ZCDC", "ZCDI", "ZCDR", "ZCDT", "ZCQ", "ZDCS", "ZDOC",
    "ZKB", "ZKEV", "ZOFC", "ZRE", "ZRE1", "ZTVA", "ZZZ",
    "ZCRM", "ZAS", "ZCOD",
}
amber_results = [
    dfgx.expect_column_distinct_values_to_be_in_set(column="SO_type", value_set=KNOWN_ORDER_TYPES),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=amber_results,
    validation_level="AMBER",
    info_message="AMBER checks passed: SO_type within known set",
    error_message="AMBER warning on customer_orders — unexpected SO_type value",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

table_utils.save_table(
    dest_table=DEST_TABLE,
    df=df_customer_orders_end,
    mode="overwrite",
    overwrite_schema=True,
)

log.info(f"Saved: {DEST_TABLE}")
