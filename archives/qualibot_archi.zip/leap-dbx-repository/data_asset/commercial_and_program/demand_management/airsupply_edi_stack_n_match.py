# Databricks notebook source
# MAGIC %md
# MAGIC #Customer Demand Management project
# MAGIC The aim of this second part of the project is be able to visualize both the past orders and the forecasts at an observation date. 
# MAGIC A stacking is needed, because the collect of orders and the collect forecast data are different. Indeed, orders are received daily. If you want the orders at an observation date, you have to take all orders ingested before the observation date. 
# MAGIC
# MAGIC ## Notebook purpose
# MAGIC This notebook stacks the orders and the forecasts for a given list of observation dates. 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {PIPELINE_READ_ENV}_gold.commercial_and_program_demand_management.airsupply_forecast_history
# MAGIC   - {PIPELINE_READ_ENV}_gold.commercial_and_program_demand_management.airsupply_order_history
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.commercial_and_program_demand_management.airsupply_stack_n_match
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC

# COMMAND ----------

import logging
import time

from pyspark.sql import functions as f
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException

from leap_utils.data_asset import table_utils, history_changelog
from leap_utils.common.logger import get_logger, setup_applevel_logger

LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# pipeline read env
dbutils.widgets.text("pipeline_read_env", "uat")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# pipeline write env
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# reference read env
dbutils.widgets.text("reference_read_env", "uat")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

HISTORY_EDI_TABLE = (
    f"{PIPELINE_READ_ENV}_gold.commercial_and_program_demand_management.airsupply_forecast_history"
)
HISTORY_EDI_TABLE_CL = (
    f"{PIPELINE_READ_ENV}_gold.commercial_and_program_demand_management.airsupply_forecast"
)

TRACKED_COLUMN = [
    "CollabSetKey",
    "PublishingDate",
    "OriginalCustomerForecastDemandDate",
    "OriginalCustomerForecastDemandQuantity",
    "OriginalCustomerForecastDemandDate_DateFormat",
    "OriginalCustomerForecastDemandYearMonth_DateFormat",
    "FCHeaderLastModificationDate",
    "FCHeaderCreationDate",
    "CustomerGroupCode",
    "CustomerGroupName",
    "CustomerOrgCode",
    "CustomerOrgName",
    "CustomerPlantCode",
    "CustomerPlantName",
    "OrderingOfficerCode",
    "OrderingOfficerName",
    "OrderingOfficerPhone",
    "SupplierGroupName",
    "SupplierOrgName",
    "SupplierSite",
    "SupplierSite_City",
    "SupplierPlannerCode",
    "SupplierNumber",
    "CustomerMaterialNumber",
    "CustomerMaterialDescription",
    "SupplierMaterialNumber",
    "SupplierMaterialDescription",
    "FreeKey",
    "FreekeyDescription",
    "LogisticFamilyName",
    "LogisticFamilyDescription",
    "LogisticToleranceName",
    "DVT",
    "CDT",
    "Criticality",
    "PurchasingOrganization",
    "PurchasingGroup",
    "MRPController",
    "LogisticSolution",
    "SupplyAgreementNumber",
    "DeleteFlag",
    "AllowCollab",
    "CommitRequired",
    "FCLineLastModificationDate",
    "FCLineLastModifiedBy",
    "FCLineCreationDate",
    "DataMeasure",
    "HorizonType",
    "Bucket",
    "ProgramMSN",
    "VersionNumber",
    "StandardNumber",
    "Option",
    "Exception",
    "LastCommitDate",
    "UOM",
    "ContractReference",
    "DetailInfo",
    "SupplierSAPCode",
    "DownloadedOnce",
    "Downloaded",
    "LastEDIMessage",
    "SupplierRemark",
    "AllowSupplierRemark",
    "KitHeader",
    "KitComponent",
]

forecasts_columns = [
    "CustomerMaterialNumber",
    "CustomerMaterialDescription",
    "SupplierMaterialNumber",
    "SupplierMaterialDescription",
    "MaterialNumber",
    "ProgramMSN",
    "MSN_Cleaned",
    "Material_MSN",
    "EDISnapshotDate",
    "HorizonType",
    "PublishingDate_DateFormat",
    "OriginalCustomerForecastDemandDate_DateFormat",
    "OriginalCustomerForecastDemandQuantity",
    "Start_Validity",
    "End_Validity",
    "FCHeaderCreationDate",
    "_meta_is_current",
    "_meta_is_latest",
    "SelectedRows",
    "OriginalCustomerForecastDemandDate_DateFormat_week_number",
]
orders_columns = [
    "MATERIAL_CUSTOMER_NUMBER",
    "MATERIAL_CUSTOMER_DESC",
    "MATERIAL_SUPPLIER_NUMBER",
    "MATERIAL_SUPPLIER_DESC",
    "PO_MSN",
    "PO_Status",
    "MSN_Cleaned",
    "MaterialNumber",
    "Material_MSN",
    "EDISnapshotDate",
    "PO_LastMod_DateFormat",
    "PO_CollabReqQty",
    "PO_CollabReqDate_DateFormat",
    "PO_PoNumber",
    "PO_PosNumber",
    "PO_UpdateVersion",
    "Start_Validity",
    "End_Validity",
    "_meta_is_current",
    "_meta_is_latest",
    "PO_LineLastMod",
    "PO_CollabReqDate_DateFormat_week_number",
]
DEFAULT_CHECKS_COLUMNS = [
    "HorizonType",
    "OriginalCustomerForecastDemandDate_DateFormat",
    "OriginalCustomerForecastDemandQuantity",
]
forecasts_columns_map = {
    "LastKnownClientUpdateDate": f.col("FCHeaderCreationDate"),
    "PO_Status": f.lit("FORECAST"),
    "PO_PoNumber": f.lit("ND"),
    "PO_PosNumber": f.lit("ND"),
    "PO_UpdateVersion": f.lit("ND"),
    "is_orders_in_flex": f.lit(False),
    "is_PO_needs_duplicate": f.lit(False),
}
orders_columns_names_map = {
    "MATERIAL_CUSTOMER_NUMBER": "CustomerMaterialNumber",
    "MATERIAL_CUSTOMER_DESC": "CustomerMaterialDescription",
    "MATERIAL_SUPPLIER_NUMBER": "SupplierMaterialNumber",
    "MATERIAL_SUPPLIER_DESC": "SupplierMaterialDescription",
    "PO_MSN": "ProgramMSN",
    "PO_CollabReqQty": "OriginalCustomerForecastDemandQuantity",
    "PO_CollabReqDate_DateFormat": "OriginalCustomerForecastDemandDate_DateFormat",
    "PO_CollabReqDate_DateFormat_week_number": "OriginalCustomerDemandDate_week_number",
}


PO_CANCELLED_STATUS = "CANCELLED"

stack_n_match = (
    f"{PIPELINE_WRITE_ENV}_gold.commercial_and_program_demand_management.airsupply_stack_n_match"
)
orders_history = (
    f"{REFERENCE_READ_ENV}_gold.commercial_and_program_demand_management.airsupply_order_history"
)

# COMMAND ----------

df_orders_history = spark.read.table(orders_history)

# COMMAND ----------

# MAGIC %md
# MAGIC # Pre - processing

# COMMAND ----------

# MAGIC %md
# MAGIC ## Forecast

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create History change log

# COMMAND ----------

def process_table(
    table_name: str,
    input_table_path: str,
) -> str:
    """
    process ingestion of a table
    return {output_table_path} if ok, or None if not
    """
    startTime = time.time()

    # Read stack table
    df_table_stack = spark.read.table(input_table_path)
    df_table_stack = df_table_stack.withColumn(
        "FCHeaderCreationDate",
        f.date_format(
            f.unix_timestamp(f.col("FCHeaderCreationDate"), "yyyyMMddHHmmss").cast(
                "timestamp"
            ),
            "yyyy-MM-dd",
        ),
    )
    df_table_stack = df_table_stack.withColumn(
        "FCHeaderCreationDate",
        f.when(
            f.col("FCHeaderCreationDate").isNull(), f.col("EDISnapshotDate")
        ).otherwise(f.col("FCHeaderCreationDate")),
    )

    df_table_stack = df_table_stack.withColumn(
        "sort_duplicate",
        f.when(f.col("SelectedRows") == "Yes", f.lit(1)).otherwise(f.lit(0)),
    )

    Unity_Catalog_Table_Name = f"{table_name.lower()}_history_change_log"
    history_change_log_table_path = Unity_Catalog_Table_Name

    # get the first_existing_timestamp_of_extraction
    first_existing_timestamp_of_extraction_in_stack = df_table_stack.select(
        f.min("FCHeaderCreationDate")
    ).first()["min(FCHeaderCreationDate)"]
    log.info(
        f"the first timestamp in Stack table is : {first_existing_timestamp_of_extraction_in_stack}"
    )

    # get the last_existing_timestamp_of_extraction
    last_existing_timestamp_of_extraction_in_stack = df_table_stack.select(
        f.max("FCHeaderCreationDate")
    ).first()["max(FCHeaderCreationDate)"]
    log.info(
        f"the last timestamp in Stack table is : {last_existing_timestamp_of_extraction_in_stack}"
    )

    # Below the computation of the full history table
    log.info(f"Computing the FULL history changelog table {Unity_Catalog_Table_Name}")

    df_history_final = history_changelog.initialize_history_changelog(
        df=df_table_stack,
        id_column_list=["CustomerMaterialNumber", "MSN_Cleaned"],
        sort_column="FCHeaderCreationDate",
        tracked_column_list=TRACKED_COLUMN,
        data_extraction_mode="FULL",
        calculate_discontinuities=False,
        allow_duplicate=True,
        duplicate_sorting=["EDISnapshotDate" ,"sort_duplicate"],
    )
    return df_history_final, history_change_log_table_path

# COMMAND ----------

df_forecast, history_change_log_table_path = process_table(
    HISTORY_EDI_TABLE_CL, HISTORY_EDI_TABLE
)
df_forecast_date_modified = df_forecast.withColumn(
    "End_Validity",
    f.when(
        f.col("End_Validity") > f.date_add(f.col("EDIsnapshotDate"), 7),
        f.date_add(f.col("EDIsnapshotDate"), 7),
    ).otherwise(f.col("End_Validity")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Filter, rename and select

# COMMAND ----------

df_forecasts = (
    df_forecast_date_modified.filter(
        ((f.col("Program") == "SA") | (f.col("Program") == "XWB"))
        & (f.col("OriginalCustomerForecastDemandQuantity") > 0)
    )
    .select(forecasts_columns)
    .withColumns(forecasts_columns_map)
    .withColumnRenamed(
        "OriginalCustomerForecastDemandDate_DateFormat_week_number",
        "OriginalCustomerDemandDate_week_number",
    )
    .drop("PublishingDate_DateFormat", "FCHeaderCreationDate")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Order

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Aggregation
# MAGIC
# MAGIC Handle duplicate for "KIT" article

# COMMAND ----------

serie_condition = (
    (f.col("PO_OrderType") == "CALLUP") & (f.lower(f.col("PO_DocType")) == "call-up")
) | ((f.col("PO_OrderType") == "OTHER") & (f.lower(f.col("PO_DocType")) == "manual"))

df_orders_filtred = df_orders_history.filter(
    ((f.col("Program") == "SA") & serie_condition) | (f.col("Program") == "XWB")
).withColumn(
    "PO_CreationDate_DateFormat",
    f.to_date(f.substring(f.col("PO_CreationDate"), 1, 8), "yyyyMMdd"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Filter, rename and select
# MAGIC
# MAGIC For "KIT" orders, an order is defined across three different rows. The goal is to aggregate these three rows by extracting the useful information from each row according to certain rules.

# COMMAND ----------

df_orders_kit = df_orders_filtred.filter((f.col("PO_DocType") == "KIT") & (f.col("PO_Status")!="CANCELLED"))
df_orders_wo_kit = df_orders_filtred.filter((f.col("PO_DocType") != "KIT") | ( (f.col("PO_DocType") == "KIT") & (f.col("PO_Status")=="CANCELLED")))

# COMMAND ----------

rules = {
    'PO_CommodityGroup': f.col("PO_KitHeader") == True,
    'PO_CreationDate': f.col("PO_KitHeader") == True,
    'PO_KitComponent': f.col("PO_KitHeader") == True,
    'PO_LineLastMod': f.col("PO_KitHeader") == True,
    'PO_LinePoPubDate': f.col("PO_KitHeader") == True,
    'PO_PartNumber': f.col("PO_KitHeader") == True,
    'PO_TrackingNumber': f.col("PO_KitHeader") == True,
    'PO_KitHeader': f.col("PO_KitHeader") == True,
    'MATERIAL_CUSTOMER_DESC': f.col("PO_PosNumber") == "00002",
    'PO_PosNumber': f.col("PO_PosNumber") == "00002",
    'MATERIAL_CUSTOMER_NUMBER': f.col("PO_PosNumber") == "00002",
    'MATERIAL_SUPPLIER_DESC': f.col("PO_PosNumber") == "00002",
    'MATERIAL_SUPPLIER_NUMBER': f.col("PO_PosNumber") == "00002",
    'PO_FinalLocation': f.col("PO_PosNumber") == "00002",
    'PO_LineDescr': f.col("PO_PosNumber") == "00002",
    'PO_LineText': f.col("PO_PosNumber") == "00002",
    'PO_SerialNumReq': f.col("PO_PosNumber") == "00002",
    "Program": f.col("PO_PosNumber") == "00002",
    "MSN_Int": f.col("PO_PosNumber") == "00002",
    "MSN_Cleaned": f.col("PO_PosNumber") == "00002", 
    "MSN_Long": f.col("PO_PosNumber") == "00002",
    "MaterialNumber": f.col("PO_PosNumber") == "00002",
    "Material_MSN": f.col("PO_PosNumber") == "00002",
    'PARTNER_RELATION_CUSTOMER_PLANTCODE': (f.col("PO_OriginalPrice").isNotNull()) & (f.col("PO_OriginalPrice")!=0),
    'PARTNER_RELATION_CUSTOMER_PLANTNAME': (f.col("PO_OriginalPrice").isNotNull()) & (f.col("PO_OriginalPrice")!=0),
    'PO_AgreedPrice': (f.col("PO_OriginalPrice").isNotNull()) & (f.col("PO_OriginalPrice")!=0),
    'PO_CollabPrice': (f.col("PO_OriginalPrice").isNotNull()) & (f.col("PO_OriginalPrice")!=0),
    'PO_OriginalPrice': (f.col("PO_OriginalPrice").isNotNull()) & (f.col("PO_OriginalPrice")!=0),
    'PO_ProdOrderNum': (f.col("PO_OriginalPrice").isNotNull()) & (f.col("PO_OriginalPrice")!=0),
    'PO_RequestedAmount': (f.col("PO_OriginalPrice").isNotNull()) & (f.col("PO_OriginalPrice")!=0),
}

simple_columns = [column for column in df_orders_kit.columns if column not in rules.keys() and column not in ["PO_PoNumber", "EDISnapshotDate", "End_Validity"]]
min_columns = ["End_Validity"]
agg_exprs = []

for col_name, condition in rules.items():
    agg_exprs.append(f.first(f.when(condition, f.col(col_name)), ignorenulls=True).alias(col_name))

for col_name in min_columns:
    agg_exprs.append(
        f.min(f.col(col_name)).alias(col_name)
    )

for col_name in simple_columns:
    agg_exprs.append(f.first(f.col(col_name), ignorenulls=True).alias(col_name))

agg_exprs.append(
    f.count("*").alias("row_count")
)

agg_exprs.append(
    f.concat_ws(",", f.collect_list("PO_PosNumber")).alias("PosNumber_concat")
)

df_orders_kit_agg = df_orders_kit.groupBy("PO_PoNumber", "EDISnapshotDate").agg(
    *agg_exprs
).select(df_orders_kit.columns + ["row_count", "PosNumber_concat"])

# COMMAND ----------

condition_to_columns = {
    "PO_KitHeader": [
        col_name for col_name, condition in rules.items() 
        if str(condition) == str((f.col("PO_KitHeader") == True))
    ],
    "PO_PosNumber": [
        col_name for col_name, condition in rules.items()
        if str(condition) == str((f.col("PO_PosNumber") == "00002"))
    ],
    "PO_OriginalPrice": [
        col_name for col_name, condition in rules.items()
        if str(condition) == str((f.col("PO_OriginalPrice").isNotNull()) & (f.col("PO_OriginalPrice")!=0))
    ]
}

window_spec = Window.partitionBy("PO_PoNumber").orderBy("start_validity")

rules_to_complete_null_columns = {
    "rule_1": {
        "condition": (f.col("row_count") == 2) & (f.col("PO_KitHeader") == True) & (f.col("PO_PosNumber") == "00002"),
        "columns": condition_to_columns["PO_OriginalPrice"]
    },
    "rule_2": {
        "condition": (
            (f.col("row_count") == 2) & (f.col("PO_KitHeader") == True) & 
            (f.col("PO_OriginalPrice").isNotNull()) & (f.col("PO_OriginalPrice") != 0)
        ),
        "columns": condition_to_columns["PO_PosNumber"]
    },
    "rule_3": {
        "condition": (
            (f.col("row_count") == 2) & (f.col("PO_PosNumber") == "00002") & 
            (f.col("PO_OriginalPrice").isNotNull()) & (f.col("PO_OriginalPrice") != 0)
        ),
        "columns": condition_to_columns["PO_KitHeader"]
    },
    "rule_4": {
        "condition": (f.col("row_count") == 1) & (f.col("PO_KitHeader") == True),
        "columns": condition_to_columns["PO_OriginalPrice"] + condition_to_columns["PO_PosNumber"]
    },
    "rule_5": {
        "condition": (f.col("row_count") == 1) & (f.col("PO_PosNumber") == "00002"),
        "columns": condition_to_columns["PO_OriginalPrice"] + condition_to_columns["PO_KitHeader"]
    },
    "rule_6": {
        "condition": (f.col("row_count") == 1) & (f.col("PO_OriginalPrice").isNotNull()) & (f.col("PO_OriginalPrice") != 0),
        "columns": condition_to_columns["PO_KitHeader"] + condition_to_columns["PO_PosNumber"]
    },
}
df_orders_kit_complete = df_orders_kit_agg

lagged_dict = {}

for rule_name, rule in rules_to_complete_null_columns.items():
    condition = rule["condition"]
    for col_name in rule["columns"]:
        lagged_dict[col_name] = f.when(condition, f.lag(col_name).over(window_spec)).otherwise(f.col(col_name))

df_orders_kit_complete = df_orders_kit_complete.withColumns(
    lagged_dict
)

# COMMAND ----------

df_orders_fin = df_orders_wo_kit.unionByName(df_orders_kit_complete.select(df_orders_kit.columns))

# COMMAND ----------

df_orders = (
    df_orders_fin
    .select(orders_columns)
    .filter(f.col("MSN_Cleaned").isNotNull())
    .withColumn("SelectedRows", f.lit("Yes"))
    .withColumn(
        "LastKnownClientUpdateDate",
        f.coalesce(f.to_date(f.col("PO_LineLastMod"), "yyyyMMddHHmmss"), f.col("Start_Validity")),
    )
    .withColumn("HorizonType", f.lit("FIRM"))
    .withColumnsRenamed(orders_columns_names_map)
    .drop("PO_LastMod_DateFormat", "PO_LineLastMod")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

window_spec = Window.partitionBy("Material_MSN").orderBy("Start_Validity")

df_orders_prev_order = df_orders.withColumn(
    "has_not_previous_cancelled",
    f.max(f.when(~f.col("PO_Status").isin(PO_CANCELLED_STATUS), 1).otherwise(0)).over(
        window_spec.rowsBetween(Window.unboundedPreceding, -1)
    ),
)
df_orders_prev_order = df_orders_prev_order.withColumn(
    "prev_PO_PoNumbers",
    f.collect_list("PO_PoNumber").over(
        window_spec.rowsBetween(Window.unboundedPreceding, -1)
    ),
).withColumn(
    "prev_PO_PosNumbers",
    f.collect_list("PO_PosNumber").over(
        window_spec.rowsBetween(Window.unboundedPreceding, -1)
    ),
)

# Filter list to keep only values different from actual lines
df_orders_prev_order_filtered = df_orders_prev_order.withColumn(
    "prev_PO_PoNumbers_filtered",
    f.expr("filter(prev_PO_PoNumbers, x -> x != PO_PoNumber)"),
).withColumn(
    "prev_PO_PosNumbers_filtered",
    f.expr("filter(prev_PO_PosNumbers, x -> x != PO_PosNumber)"),
)

df_orders_duplicate = df_orders_prev_order_filtered.withColumn(
    "is_PO_needs_duplicate",
    f.when(
        (
            (f.col("has_not_previous_cancelled") == 1)
            & (
                (f.size(f.col("prev_PO_PoNumbers_filtered")) > 0)
                | (f.size(f.col("prev_PO_PosNumbers_filtered")) > 0)
            )
        ),
        f.lit(True),
    ).otherwise(f.lit(False)),
).drop(
    "has_not_previous_cancelled",
    "prev_PO_PoNumbers_filtered",
    "prev_PO_PosNumbers_filtered",
    "prev_PO_PoNumbers",
    "prev_PO_PosNumbers",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Firm orders within forecast horizon
# MAGIC For Singular Aircraft, the firm horizon (horizon for firm orders) is fixed at 4 weeks. However, it happens sometimes that Airbus makes orders outside this horizon (in the flex horizon). The aim of this section is to report orders in flex horizon.  

# COMMAND ----------

df_orders_flagged = df_orders_duplicate.withColumn(
    "is_orders_in_flex",
    f.when(
        f.datediff(
            f.col("OriginalCustomerForecastDemandDate_DateFormat"),
            f.col("LastKnownClientUpdateDate"),
        )
        > 28,
        f.lit(True),
    ).otherwise(f.lit(False)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Firm orders back to forecast
# MAGIC For SA, Airbus can not modify an order (it is the contract). However, it happens that Airbus create a forecast on the same (Material; MSN) than an order. The aim of this section is to report those cases.

# COMMAND ----------

df_output = df_orders_flagged.unionByName(df_forecasts)
df_output_filtered = df_output.filter(f.col("PO_Status") != PO_CANCELLED_STATUS)
df_type = df_output_filtered.withColumn(
    "Ord_or_forecast",
    f.when(f.col("HorizonType") != "FIRM", f.lit("Forecast")).otherwise(f.lit("Order")),
)
df_orders_and_forecasts = df_type

# COMMAND ----------

window_spec = Window.partitionBy("Material_MSN").orderBy("LastKnownClientUpdateDate")

df_orders_and_forecasts = df_orders_and_forecasts.withColumn(
    "has_previous_order",
    f.max(
        f.when(f.col("Ord_or_forecast") == "Order", f.lit(True)).otherwise(f.lit(False))
    ).over(window_spec.rowsBetween(Window.unboundedPreceding, -1)),
)

df_orders_and_forecasts_prev = df_orders_and_forecasts.withColumn(
    "is_reverted_forecast",
    f.when(
        (f.col("Ord_or_forecast") == "Forecast") & (f.col("has_previous_order")),
        f.lit(True),
    ).otherwise(f.lit(False)),
).drop("has_previous_order")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adjust Forecast end validity date
# MAGIC
# MAGIC To Match Forecast and orders, end_validity of forecast are adjusted to:
# MAGIC - start validity of following orders
# MAGIC - 7 days after EDISnapshot date if no orders where found
# MAGIC

# COMMAND ----------

# replace start validity when = to 1900-01-01
df_orders_and_forecasts_compute_date = df_orders_and_forecasts_prev.withColumn(
    "Start_Validity",
    f.when(
        f.col("Start_Validity") == "1900-01-01",
        f.col("LastKnownClientUpdateDate"),
    ).otherwise(f.col("Start_Validity")),
)

# COMMAND ----------

df_orders_and_forecasts_lead = df_orders_and_forecasts_compute_date.withColumn(
    "lead_status", f.lead("Ord_or_forecast", 1).over(window_spec)
).withColumn("lead_start_validity", f.lead("Start_Validity", 1).over(window_spec))

df_orders_and_forecasts_corrected = df_orders_and_forecasts_lead.withColumn(
    "End_Validity",
    f.when(
        (
            (f.col("Ord_or_forecast") == "Forecast")
            & (f.col("lead_status") == "Order")
            & (~f.col("is_reverted_forecast"))
            & (f.datediff(f.col("lead_start_validity"), f.col("EDIsnapshotDate")) <= 7)
        ),
        f.col("lead_start_validity"),
    )
    .when(
        (
            (f.col("Ord_or_forecast") == "Forecast")
            & (
                (f.col("lead_status").isNull())
                | (
                    f.col("is_reverted_forecast")
                    | (f.col("End_Validity") > f.date_add(f.col("EDIsnapshotDate"), 7))
                )
            )
        ),
        f.date_add(f.col("EDISnapshotDate"), 7),
    )
    .otherwise(f.col("End_Validity")),
).drop("lead_status", "lead_start_validity")

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Outputs - Leap Tables - Stack & Match history

# COMMAND ----------

try:
    table_utils.save_table(
        dest_table=stack_n_match, df=df_orders_and_forecasts_corrected, mode="overwrite"
    )
except AnalysisException as e:
    log.error(
        f"Table {stack_n_match} has not been created, an error occured during creation."
        f"\n Error is : \n {e}"
    )
    raise e

# COMMAND ----------


