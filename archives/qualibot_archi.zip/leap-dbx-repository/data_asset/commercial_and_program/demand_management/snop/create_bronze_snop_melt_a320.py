# Databricks notebook source
# MAGIC %md
# MAGIC #Customer Demand Management project 
# MAGIC
# MAGIC ## Notebook purpose
# MAGIC S&OP uploaded in the web app union the S&OP before dash  
# MAGIC **Description:**  
# MAGIC When the user upload his S&OP file, it creates (or replace) two bronze tables:
# MAGIC    - snop_latest : table of the latest s&op upload by the user as it is 
# MAGIC    - melt_snop_latest : table of the  latest s&op upload melt, including the user email and the load date.
# MAGIC
# MAGIC The aim here is to historise the bronze snop melt table.
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC  -  {pipeline_read_env}_bronze.commercial_and_program_demand_management.snop_melt_a320_latest
# MAGIC  -  {pipeline_read_env}_bronze.commercial_and_program_demand_management.snop_melt_a320_history
# MAGIC  -  {refrence_read_env}_gold.commercial_and_program_deman_dmanagement.snop_history
# MAGIC  -  {refrence_read_env}_bronze.commercial_and_program_demand_management.snop_melt_a320_history
# MAGIC  
# MAGIC **Output table(s):**  
# MAGIC   - {pipeline_write_env}_bronze.airsupply.snop_melt_a320_history
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC App request 
# MAGIC
# MAGIC **PS: Iniialization is one shot**

# COMMAND ----------

from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

# reference read env
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# pipeline read env
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# reference read env
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# initialize
dbutils.widgets.text("initialize", "true")
INITIALIZE = dbutils.widgets.get("initialize").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ####Config

# COMMAND ----------

SNOP_LATEST_TABLE = f"{PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.snop_melt_a320_latest"
SNOP_HISTORY_TABLE = f"{PIPELINE_WRITE_ENV}_bronze.commercial_and_program_demand_management.snop_melt_a320_history"
SNOP_OLD_TABLE = f"{REFERENCE_READ_ENV}_gold.commercial_and_program.snop_history"
SNOP_HISTORY_REFERENCE_TABLE = (
    f"{REFERENCE_READ_ENV}_bronze.airsupply.snop_melt_a320_history"
)
# check if the table exists and initialization is not requested
table_history_exist_bool = table_utils.UnityCatalogCheckTableExists(
    SNOP_HISTORY_TABLE
) and not (INITIALIZE)
# Email to be used for old S&OP before web app requests
replacement_email = "unknown"

PROCESS_COLUMNS_DICT = {
    "SNOPSnapshotDate": f.to_date(f.col("SNOPSnapshotDate"), "yyyy-MM-dd"),
    "TargetNumberOfShipsets": f.col("TargetNumberOfShipsets").cast("int"),
}

# COMMAND ----------

# MAGIC %md
# MAGIC ####Inputs

# COMMAND ----------

# read the table created by the app
df_latest = spark.read.table(SNOP_LATEST_TABLE)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Preparation: Cast columns

# COMMAND ----------

# cast date to date and number to int
df_latest = df_latest.withColumns(PROCESS_COLUMNS_DICT)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Preparation: Get the unique ID of the latest EDI

# COMMAND ----------

# get leatest ID
SNOPSnapshotDate_latest, SNOPUserEmail_latest = df_latest.select(
    "SNOPSnapshotDate", "SNOPUserEmail"
).collect()[0]
ID_latest = f"{SNOPSnapshotDate_latest}_{SNOPUserEmail_latest}"

# COMMAND ----------

# MAGIC %md
# MAGIC ####Transformation: Create History if needed and update it with latest

# COMMAND ----------

if table_history_exist_bool:
    # if the history exists read it
    df_history = spark.read.table(SNOP_HISTORY_TABLE)

else:
    # if the history table does not exist read the prod existing table and the old table before the dash app
    df_history = spark.read.table(SNOP_HISTORY_REFERENCE_TABLE).withColumn(
        "SNOPUserEmail",
        f.when(f.col("SNOPUserEmail").isNull(), f.lit(replacement_email)).otherwise(
            f.col("SNOPUserEmail")
        ),
    )

    df_history_old = spark.read.table(SNOP_OLD_TABLE).withColumn(
        "SNOPUserEmail", f.lit(replacement_email)
    )
    common_cols = [
        "OriginalCustomerForecastDemandYearMonth_DateFormat",
        "SNOPSnapshotDate",
        "SNOPUserEmail",
        "SupplierMaterialDescription",
        "SupplierMaterialNumber",
        "TargetNumberOfShipsets",
    ]
    df_history_old = df_history_old.select(*common_cols)
    # remove if it is already there
    df_history.join(
        df_history_old, on=["SNOPSnapshotDate", "SNOPUserEmail"], how="left_anti"
    )
    df_history = df_history.unionByName(df_history_old, allowMissingColumns=True)
    df_history = df_history.orderBy(f.col("SNOPSnapshotDate").asc())

# COMMAND ----------

# Add latest if it is not already there
df_history_enriched = df_history.withColumn(
    "ID", f.concat_ws("_", f.col("SNOPSnapshotDate"), f.col("SNOPUserEmail"))
)
df_history_enriched = df_history_enriched.filter(f.col("ID") != ID_latest)
df_history_enriched = df_history_enriched.drop("ID")
new_df_history_enriched = df_history_enriched.unionByName(
    df_latest, allowMissingColumns=True
)

# COMMAND ----------

# Save the history snop table
if (df_history.count() != new_df_history_enriched.count()) | INITIALIZE:
    new_df_history_enriched = new_df_history_enriched.withColumns(PROCESS_COLUMNS_DICT)
    table_utils.save_table(
        dest_table=SNOP_HISTORY_TABLE,
        df=new_df_history_enriched,
        overwrite_schema=True,
        mode="overwrite",
    )
