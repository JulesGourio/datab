# Databricks notebook source
# MAGIC %md
# MAGIC #Customer Demand Management project 
# MAGIC ## Notebook purpose
# MAGIC S&OP uploaded in Web App 
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim here is to create the silver table. As it is today, the silver table is the same than the bronze melt table with a slight preparation
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC  - {PIPELINE_READ_ENV}_bronze.airsupply.snop_melt_a350_latest
# MAGIC  - {PIPELINE_READ_ENV}_bronze.airsupply.snop_melt_a350_history
# MAGIC  
# MAGIC **Output table(s):**  
# MAGIC  - {PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.snop_melt_a350_latest
# MAGIC  - {PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.snop_melt_a350_history
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC create_bronze_snop

# COMMAND ----------

from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

# reference read env
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# pipeline read env
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Config

# COMMAND ----------

SNOP_SILVER_TABLE = f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.snop_melt_a350_latest"
SNOP_SILVER_HISTORY_TABLE = f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.snop_melt_a350_history"

SNOP_BRONZE_TABLE = f"{PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.snop_melt_a350_latest"
SNOP_BRONZE_HISTORY_TABLE = f"{PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.snop_melt_a350_history"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Inputs

# COMMAND ----------

df_snop_bronze_latest = spark.read.table(SNOP_BRONZE_TABLE)
df_snop_bronze_history = spark.read.table(SNOP_BRONZE_HISTORY_TABLE)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Preparation: Get the forecast/demand date to avoid long strings

# COMMAND ----------

# get the year and month from date
df_silver_latest = df_snop_bronze_latest.withColumn(
    "OriginalCustomerForecastDemandYearMonth_DateFormat",
    f.substring("OriginalCustomerForecastDemandYearMonth_DateFormat", 1, 7),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Outputs :  save the silver S&OP tables

# COMMAND ----------

# save latest
table_utils.save_table(
    dest_table=SNOP_SILVER_TABLE,
    df=df_silver_latest,
    overwrite_schema=False,
    mode="overwrite",
)
table_utils.save_table(
    dest_table=SNOP_SILVER_HISTORY_TABLE,
    df=df_silver_latest,
    overwrite_schema=False,
    mode="append",
)
