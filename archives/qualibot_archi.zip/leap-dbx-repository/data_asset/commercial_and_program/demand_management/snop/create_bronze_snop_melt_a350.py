# Databricks notebook source
# MAGIC %md
# MAGIC #Customer Demand Management project 
# MAGIC
# MAGIC ## Notebook purpose
# MAGIC S&OP uploaded in the web app union the S&OP before dash  
# MAGIC **Description:**  
# MAGIC When the user upload his S&OP file, it creates (or replace) two bronze tables:
# MAGIC    - snop_latest : table of the latest s&op upload by the user as it is 
# MAGIC    - melt_snop_latest : table of the  latest s&op upload melt, including the user email and the load date.
# MAGIC
# MAGIC The aim here is to historise the bronze snop melt table.
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC  -  {pipeline_read_env}_bronze.commercial_and_program_demand_management.snop_melt_a320_latest
# MAGIC  -  {pipeline_read_env}_bronze.commercial_and_program_demand_management.snop_melt_a320_history
# MAGIC  -  {refrence_read_env}_gold.commercial_and_program_deman_dmanagement.snop_history
# MAGIC  -  {refrence_read_env}_bronze.commercial_and_program_demand_management.snop_melt_a320_history
# MAGIC  
# MAGIC **Output table(s):**  
# MAGIC   - {pipeline_write_env}_bronze.airsupply.snop_melt_a320_history
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC App request 
# MAGIC
# MAGIC **PS: Iniialization is one shot**

# COMMAND ----------

from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

# reference read env
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# pipeline read env
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# reference read env
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# initialize
dbutils.widgets.text("initialize", "true")
INITIALIZE = dbutils.widgets.get("initialize").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ####Config

# COMMAND ----------

SNOP_LATEST_TABLE = f"{PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.snop_melt_a350_latest"
SNOP_HISTORY_TABLE = f"{PIPELINE_WRITE_ENV}_bronze.commercial_and_program_demand_management.snop_melt_a350_history"

replacement_email = "unknown"

PROCESS_COLUMNS_DICT = {
    "SNOPSnapshotDate": f.to_date(f.col("SNOPSnapshotDate"), "yyyy-MM-dd"),
    "TargetNumberOfShipsets": f.col("TargetNumberOfShipsets").cast("int"),
}

# COMMAND ----------

# MAGIC %md
# MAGIC ####Inputs

# COMMAND ----------

# read the table created by the app
df_latest = spark.read.table(SNOP_LATEST_TABLE)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Preparation: Cast columns

# COMMAND ----------

# cast date to date and number to int
df_latest = df_latest.withColumns(PROCESS_COLUMNS_DICT)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Output

# COMMAND ----------

# MAGIC %md
# MAGIC ## History

# COMMAND ----------

table_utils.save_table(
    dest_table=SNOP_HISTORY_TABLE,
    df=df_latest,
    overwrite_schema=False,
    mode="append",
)
