# Databricks notebook source
# MAGIC %md
# MAGIC #Customer Demand Management project 
# MAGIC
# MAGIC ## Notebook purpose
# MAGIC S&OP uploaded in Web App 
# MAGIC
# MAGIC **Description:** 
# MAGIC The aim here is to create the gold table, that is the same than the silver table.
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC  - {pipeline_read_env}_silver.commercial_and_program_demand_management.snop_melt_a320_latest
# MAGIC  - {pipeline_read_env}_silver.commercial_and_program_demand_management.snop_melt_a320_history
# MAGIC  
# MAGIC **Output table(s):**  
# MAGIC  - {pipeline_write_env}_gold.commercial_and_program_demand_management.snop_melt_a320_latest
# MAGIC  - {pipeline_write_env}_gold.commercial_and_program_demand_management.snop_melt_a320_history
# MAGIC
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Create_silver_snop

# COMMAND ----------

from leap_utils.data_asset import table_utils

# COMMAND ----------

# reference read env
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# pipeline read env
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Config

# COMMAND ----------

get_input_table = (
    lambda suffix: f"{PIPELINE_READ_ENV}_silver.commercial_and_program_demand_management.snop_melt_a320_{suffix}"
)
get_output_table = (
    lambda suffix: f"{PIPELINE_WRITE_ENV}_gold.commercial_and_program_demand_management.snop_melt_a320_{suffix}"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input

# COMMAND ----------

df_silver_latest, df_silver_history = spark.read.table(
    get_input_table("latest")
), spark.read.table(get_input_table("history"))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Save

# COMMAND ----------

table_utils.save_table(
    dest_table=get_output_table("latest"),
    df=df_silver_latest,
    mode="overwrite",
    overwrite_schema=True,
)
table_utils.save_table(
    dest_table=get_output_table("history"),
    df=df_silver_history,
    mode="overwrite",
    overwrite_schema=True,
)
