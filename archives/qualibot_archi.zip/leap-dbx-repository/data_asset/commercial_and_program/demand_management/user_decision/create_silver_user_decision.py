# Databricks notebook source
# MAGIC %md
# MAGIC #Customer Demand Management project 
# MAGIC
# MAGIC ## Notebook purpose
# MAGIC User decision  uploaded in Web App 
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim here is to create the silver table. As it is today, the silver table is the same than the bronze table.
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC  - {PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.user_decision_latest
# MAGIC  - {PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.user_decision_history
# MAGIC  
# MAGIC **Output table(s):**  
# MAGIC  - {PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.user_decision_latest
# MAGIC  - {PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.user_decision_history
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC create_bronze_snop

# COMMAND ----------

from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

# reference read env
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# pipeline read env
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Config

# COMMAND ----------

UD_SILVER_TABLE = f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.user_decision_latest"
UD_SILVER_HISTORY_TABLE = f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.user_decision_history"

UD_BRONZE_TABLE = f"{PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.user_decision_latest"
UD_BRONZE_HISTORY_TABLE = f"{PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.user_decision_history"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Inputs

# COMMAND ----------

df_ud_bronze_latest = spark.read.table(UD_BRONZE_TABLE)
df_ud_bronze_history = spark.read.table(UD_BRONZE_HISTORY_TABLE)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Outputs :  save the silver S&OP tables

# COMMAND ----------

# save latest
table_utils.save_table(
    dest_table=UD_SILVER_TABLE,
    df=df_ud_bronze_latest,
    overwrite_schema=True,
    mode="overwrite",
)
table_utils.save_table(
    dest_table=UD_SILVER_HISTORY_TABLE,
    df=df_ud_bronze_history,
    overwrite_schema=True,
    mode="overwrite",
)
