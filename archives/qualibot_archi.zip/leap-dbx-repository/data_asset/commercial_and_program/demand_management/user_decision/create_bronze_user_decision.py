# Databricks notebook source
# MAGIC %md
# MAGIC #Customer Demand Management project 
# MAGIC
# MAGIC ## Notebook purpose
# MAGIC The User Decision table is defined as a table where users choose whether to apply smoothing, not apply smoothing, or delete certain part numbers from the weekly Forecast EDI.
# MAGIC
# MAGIC **Description:**  
# MAGIC When the user upload his choices, it creates (or replace) the bronze table below:
# MAGIC    - user_decision_latest: table of the latest user_decision
# MAGIC The aim here is to historise the bronze user_decision-table
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC  -  {pipeline_read_env}_bronze.commercial_and_program_demand_management.user_decision_latest
# MAGIC  -  {pipeline_read_env}_bronze.commercial_and_program_demand_management.user_decision_history
# MAGIC  
# MAGIC **Output table(s):**  
# MAGIC   - {pipeline_write_env}_bronze.commercial_and_program_demand_management.user_decision_history
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC App request 

# COMMAND ----------

import logging

from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

from leap_utils.common.logger import get_logger, setup_applevel_logger

LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# reference read env
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# pipeline read env
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("program", "SA")
PROGRAM = dbutils.widgets.get("program")

program_model = ""
if PROGRAM == "SA":
    program_model = "a320"
elif PROGRAM == "XWB":
    program_model = "a350"

log.info(f"PROGRAM: {PROGRAM}")

# COMMAND ----------

# MAGIC %md
# MAGIC ####Config

# COMMAND ----------

UD_LATEST_TABLE = f"{PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.user_decision_{program_model}_latest"
UD_GLOBAL_LATEST_TABLE = f"{PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.user_decision_latest"
UD_HISTORY_TABLE = f"{PIPELINE_WRITE_ENV}_bronze.commercial_and_program_demand_management.user_decision_history"
KEY_COLUMNS = ["Email", "Timestamp"]

# COMMAND ----------

# MAGIC %md
# MAGIC ####Inputs

# COMMAND ----------

# read the table created by the dash app
df_latest = spark.read.table(UD_LATEST_TABLE)
df_latest = df_latest.withColumn("program", f.lit(PROGRAM))

if not (table_utils.UnityCatalogCheckTableExists(UD_GLOBAL_LATEST_TABLE)):
    df_global_latest = df_latest
else:
    df_global_latest = spark.read.table(UD_GLOBAL_LATEST_TABLE)
    df_global_latest_other_prog = df_global_latest.filter(f.col("program")!=PROGRAM)
    df_global_latest = df_global_latest_other_prog.unionByName(df_latest)


# COMMAND ----------

# MAGIC %md
# MAGIC ####Preparation: Check if history is already created if not recreate it as latest

# COMMAND ----------

if not (table_utils.UnityCatalogCheckTableExists(UD_HISTORY_TABLE)):
    df_history = df_latest
else:
    df_history = spark.read.table(UD_HISTORY_TABLE).filter(f.col("program")==PROGRAM)
    # Step 1: Identify new records by performing a left anti join
    df_new_records = df_latest.join(df_history, on=KEY_COLUMNS, how="left_anti")

    # Step 2: Append the new records to the history DataFrame
    df_history = df_history.unionByName(df_new_records).unionByName(spark.read.table(UD_HISTORY_TABLE).filter(f.col("program")!=PROGRAM))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Save output

# COMMAND ----------

# Save latest
table_utils.save_table(
    dest_table=UD_GLOBAL_LATEST_TABLE,
    df=df_global_latest,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

# Save the history UD
table_utils.save_table(
    dest_table=UD_HISTORY_TABLE,
    df=df_history,
    overwrite_schema=True,
    mode="overwrite",
)
