# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC Clean and transform Data from slvr to gold
# MAGIC
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.commercial_and_program_demand_management.airsupply_order_latest
# MAGIC - {PIPELINE_WRITE_ENV}_gold.commercial_and_program_demand_management.airsupply_order_history
# MAGIC
# MAGIC **Intput :**  
# MAGIC - {PIPELINE_READ_ENV}_silver.commercial_and_program_demand_management.airsupply_edi_orders_latest
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC
# MAGIC - airsupply_order_run

# COMMAND ----------

# MAGIC %md
# MAGIC # Config

# COMMAND ----------

# MAGIC %md
# MAGIC ## Libraries

# COMMAND ----------

import logging

import pyspark.sql.functions as f

from leap_utils.common.logger import get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils
from pyspark.sql.utils import AnalysisException
from pyspark.sql.window import Window
from pyspark.sql import DataFrame


LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets & Parameters

# COMMAND ----------

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

orders_silver_history_name = (
    f"{PIPELINE_READ_ENV}_silver.commercial_and_program_demand_management.airsupply_order_history"
)
orders_gold_table_name = (
    f"{PIPELINE_WRITE_ENV}_gold.commercial_and_program_demand_management.airsupply_order_latest"
)
orders_gold_table_name_history = (
    f"{PIPELINE_WRITE_ENV}_gold.commercial_and_program_demand_management.airsupply_order_history"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Input

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tables - leap tables

# COMMAND ----------

# MAGIC %md
# MAGIC - {PIPELINE_WRITE_ENV}_gold.commercial_and_program_demand_management.airsupply_order_history : contains history of all airsupply EDI orders

# COMMAND ----------

df_orders_silver = spark.read.table(orders_silver_history_name)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Outputs - Leap Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### History

# COMMAND ----------

try:
    table_utils.save_table(
        dest_table=orders_gold_table_name_history, df=df_orders_silver, mode="overwrite"
    )
except AnalysisException as e:
    log.error(
        f"Table {orders_gold_table_name_history} has not been created, an error occured during creation."
        f"\n Error is : \n {e}"
    )
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ## Latest 

# COMMAND ----------

df_orders_latest = df_orders_silver.filter(f.col("_meta_is_latest"))

try:
    table_utils.save_table(
        dest_table=orders_gold_table_name, df=df_orders_latest, mode="overwrite"
    )
except AnalysisException as e:
    log.error(
        f"Table {orders_gold_table_name} has not been created, an error occured during creation."
        f"\n Error is : \n {e}"
    )
    raise e
