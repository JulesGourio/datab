# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Airsupply EDI forecast bronze to silver (DDMS)
# MAGIC
# MAGIC **Description:**
# MAGIC Attribute the DDMS flag to orders based on business rules.
# MAGIC
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.airsupply_order_latest_with_ddms
# MAGIC
# MAGIC **Intput :**
# MAGIC - {PIPELINE_READ_ENV}_landingzone.airsupply.orders_stack

# COMMAND ----------

# MAGIC %md
# MAGIC # Config

# COMMAND ----------

# MAGIC %md
# MAGIC ## Libraries

# COMMAND ----------

import logging

from pyspark.sql import functions as f
from pyspark.sql.utils import AnalysisException

from leap_utils.common.logger import get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils

from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("skip_task", "False")
SKIP_TASK = dbutils.widgets.get("skip_task").lower() == "true"

dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = dbutils.widgets.get("force_reinitialization").lower() == "true"

# COMMAND ----------

if SKIP_TASK:
    dbutils.notebook.exit("skip task")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Leap Table

# COMMAND ----------

df_order_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_landingzone.airsupply.orders_stack"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Hard coded variable

# COMMAND ----------

OUTPUT_TABLE_PATH = f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.airsupply_order_latest_with_ddms"

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - DDMS table

# COMMAND ----------

# Read DDMS table
DDMS_TABLE = f"{PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.nff_e2e_elec_planning"

df_ddms = (
    spark.read.table(DDMS_TABLE)
    .select(f.col("msn").alias("MSN_Int"), "a_c_tags", "year_week") # a_c_tags column contains the DDMS info
    .filter(f.col("MSN_Int").isNotNull())
    .dropDuplicates()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Latest orders
# MAGIC Orders are uploaded everyday. After the ingestion (append in orders_stack), we should get back the latest orders to enrich them with DDMS info.

# COMMAND ----------

df_order_prep = df_order_raw.filter(
    f.col("EDISnapshotDate") == df_order_raw.agg(f.max("EDISnapshotDate")).first()[0]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1: Add DDMS info

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1.1: Add a_c_tags column

# COMMAND ----------

# DBTITLE 1,Cell 22
# Add week number of EDISnapshot to join
df_order = (
    table_utils.add_week_number(df=df_order_prep, date_col="EDISnapshotDate")
    .withColumnRenamed("EDISnapshotDate_week_number", "year_week")
    .withColumn("MSN_Int", f.try_element_at(f.split(f.col("PO_MSN"), "/"), f.lit(2)).try_cast("int"))
)

# Get the latest update date of DDMS and Orders tables to check if DDMS data info have been ingested for the latest order
last_present_year_week_ddms = df_ddms.agg(f.max("year_week")).collect()[0][0]
current_year_week_order = df_order.agg(f.max("year_week")).collect()[0][0]
print(
    f"[INFO] last_year_week_ddms = {last_present_year_week_ddms}, year_week_orders = {current_year_week_order}"
)

ddms_info_present_for_last_order = (
    df_ddms.filter(f.col("year_week") == current_year_week_order).limit(1).count() > 0
)

# If DDMS info is missing for the latest orders, use the most recent available DDMS data
if not ddms_info_present_for_last_order:
    print(f"[INFO] No DDMS data for last orders, take latest DDMS info.")
    df_ddms = df_ddms.filter(f.col("year_week") == last_present_year_week_ddms)
else:
    df_ddms = df_ddms.filter(f.col("year_week") == current_year_week_order)

df_order = df_order.join(df_ddms, on="MSN_Int", how="left").drop("year_week", "MSN_Int")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1.2: Apply business rules
# MAGIC Set PO_ConfigStandard to "DDMS" only if all the following conditions are met:
# MAGIC - PARTNER_RELATION_CUSTOMER_GROUPNAME is "Airbus SAS"
# MAGIC - MATERIAL_CUSTOMER_NUMBER is DB808 or DB235
# MAGIC - DDMS info is present (as indicated in the a_c_tags column)
# MAGIC
# MAGIC Business rules defined by Sébastien DUCRUEZET on 30/01/2026.

# COMMAND ----------

df_order = (
    df_order.withColumn("is_ddms", f.col("a_c_tags").like("%DDMS%"))
    .withColumn(
        "PO_ConfigStandard",
        f.when(
            (f.col("is_ddms"))
            & (f.col("PARTNER_RELATION_CUSTOMER_GROUPNAME") == "Airbus SAS")
            & (f.col("MATERIAL_CUSTOMER_NUMBER").isin(["DB808", "DB235"])),
            f.lit("DDMS"),
        ).otherwise(
            f.col("PO_ConfigStandard"),
        ),
    )
    .drop("a_c_tags", "is_ddms")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

validation_level = "RED"

# PO_ConfigStandard is excluded since this is where the DDMS flag is added, therefore the column is changed.
cols_to_compare = [c for c in df_order_prep.columns if c != "PO_ConfigStandard"]

assert df_order_prep.columns == df_order.columns

df_gx_diff = SparkDFDataset(
    df_order_prep.select(cols_to_compare)
    .subtract(df_order.select(cols_to_compare))
    .unionByName(
        df_order.select(cols_to_compare).subtract(df_order_prep.select(cols_to_compare))
    )
)

quality_check_results = [df_gx_diff.expect_table_row_count_to_equal(0)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message="All checks inspection",
    error_message="Quality checks failed for airsupply_order_latest_with_ddms table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="airsupply_order_latest_with_ddms",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# DBTITLE 1,Cell 27
# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

try:
    table_utils.save_table(
        dest_table=OUTPUT_TABLE_PATH, df=df_order, mode="overwrite"
    )
    
except AnalysisException as e:
    log.error(
        f"Table {OUTPUT_TABLE_PATH} has not been created, an error occured during creation."
        f"\n Error is: \n {e}"
    )
    raise e
