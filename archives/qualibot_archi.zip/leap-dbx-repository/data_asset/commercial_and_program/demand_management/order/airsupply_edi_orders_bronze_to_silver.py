# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Airsupply EDI orders Bronze to Silver
# MAGIC
# MAGIC **Description:**  
# MAGIC Clean and transform Data from bronze to silver
# MAGIC
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {pipeline_write_env}_silver.commercial_and_program_demand_management.airsupply_order_history
# MAGIC - {pipeline_write_env}_silver.commercial_and_program_demand_management.airsupply_order_latest
# MAGIC
# MAGIC **Intput :**  
# MAGIC - {pipeline_read_env}_bronze.commercial_and_program_demand_management.airsupply_edi_orders_history
# MAGIC
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC - airsupply_order_run

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Libraries

# COMMAND ----------

import logging

import pyspark.sql.functions as f
from pyspark.sql.utils import AnalysisException

from leap_utils.common.logger import get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils

LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets & Parameters

# COMMAND ----------

dbutils.widgets.text("pipeline_read_env", "dev")
pipeline_read_env = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
reference_read_env = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
pipeline_write_env = dbutils.widgets.get("pipeline_write_env")

dest_silver_table_latest = (
    f"{pipeline_write_env}_silver.commercial_and_program_demand_management.airsupply_order_latest"
)
dest_silver_table_history = (
    f"{pipeline_write_env}_silver.commercial_and_program_demand_management.airsupply_order_history"
)

df_orders_history_change_log = (
    f"{pipeline_read_env}_bronze.commercial_and_program_demand_management.airsupply_edi_orders_history_change_log"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Input Leap Tables

# COMMAND ----------

df_orders_history_cl = spark.read.table(df_orders_history_change_log)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Possible mapping if new schema
# MAGIC
# MAGIC If new schema or modification
# MAGIC Exemple renaming columns: 
# MAGIC
# MAGIC
# MAGIC ```
# MAGIC mapping_new_schema = {
# MAGIC     "new_schema_CustomerPlantCode":CUSTOMERPLANTCODE,
# MAGIC     "new_schema_CustomerGroupName": CUSTOMERGROUPNAME,
# MAGIC     ...
# MAGIC }
# MAGIC ```

# COMMAND ----------

mapping_new_schema = {}
if mapping_new_schema:
    df_orders_history_cl = df_orders_history_cl.withColumnsRenamed(mapping_new_schema)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Date formatting and renaming

# COMMAND ----------

date_columns = [
    ("PO_PoPubDate", "PO_PoPubDate_DateFormat"),
    ("PO_LastMod", "PO_LastMod_DateFormat"),
    ("PO_CollabReqDate", "PO_CollabReqDate_DateFormat"),
    ("PO_CollabPromDate", "PO_CollabPromDate_DateFormat"),
]

for original_col, new_col in date_columns:
    df_orders_history_cl = df_orders_history_cl.withColumn(
        new_col, f.try_to_date(f.substring(f.col(original_col), 1, 8), "yyyyMMdd")
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creation of MSN & Program parameters:
# MAGIC 1. **Program**: Name (if provided)of the customer program taken from ProgramMSN column
# MAGIC 2. **MSN_Int**: Integer value of MSN provided in ProgramMSN column (no program designation)
# MAGIC 3. **MSN_Cleaned**: 6 digit always string of MSN_int (padded with zeros to left)
# MAGIC 4. **MSN_Long**: 10 digit always string of MSN_int (padded with zeros to left) -> just in case someone "fills to the left" of the 6 on MSN_Cleaned
# MAGIC 5. **Material_Number**: Quasi-Master Material number: we take the value of SupplierMaterialNumber if is not null else we take the value of CustomerMaterialNumber
# MAGIC 6. **Material_MSN**: concat MaterialNumber with MSN_Long.
# MAGIC 7. **Week Number**: Add standard SAP week number

# COMMAND ----------

# Extract Program and MSN_Int from PO_MSN
df_orders_enriched = (
    df_orders_history_cl.withColumn("_prog_msn_arr", f.split(f.col("PO_MSN"), "/"))
    .withColumn(
        "Program",
        f.when(f.size("_prog_msn_arr") >= 1, f.col("_prog_msn_arr").getItem(0)),
    )
    .withColumn(
        "MSN_Int",
        f.when(
            f.size("_prog_msn_arr") >= 2,
            f.col("_prog_msn_arr").getItem(1).try_cast("int"),
        ),
    )
    .drop("_prog_msn_arr")
)

# Generate MSN_Cleaned and MSN_Long
df_orders_enriched = df_orders_enriched.withColumn(
    "MSN_Cleaned", f.lpad(f.col("MSN_Int").try_cast("string"), 6, "0")
)
df_orders_enriched = df_orders_enriched.withColumn(
    "MSN_Long", f.lpad(f.col("MSN_Cleaned"), 10, "0")
)

# Combine MaterialNumber with MSN_Long
df_orders_enriched = df_orders_enriched.withColumn(
    "MaterialNumber",
    f.coalesce(f.col("MATERIAL_SUPPLIER_NUMBER"), f.col("MATERIAL_CUSTOMER_NUMBER")),
)
df_orders_enriched = df_orders_enriched.withColumn(
    "Material_MSN", f.concat_ws("_", f.col("MaterialNumber"), f.col("MSN_Long"))
)
df_orders_enriched = table_utils.add_week_number(
    df=df_orders_enriched, date_col="PO_CollabReqDate_DateFormat"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Leap Table -- Orders History

# COMMAND ----------

try:
    table_utils.save_table(
        dest_table=dest_silver_table_history,
        df=df_orders_enriched,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {df_orders_enriched} has not been created, an error occured during creation."
        f"\n Error is : \n {e}"
    )
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ## Leap Tables --  Orders Latest

# COMMAND ----------

df_orders_enriched_latest = df_orders_enriched.filter(f.col("_meta_is_latest"))
try:
    table_utils.save_table(
        dest_table=dest_silver_table_latest,
        df=df_orders_enriched_latest,
        mode="overwrite",
    )
except AnalysisException as e:
    log.error(
        f"Table {dest_silver_table_latest} has not been created, an error occured during creation."
        f"\n Error is : \n {e}"
    )
    raise e
