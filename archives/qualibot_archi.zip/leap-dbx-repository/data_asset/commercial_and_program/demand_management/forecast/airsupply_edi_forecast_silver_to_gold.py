# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Airsupply EDI forecast Silver to Gold
# MAGIC
# MAGIC **Description:**  
# MAGIC Clean and transform Data from slvr to gold, to correct the abnormal quantities and the duplicate rows.
# MAGIC
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {pipeline_write_env}_gold.commercial_and_program_demand_management.airsupply_forecast_latest
# MAGIC - {PIPELINE_WRITE_ENV}_gold.commercial_and_program_demand_management.airsupply_forecast_history
# MAGIC   
# MAGIC **Intput :**  
# MAGIC - {pipeline_read_env}_silver.commercial_and_program_demand_management.airsupply_forecast_latest
# MAGIC - {PIPELINE_READ_ENV}_gold.commercial_and_program_demand_management.airsupply_forecast_history
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC TODO: ADD job
# MAGIC
# MAGIC
# MAGIC **Things to do:** 

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config Imports

# COMMAND ----------

import logging
import time
import datetime
from typing import Tuple

from pyspark.sql import functions as f
from pyspark.sql.window import Window
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as DataFrame

from leap_utils.common.logger import get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils, history_changelog
from ingestion.airsupply import airsupply_ingestion_utils

LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widget

# COMMAND ----------

dbutils.widgets.text("pipeline_read_env", "uat")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "uat")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("multiple_EDI", "False")
MULTIPLE_EDI = dbutils.widgets.get("multiple_EDI").lower() == "true"

dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = dbutils.widgets.get("force_reinitialization").lower() == "true"

dbutils.widgets.text("initialisation_date", "")
INIT_DATE = dbutils.widgets.get("initialisation_date")

dbutils.widgets.text("new_schema", "False")
NEW_SCHEMA = dbutils.widgets.get("new_schema").lower() == "true"

dbutils.widgets.text("skip_task", "False")
SKIP_TASK = dbutils.widgets.get("skip_task").lower() == "true"

if not FORCE_REINITIALIZATION and INIT_DATE:
    dbutils.notebook.exit("Initialisation date is not empty")
if INIT_DATE:
    try:
        datetime.datetime.strptime(INIT_DATE, "%Y-%m-%d")
    except ValueError:
        dbutils.notebook.exit("init_date not in format: yyyy-MM-dd")

# COMMAND ----------

if SKIP_TASK:
    dbutils.notebook.exit("Skip Task")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

LATEST_EDI_TABLE_GOLD = f"{PIPELINE_READ_ENV}_gold.commercial_and_program_demand_management.airsupply_forecast_latest"
HISTORY_EDI_TABLE = f"{PIPELINE_READ_ENV}_gold.commercial_and_program_demand_management.airsupply_forecast_history"
HISTORY_EDI_TABLE_SILVER = f"{PIPELINE_READ_ENV}_silver.commercial_and_program_demand_management.airsupply_forecast_history"

SELECTED_PROGRAM = ["SA", "XWB"]

window_partion_by_part_msn = Window.partitionBy("CustomerMaterialNumber", "MSN_Cleaned")
window_order_by_date = window_partion_by_part_msn.orderBy(
    "OriginalCustomerForecastDemandDate_DateFormat"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Input Function

# COMMAND ----------

def process_duplicate_data(
    df: DataFrame, suffix: str = "", select: bool = False
) -> Tuple[DataFrame, DataFrame]:
    """
    Process the duplicate data in a DataFrame.
    """

    df_with_duplicate_line = df.withColumn(
        "Duplicate_line", f.count("MSN_Cleaned").over(window_partion_by_part_msn)
    )
    df_noduplicate = df_with_duplicate_line.filter(f.col("Duplicate_line") == 1)
    df_duplicate = df_with_duplicate_line.filter(f.col("Duplicate_line") > 1)
    if select:
        df_duplicate = df_duplicate.select(
            "MSN_Cleaned",
            "CustomerMaterialNumber",
            f.col("Duplicate_line").alias(f"Duplicate_line{suffix}"),
        )
    return df_noduplicate, df_duplicate


def get_nth_latest_edi_date(df_edi_history: DataFrame, n: int) -> str:
    """
    Get the nth latest EDI snapshot date from the DataFrame.
    """
    edi_dates = (
        df_edi_history.select("EDISnapshotDate")
        .dropDuplicates()
        .orderBy("EDISnapshotDate", ascending=False)
        .collect()
    )
    return edi_dates[n]["EDISnapshotDate"]

# COMMAND ----------

def process_case_1(
    df_case_1: DataFrame,
    df_noduplicate_t_1: DataFrame,
    window_partition_by_part_msn: Window,
    window_order_by_date: Window,
):
    """
    Processes case 1: Duplicated in the latest EDI but not in the previous one.

    :param df_case_1: Latest EDI DataFrame
    :type df_case_1: DataFrame
    :param df_noduplicate_t_1: Previous EDI DataFrame without duplicates
    :type df_noduplicate_t_1: DataFrame
    :param window_partition_by_part_msn: Window specification to partition by part MSN
    :type window_partition_by_part_msn: Window
    :param window_order_by_date: Window specification to order by date
    :type window_order_by_date: Window
    :return: Processed DataFrame with selected rows marked
    :rtype: DataFrame
    """
    df_noduplicate_t_1_prep = df_noduplicate_t_1.select(
        "CustomerMaterialNumber",
        "OriginalCustomerForecastDemandDate_DateFormat",
        "MSN_Cleaned",
        f.col("OriginalCustomerForecastDemandQuantity").alias(
            "OriginalCustomerForecastDemandQuantity_previous"
        ),
    )

    df_case_1_prep = df_case_1.join(
        df_noduplicate_t_1_prep,
        on=[
            "CustomerMaterialNumber",
            "OriginalCustomerForecastDemandDate_DateFormat",
            "MSN_Cleaned",
        ],
        how="left",
    )

    df_case_1_prep = df_case_1_prep.withColumn(
        "PreviousSameDate",
        f.when(
            f.col("OriginalCustomerForecastDemandQuantity_previous").isNull(), 0
        ).otherwise(1),
    )

    df_case_1_prep = df_case_1_prep.withColumn(
        "SumPreviousSameDate",
        f.sum("PreviousSameDate").over(window_partition_by_part_msn),
    )

    df_w_prevdate, df_no_prevdate = df_case_1_prep.filter(
        f.col("SumPreviousSameDate") > 0
    ), df_case_1_prep.filter(f.col("SumPreviousSameDate") == 0)

    df_w_prevdate_prep = df_w_prevdate.withColumn(
        "SelectedRows", f.when(f.col("PreviousSameDate") == 0, "Yes").otherwise("No")
    ).drop("SumPreviousSameDate")

    df_no_prevdate_prep = df_no_prevdate.withColumn(
        "SelectedRows", f.row_number().over(window_order_by_date)
    ).withColumn(
        "SelectedRows", f.when(f.col("SelectedRows") == 1, "Yes").otherwise("No")
    )

    return (
        df_no_prevdate_prep.drop("SumPreviousSameDate")
        .unionByName(df_w_prevdate_prep)
        .drop("OriginalCustomerForecastDemandQuantity_previous", "PreviousSameDate")
    )


def process_case_2(
    df_case_2: DataFrame,
    df_t_1_corrected: DataFrame,
    window_partition_by_part_msn: Window,
    window_order_by_date: Window,
):
    """
    Processes case 2: Duplicated in the latest EDI and was already duplicated in the previous one.

    :param df_case_2: Latest EDI DataFrame
    :type df_case_2: DataFrame
    :param df_t_1_corrected: Previous EDI DataFrame with corrections
    :type df_t_1_corrected: DataFrame
    :param window_partition_by_part_msn: Window specification to partition by part MSN
    :type window_partition_by_part_msn: Window
    :param window_order_by_date: Window specification to order by date
    :type window_order_by_date: Window
    :return: Processed DataFrame with selected rows marked
    :rtype: DataFrame
    """
    df_case_2_prep = df_case_2.join(
        df_t_1_corrected,
        on=[
            "CustomerMaterialNumber",
            "MSN_Cleaned",
            "OriginalCustomerForecastDemandDate_DateFormat",
        ],
        how="left",
    ).withColumn(
        "MSN_not_in_corrected_t_1",
        f.when(f.col("SelectedRows").isNull() == True, 0).otherwise(1),
    )

    df_case_2_prep = df_case_2_prep.withColumn(
        "temp_col", f.sum("MSN_not_in_corrected_t_1").over(window_partition_by_part_msn)
    )

    df_case_2_samedate, df_case_2_diffdate = df_case_2_prep.filter(
        f.col("temp_col") == 2
    ), df_case_2_prep.filter(f.col("temp_col") < 2)

    df_case_2_diffdate = df_case_2_diffdate.withColumn(
        "SelectedRows",
        f.when(f.row_number().over(window_order_by_date) == 1, "Yes").otherwise("No"),
    )

    return df_case_2_diffdate.unionByName(df_case_2_samedate).drop(
        "temp_col", "MSN_not_in_corrected_t_1"
    )


def quality_check(df_edi_t: DataFrame, df_final_sa: DataFrame):
    """
    Performs quality checks after handling duplicate rows.

    :param df_edi_t: Latest EDI DataFrame
    :type df_edi_t: DataFrame
    :param df_final_sa: Final processed DataFrame
    :type df_final_sa: DataFrame
    :raises Exception: If there are duplicates or invalid quantities
    """
    a = (
        df_edi_t.select("MSN_Cleaned", "CustomerMaterialNumber")
        .dropDuplicates()
        .count()
    )
    b = df_final_sa.filter(f.col("SelectedRows") == "Yes").count()

    if a != b:
        raise Exception("Duplicates")

    max_qty = (
        df_final_sa.withColumn(
            "OriginalCustomerForecastDemandQuantity",
            df_final_sa["OriginalCustomerForecastDemandQuantity"].cast("int"),
        )
        .select("OriginalCustomerForecastDemandQuantity")
        .dropDuplicates()
        .orderBy("OriginalCustomerForecastDemandQuantity", ascending=False)
        .collect()[0]["OriginalCustomerForecastDemandQuantity"]
    )

    if max_qty >= 3:
        raise Exception("Invalid quantities")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - get latest incoming data

# COMMAND ----------

if (
    table_utils.UnityCatalogCheckTableExists(HISTORY_EDI_TABLE)
    and not FORCE_REINITIALIZATION
):
    last_edi_date = airsupply_ingestion_utils.get_last_date(
        df=spark.read.table(HISTORY_EDI_TABLE), column="EDISnapshotDate"
    )
    df_forecast_silver_latest = spark.read.table(HISTORY_EDI_TABLE_SILVER).filter(
        f.col("EDISnapshotDate") > last_edi_date
    )
else:
    df_forecast_silver_latest = spark.read.table(HISTORY_EDI_TABLE_SILVER)
    if INIT_DATE:
        df_forecast_silver_latest = df_forecast_silver_latest.filter(f.col("EDISnapshotDate") >= INIT_DATE)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Filter Data

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 2.1: Remove deleted rows in Airsupply

# COMMAND ----------

df_forecast_silver_latest = df_forecast_silver_latest.filter(
    f.col("DeleteFlag") == "false"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 2.2: Filter the latest forecats on the chosen program SA (A320) and XWB (A350) and Select used columns

# COMMAND ----------

df_edi_latest_added_columns_qty = df_forecast_silver_latest.withColumn(
    "OriginalCustomerForecastDemandQuantity_initial",
    f.col("OriginalCustomerForecastDemandQuantity"),
)
df_edi_latest_filtered = df_edi_latest_added_columns_qty.filter(
    (f.col("Program")== "SA") | ((f.col("Program") == "XWB") & (~f.col("MSN_Cleaned").startswith("009")))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 2.3: Remove Zero Quantities
# MAGIC It has happened that Airbus sent forecasts with 0 quantities by MSN/Material which is not resperesentive of any actual forecasts, Hence we remove them from the get-go

# COMMAND ----------

df_edi_latest_filtered_without_zero_qty = df_edi_latest_filtered.filter(
    f.col("OriginalCustomerForecastDemandQuantity") > 0
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC #### Transformation 1: Handle Abnormal quantities
# MAGIC It's unnecessary to order more than one quantity.Any quantity over one is considered **abnormal** for all materials, except **DB654**. 
# MAGIC
# MAGIC **PS:** Quantities are also adjusted for unsmoothed data (SA only), such as DB159 or dates before the smoothing start date.
# MAGIC
# MAGIC - if quantity>2 and material = DB654 ===> quantity =2
# MAGIC - if quantity>1 and material!=DB654 ===> quantity =1
# MAGIC - otherwise quantity

# COMMAND ----------

# Handle special case of customer material DB654 (quantity allowed=2)
df_edi_latest_corrected = df_edi_latest_filtered_without_zero_qty.filter(
    f.col("Program") == "SA"
).withColumn(
    "OriginalCustomerForecastDemandQuantity",
    f.when(
        (f.col("CustomerMaterialNumber") == "DB654")
        & (f.col("OriginalCustomerForecastDemandQuantity") > 2),
        f.lit(2),
    ).otherwise(
        f.when(
            (f.col("CustomerMaterialNumber") != "DB654")
            & (f.col("OriginalCustomerForecastDemandQuantity") > 1),
            f.lit(1),
        ).otherwise(f.col("OriginalCustomerForecastDemandQuantity"))
    ),
)

df_edi_latest_corrected = df_edi_latest_corrected.unionByName(
    df_edi_latest_filtered_without_zero_qty.filter(
        f.col("Program") == "XWB"
    ).withColumn(
        "OriginalCustomerForecastDemandQuantity",
        f.when(
            f.col("OriginalCustomerForecastDemandQuantity") > 1,
        f.lit(1)
        ).otherwise(f.col("OriginalCustomerForecastDemandQuantity"))
    ) 
)

# Compare the old initial quantity with the corrected -> Flag
df_edi_latest_corrected = df_edi_latest_corrected.withColumn(
    "Qty_correctedYN",
    f.when(
        f.col("OriginalCustomerForecastDemandQuantity")
        != f.col("OriginalCustomerForecastDemandQuantity_initial"),
        f.lit("Yes"),
    ).otherwise(f.lit("No")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Initialization

# COMMAND ----------

# MAGIC %md
# MAGIC Code needs to handle different use case:
# MAGIC - First run: No forecast history table exist
# MAGIC   - if new data incoming contains only one EDI -> save data as latest and history
# MAGIC   - else: Handle duplicate rows on first EDI incoming and join it to all EDI
# MAGIC - History table exist:
# MAGIC   - add latest forecast table to all incoming EDI 

# COMMAND ----------

if (
    not table_utils.UnityCatalogCheckTableExists(HISTORY_EDI_TABLE)
    or FORCE_REINITIALIZATION
):
    if FORCE_REINITIALIZATION:
        log.info(f"FORCE REINITIALIZATION")
    else:
        log.info("Landing Zone table doesn't exist")
    unique_dates = (
        df_edi_latest_corrected.select("EDISnapshotDate")
        .distinct()
        .orderBy("EDISnapshotDate")
        .collect()
    )
    unique_dates_strings = [
        row["EDISnapshotDate"].strftime("%Y-%m-%d") for row in unique_dates
    ]
    if len(unique_dates_strings) == 1:
        log.info("Unique EDI in forecast")
        df_with_duplicate_line = df_edi_latest_corrected.withColumn(
            "Duplicate_line", f.count("MSN_Cleaned").over(window_partion_by_part_msn)
        )
        df_no_prevdate_prep = df_with_duplicate_line.withColumn(
            "SelectedRows", f.row_number().over(window_order_by_date)
        ).withColumn(
            "SelectedRows",
            f.when(f.col("SelectedRows") == 1, f.lit("Yes")).otherwise(f.lit("No")),
        )
        try:
            table_utils.save_table(
                dest_table=LATEST_EDI_TABLE_GOLD,
                df=df_no_prevdate_prep,
                mode="overwrite",
            )
        except AnalysisException as e:
            log.error(
                f"Table {LATEST_EDI_TABLE_GOLD} has not been created, an error occured during creation."
                f"\n Error is : \n {e}"
            )
            raise e
        try:
            table_utils.save_table(
                dest_table=HISTORY_EDI_TABLE, df=df_no_prevdate_prep, mode="overwrite"
            )
        except AnalysisException as e:
            log.error(
                f"Table {HISTORY_EDI_TABLE} has not been created, an error occured during creation."
                f"\n Error is : \n {e}"
            )
            raise e
        dbutils.notebook.exit("Initialization done")
    else:
        df_edi_latest_corrected_filtered = df_edi_latest_corrected.filter(
            f.col("EDISnapshotDate") == unique_dates_strings[0]
        )
        df_with_duplicate_line = df_edi_latest_corrected_filtered.withColumn(
            "Duplicate_line", f.count("MSN_Cleaned").over(window_partion_by_part_msn)
        )
        df_no_prevdate_prep = (
            df_with_duplicate_line.withColumn(
                "SelectedRows", f.row_number().over(window_order_by_date)
            ).withColumn(
                "SelectedRows",
                f.when(f.col("SelectedRows") == 1, f.lit("Yes")).otherwise(f.lit("No")),
            )
        ).select(
            "CustomerMaterialNumber",
            "MSN_Cleaned",
            "EDISnapshotDate",
            "SelectedRows",
            "OriginalCustomerForecastDemandDate_DateFormat",
        )
        df_edi_all = df_edi_latest_corrected.join(
            df_no_prevdate_prep,
            [
                "CustomerMaterialNumber",
                "MSN_Cleaned",
                "EDISnapshotDate",
                "OriginalCustomerForecastDemandDate_DateFormat",
            ],
            "left",
        )
else:
    log.info("Landing zone table already exist")
    df_edi_t = df_edi_latest_corrected
    df_edi_t_1 = spark.read.table(LATEST_EDI_TABLE_GOLD).filter(
        f.col("OriginalCustomerForecastDemandQuantity") > 0
    )

    df_edi_all = df_edi_t.unionByName(df_edi_t_1, allowMissingColumns=True)
    unique_dates = (
        df_edi_all.select("EDISnapshotDate")
        .distinct()
        .orderBy("EDISnapshotDate")
        .collect()
    )
    unique_dates_strings = [
        row["EDISnapshotDate"].strftime("%Y-%m-%d") for row in unique_dates
    ]
    if len(unique_dates_strings) == 1:
        raise Exception("New EDI same date as old")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2: Handle Duplicated rows
# MAGIC Airbus sometimes sends two rows with the same MSN and material, with non-zero quantities and different demand dates. This is usually caused by a change in demand date, where a new row is created with the updated date, but the previous row's quantity is not set to zero.
# MAGIC
# MAGIC **Vocabulary**: 
# MAGIC - edi_t: latest  (t) 
# MAGIC - edi_t_1: previous EDI (t-1) [Refrence without duplicates]
# MAGIC
# MAGIC Possibles Cases to handle:
# MAGIC
# MAGIC - **Case 1:**  duplicated in the latest EDI but not in the previous one.
# MAGIC
# MAGIC - **Case 2:**  duplicated in the latest EDI and was already duplicated in the previous one

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC The first case is when a (Material; MSN) is **duplicated in the latest EDI but not in the previous one**.
# MAGIC
# MAGIC Inside the case 1, there are two possibilities for duplicate (MSN; Material): 
# MAGIC - One row with the same date than the previous EDI -->  in this case, we keep the other date 
# MAGIC - No row with the same date as the previous EDI -->  in this case, we keep the earliest date 
# MAGIC
# MAGIC **PS**: No real action of removing is taken we define a new column SelectedRows that allow us to filter

# COMMAND ----------

# MAGIC %md
# MAGIC The second case is when a (Material; MSN) is **duplicated in the latest EDI and was already duplicated in the previous one.**
# MAGIC
# MAGIC Inside case 2, there are two possibilities for a duplicate (MSN; Material): 
# MAGIC - the two rows are exactly identical (same demand dates) in the latest and previous EDI  -->  in this case, we keep the same selection than the previous EDI
# MAGIC - the two rows are different between the latest and previous EDI  -->  in this case, we keep the earliest date

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import Window

# Initialize final df to append DataFrame
if (
    not table_utils.UnityCatalogCheckTableExists(HISTORY_EDI_TABLE)
    or FORCE_REINITIALIZATION
):
    df_final_corrected = df_edi_all.filter(
        f.col("EDISnapshotDate") == unique_dates_strings[0]
    )
else:
    df_final_corrected = spark.createDataFrame([], df_edi_all.schema)

# Define window specifications
window_partition_by_part_msn = Window.partitionBy(
    "CustomerMaterialNumber", "MSN_Cleaned"
)
window_order_by_date = window_partition_by_part_msn.orderBy(
    "OriginalCustomerForecastDemandDate_DateFormat"
)

df_edi_t_1 = df_edi_all.filter(f.col("EDISnapshotDate") == unique_dates_strings[0])

# Iterate over unique dates
for i in range(1, len(unique_dates_strings)):
    t = unique_dates_strings[i]
    t_minus_1 = unique_dates_strings[i - 1]
    date1 = datetime.datetime.strptime(t, "%Y-%m-%d")
    date2 = datetime.datetime.strptime(t_minus_1, "%Y-%m-%d")

    # Calculate the difference in days
    day_difference = (date1 - date2).days
    log.info(f"t :{t}, t-1 :{t_minus_1}")

    # Filter DataFrame for current and previous dates
    df_edi_t = df_edi_all.filter(f.col("EDISnapshotDate") == t).drop("SelectedRows")
    df_edi_t_1 = df_edi_all.filter(f.col("EDISnapshotDate") == t_minus_1)

    if (i == 1) or (day_difference > 8):
        df_t_1_corrected = df_edi_t_1.select(
            "CustomerMaterialNumber",
            "MSN_Cleaned",
            "OriginalCustomerForecastDemandDate_DateFormat",
            "SelectedRows",
        )
    else:
        df_t_1_corrected = spark.createDataFrame(data_dict)

    # Process duplicate data
    df_noduplicate_t, df_duplicate_t = process_duplicate_data(df=df_edi_t)
    df_noduplicate_t_1, df_duplicate_t_1 = process_duplicate_data(
        df=df_edi_t_1, suffix="_previous", select=True
    )

    # Join duplicated data from current and previous dates
    df_duplicates_t_and_t_1 = df_duplicate_t.join(
        df_duplicate_t_1.dropDuplicates(),
        on=["MSN_Cleaned", "CustomerMaterialNumber"],
        how="left",
    )

    # Define new column to distinguish cases
    df_cases = df_duplicates_t_and_t_1.withColumn(
        "PreviousDuplicateYN",
        f.when(f.col("Duplicate_line_previous").isNull(), "No").otherwise("Yes"),
    ).drop("Duplicate_line_previous")

    # Split cases into two groups
    df_case_1 = df_cases.filter(f.col("PreviousDuplicateYN") == "No")
    df_case_2 = df_cases.filter(f.col("PreviousDuplicateYN") == "Yes")

    # Apply transformations to Case 1
    df_case_1_final = process_case_1(
        df_case_1,
        df_noduplicate_t_1,
        window_partition_by_part_msn,
        window_order_by_date,
    )

    # Apply transformations to Case 2
    df_case_2_final = process_case_2(
        df_case_2, df_t_1_corrected, window_partition_by_part_msn, window_order_by_date
    )

    # Union of Case 1 and Case 2
    df_duplicate_final = df_case_2_final.unionByName(df_case_1_final)
    df_duplicate_final = df_duplicate_final.drop("PreviousDuplicateYN")
    df_noduplicate_final = df_noduplicate_t.withColumn("SelectedRows", f.lit("Yes"))
    df_final_sa = df_noduplicate_final.unionByName(df_duplicate_final)
    df_final_corrected = df_final_sa.unionByName(
        df_final_corrected, allowMissingColumns=True
    )

    # Quality Check
    quality_check(df_edi_t, df_final_sa)

    # Update df_edi_t_1 for the next iteration
    # df_edi_t_1 = df_final_sa
    data_dict = df_final_sa.select(
        "CustomerMaterialNumber",
        "MSN_Cleaned",
        "OriginalCustomerForecastDemandDate_DateFormat",
        "SelectedRows"
    ).collect()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2.4: Union Duplicates, no dupliactes and none Airbus data in the latest EDI

# COMMAND ----------

df_final_zero_quantity = (
    df_edi_latest_filtered.filter(f.col("OriginalCustomerForecastDemandQuantity") == 0)
    .withColumn("SelectedRows", f.lit("No"))
    .withColumn("Duplicate_line", f.lit(1))
    .withColumn(
        "Qty_correctedYN",
        f.lit("No"),
    )
)

df_final_no_sa = (
    df_forecast_silver_latest.filter(
        (f.col("Program").isNull())
        | ((f.col("Program") != "SA") & (f.col("Program") != "XWB"))
        | ((f.col("Program") == "XWB") & f.col("MSN_Cleaned").startswith("009"))
    )
    .withColumn(
        "OriginalCustomerForecastDemandQuantity_initial",
        f.col("OriginalCustomerForecastDemandQuantity"),
    )
    .withColumn("SelectedRows", f.lit("Yes"))
    .withColumn("Duplicate_line", f.lit(1))
    .withColumn(
        "Qty_correctedYN",
        f.lit("No"),
    )
)
df_final_sa_w_zero_quantity = df_final_corrected.unionByName(df_final_zero_quantity)
df_final = df_final_sa_w_zero_quantity.unionByName(df_final_no_sa)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality checks

# COMMAND ----------

# MAGIC %md
# MAGIC Checks if any Data has been lost 

# COMMAND ----------

init_count = df_forecast_silver_latest.count()
final_count = df_final.count()

if init_count != final_count:
    raise Exception(f"Lost data. Init count: {init_count} | final count: {final_count}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Outputs - Leap Tables - forecast history

# COMMAND ----------

if (
    table_utils.UnityCatalogCheckTableExists(DbxTablePath=HISTORY_EDI_TABLE)
    and not FORCE_REINITIALIZATION 
):
    mode = "append"
else:
    mode = "overwrite"
if INIT_DATE:
    if table_utils.UnityCatalogCheckTableExists(HISTORY_EDI_TABLE):
        df_final = df_final.unionByName(
            spark.read.table(HISTORY_EDI_TABLE).filter(f.col("EDISnapshotDate") < INIT_DATE)
        )
    else:
        df_forecast_silver_latest.filter(
            f.col("EDISnapshotDate") < INIT_DATE
        ).withColumn(
            "OriginalCustomerForecastDemandQuantity_initial",
            f.col("OriginalCustomerForecastDemandQuantity"),
        ).withColumn(
            "SelectedRows", f.lit("Yes")
        ).withColumn(
            "Duplicate_line", f.lit(1)
        ).withColumn(
            "Qty_correctedYN",
            f.lit("No"),
        )
        df_final = df_final.unionByName(df_forecast_silver_latest)    
try:
    table_utils.save_table(
        dest_table=HISTORY_EDI_TABLE, df=df_final, mode=mode, merge_schema=True
    )
except AnalysisException as e:
    log.error(
        f"Table {HISTORY_EDI_TABLE} has not been created, an error occured during creation."
        f"\n Error is : \n {e}"
    )
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ## Outputs - Leap Tables - Forecast Latest

# COMMAND ----------

df_latest_gold = airsupply_ingestion_utils.get_last_forecast_edi(df=df_final)

try:
    table_utils.save_table(
        dest_table=LATEST_EDI_TABLE_GOLD, df=df_latest_gold, mode="overwrite"
    )
except AnalysisException as e:
    log.error(
        f"Table {LATEST_EDI_TABLE_GOLD} has not been created, an error occured during creation."
        f"\n Error is : \n {e}"
    )
    raise e
