# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Airuspply EDI forecast bronze to silver
# MAGIC
# MAGIC **Description:**
# MAGIC Clean and transform Data from brnz to silver
# MAGIC
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.airsupply_forecast_latest
# MAGIC - {PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.airsupply_forecast_latest_with_ddms
# MAGIC
# MAGIC **Intput :**
# MAGIC - {PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.airsupply_edi_forecast_latest
# MAGIC
# MAGIC
# MAGIC **Triggered by:**
# MAGIC TODO: Add job
# MAGIC
# MAGIC
# MAGIC **Things to do:**

# COMMAND ----------

# MAGIC %md
# MAGIC # Config

# COMMAND ----------

# MAGIC %md
# MAGIC ## Libraries

# COMMAND ----------

import logging

from pyspark.sql import functions as f
from pyspark.sql.utils import AnalysisException
import great_expectations as gx

from leap_utils.common.logger import get_logger, setup_applevel_logger
from leap_utils.data_asset import table_utils
from leap_utils.common.validation import gx_validation
from ingestion.airsupply import airsupply_ingestion_utils


LOG_LEVEL = "DEBUG"
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("skip_task", "False")
SKIP_TASK = dbutils.widgets.get("skip_task").lower() == "true"

dbutils.widgets.text("force_reinitialization", "False")
FORCE_REINITIALIZATION = dbutils.widgets.get("force_reinitialization").lower() == "true"

# COMMAND ----------

if SKIP_TASK:
    dbutils.notebook.exit("skip task")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Leap Table

# COMMAND ----------

df_forecast_history = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.edi_airsupply_forecast_history_view"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - hard coded variable

# COMMAND ----------

dest_silver_table = f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.airsupply_forecast_latest"
dest_silver_history_table = f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.airsupply_forecast_history"
dest_silver_with_ddms_table = f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program_demand_management.airsupply_forecast_latest_with_ddms"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Parameters

# COMMAND ----------

# Bronze Column Name
ORIGINALFILEPATH = "OriginalFilePath"
INGESTION_TIMESTAMP = "ingestion_timestamp"
ORIGINALFILESOURCE = "OriginalFileSource"
EDISNAPSHOTRAW = "EDISnapshotRaw"
EDISNAPSHOTDATE = "EDISnapshotDate"
BRONZEUID = "BronzeUID"
COLLABSETKEY = "CollabSetKey"
PUBLISHINGDATE = "PublishingDate"
FCHEADERLASTMODIFICATIONDATE = "FCHeaderLastModificationDate"
FCHEADERCREATIONDATE = "FCHeaderCreationDate"
CUSTOMERGROUPCODE = "CustomerGroupCode"
CUSTOMERGROUPNAME = "CustomerGroupName"
CUSTOMERORGCODE = "CustomerOrgCode"
SUPPLIERNUMBER = "SupplierNumber"
CUSTOMERMATERIALNUMBER = "CustomerMaterialNumber"
CUSTOMERMATERIALDESCRIPTION = "CustomerMaterialDescription"
SUPPLIERMATERIALNUMBER = "SupplierMaterialNumber"
SUPPLIERMATERIALDESCRIPTION = "SupplierMaterialDescription"
HORIZONTYPE = "HorizonType"
DELIVERYDATEDEMANDDATE = "DeliveryDateDemandDate"
DEMANDQUANTITY = "DemandQuantity"
PROGRAMMSN = "ProgramMSN"
EXTRACTEDTIMESTAMP = "ExtractedTimestamp"

# ADD Silver column name
PUBLISHINGDATE_DATEFORMAT = "PublishingDate_DateFormat"
DELIVERYDATEDEMAND_DATEFORMAT = "DeliveryDateDemand_DateFormat"
ORIGINALCUSTOMERFORECASTDEMANDYEARMONTH_DATEFORMAT = (
    "OriginalCustomerForecastDemandYearMonth_DateFormat"
)
ORIGINALCUSTOMERFORECASTDEMANDDATE = "OriginalCustomerForecastDemandDate"
ORIGINALCUSTOMERFORECASTDEMANDQUANTITY = "OriginalCustomerForecastDemandQuantity"
ORIGINALCUSTOMERFORECASTDEMANDDATE_DATEFORMAT = (
    "OriginalCustomerForecastDemandDate_DateFormat"
)
PROGRAM = "Program"
MSN_INT = "MSN_Int"
MSN_CLEANED = "MSN_Cleaned"
MSN_LONG = "MSN_Long"
MATERIALNUMBER = "MaterialNumber"
MATERIAL_MSN = "Material_MSN"

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC # Data Preparation - Clean and Format data

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get the last EDI forecast not processed

# COMMAND ----------

if (
    table_utils.UnityCatalogCheckTableExists(dest_silver_table)
    and not FORCE_REINITIALIZATION
):
    last_edi_date = airsupply_ingestion_utils.get_last_date(
        df=spark.read.table(dest_silver_table), column="EDISnapshotDate"
    )
    df_forecast_latest = df_forecast_history.filter(
        f.col("EDISnapshotDate") > last_edi_date
    )
else:
    df_forecast_latest = df_forecast_history

# COMMAND ----------

if df_forecast_latest.count() == 0:
    dbutils.notebook.exit("No new data - skip compute")

# COMMAND ----------

# MAGIC %md
# MAGIC ## [Optionnal] Mapping

# COMMAND ----------

"""
If new schema or modification
Exemple renaming columns: 

mapping_new_schema = {
    "new_schema_CustomerPlantCode":CUSTOMERPLANTCODE,
    "new_schema_CustomerGroupName": CUSTOMERGROUPNAME,
    ...
}
"""
mapping_new_schema = {}
if mapping_new_schema:
    df_forecast_latest = df_forecast_latest.withColumnsRenamed(mapping_new_schema)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Date formatting and renaming

# COMMAND ----------

column_renamed = {
    DELIVERYDATEDEMANDDATE: ORIGINALCUSTOMERFORECASTDEMANDDATE,
    DEMANDQUANTITY: ORIGINALCUSTOMERFORECASTDEMANDQUANTITY,
    DELIVERYDATEDEMAND_DATEFORMAT: ORIGINALCUSTOMERFORECASTDEMANDDATE_DATEFORMAT,
}
df_forecast_renamed = (
    df_forecast_latest.withColumn(
        PUBLISHINGDATE_DATEFORMAT,
        f.to_date(f.substring(f.col(PUBLISHINGDATE), 1, 8), "yyyyMMdd"),
    )
    .withColumn(
        DELIVERYDATEDEMAND_DATEFORMAT,
        f.to_date(f.substring(f.col(DELIVERYDATEDEMANDDATE), 1, 8), "yyyyMMdd"),
    )
    .withColumn(
        ORIGINALCUSTOMERFORECASTDEMANDYEARMONTH_DATEFORMAT,
        f.date_format(f.col(DELIVERYDATEDEMAND_DATEFORMAT), "yyyy-MM"),
    )
    .withColumnsRenamed(column_renamed)
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1: Creation of MSN & Program parameters:
# MAGIC
# MAGIC 1. **Program**: Name (if provided) of the customer program taken from the ProgramMSN column.
# MAGIC
# MAGIC 2. **MSN_Int**: Integer value of MSN provided in the ProgramMSN column (no program designation).
# MAGIC
# MAGIC 3. **MSN_Cleaned**: 6-digit always string of MSN_Int (padded with zeros to the left).
# MAGIC
# MAGIC 4. **MSN_Long**: 10-digit always string of MSN_Int (padded with zeros to the left) - just in case someone "fills to the left" of the 6 on MSN_Cleaned.
# MAGIC
# MAGIC 5. **MaterialNumber**:  Quasi-Master Material number: we take the value of SupplierMaterialNumber if is not null else we take the value of CustomerMaterialNumber
# MAGIC
# MAGIC 6. **Material_MSN**: concat MaterialNumber with MSN_Long
# MAGIC
# MAGIC 7. **week number:**: Add SAP standard week number for customer demand

# COMMAND ----------

split_col = f.split(f.col(PROGRAMMSN), "/")

df_forecast_enriched = (
    df_forecast_renamed
    .withColumn("_prog_msn_arr", split_col)
    .withColumn(
        PROGRAM,
        f.when(f.size("_prog_msn_arr") >= 1, f.col("_prog_msn_arr").getItem(0)),
    )
    .withColumn(
        MSN_INT,
        f.when(
            f.size("_prog_msn_arr") >= 2,
            f.col("_prog_msn_arr").getItem(1).cast("int"),
        ),
    )
    .drop("_prog_msn_arr")
)
df_forecast_enriched = df_forecast_enriched.withColumn(
    MSN_CLEANED, f.lpad(f.col(MSN_INT).cast("string"), 6, "0")
)
df_forecast_enriched = df_forecast_enriched.withColumn(
    MSN_LONG, f.lpad(f.col(MSN_CLEANED), 10, "0")
)
df_forecast_enriched = df_forecast_enriched.withColumn(
    MATERIALNUMBER,
    f.coalesce(f.col(SUPPLIERMATERIALNUMBER), f.col(CUSTOMERMATERIALNUMBER)),
)
df_forecast_enriched = df_forecast_enriched.withColumn(
    MATERIAL_MSN, f.concat_ws("_", f.col(MATERIALNUMBER), f.col(MSN_LONG))
)
df_forecast_enriched = table_utils.add_week_number(
    df=df_forecast_enriched, date_col=ORIGINALCUSTOMERFORECASTDEMANDDATE_DATEFORMAT
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2: Add DDMS info

# COMMAND ----------

# MAGIC %md
# MAGIC #### Transformation 2.1: Add a_c_tags column

# COMMAND ----------

# Read DDMS table
DDMS_TABLE = f"{PIPELINE_READ_ENV}_bronze.commercial_and_program_demand_management.nff_e2e_elec_planning"

df_ddms = (
    spark.read.table(DDMS_TABLE)
    .select(
        f.col("msn").alias("MSN_Int"), "a_c_tags", "year_week"
    )  # a_c_tags column contains the DDMS info
    .filter(f.col("MSN_Int").isNotNull())
    .dropDuplicates()
)

# Add week number of EDISnapshot to join
df_forecast_enriched_with_ddms = (
    table_utils.add_week_number(df=df_forecast_enriched, date_col="EDISnapshotDate")
    .withColumnRenamed("EDISnapshotDate_week_number", "year_week")
    .join(df_ddms, ["MSN_Int", "year_week"], "left")
)

# Get the latest update date of DDMS and Forecast tables to check if DDMS data info have been ingested for the latest forecast
last_year_week_ddms = df_ddms.agg(f.max("year_week")).collect()[0][0]
last_year_week_forecast = df_forecast_enriched_with_ddms.agg(f.max("year_week")).collect()[0][0]
print(
    f"[INFO] last_year_week_ddms = {last_year_week_ddms}, last_year_week_forecast = {last_year_week_forecast}"
)

ddms_info_present_for_last_forecast = (
    df_ddms.filter(f.col("year_week") == last_year_week_forecast).limit(1).count() > 0
)

# If DDMS info is missing for the latest forecast, use the most recent available DDMS data
if not ddms_info_present_for_last_forecast:
    print(f"[INFO] No DDMS data for last forecasts, take latest DDMS info.")

    df_last_forecast_for_ddms = df_forecast_enriched_with_ddms.filter(
        f.col("year_week") == last_year_week_forecast
    ).drop("a_c_tags")

    df_last_forecast_with_ddms = df_last_forecast_for_ddms.join(
        df_ddms.filter(f.col("year_week") == last_year_week_ddms).drop("year_week"),
        on=["MSN_Int"],
        how="left",
    )

    df_forecast_enriched_with_ddms = df_forecast_enriched_with_ddms.filter(
        ~(f.col("year_week") == last_year_week_forecast)
    ).unionByName(df_last_forecast_with_ddms)

df_forecast_enriched_with_ddms = df_forecast_enriched_with_ddms.drop("year_week")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Transformation 2.2: Apply business rules
# MAGIC Set StandardNumber to "DDMS" only if all the following conditions are met:
# MAGIC - CustomerGroupName is "Airbus SAS"
# MAGIC - CustomerMaterialNumber is DB808 or DB235
# MAGIC - DDMS info is present (as indicated in the a_c_tags column)
# MAGIC
# MAGIC Business rules defined by Sébastien DUCRUEZET on 30/01/2026.

# COMMAND ----------

df_forecast_enriched_with_ddms = (
    df_forecast_enriched_with_ddms.withColumn("is_ddms", f.col("a_c_tags").like("%DDMS%"))
    .withColumn(
        "StandardNumber",
        f.when(
            (f.col("is_ddms"))
            & (f.col("CustomerGroupName") == "Airbus SAS")
            & (f.col("CustomerMaterialNumber").isin(["DB808", "DB235"])),
            f.lit("DDMS"),
        ).otherwise(f.col("StandardNumber")),
    )
    .drop("a_c_tags", "is_ddms")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Column name

# COMMAND ----------

expected_mandatory_columns_names = {
    ORIGINALFILEPATH,
    INGESTION_TIMESTAMP,
    ORIGINALFILESOURCE,
    EDISNAPSHOTRAW,
    EDISNAPSHOTDATE,
    BRONZEUID,
    COLLABSETKEY,
    PUBLISHINGDATE,
    FCHEADERLASTMODIFICATIONDATE,
    FCHEADERCREATIONDATE,
    HORIZONTYPE,
    PROGRAMMSN,
    EXTRACTEDTIMESTAMP,
    PUBLISHINGDATE_DATEFORMAT,
    ORIGINALCUSTOMERFORECASTDEMANDDATE_DATEFORMAT,
    PROGRAM,
    MSN_INT,
    MSN_CLEANED,
    MSN_LONG,
    f"{ORIGINALCUSTOMERFORECASTDEMANDDATE_DATEFORMAT}_week_number",
}

# COMMAND ----------

dfgx_In1_prep = gx.dataset.SparkDFDataset(df_forecast_enriched, persist=False)

red_quality_check_results = [
    dfgx_In1_prep.expect_table_columns_to_match_set(
        column_set=expected_mandatory_columns_names, exact_match=False
    )
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="New schema matches with expected schema",
    error_message="At least one red quality checks is KO, the job has stopped, check corresponding results",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="airsupply_forecast_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Latest Table

# COMMAND ----------

latest_edi_date = airsupply_ingestion_utils.get_last_date(
    df=df_forecast_enriched, column="EDISnapshotdate"
)
df_forecast_enriched_latest = df_forecast_enriched.filter(
    f.col("EDISnapshotdate") == latest_edi_date
)
df_forecast_enriched_latest_with_ddms = df_forecast_enriched_with_ddms.filter(
    f.col("EDISnapshotdate") == latest_edi_date
)
try:
    # Save latest
    table_utils.save_table(
        dest_table=dest_silver_table, df=df_forecast_enriched_latest, mode="overwrite"
    )
    # Save latest with ddms, will be imported during CSV creation to add DDMS info
    table_utils.save_table(
        dest_table=dest_silver_with_ddms_table,
        df=df_forecast_enriched_latest_with_ddms,
        mode="overwrite",
    )
except AnalysisException as e:
    log.error(
        f"Table {dest_silver_table} has not been created, an error occured during creation."
        f"\n Error is : \n {e}"
    )
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save history table

# COMMAND ----------

if (
    table_utils.UnityCatalogCheckTableExists(dest_silver_history_table)
    and not FORCE_REINITIALIZATION
):
    mode = "append"
else:
    mode = "overwrite"
log.info(f"saving table {dest_silver_history_table} in {mode} mode")
try:
    table_utils.save_table(
        dest_table=dest_silver_history_table,
        df=df_forecast_enriched,
        mode=mode,
        merge_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {dest_silver_history_table} has not been created, an error occured during creation."
        f"\n Error is : \n {e}"
    )
    raise e
