# Databricks notebook source
# %% Imports
import pandas as pd
from IPython.display import display
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("read_env", "dev")
READ_ENV = dbutils.widgets.get("read_env")

dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Constants
ASCO_SILS_BRONZE_STACK_DATABASE = (
    f"{READ_ENV}_bronze.leap_depot_uc22_demand_management_is_boeing"
)
ASCO_SILS_BRONZE_STACK_TABLE = (
    f"{ASCO_SILS_BRONZE_STACK_DATABASE}.asco_sils_bronze_stack"
)

ASCO_SILS_BUSINESS_HEADERS_DATABASE = f"{READ_ENV}_bronze.manual_input"
ASCO_SILS_BUSINESS_HEADERS_TABLE = (
    f"{ASCO_SILS_BUSINESS_HEADERS_DATABASE}.asco_sils_business_headers"
)

ASCO_SILS_WRITE_DATABASE = f"{WRITE_ENV}_silver.commercial_and_program_boeing"
ASCO_SILS_SILVER_TABLE = f"{ASCO_SILS_WRITE_DATABASE}.asco_sils_silver"

ASCO_SILS_FILENAME_TIMESTAMPS_REGEX = r"(\d{8}\_\d{6})\_(\d{8}) ASCO_Sils.csv"

ASCO_SILS_DATAFRAME_PREFIX = "ASCO"

# COMMAND ----------

# %% Read ASCO SILS with spark
df_asco_sils_bronze_stack = spark.read.table(ASCO_SILS_BRONZE_STACK_TABLE)

if DEBUG:
    display(df_asco_sils_bronze_stack.toPandas())

# COMMAND ----------

# %% Remove %20 in filenames and filepath
df_asco_sils_bronze_stack_clean = df_asco_sils_bronze_stack.withColumns(
    {
        column_name: f.replace(f.col(column_name), f.lit("%20"), f.lit(" "))
        for column_name in ["filename", "filepath"]
    }
)

if DEBUG:
    display(df_asco_sils_bronze_stack_clean.toPandas())

# COMMAND ----------

# %% Add leapdepot and extraction timestamps from the start of the filename and insert it after filename and filepath
file_timestamp_columns = {
    f"{timestamp_type}_timestamp": f.to_timestamp(
        f.regexp_extract(
            f.col("filename"), ASCO_SILS_FILENAME_TIMESTAMPS_REGEX, regex_index + 1
        ),
        timestamp_format,
    )
    for regex_index, (timestamp_type, timestamp_format) in enumerate(
        [
            ("leapdepot", "yyyyMMdd_HHmmss"),
            ("extraction", "yyyyMMdd"),
        ]
    )
}

df_asco_sils_bronze_stack_with_extraction = df_asco_sils_bronze_stack_clean.withColumns(
    file_timestamp_columns
).select(
    *table_utils.get_columns_for_insertion_after_column(
        df_asco_sils_bronze_stack_clean,
        search_column_name="filepath",
        insert_columns=["leapdepot_timestamp", "extraction_timestamp"],
    )
)

if DEBUG:
    display(df_asco_sils_bronze_stack_with_extraction.toPandas())

# COMMAND ----------

# %% Write business headers table using local csv
spark.sql(f"CREATE DATABASE IF NOT EXISTS {ASCO_SILS_BUSINESS_HEADERS_DATABASE}")

with open("./asco_sils_business_headers.csv") as asco_sils_business_headers_csv_file:
    pd_asco_sils_business_headers = pd.read_csv(
        asco_sils_business_headers_csv_file, sep=";"
    )

    df_asco_sils_business_headers = spark.createDataFrame(pd_asco_sils_business_headers)

    table_utils.save_table(
        dest_table=ASCO_SILS_BUSINESS_HEADERS_TABLE,
        df=df_asco_sils_business_headers,
        mode="overwrite",
        overwrite_schema=True
    )

# COMMAND ----------

# %% Read ASCO SILS business headers
df_asco_sils_business_headers = spark.read.table(ASCO_SILS_BUSINESS_HEADERS_TABLE)

if DEBUG:
    display(df_asco_sils_business_headers.toPandas())

# COMMAND ----------

# %% Cleanup and rename column names
df_asco_sils_prefixed = table_utils.add_prefix_to_columns(
    df_asco_sils_bronze_stack_with_extraction, ASCO_SILS_DATAFRAME_PREFIX
)

df_asco_sils_renamed = table_utils.rename_columns_with_sap_business_header(
    df_asco_sils_prefixed, df_asco_sils_business_headers
)

df_asco_sils_cast = table_utils.cast_columns_with_sap_business_headers(
    df_asco_sils_renamed, df_asco_sils_business_headers, date_format=None
)

if DEBUG:
    display(df_asco_sils_cast.toPandas())

# COMMAND ----------

# %% Write Silver
spark.sql(f"CREATE DATABASE IF NOT EXISTS {ASCO_SILS_WRITE_DATABASE}")

table_utils.save_table(
    dest_table=ASCO_SILS_SILVER_TABLE,
    df=df_asco_sils_cast,
    mode="overwrite",
    overwrite_schema=True
)
