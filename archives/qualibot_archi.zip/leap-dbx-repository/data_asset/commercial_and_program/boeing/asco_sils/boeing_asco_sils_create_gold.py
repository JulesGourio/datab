# Databricks notebook source
# %% Imports
import pandas as pd
from IPython.display import display
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("read_env", "dev")
READ_ENV = dbutils.widgets.get("read_env")

dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Constants
ASCO_SILS_READ_DATABASE = f"{READ_ENV}_silver.commercial_and_program_boeing"
ASCO_SILS_WRITE_DATABASE = f"{WRITE_ENV}_gold.commercial_and_program_boeing"

ASCO_SILS_SILVER_TABLE = f"{ASCO_SILS_READ_DATABASE}.asco_sils_silver"
ASCO_SILS_GOLD_TABLE = f"{ASCO_SILS_WRITE_DATABASE}.asco_sils_gold"
ASCO_SILS_GOLD_EXPOSED_TABLE = f"{ASCO_SILS_WRITE_DATABASE}.asco_sils_gold_exposed"

ASCO_SILS_DATAFRAME_PREFIX = "ASCO"

# COMMAND ----------

# %% Read ASCO SILS silver
df_asco_sils_silver = spark.read.table(ASCO_SILS_SILVER_TABLE)

if DEBUG:
    display(df_asco_sils_silver.toPandas())

# COMMAND ----------

# %% Keep program empty for now as a placeholder. (we don't have the program name in the filename)
df_asco_sils_program = df_asco_sils_silver.withColumn(
    "Program", f.lit(None).cast("string")
)

if DEBUG:
    display(df_asco_sils_program.toPandas())

# COMMAND ----------

# %% Use extraction timestamp as a business column to identify ASCO SILS forecast date
df_asco_sils_forecast_date = df_asco_sils_program.withColumn(
    "Document_Date",
    f.to_date(f.col(f"{ASCO_SILS_DATAFRAME_PREFIX}_extraction_timestamp")),
)

if DEBUG:
    display(df_asco_sils_forecast_date.toPandas())

# COMMAND ----------

# %% Add calculated fields for the Item identifier (example: "286W30C1-9AG")
df_asco_sils_item_calculations = df_asco_sils_forecast_date.withColumns(
    {
        # Eight first characters of Item (example: "286W30C1")
        "PN_Base_Number": f.substring(f.col("Item"), pos=1, len=8),
        # Fifth to eighth characters of Item (example: "30C1")
        "PN_Wire_Bundle": f.substring(f.col("Item"), pos=5, len=4),
        # If the 9th character of Item is "-": take everything after the "-", otherwise: null (example: "9AG")
        "PN_Dash_Number": f.when(
            f.substring(f.col("Item"), pos=9, len=1) == f.lit("-"),
            f.substring_index(f.col("Item"), delim="-", count=-1),
        ),
        # Three first characters of Item (example: "286")
        "PN_System_Identifier": f.substring(f.col("Item"), pos=1, len=3),
        # Fourth character of Item (example: "W")
        "PN_Program_Identifier": f.substring(f.col("Item"), pos=4, len=1),
    }
)

if DEBUG:
    display(df_asco_sils_item_calculations.toPandas())

# COMMAND ----------

# %% Warn on ASCO SILS non-null quantity and force ASCO SILS quantity to 1
df_asco_sils_non_null_quantity = df_asco_sils_item_calculations.where(
    f.col("Quantity").isNotNull()
)

if df_asco_sils_non_null_quantity.count() > 0:
    print("WARNING, some non-null quantity were found in ASCO SILS:")
    display(df_asco_sils_non_null_quantity.toPandas())

df_asco_sils_quantity = df_asco_sils_item_calculations.withColumn("Quantity", f.lit(1))

if DEBUG:
    display(df_asco_sils_quantity.toPandas())

# COMMAND ----------

# %% Write Gold
spark.sql(f"CREATE DATABASE IF NOT EXISTS {ASCO_SILS_WRITE_DATABASE}")

table_utils.save_table(
    dest_table=ASCO_SILS_GOLD_TABLE,
    df=df_asco_sils_quantity,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# %% Write Gold Exposed
columns_not_starting_with_SILS = [rf"^(?!{ASCO_SILS_DATAFRAME_PREFIX}_).*"]
exposed_select_statement = ", ".join(
    table_utils.search_columns_to_keep_in_list(
        df=df_asco_sils_quantity,
        column_name_regex_list=columns_not_starting_with_SILS,
    )
)

table_utils.create_table_view(
    src_full_tablename=ASCO_SILS_GOLD_TABLE,
    dest_full_tablename=ASCO_SILS_GOLD_EXPOSED_TABLE,
    select_statement=exposed_select_statement,
    replace_view=True,
)
