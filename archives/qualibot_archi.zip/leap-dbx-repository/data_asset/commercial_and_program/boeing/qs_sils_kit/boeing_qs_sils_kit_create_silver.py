# Databricks notebook source
# %% Imports
import pandas as pd
from IPython.display import display
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("read_env", "dev")
READ_ENV = dbutils.widgets.get("read_env")

dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Constants
QS_SILS_KIT_BRONZE_STACK_DATABASE = (
    f"{READ_ENV}_bronze.leap_depot_uc22_demand_management_is_boeing"
)
QS_SILS_KIT_BRONZE_STACK_TABLE = (
    f"{QS_SILS_KIT_BRONZE_STACK_DATABASE}.qs_sils_kit_bronze_stack"
)

QS_SILS_KIT_BUSINESS_HEADERS_DATABASE = f"{READ_ENV}_bronze.manual_input"
QS_SILS_KIT_BUSINESS_HEADERS_TABLE = (
    f"{QS_SILS_KIT_BUSINESS_HEADERS_DATABASE}.qs_sils_kit_business_headers"
)

QS_SILS_KIT_WRITE_DATABASE = f"{WRITE_ENV}_silver.commercial_and_program_boeing"
QS_SILS_KIT_SILVER_TABLE = f"{QS_SILS_KIT_WRITE_DATABASE}.qs_sils_kit_silver"

QS_SILS_KIT_FILENAME_TIMESTAMPS_REGEX = (
    r"(\d{8}\_\d{6})\_(\d{8}) QS_Latecore SILS Kits.csv"
)

QS_SILS_KIT_DATAFRAME_PREFIX = "QS_SILS"

# COMMAND ----------

# %% Read QS SILS Kit with spark
df_qs_sils_kit_bronze_stack = spark.read.table(QS_SILS_KIT_BRONZE_STACK_TABLE)

if DEBUG:
    display(df_qs_sils_kit_bronze_stack.toPandas())

# COMMAND ----------

# %% Remove %20 in filenames and filepath
df_qs_sils_kit_bronze_stack_clean = df_qs_sils_kit_bronze_stack.withColumns(
    {
        column_name: f.replace(f.col(column_name), f.lit("%20"), f.lit(" "))
        for column_name in ["filename", "filepath"]
    }
)

if DEBUG:
    display(df_qs_sils_kit_bronze_stack_clean.toPandas())

# COMMAND ----------

# %% Add leapdepot and extraction timestamps from the start of the filename and insert it after filename and filepath
file_timestamp_columns = {
    f"{timestamp_type}_timestamp": f.to_timestamp(
        f.regexp_extract(
            f.col("filename"), QS_SILS_KIT_FILENAME_TIMESTAMPS_REGEX, regex_index + 1
        ),
        timestamp_format,
    )
    for regex_index, (timestamp_type, timestamp_format) in enumerate(
        [
            ("leapdepot", "yyyyMMdd_HHmmss"),
            ("extraction", "yyyyMMdd"),
        ]
    )
}

df_qs_sils_kit_bronze_stack_with_extraction = (
    df_qs_sils_kit_bronze_stack_clean.withColumns(file_timestamp_columns).select(
        *table_utils.get_columns_for_insertion_after_column(
            df_qs_sils_kit_bronze_stack_clean,
            search_column_name="filepath",
            insert_columns=["leapdepot_timestamp", "extraction_timestamp"],
        )
    )
)

if DEBUG:
    display(df_qs_sils_kit_bronze_stack_with_extraction.toPandas())

# COMMAND ----------

# %% Write business headers table using local csv
spark.sql(f"CREATE DATABASE IF NOT EXISTS {QS_SILS_KIT_BUSINESS_HEADERS_DATABASE}")

with open(
    "./qs_sils_kit_business_headers.csv"
) as qs_sils_kit_business_headers_csv_file:
    pd_qs_sils_kit_business_headers = pd.read_csv(
        qs_sils_kit_business_headers_csv_file, sep=";"
    )

    df_qs_sils_kit_business_headers = spark.createDataFrame(pd_qs_sils_kit_business_headers)

    table_utils.save_table(
        dest_table=QS_SILS_KIT_BUSINESS_HEADERS_TABLE,
        df=df_qs_sils_kit_business_headers,
        mode="overwrite",
        overwrite_schema=True
    )

# COMMAND ----------

# %% Read QS SILS Kit business headers
df_qs_sils_kit_business_headers = spark.read.table(QS_SILS_KIT_BUSINESS_HEADERS_TABLE)

if DEBUG:
    display(df_qs_sils_kit_business_headers.toPandas())

# COMMAND ----------

# %% Cleanup and rename column names
df_qs_sils_kit_prefixed = table_utils.add_prefix_to_columns(
    df_qs_sils_kit_bronze_stack_with_extraction,
    QS_SILS_KIT_DATAFRAME_PREFIX,
)

df_qs_sils_kit_renamed = table_utils.rename_columns_with_sap_business_header(
    df_qs_sils_kit_prefixed, df_qs_sils_kit_business_headers
)

df_qs_sils_kit_cast = table_utils.cast_columns_with_sap_business_headers(
    df_qs_sils_kit_renamed, df_qs_sils_kit_business_headers, date_format=None
)

if DEBUG:
    display(df_qs_sils_kit_cast.toPandas())

# COMMAND ----------

# %% Trim leading space in the "PO_Number" column (source column named "Schedule #") because of Excel file having the
#  wrong encoding

if DEBUG:
    print(f"{df_qs_sils_kit_cast.toPandas()['PO_Number'][0]!r}")

df_qs_sils_kit_trim = df_qs_sils_kit_cast.withColumn(
    "PO_Number", f.trim(f.col("PO_Number"))
)

if DEBUG:
    display(df_qs_sils_kit_trim.toPandas())
    print(f"{df_qs_sils_kit_trim.toPandas()['PO_Number'][0]!r}")


# COMMAND ----------

# %% Write Silver
spark.sql(f"CREATE DATABASE IF NOT EXISTS {QS_SILS_KIT_WRITE_DATABASE}")

table_utils.save_table(
    dest_table=QS_SILS_KIT_SILVER_TABLE,
    df=df_qs_sils_kit_trim,
    mode="overwrite",
    overwrite_schema=True
)
