# Databricks notebook source
# %% Imports
import pandas as pd
from IPython.display import display
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("read_env", "dev")
READ_ENV = dbutils.widgets.get("read_env")

dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Constants
QS_SILS_KIT_READ_DATABASE = f"{READ_ENV}_silver.commercial_and_program_boeing"
QS_SILS_KIT_WRITE_DATABASE = f"{WRITE_ENV}_gold.commercial_and_program_boeing"

QS_SILS_KIT_SILVER_TABLE = f"{QS_SILS_KIT_READ_DATABASE}.qs_sils_kit_silver"
QS_SILS_KIT_GOLD_TABLE = f"{QS_SILS_KIT_WRITE_DATABASE}.qs_sils_kit_gold"
QS_SILS_KIT_GOLD_EXPOSED_TABLE = (
    f"{QS_SILS_KIT_WRITE_DATABASE}.qs_sils_kit_gold_exposed"
)

QS_SILS_KIT_DATAFRAME_PREFIX = "QS_SILS"

# COMMAND ----------

# %% Read QS SILS Kit silver
df_qs_sils_kit_silver = spark.read.table(QS_SILS_KIT_SILVER_TABLE)

if DEBUG:
    display(df_qs_sils_kit_silver.toPandas())

# COMMAND ----------

# %% Keep program empty for now as a placeholder. (we don't have the program name in the filename)
df_qs_sils_kit_program = df_qs_sils_kit_silver.withColumn(
    "Program", f.lit(None).cast("string")
)

if DEBUG:
    display(df_qs_sils_kit_program.toPandas())

# COMMAND ----------

# %% Use extraction timestamp as a business column to identify QS SILS Kit forecast date
df_qs_sils_kit_forecast_date = df_qs_sils_kit_program.withColumn(
    "Document_Date",
    f.to_date(f.col(f"{QS_SILS_KIT_DATAFRAME_PREFIX}_extraction_timestamp")),
)

if DEBUG:
    display(df_qs_sils_kit_forecast_date.toPandas())

# COMMAND ----------

# %% Add calculated fields for the Item identifier (example: "286W30C1-9AG")
df_qs_sils_kit_item_calculations = df_qs_sils_kit_forecast_date.withColumns(
    {
        # Eight first characters of Item (example: "286W30C1")
        "PN_Base_Number": f.substring(f.col("Item"), pos=1, len=8),
        # If the 9th character of Item is "-": take everything after the "-", otherwise: null (example: "9AG")
        "PN_Dash_Number": f.when(
            f.substring(f.col("Item"), pos=9, len=1) == f.lit("-"),
            f.substring_index(f.col("Item"), delim="-", count=-1),
        ),
        # Three first characters of Item (example: "286")
        "PN_System_Identifier": f.substring(f.col("Item"), pos=1, len=3),
        # Fourth character of Item (example: "W")
        "PN_Program_Identifier": f.substring(f.col("Item"), pos=4, len=1),
    }
)

if DEBUG:
    display(df_qs_sils_kit_item_calculations.toPandas())

# COMMAND ----------

# %% Write Gold
spark.sql(f"CREATE DATABASE IF NOT EXISTS {QS_SILS_KIT_WRITE_DATABASE}")

table_utils.save_table(
    dest_table=QS_SILS_KIT_GOLD_TABLE,
    df=df_qs_sils_kit_item_calculations,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# %% Write Gold Exposed
columns_not_starting_with_QS_SILS = [rf"^(?!{QS_SILS_KIT_DATAFRAME_PREFIX}_).*"]
exposed_select_statement = ", ".join(
    table_utils.search_columns_to_keep_in_list(
        df=df_qs_sils_kit_item_calculations,
        column_name_regex_list=columns_not_starting_with_QS_SILS,
    )
)

table_utils.create_table_view(
    src_full_tablename=QS_SILS_KIT_GOLD_TABLE,
    dest_full_tablename=QS_SILS_KIT_GOLD_EXPOSED_TABLE,
    select_statement=exposed_select_statement,
    replace_view=True,
)
