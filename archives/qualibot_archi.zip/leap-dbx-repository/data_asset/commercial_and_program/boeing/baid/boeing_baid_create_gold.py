# Databricks notebook source
# MAGIC %md
# MAGIC # Setup

# COMMAND ----------

# %% Imports
import pandas as pd
from IPython.display import display
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Constants
BAID_READ_DATABASE = f"{PIPELINE_READ_ENV}_silver.commercial_and_program_boeing"
BAID_WRITE_DATABASE = f"{PIPELINE_WRITE_ENV}_gold.commercial_and_program_boeing"

BAID_SILVER_TABLE = f"{BAID_READ_DATABASE}.baid_silver"
BAID_GOLD_TABLE = f"{BAID_WRITE_DATABASE}.baid_gold"
BAID_GOLD_EXPOSED_TABLE = f"{BAID_WRITE_DATABASE}.baid_gold_exposed"

BAID_DATAFRAME_PREFIX = "BAID"

# COMMAND ----------

# MAGIC %md
# MAGIC # Read table

# COMMAND ----------

# %% Read BAID silver
df_baid_silver = spark.read.table(BAID_SILVER_TABLE)

if DEBUG:
    display(df_baid_silver.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC # Data asset enrichment

# COMMAND ----------

# %% Keep program empty for now as a placeholder, but filename is not robust enough to obtain the program name.
df_baid_program = df_baid_silver.withColumn("Program", f.lit(None).cast("string"))

if DEBUG:
    display(df_baid_program.toPandas())

# COMMAND ----------

# %% Use extraction timestamp as a business column to identify BAID forecast date
df_baid_forecast_date = df_baid_program.withColumn(
    "Document_Date", f.to_date(f.col(f"{BAID_DATAFRAME_PREFIX}_extraction_timestamp"))
)

if DEBUG:
    display(df_baid_forecast_date.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC # Save table

# COMMAND ----------

# %% Write Gold
spark.sql(f"CREATE DATABASE IF NOT EXISTS {BAID_WRITE_DATABASE}")

table_utils.save_table(
    dest_table=BAID_GOLD_TABLE,
    df=df_baid_forecast_date,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# %% Write Gold Exposed
columns_not_starting_with_BAID = [rf"^(?!{BAID_DATAFRAME_PREFIX}_).*"]
exposed_select_statement = ", ".join(
    table_utils.search_columns_to_keep_in_list(
        df=df_baid_forecast_date,
        column_name_regex_list=columns_not_starting_with_BAID,
    )
)

table_utils.create_table_view(
    src_full_tablename=BAID_GOLD_TABLE,
    dest_full_tablename=BAID_GOLD_EXPOSED_TABLE,
    select_statement=exposed_select_statement,
    replace_view=True,
)
