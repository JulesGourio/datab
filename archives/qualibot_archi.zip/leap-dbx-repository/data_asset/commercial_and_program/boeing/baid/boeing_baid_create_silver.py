# Databricks notebook source
# MAGIC %md
# MAGIC # Setup

# COMMAND ----------

# %% Imports
import pandas as pd
from IPython.display import display
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Constants
BAID_BRONZE_STACK_READ_DATABASE = (
    f"{REFERENCE_READ_ENV}_bronze.leap_depot_uc22_demand_management_is_boeing"
)
BAID_BRONZE_STACK_TABLE = f"{BAID_BRONZE_STACK_READ_DATABASE}.baid_bronze_stack"

BAID_BUSINESS_HEADERS_READ_DATABASE = f"{PIPELINE_READ_ENV}_bronze.manual_input"
BAID_BUSINESS_HEADERS_READ_TABLE = (
    f"{BAID_BUSINESS_HEADERS_READ_DATABASE}.baid_business_headers"
)

BAID_BUSINESS_HEADERS_WRITE_DATABASE = f"{PIPELINE_WRITE_ENV}_bronze.manual_input"
BAID_BUSINESS_HEADERS_WRITE_TABLE = (
    f"{BAID_BUSINESS_HEADERS_WRITE_DATABASE}.baid_business_headers"
)

BAID_WRITE_DATABASE = f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program_boeing"
BAID_WRITE_SILVER_TABLE = f"{BAID_WRITE_DATABASE}.baid_silver"

BAID_FILENAME_TIMESTAMPS_REGEX = r"(\d{8}_\d{6})_BAID-6[_ ](\d{4}-\d{2}-\d{2}|\d{8}_\d{6}).(?i)txt"

BAID_DATAFRAME_PREFIX = "BAID"

# COMMAND ----------

# MAGIC %md
# MAGIC # Read table

# COMMAND ----------

# %% Read BAID with spark
df_baid_bronze_stack = spark.read.table(BAID_BRONZE_STACK_TABLE)

if DEBUG:
    display(df_baid_bronze_stack.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC # Data asset metadata

# COMMAND ----------

# %% Remove %20 in filenames and filepath
df_baid_bronze_stack_clean = df_baid_bronze_stack.withColumns(
    {
        column_name: f.replace(f.col(column_name), f.lit("%20"), f.lit(" "))
        for column_name in ["filename", "filepath"]
    }
)

if DEBUG:
    display(df_baid_bronze_stack_clean.toPandas())

# COMMAND ----------

# %% Add leapdepot and extraction timestamps from the start of the filename and insert it after filename and filepath
leapdepot_raw = f.regexp_extract(f.col("filename"), BAID_FILENAME_TIMESTAMPS_REGEX, 1)
extraction_raw = f.regexp_extract(f.col("filename"), BAID_FILENAME_TIMESTAMPS_REGEX, 2)

df_baid_bronze_stack_with_extraction = df_baid_bronze_stack_clean.withColumns(
    {
        "leapdepot_timestamp": f.to_timestamp(leapdepot_raw, "yyyyMMdd_HHmmss"),

        "extraction_timestamp": f.coalesce(
            f.try_to_timestamp(extraction_raw, f.lit("yyyy-MM-dd")),
            f.try_to_timestamp(extraction_raw, f.lit("yyyyMMdd_HHmmss")),
        ),
    }
).select(
    *table_utils.get_columns_for_insertion_after_column(
        df_baid_bronze_stack_clean,
        search_column_name="filepath",
        insert_columns=["leapdepot_timestamp", "extraction_timestamp"],
    )
)

if DEBUG:
    display(df_baid_bronze_stack_with_extraction.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC # Business headers and column casting

# COMMAND ----------

# %% Write business headers table using repository CSV
spark.sql(f"CREATE DATABASE IF NOT EXISTS {BAID_BUSINESS_HEADERS_WRITE_DATABASE}")

with open("./baid_business_headers.csv") as baid_business_headers_csv_file:
    pd_baid_business_headers = pd.read_csv(baid_business_headers_csv_file, sep=";")

    df_baid_business_headers = spark.createDataFrame(pd_baid_business_headers)

    table_utils.save_table(
        dest_table=BAID_BUSINESS_HEADERS_WRITE_TABLE,
        df=df_baid_business_headers,
        mode="overwrite",
        overwrite_schema=True
    )

# COMMAND ----------

# %% Read BAID business headers
df_baid_business_headers = spark.read.table(BAID_BUSINESS_HEADERS_WRITE_TABLE)

if DEBUG:
    display(df_baid_business_headers.toPandas())

# COMMAND ----------

# %% Cleanup and rename column names
df_baid_prefixed = table_utils.add_prefix_to_columns(
    df_baid_bronze_stack_with_extraction, BAID_DATAFRAME_PREFIX
)

df_baid_renamed = table_utils.rename_columns_with_sap_business_header(
    df_baid_prefixed, df_baid_business_headers
)

df_baid_cast = table_utils.cast_columns_with_sap_business_headers(
    df_baid_renamed, df_baid_business_headers, date_format="M/d/yyyy"
)

if DEBUG:
    display(df_baid_cast.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC # Silver cleaning

# COMMAND ----------

# None

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality checks

# COMMAND ----------

# None

# COMMAND ----------

# MAGIC %md
# MAGIC # Save table

# COMMAND ----------

# %% Write Silver
spark.sql(f"CREATE DATABASE IF NOT EXISTS {BAID_WRITE_DATABASE}")

table_utils.save_table(
    dest_table=BAID_WRITE_SILVER_TABLE,
    df=df_baid_cast,
    mode="overwrite",
    overwrite_schema=True
)