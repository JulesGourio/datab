# Databricks notebook source
# MAGIC %md
# MAGIC # boeing_part_numbers_create_gold
# MAGIC **Description:**  
# MAGIC Add columns and transform some columns, using the same columns, then create the gold tables (normal and exposed)
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - F_Boeing_IS_Part_Numbers_Data_Asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_write_env}_silver.commercial_and_program_boeing.part_numbers_company_history
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.commercial_and_program_boeing.part_numbers_company_history
# MAGIC - {pipeline_write_env}_gold.commercial_and_program_boeing.part_numbers_company_latest
# MAGIC - {pipeline_write_env}_gold.commercial_and_program_boeing.part_numbers_company_exposed

# COMMAND ----------

# %% Imports

from IPython.display import display
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1 - Constant values

# COMMAND ----------

# %% Constants
PN_DATAFRAME_PREFIX = "PN"

catalog_read = f"{PIPELINE_READ_ENV}_silver"
domain_read = "commercial_and_program_boeing"
table_read = "part_numbers_company_history"

catalog_write = f"{PIPELINE_WRITE_ENV}_gold"
domain_write = "commercial_and_program_boeing"
table_write_latest = "part_numbers_company_latest"
table_write_history = "part_numbers_company_history"
table_write_exposed = "part_numbers_company_exposed"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2 - Read Table

# COMMAND ----------

# %% Read PN silver
df_pn_silver = spark.read.table(f"{catalog_read}.{domain_read}.{table_read}")

if DEBUG:
    df_pn_silver.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3 - Data asset enrichment
# MAGIC
# MAGIC - Program
# MAGIC - Document_Date

# COMMAND ----------

df_pn_enriched = df_pn_silver.withColumn("Document_Date", f.to_date(f.col(f"{PN_DATAFRAME_PREFIX}_extraction_timestamp")))

if DEBUG:
    df_pn_enriched.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4 - Save Table

# COMMAND ----------

# MAGIC %md
# MAGIC ### History

# COMMAND ----------

# %% Write Gold
spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog_write}.{domain_write}")

table_utils.save_table(
    dest_table=f"{catalog_write}.{domain_write}.{table_write_history}",
    df=df_pn_enriched,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Latest

# COMMAND ----------

max_extraction_date = df_pn_enriched.select(
    f.max(f"{PN_DATAFRAME_PREFIX}_ingestion_timestamp")
).first()[0]

df_pn_gold_latest = df_pn_enriched.filter(
    f.col(f"{PN_DATAFRAME_PREFIX}_ingestion_timestamp") == max_extraction_date
)

# Save BTT Bundel Gold Latest
table_utils.save_table(df=df_pn_gold_latest, dest_table=f"{catalog_write}.{domain_write}.{table_write_latest}", mode="overwrite")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Exposed table

# COMMAND ----------

# %% Write Gold Exposed
columns_not_starting_with_PN = [rf"^(?!{PN_DATAFRAME_PREFIX}_).*"]
exposed_select_statement = ", ".join(
    table_utils.search_columns_to_keep_in_list(
        df=df_pn_gold_latest,
        column_name_regex_list=columns_not_starting_with_PN,
    )
)

table_utils.create_table_view(
    src_full_tablename=f"{catalog_write}.{domain_write}.{table_write_latest}",
    dest_full_tablename=f"{catalog_write}.{domain_write}.{table_write_exposed}",
    select_statement=exposed_select_statement,
    replace_view=True,
)
