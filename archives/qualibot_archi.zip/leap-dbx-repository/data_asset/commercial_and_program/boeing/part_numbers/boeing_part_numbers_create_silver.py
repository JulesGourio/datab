# Databricks notebook source
# MAGIC %md
# MAGIC # boeing_part_numbers_create_silver
# MAGIC **Description:**  
# MAGIC Adds columns (leapdepot and extraction times) using regex on filename, rename Buissnes columns name using local csv file.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - F_Boeing_IS_Part_Numbers_Data_Asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_dev_bronze.leap_depot_uc22_demand_management_is_boeing.part_numbers_company_stack
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.commercial_and_program_boeing.part_numbers_company_history

# COMMAND ----------

# %% Imports
import pandas as pd
from IPython.display import display
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1 - Constant Variables

# COMMAND ----------

# %% Constants
catalog_read = f"{PIPELINE_READ_ENV}_bronze"
domain_read = "leap_depot_uc22_demand_management_is_boeing"
table_read = "part_numbers_company_stack"

catalog_read_buissnes_headers = f"{PIPELINE_READ_ENV}_bronze"
domain_read_buissnes_headers = "manual_input"
table_read_buissnes_headers = "part_numbers_company_business_headers"

catalog_write = f"{PIPELINE_WRITE_ENV}_silver"
domain_write = "commercial_and_program_boeing"
table_write = "part_numbers_company_history"

# Regex expressions
datetime_regex = r"(\d{8}\_\d{6})"  # Matches 'YYYYMMDD_HHMMSS'
date_regex = r"(\d{8})"  # Matches 'YYYYMMDD' before space

PN_DATAFRAME_PREFIX = "PN"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2 - Read Bronze Table

# COMMAND ----------

# %% Read part_numbers with spark
df_pn_bronze_stack = spark.read.table(f"{catalog_read}.{domain_read}.{table_read}")

if DEBUG:
    df_pn_bronze_stack.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3 - Metadata Columns

# COMMAND ----------

# %% Add leapdepot and extraction timestamps from the start of the filename and insert it after filename and filepath
df_pn_transformed = (
    df_pn_bronze_stack.withColumn(
        "extraction_timestamp",
        f.to_timestamp(f.regexp_extract("file_name", datetime_regex, 1), "yyyyMMdd_HHmmss"),
    )
    .withColumn(
        "leapdepot_timestamp",
        f.to_date(f.regexp_extract("file_name", date_regex, 1), "yyyyMMdd"),
    )  # Convert to Date
)

col_to_move_leadpot = "leapdepot_timestamp"
col_to_move_extraction = "extraction_timestamp"

list_columns_new_order = table_utils.get_columns_for_insertion_after_column(
    df_pn_transformed, "file_path", [col_to_move_leadpot, col_to_move_extraction]
)
# Remove repete columns
list_columns_new_order = list_columns_new_order[:-2]

df_pn_stack_with_extraction = df_pn_transformed.select(list_columns_new_order)


if DEBUG:
    df_pn_stack_with_extraction.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4 - Headers transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ### - Read local csv file and save table

# COMMAND ----------

# %% Write business headers table using repository CSV
spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog_read_buissnes_headers}.{domain_read_buissnes_headers}")

with open("./pn_company_business_headers.csv") as pn_business_headers_csv_file:
    pd_pn_business_headers = pd.read_csv(pn_business_headers_csv_file, sep=";")

    df_pn_business_headers = spark.createDataFrame(pd_pn_business_headers)

    table_utils.save_table(
        dest_table=f"{catalog_read_buissnes_headers}.{domain_read_buissnes_headers}.{table_read_buissnes_headers}",
        df=df_pn_business_headers,
        mode="overwrite",
        overwrite_schema=True
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### - Read header table

# COMMAND ----------

# %% Read part_numbers business headers
df_pn_business_headers = spark.read.table(f"{catalog_read_buissnes_headers}.{domain_read_buissnes_headers}.{table_read_buissnes_headers}")

if DEBUG:
    df_pn_business_headers.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### - Set Buisnes Headers

# COMMAND ----------

# %% Cleanup and rename column names
df_pn_prefixed = table_utils.add_prefix_to_columns(
    df_pn_stack_with_extraction, PN_DATAFRAME_PREFIX
)

df_pn_renamed = table_utils.rename_columns_with_sap_business_header(
    df_pn_prefixed, df_pn_business_headers
)


if DEBUG:
    df_pn_renamed.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5 - Save Table

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog_write}.{domain_write}")

table_utils.save_table(
    dest_table=f"{catalog_write}.{domain_write}.{table_write}",
    df=df_pn_renamed,
    mode="overwrite",
    overwrite_schema=True
)
