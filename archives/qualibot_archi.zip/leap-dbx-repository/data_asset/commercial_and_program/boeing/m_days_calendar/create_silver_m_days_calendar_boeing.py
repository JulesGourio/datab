# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to transform a bronze table into a silver table by formating and renaming operations
# MAGIC
# MAGIC
# MAGIC **Intput :**
# MAGIC - `{read_env}_bronze.boeing.m_days_calendar`
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - `{output_env}_silver.boeing.m_days_calendar`
# MAGIC
# MAGIC
# MAGIC **Triggered by:**
# MAGIC
# MAGIC `file arrival to check every on the first day of year otherwise manual`
# MAGIC
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text("write_env", "dev")
dbutils.widgets.text("read_env", "dev")
# Get write environment variable
WRITE_ENV = dbutils.widgets.get("write_env")
READ_ENV = dbutils.widgets.get("write_env")

INPUT_TABLE = (
    f"{READ_ENV}_bronze.leap_depot_uc22_demand_management_is_boeing.m_days_calendar"
)
OUTPUT_DATABASE = f"{WRITE_ENV}_silver.commercial_and_program_boeing"
OUTPUT_TABLE = f"{OUTPUT_DATABASE}.m_days_calendar"

# COMMAND ----------


# Useful functions
def add_table_name(df: SparkDataFrame, table_name: str) -> SparkDataFrame:
    """
    the aim of this function is to add prefix to a columnName of a specific table
    """
    for col in df.columns:
        df = df.withColumnRenamed(f"{col}", f"{table_name}_{col}")
    return df


def check_schema_of_the_file(df_names: SparkDataFrame):
    """
    the aim of this function is to Check if we have the right columns
    """
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# COMMAND ----------

# MAGIC %md
# MAGIC ####Upload Table fom Files & Renaming Headers

# COMMAND ----------

# Load m_calendar
df_calendar = spark.read.table(INPUT_TABLE)

# COMMAND ----------

## Add Prefix MCALENDAR to column
df_calendar = add_table_name(df_calendar, "BOEING")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Add Date/Int Format

# COMMAND ----------

from pyspark.sql.types import DataType, IntegerType

df_calendar = df_calendar.withColumn(
    "BOEING_Date", f.to_date(f.col("BOEING_Date").substr(1, 10), "yyyy-MM-dd")
)

df_calendar = df_calendar.withColumn(
    "BOEING_M_Day", f.col("BOEING_M_Day").cast(IntegerType())
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create Silver Table

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {OUTPUT_DATABASE}")

table_utils.save_table(
    dest_table=OUTPUT_TABLE,
    df=df_calendar,
    mode="overwrite",
    overwrite_schema=True
)
