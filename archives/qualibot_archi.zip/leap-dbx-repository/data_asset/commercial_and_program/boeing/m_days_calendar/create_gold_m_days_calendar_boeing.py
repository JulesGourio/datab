# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The purpose of this notebook is to transform a bronze table into a silver table by formating and renaming operations
# MAGIC
# MAGIC
# MAGIC **Intput :**
# MAGIC - `{read_env}_silver.boeing.m_days_calendar`
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - `{output_env}_gold.boeing.m_days_calendar`
# MAGIC
# MAGIC
# MAGIC **Triggered by:**
# MAGIC
# MAGIC `file arrival to check every on the first day of year otherwise manual`
# MAGIC
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql import functions as f
from pyspark.sql.window import Window
from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text("write_env", "dev")
dbutils.widgets.text("read_env", "dev")
# Get write environment variable
WRITE_ENV = dbutils.widgets.get("write_env")
READ_ENV = dbutils.widgets.get("write_env")

INPUT_TABLE = f"{READ_ENV}_silver.commercial_and_program_boeing.m_days_calendar"
OUTPUT_DATABASE = f"{WRITE_ENV}_gold.commercial_and_program_boeing"
OUTPUT_TABLE = f"{OUTPUT_DATABASE}.m_days_calendar"
OUTPUT_TABLE_EXPOSED = f"{OUTPUT_DATABASE}.m_days_calendar_exposed"
BUSSNESS_COLUMNS = ["Date", "M_Day", "Day_Off_reason"]

# COMMAND ----------

# MAGIC %md
# MAGIC ####Upload Table fom Files & Renaming Headers

# COMMAND ----------

# Load m_calendar
df_calendar = spark.read.table(INPUT_TABLE)

# COMMAND ----------

window_spec = Window.orderBy(f.asc("BOEING_M_Day"))
df_calendar_without_nan = df_calendar.filter(f.col("BOEING_M_Day").isNotNull())
start_index = (
    df_calendar.sort("Boeing_Date")
    .agg(f.first("Boeing_M_Day", ignorenulls=True))
    .first()[0]
)
# Add a column with row number or NaN for rows with NaN values
df_calendar_without_nan = df_calendar_without_nan.withColumn(
    "BOEING_index", f.row_number().over(window_spec) + start_index - 1
)
df_calendar = df_calendar.join(
    df_calendar_without_nan.select(["BOEING_Date", "BOEING_index"]),
    on="BOEING_Date",
    how="left",
)

# COMMAND ----------

for col in BUSSNESS_COLUMNS:
    df_calendar = df_calendar.withColumnRenamed("BOEING_" + col, col)
df_calendar = df_calendar.sort(f.asc(f.col("BOEING_Date")))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create Gold Table

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {OUTPUT_DATABASE}")

table_utils.save_table(
    dest_table=OUTPUT_TABLE,
    df=df_calendar,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Expose Gold Table

# COMMAND ----------

query = "CREATE OR REPLACE VIEW {} as select {} from {};".format(
    OUTPUT_TABLE_EXPOSED, ", ".join(BUSSNESS_COLUMNS), OUTPUT_TABLE
)
query_results = spark.sql(str(query))
