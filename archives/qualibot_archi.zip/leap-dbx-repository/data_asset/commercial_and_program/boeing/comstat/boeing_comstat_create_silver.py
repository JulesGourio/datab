# Databricks notebook source
# MAGIC %md
# MAGIC # Setup

# COMMAND ----------

# %% Imports
import pandas as pd
from IPython.display import display
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Constants
COMSTAT_BRONZE_STACK_READ_DATABASE = (
    f"{REFERENCE_READ_ENV}_bronze.leap_depot_uc22_demand_management_is_boeing"
)
COMSTAT_BRONZE_STACK_TABLE = (
    f"{COMSTAT_BRONZE_STACK_READ_DATABASE}.comstat_bronze_stack"
)

COMSTAT_BUSINESS_HEADERS_READ_DATABASE = f"{PIPELINE_READ_ENV}_bronze.manual_input"
COMSTAT_BUSINESS_HEADERS_READ_TABLE = (
    f"{COMSTAT_BUSINESS_HEADERS_READ_DATABASE}.comstat_business_headers"
)

COMSTAT_BUSINESS_HEADERS_WRITE_DATABASE = f"{PIPELINE_WRITE_ENV}_bronze.manual_input"
COMSTAT_BUSINESS_HEADERS_WRITE_TABLE = (
    f"{COMSTAT_BUSINESS_HEADERS_WRITE_DATABASE}.comstat_business_headers"
)

COMSTAT_WRITE_DATABASE = f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program_boeing"
COMSTAT_WRITE_SILVER_TABLE = f"{COMSTAT_WRITE_DATABASE}.comstat_silver"

COMSTAT_FILENAME_TIMESTAMPS_REGEX = (
    r"(\d{8}\_\d{6})_COMSTAT - Latelec_Template (\d{4}-\d{2}-\d{2}).csv"
)

COMSTAT_DATAFRAME_PREFIX = "COMSTAT"

# COMMAND ----------

# MAGIC %md
# MAGIC # Read table

# COMMAND ----------

# %% Read COMSTAT with spark
df_comstat_bronze_stack = spark.read.table(COMSTAT_BRONZE_STACK_TABLE)

if DEBUG:
    display(df_comstat_bronze_stack.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC # Data asset metadata

# COMMAND ----------

# %% Remove %20 in filenames and filepath
df_comstat_bronze_stack_clean = df_comstat_bronze_stack.withColumns(
    {
        column_name: f.replace(f.col(column_name), f.lit("%20"), f.lit(" "))
        for column_name in ["filename", "filepath"]
    }
)

if DEBUG:
    display(df_comstat_bronze_stack_clean.toPandas())

# COMMAND ----------

# %% Add leapdepot and extraction timestamps from the start of the filename and insert it after filename and filepath
file_timestamp_columns = {
    f"{timestamp_type}_timestamp": f.to_timestamp(
        f.regexp_extract(
            f.col("filename"), COMSTAT_FILENAME_TIMESTAMPS_REGEX, regex_index + 1
        ),
        timestamp_format,
    )
    for regex_index, (timestamp_type, timestamp_format) in enumerate(
        [
            ("leapdepot", "yyyyMMdd_HHmmss"),
            ("extraction", "yyyy-MM-dd"),
        ]
    )
}

df_comstat_bronze_stack_with_extraction = df_comstat_bronze_stack_clean.withColumns(
    file_timestamp_columns
).select(
    *table_utils.get_columns_for_insertion_after_column(
        df_comstat_bronze_stack_clean,
        search_column_name="filepath",
        insert_columns=["leapdepot_timestamp", "extraction_timestamp"],
    )
)

if DEBUG:
    display(df_comstat_bronze_stack_with_extraction.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC # Business headers and column casting

# COMMAND ----------

# %% Write business headers table using repository CSV
spark.sql(f"CREATE DATABASE IF NOT EXISTS {COMSTAT_BUSINESS_HEADERS_WRITE_DATABASE}")

with open("./comstat_business_headers.csv") as comstat_business_headers_csv_file:
    pd_comstat_business_headers = pd.read_csv(
        comstat_business_headers_csv_file, sep=";"
    )

    df_comstat_business_headers = spark.createDataFrame(pd_comstat_business_headers)

    table_utils.save_table(
        dest_table=COMSTAT_BUSINESS_HEADERS_WRITE_TABLE,
        df=df_comstat_business_headers,
        mode="overwrite",
        overwrite_schema=True
    )

# COMMAND ----------

# %% Read COMSTAT business headers
df_comstat_business_headers = spark.read.table(COMSTAT_BUSINESS_HEADERS_WRITE_TABLE)

if DEBUG:
    display(df_comstat_business_headers.toPandas())

# COMMAND ----------

# %% Cleanup and rename column names
df_comstat_prefixed = table_utils.add_prefix_to_columns(
    df_comstat_bronze_stack_with_extraction, COMSTAT_DATAFRAME_PREFIX
)

df_comstat_renamed = table_utils.rename_columns_with_sap_business_header(
    df_comstat_prefixed, df_comstat_business_headers
)

df_comstat_cast = table_utils.cast_columns_with_sap_business_headers(
    df_comstat_renamed, df_comstat_business_headers, date_format=None
)

if DEBUG:
    display(df_comstat_cast.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC # Silver cleaning

# COMMAND ----------

# None

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality checks

# COMMAND ----------

# None

# COMMAND ----------

# MAGIC %md
# MAGIC # Save table

# COMMAND ----------

# %% Write Silver
spark.sql(f"CREATE DATABASE IF NOT EXISTS {COMSTAT_WRITE_DATABASE}")

table_utils.save_table(
    dest_table=COMSTAT_WRITE_SILVER_TABLE,
    df=df_comstat_cast,
    mode="overwrite",
    overwrite_schema=True
)
