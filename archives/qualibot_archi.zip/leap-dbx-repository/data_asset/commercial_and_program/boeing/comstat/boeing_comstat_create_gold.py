# Databricks notebook source
# MAGIC %md
# MAGIC # Setup

# COMMAND ----------

# %% Imports
import pandas as pd
from IPython.display import display
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Constants
COMSTAT_READ_DATABASE = f"{PIPELINE_READ_ENV}_silver.commercial_and_program_boeing"
COMSTAT_WRITE_DATABASE = f"{PIPELINE_WRITE_ENV}_gold.commercial_and_program_boeing"

COMSTAT_SILVER_TABLE = f"{COMSTAT_READ_DATABASE}.comstat_silver"
COMSTAT_GOLD_TABLE = f"{COMSTAT_WRITE_DATABASE}.comstat_gold"
COMSTAT_GOLD_EXPOSED_TABLE = f"{COMSTAT_WRITE_DATABASE}.comstat_gold_exposed"

COMSTAT_DATAFRAME_PREFIX = "COMSTAT"

# COMMAND ----------

# MAGIC %md
# MAGIC # Read table

# COMMAND ----------

# %% Read COMSTAT silver
df_comstat_silver = spark.read.table(COMSTAT_SILVER_TABLE)

if DEBUG:
    display(df_comstat_silver.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC # Data asset enrichment

# COMMAND ----------

# %% Use extraction timestamp as a business column to identify COMSTAT forecast date
df_comstat_forecast_date = df_comstat_silver.withColumn(
    "Document_Date",
    f.to_date(f.col(f"{COMSTAT_DATAFRAME_PREFIX}_extraction_timestamp")),
)

if DEBUG:
    display(df_comstat_forecast_date.toPandas())

# COMMAND ----------

# %% Add calculated fields for the Item identifier (example: "286W30C1-9AG")
df_comstat_item_calculations = df_comstat_forecast_date.withColumns(
    {
        # Eight first characters of Item (example: "286W30C1")
        "PN_Base_Number": f.substring(f.col("Item"), pos=1, len=8),
        # If the 9th character of Item is "-": take everything after the "-", otherwise: null (example: "9AG")
        "PN_Dash_Number": f.when(
            f.substring(f.col("Item"), pos=9, len=1) == f.lit("-"),
            f.substring_index(f.col("Item"), delim="-", count=-1),
        ),
        # Three first characters of Item (example: "286")
        "PN_System_Identifier": f.substring(f.col("Item"), pos=1, len=3),
        # Fourth character of Item (example: "W")
        "PN_Program_Identifier": f.substring(f.col("Item"), pos=4, len=1),
    }
)

if DEBUG:
    display(df_comstat_item_calculations.toPandas())

# COMMAND ----------

# MAGIC %md
# MAGIC # Save table

# COMMAND ----------

# %% Write Gold
spark.sql(f"CREATE DATABASE IF NOT EXISTS {COMSTAT_WRITE_DATABASE}")

table_utils.save_table(
    dest_table=COMSTAT_GOLD_TABLE,
    df=df_comstat_item_calculations,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# %% Write Gold Exposed
columns_not_starting_with_COMSTAT = [rf"^(?!{COMSTAT_DATAFRAME_PREFIX}_).*"]
exposed_select_statement = ", ".join(
    table_utils.search_columns_to_keep_in_list(
        df=df_comstat_item_calculations,
        column_name_regex_list=columns_not_starting_with_COMSTAT,
    )
)

table_utils.create_table_view(
    src_full_tablename=COMSTAT_GOLD_TABLE,
    dest_full_tablename=COMSTAT_GOLD_EXPOSED_TABLE,
    select_statement=exposed_select_statement,
    replace_view=True,
)
