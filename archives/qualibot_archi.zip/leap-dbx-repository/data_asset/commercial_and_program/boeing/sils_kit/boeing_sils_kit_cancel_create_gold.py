# Databricks notebook source
# MAGIC %md
# MAGIC # boeing_sils_kit_cancel_create_gold
# MAGIC
# MAGIC **Description:**  
# MAGIC Create of gold table, separating PO & Company Code
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - F_Boeing_SILS_Kit_Data_Asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver.commercial_and_program_boeing.sils_kit_cancel_silver
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.commercial_and_program_boeing.sils_kit_cancel_gold

# COMMAND ----------

# %% Imports
import pandas as pd
from IPython.display import display
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Constants
SILS_KIT_WRITE_DATABASE = f"{PIPELINE_WRITE_ENV}_gold.commercial_and_program_boeing"

# Sils Kit Cancel file
SILS_KIT_CANCEL_SILVER_TABLE = (
    f"{PIPELINE_READ_ENV}_silver.commercial_and_program_boeing.sils_kit_cancel_silver"
)
SILS_KIT_CANCEL_GOLD_TABLE = f"{SILS_KIT_WRITE_DATABASE}.sils_kit_cancel_gold"
SILS_KIT_CANCEL_GOLD_EXPOSED_TABLE = (
    f"{SILS_KIT_WRITE_DATABASE}.sils_kit_cancel_gold_exposed"
)

SILS_KIT_DATAFRAME_PREFIX = "SILS"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read SILS Kit silver

# COMMAND ----------

# %% Read SILS Kit silver
df_sils_kit_cancel_silver = spark.read.table(SILS_KIT_CANCEL_SILVER_TABLE)

if DEBUG:
    df_sils_kit_cancel_silver.limit(10).display()

# COMMAND ----------

# %% Use extraction timestamp as a business column to identify sils kit forecast date
df_sils_kit_cancel_document_date = df_sils_kit_cancel_silver.withColumn(
    "Document_Date",
    f.to_date(f.col(f"{SILS_KIT_DATAFRAME_PREFIX}_extraction_timestamp")),
)

if DEBUG:
    df_sils_kit_cancel_document_date.limit(10).display()

# COMMAND ----------

df_sils_kit_cancel_calculations = df_sils_kit_cancel_document_date.withColumns(
    {
        # Eight first characters of Item (example: "286W30C1")
        "Company_Code": f.substring(f.col("Company_And_PO_Number"), pos=1, len=3),
        "PO_Number": f.substring(f.col("Company_And_PO_Number"), pos=5, len=9),
    }
)
df_sils_kit_cancel_calculations = df_sils_kit_cancel_calculations.drop(
    "Company_And_PO_Number"
)

if DEBUG:
    df_sils_kit_cancel_calculations.limit(10).display()

# COMMAND ----------

# %% Write Gold
spark.sql(f"CREATE DATABASE IF NOT EXISTS {SILS_KIT_WRITE_DATABASE}")

table_utils.save_table(
    dest_table=SILS_KIT_CANCEL_GOLD_TABLE,
    df=df_sils_kit_cancel_calculations,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

columns_not_starting_with_SILS = [r"^(?!SILS_).*"]
# Sils Kit Cancel File
exposed_select_statement_cancel = ", ".join(
    table_utils.search_columns_to_keep_in_list(
        df=df_sils_kit_cancel_calculations,
        column_name_regex_list=columns_not_starting_with_SILS,
    )
)

table_utils.create_table_view(
    src_full_tablename=SILS_KIT_CANCEL_GOLD_TABLE,
    dest_full_tablename=SILS_KIT_CANCEL_GOLD_EXPOSED_TABLE,
    select_statement=exposed_select_statement_cancel,
    replace_view=True,
)
