# Databricks notebook source
# MAGIC %md
# MAGIC # boeing_sils_kit_create_silver
# MAGIC **Description:**
# MAGIC This notebook adds some columns (leadpot & extraction time), rename to columns Buissnes name using local csv, set Date formats, and validates certains columns are not null/empty values, these columns ("red_quality_check_columns") are defined as those that should have values.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - F_Boeing_SILS_Kit_Data_Asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_bronze.leap_depot_uc22_demand_management_is_boeing.sils_kit_bronze_stack
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.commercial_and_program_boeing.sils_kit_silver
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **Python dependencies needed**
# MAGIC
# MAGIC `%pip install great-expectations`

# COMMAND ----------

# %% Imports
import pandas as pd
from databricks.sdk.runtime import dbutils
from great_expectations.dataset import SparkDFDataset
from pyspark.sql import functions as f

from leap_utils.common.validation import gx_validation
from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Constants
SILS_KIT_BRONZE_STACK_READ_DATABASE = (
    f"{PIPELINE_READ_ENV}_bronze.leap_depot_uc22_demand_management_is_boeing"
)
SILS_KIT_BRONZE_STACK_TABLE = (
    f"{SILS_KIT_BRONZE_STACK_READ_DATABASE}.sils_kit_bronze_stack"
)

SILS_KIT_BUSINESS_HEADERS_READ_DATABASE = f"{PIPELINE_READ_ENV}_bronze.manual_input"
SILS_KIT_BUSINESS_HEADERS_WRITE_DATABASE = f"{PIPELINE_WRITE_ENV}_bronze.manual_input"

SILS_KIT_BUSINESS_HEADERS_READ_TABLE = (
    f"{SILS_KIT_BUSINESS_HEADERS_READ_DATABASE}.sils_kit_business_headers"
)
SILS_KIT_BUSINESS_HEADERS_WRITE_TABLE = (
    f"{SILS_KIT_BUSINESS_HEADERS_WRITE_DATABASE}.sils_kit_business_headers"
)

SILS_KIT_WRITE_DATABASE = f"{PIPELINE_WRITE_ENV}_silver.commercial_and_program_boeing"
SILS_KIT_WRITE_SILVER_TABLE = f"{SILS_KIT_WRITE_DATABASE}.sils_kit_silver"

# Regex Expression to get Date and Datetime from filename
datetime_regex = r"(\d{8}[-_]\d{6})"  # Matches 'YYYYMMDD_HHMMSS' or 'YYYYMMDD-HHMMSS'
date_regex = r"(\d{8})"  # Matches 'YYYYMMDD' before space

SILS_KIT_DATAFRAME_PREFIX = "SILS"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read Bronze table

# COMMAND ----------

# %% Read SILS Kit with spark
df_sils_kit_bronze_stack = spark.read.table(SILS_KIT_BRONZE_STACK_TABLE)

if DEBUG:
    df_sils_kit_bronze_stack.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data asset metadata
# MAGIC Remove %20 in filenames and filepath

# COMMAND ----------

df_sils_kit_bronze_stack_clean = df_sils_kit_bronze_stack.withColumns(
    {
        column_name: f.replace(f.col(column_name), f.lit("%20"), f.lit(" "))
        for column_name in ["filename", "filepath"]
    }
)

if DEBUG:
    df_sils_kit_bronze_stack_clean.limit(10).display()

# COMMAND ----------

# 1 -  Add leapdepot and extraction timestamps from the start of the filename and insert it after filename and filepath
df_transformed = df_sils_kit_bronze_stack_clean.withColumn(
    "extraction_timestamp",
    # 1 - Get Date time with 2 options,  2 - Replace "-" for "_" , 2, 3 - Convert to Timestamp
    f.to_timestamp(
        f.regexp_replace(f.regexp_extract("filename", datetime_regex, 1), "-", "_"),
        "yyyyMMdd_HHmmss",
    ),
).withColumn(
    "leapdepot_timestamp",
    f.to_date(f.regexp_extract("filename", date_regex, 1), "yyyyMMdd"),
)  # Convert to Date

# 2 - Order Columns - Add 2 columns after "filepath"
col_to_move_leadpot = "leapdepot_timestamp"
col_to_move_extraction = "extraction_timestamp"

list_columns_ordered = table_utils.get_columns_for_insertion_after_column(
    df_transformed, "filepath", [col_to_move_leadpot, col_to_move_extraction]
)
# 3 - Remove the last columns as are repeated (Are added at posistion 2 in previous step but remains also at the end of list)
list_columns_ordered = list_columns_ordered[:-2]

df_sils_kit_bronze_stack_with_extraction = df_transformed.select(list_columns_ordered)

if DEBUG:
    df_sils_kit_bronze_stack_with_extraction.filter(
        f.col("leapdepot_timestamp") > "2025-03-03"
    ).limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read Buissnes headers from CSV
# MAGIC - Create DB if not exist
# MAGIC - Read CSV headers file
# MAGIC - Save table

# COMMAND ----------

# %% Write business headers table using repository CSV
spark.sql(f"CREATE DATABASE IF NOT EXISTS {SILS_KIT_BUSINESS_HEADERS_WRITE_DATABASE}")

with open("./sils_kit_business_headers.csv") as sils_kit_business_headers_csv_file:
    pd_sils_kit_business_headers = pd.read_csv(
        sils_kit_business_headers_csv_file, sep=";"
    )

    df_sils_kit_business_headers = spark.createDataFrame(pd_sils_kit_business_headers)

    table_utils.save_table(
        dest_table=SILS_KIT_BUSINESS_HEADERS_WRITE_TABLE,
        df=df_sils_kit_business_headers,
        mode="overwrite",
        overwrite_schema=True,
    )

# COMMAND ----------

# %% Read SILS Kit business headers
df_sils_kit_business_headers = spark.read.table(SILS_KIT_BUSINESS_HEADERS_READ_TABLE)

if DEBUG:
    df_sils_kit_business_headers.limit(10).display()

# COMMAND ----------

# %% Cleanup and rename column names
df_sils_kit_prefixed = table_utils.add_prefix_to_columns(
    df_sils_kit_bronze_stack_with_extraction, SILS_KIT_DATAFRAME_PREFIX
)

df_sils_kit_renamed = table_utils.rename_columns_with_sap_business_header(
    df_sils_kit_prefixed, df_sils_kit_business_headers
)

df_sils_kit_cast = table_utils.cast_columns_with_sap_business_headers(
    df_sils_kit_renamed, df_sils_kit_business_headers, date_format=None
)
if DEBUG:
    df_sils_kit_cast.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver cleaning

# COMMAND ----------

# %% Trim leading space in the "Schedule_Number" column (source column named "Schedule #") because of Excel file having
#  the wrong encoding
if DEBUG:
    print(f"{df_sils_kit_cast.toPandas()['Schedule_Number'][0]!r}")

df_sils_kit_trim = df_sils_kit_cast.withColumn(
    "Schedule_Number", f.trim(f.col("Schedule_Number"))
)

if DEBUG:
    print(f"{df_sils_kit_trim.toPandas()['Schedule_Number'][0]!r}")
    df_sils_kit_trim.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks

# COMMAND ----------

# %% Compute the "all columns have no null values" quality check to all columns of the data asset
df = df_sils_kit_trim
gdf = SparkDFDataset(df, persist=False)

no_null_columns_validation = [
    gdf.expect_column_values_to_not_be_null(column_name) for column_name in df.columns
]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Red quality checks, some columns HAVE to be non-null.

# COMMAND ----------

red_quality_check_columns = [
    "Requirement_Date",
    "Item",
    "Schedule_Number",
    "PO_Position",
    "Quantity",
]

red_quality_check_results = [
    no_null_columns_validation[df.columns.index(red_column_name)]
    for red_column_name in red_quality_check_columns
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="All columns are non-null on this red QC",
    error_message="Could not validate that red QC columns have no null values.",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name=SILS_KIT_WRITE_SILVER_TABLE,
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Amber quality checks, all the other columns are preferred to be non-null, but not blocking.

# COMMAND ----------

amber_quality_checks_columns = [
    col_name for col_name in df.columns if col_name not in red_quality_check_columns
]

amber_quality_check_results = [
    no_null_columns_validation[df.columns.index(amber_column_name)]
    for amber_column_name in amber_quality_checks_columns
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=amber_quality_check_results,
    validation_level="AMBER",
    info_message="All columns are non-null on this amber QC",
    error_message="Could not validate that amber QC columns have no null values",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name=SILS_KIT_WRITE_SILVER_TABLE,
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Save table

# COMMAND ----------

# %% Write Silver
spark.sql(f"CREATE DATABASE IF NOT EXISTS {SILS_KIT_WRITE_DATABASE}")

table_utils.save_table(
    dest_table=SILS_KIT_WRITE_SILVER_TABLE,
    df=df_sils_kit_trim,
    mode="overwrite",
    overwrite_schema=True,
)
