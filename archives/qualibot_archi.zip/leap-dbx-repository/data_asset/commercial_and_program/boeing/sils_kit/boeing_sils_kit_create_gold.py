# Databricks notebook source
# MAGIC %md
# MAGIC # boeing_sils_kit_create_gold
# MAGIC
# MAGIC **Description:**  
# MAGIC Create of gold table, separating PO & Company Code, add Program column using "file name" col
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - F_Boeing_SILS_Kit_Data_Asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver.commercial_and_program_boeing.sils_kit_silver
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.commercial_and_program_boeing.sils_kit_gold

# COMMAND ----------

# %% Imports
import pandas as pd
from IPython.display import display
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Pandas display config
pd.set_option("display.max_columns", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.width", None)

# COMMAND ----------

# %% Constants
SILS_KIT_READ_DATABASE = f"{PIPELINE_READ_ENV}_silver.commercial_and_program_boeing"
SILS_KIT_WRITE_DATABASE = f"{PIPELINE_WRITE_ENV}_gold.commercial_and_program_boeing"

SILS_KIT_SILVER_TABLE = f"{SILS_KIT_READ_DATABASE}.sils_kit_silver"
SILS_KIT_GOLD_TABLE = f"{SILS_KIT_WRITE_DATABASE}.sils_kit_gold"
SILS_KIT_GOLD_EXPOSED_TABLE = f"{SILS_KIT_WRITE_DATABASE}.sils_kit_gold_exposed"

SILS_KIT_DATAFRAME_PREFIX = "SILS"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read Silver table

# COMMAND ----------

# %% Read SILS Kit silver
df_sils_kit_silver = spark.read.table(SILS_KIT_SILVER_TABLE)

if DEBUG:
    df_sils_kit_silver.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation and aggregation columns

# COMMAND ----------

# MAGIC %md
# MAGIC ### Add Document_Date Column

# COMMAND ----------

# %% Use extraction timestamp as a business column to identify sils kit forecast date
df_sils_kit_forecast_date = df_sils_kit_silver.withColumn(
    "Document_Date", f.col(f"{SILS_KIT_DATAFRAME_PREFIX}_leapdepot_timestamp")
)

if DEBUG:
    df_sils_kit_forecast_date.limit(10).display()

# COMMAND ----------

# %% Add calculated fields for the Item identifier (example: "286W30C1-9AG")
df_sils_kit_item_calculations = df_sils_kit_forecast_date.withColumns(
    {
        # Eight first characters of Item (example: "286W30C1")
        "PN_Base_Number": f.substring(f.col("Item"), pos=1, len=8),
        # If the 9th character of Item is "-": take everything after the "-", otherwise: null (example: "9AG")
        "PN_Dash_Number": f.when(
            f.substring(f.col("Item"), pos=9, len=1) == f.lit("-"),
            f.substring_index(f.col("Item"), delim="-", count=-1),
        ),
        # Three first characters of Item (example: "286")
        "PN_System_Identifier": f.substring(f.col("Item"), pos=1, len=3),
        # Fourth character of Item (example: "W")
        "PN_Program_Identifier": f.substring(f.col("Item"), pos=4, len=1),
    }
)

if DEBUG:
    df_sils_kit_item_calculations.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Set Program column value
# MAGIC There 2 ways to get file name, as a new change on file names will affect new rows but not previous data.
# MAGIC
# MAGIC Example of SILS_filename (yyyyMMdd_HHmmss_yyyyMMdd & yyyyMMdd_HHmmss_1_yyyyMMdd ):
# MAGIC - 20241126_090000_20241126 SILS KITS LATECOERE BUMP ESRC 737 Wire Bundles Call-Off Data.csv
# MAGIC - 20241126_090000_1_20241126 SILS KITS LATECOERE BUMP ESRC 737 Wire Bundles Call-Off Data.csv

# COMMAND ----------

regex_pattern = r"(\d{3})(?=\sWire)"
# In order to match, the rule is to get 3 digits before space and the word "Wire", you can see this on the files names showed above

# Add Progam value using file name, using a regex pattern
df_sils_kit_item_calculations = df_sils_kit_item_calculations.withColumn(
    "Program",
    f.regexp_extract(
        f.col("SILS_filename"), regex_pattern, idx=1
    ),  # The '1' corresponds to the first capture group
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Ad Columns Company_Code and PO_Number
# MAGIC Values come from "Schedule_Number" column

# COMMAND ----------

# %% Add Company_Code and PO_Number using the Schedule_Number (example: "618-P00212344")
df_sils_kit_schedule_number_calculation = df_sils_kit_item_calculations.withColumns(
    {
        # Three first characters of Schedule_Number (example: "618")
        "Company_Code": f.substring(f.col("Schedule_Number"), pos=1, len=3),
        # The last nine characters of Schedule_Number (example: "P00212344")
        "PO_Number": f.substring(f.col("Schedule_Number"), pos=5, len=9),
    }
)

if DEBUG:
    df_sils_kit_schedule_number_calculation.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save Table

# COMMAND ----------

# %% Write Gold
spark.sql(f"CREATE DATABASE IF NOT EXISTS {SILS_KIT_WRITE_DATABASE}")

table_utils.save_table(
    dest_table=SILS_KIT_GOLD_TABLE,
    df=df_sils_kit_schedule_number_calculation,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create View (Exposed)

# COMMAND ----------

# %% Write Gold Exposed
columns_not_starting_with_SILS = [r"^(?!SILS_).*"]
exposed_select_statement = ", ".join(
    table_utils.search_columns_to_keep_in_list(
        df=df_sils_kit_schedule_number_calculation,
        column_name_regex_list=columns_not_starting_with_SILS,
    )
)

table_utils.create_table_view(
    src_full_tablename=SILS_KIT_GOLD_TABLE,
    dest_full_tablename=SILS_KIT_GOLD_EXPOSED_TABLE,
    select_statement=exposed_select_statement,
    replace_view=True,
)
