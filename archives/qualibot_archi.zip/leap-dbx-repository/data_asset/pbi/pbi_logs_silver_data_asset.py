# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # PBI LOGS DATA ASSET SILVER
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to build PowerBI logs data assets
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - PowerBI logs ingestion.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_landingzone.pbi.pbi_users_stack
# MAGIC - {pipeline_read_env}_bronze.pbi.pbi_activity_events_latest
# MAGIC - {pipeline_read_env}_bronze.pbi.pbi_users_latest
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC - N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - N/A
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.pbi.pbi_users_history
# MAGIC - {pipeline_write_env}_silver.pbi.pbi_activity_events_history
# MAGIC
# MAGIC **Output Files Pipeline**
# MAGIC N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import DateType
from great_expectations.dataset import SparkDFDataset
from pyspark.sql.window import Window
from datetime import timedelta

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

## functions used from "leap_utils.data_asset.table_utils"
#### add_prefix_to_columns()
#### UnityCatalogCheckTableExists()
#### create_unity_catalog_table()
#### set_table_column_not_null()
#### add_table_primary_key()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("run_job_on_latest", "true")  # history/update
RUN_JOB_ON_LATEST = dbutils.widgets.get("run_job_on_latest").lower() == "true"

dbutils.widgets.text("bypass_quality_checks", "false")  # history/update
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# Set timedelta allowance in hours between extraction_timestamp and last event
dbutils.widgets.text("timedelta_allowance", "12")
TIME_DELTA_ALLOWANCE = int(dbutils.widgets.get("timedelta_allowance"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables Location
# MAGIC
# MAGIC Details on how to read the input tables

# COMMAND ----------

LANDING_ZONE_SCHEMA = f"{PIPELINE_READ_ENV}_landingzone.pbi"
BRONZE_SCHEMA = f"{PIPELINE_READ_ENV}_bronze.pbi"

# Stack of users
T_USERS_STACK = f"{LANDING_ZONE_SCHEMA}.pbi_users_stack"
# Latest active users
T_USERS_LATEST = f"{BRONZE_SCHEMA}.pbi_users_latest"
# Latest events history
T_EVENTS_LATEST = f"{BRONZE_SCHEMA}.pbi_activity_events_latest"

# Licenses of bigdb users
T_USERS_BIGDB = f"{BRONZE_SCHEMA}.licences_bigdb"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

SILVER_SCHEMA = f"{PIPELINE_WRITE_ENV}_silver.pbi"

TABLE_USER_DEST = f"{SILVER_SCHEMA}.pbi_users_history"
TABLE_USER_DEST_PK = "pbi_users_history_PK"

TABLE_EVENTS_DEST = f"{SILVER_SCHEMA}.pbi_activity_events_history"
TABLE_EVENTS_DEST_PK = "pbi_activity_events_history_PK"

MODE = "append" if RUN_JOB_ON_LATEST else "overwrite"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# Columns needed to create the empty table at first run
TABLE_USER_FIRST_COLS = {
    "stack_row_id": "BIGINT",
    "extraction_timestamp": "TIMESTAMP",
    "ingestion_timestamp": "TIMESTAMP",
    "file_name": "STRING",
    "file_mode": "STRING",
    "CompanyName": "STRING",
    "Department": "STRING",
    "DisplayName": "STRING",
    "Mail": "STRING",
    "UserPrincipalName": "STRING",
}

# cluster table by these columns, rather than partitioning
TABLE_USER_CLUSTER_COLS = "UserPrincipalName"

# As a best practice, we'll define a Primary Key on the output table, below are the PK columns
TABLE_USER_PK_COLS = "CompanyName, Department, DisplayName, UserPrincipalName"

# COMMAND ----------

# Columns needed to create the empty table at first run
TABLE_EVENTS_FIRST_COLS = {
    "stack_row_id": "BIGINT",
    "extraction_timestamp": "TIMESTAMP",
    "ingestion_timestamp": "TIMESTAMP",
    "file_name": "STRING",
    "file_mode": "STRING",
    "Id": "STRING",
    "UserId": "STRING",
    "UserKey": "STRING",
    "CreationTime": "TIMESTAMP",
}


# cluster table by these columns, rather than partitioning
TABLE_EVENTS_CLUSTER_COLS = "UserId, UserKey, CreationTime"

# As a best practice, we'll define a Primary Key on the output table, below are the PK columns
TABLE_EVENTS_PK_COLS = "Id"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# Sample reference date when target table exists ans is empty
THE_ORIGIN = "1970-01-01"
THE_END = "9999-12-31"

# License interruption detection gap
GAP_THRESHOLD_DAYS = 7

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.debug(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.debug(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.debug(f"LANDING_ZONE_SCHEMA is:  {LANDING_ZONE_SCHEMA}")
log.debug(f"BRONZE_SCHEMA is:  {BRONZE_SCHEMA}")
log.debug(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Read tables

# COMMAND ----------

# Upload T_USERS_STACK
df_users_stack = spark.read.table(f"{T_USERS_STACK}")

# Upload T_USERS_LATEST
df_users_latest = spark.read.table(f"{T_USERS_LATEST}")
df_users_latest = table_utils.add_prefix_to_columns(df_users_latest, "ulatest")

# Upload T_EVENTS_LATEST
df_events_latest = spark.read.table(f"{T_EVENTS_LATEST}")

# Upload T_USERS_BIGDB
df_users_bigdb = spark.read.table(f"{T_USERS_BIGDB}")
df_users_bigdb = table_utils.add_prefix_to_columns(df_users_bigdb, "bigdb")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - If RUN_JOB_ON_LATEST Filter Events table on needed stacks

# COMMAND ----------

# check job type - Filter all tables on needed stacks - exit notebook if target is up to date
if (table_utils.UnityCatalogCheckTableExists(TABLE_EVENTS_DEST)) and (
    RUN_JOB_ON_LATEST == True
):
    df_target = spark.read.table(TABLE_EVENTS_DEST)
    latest_extraction_timestamp = df_target.select(
        f.max("extraction_timestamp")
    ).first()[0]

    if latest_extraction_timestamp is None:
        latest_extraction_timestamp = THE_ORIGIN
        log.info(
            f"the latest_extraction_timestamp in {TABLE_EVENTS_DEST} is None, taking : {latest_extraction_timestamp}"
        )
    else:
        log.info(
            f"the latest_extraction_timestamp in {TABLE_EVENTS_DEST} is : {latest_extraction_timestamp}"
        )

    df_events_latest_filtered = df_events_latest.filter(
        f.col("extraction_timestamp") > latest_extraction_timestamp
    )
else:
    MODE = "overwrite"
    log.debug(f"MODE is:  {MODE}")
    df_events_latest_filtered = df_events_latest

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Filter Events - Get UserId, UserKey table from Events
# MAGIC
# MAGIC Depuis la table events :
# MAGIC - garder les UserKey sur 16 caractères
# MAGIC - supprimer les WorkSpaceName null et blank
# MAGIC - filtrer les colonnes utiles
# MAGIC - supprimer les RequestId null

# COMMAND ----------

df_events_filtered = df_events_latest_filtered.filter(
    (f.length(f.regexp_extract("UserKey", "^[a-zA-Z0-9]*$", 0)) == 16)
    & (f.col("WorkSpaceName").isNotNull())
    & (f.col("WorkSpaceName") != "")
    & (f.col("RequestId").isNotNull())
)

df_events_latest = df_events_latest.filter(f.col("RequestId").isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - UserId in lowercase
# MAGIC
# MAGIC Depuis la table events, transformer UserId en minuscules

# COMMAND ----------

df_events_filtered = df_events_filtered.withColumn("UserId", f.lower(f.col("UserId")))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Filter Events - Get UserId, UserKey table from Events
# MAGIC
# MAGIC Depuis la table events, trouver tous les couples : UserId, UserKey

# COMMAND ----------

# Depuis la table events, trouver tous les couples : UserId, UserKey
window = Window.partitionBy("UserId").orderBy(
    f.desc("CreationTime"), f.length("UserKey").asc()
)

# Là nous avons besoins de tous les events pour retrouver les paires : UserId, UserKey
df_events_based_users = (
    df_events_latest.withColumn("row_num", f.row_number().over(window))
    .filter(f.col("row_num") == 1)
    .select("UserId", "UserKey")
    .withColumn("UserId", f.lower(f.col("UserId")))
    .dropDuplicates()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 5a - Filter All history users
# MAGIC
# MAGIC - Depuis la table stack des users, enlever les doublons et enrichir avec le UserKey
# MAGIC - Nettoyer le DisplayName pour enlever (<Société d'appartenance>)
# MAGIC - Passer Mail en minuscules

# COMMAND ----------

window = Window.partitionBy(
    "CompanyName", "Department", "DisplayName", "UserPrincipalName"
)

df_users_stack_filtered = (
    df_users_stack.withColumn(
        "Mail", f.coalesce(f.lower(f.col("Mail")), f.lit("UNKNOWN"))
    )
    .withColumn(
        "UserPrincipalName",
        f.coalesce(f.lower(f.col("UserPrincipalName")), f.col("Mail")),
    )
    .withColumn("creation_timestamp", f.min("extraction_timestamp").over(window))
    .withColumn("latest_timestamp", f.max("extraction_timestamp").over(window))
    .filter(f.col("extraction_timestamp") == f.col("creation_timestamp"))
    .withColumn("start_validity", f.to_date(f.col("creation_timestamp")))
    .withColumn("end_validity", f.to_date(f.col("latest_timestamp")))
    .withColumn("DisplayName", f.regexp_replace("DisplayName", "\s*\(.*\)", ""))
    .drop("creation_timestamp", "latest_timestamp")
)

latest_extraction_timestamp = df_users_stack.select(
    f.max("extraction_timestamp")
).first()[0]

df_users_stack_filtered = df_users_stack_filtered.withColumn(
    "end_validity",
    f.when(
        f.col("end_validity") == f.to_date(f.lit(latest_extraction_timestamp)),
        f.lit(THE_END).cast(DateType()),
    ).otherwise(f.col("end_validity")),
)

df_users_stack_filtered = df_users_stack_filtered.withColumn(
    "CompanyName", f.coalesce(f.col("CompanyName"), f.lit("UNKNOWN"))
).withColumn("Department", f.coalesce(f.col("Department"), f.lit("UNKNOWN")))

df_users_latest = df_users_latest.withColumn(
    "ulatest_DisplayName", f.regexp_replace("ulatest_DisplayName", "\s*\(.*\)", "")
)

# COMMAND ----------

window_last = Window.partitionBy(
    "CompanyName", "Department", "DisplayName", "UserPrincipalName"
).orderBy(f.col("end_validity").desc())

df_users_stack_filtered = (
    df_users_stack_filtered
    .withColumn("rn", f.row_number().over(window_last))
    .filter(f.col("rn") == 1)
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 5b - Compute current_license_start (gap-and-island)
# MAGIC
# MAGIC Detects license interruptions (gaps > 7 days in the snapshots)
# MAGIC and calculates the start date of the most recent presence period.
# MAGIC This corrects the start_validity for users who reappear
# MAGIC after a prolonged absence.
# MAGIC
# MAGIC Protection: a gap is only counted as a license interruption if
# MAGIC other extractions occurred during the user's absence. This prevents
# MAGIC a global pipeline outage from resetting all users.

# COMMAND ----------

# All global extraction dates (independent of any user)
df_all_extraction_dates = (
    df_users_stack
    .select(f.to_date(f.col("extraction_timestamp")).alias("global_extraction_date"))
    .distinct()
)

# All distinct presence dates per user (same cleanups as Preparation 5a)
df_presence_dates = (
    df_users_stack
    .withColumn("Mail", f.coalesce(f.lower(f.col("Mail")), f.lit("UNKNOWN")))
    .withColumn(
        "UserPrincipalName",
        f.coalesce(f.lower(f.col("UserPrincipalName")), f.col("Mail")),
    )
    .withColumn("CompanyName", f.coalesce(f.col("CompanyName"), f.lit("UNKNOWN")))
    .withColumn("Department", f.coalesce(f.col("Department"), f.lit("UNKNOWN")))
    .withColumn("DisplayName", f.regexp_replace("DisplayName", r"\s*\(.*\)", ""))
    .withColumn("presence_date", f.to_date(f.col("extraction_timestamp")))
    .select(
        "CompanyName", "Department", "DisplayName", "UserPrincipalName",
        "presence_date"
    )
    .distinct()
)

window_presence = Window.partitionBy(
    "CompanyName", "Department", "DisplayName", "UserPrincipalName"
).orderBy("presence_date")

df_with_prev = df_presence_dates.withColumn(
    "prev_date", f.lag("presence_date").over(window_presence)
)

# Count how many global extractions happened during each user's gap
# If extractions_during_gap = 0, the pipeline was down → not a real license interruption
df_with_extraction_count = (
    df_with_prev
    .join(
        df_all_extraction_dates,
        on=(
            (df_all_extraction_dates.global_extraction_date > df_with_prev.prev_date)
            & (df_all_extraction_dates.global_extraction_date < df_with_prev.presence_date)
        ),
        how="left",
    )
    .groupBy(
        "CompanyName", "Department", "DisplayName", "UserPrincipalName",
        "presence_date", "prev_date"
    )
    .agg(
        f.count("global_extraction_date").alias("extractions_during_gap")
    )
)

df_with_gap_flag = df_with_extraction_count.withColumn(
    "is_new_period",
    f.when(
        f.col("prev_date").isNull(), f.lit(1)
    ).when(
        (f.datediff(f.col("presence_date"), f.col("prev_date")) > GAP_THRESHOLD_DAYS)
        & (f.col("extractions_during_gap") > 0),
        f.lit(1),
    ).otherwise(f.lit(0)),
)

df_with_period = df_with_gap_flag.withColumn(
    "period_group",
    f.sum("is_new_period").over(window_presence),
)

window_period = Window.partitionBy(
    "CompanyName", "Department", "DisplayName", "UserPrincipalName", "period_group"
)

df_period_starts = (
    df_with_period
    .withColumn("period_start", f.min("presence_date").over(window_period))
)

window_latest_period = Window.partitionBy(
    "CompanyName", "Department", "DisplayName", "UserPrincipalName"
).orderBy(f.col("period_group").desc())

df_current_license_start = (
    df_period_starts
    .withColumn("rn", f.row_number().over(window_latest_period))
    .filter(f.col("rn") == 1)
    .select(
        f.col("CompanyName").alias("cls_CompanyName"),
        f.col("Department").alias("cls_Department"),
        f.col("DisplayName").alias("cls_DisplayName"),
        f.col("UserPrincipalName").alias("cls_UserPrincipalName"),
        f.col("period_start").alias("current_license_start"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 5c - Override start_validity with current_license_start
# MAGIC
# MAGIC Replace start_validity with the start date of the last period
# MAGIC of continuous presence. Backward compatible: if no gap is detected,
# MAGIC start_validity remains unchanged thanks to coalesce.

# COMMAND ----------

df_users_stack_filtered = df_users_stack_filtered.join(
    df_current_license_start,
    on=(
        (df_users_stack_filtered.CompanyName == df_current_license_start.cls_CompanyName)
        & (df_users_stack_filtered.Department == df_current_license_start.cls_Department)
        & (df_users_stack_filtered.DisplayName == df_current_license_start.cls_DisplayName)
        & (df_users_stack_filtered.UserPrincipalName == df_current_license_start.cls_UserPrincipalName)
    ),
    how="left",
).drop("cls_CompanyName", "cls_Department", "cls_DisplayName", "cls_UserPrincipalName")

df_users_stack_filtered = df_users_stack_filtered.withColumn(
    "start_validity",
    f.coalesce(f.col("current_license_start"), f.col("start_validity")),
)

df_users_stack_filtered = df_users_stack_filtered.drop("current_license_start")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 6 - UserPrincipalName in lowercase
# MAGIC
# MAGIC Depuis la table users, transformer UserPrincipalName and Mail en minuscules

# COMMAND ----------

df_users_latest = df_users_latest.withColumn(
    "ulatest_UserPrincipalName", f.lower(f.col("ulatest_UserPrincipalName"))
).withColumn("ulatest_Mail", f.lower(f.col("ulatest_Mail")))

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Join Users with UserKey
# MAGIC
# MAGIC Enrichir la table des Users avec UserKey

# COMMAND ----------

df_users_stack_w_userkey = df_users_stack_filtered.join(
    df_events_based_users,
    on=(df_users_stack_filtered.UserPrincipalName == df_events_based_users.UserId),
    how="left",
).drop(
    "UserId",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Join Users with latest to get the active licenses
# MAGIC
# MAGIC Enrichir la table des Users avec la latest pour avoir les licences actives

# COMMAND ----------

df_users_stack_licensed = df_users_stack_w_userkey.join(
    df_users_latest.select(
        f.col("ulatest_UserPrincipalName"),
        f.col("ulatest_CompanyName"),
        f.col("ulatest_Department"),
        f.col("ulatest_DisplayName"),
    ),
    on=(
        df_users_stack_w_userkey.UserPrincipalName
        == df_users_latest.ulatest_UserPrincipalName
    )
    & (df_users_stack_w_userkey.CompanyName == df_users_latest.ulatest_CompanyName)
    & (df_users_stack_w_userkey.Department == df_users_latest.ulatest_Department)
    & (df_users_stack_w_userkey.DisplayName == df_users_latest.ulatest_DisplayName),
    how="left",
)
df_users_stack_licensed = df_users_stack_licensed.withColumn(
    "has_valid_license", (f.col("ulatest_UserPrincipalName").isNotNull())
)
df_users_stack_licensed = df_users_stack_licensed.drop(
    f.col("ulatest_UserPrincipalName"),
    f.col("ulatest_CompanyName"),
    f.col("ulatest_Department"),
    f.col("ulatest_DisplayName"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Join Users with bigdb licenses
# MAGIC
# MAGIC Enrichir la table des Users avec les licences bigdb pour avoir les licences actives bigdb et les autres

# COMMAND ----------

df_users_stack_licensed_w_bigdb = df_users_stack_licensed.join(
    df_users_bigdb.select(f.col("bigdb_Mail")),
    on=(df_users_stack_licensed.Mail == df_users_bigdb.bigdb_Mail),
    how="left",
)
df_users_stack_licensed_w_bigdb = df_users_stack_licensed_w_bigdb.withColumn(
    "has_bigdb_license", (f.col("bigdb_Mail").isNotNull())
)
df_users_stack_licensed_w_bigdb = df_users_stack_licensed_w_bigdb.drop(
    f.col("bigdb_Mail")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Add temporary ID column
# MAGIC

# COMMAND ----------

pk_cols = [col.strip() for col in TABLE_USER_PK_COLS.split(",")]
df_users_stack_licensed_with_bigdb_and_id = df_users_stack_licensed_w_bigdb.withColumn(
    "ID", f.concat_ws("_", *[f.regexp_replace(col, " ", "_") for col in pk_cols])
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 5 - Update null UserKey with ID
# MAGIC

# COMMAND ----------

df_users_stack_licensed_with_bigdb_and_userkey = (
    df_users_stack_licensed_with_bigdb_and_id.withColumn(
        "UserKey",
        f.coalesce(
            df_users_stack_licensed_with_bigdb_and_id["UserKey"],
            df_users_stack_licensed_with_bigdb_and_id["ID"],
        ),
    ).drop("ID")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 6 - Update creation_date grouping by UserKey
# MAGIC
# MAGIC Ajouter les champs :
# MAGIC - creation_date
# MAGIC - stack_initial_date
# MAGIC - stack_latest_date
# MAGIC

# COMMAND ----------

window = Window.partitionBy("UserKey")

stack_initial_date = df_users_stack_licensed_with_bigdb_and_userkey.agg(
    f.min("start_validity")
).collect()[0][0]
stack_latest_date = df_users_latest.agg(
    f.to_date(f.max("ulatest_extraction_timestamp"))
).collect()[0][0]

df_users_stack_filtered_with_creation_date = (
    df_users_stack_licensed_with_bigdb_and_userkey.withColumn(
        "creation_date", f.expr("min(start_validity)").over(window)
    )
    .withColumn("stack_initial_date", f.lit(stack_initial_date))
    .withColumn("stack_latest_date", f.lit(stack_latest_date))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display DEBUG values
# MAGIC

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    display(df_users_stack_filtered_with_creation_date)

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    display(df_events_filtered)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Final Dataframes - before quality checks and outputs
# MAGIC

# COMMAND ----------

df_users_history = df_users_stack_filtered_with_creation_date
df_events_history = df_events_filtered

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

## Quality Checks - Common Functions defined in leap_utils

#### validate_and_log_gx_results()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - Uniqueness
# MAGIC
# MAGIC
# MAGIC Tests d'unicité sur le Dataframe df_users_history

# COMMAND ----------

df_to_check = df_users_history.filter(f.col("has_valid_license") == True)
col = "UserPrincipalName"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=True)

quality_check_results = [df_gx.expect_column_values_to_be_unique(column=col)]

# Validate all red quality checks, if at least one fails the job stops
gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col}(s) are unique",
    error_message=f"{col}(s) are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="pbi_logs_silver",
    log_to_event_table=True,
    log_successes=True,
)


# COMMAND ----------

# Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
df_to_check = df_users_history
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=True)

# Define the red quality checks
table_dest_pk_cols_list = TABLE_USER_PK_COLS.replace(" ", "").split(",")
red_quality_check_results = [
    df_gx.expect_compound_columns_to_be_unique(column_list=table_dest_pk_cols_list)
]

# Validate all red quality checks, if at least one fails the job stops
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"Compound cols {TABLE_USER_PK_COLS} are unique",
    error_message=f"Compound cols {TABLE_USER_PK_COLS} are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="pbi_logs_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 2 - Not null expectation
# MAGIC
# MAGIC Tests de non valeurs nulles sur le Dataframe df_users_history

# COMMAND ----------

df_to_check = df_users_history
col = "UserKey"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=True)

quality_check_results = [df_gx.expect_column_values_to_not_be_null(column=col)]

# Validate all red quality checks, if at least one fails the job stops
gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col}(s) are not null",
    error_message=f"{col} contains null(s), check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="pbi_logs_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 3 - Check max value
# MAGIC
# MAGIC Tests de valeur max de la colonne CreationTime sur le Dataframe df_events_history
# MAGIC On doit avoir des CreationTime moins de 12 heures avant l'extraction

# COMMAND ----------

df_to_check = df_events_history
col = "CreationTime"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

# Calculer la valeur maximale de la colonne extraction_timestamp
max_timestamp = df_to_check.select(f.max("extraction_timestamp")).first()[0]

if max_timestamp is not None:
    # Soustraire {TIME_DELTA_ALLOWANCE} heures à la valeur maximale de extraction_timestamp
    lower_bound = max_timestamp - timedelta(hours=TIME_DELTA_ALLOWANCE)

    df_gx = SparkDFDataset(df_to_check, persist=True)

    quality_check_results = [
        df_gx.expect_column_max_to_be_between(column=col, min_value=lower_bound)
    ]

    # Validate all red quality checks, if at least one fails the job stops
    gx_validation.validate_and_log_gx_results(
        quality_check_results=quality_check_results,
        validation_level=validation_level,
        info_message=f"Max value for {col} is >= {lower_bound}",
        error_message=f"Result={quality_check_results} \nMax value for {col} is too old, check the summary of this run.",
        pipeline_write_env=PIPELINE_WRITE_ENV,
        table_name="pbi_logs_silver",
        log_to_event_table=True,
        log_successes=True,
    )


# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver tables Processing
# MAGIC - Write silver tables
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Users
# MAGIC

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by TABLE_USER_CLUSTER_COLS
catalog, schema, table = TABLE_USER_DEST.split(".")

try:
    table_utils.create_unity_catalog_table(
        catalog,
        schema,
        table,
        force_reinitialization=False,
        cluster_cols=TABLE_USER_CLUSTER_COLS,
        partition_col=None,
        primary_key_cols=None,
        columns=TABLE_USER_FIRST_COLS,
        force_drop=False,
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_USER_DEST} has not been created, an error occured during creation. \nError is {e}"
    )
    raise Exception()

# COMMAND ----------

# Save the table from Dataframe df_users_history, preserving cluster columns
table_user_cluster_cols_cleaned = TABLE_USER_CLUSTER_COLS.replace(" ", "")
try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=TABLE_USER_DEST,
        df=df_users_history,
        mode="overwrite",
        overwrite_schema=True,
        merge_schema=True,
        cluster_cols=table_user_cluster_cols_cleaned,
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_USER_DEST} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {TABLE_USER_DEST} saved in {duration} seconds.")
    log.info(f"Wrote {df_users_history.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Events
# MAGIC

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by TABLE_EVENTS_CLUSTER_COLS
catalog, schema, table = TABLE_EVENTS_DEST.split(".")

try:
    table_utils.create_unity_catalog_table(
        catalog,
        schema,
        table,
        force_reinitialization=False,
        cluster_cols=TABLE_EVENTS_CLUSTER_COLS,
        partition_col=None,
        primary_key_cols=None,
        columns=TABLE_EVENTS_FIRST_COLS,
        force_drop=False,
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_EVENTS_DEST} has not been created, an error occured during creation. \nError is {e}"
    )
    raise Exception()

# COMMAND ----------

# Save the table from Dataframe df_events_history, preserving cluster columns
table_events_cluster_cols_cleaned = TABLE_EVENTS_CLUSTER_COLS.replace(" ", "")
try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=TABLE_EVENTS_DEST,
        df=df_events_history,
        mode=MODE,
        overwrite_schema=True,
        merge_schema=True,
        cluster_cols=table_events_cluster_cols_cleaned,
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_EVENTS_DEST} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {TABLE_EVENTS_DEST} saved in {duration} seconds.")
    log.info(f"Wrote {df_events_history.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Constraints

# COMMAND ----------

# MAGIC %md
# MAGIC #### Users
# MAGIC

# COMMAND ----------

# Add Primary Key if not exists
catalog, schema, table = TABLE_USER_DEST.split(".")
pk_name = TABLE_USER_DEST_PK.lower()
nb_cons = spark.sql(
    f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_USER_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=TABLE_USER_DEST, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=TABLE_USER_DEST,
        pk_name=TABLE_USER_DEST_PK,
        columns=TABLE_USER_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC #### Events
# MAGIC

# COMMAND ----------

# Add Primary Key if not exists
catalog, schema, table = TABLE_EVENTS_DEST.split(".")
pk_name = TABLE_EVENTS_DEST_PK.lower()
nb_cons = spark.sql(
    f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_EVENTS_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=TABLE_EVENTS_DEST, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=TABLE_EVENTS_DEST,
        pk_name=TABLE_EVENTS_DEST_PK,
        columns=TABLE_EVENTS_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced