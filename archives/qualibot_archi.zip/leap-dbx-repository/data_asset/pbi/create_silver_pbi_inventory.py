# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Silver PBI Inventory
# MAGIC
# MAGIC **Description:**
# MAGIC Cleans the latest Power BI tenant inventory: workspaces, reports, and the tables, parameters and data sources of
# MAGIC every semantic model. Columns get business names and Power BI ids are lower-cased, since the activity logs and the
# MAGIC refresh jobs spell the same id in different cases.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - *(none)*
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - UC091 Leap Suite Overview — Power BI Inventory
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{pipeline_read_env}_bronze.pbi.pbi_inventory_workspaces_latest`
# MAGIC - `{pipeline_read_env}_bronze.pbi.pbi_inventory_reports_latest`
# MAGIC - `{pipeline_read_env}_bronze.pbi.pbi_inventory_model_tables_latest`
# MAGIC - `{pipeline_read_env}_bronze.pbi.pbi_inventory_model_parameters_latest`
# MAGIC - `{pipeline_read_env}_bronze.pbi.pbi_inventory_model_datasources_latest`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - *(none)*
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_silver.pbi.pbi_inventory_workspaces`
# MAGIC - `{pipeline_write_env}_silver.pbi.pbi_inventory_reports`
# MAGIC - `{pipeline_write_env}_silver.pbi.pbi_inventory_model_tables`
# MAGIC - `{pipeline_write_env}_silver.pbi.pbi_inventory_model_parameters`
# MAGIC - `{pipeline_write_env}_silver.pbi.pbi_inventory_model_datasources`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC 1. *(none)*

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Package Imports

# COMMAND ----------

import great_expectations as gx
import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ## LEAP Function Imports

# COMMAND ----------

from leap_utils.common import logger
from leap_utils.common.validation import gx_validation
from leap_utils.data_asset.table_utils import save_table

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Common Functions

# COMMAND ----------


def lower_id(column: str):
    """Return a Power BI id trimmed and lower-cased, so ids from every source compare equal."""
    return f.lower(f.trim(f.col(column)))


# COMMAND ----------

# MAGIC %md
# MAGIC ## Other config

# COMMAND ----------

SRC_WORKSPACES = f"{PIPELINE_READ_ENV}_bronze.pbi.pbi_inventory_workspaces_latest"
SRC_REPORTS = f"{PIPELINE_READ_ENV}_bronze.pbi.pbi_inventory_reports_latest"
SRC_MODEL_TABLES = f"{PIPELINE_READ_ENV}_bronze.pbi.pbi_inventory_model_tables_latest"
SRC_MODEL_PARAMETERS = f"{PIPELINE_READ_ENV}_bronze.pbi.pbi_inventory_model_parameters_latest"
SRC_MODEL_DATASOURCES = f"{PIPELINE_READ_ENV}_bronze.pbi.pbi_inventory_model_datasources_latest"

DEST_WORKSPACES = f"{PIPELINE_WRITE_ENV}_silver.pbi.pbi_inventory_workspaces"
DEST_REPORTS = f"{PIPELINE_WRITE_ENV}_silver.pbi.pbi_inventory_reports"
DEST_MODEL_TABLES = f"{PIPELINE_WRITE_ENV}_silver.pbi.pbi_inventory_model_tables"
DEST_MODEL_PARAMETERS = f"{PIPELINE_WRITE_ENV}_silver.pbi.pbi_inventory_model_parameters"
DEST_MODEL_DATASOURCES = f"{PIPELINE_WRITE_ENV}_silver.pbi.pbi_inventory_model_datasources"

for destination in (DEST_WORKSPACES, DEST_REPORTS, DEST_MODEL_TABLES, DEST_MODEL_PARAMETERS, DEST_MODEL_DATASOURCES):
    log.info(f"Destination table: {destination}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## LEAP tables

# COMMAND ----------

df_workspaces_raw = spark.table(SRC_WORKSPACES)
df_reports_raw = spark.table(SRC_REPORTS)
df_model_tables_raw = spark.table(SRC_MODEL_TABLES)
df_model_parameters_raw = spark.table(SRC_MODEL_PARAMETERS)
df_model_datasources_raw = spark.table(SRC_MODEL_DATASOURCES)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Workspaces

# COMMAND ----------

df_workspaces_end = df_workspaces_raw.select(
    lower_id("WorkspaceId").alias("workspace_ID"),
    f.col("WorkspaceName").alias("workspace_name"),
    f.col("WorkspaceDescription").alias("workspace_description"),
    lower_id("DomainId").alias("domain_ID"),
    f.col("Domain").alias("domain"),
    f.transform(f.col("Tags"), lambda tag: f.lower(f.trim(tag))).alias("workspace_tags"),
    f.transform(f.col("ContactEmails"), lambda email: f.lower(f.trim(email))).alias("workspace_contact_emails"),
    "extraction_timestamp",
    "file_name",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Reports
# MAGIC
# MAGIC The file's link opens the report under "My workspace" whoever the viewer is, so the link is rebuilt from the
# MAGIC workspace, as the activity logs do.

# COMMAND ----------

df_reports_end = df_reports_raw.select(
    lower_id("ReportId").alias("report_ID"),
    f.col("ReportName").alias("report_name"),
    f.col("ReportDescription").alias("report_description"),
    f.col("ReportType").alias("report_type"),
    lower_id("WorkspaceId").alias("workspace_ID"),
    f.concat(
        f.lit("https://app.powerbi.com/groups/"), lower_id("WorkspaceId"), f.lit("/reports/"), lower_id("ReportId")
    ).alias("report_url"),
    f.col("WebUrl").alias("report_web_url"),
    f.lower(f.col("ModifiedBy")).alias("report_modified_by"),
    f.transform(f.col("Tags"), lambda tag: f.lower(f.trim(tag))).alias("report_tags"),
    f.transform(f.col("ContactEmails"), lambda email: f.lower(f.trim(email))).alias("report_contact_emails"),
    lower_id("SemanticModelId").alias("semantic_model_ID"),
    f.col("SemanticModelName").alias("semantic_model_name"),
    lower_id("SemanticModelWorkspaceId").alias("semantic_model_workspace_ID"),
    f.col("SemanticModelNote").alias("semantic_model_note"),
    "extraction_timestamp",
    "file_name",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Model tables
# MAGIC
# MAGIC A model table has one source per partition, so the partition index is part of the key.

# COMMAND ----------

df_model_tables_end = df_model_tables_raw.select(
    f.concat_ws("-", lower_id("SemanticModelId"), f.col("TableName"), f.col("SourceIndex").try_cast("string")).alias(
        "pbi_inventory_model_tables_ID"
    ),
    lower_id("SemanticModelId").alias("semantic_model_ID"),
    f.col("TableName").alias("model_table_name"),
    f.col("IsHidden").alias("is_hidden"),
    f.col("SourceIndex").alias("source_index"),
    f.col("Expression").alias("m_expression"),
    "extraction_timestamp",
    "file_name",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Model parameters

# COMMAND ----------

df_model_parameters_end = df_model_parameters_raw.select(
    f.concat_ws("-", lower_id("SemanticModelId"), f.col("ParameterName")).alias("pbi_inventory_model_parameters_ID"),
    lower_id("SemanticModelId").alias("semantic_model_ID"),
    f.col("ParameterName").alias("parameter_name"),
    f.col("ParameterDescription").alias("parameter_description"),
    f.col("Expression").alias("m_expression"),
    "extraction_timestamp",
    "file_name",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Model data sources

# COMMAND ----------

df_model_datasources_end = df_model_datasources_raw.select(
    f.concat_ws("-", lower_id("SemanticModelId"), f.col("DataSourceIndex").try_cast("string")).alias(
        "pbi_inventory_model_datasources_ID"
    ),
    lower_id("SemanticModelId").alias("semantic_model_ID"),
    f.col("DataSourceIndex").alias("datasource_index"),
    f.col("DataSourceType").alias("datasource_type"),
    f.col("ConnectionKind").alias("connection_kind"),
    f.col("ConnectionPath").alias("connection_path"),
    f.col("Server").alias("server"),
    f.col("Database").alias("database"),
    f.col("Path").alias("path"),
    f.col("Url").alias("url"),
    f.col("SharePointSiteUrl").alias("sharepoint_site_url"),
    "extraction_timestamp",
    "file_name",
)

if DEBUG:
    df_reports_end.limit(5).display()
    df_model_tables_end.limit(5).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks
# MAGIC
# MAGIC RED: every key unique and present, or Gold would double-count a model's sources.

# COMMAND ----------

key_columns = {
    "workspace_ID": df_workspaces_end,
    "report_ID": df_reports_end,
    "pbi_inventory_model_tables_ID": df_model_tables_end,
    "pbi_inventory_model_parameters_ID": df_model_parameters_end,
    "pbi_inventory_model_datasources_ID": df_model_datasources_end,
}

red_results = []
for key_column, df_checked in key_columns.items():
    dfgx = gx.dataset.SparkDFDataset(df_checked, persist=False)
    red_results.append(dfgx.expect_column_values_to_be_unique(column=key_column))
    red_results.append(dfgx.expect_column_values_to_not_be_null(column=key_column))

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="Power BI inventory Silver: every key is unique and present.",
    error_message="Power BI inventory Silver: a key is repeated or missing.",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

outputs = {
    DEST_WORKSPACES: df_workspaces_end,
    DEST_REPORTS: df_reports_end,
    DEST_MODEL_TABLES: df_model_tables_end,
    DEST_MODEL_PARAMETERS: df_model_parameters_end,
    DEST_MODEL_DATASOURCES: df_model_datasources_end,
}

for destination, df_output in outputs.items():
    save_table(dest_table=destination, df=df_output, mode="overwrite", overwrite_schema=True)
    log.info(f"Saved: {destination}")
