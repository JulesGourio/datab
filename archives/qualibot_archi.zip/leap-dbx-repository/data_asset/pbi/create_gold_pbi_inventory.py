# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Gold PBI Inventory
# MAGIC
# MAGIC **Description:**
# MAGIC Tells, for every Power BI semantic model, which Databricks tables it reads, and for every report, where it lives
# MAGIC and which environments its data comes from. The tables are read out of the Power Query expression behind each
# MAGIC model table, so they are what the dashboard really reads, not what its refresh job happens to write.
# MAGIC - `pbi_semantic_model_sources` — one row per model table and Databricks table it reads; a model table whose
# MAGIC   expression names no table keeps one row with the reason. Feeds the dashboard lineage.
# MAGIC - `pbi_report_inventory` — one row per report, joinable to the activity logs on `report_ID` / `semantic_model_ID`.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - Reading a table name out of a Power Query expression — see *Common Functions*
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - UC091 Leap Suite Overview — Power BI Inventory
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{pipeline_read_env}_silver.pbi.pbi_inventory_workspaces`
# MAGIC - `{pipeline_read_env}_silver.pbi.pbi_inventory_reports`
# MAGIC - `{pipeline_read_env}_silver.pbi.pbi_inventory_model_tables`
# MAGIC - `{pipeline_read_env}_silver.pbi.pbi_inventory_model_parameters`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - *(none)*
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_gold.pbi.pbi_semantic_model_sources`
# MAGIC - `{pipeline_write_env}_gold.pbi.pbi_report_inventory`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC 1. A model table whose expression refers to a parameter the model does not define, or picks its table at refresh time, keeps `source_status` = `unresolved` in section [Transformations - Semantic model sources].

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Package Imports

# COMMAND ----------

import re

import great_expectations as gx
import pyspark.sql.functions as f
from pyspark.sql.types import ArrayType, StringType, StructField, StructType

# COMMAND ----------

# MAGIC %md
# MAGIC ## LEAP Function Imports

# COMMAND ----------

from leap_utils.common import logger
from leap_utils.common.validation import gx_validation
from leap_utils.data_asset.table_utils import save_table

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Other config

# COMMAND ----------

SRC_WORKSPACES = f"{PIPELINE_READ_ENV}_silver.pbi.pbi_inventory_workspaces"
SRC_REPORTS = f"{PIPELINE_READ_ENV}_silver.pbi.pbi_inventory_reports"
SRC_MODEL_TABLES = f"{PIPELINE_READ_ENV}_silver.pbi.pbi_inventory_model_tables"
SRC_MODEL_PARAMETERS = f"{PIPELINE_READ_ENV}_silver.pbi.pbi_inventory_model_parameters"

DEST_SEMANTIC_MODEL_SOURCES = f"{PIPELINE_WRITE_ENV}_gold.pbi.pbi_semantic_model_sources"
DEST_REPORT_INVENTORY = f"{PIPELINE_WRITE_ENV}_gold.pbi.pbi_report_inventory"

ENVIRONMENTS = ["PROD", "UAT", "DEV"]
PROD_ENVIRONMENT = "PROD"

# The workspace a model connects through decides which compute serves it, independently of the catalog it reads.
DATABRICKS_HOST_ENVS = {
    "dbc-77b87d5a-6bcb.cloud.databricks.com": "PROD",
    "dbc-3a17bfce-9e88.cloud.databricks.com": "UAT",
    "dbc-c623749d-731b.cloud.databricks.com": "DEV",
}

# Catalogs are named <env>_<layer>, with the disaster recovery and sandbox copies carrying an extra prefix.
ENV_FROM_CATALOG_PATTERN = r"^(?:sd_|dr_)?(dev|uat|prod)_"
LAYERS = ["landingzone", "bronze", "silver", "gold", "proj", "selfservice", "lab"]
UNKNOWN_LAYER = "other"

STATUS_RESOLVED = "resolved"
# Partitions of one model table can disagree; the least certain status is the one reported.
STATUS_BY_SEVERITY = ["resolved", "no_table_read", "partially_resolved", "unresolved"]

log.info(f"Destination table: {DEST_SEMANTIC_MODEL_SOURCES}")
log.info(f"Destination table: {DEST_REPORT_INVENTORY}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Common Functions
# MAGIC
# MAGIC A model table's Power Query expression names its Databricks table in one of two ways: navigation steps
# MAGIC (`Source{[Name="prod_gold",Kind="Database"]}`, then the schema, then the table or view), or SQL text passed to
# MAGIC `Value.NativeQuery`. Either is often assembled from model parameters (`#"env" & "_gold"`), so names bound to a
# MAGIC text are substituted and concatenations folded before anything is read.

# COMMAND ----------

# Power Query escapes inside a text literal; "#(cr,lf)" must be replaced before its parts.
M_TEXT_ESCAPES = {"#(cr,lf)": "\n", "#(lf)": "\n", "#(cr)": "\n", "#(tab)": " "}
M_TOKEN_PATTERN = re.compile(
    r'(?P<comment>//[^\n]*|/\*.*?\*/)'
    r'|(?P<text>"(?:[^"]|"")*")'
    r'|(?P<quoted_name>#"(?:[^"]|"")*")'
    r'|(?P<name>[A-Za-z_][A-Za-z0-9_.]*)'
    r'|(?P<space>\s+)'
    r'|(?P<other>.)',
    re.S,
)
# Folding repeats while a pass binds or folds something new; real expressions settle in two or three passes.
M_FOLD_MAX_PASSES = 10
M_PARAMETER_VALUE_PATTERN = re.compile(
    r'^\s*(?:let\s+(?P<step>[A-Za-z_]\w*)\s*=\s*)?"(?P<value>(?:[^"]|"")*)"(?P<rest>[\s\S]*)$'
)
DATABRICKS_CONNECTOR_PATTERN = re.compile(r"\bDatabricks(?:MultiCloud)?\.(?:Catalogs|Query)\s*\(", re.I)
NAVIGATION_STEP_PATTERN = re.compile(
    r'\{\s*\[\s*(?:Name\s*=\s*"(?P<name1>[^"]*)"(?:\s*,\s*Kind\s*=\s*"(?P<kind1>\w+)")?'
    r'|Kind\s*=\s*"(?P<kind2>\w+)"\s*,\s*Name\s*=\s*"(?P<name2>[^"]*)")\s*\]\s*\}',
    re.I,
)
# A navigation step without a Kind is placed by its depth: catalog, then schema, then table.
NAVIGATION_KIND_BY_DEPTH = ["database", "schema", "table"]
CATALOG_OPTION_PATTERN = re.compile(r'\bCatalog\s*=\s*"([^"]+)"', re.I)
SQL_COMMENT_PATTERN = re.compile(r"--[^\n]*|/\*.*?\*/", re.S)
SQL_TABLE_REFERENCE_PATTERN = re.compile(
    r"\b(?:from|join|describe\s+history|describe\s+detail)\s+(?!\()"
    r"((?:`[^`]+`|[A-Za-z0-9_]+)(?:\s*\.\s*(?:`[^`]+`|[A-Za-z0-9_]+)){0,2})",
    re.I,
)
SQL_CTE_NAME_PATTERN = re.compile(r"(?:\bwith|,)\s*([A-Za-z0-9_]+)\s+as\s*\(", re.I)
SQL_DETECTION_PATTERN = re.compile(r"\bselect\b|\bdescribe\s+(?:history|detail)\b", re.I)
# A text that reads like part of a query or of a catalog name (`"SELECT * FROM "`, `"_proj.finance.x"`).
QUERY_FRAGMENT_PATTERN = re.compile(
    r"\b(?:select|from|join|describe)\b|^_?(?:landingzone|bronze|silver|gold|proj|selfservice|lab)\b", re.I
)


def m_text_value(token: str) -> str:
    """Return the content of an M text literal, with doubled quotes and character escapes decoded."""
    value = token[1:-1].replace('""', '"')
    for escape, replacement in M_TEXT_ESCAPES.items():
        value = value.replace(escape, replacement)
    return value


def m_name(token: str) -> str:
    """Return an M identifier without the #"..." quoting."""
    return m_text_value(token[1:]) if token.startswith('#"') else token


def m_parameter_value(expression: str):
    """
    Return the text a model parameter or a one-step query evaluates to (`"prod" meta [...]` or
    `let Source = "prod" in Source`), or None when it is anything else.
    """
    match = M_PARAMETER_VALUE_PATTERN.match(expression or "")
    if not match:
        return None
    rest = match.group("rest").strip()
    if match.group("step"):
        if not re.fullmatch(rf"in\s+{re.escape(match.group('step'))}", rest):
            return None
    elif rest and not rest.startswith("meta"):
        return None
    return m_text_value(f'"{match.group("value")}"')


def fold_m_expression(expression: str, parameters: dict) -> list:
    """
    Return the expression's tokens (comments and whitespace dropped), with every name bound to a text replaced by
    that text and every `text & text` concatenation folded into one text.

    Names are bound by the model parameters and by the expression's own `name = text` steps, so a step aliasing a
    parameter (`selected_env = #"env"`) resolves too. Text literals are never searched for names.
    """
    tokens = [
        (match.lastgroup, match.group())
        for match in M_TOKEN_PATTERN.finditer(expression or "")
        if match.lastgroup not in ("comment", "space")
    ]
    bindings = {name.lower(): value for name, value in parameters.items() if value is not None}

    def as_text(value: str) -> tuple:
        return ("text", '"' + value.replace('"', '""') + '"')

    for _ in range(M_FOLD_MAX_PASSES):
        changed = False

        substituted = []
        for index, (kind, value) in enumerate(tokens):
            if kind in ("name", "quoted_name") and m_name(value).lower() in bindings:
                following = tokens[index + 1][1] if index + 1 < len(tokens) else None
                after_following = tokens[index + 2][1] if index + 2 < len(tokens) else None
                previous = tokens[index - 1][1] if index > 0 else None
                # A name followed by "=" is the step or record field being defined, and one after "[" is a field.
                is_definition = following == "=" and after_following != ">"
                if not is_definition and previous not in ("[", "{"):
                    substituted.append(as_text(bindings[m_name(value).lower()]))
                    changed = True
                    continue
            substituted.append((kind, value))

        folded = []
        for kind, value in substituted:
            if kind == "text" and len(folded) >= 2 and folded[-1][1] == "&" and folded[-2][0] == "text":
                folded.pop()
                folded[-1] = as_text(m_text_value(folded[-1][1]) + m_text_value(value))
                changed = True
            else:
                folded.append((kind, value))
        tokens = folded

        for index in range(len(tokens) - 2):
            kind, value = tokens[index]
            if kind in ("name", "quoted_name") and tokens[index + 1][1] == "=" and tokens[index + 2][0] == "text":
                after = tokens[index + 3][1] if index + 3 < len(tokens) else None
                if after in (None, ",", "in"):
                    name, text_value = m_name(value).lower(), m_text_value(tokens[index + 2][1])
                    if bindings.get(name) != text_value:
                        bindings[name] = text_value
                        changed = True

        if not changed:
            break
    return tokens


def normalize_sql_identifier(identifier: str) -> list:
    """Split a dotted SQL identifier into lower-cased parts, without backticks."""
    return [part.strip().strip("`").lower() for part in identifier.split(".")]


def extract_databricks_sources(expression: str, parameters: dict) -> dict:
    """
    Return the Databricks tables a Power Query expression reads, as
    {"is_databricks": bool, "host": str or None, "status": str, "sources": [(catalog, schema, table, method)]}.

    Navigation steps give catalog, schema and table directly; SQL text (`DESCRIBE HISTORY` included) gives
    `catalog.schema.table`, or `schema.table` completed with the catalog of the navigation step or of the
    connector's `Catalog` option. `status` is `resolved` when a table was found (`partially_resolved` if a query
    fragment stays unbound), `no_table_read` when the only SQL reads no table (a generated calendar,
    `current_user()`), and `unresolved` otherwise — typically a name the model binds nowhere.

    :param expression: Power Query (M) expression of one model table partition.
    :type expression: str
    :param parameters: Model parameter name → text value (None when not a text).
    :type parameters: dict
    :return: The connector host, the status and the tables read.
    :rtype: dict
    """
    if not DATABRICKS_CONNECTOR_PATTERN.search(expression or ""):
        return {"is_databricks": False, "host": None, "status": None, "sources": []}

    tokens = fold_m_expression(expression, parameters)
    folded = " ".join(value for _, value in tokens)

    host = None
    connector = DATABRICKS_CONNECTOR_PATTERN.search(folded)
    first_argument = re.match(r'\s*"((?:[^"]|"")*)"', folded[connector.end():]) if connector else None
    if first_argument:
        host = m_text_value(f'"{first_argument.group(1)}"').lower()

    sources = []
    current = {}
    default_catalog = None
    for step in NAVIGATION_STEP_PATTERN.finditer(folded):
        name = (step.group("name1") if step.group("name1") is not None else step.group("name2")).lower()
        kind = (step.group("kind1") or step.group("kind2") or NAVIGATION_KIND_BY_DEPTH[min(len(current), 2)]).lower()
        if kind == "database":
            current = {"database": name}
            default_catalog = default_catalog or name
        elif kind == "schema" and "database" in current:
            current = {"database": current["database"], "schema": name}
        elif kind in ("table", "view") and "schema" in current:
            sources.append((current["database"], current["schema"], name, "navigation"))
            current = {"database": current["database"], "schema": current["schema"], "table": name}

    catalog_option = CATALOG_OPTION_PATTERN.search(folded)
    default_catalog = default_catalog or (catalog_option.group(1).lower() if catalog_option else None)

    reads_sql_without_table = False
    for kind, value in tokens:
        if kind != "text":
            continue
        query = SQL_COMMENT_PATTERN.sub(" ", m_text_value(value))
        if not SQL_DETECTION_PATTERN.search(query):
            continue
        cte_names = {name.lower() for name in SQL_CTE_NAME_PATTERN.findall(query)}
        references = [normalize_sql_identifier(reference) for reference in SQL_TABLE_REFERENCE_PATTERN.findall(query)]
        references = [parts for parts in references if not (len(parts) == 1 and parts[0] in cte_names)]
        if not references:
            reads_sql_without_table = True
        for parts in references:
            if len(parts) == 3:
                sources.append((parts[0], parts[1], parts[2], "native_query"))
            elif len(parts) == 2 and default_catalog:
                sources.append((default_catalog, parts[0], parts[1], "native_query"))

    # A query fragment still concatenated with a name means part of the query depends on a name the model does
    # not bind; row-level concatenations (`[column] & " "`, `Text.From(...)`) are not query fragments.
    def is_unbound_query_fragment(text_index: int, name_index: int) -> bool:
        if not (0 <= name_index < len(tokens)) or tokens[name_index][0] not in ("name", "quoted_name"):
            return False
        if name_index + 1 < len(tokens) and tokens[name_index + 1][1] == "(":
            return False
        return bool(QUERY_FRAGMENT_PATTERN.search(m_text_value(tokens[text_index][1])))

    has_unbound_query_fragment = any(
        kind == "text"
        and (
            (index + 1 < len(tokens) and tokens[index + 1][1] == "&" and is_unbound_query_fragment(index, index + 2))
            or (index >= 1 and tokens[index - 1][1] == "&" and is_unbound_query_fragment(index, index - 2))
        )
        for index, (kind, _) in enumerate(tokens)
    )

    sources = list(dict.fromkeys(sources))
    if sources:
        status = "partially_resolved" if has_unbound_query_fragment else STATUS_RESOLVED
    elif reads_sql_without_table and not has_unbound_query_fragment:
        status = "no_table_read"
    else:
        status = "unresolved"
    return {"is_databricks": True, "host": host, "status": status, "sources": sources}


PARSED_EXPRESSION_SCHEMA = StructType(
    [
        StructField("status", StringType(), True),
        StructField("host", StringType(), True),
        StructField(
            "sources",
            ArrayType(
                StructType(
                    [
                        StructField("catalog", StringType(), True),
                        StructField("schema", StringType(), True),
                        StructField("table", StringType(), True),
                        StructField("method", StringType(), True),
                    ]
                )
            ),
            True,
        ),
    ]
)


@f.udf(returnType=PARSED_EXPRESSION_SCHEMA)
def parse_m_expression(expression: str, parameter_expressions: dict):
    """Return the Databricks reads of one expression, or null when it does not use the Databricks connector."""
    parameters = {name: m_parameter_value(value) for name, value in (parameter_expressions or {}).items()}
    result = extract_databricks_sources(expression or "", parameters)
    if not result["is_databricks"]:
        return None
    return (
        result["status"],
        result["host"],
        [
            {"catalog": catalog, "schema": schema, "table": table, "method": method}
            for catalog, schema, table, method in result["sources"]
        ],
    )


def chained_when(conditions: list):
    """Return a CASE expression over (condition, value) pairs, null when none holds."""
    expression = None
    for condition, value in conditions:
        expression = f.when(condition, value) if expression is None else expression.when(condition, value)
    return expression


def status_severity_column(status):
    """Return a status's position in STATUS_BY_SEVERITY, so the least certain one can be kept with max()."""
    return chained_when([(status == f.lit(name), f.lit(rank)) for rank, name in enumerate(STATUS_BY_SEVERITY)])


def env_column(catalog):
    """Return the environment a catalog belongs to, or null when it follows no convention."""
    return f.nullif(f.upper(f.regexp_extract(catalog, ENV_FROM_CATALOG_PATTERN, 1)), f.lit(""))


def layer_column(catalog):
    """Return the medallion layer a catalog belongs to."""
    return chained_when([(catalog.endswith(f"_{layer}"), f.lit(layer)) for layer in LAYERS]).otherwise(
        f.lit(UNKNOWN_LAYER)
    )


def workspace_env_column(tags):
    """Return the environment a workspace is tagged with, the most critical first, or null when untagged."""
    return chained_when([(f.array_contains(tags, env.lower()), f.lit(env)) for env in ENVIRONMENTS])


def host_env_column(host):
    """Return the environment of the Databricks workspace a model connects through."""
    return chained_when([(host == f.lit(known_host), f.lit(env)) for known_host, env in DATABRICKS_HOST_ENVS.items()])


# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## LEAP tables

# COMMAND ----------

df_workspaces_raw = spark.table(SRC_WORKSPACES)
df_reports_raw = spark.table(SRC_REPORTS)
df_model_tables_raw = spark.table(SRC_MODEL_TABLES)
df_model_parameters_raw = spark.table(SRC_MODEL_PARAMETERS)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Workspaces

# COMMAND ----------

df_workspaces_prep = df_workspaces_raw.select(
    "workspace_ID",
    "workspace_name",
    f.col("domain").alias("workspace_domain"),
    "workspace_tags",
    workspace_env_column(f.col("workspace_tags")).alias("workspace_env_tag"),
    "workspace_contact_emails",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Semantic models
# MAGIC
# MAGIC A model is listed once per report built on it, with the same name and workspace each time.

# COMMAND ----------

df_semantic_models_prep = (
    df_reports_raw.where(f.col("semantic_model_ID").isNotNull())
    .groupBy("semantic_model_ID")
    .agg(
        f.max("semantic_model_name").alias("semantic_model_name"),
        f.max("semantic_model_workspace_ID").alias("semantic_model_workspace_ID"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Model parameters
# MAGIC
# MAGIC Gathered per model, since any table of the model may refer to any of its parameters.

# COMMAND ----------

df_model_parameters_prep = (
    df_model_parameters_raw.where(f.col("parameter_name").isNotNull())
    .groupBy("semantic_model_ID")
    .agg(
        f.map_from_entries(f.collect_list(f.struct("parameter_name", "m_expression"))).alias("parameter_expressions")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformations - Semantic model sources
# MAGIC
# MAGIC Only expressions using the Databricks connector are kept; Excel, SharePoint and database sources stay in the
# MAGIC Silver data sources table. Partitions of a model table reading the same table give one row.

# COMMAND ----------

df_parsed_expressions = (
    df_model_tables_raw.join(df_model_parameters_prep, "semantic_model_ID", "left")
    .withColumn("parsed", parse_m_expression(f.col("m_expression"), f.col("parameter_expressions")))
    .where(f.col("parsed").isNotNull())
    .select(
        "semantic_model_ID",
        "model_table_name",
        "is_hidden",
        "extraction_timestamp",
        f.col("parsed.status").alias("source_status"),
        f.col("parsed.host").alias("databricks_host"),
        f.explode_outer("parsed.sources").alias("source"),
    )
)

df_semantic_model_sources_prep = (
    df_parsed_expressions.withColumn(
        "source_table_name",
        f.when(
            f.col("source").isNotNull(),
            f.concat_ws(".", f.col("source.catalog"), f.col("source.schema"), f.col("source.table")),
        ),
    )
    .groupBy("semantic_model_ID", "model_table_name", "source_table_name")
    .agg(
        f.max("is_hidden").alias("is_model_table_hidden"),
        f.max("extraction_timestamp").alias("extraction_timestamp"),
        f.max(status_severity_column(f.col("source_status"))).alias("source_status_severity"),
        f.min("databricks_host").alias("databricks_host"),
        f.concat_ws(", ", f.sort_array(f.collect_set("source.method"))).alias("extraction_method"),
        # The three parts are fixed by source_table_name, the grouping key.
        f.max(f.col("source.catalog")).alias("source_catalog"),
        f.max(f.col("source.schema")).alias("source_schema"),
        f.max(f.col("source.table")).alias("source_table"),
    )
    .withColumn(
        "source_status",
        f.element_at(f.array(*[f.lit(name) for name in STATUS_BY_SEVERITY]), f.col("source_status_severity") + 1),
    )
    .drop("source_status_severity")
)

# COMMAND ----------

# MAGIC %md
# MAGIC A read is non-production when the table is not a production one, or when the model connects through a
# MAGIC non-production workspace: either breaks the report when that environment is refreshed or rebuilt.

# COMMAND ----------

log.info("LEFT JOIN semantic models and workspaces: a model missing from the reports list has no name or workspace.")

df_semantic_model_sources_end = (
    df_semantic_model_sources_prep.join(df_semantic_models_prep, "semantic_model_ID", "left")
    .join(
        df_workspaces_prep,
        f.col("semantic_model_workspace_ID") == f.col("workspace_ID"),
        "left",
    )
    .withColumn("source_env", env_column(f.col("source_catalog")))
    .withColumn("source_layer", f.when(f.col("source_catalog").isNotNull(), layer_column(f.col("source_catalog"))))
    .withColumn("databricks_host_env", host_env_column(f.col("databricks_host")))
    .withColumn(
        "is_reading_non_prod",
        f.col("source_table_name").isNotNull()
        & (
            (f.coalesce(f.col("source_env"), f.lit("")) != f.lit(PROD_ENVIRONMENT))
            | (f.coalesce(f.col("databricks_host_env"), f.lit("")) != f.lit(PROD_ENVIRONMENT))
        ),
    )
    .withColumn(
        "is_prod_workspace_reading_non_prod",
        (f.coalesce(f.col("workspace_env_tag"), f.lit("")) == f.lit(PROD_ENVIRONMENT)) & f.col("is_reading_non_prod"),
    )
    .withColumn(
        "pbi_semantic_model_sources_ID",
        f.concat_ws(
            "-",
            f.col("semantic_model_ID"),
            f.col("model_table_name"),
            f.coalesce(f.col("source_table_name"), f.col("source_status")),
        ),
    )
    .select(
        "pbi_semantic_model_sources_ID",
        "semantic_model_ID",
        "semantic_model_name",
        "workspace_ID",
        "workspace_name",
        "workspace_env_tag",
        "model_table_name",
        "is_model_table_hidden",
        "source_status",
        "source_table_name",
        "source_catalog",
        "source_schema",
        "source_table",
        "source_layer",
        "source_env",
        "extraction_method",
        "databricks_host",
        "databricks_host_env",
        "is_reading_non_prod",
        "is_prod_workspace_reading_non_prod",
        "extraction_timestamp",
    )
)

if DEBUG:
    df_semantic_model_sources_end.limit(5).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformations - Report inventory
# MAGIC
# MAGIC The report's own workspace decides whether it is a production report: a report is often published apart from
# MAGIC its model.

# COMMAND ----------

df_report_reads = df_semantic_model_sources_end.groupBy("semantic_model_ID").agg(
    f.max(f.col("is_reading_non_prod")).alias("is_reading_non_prod"),
    f.sort_array(f.collect_set("source_env")).alias("databricks_source_envs"),
    f.sort_array(f.collect_set("databricks_host_env")).alias("databricks_host_envs"),
    f.countDistinct("source_table_name").alias("databricks_table_count"),
    f.sum(f.when(f.col("source_status") != f.lit(STATUS_RESOLVED), 1).otherwise(0)).alias(
        "unresolved_model_table_count"
    ),
)

log.info("LEFT JOIN reports and workspaces / model reads: a report on a non-Databricks model has no reads.")

df_report_inventory_end = (
    df_reports_raw.join(df_workspaces_prep, "workspace_ID", "left")
    .join(df_report_reads, "semantic_model_ID", "left")
    .withColumn("is_reading_databricks", f.col("databricks_table_count") > f.lit(0))
    .withColumn(
        "is_prod_workspace_reading_non_prod",
        (f.col("workspace_env_tag") == f.lit(PROD_ENVIRONMENT)) & f.col("is_reading_non_prod"),
    )
    .select(
        "report_ID",
        "report_name",
        "report_type",
        "report_description",
        "report_url",
        "report_modified_by",
        "report_tags",
        "report_contact_emails",
        "workspace_ID",
        "workspace_name",
        "workspace_domain",
        "workspace_tags",
        "workspace_env_tag",
        "workspace_contact_emails",
        "semantic_model_ID",
        "semantic_model_name",
        "semantic_model_workspace_ID",
        "semantic_model_note",
        f.coalesce(f.col("is_reading_databricks"), f.lit(False)).alias("is_reading_databricks"),
        "databricks_source_envs",
        "databricks_host_envs",
        f.coalesce(f.col("databricks_table_count"), f.lit(0)).alias("databricks_table_count"),
        f.coalesce(f.col("unresolved_model_table_count"), f.lit(0)).alias("unresolved_model_table_count"),
        f.coalesce(f.col("is_prod_workspace_reading_non_prod"), f.lit(False)).alias(
            "is_prod_workspace_reading_non_prod"
        ),
        "extraction_timestamp",
    )
)

if DEBUG:
    df_report_inventory_end.limit(5).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks
# MAGIC
# MAGIC RED: keys unique and present. AMBER: model and report workspaces found, and the share of Databricks model tables
# MAGIC read to a table stays high — a drop means the expressions changed shape and the parser needs a look.

# COMMAND ----------

dfgx_semantic_model_sources = gx.dataset.SparkDFDataset(df_semantic_model_sources_end, persist=False)
dfgx_report_inventory = gx.dataset.SparkDFDataset(df_report_inventory_end, persist=False)

red_results = [
    dfgx_semantic_model_sources.expect_column_values_to_be_unique(column="pbi_semantic_model_sources_ID"),
    dfgx_semantic_model_sources.expect_column_values_to_not_be_null(column="pbi_semantic_model_sources_ID"),
    dfgx_report_inventory.expect_column_values_to_be_unique(column="report_ID"),
    dfgx_report_inventory.expect_column_values_to_not_be_null(column="report_ID"),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="Power BI inventory Gold: every key is unique and present.",
    error_message="Power BI inventory Gold: a key is repeated or missing — partitions or reports were not collapsed.",
)

amber_results = [
    dfgx_semantic_model_sources.expect_column_values_to_not_be_null(column="workspace_name", mostly=0.99),
    dfgx_report_inventory.expect_column_values_to_not_be_null(column="workspace_name", mostly=0.99),
    dfgx_semantic_model_sources.expect_column_values_to_be_in_set(
        column="source_status", value_set=[STATUS_RESOLVED], mostly=0.95
    ),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=amber_results,
    validation_level="AMBER",
    info_message="Power BI inventory Gold: workspaces found and model tables read to a table.",
    error_message="Power BI inventory Gold: workspaces missing, or fewer model tables read to a table than usual.",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

save_table(
    dest_table=DEST_SEMANTIC_MODEL_SOURCES,
    df=df_semantic_model_sources_end,
    mode="overwrite",
    overwrite_schema=True,
)
log.info(f"Saved: {DEST_SEMANTIC_MODEL_SOURCES}")

# COMMAND ----------

save_table(
    dest_table=DEST_REPORT_INVENTORY,
    df=df_report_inventory_end,
    mode="overwrite",
    overwrite_schema=True,
)
log.info(f"Saved: {DEST_REPORT_INVENTORY}")
