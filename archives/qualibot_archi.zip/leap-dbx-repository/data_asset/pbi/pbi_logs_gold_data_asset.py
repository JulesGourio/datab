# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # PBI LOGS DATA ASSET GOLD
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to build PowerBI logs data assets
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - PowerBI logs ingestion.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver.pbi.pbi_users_history
# MAGIC - {pipeline_read_env}_silver.pbi.pbi_activity_events_history
# MAGIC
# MAGIC **Input Files Pipeline**
# MAGIC - N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - N/A
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.pbi.pbi_users_history
# MAGIC - {pipeline_write_env}_gold.pbi.pbi_activity_events_history
# MAGIC
# MAGIC **Output Files Pipeline**
# MAGIC N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. N/A
# MAGIC     2. N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import logging
import time
from pyspark.sql.utils import AnalysisException
from pyspark.sql import DataFrame as SparkDataFrame
from great_expectations.dataset import SparkDFDataset
from typing import List, Dict
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger
from leap_utils.common.validation import quality_checks, gx_validation

# COMMAND ----------

## functions used from "leap_utils.data_asset.table_utils"
#### create_unity_catalog_table()
#### set_table_column_not_null()
#### add_table_primary_key()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("bypass_quality_checks", "false")  # history/update
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC

# COMMAND ----------

spark.conf.set("spark.sql.ansi.enabled", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration
# MAGIC
# MAGIC Details on how to read the manual files 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location
# MAGIC
# MAGIC Definition of folder Input data is housed in

# COMMAND ----------

# Global variables
BUCKET_NAME = f"leap-s3-raw-weeu1-{REFERENCE_READ_ENV}"
PREFIX = "manual/manual_upload/PBI/"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Files Config
# MAGIC
# MAGIC Definition of files to ingest
# MAGIC

# COMMAND ----------

T_WORKSPACE_CLASSIFICATION = (
    f"s3://{BUCKET_NAME}/{PREFIX}PowerBI_WorkSpaceName_Classification.csv"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Tables Location
# MAGIC
# MAGIC Details on how to read the input tables

# COMMAND ----------

SILVER_SCHEMA = f"{PIPELINE_READ_ENV}_silver.pbi"

T_USERS_HISTORY = f"{SILVER_SCHEMA}.pbi_users_history"
T_EVENTS_HISTORY = f"{SILVER_SCHEMA}.pbi_activity_events_history"

T_EMAIL_WORKPLACE = (
    f"{PIPELINE_READ_ENV}_proj.hr.hr_workforce_proj_email_to_workplace"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Folder location
# MAGIC

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables location
# MAGIC
# MAGIC Definition of catalog and schema for delta tables

# COMMAND ----------

GOLD_SCHEMA = f"{PIPELINE_WRITE_ENV}_gold.pbi"

TABLE_USER_DEST = f"{GOLD_SCHEMA}.pbi_users_history"
TABLE_USER_DEST_PK = "pbi_users_history_PK"

TABLE_USER_EVAL_DEST = f"{GOLD_SCHEMA}.pbi_users_unlicensed"

TABLE_EVENTS_DEST = f"{GOLD_SCHEMA}.pbi_activity_events_history"
TABLE_EVENTS_DEST_PK = "pbi_activity_events_history_PK"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Tables settings
# MAGIC
# MAGIC Definition of constraints

# COMMAND ----------

# Columns needed to create the empty table at first run
TABLE_USER_FIRST_COLS = {
    "stack_row_id": "BIGINT",
    "extraction_timestamp": "TIMESTAMP",
    "ingestion_timestamp": "TIMESTAMP",
    "file_name": "STRING",
    "file_mode": "STRING",
    "CompanyName": "STRING",
    "Department": "STRING",
    "DisplayName": "STRING",
    "Mail": "STRING",
    "UserPrincipalName": "STRING",
}

# cluster table by these columns, rather than partitioning
TABLE_USER_CLUSTER_COLS = "UserPrincipalName"

# As a best practice, we'll define a Primary Key on the output table, below are the PK columns
TABLE_USER_PK_COLS = "CompanyName, Department, DisplayName, UserPrincipalName"

# COMMAND ----------

# Columns needed to create the empty table at first run
TABLE_EVENTS_FIRST_COLS = {
    "stack_row_id": "BIGINT",
    "extraction_timestamp": "TIMESTAMP",
    "ingestion_timestamp": "TIMESTAMP",
    "file_name": "STRING",
    "file_mode": "STRING",
    "Id": "STRING",
    "UserId": "STRING",
    "UserKey": "STRING",
    "CreationTime": "TIMESTAMP",
}

# cluster table by these columns, rather than partitioning
TABLE_EVENTS_CLUSTER_COLS = "UserId, UserKey, CreationTime"

# As a best practice, we'll define a Primary Key on the output table, below are the PK columns
TABLE_EVENTS_PK_COLS = "Id"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Global Variables

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Inputs 
# MAGIC
# MAGIC At this step we may want to print all variables
# MAGIC

# COMMAND ----------

log.debug(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.debug(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.debug(f"SILVER_SCHEMA is:  {SILVER_SCHEMA}")
log.debug(f"GOLD_SCHEMA is:  {GOLD_SCHEMA}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality checks - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs Processing
# MAGIC - Read tables

# COMMAND ----------

# Upload T_USERS_HISTORY
df_users_history = spark.read.table(f"{T_USERS_HISTORY}")

# Upload T_EVENTS_HISTORY
df_events_history = spark.read.table(f"{T_EVENTS_HISTORY}")

# Upload
df_workspace_classification = spark.read.csv(
    f"{T_WORKSPACE_CLASSIFICATION}", header=True, inferSchema=True, sep=";"
)

df_email_workplace = spark.read.table(f"{T_EMAIL_WORKPLACE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

metadata_cols = [
    "stack_row_id",
    "extraction_timestamp",
    "ingestion_timestamp",
    "file_name",
]

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - 

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Join Users with Events on UserKey
# MAGIC
# MAGIC Enrichir la table des Users avec lastEvent et oldestEvent

# COMMAND ----------

df_join_temp = df_users_history.join(
    df_events_history,
    on="UserKey",
    how="left",
)

df_join_temp_agg = (
    df_join_temp.groupBy("UserKey")
    .agg(
        f.max("CreationTime").alias("lastEvent"),
        f.min("CreationTime").alias("oldestEvent"),
    )
    .withColumnRenamed("UserKey", "UserKey_1")
)

df_users_last_oldest_event = df_users_history.join(
    df_join_temp_agg,
    on=(df_users_history.UserKey == df_join_temp_agg.UserKey_1),
    how="left",
).drop("UserKey_1")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Adjust creation_date when (creation_date == stack_initial_date) & (creation_date > oldestEvent)
# MAGIC
# MAGIC Quand la creation_date est égale à stack_initial_date mais postérieure au oldestEvent mettre creation_date = oldestEvent

# COMMAND ----------

condition = (f.col("creation_date") == f.col("stack_initial_date")) & (
    f.col("creation_date") > f.col("oldestEvent")
)

df_users_creation_date_adjusted = df_users_last_oldest_event.withColumn(
    "creation_date",
    f.when(condition, f.to_date(f.col("oldestEvent"))).otherwise(
        f.col("creation_date")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Events leftanti Join Users to find unlicensed users
# MAGIC
# MAGIC Trouver les users non licenciés qui ont généré des évènements

# COMMAND ----------

# Find Unlicensed users with min and max event CreationTime
df_events_agg = (
    df_events_history.groupBy("UserKey")
    .agg(
        f.max("CreationTime").alias("lastEvent"),
        f.min("CreationTime").alias("oldestEvent"),
    )
    .withColumnRenamed("UserKey", "UserKey_1")
)

# For each UserKey take the 1st occurence in the event history
window = Window.partitionBy("UserKey").orderBy(f.col("extraction_timestamp").asc())
df_events_last = (
    df_events_history.select(*metadata_cols, "UserId", "UserKey", "CreationTime")
    .join(
        df_events_agg,
        on=(df_events_history.UserKey == df_events_agg.UserKey_1)
        & (df_events_history.CreationTime == df_events_agg.lastEvent),
        how="inner",
    )
    .withColumn("row", f.row_number().over(window))
    .filter(f.col("row") == 1)
    .drop("UserKey_1", "CreationTime", "row")
)

# Left anti join with users table to keep only those unlicensed
df_users_eval = df_events_last.join(
    df_users_history.filter(f.col("has_valid_license") == True).withColumnRenamed(
        "UserKey", "UserKey_1"
    ),
    on=(df_events_last.UserKey == f.col("UserKey_1")),
    how="leftanti",
).withColumnRenamed("UserId", "UserPrincipalName")

# Keep only UserKey for lastEvent for a same UserPrincipalName
window = Window.partitionBy("UserPrincipalName").orderBy(f.col("lastEvent").desc())
df_users_eval = df_users_eval.withColumn("row", f.row_number().over(window)).filter(f.col("row") == 1).drop("row")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Add YearWeek and Day to Events table
# MAGIC
# MAGIC Ajouter année/semaine et jour de l'évènement et année/semaine et jour courant pour utiliser dans la visualisation

# COMMAND ----------

df_events_history_enriched_week_year = (
    df_events_history.withColumn("CreationDate", f.to_date(f.col("CreationTime")))
    .withColumn("CurrentDate", f.current_date())
    .withColumn("CreationWeek", f.weekofyear("CreationDate"))
    .withColumn("CurrentWeek", f.weekofyear("CurrentDate"))
    .withColumn("CreationMonth", f.month("CreationDate"))
    .withColumn("CurrentMonth", f.month("CurrentDate"))
    # Example : 2023-01-01 is in week 52 of year 2022 so need to substract 1 from year
    .withColumn(
        "CreationYear",
        f.when(
            (f.col("CreationWeek").isin(52, 53)) & (f.col("CreationMonth") == 1),
            f.year("CreationDate") - 1,
        ).otherwise(f.year("CreationDate")),
    )
    .withColumn(
        "CreationYear",
        f.when(
            (f.col("CreationWeek").isin(1)) & (f.col("CreationMonth") == 12),
            f.year("CreationDate") + 1,
        ).otherwise(f.year("CreationDate")),
    )
    .withColumn(
        "CurrentYear",
        f.when(
            (f.col("CurrentWeek").isin(52, 53)) & (f.col("CurrentMonth") == 1),
            f.year("CurrentDate") - 1,
        ).otherwise(f.year("CurrentDate")),
    )
    .withColumn(
        "EventWeek",
        f.col("CreationYear") * 100 + f.col("CreationWeek"),
    )
    .withColumn(
        "DataAssetWeek",
        f.col("CurrentYear") * 100 + f.col("CurrentWeek"),
    )

    .withColumn(
        "EventDay",
        f.date_format("CreationDate", "yyyyMMdd").cast("int"),
    )
    
    .withColumn(
        "DataAssetDay",
        f.date_format("CurrentDate", "yyyyMMdd").cast("int"),
    )
    .drop(
        "CreationWeek",
        "CreationMonth",
        "CreationYear",
        "CurrentWeek",
        "CurrentMonth",
        "CurrentYear",
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 5 - Add WorkSpaceCategory to Events table
# MAGIC
# MAGIC Ajouter une classification du WorkSpaceName grâce au fichier CSV précédemment chargé dans df_workspace_classification

# COMMAND ----------

# Créer une liste de toutes les expressions régulières et leurs catégories correspondantes à partir de df_workspace_classification
df_workspace_classification_regex = df_workspace_classification.filter(
    df_workspace_classification.TYPE == "REGEX"
)
regex_list = [row.INPUT for row in df_workspace_classification_regex.collect()]
output_list = [row.OUTPUT for row in df_workspace_classification_regex.collect()]

# Ajouter une nouvelle colonne WorkSpaceCategory à df_events_history en utilisant les expressions régulières
df_events_history_enriched_wks_cat = df_events_history_enriched_week_year.withColumn(
    "WorkSpaceCategory", f.lit(None)
)
for regex, output in zip(regex_list, output_list):
    df_events_history_enriched_wks_cat = df_events_history_enriched_wks_cat.withColumn(
        "WorkSpaceCategory",
        f.when(
            (df_events_history_enriched_wks_cat.WorkSpaceCategory.isNull())
            & (
                f.regexp_extract(
                    df_events_history_enriched_wks_cat.WorkSpaceName, regex, 0
                )
                != ""
            ),
            f.lit(output),
        ).otherwise(df_events_history_enriched_wks_cat.WorkSpaceCategory),
    )

# Remplir les valeurs manquantes de WorkSpaceCategory avec "Unknown"
df_events_history_enriched_wks_cat = df_events_history_enriched_wks_cat.fillna(
    {"WorkSpaceCategory": "Unknown"}
)

# Mettre à jour la colonne WorkSpaceCategory en utilisant les noms de workspace
df_workspace_classification_name = df_workspace_classification.filter(
    df_workspace_classification.TYPE == "NAME"
)

df_events_history_enriched_wks_cat = df_events_history_enriched_wks_cat.join(
    df_workspace_classification_name,
    df_events_history_enriched_wks_cat.WorkSpaceName
    == df_workspace_classification_name.INPUT,
    how="left",
)
df_events_history_enriched_wks_cat = df_events_history_enriched_wks_cat.withColumn(
    "WorkSpaceCategory",
    f.coalesce(
        df_events_history_enriched_wks_cat.OUTPUT,
        df_events_history_enriched_wks_cat.WorkSpaceCategory,
    ),
)
df_events_history_enriched_wks_cat = df_events_history_enriched_wks_cat.drop(
    "TYPE", "INPUT", "OUTPUT"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 6 - Add country and workplace to Events table
# MAGIC
# MAGIC Ajouter une information de localisation pour chaque email
# MAGIC Enlever les doublons d'Id

# COMMAND ----------

# Ajouter un window pour garder uniquement la dernière version de chaque Id
window_id = Window.partitionBy("Id").orderBy(f.col("extraction_timestamp").desc())

# Enrichir les données d'évènements avec les informations d'utilisateurs, en prenant une marge de 7 jours par rapport à la date de validité des utilisateurs
df_events_history_enriched_wks_cat_email = (
    df_events_history_enriched_wks_cat.withColumn(
        "row_num", f.row_number().over(window_id)
    )
    .filter(f.col("row_num") == 1)
    .drop("row_num")
    .join(
        df_email_workplace,
        (df_events_history_enriched_wks_cat.UserId == df_email_workplace.email)
        & (
            df_events_history_enriched_wks_cat.CreationDate
            <= f.date_add(df_email_workplace.date_end, 7)
        ),
        how="left",
    )
    .withColumn(
        "is_central",
        f.when(f.col("workplace") == "Toulouse-Mach1", f.lit(True)).otherwise(
            f.lit(False)
        ),
    )
    .withColumn(
        "country",
        f.when(f.col("country").isNull(), f.lit("Unknown")).otherwise(f.col("country")),
    )
    .withColumn(
        "workplace",
        f.when(f.col("workplace").isNull(), f.lit("Unknown")).otherwise(
            f.col("workplace")
        ),
    )
    .drop("date_end", "email")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 7 - Add Report URL
# MAGIC
# MAGIC Adds a ReportUrl column by concatenating the Power BI base URL with “WorkspaceId” and “ReportId”

# COMMAND ----------

df_events_history_enriched_report_url = df_events_history_enriched_wks_cat_email.withColumn(
    "ReportUrl",
    f.concat(
        f.lit("https://app.powerbi.com/groups/"),
        f.col("WorkspaceId").cast("string"),
        f.lit("/reports/"),
        f.col("ReportId").cast("string"),
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display DEBUG values
# MAGIC

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    display(df_users_eval)
    display(df_users_creation_date_adjusted)
    display(df_events_history_enriched_wks_cat_email)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Final Dataframes - before quality checks and outputs
# MAGIC

# COMMAND ----------

df_users_history_gold = df_users_creation_date_adjusted
df_events_history_gold = df_events_history_enriched_report_url
df_users_evaluation_gold = df_users_eval

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks - Common Functions

# COMMAND ----------

## Quality Checks - Common Functions defined in leap_utils

#### validate_and_log_gx_results()

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Quality Checks 1 - Uniqueness
# MAGIC
# MAGIC N/A

# COMMAND ----------

df_to_check = df_users_history_gold
df_to_check = df_to_check.filter(f.col("has_valid_license") == True)
col = "UserPrincipalName"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=True)

quality_check_results = [
    df_gx.expect_column_values_to_be_unique(column=col),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col}(s) are unique",
    error_message=f"{col}(s) are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="pbi_users_history_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
df_to_check = df_users_history_gold
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=True)

# Define the red quality checks
table_dest_pk_cols_list = TABLE_USER_PK_COLS.replace(" ", "").split(",")
quality_check_results = [
    df_gx.expect_compound_columns_to_be_unique(column_list=table_dest_pk_cols_list)
]

# Validate all red quality checks, if at least one fails the job stops
gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"Compound cols {TABLE_USER_PK_COLS} are unique",
    error_message=f"Compound cols {TABLE_USER_PK_COLS} are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="pbi_users_history_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

df_to_check = df_users_eval
col = "UserPrincipalName"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=True)

quality_check_results = [
    df_gx.expect_column_values_to_be_unique(column=col)
]

# Validate all red quality checks, if at least one fails the job stops
gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col}(s) are unique",
    error_message=f"{col}(s) are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="pbi_evaluation_users_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

df_to_check = df_events_history_gold
col = "Id"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=True)

quality_check_results = [
    df_gx.expect_column_values_to_be_unique(column=col)
]

# Validate all red quality checks, if at least one fails the job stops
gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col}(s) are unique",
    error_message=f"{col}(s) are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="pbi_events_history_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Gold tables Processing
# MAGIC - Write gold tables
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Users
# MAGIC

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by TABLE_USER_CLUSTER_COLS
catalog, schema, table = TABLE_USER_DEST.split(".")

try:
    table_utils.create_unity_catalog_table(
        catalog,
        schema,
        table,
        force_reinitialization=False,
        cluster_cols=TABLE_USER_CLUSTER_COLS,
        partition_col=None,
        primary_key_cols=None,
        columns=TABLE_USER_FIRST_COLS,
        force_drop=False,
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_USER_DEST} has not been created, an error occured during creation. \nError is {e}"
    )
    raise Exception()

# COMMAND ----------

# Save the table from Dataframe df_users_history_gold, preserving cluster columns
table_user_cluster_cols_cleaned = TABLE_USER_CLUSTER_COLS.replace(" ", "")
try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=TABLE_USER_DEST,
        df=df_users_history_gold,
        mode="overwrite",
        overwrite_schema=True,
        merge_schema=True,
        cluster_cols=table_user_cluster_cols_cleaned,
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_USER_DEST} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {TABLE_USER_DEST} saved in {duration} seconds.")
    log.info(f"Wrote {df_users_history_gold.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Users Unlicensed
# MAGIC

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by TABLE_USER_CLUSTER_COLS
catalog, schema, table = TABLE_USER_EVAL_DEST.split(".")

try:
    table_utils.create_unity_catalog_table(
        catalog,
        schema,
        table,
        force_reinitialization=False,
        cluster_cols=None,
        partition_col=None,
        primary_key_cols=None,
        columns=TABLE_USER_FIRST_COLS,
        force_drop=False,
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_USER_EVAL_DEST} has not been created, an error occured during creation. \nError is {e}"
    )
    raise Exception()

# COMMAND ----------

# Save the table from Dataframe df_users_evaluation_gold
try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=TABLE_USER_EVAL_DEST,
        df=df_users_evaluation_gold,
        mode="overwrite",
        overwrite_schema=True,
        merge_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_USER_EVAL_DEST} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {TABLE_USER_EVAL_DEST} saved in {duration} seconds.")
    log.info(f"Wrote {df_users_evaluation_gold.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Events
# MAGIC

# COMMAND ----------

# Create the empty clustered table if not exists, clustered by TABLE_EVENTS_CLUSTER_COLS
catalog, schema, table = TABLE_EVENTS_DEST.split(".")

try:
    table_utils.create_unity_catalog_table(
        catalog,
        schema,
        table,
        force_reinitialization=False,
        cluster_cols=TABLE_EVENTS_CLUSTER_COLS,
        partition_col=None,
        primary_key_cols=None,
        columns=TABLE_EVENTS_FIRST_COLS,
        force_drop=False,
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_EVENTS_DEST} has not been created, an error occured during creation. \nError is {e}"
    )
    raise Exception()

# COMMAND ----------

# Save the table from Dataframe df_events_history_gold, preserving cluster columns
table_events_cluster_cols_cleaned = TABLE_EVENTS_CLUSTER_COLS.replace(" ", "")
try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=TABLE_EVENTS_DEST,
        df=df_events_history_gold,
        mode="overwrite",
        overwrite_schema=True,
        merge_schema=True,
        cluster_cols=table_events_cluster_cols_cleaned,
    )
except AnalysisException as e:
    log.error(
        f"Table {TABLE_EVENTS_DEST} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {TABLE_EVENTS_DEST} saved in {duration} seconds.")
    log.info(f"Wrote {df_events_history_gold.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Constraints

# COMMAND ----------

# MAGIC %md
# MAGIC #### Users
# MAGIC

# COMMAND ----------

# Add Primary Key if not exists
catalog, schema, table = TABLE_USER_DEST.split(".")
pk_name = TABLE_USER_DEST_PK.lower()
nb_cons = spark.sql(
    f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_USER_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=TABLE_USER_DEST, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=TABLE_USER_DEST,
        pk_name=TABLE_USER_DEST_PK,
        columns=TABLE_USER_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC #### Events
# MAGIC

# COMMAND ----------

# Add Primary Key if not exists
catalog, schema, table = TABLE_EVENTS_DEST.split(".")
pk_name = TABLE_EVENTS_DEST_PK.lower()
nb_cons = spark.sql(
    f"select count(*) from system.information_schema.table_constraints where table_catalog='{catalog}' and table_schema='{schema}' and table_name='{table}' and constraint_name='{pk_name}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_EVENTS_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=TABLE_EVENTS_DEST, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=TABLE_EVENTS_DEST,
        pk_name=TABLE_EVENTS_DEST_PK,
        columns=TABLE_EVENTS_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Set up governed tags and comments on assets
# MAGIC
# MAGIC - IT
# MAGIC - domain
# MAGIC - refresh_frequency
# MAGIC - system.certification_status
# MAGIC - class.email_address
# MAGIC - class.ip_address

# COMMAND ----------

# set governed tags
spark.sql(f"ALTER TABLE {TABLE_USER_DEST} ALTER COLUMN CompanyName SET TAGS ('primary_key');")
spark.sql(f"ALTER TABLE {TABLE_USER_DEST} ALTER COLUMN Department SET TAGS ('primary_key');")
spark.sql(f"ALTER TABLE {TABLE_USER_DEST} ALTER COLUMN DisplayName SET TAGS ('primary_key','class.name');")
spark.sql(f"ALTER TABLE {TABLE_USER_DEST} ALTER COLUMN UserPrincipalName SET TAGS ('primary_key','class.email_address');")
spark.sql(f"ALTER TABLE {TABLE_USER_DEST} ALTER COLUMN Mail SET TAGS ('class.email_address');")
spark.sql(f"ALTER TABLE {TABLE_USER_DEST} SET TAGS ('IT');")
spark.sql(f"ALTER TABLE {TABLE_USER_DEST} SET TAGS ('domain' = 'IT');")
spark.sql(f"ALTER TABLE {TABLE_USER_DEST} SET TAGS ('refresh_frequency' = 'daily');")
spark.sql(f"ALTER TABLE {TABLE_USER_DEST} SET TAGS ('system.certification_status' = 'certified');")
spark.sql(f"ALTER TABLE {TABLE_USER_DEST} SET TAGS ('primary_key_columns' = 'CompanyName,Department,DisplayName,UserPrincipalName');")

# set comments
spark.sql(f"""COMMENT ON TABLE {TABLE_USER_DEST} IS
'PBI usage users history gold.';""")

# COMMAND ----------

# set governed tags
spark.sql(f"ALTER TABLE {TABLE_USER_EVAL_DEST} ALTER COLUMN UserPrincipalName SET TAGS ('primary_key','class.email_address');")
spark.sql(f"ALTER TABLE {TABLE_USER_EVAL_DEST} SET TAGS ('IT');")
spark.sql(f"ALTER TABLE {TABLE_USER_EVAL_DEST} SET TAGS ('domain' = 'IT');")
spark.sql(f"ALTER TABLE {TABLE_USER_EVAL_DEST} SET TAGS ('refresh_frequency' = 'daily');")
spark.sql(f"ALTER TABLE {TABLE_USER_EVAL_DEST} SET TAGS ('system.certification_status' = 'certified');")
spark.sql(f"ALTER TABLE {TABLE_USER_EVAL_DEST} SET TAGS ('primary_key_columns' = 'UserPrincipalName');")

# set comments
spark.sql(f"""COMMENT ON TABLE {TABLE_USER_EVAL_DEST} IS
'PBI usage evaluation users list gold.';""")

# COMMAND ----------

# set governed tags
spark.sql(f"ALTER TABLE {TABLE_EVENTS_DEST} ALTER COLUMN Id SET TAGS ('primary_key');")
spark.sql(f"ALTER TABLE {TABLE_EVENTS_DEST} ALTER COLUMN UserId SET TAGS ('class.email_address');")
spark.sql(f"ALTER TABLE {TABLE_EVENTS_DEST} ALTER COLUMN ClientIP SET TAGS ('class.ip_address');")
spark.sql(f"ALTER TABLE {TABLE_EVENTS_DEST} SET TAGS ('IT');")
spark.sql(f"ALTER TABLE {TABLE_EVENTS_DEST} SET TAGS ('domain' = 'IT');")
spark.sql(f"ALTER TABLE {TABLE_EVENTS_DEST} SET TAGS ('refresh_frequency' = 'daily');")
spark.sql(f"ALTER TABLE {TABLE_EVENTS_DEST} SET TAGS ('system.certification_status' = 'certified');")
spark.sql(f"ALTER TABLE {TABLE_EVENTS_DEST} SET TAGS ('primary_key_columns' = 'Id');")

# set comments
spark.sql(f"""COMMENT ON TABLE {TABLE_EVENTS_DEST} IS
'PBI usage event history gold.';""")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# No output file is produced