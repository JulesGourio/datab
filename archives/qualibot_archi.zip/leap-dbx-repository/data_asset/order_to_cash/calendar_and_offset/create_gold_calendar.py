# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Calendar for purchase_order
# MAGIC
# MAGIC **Description:**  
# MAGIC This notebook aims to generate the data asset of offset and calendar.
# MAGIC - calendar data indicates whether the client is working and is able to receive the product manufactured
# MAGIC
# MAGIC **Input Tables (Pipeline)**
# MAGIC - {pipeline_read_env}_silver.order_to_cash.calendar
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.order_to_cash.calendar"
# MAGIC
# MAGIC NB: ("material_number", "calendar_date") is the primary key (composite) of the output data asset `calendar`
# MAGIC
# MAGIC **Job Pipeline**
# MAGIC - gold-calendar-and-offset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pandas as pd

from datetime import datetime, timedelta, date
from pyspark.sql import functions as f
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ### Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_read_env", "dev")
pipeline_read_env = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
reference_read_env = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
pipeline_write_env = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("DATE_FILTERING_DELIVERIES", "2020-1-1")
DATE_FILTERING_DELIVERIES = dbutils.widgets.get("DATE_FILTERING_DELIVERIES")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# Import material_master table
df_silver_calendar = spark.read.table(
    f"{pipeline_read_env}_silver.order_to_cash.calendar"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation: Complete `calendar_date` by inclunding week-end as non-working days

# COMMAND ----------

# if day is sunday/saturday = 0
calendar_spark_df = df_silver_calendar.withColumn(
    "is_working_day_filled",
    f.when(
        (f.weekday("calendar_date") == 5) | (f.weekday("calendar_date") == 6), f.lit(0)
    ).otherwise(f.col("is_working_day_filled")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create next_calendar-date for `calendar_spark_df_with_calendar`

# COMMAND ----------

# Only keep the lines related to a WORKING DAY
df_calendar_working_days = (
    calendar_spark_df.filter(f.col("is_working_day_filled") == 1)
    .select(f.col("calendar_date").alias("next_calendar_date"), "material_number")
    .alias("working_day_calendar")
)

# At this step, for each material_number, we get a combination of any possible couples of (date and working_day)
df_calendar_all_couples = (
    calendar_spark_df.alias("all_calendar")
    .join(
        other=df_calendar_working_days,
        on=(
            (
                f.col("all_calendar.calendar_date")
                <= df_calendar_working_days.next_calendar_date
            )
            & (
                f.col("all_calendar.material_number")
                == df_calendar_working_days.material_number
            )
        ),
        how="left",
    )
    .drop(f.col("working_day_calendar.material_number"))
)

# take off couples with same dates and get the first element of remaining lines per material_number & calendar_date
df_calendar_all_couples_minus_same_date = table_utils.drop_duplicates_by_order(
    df=df_calendar_all_couples,
    columns=["all_calendar.material_number", "calendar_date"],
    order_col="next_calendar_date",
    keep="first",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Calendar

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{pipeline_write_env}_gold.order_to_cash.calendar",
    df=df_calendar_all_couples_minus_same_date,
    mode="overwrite",
)
