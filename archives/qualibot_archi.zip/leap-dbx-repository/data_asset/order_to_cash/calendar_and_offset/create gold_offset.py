# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Offset for purchase_order
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC This notebook aims to generate the data asset of offset.
# MAGIC - offset time corresponds to the time to send a product from a Latecoere plant to one's purchaser
# MAGIC
# MAGIC
# MAGIC **Input Tables (Pipeline)**
# MAGIC - {pipeline_read_env}_silver.order_to_cash.offset"
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.order_to_cash.offset"
# MAGIC
# MAGIC
# MAGIC NB: 
# MAGIC ("material_number", "plant") is the primary key (composite) of the output data asset `offset`
# MAGIC
# MAGIC
# MAGIC **Job Pipeline**
# MAGIC - order-to-cash-offset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pandas as pd

from datetime import datetime, timedelta, date
from pyspark.sql import functions as f
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ### Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_read_env", "dev")
pipeline_read_env = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
reference_read_env = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
pipeline_write_env = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# this is the offset to substract to the general offset calculated because it is directly the time (in days) estmated for the invoice service of Latecoere to generate it
OFFSET_ADV_MINUS_HANDOVER = 1

# COMMAND ----------

# MAGIC %md
# MAGIC ## Generate & unpivot dataframe

# COMMAND ----------

df_silver_offset = spark.read.table(f"{pipeline_read_env}_silver.order_to_cash.offset")

# COMMAND ----------

# Take off the administrative time to genereate the invoice at Latecoere
df_silver_offset = df_silver_offset.withColumn(
    "offset", f.col("offset") - OFFSET_ADV_MINUS_HANDOVER
)

# Replace NaN values per 0
df_silver_offset = df_silver_offset.na.fill(0, subset=["offset"])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save offset Gold

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{pipeline_write_env}_gold.order_to_cash.offset",
    df=df_silver_offset,
    mode="overwrite",
)
