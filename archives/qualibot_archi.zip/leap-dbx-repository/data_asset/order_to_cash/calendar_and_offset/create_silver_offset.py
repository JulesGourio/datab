# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Offset for purchase_order
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC This notebook aims to generate the **silver** data asset of offset.
# MAGIC - offset time corresponds to the time to send a product from a Latecoere plant to one's purchaser
# MAGIC
# MAGIC /|\ The data is based on `bronze.manual_input.offset_calendar` which is a file that has to be updated manually.  
# MAGIC NB: When inserting a new file of calendar&offset in the manual_inputs, becareful to the column name `Désignation facture` that is not correctly decoded by Databricks -> you need to directly rename this column
# MAGIC
# MAGIC **Input Tables (Pipeline)**
# MAGIC - {pipeline_read_env}_bronze.manual_input.offset_calendar"
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.order_to_cash.offset"
# MAGIC
# MAGIC **Job Pipeline**
# MAGIC - order-to-purchase-offset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pandas as pd

from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ### Widgets
# MAGIC

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_read_env", "dev")
pipeline_read_env = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
reference_read_env = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
pipeline_write_env = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - ``offset_calendar``
# MAGIC The below dataset imported represents for a specific range of `"PC Short Name" and "IS*M"` the working weeks of the company that will received the manufacture product. 
# MAGIC Then for the columns with a header comprised between 2000 & 2500, it corresponds to the different Latecoere plants and the time (in days) to deliver a product to the `PC Short Name` client.
# MAGIC
# MAGIC
# MAGIC Columns with a date index (the date corresponds to a Monday start of the week).  
# MAGIC Thus, if there is 1 in the column, the firm related will work all the week
# MAGIC
# MAGIC NB: ``Material_number`` is a primary key of `df_material`

# COMMAND ----------

df_calendar_offset = spark.read.table(
    f"{pipeline_read_env}_bronze.manual_input.offset_calendar"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Define useful columns

# COMMAND ----------

## COLUMNS INPUTS

# Define useful columns
main_columns = ["PC Code", "PC Short Name", "IS*M"]
plants = ["2000", "2020", "2030", "2110", "2300", "2400", "2500"]
offset_columns = main_columns + plants

# COMMAND ----------

offset_df = df_calendar_offset.select(offset_columns)

offset_df = offset_df.withColumns(
    {column: f.col(column).cast("int") for column in plants}
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Drop lines with null 

# COMMAND ----------

offset_df_filtered = offset_df.filter(f.col("PC Code").isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Generate & unpivot dataframe

# COMMAND ----------

# Map / Melt the dataframe so that there is one column remaining with the offset per plant

# offset_df = spark.createDataFrame(df[offset_columns])
offset_df_melted = offset_df_filtered.unpivot(
    ids=main_columns,
    values=plants,
    variableColumnName="plant",
    valueColumnName="offset",
)

offset_df_melted = offset_df_melted.filter(f.col("offset").isNotNull())

# COMMAND ----------

offset_df_melted = offset_df_melted.withColumnsRenamed(
    {
        "PC Code": "profit_center",
        "PC Short Name": "PC_description",
        "IS*M": "material_number",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### DropDuplicates

# COMMAND ----------

offset_df_melted = offset_df_melted.drop_duplicates(
    ["profit_center", "material_number", "plant", "offset"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save offset Silver

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{pipeline_write_env}_silver.order_to_cash.offset",
    df=offset_df_melted,
    mode="overwrite",
)
