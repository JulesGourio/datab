# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Calendar for purchase_order
# MAGIC
# MAGIC **Description:**  
# MAGIC This notebook aims to generate the data asset of silver calendar.
# MAGIC Calendar data indicates whether the client is working and is able to receive the product manufactured or not...
# MAGIC
# MAGIC /|\ 
# MAGIC The data is based on `bronze.manual_input.offset_calendar` which is a file that has to be updated manually.  
# MAGIC NB: When inserting a new file, becareful to the column name `Désignation facture` that is not corrected decoded by Databricks
# MAGIC
# MAGIC **Input Tables (Pipeline)**
# MAGIC - {pipeline_read_env}_bronze.manual_input.offset_calendar"
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.order_to_cash.calendar"
# MAGIC
# MAGIC **Job Pipeline**
# MAGIC - order-to-cash-calendar

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pandas as pd

from datetime import datetime, timedelta, date
from pyspark.sql import functions as f
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ### Widgets
# MAGIC

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_read_env", "dev")
pipeline_read_env = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
reference_read_env = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
pipeline_write_env = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC The below dataset imported represents for a specific range of `"PC Short Name" and "IS*M"` the working weeks of the company that will received the manufacture product: it' a **calendar customer referential** !!  
# MAGIC The columns with a header comprised between 2000 & 2500 corresponds to the different Latecoere **plants** associated to the **time (in days)** to deliver a product to the `PC Short Name` client.
# MAGIC
# MAGIC Columns with a date index correspond to a Monday (start of the week). Thus, if there is 1 in the column, the firm related will work all the week

# COMMAND ----------

# Import material_master table
df_calendar_offset = spark.read.table(
    f"{pipeline_read_env}_bronze.manual_input.offset_calendar"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

## COLUMNS INPUTS

# Define useful columns
main_columns = ["PC Code", "PC Short Name", "IS*M", "Désignation facture"]
plants = ["2000", "2020", "2030", "2110", "2300", "2400", "2500"]

# Date columns
date_columns = list(set(df_calendar_offset.columns) - set(main_columns + plants))
date_columns_format = [
    col.strftime("%d/%m/%Y")
    for col in sorted(
        [datetime.strptime(col, "%d/%m/%Y").date() for col in date_columns]
    )
]
calendar_columns = main_columns + date_columns_format

# COMMAND ----------

# Get the Min and Max date
calendar_start_day = datetime.strptime(date_columns_format[0], "%d/%m/%Y")  # .date
calendar_end_day = datetime.strptime(date_columns_format[-1], "%d/%m/%Y")  # .date

# COMMAND ----------

# MAGIC %md
# MAGIC The below dataset imported represents for a specific range of `"PC Short Name" and "IS*M"` the working weeks of the company that will received the manufacture product.
# MAGIC
# MAGIC Columns with a date index (the date corresponds to a Monday start of the week).  
# MAGIC Thus, if there is 1 in the column, the firm related will work all the week

# COMMAND ----------

calendar_df = df_calendar_offset.select(calendar_columns)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extend & Add datetime to df on all the period

# COMMAND ----------

# add all days between the `calendar_start_day` and the `calendar_end_day` to the dataframe with a default None
columns_days = [
    (calendar_start_day + timedelta(days=x)).strftime("%d/%m/%Y")
    for x in range((calendar_end_day - calendar_start_day).days)
]
news_columns = {
    column: f.lit(None) for column in columns_days if column not in calendar_df.columns
}

calendar_df = calendar_df.withColumns(news_columns)
calendar_df = calendar_df.select((main_columns + columns_days))

# COMMAND ----------

calendar_df_renamed = calendar_df.withColumnsRenamed(
    {
        "PC Code": "profit_center",
        "PC Short Name": "PC_description",
        "IS*M": "material_number",
        "Désignation facture": "SD_Description",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Drop lines with null 

# COMMAND ----------

calendar_df_filtered = calendar_df_renamed.filter(f.col("material_number").isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation: Melt date columns into 1 column
# MAGIC As the dataset `calendar_df_filtered` was filled with new temporal columns to have every day, we need after melting to fill the Nan values logically.
# MAGIC This is what is done on the next cells 

# COMMAND ----------

# melt the previous dataframe in order to gather `columns_days` into 1 column ``is_working_day``
main_columns = ["profit_center", "PC_description", "material_number", "SD_Description"]

calendar_df_melt = calendar_df_filtered.unpivot(
    ids=main_columns,
    values=columns_days,
    variableColumnName="calendar_date",
    valueColumnName="is_working_day",
).sort(main_columns)

# As the pandas method fillna(method=ffill) does not exist in pyspark, we implete it this way:
# Step 1
window_spec = Window.rowsBetween(Window.unboundedPreceding, 0).partitionBy(
    "material_number"
)

#  Use the 'last' function to forward fill values within the window
# Step 2
calendar_df_melt_filled = calendar_df_melt.withColumn(
    "is_working_day_filled", f.last("is_working_day", True).over(window_spec)
)
calendar_df_melt_filled = calendar_df_melt_filled.drop("is_working_day")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop duplicates & Cast

# COMMAND ----------

calendar_df_melt_filled = calendar_df_melt_filled.drop_duplicates(
    ["material_number", "calendar_date"]
)

# COMMAND ----------

calendar_spark_df = calendar_df_melt_filled.withColumn(
    "calendar_date", f.to_date("calendar_date", "dd/MM/yyyy")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Calendar

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{pipeline_write_env}_silver.order_to_cash.calendar",
    df=calendar_spark_df,
    mode="overwrite",
)
