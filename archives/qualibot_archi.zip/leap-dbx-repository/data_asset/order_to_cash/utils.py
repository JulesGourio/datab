"""
Module that contains functions that are used in the notebooks of these projects
"""

from pyspark.sql import DataFrame, functions as f


def generate_monthly_date(df: DataFrame, col: str) -> DataFrame:
    """
    Generate a new column of `df` based on `col` column 
    with the following date format: "yyyy-MM"

    :param df: a pySpark dataframe 
    :type df: DataFrame
    :param col: a column of the dataframe to operate on
    :type col: str

    :return: a dataframe containing the new column based on `col` column 
        with the following date format: "yyyy-MM"
    :rtype: DataFrame
    """

    return df.withColumn(f"{col}_date_monthly", f.date_format(f.col(col), "yyyy-MM"))


def conditional_lowercase(word: str) -> str:
    """
    Function used to lowercase the column name if the column name 
    starts with one of the following prefixes

    :param word: a column of a dataframe to operate on
    :type word: str

    :return: `word` lowercased or with a prefix 
    :rtype: str
    """

    prefixes=["PC_", "SD_", "Material_", "business_ID", "MRP_"]

    for prefix in prefixes:
        if word.startswith(prefix):
            return prefix + word[len(prefix) :].lower()
        
    return word.lower()