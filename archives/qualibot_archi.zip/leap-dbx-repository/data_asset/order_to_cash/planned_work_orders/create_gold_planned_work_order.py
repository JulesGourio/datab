# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Work/Planned  orders : Gold data asset
# MAGIC **Description:**
# MAGIC The goal of the dataset is to build an gather at the same time **Planned Orders** and **Work Orders** and to enrich this dataset with others
# MAGIC
# MAGIC Definitions
# MAGIC 1. **Planned work orders** are those that have been created and **are in the planning phase** but have not yet been released for execution. These work orders are scheduled to be carried out at a future date and typically have statuses indicating they are in the preparation or scheduling stages.
# MAGIC
# MAGIC 2. Ongoing **work orders** are those that have been released for execution and are currently being worked on. These work orders have moved beyond the planning phase and are now in the process of being executed (manufactured) or completed.
# MAGIC
# MAGIC **Confluence Documentation**
# MAGIC - http://confluence.lat.corp:8090/display/LEAP/Data+asset+Planned+Work+Orders
# MAGIC
# MAGIC **Related Job Pipeline**
# MAGIC - D_X_SAP_Worked_Planned_Orders_History_Data_Asset
# MAGIC
# MAGIC **Input Tables Pipeline:**
# MAGIC - {PIPELINE_READ_ENV}_silver.order_to_cash.planned_work_order
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed
# MAGIC - {REFERENCE_READ_ENV}_gold.finance.profit_center_exposed
# MAGIC - {PIPELINE_READ_ENV}_gold.order_to_cash.calendar
# MAGIC - {PIPELINE_READ_ENV}_gold.order_to_cash.offset
# MAGIC - {PIPELINE_READ_ENV}_gold.order_to_cash.customer_order_exposed
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.order_to_cash.customer_order_latest
# MAGIC - {PIPELINE_WRITE_ENV}_gold.order_to_cash.customer_order_latest_exposed
# MAGIC - {PIPELINE_WRITE_ENV}_proj.order_to_cash.customer_order_history
# MAGIC - {PIPELINE_WRITE_ENV}_proj.order_to_cash.customer_order_history_exposed
# MAGIC
# MAGIC **Technical debt**
# MAGIC - We suppose that the work order (*in French: Ordre Fabrication*) extraction happens **after** planned orders to check later
# MAGIC - We do not implement past historisation which means that :
# MAGIC     1. the data stored in the prod db for stacked_history will only dated from the day the job was deployed !
# MAGIC     2. in case of any reinitialisation of the db database, the data accumulated until this action would be loose
# MAGIC     3. a solution would be to use (and generate if not existing)  the `sap_planned_order_stack` and `sap_work_order_basics_history_exposed` gold db in the silver step

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as f

import great_expectations as gx
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import historisation, table_utils
from data_asset.order_to_cash.utils import generate_monthly_date, conditional_lowercase

# Logging imports
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments)
# MAGIC - DATE_FILTERING_DELIVERIES is used to filter the customers data asset and get the ones that are "recent" customers ; in other words the active customers
# MAGIC - force_db_reinitialization -> Used to generate totally from the beginning the history of the output data asset. In that case, we drop all the output data asset

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("DATE_FILTERING_DELIVERIES", "2020-1-1")
DATE_FILTERING_DELIVERIES = dbutils.widgets.get("DATE_FILTERING_DELIVERIES")

dbutils.widgets.text("force_db_reinitialization", "False")
force_db_reinitialization = (
    dbutils.widgets.get("force_db_reinitialization").lower() == "true"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### LOG LEVEL
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Log environments

# COMMAND ----------

log.info(f"PIPELINE_WRITE_ENV", {PIPELINE_WRITE_ENV})
log.info(f"PIPELINE_READ_ENV", {PIPELINE_READ_ENV})
log.info(f"REFERENCE_READ_ENV", {REFERENCE_READ_ENV})
log.info(f"force_db_reinitialization", {force_db_reinitialization})

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC - Silver work orders: **``df_wo_silver``**
# MAGIC - Material Master Data Asset: **``df_mat_gold``**: Master material data asset with all necessary information about materials
# MAGIC - Profit center **``df_pc_gold``**: profit centers gold data asset
# MAGIC - Calendar **``df_calendar``**: Calendar per PC/Material for receiving sites working days
# MAGIC - Offset **``df_offset``**: offset to add to estimated good issue date in order to count for the days spent in delivery
# MAGIC - Customer Order **``customer_orders``**: table that is related to all the customers

# COMMAND ----------

df_wo_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.order_to_cash.planned_work_order"
)
df_mat_gold = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_master_data_basics_exposed"
)
df_pc_gold = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)
customer_orders = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.order_to_cash.customer_order_exposed"
)
df_calendar = spark.read.table(f"{PIPELINE_READ_ENV}_gold.order_to_cash.calendar")
df_offset = spark.read.table(f"{PIPELINE_READ_ENV}_gold.order_to_cash.offset")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

TABLE_PREFIX = ["AFKO", "AUFK", "PLAF"]
MASTER_MAT_COLUMNS = ["Material_Number", "Description"]
JOIN_MATERIAL_SO = ["Material_Number"]
JOIN_PC_SO = ["profit_center"]
SD_DATE_COLUMN = "end_planned_date"
PROFIT_CENTER_COLUMNS = ["Profit_center_short", "Long_Description"]
PROFIT_CENTER_PREFIX_COLUMNS = [
    "Customer_Group",
    "Aircraft_platform",
    "Aircraft_product",
    "Branch",
    "Product_Group",
]

ESTIMATED_DELIVERY_DATE = "estimated_delivery_date"
ID_COLUMNS = ["order_number"]

# COMMAND ----------

# Inputs related to historisation
catalog_history = f"{PIPELINE_WRITE_ENV}_proj"
catalog_latest = f"{PIPELINE_WRITE_ENV}_gold"
domain = "order_to_cash"
table = "planned_work_order"

dest_table_history = f"{catalog_history}.{domain}.{table}_stacked_history"
dest_table_latest = f"{catalog_latest}.{domain}.{table}_latest"

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

df_wo_silver_filtered, MODE = historisation.optimize_and_historize(
    df_input_history=df_wo_silver,
    dest_output_table_history=dest_table_history,
    force_db_reinitialization=force_db_reinitialization,
    extraction_date_col_name_input_df="extraction_date",
    extraction_date_col_name_output_df="extraction_date",
)

# Quit notebook without any errors
if MODE is None:
    dbutils.notebook.exit(f"the table `{dest_table_history}` is already up to date")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 -  Select columns in the enrichements and create necessay columns:
# MAGIC - Add prefix to enrichements to identify object source
# MAGIC - Create dscription as oject - object desvription

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 1.1 -  Material Master data

# COMMAND ----------

df_mat_prep = df_mat_gold.select(MASTER_MAT_COLUMNS).withColumn(
    "material_description",
    f.concat_ws(" - ", f.col("Material_Number"), f.col("Description")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 1.2 -  Profit Center
# MAGIC Rename and create a concatenate column

# COMMAND ----------

df_pc_prep = (
    df_pc_gold.select(PROFIT_CENTER_COLUMNS + PROFIT_CENTER_PREFIX_COLUMNS)
    .withColumnsRenamed({col: f"PC_{col}" for col in PROFIT_CENTER_PREFIX_COLUMNS})
    .withColumn(
        "PC_description",
        f.concat_ws(" - ", f.col("Profit_center_short"), f.col("Long_Description")),
    )
    .drop("Long_Description")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 1.3 -  Create ID column

# COMMAND ----------

# Create `business_ID` column
df_wo_prep = df_wo_silver_filtered.withColumn(
    "business_ID", f.concat_ws("_", *ID_COLUMNS)
)

# remove leading zeros
df_wo_trans = table_utils.remove_leading_zeros(
    df=df_wo_prep, column_names=["material_number"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC ## Join Sales orders <-- Master material data <-- Profit center

# COMMAND ----------

df_wo_trans_mat = df_wo_trans.join(other=df_mat_prep, on=JOIN_MATERIAL_SO, how="left")
df_wo_trans_mat_prep = df_wo_trans_mat.join(
    df_pc_prep.withColumnRenamed("profit_center_short", "profit_center"),
    on=JOIN_PC_SO,
    how="left",
)
df_wo_trans_mat_prep = df_wo_trans_mat_prep.withColumnRenamed("Plant", "plant")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 -  Prepare calendar
# MAGIC ### Join Sales/Work orders <-- df_offset
# MAGIC From the estimated end manufactured date and the offset, we can calculate the date for which the customer will receive one's command:
# MAGIC ```temp_estimated_delivery_date = offset + end_planned_date```
# MAGIC Even though we have to recall the calendar data which gives closing date of the customer.
# MAGIC If the ``temp_estimated_delivery_date`` is on a closing date of the customer then, we have to postpone it to the next opening date.
# MAGIC Consequently, this is what we are calculaing here by finding this next opening date!

# COMMAND ----------

df_wo_with_offset = df_wo_trans_mat_prep.join(
    other=df_offset.select("material_number", "plant", "offset"),
    how="left",
    on=["material_number", "plant"],
)

df_wo_with_offset = df_wo_with_offset.withColumn(
    "temp_estimated_delivery_date",
    f.date_add(f.col(SD_DATE_COLUMN), f.col("offset").cast("int")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Prepare calendar
# MAGIC ### Check join between work/planned orders & customers orders
# MAGIC Let's recall that the data asset has to give matches between orders (work & planned) to the customers.
# MAGIC So, we want **to be sure** that any lines related to orders are reliable to the customers.
# MAGIC
# MAGIC This link operates on the following key ("sales_document", "sd_item").
# MAGIC That's why we calculate the antileft join between `df_wo_with_offset` & `customer_orders` to be sure this does not happen

# COMMAND ----------

leftanti = df_wo_with_offset.join(
    other=df_wo_with_offset, on=["sales_document", "sd_item"], how="leftanti"
)

# COMMAND ----------

# Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
work_planned_orders_anti_customer_orders = gx.dataset.SparkDFDataset(
    leftanti, persist=False
)

# Define the red quality checks
red_quality_check_results = [
    work_planned_orders_anti_customer_orders.expect_table_row_count_to_equal(value=0),
]

# Validate all red quality checks, if at least one fails the job stops
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="There are no elements from work-planned-orders that match customer-orders",
    error_message="At least one red quality checks is KO, the job has stopped, check corresponding results",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="planned_work_order_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

log.info(
    f"Number of work/planned orders with 'sales_document' key null: {df_wo_with_offset.filter(f.col('sales_document').isNull()).count()}"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Join df_wo_with_estimated_date <-- Customers orders
# MAGIC ("material_number", "profit_center") is the **primary key** (composite) of this data asset

# COMMAND ----------

customer_orders_reduced = (
    customer_orders.filter(
        (f.col("requested_delivery_date") > DATE_FILTERING_DELIVERIES)
        & (f.col("material_number").isNotNull())
    )
    .select(["sales_document", "sd_item"])
    .distinct()
)

# COMMAND ----------

df_wo_co_with_estimated_date = df_wo_with_offset.join(
    other=customer_orders_reduced, on=["sales_document", "sd_item"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 -  Add estimated delivery date
# MAGIC ### Join df_wo_with_estimated_date <-- df_calendar
# MAGIC After having calculating the `temp_estimated_delivery_date`, we match on the calendar_date : that will allow us to guess finally the `next_calendar_date` that match with the openings/workings days of the customer
# MAGIC
# MAGIC NB: ("material_number", "calendar_date") is the primary key (composite) of the output data asset `calendar`

# COMMAND ----------

df_wo_co_with_estimated_date = (
    df_wo_with_offset.alias("wo_offset")
    .join(
        df_calendar.alias("all_calendar"),
        on=(
            (
                f.col("wo_offset.material_number")
                == f.col("all_calendar.material_number")
            )
            & (
                f.col("wo_offset.temp_estimated_delivery_date")
                == f.col("all_calendar.calendar_date")
            )
        ),
        how="left",
    )
    .withColumnRenamed("next_calendar_date", "estimated_delivery_date")
)

# COMMAND ----------

# keep only the dates located in the given range
min_date, max_date = df_wo_co_with_estimated_date.select(
    f.min("calendar_date"), f.max("calendar_date")
).collect()[0]
df_wo_co_with_estimated_date = df_wo_co_with_estimated_date.filter(
    f.col(SD_DATE_COLUMN).between(min_date, max_date)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 - Add 2 new columns: Months & Week Number

# COMMAND ----------

df_wo = table_utils.add_week_number(
    df=df_wo_co_with_estimated_date, date_col=ESTIMATED_DELIVERY_DATE
)
df_wo = generate_monthly_date(df=df_wo, col=ESTIMATED_DELIVERY_DATE)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 5 - Drop duplicates columns & Lower case columns name

# COMMAND ----------

# Drop the duplicated columns
df_wo = df_wo.drop(
    f.col("all_calendar.material_number"),
    f.col("all_calendar.profit_center"),
    f.col("all_calendar.PC_description"),
)
df_wo = df_wo.withColumnsRenamed(
    {col: conditional_lowercase(col) for col in df_wo.columns}
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold Customer_orders

# COMMAND ----------

max_extraction_date = df_wo.select(f.max("extraction_date")).first()[0]

df_wo_latest = df_wo.filter(f.col("extraction_date") == max_extraction_date)

# COMMAND ----------

# Save history
table_utils.save_table(
    df=df_wo, dest_table=dest_table_history, mode=MODE, merge_schema=True
)

# Save Latest
table_utils.save_table(df=df_wo_latest, dest_table=dest_table_latest, mode="overwrite")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output Exposed Tables
# MAGIC - Proj **history** customer_orders exposed
# MAGIC - Gold **latest** customer_orders exposed

# COMMAND ----------

ORDER_COLUMNS = ["business_ID", "order_number"]

select_statement = ",".join(
    ORDER_COLUMNS
    + [
        col
        for col in df_wo.columns
        if all(
            [not (col.upper().startswith(one_prefix)) for one_prefix in TABLE_PREFIX]
        )
        and col not in ORDER_COLUMNS
    ]
)

# Save latest exposed
table_utils.create_table_view(
    src_full_tablename=dest_table_latest,
    dest_full_tablename=f"{dest_table_latest}_exposed",
    select_statement=select_statement,
    replace_view=True,
)

# Save history exposed
table_utils.create_table_view(
    src_full_tablename=dest_table_history,
    dest_full_tablename=f"{dest_table_history}_exposed",
    select_statement=select_statement,
    replace_view=True,
)
