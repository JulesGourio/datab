# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Planned and work orders : Silver data asset
# MAGIC **Description:**
# MAGIC Planned work orders are those that have been created and are in the planning phase but have not yet been released for execution.
# MAGIC These work orders are scheduled to be carried out at a future date and typically have statuses indicating they are in the preparation or scheduling stages.
# MAGIC
# MAGIC **Confluence Documentation**
# MAGIC - http://confluence.lat.corp:8090/display/LEAP/Data+asset+Planned+Work+Orders
# MAGIC
# MAGIC **Related Job Pipeline**
# MAGIC - D_X_SAP_Worked_Planned_Orders_History_Data_Asset
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {reference_read_env}_gold.production.sap_planned_order_latest
# MAGIC - {reference_read_env}_gold.production.sap_work_order_basics_latest
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.afko_latest
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.order_to_cash.planned_work_order
# MAGIC
# MAGIC **Technical debt**
# MAGIC - We suppose that the work order extraction happens **after** planned orders to check later
# MAGIC - We do not implement past historisation which means that :
# MAGIC   1. the data stored in the prod db for stacked_history will only dated from the day the job was deployed !
# MAGIC   2. in case of any reinitialisation of the db database, the data accumulated until this action would be loose
# MAGIC   3. If the job crash then, there would be a hole of history gold data during the time slot
# MAGIC   4. a solution would be to use the `wb2vvbakvbap2_stack` bronze db in the silver step

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
from pyspark.sql.window import Window
import great_expectations as gx

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.

# COMMAND ----------

# dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_read_env", "dev")
pipeline_read_env = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
reference_read_env = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_write_env", "dev")
pipeline_write_env = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### LOG LEVEL
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Log environments

# COMMAND ----------

log.info(f"PIPELINE_WRITE_ENV {pipeline_write_env}")
log.info(f"PIPELINE_READ_ENV {pipeline_read_env}")
log.info(f"REFERENCE_READ_ENV {reference_read_env}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC - Planned work orders: **``df_planned_wo_gold``** business header to use or cast and rename columns
# MAGIC - Ongoing work orders: **``df_ongoing_wo_gold``** stores the header information for deliveries.
# MAGIC - AFKO: **``df_afko_raw``**  stores the header information for deliveries (to use later for checking the timestamps)
# MAGIC
# MAGIC NB1: afko is the source of work order and planned order.

# COMMAND ----------

# Data asset of Planned Orders
df_planned_wo_gold = spark.read.table(
    f"{reference_read_env}_gold.production.sap_planned_order_latest"
)

# Data asset of Worked Orders
df_ongoing_wo_gold = spark.read.table(
    f"{reference_read_env}_gold.production.sap_work_order_basics_latest"
)

# Source of above data asset - only used to get a timestamp
df_afko_raw = spark.read.table(
    f"{reference_read_env}_bronze.sap_latecoere_ecc6.afko_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

COMMON_COLUMNS = [
    "WBS_Code",
    "Start_Planned_Date",
    "Customers_Orders",
    "Plant",
    "Material_Number",
    "MRP_Controller",
    "Customers_Orders_Item",
    "Branch",
    "order_number",
    "Production_Version",
    "Profit_Center",
    "Storage_Location",
    "End_Planned_Date",
    "Production_Site",
    "Real_Start_Date",
    "Real_End_Date",
    "Order_status",
    "Quantity",
    "extraction_date",
]
RENAME_COLUMNS = {
    "Customers_Orders": "sales_document",
    "Customers_Orders_Item": "SD_item",
}

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 -  Rename columns

# COMMAND ----------

df_planned_wo_prep = (
    df_planned_wo_gold.withColumnRenamed("planned_order_number", "order_number")
    .withColumn("order_status", f.lit("Planned_Order"))
    .withColumns({"real_start_date": f.lit(None), "real_end_date": f.lit(None)})
)
df_ongoing_wo_prep = df_ongoing_wo_gold.withColumnsRenamed(
    {
        "Quantity_Ordered": "quantity",
        "wo_number": "order_number",
        "wo_status": "order_status",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Add extraction timestamp of afko
# MAGIC afko is the source of work order and planned order.
# MAGIC As the timestamp is not present in the gold data asset, we use the raw source to get "extraction_timestamp" & "plaf_extraction_timestamp" and check the coherence of the extracion date

# COMMAND ----------

extraction_wo = df_afko_raw.select("extraction_timestamp").distinct().collect()[0][0]
extraction_planned_wo = (
    df_planned_wo_prep.select("plaf_extraction_timestamp").distinct().collect()[0][0]
)

# COMMAND ----------

if extraction_wo >= extraction_planned_wo:
    log.info("OF extracted after OP")
else:
    log.info("Error: OF was extracted before OP - please check")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Transform timestamp columns

# COMMAND ----------

# Cast and Transform Planned WO
df_planned_wo_prep = df_planned_wo_prep.withColumn(
    "extraction_date", f.col("PLAF_extraction_timestamp").cast("date")
)
df_ongoing_wo_prep = df_ongoing_wo_prep.withColumn(
    "extraction_date", f.lit(extraction_planned_wo.date()).cast("date")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 - Union Planned/ongoing wo
# MAGIC We create a unique dataset that gathers the orders: whether it be the **planned** or the **work orders**

# COMMAND ----------

df_wo = (
    df_ongoing_wo_prep.select(COMMON_COLUMNS)
    .unionByName(df_planned_wo_prep.select(COMMON_COLUMNS), allowMissingColumns=True)
    .withColumnsRenamed(RENAME_COLUMNS)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2 - Filter work orders with no sales_document

# COMMAND ----------

df_wo_filtered = df_wo.filter(f.col("sales_document").isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3 - Check there is no double WO/PO, and flag with the planned order number
# MAGIC - We get the common sales document/item/material between work orders and work orders planned to check the elements still appearing in planned hence already converted to work order
# MAGIC
# MAGIC In the chain of business process: work-order comes after planned-order. (customer-order -> planned-order -> work-order -> delivery)
# MAGIC Normally, **orders cannot** have **at the same time** 'Planned Order' and 'Work Order' status !
# MAGIC Here, we want to check the intersection of these 2 ensembles is empty.
# MAGIC In case the intersection is not empty, we decide to create a flag rather than deleted the data
# MAGIC
# MAGIC NB1: The possible values of `order_status` are "WO_To_Analyse" "WO_Open", "WO_Scrapped", "WO_Delivered", "WO_Cancelled", "WO_In_Progress", "Planned_Order"

# COMMAND ----------

# Join on two ensembles and get intersection
joined_on_columns = ["sales_document", "sd_item", "material_number"]
work_orders_stil_planned = (
    df_wo_filtered.filter(f.col("order_status") == "Planned_Order")
    .select(f.col("order_number").alias("planned_order_number"), *joined_on_columns)
    .join(
        df_wo_filtered.filter(
            ~f.col("order_status").isin("WO_Cancelled", "Planned_Order")
        ).select(f.col("order_number"), *joined_on_columns),
        on=joined_on_columns,
        how="inner",
    )
)

# COMMAND ----------

intersection = work_orders_stil_planned.filter(
    f.col("planned_order_number").isNotNull()
)

# COMMAND ----------

intersection = intersection.withColumn(
    "flag_warning_double_status", f.lit(1).cast("boolean")
)

# COMMAND ----------

log.warn(
    f"Becareful: There are {intersection.count()} orders which have doubled status: at the same time 'Planned Order' and 'Work Order'"
)

for order in intersection.collect():
    log.warn(
        f"The following order number {order.planned_order_number} has 2 status ('Planned Order' and 'Work Order') which is theoretically impossible"
    )

# COMMAND ----------

# Complete `df_wo_filtered` with the above information
df_wo_filtered = df_wo_filtered.join(
    intersection, on=joined_on_columns + ["order_number"], how="left"
)

# COMMAND ----------

df_wo_filtered_renamed = df_wo_filtered.withColumnsRenamed(
    {
        "Quantity_Ordered": "quantity",
        "wo_number": "order_number",
        "wo_status": "order_status",
        "Start_Planned_Date": "start_planned_date",
        "Plant": "plant",
        "Branch": "branch",
        "Material_Number": "material_number",
        "WBS_Code": "WBS_code",
        "MRP_Controller": "MRP_controller",
        "Production_Version": "production_version",
        "Profit_Center": "profit_center",
        "Storage_Location": "storage_location",
        "End_Planned_Date": "end_planned_date",
        "Production_Site": "production_site",
        "Real_Start_Date": "real_start_date",
        "Real_End_Date": "real_end_date",
        "Order_status": "order_status",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Quality Check after Transformation
# MAGIC - Check the unicity of the order number
# MAGIC
# MAGIC In case of any duplicates on `order_number` column, print the related lines of the data asset

# COMMAND ----------

all_duplicates_count = (
    df_wo_filtered_renamed.count() - df_wo_filtered_renamed.distinct().count()
)
duplicates_order_number_count = (
    df_wo_filtered_renamed.select("order_number").count()
    - df_wo_filtered_renamed.select("order_number").distinct().count()
)

log.info(f"Number of duplicated lines: {all_duplicates_count}")
log.info(
    f"Number of duplicated lines on `order_number` key:  {duplicates_order_number_count}"
)


if duplicates_order_number_count > 0:
    # Create a window specification partitioned by the duplicate columns
    window_spec = Window.partitionBy(["order_number"])

    # Add a count column to identify duplicates
    df_with_duplicates = df_wo_filtered_renamed.withColumn(
        "count", f.count("*").over(window_spec)
    )

    # Filter rows where the count is greater than 1 (duplicates)
    duplicates = df_with_duplicates.filter(f.col("count") > 1).drop("count")

    duplicates.display()

# COMMAND ----------

# Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
dfgx_In1_prep = gx.dataset.SparkDFDataset(df_wo_filtered_renamed, persist=False)

# Define the red quality checks
red_quality_check_results = [
    dfgx_In1_prep.expect_compound_columns_to_be_unique(column_list=["order_number"]),
]

# Validate all red quality checks, if at least one fails the job stops
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="There's no duplicated rows and col_a doesn't have any null value",
    error_message="At least one red quality checks is KO, the job has stopped, check corresponding results",
    pipeline_write_env=pipeline_write_env,
    table_name="planned_work_order_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables - Silver Planned Work Order

# COMMAND ----------

# Save Planned and work orders stack
table_path = f"{pipeline_write_env}_silver.order_to_cash.planned_work_order"
table_utils.save_table(
    dest_table=table_path, df=df_wo_filtered_renamed, mode="overwrite"
)
