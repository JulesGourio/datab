# Databricks notebook source
# MAGIC %md
# MAGIC # Transit time : Silver data asset 
# MAGIC Transit time does correspond to the data asset which matches with customer clients and gives the time for a manufactured product to be delivered. Besides, it indicates the time window for which a manufactured product can be delivered
# MAGIC
# MAGIC **Description**  
# MAGIC This notebook aims at doing the silver task to clean transit time manual input data asset
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {reference_read_env}_bronze.manual_input.revenue_forecast_transit_time
# MAGIC
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.order_to_cash.transit_time

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

# Logging imports
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### LOG LEVEL 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Log environments

# COMMAND ----------

log.info(f"PIPELINE_WRITE_ENV, {PIPELINE_WRITE_ENV}")
log.info(f"PIPELINE_READ_ENV, {PIPELINE_READ_ENV}")
log.info(f"REFERENCE_READ_ENV, {REFERENCE_READ_ENV}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC - Bronze Transit time: **``df_transit_time``**

# COMMAND ----------

df_transit_time = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze.manual_input.revenue_forecast_transit_time"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# Inputs to save table
catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "order_to_cash"
table = "transit_time"
dest_table = f"{catalog}.{domain}.{table}"

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Rename & Drop useless transit time columns 

# COMMAND ----------

df_transit_time = df_transit_time.drop("IS*M")

# COMMAND ----------

df_transit_time_renamed = df_transit_time.withColumnsRenamed(
    {
        "CP": "profit_center",
        "Point expedition": "shipping_receiving_place",
        "Client livre previsionnel": "customer_code",
        "Nominal transit time (opening days)": "transit_time",
        "Logistic window (opening days)": "time_window",
        "Incoterm": "incoterm_code",
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 - Trim Data

# COMMAND ----------

df_transit_time_prep = table_utils.trim_dataframe(df_transit_time_renamed)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3 - Replace NA values of "time_window" column per `null`
# MAGIC `time_window` corresponds in advanced to the number of days before the expecting date the new manufactured product can be received by the client.  
# MAGIC When there is "NA", it means that the client directlty pay after the bl newly edited. Thus, there is no a minimum date so that the product be received   

# COMMAND ----------

df_transit_time_prep = df_transit_time_prep.replace(
    "NA", None, subset=["time_window"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 4 - Cast columns in expected types

# COMMAND ----------

df_transit_time_prep = df_transit_time_prep.withColumn(
    "time_window", f.col("time_window").cast("int")
)
df_transit_time_prep = df_transit_time_prep.withColumn(
    "transit_time", f.col("transit_time").cast("int")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 5 - Drop duplicates

# COMMAND ----------

PRIMARY_KEY = ["profit_center", "customer_code", "shipping_receiving_place"]

# COMMAND ----------

count_duplicates = (
    df_transit_time_prep.select(*PRIMARY_KEY).count()
    - df_transit_time_prep.select(*PRIMARY_KEY).distinct().count()
)

log.info(f"Number of duplicates in `transit_time` data asset: {count_duplicates}")

# COMMAND ----------

duplicates_info_grouped = (
    df_transit_time_prep.groupBy(PRIMARY_KEY)
    .agg(
        f.collect_set("transit_time").alias("unique_values"),  # Collect unique values
        f.count("transit_time").alias(
            "count"
        ),  # Optional: count total rows in each group
    )
    .filter(f.col("count") > 1)
    .withColumn(
        "are_values_identical", f.size(f.col("unique_values")) == 1
    )  # Check if all values are identical
)

# COMMAND ----------

if duplicates_info_grouped.filter(f.col("are_values_identical") == f.lit(False)).count() > 0:
    log.debug(duplicates_info_grouped.display())
    raise TypeError(
        "Duplicates: there are duplicates with different values for column `transit_time`"
    )

else:
    log.info("No duplicates found")
    df_transit_time_prep = df_transit_time_prep.dropDuplicates(subset=PRIMARY_KEY)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables - Silver transit time

# COMMAND ----------

# Save transit time Gold
table_utils.save_table(df=df_transit_time_prep, dest_table=dest_table, mode="overwrite")
