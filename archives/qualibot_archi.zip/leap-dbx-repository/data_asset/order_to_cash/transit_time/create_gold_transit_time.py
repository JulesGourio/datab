# Databricks notebook source
# MAGIC %md
# MAGIC # Transit time : Gold data asset 
# MAGIC Transit time does correspond to the data asset which matches with customer clients and gives the time for a manufactured product to be delivered. Besides, it indicates the time window for which a manufactured product can be delivered
# MAGIC
# MAGIC **Description**  
# MAGIC This notebook aims at doing the gold task to do enrichment of transit time silver data asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_write_env}_silver.order_to_cash.transit_time
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.order_to_cash.transit_time

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

# Logging imports
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### LOG LEVEL 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Log environments

# COMMAND ----------

log.info(f"PIPELINE_WRITE_ENV, {PIPELINE_WRITE_ENV}")
log.info(f"PIPELINE_READ_ENV, {PIPELINE_READ_ENV}")
log.info(f"REFERENCE_READ_ENV, {REFERENCE_READ_ENV}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC - Bronze Transit time: **``df_transit_time``**

# COMMAND ----------

df_silver_transit_time = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.order_to_cash.transit_time"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# Inputs to save table
catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "order_to_cash"
table = "transit_time"
dest_table = f"{catalog}.{domain}.{table}"

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables - Gold transit time

# COMMAND ----------

# Save transit time Gold
table_utils.save_table(
    df=df_silver_transit_time, dest_table=dest_table, mode="overwrite"
)
