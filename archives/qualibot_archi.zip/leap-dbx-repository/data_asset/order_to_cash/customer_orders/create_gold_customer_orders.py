# Databricks notebook source
# MAGIC %md
# MAGIC # Customer orders : Gold data asset 
# MAGIC
# MAGIC
# MAGIC **Description**  
# MAGIC Customer orders is mandatory to analyse and understand the client demand trends, we already have a view combining the main tables in the Sales document module. 
# MAGIC
# MAGIC **Confluence Documentation**
# MAGIC - http://confluence.lat.corp:8090/display/LEAP/Data+asset+CUSTOMER+ORDERS
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver.order_to_cash.customer_orders
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {reference_read_env}_gold.finance.profit_center_exposed
# MAGIC - {reference_read_env}_gold.master_data.material_master_data_plant_exposed
# MAGIC - {reference_read_env}_gold.finance.currency_exchange
# MAGIC - {reference_read_env}_gold.finance.customer_master_data_latest_exposed
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.vbkd_latest
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.order_to_cash.customer_order_latest
# MAGIC - {pipeline_write_env}_gold.order_to_cash.customer_order_latest_exposed
# MAGIC - {pipeline_write_env}_gold.order_to_cash.customer_order_history
# MAGIC - {pipeline_write_env}_gold.order_to_cash.customer_order_history_exposed
# MAGIC
# MAGIC The PK (Primary Key) of the output data asset is `(sales_document, SD_item)` 
# MAGIC
# MAGIC **Related job Pipeline**
# MAGIC - D_X_SAP_Customer_Order_History_Data_Asset
# MAGIC
# MAGIC **Technical Debt**
# MAGIC - We do not implement past historisation which means that : 
# MAGIC   1. the data stored in the prod db for stacked_history will only dated from the day the job was deployed !
# MAGIC   2. in case of any reinitialisation of the db database, the data accumulated until this action would be loose
# MAGIC   3. If the job crash then, there would be a hole of history gold data during the time slot
# MAGIC   4. a solution would be to use the `wb2vvbakvbap2_stack` bronze db in the silver step

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils, amount_correction, historisation
from data_asset.order_to_cash.utils import (
    conditional_lowercase,
    generate_monthly_date,
)

# Logging imports
from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).
# MAGIC - force_db_reinitialization -> Used to generate totally from the beginning the history of the output data asset. In that case, we drop all the output data asset
# MAGIC

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("force_db_reinitialization", "False")
force_db_reinitialization = dbutils.widgets.get("force_db_reinitialization").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### LOG LEVEL 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Log environments

# COMMAND ----------

log.info(f"PIPELINE_WRITE_ENV", {PIPELINE_WRITE_ENV})
log.info(f"PIPELINE_READ_ENV", {PIPELINE_READ_ENV})
log.info(f"REFERENCE_READ_ENV", {REFERENCE_READ_ENV})
log.info(f"force_db_reinitialization", {force_db_reinitialization})

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC - Silver customer orders: **``df_sales_orders_silver``**
# MAGIC - Profit center: **``df_pc_gold``** - profit centers gold data asset
# MAGIC - Currency exchange: **``df_cex_gold``** - gold currency exchange data asset
# MAGIC - Material Master Data Asset: **``df_mat_gold``** - Master material data asset with all necessary information about material
# MAGIC - Customer master data: **``df_customer_gold``** : Master customer data asset
# MAGIC - VBKD **``df_vbkd``** (Sales Document: Business Data):
# MAGIC   - Where the PO Number is complete with 35 chars instead of 20 chars from VBAK

# COMMAND ----------

df_sales_orders_silver_history = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.order_to_cash.customer_order"
)
df_pc_gold = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)
df_cex_gold = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.currency_exchange")
df_mat_gold = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_master_data_basics_exposed"
)
df_customer_gold = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.customer_master_data_latest_exposed"
)
df_vbkd = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.vbkd_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

TABLE_PREFIX = "WB2_V_VBAK_VBAP2"
MASTER_MAT_COLUMNS = ["Material_Number", "Description"]
PROFIT_CENTER_COLUMNS = ["Profit_Center", "Profit_center_short", "Long_Description"]
PROFIT_CENTER_PREFIX_COLUMNS = [
    "Customer_Group",
    "Aircraft_platform",
    "Aircraft_product",
    "Branch",
    "Product_Group",
]
JOIN_MATERIAL_SO = ["Material_Number"]
CUSTOMER_COLUMNS = ["Customer_name", "customer_code"]
JOIN_CUSTOMER_SO = ["customer_code"]
JOIN_PC_SO = ["profit_center"]
VALUED_COLUMN = "net_amount"
CURRENCY_COLUMN = "SD_currency"
SD_DATE_COLUMN = "requested_delivery_date"
ID_COLUMNS = ["Sales_document", "SD_item"]

# COMMAND ----------

# Inputs related to historisation
catalog_latest = f"{PIPELINE_WRITE_ENV}_gold"
catalog_history = f"{PIPELINE_WRITE_ENV}_proj"
domain = "order_to_cash"
table = "customer_order"

dest_table_latest = f"{catalog_latest}.{domain}.{table}_latest"
dest_table_history = f"{catalog_history}.{domain}.{table}_stacked_history"

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC ## Preparation to filter silver history

# COMMAND ----------

df_sales_orders_silver_history_filtered, MODE = historisation.optimize_and_historize(
    df_input_history=df_sales_orders_silver_history,
    dest_output_table_history=dest_table_history,
    force_db_reinitialization=force_db_reinitialization,
    extraction_date_col_name_input_df="extraction_date",
    extraction_date_col_name_output_df="extraction_date",
)

# COMMAND ----------

# Quit notebook without any errors
if MODE is None:
    dbutils.notebook.exit(f"the table `{dest_table_history}` is already up to date")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC Refer to ``data_asset.order_to_cash.utils`` functions

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 -  Select columns in the enrichements and create necessay columns:
# MAGIC - Add prefix to enrichements to identify object source
# MAGIC - Create dscription as oject - object desvription

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 1.1 -  Material Master data 

# COMMAND ----------

df_mat_prep = (
    df_mat_gold.select(MASTER_MAT_COLUMNS)
    .withColumnRenamed("Description", "Material_Description")
    .withColumn(
        "Material_Description",
        f.concat_ws(" - ", f.col("Material_Number"), f.col("Material_Description")),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 1.2 -  Profit Center

# COMMAND ----------

df_pc_prep = (
    df_pc_gold.select(PROFIT_CENTER_COLUMNS + PROFIT_CENTER_PREFIX_COLUMNS)
    .withColumnsRenamed({col: f"PC_{col}" for col in PROFIT_CENTER_PREFIX_COLUMNS})
    .withColumn(
        "PC_description",
        f.concat_ws(" - ", f.col("Profit_center_short"), f.col("Long_Description")),
    )
    .drop("Long_Description")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 1.2 -  Customer master data

# COMMAND ----------

df_customer_prep = df_customer_gold.select(CUSTOMER_COLUMNS).drop_duplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 1.3 -  Create ID & material_number columns

# COMMAND ----------

df_sales_orders_prep = df_sales_orders_silver_history_filtered.withColumn(
    "business_ID", f.concat_ws("_", *ID_COLUMNS)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 1.4 - Get complete PO Number (VBAK.po_number -> VBKD.po_number)
# MAGIC
# MAGIC Note: There are difference on characters length for 2 tables containing the PO number, which leads to have an incomplete value using VBAK.BSTNK, instead the complete data is on VBKD.BSTKD
# MAGIC
# MAGIC Join Table VBKD with VBAK at header level (not item level)
# MAGIC
# MAGIC #### SAP Documentation:
# MAGIC - [VBKD.BSTKD ](https://www.sapdatasheet.org/abap/tabl/vbkd.html) = Customer PO Number
# MAGIC - [VBAK.BSTNK](https://www.sapdatasheet.org/abap/tabl/vbak.html) = Customer PO Number
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

df_vbkd_prep = (
    df_vbkd.withColumnRenamed("posnr", "SD_Item")
    .withColumnRenamed("vbeln", "sales_document")
    .select("sales_document", "SD_Item", "bstkd")
)

# Filter VBKD to header-level rows (POSNR = '000000'), then drop column as not longer useful
df_vbkd_prep = df_vbkd_prep.filter(f.col("SD_Item") == "000000").drop("SD_Item")

df_sales_orders_po_number_OK = df_sales_orders_prep.join(
    df_vbkd_prep, on=["sales_document"], how="left"
)
df_sales_orders_po_number_OK = df_sales_orders_po_number_OK.withColumnRenamed(
    "PO_number", "PO_number_old"
).withColumnRenamed("bstkd", "PO_number")

# Drop old PO_Number as not useful
df_sales_orders_po_number_OK = df_sales_orders_po_number_OK.drop("PO_number_old")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1 -  Sales orders <-- Master material data <-- Profit center <-- Customers master date

# COMMAND ----------

df_sales_orders_trans = df_sales_orders_po_number_OK.join(
    other=df_mat_prep, on=JOIN_MATERIAL_SO, how="left"
)
df_sales_orders_trans = (
    df_sales_orders_trans.join(other=df_pc_prep, on=JOIN_PC_SO, how="left")
    .drop("Profit_Center")
    .withColumnRenamed("profit_Center_short", "profit_center")
)
df_sales_orders_trans = df_sales_orders_trans.join(
    other=df_customer_prep, on=JOIN_CUSTOMER_SO, how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 4 -  Correct amounts 
# MAGIC In SAP, amounts have two decimals. However, amounts in some currencies have 3 digits.
# MAGIC In such case, the output table gives the wrong amount as it treats like if all amounts
# MAGIC have 2 digits. For example, an amount of 10,242TND is written 102,42 in the table we
# MAGIC extract from SAP. The number of digits per currency are in the table TCURX in SAP.
# MAGIC The aim of this function is to correct a column with amounts based on its currency
# MAGIC associated column and TCURX.

# COMMAND ----------

df_sales_orders_trans = amount_correction.create_corrected_amounts(
    df=df_sales_orders_trans, amount_col=VALUED_COLUMN, currency_col=CURRENCY_COLUMN
).withColumnRenamed(VALUED_COLUMN, f"{TABLE_PREFIX}_{VALUED_COLUMN}")

df_sales_orders_trans = df_sales_orders_trans.withColumnRenamed(
    f"{VALUED_COLUMN}_corrected", VALUED_COLUMN
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 5 -  Convert to EUR based on consolidation rate

# COMMAND ----------

today = f.to_date(f.now(), "yyyy-MM-dd")
df_sales_orders_trans = df_sales_orders_trans.withColumn(
    "currency_conversion_date", today
)

# COMMAND ----------

df_sales_orders_trans = table_utils.currency_conversion(
    df=df_sales_orders_trans,
    document_currency_column=f.col(CURRENCY_COLUMN),
    rate_types=["Consolidation"],
    rate_dates=[f.col("currency_conversion_date")],
    target_currency_value="EUR",
    document_amounts=[f.col(VALUED_COLUMN)],
    df_currency=df_cex_gold,
    reference_read_env="prod",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 6 -  Add Y-W and Y-M columns

# COMMAND ----------

df_sales_orders_trans = table_utils.add_week_number(
    df=df_sales_orders_trans, date_col=SD_DATE_COLUMN
)
df_sales_orders_trans = generate_monthly_date(
    df=df_sales_orders_trans, col=SD_DATE_COLUMN
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 7 -  columns in Lower case

# COMMAND ----------

df_sales_orders = df_sales_orders_trans.withColumnsRenamed(
    {col: conditional_lowercase(col) for col in df_sales_orders_trans.columns}
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

max_extraction_date = df_sales_orders.select(
    f.max("extraction_date")
).first()[0]

df_sales_orders_latest = df_sales_orders.filter(
    f.col("extraction_date") == max_extraction_date
)

# COMMAND ----------

# Save Customer_orders Gold Latest
table_utils.save_table(df=df_sales_orders_latest, dest_table=dest_table_latest, mode="overwrite")

# Save Customer_orders Proj history
table_utils.save_table(dest_table=dest_table_history, df=df_sales_orders, mode=MODE, merge_schema=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Customer_orders - Proj history Exposed & Gold exposed

# COMMAND ----------

ORDER_COLUMNS = ["business_ID", "sales_document", "SD_item"]
select_statement = ",".join(
    ORDER_COLUMNS
    + [
        col
        for col in df_sales_orders.columns
        if not (col.upper().startswith(TABLE_PREFIX)) and col not in ORDER_COLUMNS
    ]
)

# Save latest exposed
table_utils.create_table_view(
    src_full_tablename=dest_table_latest,
    dest_full_tablename=f"{dest_table_latest}_exposed",
    select_statement=select_statement,
    replace_view=True,
)

# Save history exposed
table_utils.create_table_view(
    src_full_tablename=dest_table_history,
    dest_full_tablename=f"{dest_table_history}_exposed",
    select_statement=select_statement,
    replace_view=True,
)
