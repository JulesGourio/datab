# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Customer orders : Silver data asset
# MAGIC
# MAGIC
# MAGIC **Description**
# MAGIC Customer orders is mandatory to analyse and understand the client demand trends. A view combining the main tables in the Sales document module exists and is called `wb2vvbakvbap2_latest`. It is based on these 2 SAP tables:
# MAGIC - VBAK
# MAGIC - VBAP (sales document item)
# MAGIC
# MAGIC
# MAGIC **Confluence Documentation**
# MAGIC - http://confluence.lat.corp:8090/display/LEAP/Data+asset+CUSTOMER+ORDERS
# MAGIC
# MAGIC **Input Tables Pipeline:**
# MAGIC None
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {reference_read_env}_bronze.headers_sap.header_business_wb2vvbakvbap2
# MAGIC - {reference_read_env}_bronze.sap_latecoere_ecc6.wb2vvbakvbap2_latest
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.order_to_cash.customer_order
# MAGIC
# MAGIC The PK (Primary Key) of the output data asset is `(sales_document, SD_item)`
# MAGIC
# MAGIC **Related job Pipeline**
# MAGIC - D_X_SAP_Customer_Order_History_Data_Asset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

# Logging imports
from leap_utils.common import logger

# gx
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### LOG LEVEL
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC - Business header: **``df_sales_orders_header``** business header to use to cast and rename columns
# MAGIC - Sales orders: **``df_sales_orders_raw``**  is a view in SAP that joins data from the sales document header (VBAK) and sales document item (VBAP) tables to facilitate reporting and analysis of sales order information.

# COMMAND ----------

df_sales_orders_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_wb2vvbakvbap2"
)
df_sales_orders_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.wb2vvbakvbap2_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

TABLE_PREFIX = "WB2_V_VBAK_VBAP2"

# Inputs related to historisation
catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "order_to_cash"
table = "customer_order"
dest_table = f"{catalog}.{domain}.{table}"

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC ## Preparation to filter silver history

# COMMAND ----------

df_sales_orders_raw = df_sales_orders_raw.withColumn(
    "extraction_date", f.col("extraction_timestamp").cast("date")
)
df_sales_orders_raw = df_sales_orders_raw.drop("extraction_timestamp")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 -  Rename and Cast with header
# MAGIC

# COMMAND ----------

df_sales_orders_prep = table_utils.add_prefix_to_columns(
    df_sales_orders_raw, TABLE_PREFIX
)
df_sales_orders_prep = table_utils.rename_columns_with_sap_business_header(
    df_sales_orders_prep, df_sales_orders_header
)
df_sales_orders_prep = table_utils.cast_columns_with_sap_business_headers(
    df_sales_orders_prep, df_sales_orders_header
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 -  Filter on Customer orders
# MAGIC in the document category we have a couple of sales document, namely return delivery, invoice, item proposal...

# COMMAND ----------

df_sales_orders_prep = df_sales_orders_prep.filter(f.col("SD_category") == f.lit("C"))
log.info(f"count of rows: {str(df_sales_orders_prep.count())}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparation 3 - Remove Leading zero

# COMMAND ----------

# remove leading zeros
df_sales_orders_prep = table_utils.remove_leading_zeros(
    df=df_sales_orders_prep, column_names=["material_number"]
)

# COMMAND ----------

# Rename column
df_sales_orders_prep = df_sales_orders_prep.withColumnRenamed(
    "WB2_V_VBAK_VBAP2_extraction_date", "extraction_date"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Quality Check after Preparation
# MAGIC - Check the unicity of the sales/item doc

# COMMAND ----------

# Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
dfgx_In1_prep = gx.dataset.SparkDFDataset(df_sales_orders_prep, persist=False)

# Define the red quality checks
red_quality_check_results = [
    dfgx_In1_prep.expect_compound_columns_to_be_unique(
        column_list=["sales_document", "SD_item"]
    ),
]

# Validate all red quality checks, if at least one fails the job stops
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="There's no duplicated rows and col_a doesn't have any null value",
    error_message="At least one red quality checks is KO, the job has stopped, check corresponding results",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="customer_orders_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables - Customer_orders silver

# COMMAND ----------

table_utils.save_table(dest_table=dest_table, df=df_sales_orders_prep, mode="overwrite")
