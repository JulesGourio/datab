# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC Produce a single dataset (qpl_base) that shows which final profit centers will consume each material reference. To determine final consumers we take future demand (open PO/PR quantities) and prorate that demand across consuming profit centers using the material-plant allocation percentages (PF_pourcentage_affectation).
# MAGIC
# MAGIC **Key processing steps:**
# MAGIC - Read active PO and PR records from the reference environment.
# MAGIC - Enrich with material master (plant allocation percentages) and exploded profit center allocations.
# MAGIC - Add profit center descriptive fields and compute the prorated quantity usage.
# MAGIC
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.quality.qpl_base
# MAGIC
# MAGIC
# MAGIC **Inputs:**
# MAGIC   - {REFERENCE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_and_requests_sap_stacked
# MAGIC   - {REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.profit_center_exposed
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# Get read environment variable
dbutils.widgets.text("REFERENCE_READ_ENV", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("REFERENCE_READ_ENV")
# Get write environment variable
dbutils.widgets.text("PIPELINE_READ_ENV", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("PIPELINE_READ_ENV")
# Get write environment variable
dbutils.widgets.text("PIPELINE_WRITE_ENV", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("PIPELINE_WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC Load source tables required for the pipeline. These are read using the configured REFERENCE_READ_ENV prefix.
# MAGIC - Purchase Orders (PO): filtered later to keep in-progress statuses only.
# MAGIC - Purchase Requests (PR): filtered later to keep open PRs only.
# MAGIC - Profit Center master for descriptive names.
# MAGIC - Material-plant master for allocation percentages.
# MAGIC - SAP Bronze characteristic tables for part classification.

# COMMAND ----------

selected_po_pr_col = [
    "material_number",
    "contract_number",
    f.col("plant_delivered").alias("plant"),
    f.col("quantity_remaining").alias("qty"),
    "supplier_code",
    "delivery_date_planned",
    "supplier_name",
    "profit_center",
]

df_pr_po = (
    spark.read.table(
        f"{REFERENCE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_and_requests_sap_stacked"
    )
    .filter(f.col("document_status") == "Doc_Open")
    .select(*selected_po_pr_col)
)

df_inprogress = table_utils.remove_leading_zeros(df_pr_po, ["material_number"])

# COMMAND ----------

# Add name Profit Center
df_pc = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
).select(
    f.col("Profit_Center_short").alias("profit_center_affectation"),
    f.col("Short_Description").alias("PC_description"),
    f.col("Customer_Group").alias("customer"),
)

# COMMAND ----------

df_mat = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
).select(
    "material_number",
    "plant",
    "material_description",
    "material_type",
    "division",
    "region",
    "PF_pourcentage_affectation",
    "familly_std",
    "classe_std",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC 1. Expand material allocation percentages (PF_pourcentage_affectation) to one row per profit center allocation.
# MAGIC 2. Enrich with material characteristics (family / class flags) from Bronze SAP attributes.
# MAGIC 3. Join profit center descriptive text and compute prorated quantity usage by allocation percentage.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get profit center consumptions

# COMMAND ----------

# Explode dictionnary
df_mat_explode = df_mat.select(
    f.col("*"),
    f.explode_outer(f.col("PF_pourcentage_affectation")).alias(
        "profit_center_affectation", "profit_center_affectation_pourcentage"
    ),
)
df_mat_explode = df_mat_explode.withColumn(
    "profit_center_affectation_pourcentage",
    f.when(f.col("profit_center_affectation_pourcentage").isNull(), f.lit(1)).otherwise(
        f.col("profit_center_affectation_pourcentage")
    ),
).drop("PF_pourcentage_affectation")

df_mat_explode = df_mat_explode.dropDuplicates()
df_mat_explode = table_utils.remove_leading_zeros(df_mat_explode, ["material_number"])
# -----------------------------------------------------------------
df_end = df_inprogress.join(df_mat_explode, ["material_number", "plant"], "left")
# -----------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add profit center name

# COMMAND ----------

df_qpl = df_end.join(df_pc, ["profit_center_affectation"], "left")
df_qpl = df_qpl.withColumn(
    "PC_desc",
    f.concat_ws(" - ", f.col("profit_center_affectation"), f.col("PC_description")),
)
df_qpl = df_qpl.withColumn(
    "quantity_usage", f.col("qty") * f.col("profit_center_affectation_pourcentage")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Table QPL BASE

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "quality"
DESTINATION_TABLE = "qpl_base"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_qpl,
    mode="overwrite",
    overwrite_schema=True,
)
