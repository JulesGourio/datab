# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim of this notebook is to create the silver table of Non Conformities based on ENC tables. 
# MAGIC - Cleaning of data format
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {REFERENCE_READ_ENV}_silver.enc.nonconformities_latest
# MAGIC   - {REFERENCE_READ_ENV}_silver.enc.nonconformityfamilies_latest
# MAGIC   - {REFERENCE_READ_ENV}_silver.enc.nonconformitysubfamilies_latest
# MAGIC   - {REFERENCE_READ_ENV}_silver.enc.products_latest
# MAGIC   - {REFERENCE_READ_ENV}_gold.quality.sites_enc
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.profit_center_exposed
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.quality.non_conformities_enc
# MAGIC   
# MAGIC **Triggered by:** 
# MAGIC Data asset - Non Conformities

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f
import datetime

from dateutil.relativedelta import relativedelta
from leap_utils.data_asset import table_utils

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Inputs

# COMMAND ----------

previous_year = (datetime.datetime.today() - relativedelta(months=1)).year - 1

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

df_nonconformities_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.quality.non_conformities_enc"
)

df_nonconformityfamilies_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.quality.non_conformity_families_enc"
)

df_nonconformitysubfamilies_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.quality.non_conformity_subfamilies_enc"
)

df_products_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.quality.products_enc"
)

df_sites_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.quality.sites_enc"
)

df_profit_center_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Inputs - Manual declaration

# COMMAND ----------

SITES_COLUMNS = [
    "site_id",
    "site",
    "division",
    "region",
]

PROFIT_CENTER_COLUMNS = [
    "profit_center_short",
    "short_description",
    "Customer_group"
]

# COMMAND ----------

OUTPUT_SILVER_TABLE_NON_CONFORMITIES  = (
    f"{PIPELINE_WRITE_ENV}_gold.quality.non_conformities_enc"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

df_sites_prep = df_sites_raw.select(SITES_COLUMNS)

df_profit_center_prep = (
    df_profit_center_raw.select(PROFIT_CENTER_COLUMNS)
    .withColumnRenamed("short_description", "profit_center_description")
    .withColumn(
        "profit_center_code_desc",
        f.concat_ws(" - ", f.col("profit_center_short"), f.col("profit_center_description")),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Joins

# COMMAND ----------

df_non_conformities_enc_final = (
    df_nonconformities_raw.join(
        df_nonconformityfamilies_raw, on="family_id", how="left"
    )
    .join(df_nonconformitysubfamilies_raw.drop("family_id"), on="subfamily_id", how="left")
    .join(df_products_raw, on="product_id", how="left")
    .join(
        df_sites_prep,
        on=df_nonconformities_raw.detection_site_id == df_sites_prep.site_id,
        how="left",
    )
    .drop("site_id")
    .withColumnsRenamed(
        {
            "site": "detection_site",
            "division": "detection_division",
            "region": "detection_region",
        }
    )
    .join(
        df_sites_prep,
        on=df_nonconformities_raw.imputed_site_id == df_sites_prep.site_id,
        how="left",
    )
    .drop("site_id")
    .withColumnsRenamed(
        {
            "site": "imputed_site",
            "division": "imputed_division",
            "region": "imputed_region",
        }
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Add columns intersite and code_nc

# COMMAND ----------

df_non_conformities_enc_final = df_non_conformities_enc_final.withColumn(
    "intersite",
    f.when(f.col("detection_site") == f.col("imputed_site"), "Internal").otherwise(
        "External"
    ),
).withColumn(
    "code_nc", f.concat_ws(" ", f.col("family_value"), f.col("subcategory"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr3 - Join with Profit Center SAP

# COMMAND ----------

df_non_conformities_enc_final = df_non_conformities_enc_final.join(
    df_profit_center_prep,
    on=df_non_conformities_enc_final.profit_center
    == df_profit_center_prep.profit_center_short,
    how="left",
).drop("profit_center_short")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 4 - Drop useless columns

# COMMAND ----------

LIST_COL_NOT_EXPOSED = [
    col for col in df_non_conformities_enc_final.columns if col.startswith("_")
]

df_non_conformities_enc_final = df_non_conformities_enc_final.drop(
    *LIST_COL_NOT_EXPOSED
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 5 - Add week number creation date

# COMMAND ----------

df_non_conformities_enc_final = table_utils.add_week_number(
    df_non_conformities_enc_final, "creation_date"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 6 - Filter on two last years

# COMMAND ----------

df_non_conformities_enc_final = df_non_conformities_enc_final.filter(
    f.year(f.col("creation_date")) >= previous_year
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 7 - Cleaning

# COMMAND ----------

df_non_conformities_enc_final = df_non_conformities_enc_final.withColumn(
    "is_family_valid",
    f.when(f.col("is_family_valid").isNull(), False).otherwise(
        f.col("is_family_valid")
    ),
).withColumn(
    "is_subfamily_valid",
    f.when(f.col("is_subfamily_valid").isNull(), False).otherwise(
        f.col("is_subfamily_valid")
    ),
).withColumn(
    "is_critical",
    f.when(f.col("is_critical").isNull(), False).otherwise(
        f.col("is_critical")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality Check

# COMMAND ----------

df_to_check = df_non_conformities_enc_final
columns_to_check = [
    "is_already_printed",
    "is_customer_complaint",
    "is_feedback",
    "is_deleted",
    "is_monitoring_type",
    "is_only_for_booking",
    "is_self_inspection",
    "is_family_valid",
    "is_critical",
    "is_subfamily_valid",
]

df_gx = SparkDFDataset(df_to_check, persist=False)

for col_to_check in columns_to_check:
    quality_check_result = df_gx.expect_column_values_to_be_in_set(
        column=col_to_check, value_set=[True, False]
    )

    gx_validation.validate_and_log_gx_results(
        quality_check_results=[quality_check_result],
        validation_level="RED",
        info_message=f"Boolean only found in {col_to_check}",
        error_message=f"No boolean values found in {col_to_check}, check the summary of this run",
        pipeline_write_env=PIPELINE_WRITE_ENV,
        table_name="non_conformities_enc_gold",
        log_to_event_table=True,
        log_successes=True,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    OUTPUT_SILVER_TABLE_NON_CONFORMITIES, df_non_conformities_enc_final, "overwrite", True
)
