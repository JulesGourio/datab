# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The goal of this notebook is to create the silver table of non conformity sub families based on ENC data. 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - {REFERENCE_READ_ENV}_bronze.enc.nonconformitysubfamilies_latest
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_silver.quality.non_conformity_subfamilies_enc
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Data asset - Non Conformities

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Input table

# COMMAND ----------

df_sites_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.enc.sites_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

SITES_COLUMNS_RENAME = {
    "siteid": "site_id",
    "isactive": "is_site_active",
    "name": "site_name",
    "trigram": "site_trigram",
    "lanip": "lan_ip",
    "wifiip": "wifi_ip",
}

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Renaming columns

# COMMAND ----------

df_sites_final = df_sites_raw.withColumnsRenamed(SITES_COLUMNS_RENAME)

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_silver.quality.sites_enc",
    df=df_sites_final,
    mode="overwrite",
    overwrite_schema=True,
)
