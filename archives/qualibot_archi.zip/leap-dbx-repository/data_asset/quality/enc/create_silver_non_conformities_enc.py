# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The goal of this notebook is to create the silver table of non conformities based on ENC data. 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - {REFERENCE_READ_ENV}_bronze.enc.nonconformities_latest
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_silver.quality.non_conformities_enc
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Data asset - Non Conformities

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

import pyspark.sql.functions as f

from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Input table

# COMMAND ----------

df_non_conformities_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.enc.nonconformities_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

NON_CONFORMITIES_COLUMNS_RENAME = {
    "alreadyprinted": "is_already_printed",
    "createdby": "created_by",
    "creationdate": "creation_date",
    "customercomplaint": "is_customer_complaint",
    "customerreference": "customer_reference",
    "deletionmessage": "deletion_message",
    "detectionsiteid": "detection_site_id",
    "familyid": "family_id",
    "feedback": "is_feedback",
    "formfilepath": "form_file_path",
    "imputationsiteid": "imputed_site_id",
    "imputationdate": "imputed_date",
    "isdeleted": "is_deleted",
    "lastmodificationdate": "last_modification_date",
    "lastmodificationuserid": "last_modification_user_id",
    "monitoringtype": "is_monitoring_type",
    "nonconformityid": "non_conformity_id",
    "nonconformitykey": "non_conformity_key",
    "onlyforbooking": "is_only_for_booking",
    "phasenumber": "phase_number",
    "printpage": "print_page",
    "productid": "product_id",
    "selfinspection": "is_self_inspection",
    "serialnumber": "serial_number",
    "subfamilyid": "subfamily_id",
}

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Renaming columns

# COMMAND ----------

df_non_conformities_final = df_non_conformities_raw.withColumnsRenamed(NON_CONFORMITIES_COLUMNS_RENAME)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Cleaning

# COMMAND ----------

df_non_conformities_final = df_non_conformities_final.withColumn(
    "is_already_printed",
    f.when(f.col("is_already_printed").isNull(), False).otherwise(
        f.col("is_already_printed")
    ),
).withColumn(
    "is_monitoring_type",
    f.when(f.col("is_monitoring_type").isNull(), False).otherwise(
        f.col("is_monitoring_type")
    ),
)

# COMMAND ----------

df_non_conformities_final = df_non_conformities_final.select(
    [
        f.when(f.col(c) == "", None).otherwise(f.col(c)).alias(c)
        for c in df_non_conformities_final.columns
    ]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_silver.quality.non_conformities_enc",
    df=df_non_conformities_final,
    mode="overwrite",
    overwrite_schema=True,
)
