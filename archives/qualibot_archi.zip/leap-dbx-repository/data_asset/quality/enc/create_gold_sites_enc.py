# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The goal of this notebook is to create the gold table of sites based on ENC data. 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - {PIPELINE_READ_ENV}_silver.quality.sites_enc
# MAGIC - {REFERENCE_READ_ENV}_bronze.manual_input.mapping_sites
# MAGIC - {REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_gold.quality.sites_enc
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Data asset - Non Conformities

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

from leap_utils.data_asset import table_utils
import pyspark.sql.functions as f

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Input table

# COMMAND ----------

df_sites_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.quality.sites_enc"
)

# COMMAND ----------

df_mapping_sites_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_sites"
)
df_mapping_site_division_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

LIST_COL_NOT_EXPOSED = [col for col in df_sites_silver.columns if col.startswith("_")]

# COMMAND ----------

# MAGIC %md
# MAGIC # Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep1 - Selecting columns

# COMMAND ----------

df_mapping_sites_raw = df_mapping_sites_raw.select("site", "site_from_enc")

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Get site, division and region

# COMMAND ----------

df_sites_gold = (
    df_sites_silver.join(
        df_mapping_sites_raw,
        on=df_sites_silver.site_name == df_mapping_sites_raw.site_from_enc,
        how="left",
    )
    .drop(df_sites_silver.site_name, df_mapping_sites_raw.site_from_enc)
    .withColumn("site", f.coalesce(f.col("site"), f.lit("LXXX - TBD")))
    .join(df_mapping_site_division_raw, on="site", how="left")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 2 - Replace trigram MEX by HER

# COMMAND ----------

df_sites_gold = df_sites_gold.withColumn(
    "site_trigram",
    f.when(f.col("site_trigram") == "MEX", f.lit("HER")).otherwise(
        f.col("site_trigram")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr 3 - Drop useless columns

# COMMAND ----------

df_sites_gold = df_sites_gold.drop(*LIST_COL_NOT_EXPOSED)

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.quality.sites_enc",
    df=df_sites_gold,
    mode="overwrite",
    overwrite_schema=True,
)
