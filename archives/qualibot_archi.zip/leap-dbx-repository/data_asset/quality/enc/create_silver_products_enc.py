# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The goal of this notebook is to create the silver table of products based on ENC data. 
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC - {REFERENCE_READ_ENV}_bronze.enc.products_latest
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC - {PIPELINE_WRITE_ENV}_silver.quality.products_enc
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Data asset - Non Conformities

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

import pyspark.sql.functions as f

from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##Input table

# COMMAND ----------

df_products_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.enc.products_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

PRODUCTS_COLUMNS_RENAME = {
    "productid": "product_id",
    "launchcode": "launch_code",
    "program": "profit_center",
}

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Renaming columns

# COMMAND ----------

df_products_final = df_products_raw.withColumnsRenamed(PRODUCTS_COLUMNS_RENAME)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Cleaning

# COMMAND ----------

df_products_final = table_utils.remove_leading_zeros(
    df_products_final, ["profit_center", "launch_code"]
)

# COMMAND ----------

df_products_final = df_products_final.select(
    [
        f.when(f.col(c) == "", None).otherwise(f.col(c)).alias(c)
        for c in df_products_final.columns
    ]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_silver.quality.products_enc",
    df=df_products_final,
    mode="overwrite",
    overwrite_schema=True,
)
