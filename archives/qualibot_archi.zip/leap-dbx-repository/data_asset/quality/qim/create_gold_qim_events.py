# Databricks notebook source
# DBTITLE 1,Notebook header
# MAGIC %md
# MAGIC
# MAGIC # CREATE GOLD QIM EVENTS
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC Creates the gold table for QIM audit events. Enriches silver events with document reference (from documents_qim_exposed), converts YES/NO columns to boolean, and adds site/division/region from mapping tables.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Quality - QIM
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver.quality.events_qim
# MAGIC - {pipeline_read_env}_gold.quality.documents_qim_exposed
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {reference_read_env}_bronze.manual_input.mapping_sites
# MAGIC - {reference_read_env}_bronze.manual_input.mapping_site_division_region
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.quality.events_qim
# MAGIC - {pipeline_write_env}_gold.quality.events_qim_exposed (view)
# MAGIC

# COMMAND ----------

# DBTITLE 1,Technical Debt
# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC N/A

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f

# COMMAND ----------

# DBTITLE 1,Config LEAP Function Imports
# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

# LEAP FUNCTION
from leap_utils.data_asset import table_utils, business_rules
from leap_utils.common.validation import gx_validation
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# DBTITLE 1,Config Widgets
# MAGIC %md
# MAGIC ## Config Widgets
# MAGIC
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# DBTITLE 1,Debug Boolean
# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Config logger
# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config Common Functions
# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Config other
# MAGIC %md
# MAGIC ## Config other
# MAGIC
# MAGIC N/A - No additional configuration needed for this gold notebook.

# COMMAND ----------

# DBTITLE 1,Inputs
# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# DBTITLE 1,Inputs - Functions
# MAGIC %md
# MAGIC ## Inputs - Functions
# MAGIC
# MAGIC | Function | Description |
# MAGIC |---|---|
# MAGIC | `format_employee_id(col_expr)` | Normalises an employee ID column expression to `L0XXXXXXX` format. IDs already starting with `L` are kept as-is. Null/empty values return null. |

# COMMAND ----------

def format_employee_id(col_expr):
    """Normalises an employee ID to L0XXXXXXX format (prefix L + 7-digit left-padded numeric part).
    IDs already starting with L are kept as-is. Null/empty values return null.
    """
    trimmed = f.trim(col_expr)
    return f.when(
        col_expr.isNotNull() & (trimmed != ""),
        f.when(trimmed.startswith("L"), trimmed).otherwise(
            f.concat(f.lit("L"), f.lpad(trimmed, 7, "0"))
        ),
    )

# COMMAND ----------

# DBTITLE 1,Inputs - LEAP tables
# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# DBTITLE 1,Import silver QIM events
# MAGIC %md
# MAGIC ### Import Silver QIM Events
# MAGIC
# MAGIC **df_events** is the silver QIM events table. Contains cleaned, renamed, and deduplicated audit event records.
# MAGIC

# COMMAND ----------

df_events = spark.read.table(f"{PIPELINE_READ_ENV}_silver.quality.events_qim")

# COMMAND ----------

# DBTITLE 1,Import QIM documents exposed
# MAGIC %md
# MAGIC ### Import QIM Documents Exposed
# MAGIC
# MAGIC **df_docs_exposed** is the gold exposed view of QIM documents. Used to enrich events with the document `reference` and `creation_date` columns.

# COMMAND ----------

# DBTITLE 1,Cell 24
df_docs_exposed = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.quality.documents_qim_exposed"
)

# COMMAND ----------

# DBTITLE 1,Import mapping_sites
# MAGIC %md
# MAGIC ### Import Mapping Sites
# MAGIC
# MAGIC **df_mapping_sites** maps QIM site abbreviations (`site_from_qim`) to standard site names (`site`).

# COMMAND ----------

df_mapping_sites = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_sites"
)

# COMMAND ----------

# DBTITLE 1,Import mapping_site_division_region
# MAGIC %md
# MAGIC ### Import Mapping Site Division Region
# MAGIC
# MAGIC **df_mapping_division_region** maps standard site names to `division` and `region`.

# COMMAND ----------

df_mapping_division_region = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region"
)

# COMMAND ----------

# DBTITLE 1,Import SAP Users Exposed
# MAGIC %md
# MAGIC ### Import HR Workforce
# MAGIC
# MAGIC **_df_workforce** is the gold HR workforce monthly view. Used to resolve employee ID codes to full names.
# MAGIC

# COMMAND ----------

_df_workforce = spark.read.table(
    "sd_prod_gold.hr.hr_workforce_gold_finance_view_monthly"
)

# COMMAND ----------

# DBTITLE 1,Inputs - File Read
# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Inputs - Manual declaration
# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Data Preparation
# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# DBTITLE 1,Preparation - Common Functions
# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Prep 1 - df_docs_exposed
# MAGIC %md
# MAGIC ## Preparation 1 - df_docs_exposed
# MAGIC
# MAGIC Select only `qim_ID`, `reference`, and `creation_date` columns needed for the join. Rename `reference` to `document_reference` to avoid ambiguity.

# COMMAND ----------

df_docs_ref = df_docs_exposed.select("qim_ID", "reference", "creation_date")

# COMMAND ----------

# DBTITLE 1,Prep 2 - df_docs_ref_prev
# MAGIC %md
# MAGIC ## Preparation 2 - df_docs_ref_prev
# MAGIC
# MAGIC Select `qim_ID` and `event_reference` from `df_docs_ref`, renaming them to `previous_event_ID` and `previous_event_reference` for use in Tr 2.

# COMMAND ----------

df_docs_ref_prev = df_docs_ref.select(
    f.col("qim_ID").alias("previous_event_ID"),
    f.col("reference").alias("previous_event_reference"),
)

# COMMAND ----------

# DBTITLE 1,Prep 3 - df_users_hr
# MAGIC %md
# MAGIC    
# MAGIC    
# MAGIC ## Preparation 3 - df_users_hr
# MAGIC
# MAGIC Filter `_df_workforce` to the most recent extraction date, derive `employee_ID` (`L0XXXXXXX` format from `User_ID`) and `full_name` (`First_name` + `Last_name`). Used in Tr 10 to resolve employee ID codes to full names.

# COMMAND ----------

# Keep only the most recent extraction date
_max_date = _df_workforce.agg(f.max("_leap_extraction_date")).first()[0]

df_users_hr = (
    _df_workforce.filter(f.col("_leap_extraction_date") == _max_date)
    .select("User_ID", "First_name", "Last_name")
    .dropDuplicates()
    .withColumn("full_name", f.concat_ws(" ", f.col("First_name"), f.col("Last_name")))
    .withColumn("employee_ID", f.concat(f.lit("L"), f.lpad(f.col("User_ID"), 7, "0")))
    .select("employee_ID", "full_name")
)

# COMMAND ----------

# DBTITLE 1,Quality Check after Preparation
# MAGIC %md
# MAGIC #### Quality Check after Preparation
# MAGIC
# MAGIC N/A

# COMMAND ----------

# DBTITLE 1,Data Transformations
# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# DBTITLE 1,Tr1 - Join with QIM documents
# MAGIC %md
# MAGIC ### Tr 1 - Join with QIM Documents
# MAGIC
# MAGIC Enrich events with `event_reference` and `creation_date` from `df_docs_ref`. Inner join on `qim_ID` (only matched records are kept).

# COMMAND ----------

# DBTITLE 1,Cell 47
# Inner join to enrich events with document reference
df_events_transf = (
    df_events.join(df_docs_ref, on="qim_ID", how="inner")
    .withColumnRenamed("reference", "event_reference")
)

# COMMAND ----------

# DBTITLE 1,Tr2 - Previous Event Document Reference
# MAGIC %md
# MAGIC ### Tr 2 - Add Previous Event Document Reference
# MAGIC
# MAGIC Left join on `previous_event_ID` with `df_docs_ref_prev` to retrieve the `event_reference` of the linked previous event. Result stored in `previous_event_reference`. Rows without a previous event remain null.

# COMMAND ----------

# Enrich events with the document_reference of the previous event
df_events_transf = df_events_transf.join(
    df_docs_ref_prev, on="previous_event_ID", how="left"
)

# COMMAND ----------

# DBTITLE 1,Tr2 - YES/NO to boolean
# MAGIC %md
# MAGIC ### Tr 3 - Convert YES/NO columns to boolean
# MAGIC
# MAGIC Convert string columns with "Yes"/"No" values to proper boolean type.

# COMMAND ----------

# Columns with Yes/No values to convert to boolean
yes_no_cols = ["is_periodic", "is_step2_validated", "is_questionnaire_needed"]

df_events_transf = df_events_transf.withColumns(
    {
        col_name: f.when(f.upper(f.col(col_name)) == "YES", f.lit(True))
        .when(f.upper(f.col(col_name)) == "NO", f.lit(False))
        .otherwise(None)
        for col_name in yes_no_cols
    }
)

# COMMAND ----------

# DBTITLE 1,Tr3 - Convert semicolons to arrays
# MAGIC %md
# MAGIC ### Tr 4 - Convert semicolon-separated columns to arrays
# MAGIC
# MAGIC Multi-value columns stored as `"A;B;C"` strings are converted to proper `array<string>` type using `split()`.

# COMMAND ----------

# Multi-value columns that use ";" as separator — convert to array<string>
array_cols = [
    "auditor_ref_codes",
    "auditor_ref_names",
    "auditor_ref_index",
    "audited_ref_codes",
    "users_distribution",
    "auditors",
    "profit_center",
    "customers",
    "questionnaires",
    "process",
    "process_code",
]

df_events_transf = df_events_transf.withColumns(
    {col_name: f.split(f.col(col_name), ";") for col_name in array_cols}
)

# COMMAND ----------

# DBTITLE 1,Tr3 - Site, Division, Region
# MAGIC %md
# MAGIC ### Tr 5 - Add Impacted Site Name, Division and Region
# MAGIC
# MAGIC Uses `business_rules.add_site_region_division` with `domain="qn"` to enrich `impacted_site` with its conventional name (`impacted_site_name`), division (`impacted_division`) and region (`impacted_region`). Special cases applied after mapping:
# MAGIC - `FRN` — no entry in mapping table; name, division and region are all set directly to `"Supplier"`.
# MAGIC - `LFR-T` — mapped name override: `"LATE - Mach1"` (mapping returns `"LATE Montredon"`); division and region kept from mapping.
# MAGIC
# MAGIC `impacted_site` is dropped after the mapping is resolved.
# MAGIC
# MAGIC Any remaining null values in `impacted_site`, `impacted_division` and `impacted_region` (unmatched site codes) are filled with `"Unassigned"`.

# COMMAND ----------

# DBTITLE 1,Cell 55
df_events_transf = business_rules.add_site_region_division(
    df=df_events_transf,
    site_col="impacted_site_qim",
    domain="qn",
    conventional_site_col="impacted_site",
    region_col="impacted_region",
    division_col="impacted_division",
    reference_read_env=REFERENCE_READ_ENV,
)

# Special cases after mapping:
#   FRN   → no mapping entry; name, division and region set to 'Supplier'
#   LFR-T → mapping returns 'LATE Montredon'; override name to 'LATE - Mach1' (specific for QIM)
df_events_transf = df_events_transf.withColumns(
    {
        "impacted_site": (
            f.when(f.col("impacted_site_qim") == "FRN", f.lit("Supplier"))
            .when(f.col("impacted_site_qim") == "LFR-T", f.lit("LATE - Mach1"))
            .otherwise(f.col("impacted_site"))
        ),
        "impacted_division": f.when(
            f.col("impacted_site_qim") == "FRN", f.lit("Supplier")
        ).otherwise(f.col("impacted_division")),
        "impacted_region": f.when(
            f.col("impacted_site_qim") == "FRN", f.lit("Supplier")
        ).otherwise(f.col("impacted_region")),
    }
)

# Replace nulls with "Unassigned" for the mapped columns
df_events_transf = df_events_transf.withColumns(
    {
        "impacted_site": f.coalesce(f.col("impacted_site"), f.lit("Unassigned")),
        "impacted_division": f.coalesce(f.col("impacted_division"), f.lit("Unassigned")),
        "impacted_region": f.coalesce(f.col("impacted_region"), f.lit("Unassigned")),
    }
)

# COMMAND ----------

# DBTITLE 1,Tr8 - Auditor Site Name
# MAGIC %md
# MAGIC ### Tr 6 - Add Auditor Site Name
# MAGIC
# MAGIC Enriches `auditor_site` (code) with its conventional name (`auditor_site_name`) using `business_rules.add_site_region_division` with `domain="qn"`. Only the site name is added — no division or region. Special cases applied after mapping:
# MAGIC - `FRN` — no entry in mapping_sites; set directly to `"Supplier"`.
# MAGIC - `LFR-T` — mapping returns `"LATE Montredon"`; overridden to `"LATE - Mach1"`.

# COMMAND ----------

# DBTITLE 1,Cell 57
df_events_transf = business_rules.add_site_region_division(
    df=df_events_transf,
    site_col="auditor_site_qim",
    domain="qn",
    conventional_site_col="auditor_site",
    reference_read_env=REFERENCE_READ_ENV,
)

# Drop division/region columns added as side-effect of the auditor site mapping
# (only impacted_division and impacted_region are needed)
df_events_transf = df_events_transf.drop("division", "region")

# Special cases after mapping:
#   FRN   → no mapping entry; set directly to 'Supplier'
#   LFR-T → mapping returns 'LATE Montredon'; override to 'LATE - Mach1' (specific for QIM)
# Fallback: if auditor_site is still null after mapping, use auditor_site_qim
df_events_transf = df_events_transf.withColumn(
    "auditor_site",
    f.when(f.col("auditor_site_qim") == "FRN", f.lit("Supplier"))
    .when(f.col("auditor_site_qim") == "LFR-T", f.lit("LATE - Mach1"))
    .otherwise(f.coalesce(f.col("auditor_site"), f.col("auditor_site_qim"))),
)

# Drop auditor_site_qim — naming is fully resolved via auditor_site
# df_events_transf = df_events_transf.drop("auditor_site_qim")

# COMMAND ----------

# DBTITLE 1,Tr6 - Clear closure_date for In Progress events
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 7 - Clear inherited `closure_date` and `conclusion`
# MAGIC
# MAGIC Periodic events inherit `closure_date` and `conclusion` from the previous event by mistake. These fields are only meaningful for terminal statuses.
# MAGIC
# MAGIC | Source status | Action | Rationale |
# MAGIC |---|---|---|
# MAGIC | `Closed` or `Canceled` | **Keep** | Terminal status — fields are always valid |
# MAGIC | `In progress` or `Postponed` | **Clear** | Confirmed inherited — event is still open |
# MAGIC
# MAGIC **In short:** `closure_date` and `conclusion` are kept only when the source system confirms closure (Closed or Canceled). All other statuses have these fields cleared unconditionally.

# COMMAND ----------

# Periodic events incorrectly carry over closure_date and conclusion from the previous event.
# Only terminal statuses (Closed, Canceled) keep these fields — all others are confirmed inherited.
_is_terminal = f.col("original_status").isin("Closed", "Canceled")

df_events_transf = df_events_transf.withColumns(
    {
        "closure_date": f.when(_is_terminal, f.col("closure_date")).otherwise(
            f.lit(None).cast("date")
        ),
        "conclusion": f.when(_is_terminal, f.col("conclusion")).otherwise(
            f.lit(None).cast("string")
        ),
    }
)

# COMMAND ----------

# DBTITLE 1,Tr6b - Computed status
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 8 - Computed Status
# MAGIC
# MAGIC Derives `computed_status` from actual date columns, independently of the source system `status` field:
# MAGIC
# MAGIC | Priority | Condition | Value |
# MAGIC |---|---|---|
# MAGIC | 1 | `original_status == 'Canceled'` | `Canceled` |
# MAGIC | 2 | `closure_date IS NOT NULL` | `Closed` |
# MAGIC | 3 | `start_date IS NOT NULL` and `expected_end_date < today` | `Overdue` |
# MAGIC | 3b | `start_date IS NULL` and `expected_start_date < today` | `Overdue` |
# MAGIC | 4 | `start_date IS NOT NULL` | `In Progress` |
# MAGIC | 5 | otherwise | `Not Started` |

# COMMAND ----------

df_events_transf = df_events_transf.withColumn(
    "computed_status",
    f.when(f.col("original_status") == "Canceled", f.lit("Canceled"))
    .when(f.col("closure_date").isNotNull(), f.lit("Closed"))
    .when(
        f.col("start_date").isNotNull()
        & f.col("expected_end_date").isNotNull()
        & (f.col("expected_end_date") < f.current_date()),
        f.lit("Overdue"),
    )
    .when(
        f.col("start_date").isNull()
        & f.col("expected_start_date").isNotNull()
        & (f.col("expected_start_date") < f.current_date()),
        f.lit("Overdue"),
    )
    .when(f.col("start_date").isNotNull(), f.lit("In Progress"))
    .otherwise(f.lit("Not Started")),
)

# COMMAND ----------

# DBTITLE 1,Tr7 - Calendar dates
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 9 - Calendar Dates
# MAGIC
# MAGIC Derives unified reference dates for calendar/BI use, preferring actual dates over expected ones:
# MAGIC
# MAGIC | Column | Logic |
# MAGIC |---|---|
# MAGIC | `calculated_start_date` | `COALESCE(start_date, expected_start_date)` — applies to all statuses |
# MAGIC | `calculated_end_date` | `COALESCE(closure_date, expected_end_date)` when Closed — `expected_end_date` for all other statuses |

# COMMAND ----------

df_events_transf = df_events_transf.withColumns(
    {
        # Best available start date — actual if present, otherwise expected
        "calculated_start_date": f.coalesce(
            f.col("start_date"), f.col("expected_start_date")
        ),
        # Best available end date — actual closure if Closed, otherwise expected end
        "calculated_end_date": f.when(
            f.col("original_status") == "Closed",
            f.coalesce(f.col("closure_date"), f.col("expected_end_date")),
        ).otherwise(f.col("expected_end_date")),
    }
)

# COMMAND ----------

# DBTITLE 1,Tr9 - Resolve Employee IDs to Names
# MAGIC %md
# MAGIC ### Tr 10 - Resolve Employee IDs to Full Names
# MAGIC
# MAGIC Replaces employee ID codes in `lead_auditor`, `validator` and `auditors` (array) with the corresponding `full_name` from the SAP users table.
# MAGIC
# MAGIC IDs are first normalised to `L0XXXXXXX` format (prefix `L` + 7-digit left-padded numeric part) before joining on `employee_ID`. IDs already in `L*` format are kept as-is. Unmatched IDs fall back to the formatted ID string.

# COMMAND ----------

df_users_lookup = df_users_hr.select("employee_ID", "full_name")

# --- Scalar: lead_auditor ---
df_events_transf = df_events_transf.withColumn(
    "lead_auditor", format_employee_id(f.col("lead_auditor"))
)
log.info("LEFT JOIN: lead_auditor → full_name (unmatched IDs kept as-is)")
df_events_transf = (
    df_events_transf.join(
        df_users_lookup.select(
            f.col("employee_ID").alias("lead_auditor"), f.col("full_name").alias("_la")
        ),
        on="lead_auditor",
        how="left",
    )
    .withColumn("lead_auditor", f.coalesce(f.col("_la"), f.col("lead_auditor")))
    .drop("_la")
)

# --- Scalar: validator ---
df_events_transf = df_events_transf.withColumn(
    "validator", format_employee_id(f.col("validator"))
)
log.info("LEFT JOIN: validator → full_name (unmatched IDs kept as-is)")
df_events_transf = (
    df_events_transf.join(
        df_users_lookup.select(
            f.col("employee_ID").alias("validator"), f.col("full_name").alias("_val")
        ),
        on="validator",
        how="left",
    )
    .withColumn("validator", f.coalesce(f.col("_val"), f.col("validator")))
    .drop("_val")
)

# --- Array: format IDs first ---
df_events_transf = df_events_transf.withColumn(
    "auditors", f.transform(f.col("auditors"), format_employee_id)
)

# --- Array: explode → join → collect_list (qim_ID is the validated PK) ---
log.info("LEFT JOIN: auditors array → full_name (unmatched IDs kept as-is)")
df_auditors_names = (
    df_events_transf.select(
        "qim_ID", f.explode_outer(f.col("auditors")).alias("_eid")
    )
    .filter(f.col("_eid").isNotNull())
    .join(
        df_users_lookup.select(
            f.col("employee_ID").alias("_eid"),
            f.col("full_name").alias("_name"),
        ),
        on="_eid",
        how="left",
    )
    .withColumn("_resolved", f.coalesce(f.col("_name"), f.col("_eid")))
    .groupBy("qim_ID")
    .agg(f.collect_list("_resolved").alias("auditors"))
)

df_events_transf = (
    df_events_transf.drop("auditors")
    .join(df_auditors_names, on="qim_ID", how="left")
)

# Fill nulls for resolved columns
df_events_transf = df_events_transf.withColumns({
    "lead_auditor": f.coalesce(f.col("lead_auditor"), f.lit("Unassigned")),
    "supplier_name": f.coalesce(f.col("supplier_name"), f.lit("Unassigned")),
})

# COMMAND ----------

# DBTITLE 1,Tr 11 - Overdue Tagging
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 11 - Overdue Tagging
# MAGIC
# MAGIC Adds overdue classification columns based on `closure_date` vs `expected_end_date`:
# MAGIC - `overdue_tag` — detailed tag with buckets
# MAGIC - `overdue_tag_label` — binary: On Time / Overdue
# MAGIC - `overdue_category` — simplified (no buckets)
# MAGIC
# MAGIC | Condition | overdue_tag |
# MAGIC |---|---|
# MAGIC | `computed_status` = Canceled | Canceled |
# MAGIC | Closed + `closure_date` ≤ `expected_end_date` | On Time (Closed) |
# MAGIC | Closed + `closure_date` > `expected_end_date` | Overdue (Closed) |
# MAGIC | Closed + no deadline | On Time (Closed) |
# MAGIC | Open + on time | On Time (Open) |
# MAGIC | Open + overdue | Buckets (< 2w, 2w-1m, 1-3m, > 3m) |
# MAGIC | Open + no deadline | No deadline |

# COMMAND ----------

# --- overdue_tag: detailed tag with buckets ---
_days_overdue = f.datediff(f.current_date(), f.col("expected_end_date"))

df_events_transf = df_events_transf.withColumn(
    "overdue_tag",
    f.when(f.col("computed_status") == "Canceled", f.lit("Canceled")).when(
        f.col("closure_date").isNotNull(),
        f.when(f.col("expected_end_date").isNull(), f.lit("On Time (Closed)"))
        .when(
            f.col("closure_date") <= f.col("expected_end_date"),
            f.lit("On Time (Closed)"),
        )
        .otherwise(f.lit("Overdue (Closed)")),
    )
    # Open events
    .when(f.col("expected_end_date").isNull(), f.lit("No deadline"))
    .when(_days_overdue <= 0, f.lit("On Time (Open)"))
    .when(_days_overdue.between(1, 13), f.lit("< 2w"))
    .when(_days_overdue.between(14, 30), f.lit("2w - 1m"))
    .when(_days_overdue.between(31, 90), f.lit("1-3m"))
    .when(_days_overdue > 90, f.lit("> 3m"))
    .otherwise(f.lit(None).cast("string")),
)

# --- overdue_tag_label: binary On Time / Overdue ---
df_events_transf = df_events_transf.withColumn(
    "overdue_tag_label",
    f.when(f.col("overdue_tag") == "Canceled", f.lit("Canceled"))
    .when(
        f.col("overdue_tag").isin("On Time (Closed)", "On Time (Open)"),
        f.lit("On Time"),
    )
    .when(f.col("overdue_tag") == "No deadline", f.lit("No deadline"))
    .otherwise(f.lit("Overdue")),
)

# --- overdue_category: simplified (no buckets) ---
df_events_transf = df_events_transf.withColumn(
    "overdue_category",
    f.when(f.col("overdue_tag") == "Canceled", f.lit("Canceled"))
    .when(f.col("overdue_tag") == "On Time (Closed)", f.lit("On Time (Closed)"))
    .when(f.col("overdue_tag") == "Overdue (Closed)", f.lit("Overdue (Closed)"))
    .when(f.col("overdue_tag") == "No deadline", f.lit("No Deadline (Open)"))
    .when(f.col("overdue_tag") == "On Time (Open)", f.lit("On Time (Open)"))
    .otherwise(f.lit("Overdue (Open)")),
)

# --- overdue_category_rank: sort order for Power BI ---
df_events_transf = df_events_transf.withColumn(
    "overdue_category_rank",
    f.when(f.col("overdue_category") == "Canceled", f.lit(6))
    .when(f.col("overdue_category") == "On Time (Closed)", f.lit(1))
    .when(f.col("overdue_category") == "On Time (Open)", f.lit(2))
    .when(f.col("overdue_category") == "Overdue (Closed)", f.lit(3))
    .when(f.col("overdue_category") == "Overdue (Open)", f.lit(4))
    .when(f.col("overdue_category") == "No Deadline (Open)", f.lit(5))
    .otherwise(f.lit(99)),
)

# COMMAND ----------

# DBTITLE 1,Tr 12 - Event Type Category
# MAGIC %md
# MAGIC ### Tr 12 - Event Type Category
# MAGIC
# MAGIC Creates `event_type_category` by concatenating `event_type` and `category` with a ` - ` separator.

# COMMAND ----------

df_events_transf = df_events_transf.withColumn(
    "event_type_category",
    f.concat_ws(" - ", f.col("event_type"), f.col("category")),
)

# COMMAND ----------

# DBTITLE 1,Quality Check after Transformations
# MAGIC %md
# MAGIC #### Quality Check after Transformations

# COMMAND ----------

# Quality check: PK must be unique and not null
pk_col = "qim_ID"
df_gx = SparkDFDataset(df_events_transf, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=pk_col),
    df_gx.expect_column_values_to_be_unique(column=pk_col),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message=f"All {pk_col}(s) are unique and not null",
    error_message="Quality checks failed for QIM Events gold table - PK is not unique or contains nulls",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="events_qim",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# DBTITLE 1,Output - Define df_gold
# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# DBTITLE 1,Output - LEAP Tables
# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# DBTITLE 1,Adding constraint primary key in DBX
# MAGIC %md
# MAGIC ### Output - Gold QIM Events
# MAGIC
# MAGIC Saving of Gold QIM Events table. Enriched with document reference and boolean conversions. Columns are reordered into logical groups. Any remaining columns (e.g. `FRM_EVENEMENT` prefixed) are appended at the end.

# COMMAND ----------

# Define the gold DataFrame and primary key
pk_col = "qim_ID"
df_gold = df_events_transf.withColumn(pk_col, f.concat_ws("-", f.col(pk_col)))

# Logical column ordering
ordered_cols = [
    # 1. Identifiers
    "qim_ID",
    "event_reference",
    "previous_event_reference",
    # 2. Event metadata
    "event_name",
    "event_type",
    "category",
    "event_type_category",
    "original_status",
    "computed_status",
    "purpose",
    "description",
    "conclusion",
    "branch",
    "is_periodic",
    "customer_report_numbers",
    "supplier_name",
    "fiscal_year",
    # 3. Overdue tagging
    "overdue_tag",
    "overdue_tag_label",
    "overdue_category",
    "overdue_category_rank",
    # 4. Dates
    "calculated_start_date",
    "calculated_end_date",
    "expected_start_date",
    "start_date",
    "expected_end_date",
    "closure_date",
    "next_audit_expected_date",
    "creation_date",
    # 5. Location
    "auditor_site",
    "auditor_site_qim",
    "impacted_site",
    "impacted_site_qim",
    "impacted_division",
    "impacted_region",
    # 6. People
    "lead_auditor",
    "validator",
    "auditors",
    "audited_ref_codes",
    "audited_ref_names",
    "observers",
    # 7. Auditor references
    "auditor_ref_codes",
    "auditor_ref_names",
    "auditor_ref_index",
    # 8. Programs & Processes
    "process",
    "process_code",
    "profit_center",
    # 9. Other parties
    "customers",
    "users_distribution",
    # 10. Flags & quality
    "is_step2_validated",
    "is_questionnaire_needed",
    "questionnaires",
    # 11. Internal IDs (end)
    "previous_event_ID",
]

# Build final select: ordered known cols first (if present), remaining cols (FRM_EVENEMENT...) at end
all_cols = df_gold.columns
final_cols = [c for c in ordered_cols if c in all_cols] + [
    c for c in all_cols if c not in ordered_cols
]
df_gold = df_gold.select(final_cols)

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "quality"
DESTINATION_TABLE = "events_qim"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_gold,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

# DBTITLE 1,Output - Gold QIM Events
# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key constraint if not already present
TABLE_CONSTRAINT_NAME = "gold_events_qim_pk"
TABLE_PK_COLS = pk_col

nb_cons = spark.sql(
    f"SELECT COUNT(*) FROM system.information_schema.table_constraints "
    f"WHERE table_catalog='{CATALOG}' AND table_schema='{SCHEMA}' "
    f"AND table_name='{DESTINATION_TABLE}' AND constraint_name='{TABLE_CONSTRAINT_NAME}'"
).first()[0]

if nb_cons == 0:
    # Set PK column NOT NULL before adding constraint
    table_utils.set_table_column_not_null(
        table_path=DESTINATION_TABLE_FULL_PATH, column=TABLE_PK_COLS
    )
    # Add primary key constraint
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
    log.info(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' added.")
else:
    log.info(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' already exists.")

# COMMAND ----------

# DBTITLE 1,Output - Gold Exposed QIM Events
# MAGIC %md
# MAGIC ### Output - Gold Exposed QIM Events
# MAGIC
# MAGIC Create or Replace the gold exposed view. Filters out columns still prefixed with `FRM_EVENEMENT` (internal/meta columns not mapped by headers).

# COMMAND ----------

# Exclude FRM_EVENEMENT prefixed columns and raw join IDs (resolved references already present)
_internal_ids = {"previous_event_ID"}
selected_columns = [
    col
    for col in df_gold.columns
    if not col.startswith("FRM_EVENEMENT") and col not in _internal_ids
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename=DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename=f"{DESTINATION_TABLE_FULL_PATH}_exposed",
    select_statement=select_statement,
    replace_view=True,
)

# COMMAND ----------

# DBTITLE 1,Output - Files
# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
