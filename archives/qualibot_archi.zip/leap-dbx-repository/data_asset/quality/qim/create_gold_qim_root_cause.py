# Databricks notebook source
# DBTITLE 1,Notebook header
# MAGIC %md
# MAGIC # CREATE GOLD QIM ROOT CAUSE
# MAGIC
# MAGIC **Description:**  
# MAGIC Creates the gold table for QIM root causes. Enriches silver root causes with document reference (from documents_qim_exposed).
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Quality - QIM
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver.quality.root_cause_qim
# MAGIC - {pipeline_read_env}_gold.quality.documents_qim_exposed
# MAGIC - {pipeline_read_env}_gold.quality.findings_qim_exposed
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.quality.root_cause_qim
# MAGIC - {pipeline_write_env}_gold.quality.root_cause_qim_exposed (view)

# COMMAND ----------

# DBTITLE 1,Technical Debt
# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC N/A

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# DBTITLE 1,Config LEAP Function Imports
# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

# LEAP FUNCTION
from leap_utils.data_asset import table_utils
from leap_utils.common.validation import gx_validation
from leap_utils.common import logger

# COMMAND ----------

# DBTITLE 1,Config Widgets
# MAGIC %md
# MAGIC ## Config Widgets
# MAGIC
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Config logger
# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config other
# MAGIC %md
# MAGIC ## Config other
# MAGIC
# MAGIC N/A

# COMMAND ----------

# DBTITLE 1,Inputs
# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# DBTITLE 1,Inputs LEAP tables
# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# DBTITLE 1,Import silver root cause
# MAGIC %md
# MAGIC ### Import Silver QIM Root Cause
# MAGIC
# MAGIC **df_root_cause** is the silver QIM root cause table.

# COMMAND ----------

df_root_cause = spark.read.table(f"{PIPELINE_READ_ENV}_silver.quality.root_cause_qim")

# COMMAND ----------

# DBTITLE 1,Import QIM documents exposed
# MAGIC %md
# MAGIC ### Import QIM Documents Exposed
# MAGIC
# MAGIC **df_docs_exposed** is the gold exposed view of QIM documents. Used to enrich root causes with `document_reference` and `creation_date` of the parent event.

# COMMAND ----------

# DBTITLE 1,Cell 18
df_docs_exposed = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.quality.documents_qim_exposed"
)

# COMMAND ----------

# DBTITLE 1,Import QIM findings exposed
# MAGIC %md
# MAGIC    
# MAGIC ### Import QIM Findings Exposed
# MAGIC
# MAGIC **df_findings_exposed** is the gold exposed view of QIM findings. Used in Tr 3 to enrich root causes with `event_type`, `event_status`, `event_category`, `finding_status`, `customer_name`, `supplier_name`, `profit_center`, `liable_site`, `liable_division`, `finding_process`, `finding_type` and `finding_nc_subtype` of the parent finding (via `finding_ID`).

# COMMAND ----------

# DBTITLE 1,Cell 20
df_findings_exposed = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.quality.findings_qim_exposed"
)

# COMMAND ----------

# DBTITLE 1,Inputs File Read
# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Inputs Manual Declaration
# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Data Preparation
# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# DBTITLE 1,Prep 1 - df_docs_ref
# MAGIC %md
# MAGIC ## Preparation 1 - df_docs_ref
# MAGIC
# MAGIC Select only `qim_ID`, `reference`, and `creation_date` from `df_docs_exposed`. Rename `reference` to `document_reference` to avoid ambiguity.

# COMMAND ----------

df_docs_ref = df_docs_exposed.select("qim_ID", "reference", "creation_date")

# COMMAND ----------

# DBTITLE 1,Prep 2 - df_findings_lookup
# MAGIC %md
# MAGIC    
# MAGIC ## Preparation 2 - df_findings_lookup
# MAGIC
# MAGIC Select `qim_ID` (join key), `event_reference`, `event_type`, `event_status`, `event_category`, `status` (renamed `finding_status`), `customer_name`, `supplier_name`, `profit_center`, `liable_site`, `liable_division`, `process` (renamed `finding_process`), `finding_type` and `nc_subtype` (renamed `finding_nc_subtype`) from `df_findings_exposed`. Used in Tr 3 to enrich root causes via `finding_ID = qim_ID`.

# COMMAND ----------

# DBTITLE 1,Cell 29
df_findings_lookup = df_findings_exposed.select(
    f.col("qim_ID").alias("_finding_id"),
    f.col("event_reference"),
    f.col("event_type"),
    f.col("event_status"),
    f.col("event_category"),
    f.col("status").alias("finding_status"),
    f.col("customer_name"),
    f.col("supplier_name"),
    f.col("profit_center"),
    f.col("liable_site"),
    f.col("liable_division"),
    f.col("process").alias("finding_process"),
    f.col("finding_type"),
    f.col("nc_subtype").alias("finding_nc_subtype"),
)

# COMMAND ----------

# DBTITLE 1,Data Transformations
# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# DBTITLE 1,Tr1 - Join with QIM documents
# MAGIC %md
# MAGIC ### Tr 1 - Join with QIM Documents
# MAGIC
# MAGIC Enrich root causes with `document_reference` and `creation_date` of the parent event. Inner join on `qim_ID` (only matched records are kept).

# COMMAND ----------

# DBTITLE 1,Cell 32
# Inner join to enrich root causes with the parent event document reference
df_root_cause_transf = (
    df_root_cause.join(df_docs_ref, on="qim_ID", how="inner")
    .withColumnRenamed("reference", "root_cause_reference")
)

# COMMAND ----------

# DBTITLE 1,Tr2 - Finding Document Reference
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 2 - Finding Document Reference
# MAGIC
# MAGIC Left join on `finding_ID` with `df_docs_ref` to retrieve the `document_reference` of the associated finding. Result stored in `finding_document_reference`.

# COMMAND ----------

df_root_cause_transf = df_root_cause_transf.join(
    df_docs_ref.select(
        f.col("qim_ID").alias("finding_ID"),
        f.col("reference").alias("finding_reference"),
    ),
    on="finding_ID",
    how="left",
)

# COMMAND ----------

# DBTITLE 1,Tr 3 - Finding Attributes
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 3 - Enrich with Finding Attributes
# MAGIC
# MAGIC Left join on `finding_ID = qim_ID` of `df_findings_lookup` to inherit:
# MAGIC - `event_reference` — reference of the parent QIM event
# MAGIC - `event_type` — type of the parent QIM event
# MAGIC - `event_status` — computed status of the parent event
# MAGIC - `event_category` — category of the parent QIM event
# MAGIC - `finding_status` — status of the parent finding
# MAGIC - `customer_name` — array of customer names from the parent finding
# MAGIC - `supplier_name` — supplier name from the parent finding
# MAGIC - `profit_center` — array of profit centers from the parent finding
# MAGIC - `liable_site` — liable site of the finding
# MAGIC - `liable_division` — liable division of the finding
# MAGIC - `finding_process` — process from the parent finding
# MAGIC - `finding_type` — type of the finding
# MAGIC - `finding_nc_subtype` — non-conformity subtype of the finding

# COMMAND ----------

# Enrich root causes with finding-level attributes via finding_ID
df_root_cause_transf = df_root_cause_transf.join(
    df_findings_lookup,
    df_root_cause_transf["finding_ID"] == df_findings_lookup["_finding_id"],
    how="left",
).drop("_finding_id")

# COMMAND ----------

# DBTITLE 1,Tr 4 - Group & Subgroup Abbreviations
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 4 - Group & Subgroup Abbreviations
# MAGIC
# MAGIC Derive abbreviated codes from the classification columns:
# MAGIC - `group_abbr` — first character of `group`
# MAGIC - `subgroup_abbr` — first two characters of `subgroup`

# COMMAND ----------

df_root_cause_transf = df_root_cause_transf.withColumns({
    "group_abbr":    f.substring(f.col("group"), 1, 1),
    "subgroup_abbr": f.substring(f.col("subgroup"), 1, 2),
})

# COMMAND ----------

# DBTITLE 1,Quality Check after Transformations
# MAGIC %md
# MAGIC #### Quality Check after Transformations

# COMMAND ----------

# Quality check: PK must be unique and not null
pk_col = "qim_ID"
df_gx = SparkDFDataset(df_root_cause_transf, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=pk_col),
    df_gx.expect_column_values_to_be_unique(column=pk_col),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message=f"All {pk_col}(s) are unique and not null",
    error_message="Quality checks failed for QIM Root Cause gold table - PK not unique or contains nulls",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="root_cause_qim",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# DBTITLE 1,Outputs
# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# DBTITLE 1,Output LEAP Tables
# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# DBTITLE 1,Output Gold QIM Root Cause
# MAGIC %md
# MAGIC ### Output - Gold QIM Root Cause
# MAGIC
# MAGIC Saving of Gold QIM Root Cause table. Enriched with parent event document reference. Columns reordered into logical groups. Any remaining columns (e.g. `FRM_ROOT_CAUSE_OCCURENCE` prefixed) are appended at the end.

# COMMAND ----------

df_gold = df_root_cause_transf.withColumn(pk_col, f.concat_ws("-", f.col(pk_col)))

ordered_cols = [
    # 1. Identifier
    "qim_ID",
    # 2. Document references
    "root_cause_reference",
    "creation_date",
    "finding_reference",
    # 3. Root cause classification
    "root_cause_name",
    "root_cause_type",
    "category",
    "group",
    "group_abbr",
    "subgroup",
    "subgroup_abbr",
    # 4. Finding attributes (from findings_exposed via finding_ID)
    "event_reference",
    "event_type",
    "event_status",
    "event_category",
    "finding_status",
    "customer_name",
    "supplier_name",
    "profit_center",
    "liable_site",
    "liable_division",
    "finding_process",
    "finding_type",
    "finding_nc_subtype",
    # 5. Other attributes
    "branch",
    "finding_ID",
]

all_cols = df_gold.columns
final_cols = [c for c in ordered_cols if c in all_cols] + [
    c for c in all_cols if c not in ordered_cols
]
df_gold = df_gold.select(final_cols)

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "quality"
DESTINATION_TABLE = "root_cause_qim"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_gold,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

# DBTITLE 1,PK constraint
# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key constraint if not already present
TABLE_CONSTRAINT_NAME = "gold_root_cause_qim_pk"
TABLE_PK_COLS = pk_col

nb_cons = spark.sql(
    f"SELECT COUNT(*) FROM system.information_schema.table_constraints "
    f"WHERE table_catalog='{CATALOG}' AND table_schema='{SCHEMA}' "
    f"AND table_name='{DESTINATION_TABLE}' AND constraint_name='{TABLE_CONSTRAINT_NAME}'"
).first()[0]

if nb_cons == 0:
    table_utils.set_table_column_not_null(
        table_path=DESTINATION_TABLE_FULL_PATH, column=TABLE_PK_COLS
    )
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
    log.info(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' added.")
else:
    log.info(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' already exists.")

# --- Gold exposed view ---
_internal_ids = {"root_cause_tree_ID", "finding_ID"}
selected_columns = [
    col
    for col in df_gold.columns
    if not col.startswith("FRM_ROOT_CAUSE_OCCURENCE") and col not in _internal_ids
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename=DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename=f"{DESTINATION_TABLE_FULL_PATH}_exposed",
    select_statement=select_statement,
    replace_view=True,
)

# COMMAND ----------

# DBTITLE 1,Output Files
# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
