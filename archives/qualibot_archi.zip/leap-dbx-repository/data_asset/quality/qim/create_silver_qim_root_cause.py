# Databricks notebook source
# DBTITLE 1,Notebook header
# MAGIC %md
# MAGIC # CREATE SILVER QIM ROOT CAUSE
# MAGIC
# MAGIC **Description:**  
# MAGIC Creates the silver table for QIM root cause occurrences (`frm_root_cause_occurence`). Applies column renaming via headers dictionary, type casting, deduplication, and composite primary key construction.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC N/A — single-table silver transformation.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Quality - QIM
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_bronze.qim.frm_root_cause_occurence_latest
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {reference_read_env}_bronze.headers_others.headers_qim_frm_root_cause_occurence
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.quality.root_cause_qim

# COMMAND ----------

# DBTITLE 1,Technical Debt
# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC N/A

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f
from pyspark.sql.types import StringType

# COMMAND ----------

# DBTITLE 1,Config LEAP Function Imports
# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

# LEAP FUNCTION
from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# COMMAND ----------

# Quality checks
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# DBTITLE 1,Config Widgets
# MAGIC %md
# MAGIC ## Config Widgets
# MAGIC
# MAGIC ### Pipeline Environments

# COMMAND ----------

# DBTITLE 1,Cell 10
dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Config logger
# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config Common Functions
# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Inputs
# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# DBTITLE 1,Inputs LEAP tables
# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# DBTITLE 1,Import Main Table
# MAGIC %md
# MAGIC ### Import Main Table
# MAGIC
# MAGIC **df_root_cause_raw** is the latest snapshot of `frm_root_cause_occurence`, containing one row per root cause node per parent event document.

# COMMAND ----------

df_root_cause_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze.qim.frm_root_cause_occurence_latest"
)

# COMMAND ----------

# DBTITLE 1,Import Headers Table
# MAGIC %md
# MAGIC ### Import Headers Table
# MAGIC
# MAGIC **df_headers_root_cause** is the headers dictionary for `frm_root_cause_occurence`. Used for column renaming and casting.

# COMMAND ----------

# DBTITLE 1,Cell 20
df_headers_root_cause = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_others.headers_qim_frm_root_cause_occurence"
)

# COMMAND ----------

# DBTITLE 1,Inputs File Read
# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Inputs Manual Declaration
# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Data Preparation
# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# DBTITLE 1,Prep Common Functions
# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Prep 0 - Clean raw data
# MAGIC %md
# MAGIC ## Prep 0 - Clean all columns
# MAGIC
# MAGIC Global cleaning on the raw DataFrame before any transformation:
# MAGIC 1. Trim leading/trailing whitespace on all string columns
# MAGIC 2. Replace empty strings `""` with `null`

# COMMAND ----------

# Get all string columns from the raw DataFrame
string_cols = [
    c.name
    for c in df_root_cause_raw.schema.fields
    if isinstance(c.dataType, StringType)
]

# Trim whitespace + replace empty strings with null — in a single pass
df_root_cause_cleaned = df_root_cause_raw.withColumns(
    {
        col: f.when(f.trim(f.col(col)) == "", None).otherwise(f.trim(f.col(col)))
        for col in string_cols
    }
)

# COMMAND ----------

# DBTITLE 1,Prep 1 - Rename and Cast
# MAGIC %md
# MAGIC ## Prep 1 - Rename and Cast columns
# MAGIC
# MAGIC Using the headers dictionary to:
# MAGIC 1. Add table prefix (`"FRM_ROOT_CAUSE_OCCURENCE"`) matching `Table_name` in headers
# MAGIC 2. Rename columns from technical names to business names
# MAGIC 3. Cast columns to their expected types

# COMMAND ----------

# Check header schema
table_utils.check_schema_of_the_header_file(df_headers_root_cause)

# Add table prefix matching headers Table_name
df_root_cause_prefixed = table_utils.add_prefix_to_columns(
    df_root_cause_cleaned, "FRM_ROOT_CAUSE_OCCURENCE"
)

# Rename columns using headers
df_root_cause_renamed = table_utils.rename_columns_with_sap_business_header(
    df_root_cause_prefixed, df_headers_root_cause
)

# Cast columns according to header Format
df_root_cause_casted = table_utils.cast_columns_with_sap_business_headers(
    df_root_cause_renamed, df_headers_root_cause, date_format="yyyy-MM-dd"
)

# COMMAND ----------

# DBTITLE 1,Prep 2 - Remove leading zeros
# MAGIC %md
# MAGIC ## Prep 2 - Remove leading zeros
# MAGIC
# MAGIC Strip leading zeros from identifier columns (numeric-like IDs only, not UUIDs).

# COMMAND ----------

# Remove leading zeros from identifier columns
id_cols = [c for c in df_root_cause_casted.columns if c.lower().endswith("id")]

df_root_cause_prep = table_utils.remove_leading_zeros(
    df=df_root_cause_casted, column_names=id_cols
)

# COMMAND ----------

# DBTITLE 1,Data Transformations
# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC Silver-level transformations: deduplication and primary key construction. No joins, no enrichment, no calculated columns.

# COMMAND ----------

# DBTITLE 1,Tr 1 - Deduplication
# MAGIC %md
# MAGIC ## Tr 1 - Deduplication
# MAGIC
# MAGIC Deduplicate on the composite primary key (`qim_ID`, `root_cause_tree_ID`).

# COMMAND ----------

# Deduplicate on composite primary key (keep first occurrence)
df_root_cause_dedup = df_root_cause_prep.dropDuplicates(["qim_ID"])

# COMMAND ----------

# DBTITLE 1,Tr 2 - Surrogate PK
# MAGIC %md
# MAGIC ## Tr 2 - Composite Primary Key
# MAGIC
# MAGIC Create surrogate key `root_cause_ID` by concatenating `qim_ID` and `root_cause_tree_ID`, then position it as the first column.

# COMMAND ----------

pk_col = "qim_ID"

# Position PK as first column
new_order = [pk_col] + [c for c in df_root_cause_dedup.columns if c != pk_col]
df_silver = df_root_cause_dedup.select(new_order)

# COMMAND ----------

# DBTITLE 1,Quality Check header
# MAGIC %md
# MAGIC # Quality Check
# MAGIC
# MAGIC Validate primary key uniqueness and non-null constraint before writing to silver.

# COMMAND ----------

# Quality check: PK must be unique and not null
df_gx = SparkDFDataset(df_silver, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=pk_col),
    df_gx.expect_column_values_to_be_unique(column=pk_col),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message=f"All {pk_col}(s) are unique and not null",
    error_message="Quality checks failed for QIM Root Cause silver table - PK is not unique or contains nulls",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="root_cause_qim",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# DBTITLE 1,Outputs
# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# DBTITLE 1,Output LEAP Tables
# MAGIC %md
# MAGIC ## Output - LEAP Tables
# MAGIC
# MAGIC ### Output - Silver QIM Root Cause

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "quality"
DESTINATION_TABLE = "root_cause_qim"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_silver,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

# DBTITLE 1,Output Files
# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
