# Databricks notebook source
# DBTITLE 1,Cell 1
# MAGIC %md
# MAGIC
# MAGIC # CREATE SILVER QIM ACTIONS
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC Creates the silver table for QIM action records (`frm_action`). Applies column renaming via headers dictionary, type casting, deduplication, and primary key construction.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC N/A — single-table silver transformation.
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Quality - QIM
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_bronze.qim.frm_action_latest
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {reference_read_env}_bronze.headers_others.headers_qim_frm_action
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.quality.actions_qim

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f
from pyspark.sql.types import StringType

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

# LEAP FUNCTION
from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# COMMAND ----------

# Quality checks
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

# log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

def get_column_values_as_list(df, column_name):
    """Extract column values from a DataFrame as a Python list."""
    return [row[column_name] for row in df.select(column_name).collect()]


def replace_invalid_dates_with_none(df, date_column_names):
    """Replace invalid date strings (empty, '00000000', 'null') with None for date columns."""
    invalid_patterns = ["", "00000000", "null", "NULL", "None"]
    for col_name in date_column_names:
        if col_name in df.columns:
            df = df.withColumn(
                col_name,
                f.when(f.col(col_name).isin(invalid_patterns), None).otherwise(
                    f.col(col_name)
                ),
            )
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Main Table
# MAGIC
# MAGIC **df_actions_raw** is the latest snapshot of the _frm_action_ table containing corrective and preventive action records from QIM system

# COMMAND ----------

df_actions_raw = spark.read.table(f"{PIPELINE_READ_ENV}_bronze.qim.frm_action_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Headers Table
# MAGIC
# MAGIC **df_headers_actions** is the headers dictionary for _frm_action_. Used for column renaming and casting.

# COMMAND ----------

# DBTITLE 1,Cell 26
df_headers_actions = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_others.headers_qim_frm_action"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 0 - Clean all columns
# MAGIC
# MAGIC Global cleaning on the raw DataFrame before any transformation:
# MAGIC 1. Trim leading/trailing whitespace on all string columns
# MAGIC 2. Replace empty strings `""` with `null`

# COMMAND ----------

# Get all string columns from the raw DataFrame
string_cols = [
    c.name for c in df_actions_raw.schema.fields if isinstance(c.dataType, StringType)
]

# Trim whitespace + replace empty strings with null — in a single pass
df_actions_cleaned = df_actions_raw.withColumns(
    {
        col: f.when(f.trim(f.col(col)) == "", None).otherwise(f.trim(f.col(col)))
        for col in string_cols
    }
)

# COMMAND ----------

# DBTITLE 1,Prep 1 - Rename, Truncate Dates and Cast
# MAGIC %md
# MAGIC ## Prep 1 - Rename, Truncate Dates and Cast columns
# MAGIC
# MAGIC Using the headers dictionary to:
# MAGIC 1. Add table prefix (`"FRM_ACTION"`) matching `Table_name` in headers
# MAGIC 2. Rename columns from technical names to business names
# MAGIC 3. Truncate date columns to `yyyy-MM-dd` (source arrives as `"yyyy-MM-dd HH:mm:ss.SSS"` — the timestamp part is discarded)
# MAGIC 4. Cast columns to their expected types (string → date)

# COMMAND ----------

# Check header schema
table_utils.check_schema_of_the_header_file(df_headers_actions)

# Add table prefix matching headers Table_name — required by rename function
df_actions_prefixed = table_utils.add_prefix_to_columns(
    df_actions_cleaned, "FRM_ACTION"
)

# Rename columns using headers (maps FRM_ACTION_<field> → <business_name>)
df_actions_renamed = table_utils.rename_columns_with_sap_business_header(
    df_actions_prefixed, df_headers_actions
)

# Truncate date columns to yyyy-MM-dd to remove timestamp
date_cols = [
    "realisation_date",
    "checking_date",
    "closure_date",
    "deadline_date",
    "initial_deadline_date",
]

df_actions_renamed = df_actions_renamed.withColumns(
    {
        col: f.col(col).substr(1, 10)
        for col in date_cols
        if col in df_actions_renamed.columns
    }
)

# Cast columns according to header Format (string → date where applicable)
df_actions_casted = table_utils.cast_columns_with_sap_business_headers(
    df_actions_renamed, df_headers_actions, date_format="yyyy-MM-dd"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 2 - Remove leading zeros
# MAGIC
# MAGIC Strip leading zeros from identifier columns where applicable (numeric-like IDs only, not UUIDs).

# COMMAND ----------

# Remove leading zeros from identifier columns
id_cols = [c for c in df_actions_casted.columns if c.lower().endswith("id")]

df_actions_prep = table_utils.remove_leading_zeros(
    df=df_actions_casted, column_names=id_cols
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC Silver-level transformations: deduplication and primary key construction. No joins, no enrichment, no calculated columns.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr 1 - Deduplication
# MAGIC
# MAGIC Deduplicate on `qim_ID` (primary key). Drop duplicate rows if any exist.

# COMMAND ----------

# Deduplicate on primary key (keep first occurrence)
df_actions_dedup = df_actions_prep.dropDuplicates(["qim_ID"])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr 2 - Primary key positioning
# MAGIC
# MAGIC Position `qim_ID` as the first column for clarity and convention.

# COMMAND ----------

# Define primary key column
pk_col = "qim_ID"

# Position primary key as first column
new_order = [pk_col] + [c for c in df_actions_dedup.columns if c != pk_col]
df_silver = df_actions_dedup.select(new_order)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check
# MAGIC
# MAGIC Validate primary key uniqueness and non-null constraint before writing to silver.

# COMMAND ----------

# Quality check: PK must be unique and not null
df_gx = SparkDFDataset(df_silver, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=pk_col),
    df_gx.expect_column_values_to_be_unique(column=pk_col),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message=f"All {pk_col}(s) are unique and not null",
    error_message="Quality checks failed for QIM Actions Silver table - PK is not unique or contains nulls",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="actions_qim",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables
# MAGIC
# MAGIC ### Output - Silver QIM Actions

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "quality"
DESTINATION_TABLE = "actions_qim"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_silver,
    overwrite_schema=True,
    mode="overwrite",
)
