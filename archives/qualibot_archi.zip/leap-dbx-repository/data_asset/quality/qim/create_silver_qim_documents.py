# Databricks notebook source
# DBTITLE 1,Notebook header
# MAGIC %md
# MAGIC
# MAGIC # CREATE SILVER QIM DOCUMENTS
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC Creates the silver table for QIM documents. Applies column renaming via headers dictionary, type casting, deduplication, and primary key construction.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC N/A — single-table silver transformation.
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Quality - QIM
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_bronze.qim.documents_latest
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {reference_read_env}_bronze.headers_others.headers_qim_documents
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.quality.documents_qim
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f
from pyspark.sql.types import StringType

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

# LEAP FUNCTION
from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# COMMAND ----------

# Quality checks
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# MAGIC %md
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# DBTITLE 1,Import Main Table
# MAGIC %md
# MAGIC ### Import Main Table
# MAGIC
# MAGIC **df_docs_raw** is the latest snapshot of the _documents_ table containing document records from QIM system
# MAGIC

# COMMAND ----------

df_docs_raw = spark.read.table(f"{PIPELINE_READ_ENV}_bronze.qim.documents_latest")

# COMMAND ----------

# DBTITLE 1,Import Headers Table
# MAGIC %md
# MAGIC ### Import Headers Table
# MAGIC
# MAGIC **df_headers_docs** is the headers dictionary for _documents_. Used for column renaming and casting.

# COMMAND ----------

# DBTITLE 1,Cell 28
df_headers_docs = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_others.headers_qim_documents"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# DBTITLE 1,Prep 0 - Clean raw data
# MAGIC %md
# MAGIC ## Prep 0 - Clean all columns
# MAGIC
# MAGIC Global cleaning on the raw DataFrame before any transformation:
# MAGIC 1. Trim leading/trailing whitespace on all string columns
# MAGIC 2. Replace empty strings `""` with `null`

# COMMAND ----------

# DBTITLE 1,Cell 35
# Get all string columns from the raw DataFrame
string_cols = [
    c.name for c in df_docs_raw.schema.fields if isinstance(c.dataType, StringType)
]

# Trim whitespace + replace empty strings with null — in a single pass
df_docs_cleaned = df_docs_raw.withColumns(
    {
        col: f.when(f.trim(f.col(col)) == "", None).otherwise(f.trim(f.col(col)))
        for col in string_cols
    }
)

# COMMAND ----------

# DBTITLE 1,Prep 1 - Rename and Cast
# MAGIC %md
# MAGIC ## Prep 1 - Rename, Truncate Dates and Cast columns
# MAGIC
# MAGIC Using the headers dictionary to:
# MAGIC 1. Add table prefix (`"DOCUMENTS"`) matching `Table_name` in headers
# MAGIC 2. Rename columns from technical names to business names
# MAGIC 3. Truncate date columns to `yyyy-MM-dd` (source arrives as `"yyyy-MM-dd HH:mm:ss.SSSSSSS"` — the timestamp part is discarded)
# MAGIC 4. Cast columns to their expected types (string → date)

# COMMAND ----------

# DBTITLE 1,Cell 37
# Check header schema
table_utils.check_schema_of_the_header_file(df_headers_docs)

# Add table prefix matching headers Table_name — required by rename function
df_docs_prefixed = table_utils.add_prefix_to_columns(df_docs_cleaned, "DOCUMENTS")

# Rename columns using headers (maps DOCUMENTS_<field> → <business_name>)
df_docs_renamed = table_utils.rename_columns_with_sap_business_header(
    df_docs_prefixed, df_headers_docs
)

# Truncate date columns to yyyy-MM-dd to remove timestamp
date_cols = [
    "creation_date",
]

df_docs_renamed = df_docs_renamed.withColumns(
    {
        col: f.col(col).substr(1, 10)
        for col in date_cols
        if col in df_docs_renamed.columns
    }
)

# Cast columns according to header Format (string → date where applicable)
df_docs_casted = table_utils.cast_columns_with_sap_business_headers(
    df_docs_renamed, df_headers_docs, date_format="yyyy-MM-dd"
)

# COMMAND ----------

# DBTITLE 1,Prep 2 - Clean columns
# MAGIC %md
# MAGIC ## Prep 2 - Remove leading zeros
# MAGIC
# MAGIC Strip leading zeros from identifier columns where applicable (numeric-like IDs only, not UUIDs).

# COMMAND ----------

# Remove leading zeros from identifier columns
id_cols = [c for c in df_docs_casted.columns if c.lower().endswith("id")]

df_docs_prep = table_utils.remove_leading_zeros(df=df_docs_casted, column_names=id_cols)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep 3 - Replace invalid values with null
# MAGIC
# MAGIC Replace placeholder values (`'?'`) in `modified_by` with `null`.

# COMMAND ----------

df_docs_prep = df_docs_prep.withColumn(
    "modified_by",
    f.when(f.col("modified_by") == "?", None).otherwise(f.col("modified_by")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Quality Check after Preparation
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Data Transformations header
# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC Silver-level transformations: deduplication and primary key construction. No joins, no enrichment, no calculated columns.
# MAGIC

# COMMAND ----------

# DBTITLE 1,Tr 1 - Deduplication
# MAGIC %md
# MAGIC ## Tr 1 - Deduplication
# MAGIC
# MAGIC Remove fully duplicate rows where all column values are identical.
# MAGIC

# COMMAND ----------

# Remove fully duplicate rows (all columns identical)
df_docs_dedup = df_docs_prep.dropDuplicates()

# COMMAND ----------

# DBTITLE 1,Tr 2 - PK positioning
# MAGIC %md
# MAGIC ## Tr 2 - Primary key positioning
# MAGIC
# MAGIC Position `qim_ID` as the first column for clarity and convention.

# COMMAND ----------

# Define primary key column
pk_col = "qim_ID"

# Position primary key as first column
# All Bronze columns are retained — .select() is used only to reorder, not to filter
new_order = [pk_col] + [c for c in df_docs_dedup.columns if c != pk_col]
df_silver = df_docs_dedup.select(new_order)

# COMMAND ----------

# DBTITLE 1,Quality Check header
# MAGIC %md
# MAGIC # Quality Check
# MAGIC
# MAGIC Validate primary key uniqueness and non-null constraint before writing to silver.

# COMMAND ----------

# Quality check: PK must be unique and not null
df_gx = SparkDFDataset(df_silver, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=pk_col),
    df_gx.expect_column_values_to_be_unique(column=pk_col),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message=f"All {pk_col}(s) are unique and not null",
    error_message="Quality checks failed for QIM Documents silver table - PK is not unique or contains nulls",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="documents_qim",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Output - Silver QIM Events
# MAGIC %md
# MAGIC ## Output - LEAP Tables
# MAGIC
# MAGIC ### Output - Silver QIM Documents

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "quality"
DESTINATION_TABLE = "documents_qim"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_silver,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

# DBTITLE 1,PK constraint header
# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key constraint if not already present
TABLE_CONSTRAINT_NAME = "silver_documents_qim_pk"
TABLE_PK_COLS = pk_col

nb_cons = spark.sql(
    f"SELECT COUNT(*) FROM system.information_schema.table_constraints "
    f"WHERE table_catalog='{CATALOG}' AND table_schema='{SCHEMA}' "
    f"AND table_name='{DESTINATION_TABLE}' AND constraint_name='{TABLE_CONSTRAINT_NAME}'"
).first()[0]

if nb_cons == 0:
    # Set PK column NOT NULL before adding constraint
    table_utils.set_table_column_not_null(
        table_path=DESTINATION_TABLE_FULL_PATH, column=TABLE_PK_COLS
    )
    # Add primary key constraint
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
    log.info(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' added.")
else:
    log.info(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' already exists.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
