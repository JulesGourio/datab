# Databricks notebook source
# DBTITLE 1,Notebook header
# MAGIC %md
# MAGIC    
# MAGIC # CREATE SILVER QIM QUESTIONS
# MAGIC
# MAGIC **Description:**  
# MAGIC Creates the silver table for QIM questions. Applies column renaming via headers dictionary, type casting, deduplication, and primary key construction.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC N/A — single-table silver transformation.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Quality - QIM
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_bronze.qim.frm_question_latest
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {reference_read_env}_bronze.headers_others.headers_qim_frm_question
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.quality.questions_qim

# COMMAND ----------

# DBTITLE 1,Technical Debt
# MAGIC %md
# MAGIC    
# MAGIC # Technical Debt
# MAGIC
# MAGIC N/A

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC %md
# MAGIC    
# MAGIC # Configuration

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
# MAGIC %md
# MAGIC    
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f
from pyspark.sql.types import StringType

# COMMAND ----------

# DBTITLE 1,Config LEAP Function Imports
# MAGIC %md
# MAGIC    
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

# LEAP FUNCTION
from leap_utils.data_asset import table_utils, business_rules
from leap_utils.common import logger

# COMMAND ----------

# Quality checks
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# DBTITLE 1,Config Widgets
# MAGIC %md
# MAGIC    
# MAGIC ## Config Widgets

# COMMAND ----------

# DBTITLE 1,Pipeline Environments
# MAGIC %md
# MAGIC    
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# DBTITLE 1,Debug Boolean
# MAGIC %md
# MAGIC    
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Config logger
# MAGIC %md
# MAGIC    
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config - Common Functions
# MAGIC %md
# MAGIC    
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Preparation Common Functions
# MAGIC %md
# MAGIC    
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Config other
# MAGIC %md
# MAGIC    
# MAGIC ## Config other
# MAGIC
# MAGIC N/A

# COMMAND ----------

# DBTITLE 1,Inputs
# MAGIC %md
# MAGIC    
# MAGIC # Inputs

# COMMAND ----------

# DBTITLE 1,Inputs - Functions
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Inputs - LEAP tables
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# DBTITLE 1,Import Main Table
# MAGIC %md
# MAGIC    
# MAGIC ### Import Main Table
# MAGIC
# MAGIC **df_question_raw** reads from `{pipeline_read_env}_bronze.qim.frm_question_latest`, the pre-filtered latest snapshot of QIM question records.

# COMMAND ----------

df_question_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze.qim.frm_question_latest"
)

# COMMAND ----------

# DBTITLE 1,Import Headers Table
# MAGIC %md
# MAGIC    
# MAGIC ### Import Headers Table
# MAGIC
# MAGIC **df_headers_question** is the headers dictionary for _frm_question_. Used for column renaming and casting.

# COMMAND ----------

# DBTITLE 1,Cell 28
df_headers_question = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_others.headers_qim_frm_question"
)

# COMMAND ----------

# DBTITLE 1,Inputs - File Read
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Inputs - Manual declaration
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Data Preparation
# MAGIC %md
# MAGIC    
# MAGIC # Data Preparation
# MAGIC  

# COMMAND ----------

# DBTITLE 1,Prep 0 - Clean raw data
# MAGIC %md
# MAGIC    
# MAGIC ## Prep 0 - Clean all columns
# MAGIC
# MAGIC Global cleaning on the raw DataFrame before any transformation:
# MAGIC 1. Trim leading/trailing whitespace on all string columns
# MAGIC 2. Replace empty strings `""` with `null`

# COMMAND ----------

# Get all string columns from the raw DataFrame
string_cols = [
    c.name for c in df_question_raw.schema.fields if isinstance(c.dataType, StringType)
]

# Trim whitespace + replace empty strings with null — in a single pass
df_question_cleaned = df_question_raw.withColumns(
    {
        col: f.when(f.trim(f.col(col)) == "", None).otherwise(f.trim(f.col(col)))
        for col in string_cols
    }
)

# COMMAND ----------

# DBTITLE 1,Prep 1 - Rename and Cast
# MAGIC %md
# MAGIC    
# MAGIC ## Prep 1 - Rename and Cast columns
# MAGIC
# MAGIC Using the headers dictionary to:
# MAGIC 1. Add table prefix (`"FRM_QUESTION"`) matching `Table_name` in headers
# MAGIC 2. Rename columns from technical names to business names
# MAGIC 3. Cast columns to their expected types

# COMMAND ----------

# Check header schema
table_utils.check_schema_of_the_header_file(df_headers_question)

# Add table prefix matching headers Table_name — required by rename function
df_question_prefixed = table_utils.add_prefix_to_columns(
    df_question_cleaned, "FRM_QUESTION"
)

# Rename columns using headers (maps frm_question_<field> → <business_name>)
df_question_renamed = table_utils.rename_columns_with_sap_business_header(
    df_question_prefixed, df_headers_question
)

# Cast columns according to header Format
df_question_casted = table_utils.cast_columns_with_sap_business_headers(
    df_question_renamed, df_headers_question, date_format="yyyy-MM-dd"
)

# COMMAND ----------

# DBTITLE 1,Prep 2 - Clean columns
# MAGIC %md
# MAGIC    
# MAGIC ## Prep 2 - Remove leading zeros
# MAGIC
# MAGIC Strip leading zeros from identifier columns where applicable.

# COMMAND ----------

# Remove leading zeros from identifier columns
id_cols = [c for c in df_question_casted.columns if c.lower().endswith("id")]

df_question_prep = table_utils.remove_leading_zeros(
    df=df_question_casted, column_names=id_cols
)

# COMMAND ----------

# DBTITLE 1,QC after Preparation
# MAGIC %md
# MAGIC    
# MAGIC #### Quality Check after Preparation
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Data Transformations header
# MAGIC %md
# MAGIC    
# MAGIC # Data Transformations
# MAGIC
# MAGIC Silver-level transformations: deduplication and primary key construction. No joins, no enrichment, no calculated columns.

# COMMAND ----------

# DBTITLE 1,Tr 1 - Deduplication
# MAGIC %md
# MAGIC    
# MAGIC ## Tr 1 - Deduplication
# MAGIC
# MAGIC Deduplicate on `qim_ID` (primary key). Drop duplicate rows if any exist.

# COMMAND ----------

# Deduplicate on primary key (keep first occurrence)
df_question_dedup = df_question_prep.dropDuplicates(["qim_ID"])

# COMMAND ----------

# DBTITLE 1,Tr 2 - PK positioning
# MAGIC %md
# MAGIC    
# MAGIC ## Tr 2 - Primary key positioning
# MAGIC
# MAGIC Position `qim_ID` as the first column for clarity and convention.

# COMMAND ----------

# Define primary key column
pk_col = "qim_ID"

# Position primary key as first column
new_order = [pk_col] + [c for c in df_question_dedup.columns if c != pk_col]
df_silver = df_question_dedup.select(new_order)

# COMMAND ----------

# DBTITLE 1,Quality Check header
# MAGIC %md
# MAGIC    
# MAGIC # Quality Check
# MAGIC
# MAGIC Validate primary key uniqueness and non-null constraint before writing to silver.

# COMMAND ----------

# Quality check: PK must be unique and not null
df_gx = SparkDFDataset(df_silver, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=pk_col),
    df_gx.expect_column_values_to_be_unique(column=pk_col),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message=f"All {pk_col}(s) are unique and not null",
    error_message="Quality checks failed for QIM Questions silver table - PK is not unique or contains nulls",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="questions_qim",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# DBTITLE 1,Outputs
# MAGIC %md
# MAGIC    
# MAGIC # Outputs

# COMMAND ----------

# DBTITLE 1,Output - Common Functions
# MAGIC %md
# MAGIC    
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Output - Silver QIM Questions
# MAGIC %md
# MAGIC    
# MAGIC ## Output - LEAP Tables
# MAGIC
# MAGIC ### Output - Silver QIM Questions

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "quality"
DESTINATION_TABLE = "questions_qim"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_silver,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

# DBTITLE 1,PK constraint header
# MAGIC %md
# MAGIC    
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key constraint if not already present
TABLE_CONSTRAINT_NAME = "silver_questions_qim_pk"
TABLE_PK_COLS = pk_col

nb_cons = spark.sql(
    f"SELECT COUNT(*) FROM system.information_schema.table_constraints "
    f"WHERE table_catalog='{CATALOG}' AND table_schema='{SCHEMA}' "
    f"AND table_name='{DESTINATION_TABLE}' AND constraint_name='{TABLE_CONSTRAINT_NAME}'"
).first()[0]

if nb_cons == 0:
    # Set PK column NOT NULL before adding constraint
    table_utils.set_table_column_not_null(
        table_path=DESTINATION_TABLE_FULL_PATH, column=TABLE_PK_COLS
    )
    # Add primary key constraint
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
    print(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' added.")
else:
    print(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' already exists.")

# COMMAND ----------

# DBTITLE 1,Output - Files
# MAGIC %md
# MAGIC    
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
