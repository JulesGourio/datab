# Databricks notebook source
# DBTITLE 1,Notebook header
# MAGIC %md
# MAGIC    
# MAGIC # CREATE SILVER QIM FINDINGS
# MAGIC
# MAGIC **Description:**  
# MAGIC Creates the silver table for QIM findings (`frm_enregistrement`). Applies column renaming via headers dictionary, type casting, and deduplication.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Quality - QIM
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_bronze.qim.frm_enregistrement_latest
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {reference_read_env}_bronze.headers_others.headers_qim_frm_findings
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_silver.quality.findings_qim

# COMMAND ----------

# DBTITLE 1,Technical Debt
# MAGIC %md
# MAGIC    
# MAGIC # Technical Debt
# MAGIC
# MAGIC N/A

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC %md
# MAGIC    
# MAGIC # Configuration

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
# MAGIC %md
# MAGIC    
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f
from pyspark.sql.types import StringType

# COMMAND ----------

# DBTITLE 1,Config LEAP Function Imports
# MAGIC %md
# MAGIC    
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

# LEAP FUNCTION
from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# COMMAND ----------

# Quality checks
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# DBTITLE 1,Config Widgets
# MAGIC %md
# MAGIC    
# MAGIC ## Config Widgets
# MAGIC
# MAGIC ### Pipeline Environments

# COMMAND ----------

# DBTITLE 1,Cell 10
dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Config logger
# MAGIC %md
# MAGIC    
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config Common Functions
# MAGIC %md
# MAGIC    
# MAGIC ## Config - Common Functions (across whole notebook)
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Inputs
# MAGIC %md
# MAGIC    
# MAGIC # Inputs

# COMMAND ----------

# DBTITLE 1,Inputs LEAP tables
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# DBTITLE 1,Import Main Table
# MAGIC %md
# MAGIC    
# MAGIC ### Import Main Table
# MAGIC
# MAGIC **df_findings_raw** is the latest snapshot of `frm_enregistrement`, containing one row per QIM finding.

# COMMAND ----------

df_findings_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze.qim.frm_enregistrement_latest"
)

# COMMAND ----------

# DBTITLE 1,Import Headers Table
# MAGIC %md
# MAGIC    
# MAGIC ### Import Headers Table
# MAGIC
# MAGIC **df_headers_findings** is the headers dictionary for `frm_enregistrement`. Used for column renaming and casting.

# COMMAND ----------

# DBTITLE 1,Cell 20
df_headers_findings = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_others.headers_qim_frm_findings"
)

# COMMAND ----------

# DBTITLE 1,Inputs File Read
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Inputs Manual Declaration
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Data Preparation
# MAGIC %md
# MAGIC    
# MAGIC # Data Preparation

# COMMAND ----------

# DBTITLE 1,Prep Common Functions
# MAGIC %md
# MAGIC    
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Prep 0 - Clean raw data
# MAGIC %md
# MAGIC    
# MAGIC ## Prep 0 - Clean all columns
# MAGIC
# MAGIC Global cleaning on the raw DataFrame before any transformation:
# MAGIC 1. Trim leading/trailing whitespace on all string columns
# MAGIC 2. Replace empty strings `""` with `null`
# MAGIC 3. Replace semicolons-only values with null

# COMMAND ----------

# Get all string columns from the raw DataFrame
string_cols = [
    c.name for c in df_findings_raw.schema.fields if isinstance(c.dataType, StringType)
]

# Trim whitespace + replace empty strings with null — in a single pass
df_findings_cleaned = df_findings_raw.withColumns(
    {
        col: f.when(f.trim(f.col(col)) == "", None).otherwise(f.trim(f.col(col)))
        for col in string_cols
    }
)

# Replace semicolons-only values with null
df_findings_cleaned = df_findings_cleaned.withColumn(
    "activity",
    f.when(
        f.regexp_replace(f.col("activity"), ";", "") == "",
        f.lit(None).cast("string"),
    ).otherwise(f.col("activity")),
)

# COMMAND ----------

# DBTITLE 1,Prep 1 - Rename and Cast
# MAGIC %md
# MAGIC    
# MAGIC ## Prep 1 - Rename, Truncate Dates and Cast columns
# MAGIC
# MAGIC Using the headers dictionary to:
# MAGIC 1. Add table prefix (`"FRM_FINDINGS"`) matching `Table_name` in headers
# MAGIC 2. Rename columns from technical names to business names
# MAGIC 3. Truncate date columns to `yyyy-MM-dd` (source arrives as `"yyyy-MM-dd HH:mm:ss.SSS"` — the timestamp part is discarded)
# MAGIC 4. Cast columns to their expected types (string → date)

# COMMAND ----------

# Check header schema
table_utils.check_schema_of_the_header_file(df_headers_findings)

# Add table prefix matching headers Table_name
df_findings_prefixed = table_utils.add_prefix_to_columns(
    df_findings_cleaned, "FRM_FINDINGS"
)

# Rename columns using headers (maps FRM_FINDINGS_<field> → <business_name>)
df_findings_renamed = table_utils.rename_columns_with_sap_business_header(
    df_findings_prefixed, df_headers_findings
)

# Truncate date columns to yyyy-MM-dd to remove timestamp
date_cols = [
    "assessment_validation_date",
    "finding_closing_date",
    "root_causes_validation_date",
    "action_checking_date",
    "expected_closure_date",
    "finding_date",
    "reception_date",
    "collaboration_date",
    "action_plan_closure_date",
    "external_validation_date",
]

df_findings_renamed = df_findings_renamed.withColumns(
    {
        col: f.col(col).substr(1, 10)
        for col in date_cols
        if col in df_findings_renamed.columns
    }
)

# Cast columns according to header Format (string → date where applicable)
df_findings_casted = table_utils.cast_columns_with_sap_business_headers(
    df_findings_renamed, df_headers_findings, date_format="yyyy-MM-dd"
)

# COMMAND ----------

# DBTITLE 1,Prep 2 - Remove leading zeros
# MAGIC %md
# MAGIC    
# MAGIC ## Prep 2 - Remove leading zeros
# MAGIC
# MAGIC Strip leading zeros from identifier columns.

# COMMAND ----------

# Remove leading zeros from identifier columns
id_cols = [c for c in df_findings_casted.columns if c.lower().endswith("id")]

df_findings_prep = table_utils.remove_leading_zeros(
    df=df_findings_casted, column_names=id_cols
)

# COMMAND ----------

# DBTITLE 1,Data Transformations
# MAGIC %md
# MAGIC    
# MAGIC # Data Transformations
# MAGIC
# MAGIC Silver-level transformations: deduplication and primary key positioning. No joins, no enrichment, no calculated columns.

# COMMAND ----------

# DBTITLE 1,Tr 1 - Deduplication
# MAGIC %md
# MAGIC    
# MAGIC ## Tr 1 - Deduplication
# MAGIC
# MAGIC Deduplicate on the primary key (`finding_ID`).

# COMMAND ----------

# Remove fully duplicate rows (all columns identical)
df_findings_dedup = df_findings_prep.dropDuplicates()

# COMMAND ----------

# DBTITLE 1,Tr 2 - Position PK
# MAGIC %md
# MAGIC    
# MAGIC ## Tr 2 - Position Primary Key
# MAGIC
# MAGIC Move `finding_ID` to the first column position.

# COMMAND ----------

pk_col = "qim_ID"

# Position PK as first column
new_order = [pk_col] + [c for c in df_findings_dedup.columns if c != pk_col]
df_silver = df_findings_dedup.select(new_order)

# COMMAND ----------

# DBTITLE 1,Quality Check header
# MAGIC %md
# MAGIC    
# MAGIC # Quality Check
# MAGIC
# MAGIC Validate primary key uniqueness and non-null constraint before writing to silver.

# COMMAND ----------

# Quality check: PK must be unique and not null
df_gx = SparkDFDataset(df_silver, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=pk_col),
    df_gx.expect_column_values_to_be_unique(column=pk_col),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message=f"All {pk_col}(s) are unique and not null",
    error_message="Quality checks failed for QIM Findings silver table - PK is not unique or contains nulls",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="findings_qim",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# DBTITLE 1,Outputs
# MAGIC %md
# MAGIC    
# MAGIC # Outputs

# COMMAND ----------

# DBTITLE 1,Output LEAP Tables
# MAGIC %md
# MAGIC    
# MAGIC ## Output - LEAP Tables
# MAGIC
# MAGIC ### Output - Silver QIM Findings

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "quality"
DESTINATION_TABLE = "findings_qim"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_silver,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

# DBTITLE 1,Output Files
# MAGIC %md
# MAGIC    
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
