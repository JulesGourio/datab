# Databricks notebook source
# DBTITLE 1,Notebook header
# MAGIC %md
# MAGIC
# MAGIC # CREATE GOLD QIM DOCUMENTS
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC Creates the gold table for QIM documents. Simple pass-through from silver with PK validation, exposed view creation, and PK constraint.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC N/A — simple gold table (no enrichment needed)
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Quality - QIM
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver.quality.documents_qim
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - N/A
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.quality.documents_qim
# MAGIC - {pipeline_write_env}_gold.quality.documents_qim_exposed
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC N/A
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC
# MAGIC

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# LEAP FUNCTION
from leap_utils.data_asset import table_utils
from leap_utils.common.validation import gx_validation
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other
# MAGIC
# MAGIC N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# DBTITLE 1,Import silver QIM documents
# MAGIC %md
# MAGIC ### Import Silver QIM Documents
# MAGIC
# MAGIC **df_docs** is the silver QIM documents table. Contains cleaned, renamed, and deduplicated document records.
# MAGIC

# COMMAND ----------

df_docs = spark.read.table(f"{PIPELINE_READ_ENV}_silver.quality.documents_qim")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Quality Check after Preparation
# MAGIC

# COMMAND ----------

# N/A - No preparation step needed for this simple gold table

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC

# COMMAND ----------

# DBTITLE 1,Tr 1 - PK positioning
# MAGIC %md
# MAGIC ### Tr 1 - Primary key positioning
# MAGIC
# MAGIC Position `qim_ID` as first column and define `df_gold` output DataFrame.
# MAGIC

# COMMAND ----------

# Define primary key and output DataFrame (PK already positioned in silver)
pk_col = "qim_ID"
df_gold = df_docs

# COMMAND ----------

# DBTITLE 1,Quality Check header
# MAGIC %md
# MAGIC # Quality Check
# MAGIC
# MAGIC Validate primary key uniqueness and non-null constraint before writing to gold.

# COMMAND ----------

df_gx = SparkDFDataset(df_gold, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=pk_col),
    df_gx.expect_column_values_to_be_unique(column=pk_col),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message=f"All {pk_col}(s) are unique and not null",
    error_message="Quality checks failed for QIM Documents gold table - PK is not unique or contains nulls",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="documents_qim",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Adding constraint primary key in DBX
# MAGIC %md
# MAGIC ## Output - LEAP Tables
# MAGIC
# MAGIC ### Output - Gold QIM Documents
# MAGIC
# MAGIC Saving of Gold QIM Documents table. No enrichment applied — pass-through from silver with PK validation.

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "quality"
DESTINATION_TABLE = "documents_qim"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_gold,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

# DBTITLE 1,Output - Gold QIM Documents
# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key constraint if not already present
TABLE_CONSTRAINT_NAME = "gold_documents_qim_pk"
TABLE_PK_COLS = pk_col

nb_cons = spark.sql(
    f"SELECT COUNT(*) FROM system.information_schema.table_constraints "
    f"WHERE table_catalog='{CATALOG}' AND table_schema='{SCHEMA}' "
    f"AND table_name='{DESTINATION_TABLE}' AND constraint_name='{TABLE_CONSTRAINT_NAME}'"
).first()[0]

if nb_cons == 0:
    # Set PK column NOT NULL before adding constraint
    table_utils.set_table_column_not_null(
        table_path=DESTINATION_TABLE_FULL_PATH, column=TABLE_PK_COLS
    )
    # Add primary key constraint
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
    log.info(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' added.")
else:
    log.info(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' already exists.")

# COMMAND ----------

# DBTITLE 1,Output - Gold Exposed QIM Documents
# MAGIC %md
# MAGIC ### Output - Gold Exposed QIM Documents
# MAGIC
# MAGIC Create or Replace the gold exposed view of the gold QIM documents table. All columns are exposed (no internal columns to filter).
# MAGIC

# COMMAND ----------

# Remove columns still prefixed with "DOCUMENTS" (internal/meta columns not in headers)
selected_columns = [col for col in df_gold.columns if not col.startswith("DOCUMENTS")]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename=DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename=f"{DESTINATION_TABLE_FULL_PATH}_exposed",
    select_statement=select_statement,
    replace_view=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
