# Databricks notebook source
# DBTITLE 1,Notebook header
# MAGIC %md
# MAGIC # CREATE GOLD QIM ACTIONS
# MAGIC
# MAGIC **Description:**  
# MAGIC Creates the gold table for QIM actions. Enriches silver actions with document reference (from documents_qim_exposed), converts YES/NO columns to boolean, and adds site/division/region via `business_rules.add_site_region_division`.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Quality - QIM
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver.quality.actions_qim
# MAGIC - {pipeline_read_env}_silver.quality.findings_qim
# MAGIC - {pipeline_read_env}_gold.quality.documents_qim_exposed
# MAGIC - {pipeline_read_env}_gold.quality.events_qim_exposed
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.quality.actions_qim
# MAGIC - {pipeline_write_env}_gold.quality.actions_qim_exposed (view)

# COMMAND ----------

# DBTITLE 1,Technical Debt
# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC N/A

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# DBTITLE 1,Config LEAP Function Imports
# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

# LEAP FUNCTION
from leap_utils.data_asset import table_utils, business_rules
from leap_utils.common.validation import gx_validation
from leap_utils.common import logger

# COMMAND ----------

# DBTITLE 1,Config Widgets
# MAGIC %md
# MAGIC ## Config Widgets
# MAGIC
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Config logger
# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config Common Functions
# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Config other
# MAGIC %md
# MAGIC ## Config other
# MAGIC
# MAGIC N/A - No additional configuration needed for this gold notebook.

# COMMAND ----------

# DBTITLE 1,Inputs
# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# DBTITLE 1,Inputs LEAP tables
# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# DBTITLE 1,Import silver QIM actions
# MAGIC %md
# MAGIC ### Import Silver QIM Actions
# MAGIC
# MAGIC **df_actions** is the silver QIM actions table. Contains cleaned, renamed, and deduplicated action records linked to QIM audit events.

# COMMAND ----------

df_actions = spark.read.table(f"{PIPELINE_READ_ENV}_silver.quality.actions_qim")

# COMMAND ----------

# DBTITLE 1,Import QIM documents exposed
# MAGIC %md
# MAGIC ### Import QIM Documents Exposed
# MAGIC
# MAGIC **df_docs_exposed** is the gold exposed view of QIM documents. Used to enrich actions with `document_reference` and `creation_date`.

# COMMAND ----------

# DBTITLE 1,Cell 20
df_docs_exposed = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.quality.documents_qim_exposed"
)

# COMMAND ----------

# DBTITLE 1,Import Silver QIM Findings
# MAGIC %md
# MAGIC    
# MAGIC ### Import Silver QIM Findings
# MAGIC
# MAGIC **df_findings_silver** is the silver QIM findings table. Used in Prep 2 to build `df_findings_lookup` — provides native finding attributes (`customer_name`, `supplier_name`, `profit_center`, `process`, `finding_type`, `nc_subtype`, `status`) and `event_qim_ID` for chaining to events. Reading from silver (instead of gold) breaks the circular dependency between findings and actions.

# COMMAND ----------

df_findings_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.quality.findings_qim"
)

# COMMAND ----------

# DBTITLE 1,Import QIM Events Exposed
# MAGIC %md
# MAGIC    
# MAGIC ### Import QIM Events Exposed
# MAGIC
# MAGIC **df_events_exposed** is the gold exposed view of QIM events. Used in Prep 2 to resolve `event_type`, `event_status` (`computed_status`) and `event_category` (`category`) via the finding’s `event_qim_ID`. No circular dependency — events_gold does not depend on actions or findings.

# COMMAND ----------

# DBTITLE 1,Cell 24
df_events_exposed = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.quality.events_qim_exposed"
)

# COMMAND ----------

# DBTITLE 1,Import HR Workforce View
# MAGIC %md
# MAGIC    
# MAGIC ### Import HR Workforce View
# MAGIC
# MAGIC **_df_workforce** is the gold HR workforce monthly view. Used to resolve employee ID codes to full names (via `df_users_hr` built in Preparation 3).

# COMMAND ----------

_df_workforce = spark.read.table(
    "sd_prod_gold.hr.hr_workforce_gold_finance_view_monthly"
)

# COMMAND ----------

# DBTITLE 1,Inputs File Read
# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Inputs - Functions
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - Functions
# MAGIC
# MAGIC | Function | Description |
# MAGIC |---|---|
# MAGIC | `format_employee_id(col_expr)` | Normalises an employee ID column expression to `L0XXXXXXX` format. IDs already starting with `L` are kept as-is. Null/empty values return null. |

# COMMAND ----------

def format_employee_id(col_expr):
    """Normalises an employee ID to L0XXXXXXX format (prefix L + 7-digit left-padded numeric part).
    IDs already starting with L are kept as-is. Null/empty values return null.
    """
    trimmed = f.trim(col_expr)
    return f.when(
        col_expr.isNotNull() & (trimmed != ""),
        f.when(trimmed.startswith("L"), trimmed).otherwise(
            f.concat(f.lit("L"), f.lpad(trimmed, 7, "0"))
        ),
    )

# COMMAND ----------

# DBTITLE 1,Inputs Manual declaration
# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Data Preparation
# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# DBTITLE 1,Preparation Common Functions
# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Prep 1 - df_docs_ref
# MAGIC %md
# MAGIC ## Preparation 1 - df_docs_ref
# MAGIC
# MAGIC Select only `qim_ID`, `reference`, and `creation_date` from `df_docs_exposed`.

# COMMAND ----------

df_docs_ref = df_docs_exposed.select("qim_ID", "reference", "creation_date")

# COMMAND ----------

# DBTITLE 1,Prep 2 - df_evt_lookup
# MAGIC %md
# MAGIC    
# MAGIC ## Preparation 2 - df_evt_lookup
# MAGIC
# MAGIC Select `event_type`, `computed_status` (→ `event_status`) and `category` (→ `event_category`) from `df_events_exposed`. Used in Prep 3 to resolve event attributes via `event_qim_ID`.

# COMMAND ----------

df_evt_lookup = df_events_exposed.select(
    f.col("qim_ID").alias("_evt_id"),
    f.col("event_type"),
    f.col("computed_status").alias("event_status"),
    f.col("category").alias("event_category"),
)

# COMMAND ----------

# DBTITLE 1,Prep 3 - df_findings_lookup
# MAGIC %md
# MAGIC    
# MAGIC ## Preparation 3 - df_findings_lookup
# MAGIC
# MAGIC Builds the finding-level lookup used in Tr 8 to enrich actions via `parent_ID = qim_ID`. Reads from `silver.findings_qim` instead of `gold.findings_qim_exposed` to break the circular dependency between actions and findings (findings gold reads from actions gold). Event attributes (`event_type`, `event_status`, `event_category`) are resolved by chaining `event_qim_ID` → `events_qim_exposed`, with a `"No Event"` default for findings without event link. Null native fields default to `"Unassigned"`.

# COMMAND ----------

# DBTITLE 1,Cell 41
# --- Select native finding fields + event_qim_ID from silver findings ---
# customer_name and profit_center are semicolon-separated strings in silver;
# convert to array<string> to match the gold output schema (gold findings Tr 4).
_df_fnd = df_findings_silver.select(
    f.col("qim_ID").alias("_finding_id"),
    f.col("event_qim_ID"),
    f.col("status").alias("finding_status"),
    f.split(f.regexp_replace(f.col("customer_name"), r"\{0\}", ";"), ";").alias("customer_name"),
    f.col("supplier_name"),
    f.split(f.regexp_replace(f.col("profit_center"), r" / ", ";"), ";").alias("profit_center"),
    f.col("process").alias("finding_process"),
    f.col("finding_type"),
    f.col("nc_subtype").alias("finding_nc_subtype"),
)

# --- Resolve event attributes via event_qim_ID → df_evt_lookup ---
_df_fnd = _df_fnd.join(
    df_evt_lookup, _df_fnd["event_qim_ID"] == df_evt_lookup["_evt_id"], how="left"
).drop("_evt_id")

# --- Fallback defaults (replicates gold findings behaviour) ---
# "No Event" for findings without event link (gold findings Tr 12)
# "Unassigned" for null native fields (gold findings default fill)
# Normalize finding_status: "Submited" → "Submitted" (same as findings gold Tr 7)
_df_fnd = _df_fnd.withColumn(
    "finding_status",
    f.when(f.col("finding_status") == "Submited", f.lit("Submitted")).otherwise(f.col("finding_status")),
)

df_findings_lookup = _df_fnd.withColumns({
    "event_type":         f.coalesce(f.col("event_type"),         f.lit("No Event")),
    "event_status":       f.coalesce(f.col("event_status"),       f.lit("No Event")),
    "event_category":     f.coalesce(f.col("event_category"),     f.lit("No Event")),
    "supplier_name":      f.coalesce(f.col("supplier_name"),      f.lit("Unassigned")),
    "finding_process":    f.coalesce(f.col("finding_process"),    f.lit("Unassigned")),
    "finding_type":       f.coalesce(f.col("finding_type"),       f.lit("Unassigned")),
    "finding_nc_subtype": f.coalesce(f.col("finding_nc_subtype"), f.lit("Unassigned")),
}).drop("event_qim_ID")

# COMMAND ----------

# DBTITLE 1,Prep 4 - df_users_hr
# MAGIC %md
# MAGIC    
# MAGIC    
# MAGIC ## Preparation 4 - df_users_hr
# MAGIC
# MAGIC Filter `_df_workforce` to the most recent extraction date, derive `employee_ID` (`L0XXXXXXX` format from `User_ID`) and `full_name` (`First_name` + `Last_name`). Used in Tr 7 to resolve the `owner` employee ID to a full name.

# COMMAND ----------

_max_date = _df_workforce.agg(f.max("_leap_extraction_date")).first()[0]

df_users_hr = (
    _df_workforce.filter(f.col("_leap_extraction_date") == _max_date)
    .select("User_ID", "First_name", "Last_name")
    .dropDuplicates()
    .withColumn("full_name", f.concat_ws(" ", f.col("First_name"), f.col("Last_name")))
    .withColumn("employee_ID", f.concat(f.lit("L"), f.lpad(f.col("User_ID"), 7, "0")))
    .select("employee_ID", "full_name")
)

# COMMAND ----------

# DBTITLE 1,QC after Preparation
# MAGIC %md
# MAGIC #### Quality Check after Preparation
# MAGIC
# MAGIC N/A

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Data Transformations
# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# DBTITLE 1,Tr1 - Join with QIM Documents
# MAGIC %md
# MAGIC ### Tr 1 - Join with QIM Documents
# MAGIC
# MAGIC Enrich actions with `action_reference` and `creation_date` from `df_docs_ref`. Inner join on `qim_ID` (only matched records are kept).

# COMMAND ----------

# DBTITLE 1,Cell 48
# Inner join to enrich actions with their document reference
df_actions_transf = (
    df_actions.join(df_docs_ref, on="qim_ID", how="inner")
    .withColumnRenamed("reference", "action_reference")
)

# COMMAND ----------

# DBTITLE 1,Tr2 - Normalize status values
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 2 - Normalize Status Values
# MAGIC
# MAGIC `"Open"` and `"Opened"` coexist in the source — both normalized to `"Opened"`.

# COMMAND ----------

# Normalize status: "Open" -> "Opened"
df_actions_transf = df_actions_transf.withColumn(
    "status",
    f.when(f.col("status") == "Open", f.lit("Opened")).otherwise(f.col("status")),
)

# COMMAND ----------

# DBTITLE 1,Tr3 - YES/NO to boolean
# MAGIC %md
# MAGIC ### Tr 3 - Convert YES/NO columns to boolean
# MAGIC
# MAGIC Convert string columns with "Yes"/"No" values to proper boolean type.
# MAGIC
# MAGIC Columns confirmed from silver schema: `is_efficient`, `is_cancelled`.

# COMMAND ----------

yes_no_cols = ["is_efficient", "is_cancelled"]
yes_no_cols_existing = [c for c in yes_no_cols if c in df_actions_transf.columns]

if yes_no_cols_existing:
    df_actions_transf = df_actions_transf.withColumns(
        {
            col_name: f.when(f.upper(f.col(col_name)) == "YES", f.lit(True))
            .when(f.upper(f.col(col_name)) == "NO", f.lit(False))
            .otherwise(None)
            for col_name in yes_no_cols_existing
        }
    )

# COMMAND ----------

# DBTITLE 1,Tr4 - Site, Division, Region
# MAGIC %md
# MAGIC ### Tr 4 - Add Action Site Name
# MAGIC
# MAGIC Resolves `site_action_qim` (raw QIM code) to its conventional name using `business_rules.add_site_region_division` with `domain="qim"`. This joins on the `site_qim` column of `mapping_sites` — the column that contains QIM system site codes. Result stored in `action_site`. After the mapping, manual overrides are applied in order:
# MAGIC - `Repair Station` / `Customer Support` + `branch == "Interconnection Systems"` → `"LFR1 - Colomiers"` (mapping gives `"LATE - Colomiers"`).
# MAGIC - `Head Quarter` + `branch == "Aerostructures"` → `"LATE - Mach1"` (mapping gives `"LFR1 - Mach1"`).
# MAGIC - `action_site` null + `site_action_qim == "Latecoere mexico"` → `"LMX - Hermosillo"`.
# MAGIC - `action_site` null + `site_action_qim == "LFR-AS-HQ"` → `"LATE - Mach1"`.
# MAGIC - `site_action_qim` = `"Supplier"` (case-insensitive) → `action_site` = `"Supplier"` and `division` = `"Supplier"` (explicit match, not fallback).
# MAGIC
# MAGIC Any remaining null values in `action_site`, `division` and `region` (unmatched site codes) are filled with `"Unassigned"`.

# COMMAND ----------

df_actions_transf = business_rules.add_site_region_division(
    df=df_actions_transf,
    site_col="site_action_qim",
    domain="qim",
    conventional_site_col="action_site",
    reference_read_env=REFERENCE_READ_ENV,
)

# Special cases
df_actions_transf = df_actions_transf.withColumn(
    "action_site",
    f.when(
        f.col("site_action_qim").isin("Repair Station", "Customer Support")
        & (f.col("branch") == "Interconnection Systems"),
        f.lit("LFR1 - Colomiers"),
    )
    .when(
        (f.col("site_action_qim") == "Head Quarter")
        & (f.col("branch") == "Aerostructures"),
        f.lit("LATE - Mach1"),
    )
    .when(
        f.col("action_site").isNull()
        & (f.col("site_action_qim") == "Latécoère Mexico"),
        f.lit("LMXA - Hermosillo"),
    )
    .when(
        f.col("action_site").isNull() & (f.col("site_action_qim") == "LFR-AS-HQ"),
        f.lit("LATE - Mach1"),
    )
    .when(
        f.upper(f.col("site_action_qim")) == "SUPPLIER",
        f.lit("Supplier"),
    )
    .otherwise(f.col("action_site")),
)

# Explicit Supplier override for division
df_actions_transf = df_actions_transf.withColumn(
    "division",
    f.when(f.upper(f.col("site_action_qim")) == "SUPPLIER", f.lit("Supplier"))
    .otherwise(f.col("division")),
)

# Replace remaining nulls with "Unassigned"
df_actions_transf = df_actions_transf.withColumns(
    {
        "action_site": f.coalesce(f.col("action_site"), f.lit("Unassigned")),
        "division": f.coalesce(f.col("division"), f.lit("Unassigned")),
        "region": f.coalesce(f.col("region"), f.lit("Unassigned")),
    }
)

# COMMAND ----------

# DBTITLE 1,Tr5 - Grand Parent Document Reference
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 5 - Event Reference
# MAGIC
# MAGIC Left join on `grand_parent_doc_ID` with `df_docs_ref` to retrieve the `reference` of the grand parent document (the QIM event this action belongs to). Result stored in `event_reference`.

# COMMAND ----------

df_actions_transf = df_actions_transf.join(
    df_docs_ref.select(
        f.col("qim_ID").alias("grand_parent_doc_ID"),
        f.col("reference").alias("event_reference"),
    ),
    on="grand_parent_doc_ID",
    how="left",
)

# COMMAND ----------

# DBTITLE 1,Tr6 - Parent Doc Document References
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 6 - Parent Doc Document References (array)
# MAGIC
# MAGIC `parent_doc_ID` can hold multiple IDs separated by `";"`. Each token is split, trimmed, joined against `df_docs_ref`, and the resolved `document_reference` values are collected back into an `array<string>`. Result stored in `finding_reference_multiple`.
# MAGIC
# MAGIC Rows where `parent_doc_ID` is null or empty produce a null array (no entry in the aggregation → null after left join). `collect_list` skips unresolved (null) references automatically.

# COMMAND ----------

# Explode ";" separated IDs into individual rows, trimming each token
df_parent_doc_exploded = (
    df_actions_transf.select("qim_ID", "parent_doc_ID")
    .withColumn(
        "parent_doc_ID_single",
        f.explode_outer(f.split(f.col("parent_doc_ID"), ";")),
    )
    .withColumn("parent_doc_ID_single", f.trim(f.col("parent_doc_ID_single")))
    .filter(
        f.col("parent_doc_ID_single").isNotNull()
        & (f.col("parent_doc_ID_single") != "")
    )
)

# Join each token against df_docs_ref, then collect resolved references into an array
# collect_list skips null values, so unresolved tokens are silently excluded
df_parent_doc_refs = (
    df_parent_doc_exploded.join(
        df_docs_ref.select(
            f.col("qim_ID").alias("parent_doc_ID_single"),
            f.col("reference").alias("parent_reference"),
        ),
        on="parent_doc_ID_single",
        how="left",
    )
    .groupBy("qim_ID")
    .agg(f.collect_list(f.col("parent_reference")).alias("finding_reference_multiple"))
)

df_actions_transf = df_actions_transf.join(df_parent_doc_refs, on="qim_ID", how="left")

# COMMAND ----------

# DBTITLE 1,Tr 7 - Resolve Owner to Full Name
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 7 - Resolve Owner to Full Name
# MAGIC
# MAGIC Replaces the employee ID in `owner` with the corresponding `full_name` from the HR workforce table. ID normalised to `L0XXXXXXX` format before joining. Unmatched IDs fall back to the formatted ID string.

# COMMAND ----------

df_users_lookup = df_users_hr.select("employee_ID", "full_name")

df_actions_transf = df_actions_transf.withColumn(
    "owner", format_employee_id(f.col("owner"))
)
log.info("LEFT JOIN: owner → full_name (unmatched IDs kept as-is)")
df_actions_transf = (
    df_actions_transf.join(
        df_users_lookup.select(
            f.col("employee_ID").alias("owner"), f.col("full_name").alias("_own")
        ),
        on="owner",
        how="left",
    )
    .withColumn("owner", f.coalesce(f.col("_own"), f.col("owner")))
    .drop("_own")
)

# COMMAND ----------

# DBTITLE 1,Tr 8 - Finding Attributes
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 8 - Enrich with Finding and Event Attributes
# MAGIC
# MAGIC Left join on `parent_ID = qim_ID` of `df_findings_lookup`

# COMMAND ----------

# Enrich actions with finding-level attributes via parent_ID
df_actions_transf = df_actions_transf.join(
    df_findings_lookup,
    df_actions_transf["parent_ID"] == df_findings_lookup["_finding_id"],
    how="left",
).drop("_finding_id")

# Fill nulls for inherited finding attributes and owner
df_actions_transf = df_actions_transf.withColumns({
    "supplier_name": f.coalesce(f.col("supplier_name"), f.lit("Unassigned")),
    "owner": f.coalesce(f.col("owner"), f.lit("Unassigned")),
})

# COMMAND ----------

# DBTITLE 1,Tr 9 - Overdue Tagging
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 9 - Overdue Tagging
# MAGIC
# MAGIC Adds overdue classification columns based on `closure_date` vs `deadline_date`:
# MAGIC - `overdue_tag_label` — display-friendly tag with "Overdue" prefix on buckets
# MAGIC - `overdue_category` — simplified (no buckets): On Time (Closed) / Overdue (Closed) / On Time (Open) / Overdue (Open) / No Deadline (Open) / Canceled
# MAGIC - `overdue_category_rank` — sort order for Power BI
# MAGIC
# MAGIC | Condition | overdue_tag_label | overdue_category |
# MAGIC |---|---|---|
# MAGIC | `status` = 'Canceled' | Canceled | Canceled |
# MAGIC | `closure_date` ≤ `deadline_date` | On Time Closed | On Time (Closed) |
# MAGIC | `closure_date` > `deadline_date` | Overdue Closed | Overdue (Closed) |
# MAGIC | Closed + no deadline | On Time Closed | On Time (Closed) |
# MAGIC | Open + on time | On Time Open | On Time (Open) |
# MAGIC | Open + overdue | Overdue + bucket | Overdue (Open) |
# MAGIC | Open + no deadline | No deadline | No Deadline (Open) |

# COMMAND ----------

# --- overdue_tag: base tag with buckets ---
_days_overdue = f.datediff(f.current_date(), f.col("deadline_date"))

df_actions_transf = df_actions_transf.withColumn(
    "overdue_tag",
    f.when(f.col("status") == "Canceled", f.lit("Canceled")).when(
        f.col("closure_date").isNotNull(),
        f.when(f.col("deadline_date").isNull(), f.lit("On Time (Closed)"))
        .when(
            f.col("closure_date") <= f.col("deadline_date"), f.lit("On Time (Closed)")
        )
        .otherwise(f.lit("Overdue (Closed)")),
    )
    # Open actions
    .when(f.col("deadline_date").isNull(), f.lit("No deadline"))
    .when(_days_overdue <= 0, f.lit("On Time (Open)"))
    .when(_days_overdue.between(1, 6), f.lit("< 1w"))
    .when(_days_overdue.between(7, 13), f.lit("1-2w"))
    .when(_days_overdue.between(14, 30), f.lit("2w - 1m"))
    .when(_days_overdue.between(31, 90), f.lit("1-3m"))
    .when(_days_overdue > 90, f.lit("> 3m"))
    .otherwise(f.lit(None).cast("string")),
)

# --- overdue_tag_label: display-friendly (no parentheses, 'Overdue' prefix on buckets) ---
df_actions_transf = df_actions_transf.withColumn(
    "overdue_tag_label",
    f.when(f.col("overdue_tag") == "Canceled", f.lit("Canceled"))
    .when(f.col("overdue_tag") == "On Time (Closed)", f.lit("On Time"))
    .when(f.col("overdue_tag") == "Overdue (Closed)", f.lit("Overdue"))
    .when(f.col("overdue_tag") == "On Time (Open)", f.lit("On Time"))
    .when(f.col("overdue_tag") == "No deadline", f.lit("No deadline"))
    .when(f.col("overdue_tag") == "< 1w", f.lit("Overdue < 1w"))
    .when(f.col("overdue_tag") == "1-2w", f.lit("Overdue 1-2w"))
    .when(f.col("overdue_tag") == "2w - 1m", f.lit("Overdue 2w - 1m"))
    .when(f.col("overdue_tag") == "1-3m", f.lit("Overdue 1-3m"))
    .when(f.col("overdue_tag") == "> 3m", f.lit("Overdue > 3m"))
    .otherwise(f.lit(None).cast("string")),
)

# --- overdue_category: simplified (no buckets) ---
df_actions_transf = df_actions_transf.withColumn(
    "overdue_category",
    f.when(f.col("overdue_tag") == "Canceled", f.lit("Canceled"))
    .when(f.col("overdue_tag") == "On Time (Closed)", f.lit("On Time (Closed)"))
    .when(f.col("overdue_tag") == "Overdue (Closed)", f.lit("Overdue (Closed)"))
    .when(f.col("overdue_tag") == "No deadline", f.lit("No Deadline (Open)"))
    .when(f.col("overdue_tag") == "On Time (Open)", f.lit("On Time (Open)"))
    .otherwise(f.lit("Overdue (Open)")),
)

# --- overdue_category_rank: sort order for Power BI ---
df_actions_transf = df_actions_transf.withColumn(
    "overdue_category_rank",
    f.when(f.col("overdue_category") == "Canceled", f.lit(7))
    .when(f.col("overdue_category") == "On Time (Closed)", f.lit(1))
    .when(f.col("overdue_category") == "On Time (Open)", f.lit(2))
    .when(f.col("overdue_category") == "Overdue (Closed)", f.lit(3))
    .when(f.col("overdue_category") == "Overdue (Open)", f.lit(5))
    .when(f.col("overdue_category") == "No Deadline (Open)", f.lit(6))
    .otherwise(f.lit(99)),
)

# COMMAND ----------

# DBTITLE 1,QC after Transformations
# MAGIC %md
# MAGIC #### Quality Check after Transformations

# COMMAND ----------

pk_col = "qim_ID"
df_gx = SparkDFDataset(df_actions_transf, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=pk_col),
    df_gx.expect_column_values_to_be_unique(column=pk_col),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message=f"All {pk_col}(s) are unique and not null",
    error_message="Quality checks failed for QIM Actions gold table - PK not unique or contains nulls",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="actions_qim",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# DBTITLE 1,Outputs
# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# DBTITLE 1,Output LEAP Tables
# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# DBTITLE 1,Output Gold QIM Actions
# MAGIC %md
# MAGIC ### Output - Gold QIM Actions
# MAGIC
# MAGIC Saving of Gold QIM Actions table. Columns reordered into logical groups: identifiers, action metadata, dates, location, people, and boolean flags. Any remaining columns (e.g. `FRM_ACTION` prefixed) are appended at the end.
# MAGIC
# MAGIC

# COMMAND ----------

# DBTITLE 1,Cell 66
pk_col = "qim_ID"
df_gold = df_actions_transf.withColumn(pk_col, f.concat_ws("-", f.col(pk_col)))
df_gold = df_gold.withColumnRenamed("parent_doc_reference", "finding_reference")

ordered_cols = [
    # 1. Identifier
    "qim_ID",
    # 2. Document reference (main, resolved via Tr 1)
    "action_reference",
    "creation_date",
    # 3. Action metadata
    "action_name",
    "action_type",
    "status",
    "progress",
    "cause",
    "justification",
    "efficiency_criteria",
    "proof",
    "history_comments",
    "realisation_comments",
    # 4. Dates
    "realisation_date",
    "checking_date",
    "closure_date",
    "deadline_date",
    "initial_deadline_date",
    # 5. Location
    "action_site",
    "branch",
    "division",
    "region",
    # 6. People
    "owner",
    # 7. Flags
    "is_efficient",
    "is_cancelled",
    # 8. Overdue tagging
    "overdue_tag",
    "overdue_tag_label",
    "overdue_category",
    "overdue_category_rank",
    # 9. Hierarchy document references
    "finding_reference",
    "finding_reference_multiple",
    "event_reference",
    # 10. Finding attributes (from findings_exposed via parent_ID)
    "event_type",
    "event_status",
    "event_category",
    "finding_status",
    "customer_name",
    "supplier_name",
    "profit_center",
    "finding_process",
    "finding_type",
    "finding_nc_subtype",
    # 11. Original QIM IDs (at the end)
    "site_action_qim",
    "grand_parent_doc_ID",
    "parent_doc_ID",
    "parent_ID",
]

all_cols = df_gold.columns
final_cols = [c for c in ordered_cols if c in all_cols] + [
    c for c in all_cols if c not in ordered_cols
]
df_gold = df_gold.select(final_cols)

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "quality"
DESTINATION_TABLE = "actions_qim"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_gold,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

# --- PK constraint ---
TABLE_CONSTRAINT_NAME = "gold_actions_qim_pk"
TABLE_PK_COLS = pk_col

nb_cons = spark.sql(
    f"SELECT COUNT(*) FROM system.information_schema.table_constraints "
    f"WHERE table_catalog='{CATALOG}' AND table_schema='{SCHEMA}' "
    f"AND table_name='{DESTINATION_TABLE}' AND constraint_name='{TABLE_CONSTRAINT_NAME}'"
).first()[0]

if nb_cons == 0:
    table_utils.set_table_column_not_null(
        table_path=DESTINATION_TABLE_FULL_PATH, column=TABLE_PK_COLS
    )
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
    log.info(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' added.")
else:
    log.info(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' already exists.")

# --- Gold exposed view ---
_internal_ids = {"grand_parent_doc_ID", "parent_doc_ID", "parent_ID"}
selected_columns = [
    col
    for col in df_gold.columns
    if not col.startswith("FRM_ACTION") and col not in _internal_ids
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename=DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename=f"{DESTINATION_TABLE_FULL_PATH}_exposed",
    select_statement=select_statement,
    replace_view=True,
)
