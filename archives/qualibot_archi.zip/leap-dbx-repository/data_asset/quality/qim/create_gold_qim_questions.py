# Databricks notebook source
# DBTITLE 1,Notebook header
# MAGIC %md
# MAGIC    
# MAGIC # CREATE GOLD QIM QUESTIONS
# MAGIC
# MAGIC **Description:**  
# MAGIC Creates the gold table for QIM questions. Enriches with `document_reference` and `creation_date` from the documents table. Columns reordered into logical groups.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC Join on `qim_ID` with documents exposed view to retrieve document reference.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Quality - QIM
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver.quality.questions_qim
# MAGIC - {pipeline_read_env}_gold.quality.documents_qim_exposed
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.quality.questions_qim

# COMMAND ----------

# DBTITLE 1,Technical Debt
# MAGIC %md
# MAGIC    
# MAGIC # Technical Debt
# MAGIC
# MAGIC N/A

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC %md
# MAGIC    
# MAGIC # Configuration

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
# MAGIC %md
# MAGIC    
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f
from pyspark.sql.types import StringType

# COMMAND ----------

# DBTITLE 1,Config LEAP Function Imports
# MAGIC %md
# MAGIC    
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

# LEAP FUNCTION
from leap_utils.data_asset import table_utils, business_rules
from leap_utils.common.validation import gx_validation
from leap_utils.common import logger

# COMMAND ----------

# Quality checks
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# DBTITLE 1,Config Widgets
# MAGIC %md
# MAGIC    
# MAGIC ## Config Widgets

# COMMAND ----------

# DBTITLE 1,Pipeline Environments
# MAGIC %md
# MAGIC    
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# DBTITLE 1,Debug Boolean
# MAGIC %md
# MAGIC    
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Config logger
# MAGIC %md
# MAGIC    
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config - Common Functions
# MAGIC %md
# MAGIC    
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Preparation Common Functions
# MAGIC %md
# MAGIC    
# MAGIC ## Preparation - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Config other
# MAGIC %md
# MAGIC    
# MAGIC ## Config other
# MAGIC
# MAGIC N/A

# COMMAND ----------

# DBTITLE 1,Inputs
# MAGIC %md
# MAGIC    
# MAGIC # Inputs

# COMMAND ----------

# DBTITLE 1,Inputs - Functions
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Inputs - LEAP tables
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# DBTITLE 1,Import Silver Table
# MAGIC %md
# MAGIC    
# MAGIC ### Import Silver Table
# MAGIC
# MAGIC **df_questions** is the silver QIM questions table.

# COMMAND ----------

df_questions = spark.read.table(f"{PIPELINE_READ_ENV}_silver.quality.questions_qim")

# COMMAND ----------

# DBTITLE 1,Import Documents Reference
# MAGIC %md
# MAGIC    
# MAGIC ### Import QIM Documents Exposed
# MAGIC
# MAGIC **df_docs_exposed** is the gold exposed view of QIM documents. Used to enrich questions with `question_reference` and `creation_date`.

# COMMAND ----------

# DBTITLE 1,Cell 28
df_docs_exposed = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.quality.documents_qim_exposed"
)

# COMMAND ----------

# DBTITLE 1,Inputs - File Read
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Inputs - Manual declaration
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Data Preparation
# MAGIC %md
# MAGIC    
# MAGIC # Data Preparation
# MAGIC
# MAGIC ### Prep 1 - df_docs_ref
# MAGIC
# MAGIC Select only `qim_ID`, `reference`, and `creation_date` from `df_docs_exposed`.

# COMMAND ----------

df_docs_ref = df_docs_exposed.select("qim_ID", "reference", "creation_date")

# COMMAND ----------

# DBTITLE 1,Data Transformations header
# MAGIC %md
# MAGIC    
# MAGIC # Data Transformations

# COMMAND ----------

# DBTITLE 1,Tr1 - Document Reference
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 1 - Document Reference
# MAGIC
# MAGIC Enrich questions with their `question_reference` and `creation_date`. Inner join on `qim_ID` (only matched records are kept).

# COMMAND ----------

# DBTITLE 1,Cell 37
# Inner join to enrich questions with their document reference
df_questions_transf = (
    df_questions.join(df_docs_ref, on="qim_ID", how="inner")
    .withColumnRenamed("reference", "question_reference")
)

# COMMAND ----------

# DBTITLE 1,Tr2 - Normalize Family
# MAGIC %md
# MAGIC
# MAGIC ### Tr 2 - Normalize Family
# MAGIC
# MAGIC Fix capitalization inconsistencies in the `family` column. Known duplicates:
# MAGIC - `"system"` → `"System"`
# MAGIC - `"Special process"` → `"Special Process"`

# COMMAND ----------

# DBTITLE 1,Cell Tr2
df_questions_transf = df_questions_transf.withColumn(
    "family",
    f.when(f.col("family") == "system", f.lit("System"))
    .when(f.col("family") == "Special process", f.lit("Special Process"))
    .otherwise(f.col("family")),
)

# COMMAND ----------

# DBTITLE 1,df_gold ordered cols
# MAGIC %md
# MAGIC    
# MAGIC ### Output - Gold QIM Questions
# MAGIC
# MAGIC Saving of Gold QIM Questions table. Enriched with document reference. Columns reordered into logical groups. Any remaining columns (e.g. `FRM_QUESTION` prefixed) are appended at the end.

# COMMAND ----------

pk_col = "qim_ID"

ordered_cols = [
    # 1. Document reference
    "qim_ID",
    "question_reference",
    "creation_date",
    # 2. Questionnaire identification
    "questionnaire_name",
    "norm",
    "family",
    # 3. Question structure
    "chapter",
    "subchapter",
    "question_index",
    "question",
]

all_cols = df_questions_transf.columns
final_cols = [c for c in ordered_cols if c in all_cols] + [
    c for c in all_cols if c not in ordered_cols
]
df_gold = df_questions_transf.select(final_cols)

# COMMAND ----------

# DBTITLE 1,QC after Transformations
# MAGIC %md
# MAGIC    
# MAGIC #### Quality Check after Transformations

# COMMAND ----------

# Quality check: PK must be unique and not null
df_gx = SparkDFDataset(df_gold, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=pk_col),
    df_gx.expect_column_values_to_be_unique(column=pk_col),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message=f"All {pk_col}(s) are unique and not null",
    error_message="Quality checks failed for QIM Questions gold table - PK not unique or contains nulls",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="questions_qim",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# DBTITLE 1,Outputs
# MAGIC %md
# MAGIC    
# MAGIC # Outputs

# COMMAND ----------

# DBTITLE 1,Output - Common Functions
# MAGIC %md
# MAGIC    
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Output - LEAP Tables
# MAGIC %md
# MAGIC    
# MAGIC ## Output - LEAP Tables
# MAGIC
# MAGIC ### Output - Gold QIM Questions

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "quality"
DESTINATION_TABLE = "questions_qim"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_gold,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

# DBTITLE 1,PK constraint header
# MAGIC %md
# MAGIC    
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key constraint if not already present
TABLE_CONSTRAINT_NAME = "gold_questions_qim_pk"
TABLE_PK_COLS = pk_col

nb_cons = spark.sql(
    f"SELECT COUNT(*) FROM system.information_schema.table_constraints "
    f"WHERE table_catalog='{CATALOG}' AND table_schema='{SCHEMA}' "
    f"AND table_name='{DESTINATION_TABLE}' AND constraint_name='{TABLE_CONSTRAINT_NAME}'"
).first()[0]

if nb_cons == 0:
    table_utils.set_table_column_not_null(
        table_path=DESTINATION_TABLE_FULL_PATH, column=TABLE_PK_COLS
    )
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
    print(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' added.")
else:
    print(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' already exists.")

# COMMAND ----------

# DBTITLE 1,Output - Gold Exposed QIM Questions
# MAGIC %md
# MAGIC    
# MAGIC ### Output - Gold Exposed QIM Questions
# MAGIC
# MAGIC Create or Replace the gold exposed view. Removes columns still prefixed with `FRM_QUESTION` (internal/meta columns not in headers).

# COMMAND ----------

# Remove columns still prefixed with "FRM_QUESTION" (internal/meta columns not in headers)
selected_columns = [
    col for col in df_gold.columns if not col.startswith("FRM_QUESTION")
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename=DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename=f"{DESTINATION_TABLE_FULL_PATH}_exposed",
    select_statement=select_statement,
    replace_view=True,
)

# COMMAND ----------

# DBTITLE 1,Output - Files
# MAGIC %md
# MAGIC    
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
