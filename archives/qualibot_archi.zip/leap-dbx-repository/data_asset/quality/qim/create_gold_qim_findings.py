# Databricks notebook source
# DBTITLE 1,Notebook header
# MAGIC %md
# MAGIC    
# MAGIC # CREATE GOLD QIM FINDINGS
# MAGIC
# MAGIC **Description:**  
# MAGIC Creates the gold table for QIM findings. Enriches silver findings with document reference (from documents_qim_exposed) and the parent event document reference.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Quality - QIM
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {pipeline_read_env}_silver.quality.findings_qim
# MAGIC - {pipeline_read_env}_gold.quality.documents_qim_exposed
# MAGIC - {pipeline_read_env}_gold.quality.events_qim_exposed
# MAGIC - {pipeline_read_env}_gold.quality.actions_qim_exposed
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {pipeline_write_env}_gold.quality.findings_qim
# MAGIC - {pipeline_write_env}_gold.quality.findings_qim_exposed (view)

# COMMAND ----------

# DBTITLE 1,Technical Debt
# MAGIC %md
# MAGIC    
# MAGIC # Technical Debt
# MAGIC
# MAGIC N/A

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC %md
# MAGIC    
# MAGIC # Configuration

# COMMAND ----------

# DBTITLE 1,Config Standard Package Imports
# MAGIC %md
# MAGIC    
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

# STANDARD FUNCTION
import pyspark.sql.functions as f

# COMMAND ----------

# DBTITLE 1,Config LEAP Function Imports
# MAGIC %md
# MAGIC    
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

# LEAP FUNCTION
from leap_utils.data_asset import table_utils, business_rules
from leap_utils.common.validation import gx_validation
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset

# COMMAND ----------

# DBTITLE 1,Config Widgets
# MAGIC %md
# MAGIC    
# MAGIC ## Config Widgets
# MAGIC
# MAGIC ### Pipeline Environments

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# DBTITLE 1,Config logger
# MAGIC %md
# MAGIC    
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# DBTITLE 1,Config other
# MAGIC %md
# MAGIC    
# MAGIC ## Config other
# MAGIC
# MAGIC N/A

# COMMAND ----------

# DBTITLE 1,Inputs
# MAGIC %md
# MAGIC    
# MAGIC # Inputs

# COMMAND ----------

# DBTITLE 1,Inputs LEAP tables
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# DBTITLE 1,Import silver findings
# MAGIC %md
# MAGIC    
# MAGIC ### Import Silver QIM Findings
# MAGIC
# MAGIC **df_findings** is the silver QIM findings table. Contains cleaned, renamed, and deduplicated finding records.

# COMMAND ----------

df_findings = spark.read.table(f"{PIPELINE_READ_ENV}_silver.quality.findings_qim")

# COMMAND ----------

# DBTITLE 1,Import QIM documents exposed
# MAGIC %md
# MAGIC    
# MAGIC ### Import QIM Documents Exposed
# MAGIC
# MAGIC **df_docs_exposed** is the gold exposed view of QIM documents. Used to enrich findings with `document_reference` and `creation_date`.

# COMMAND ----------

# DBTITLE 1,Cell 18
df_docs_exposed = spark.read.table(f"{PIPELINE_READ_ENV}_gold.quality.documents_qim_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import HR Workforce View
# MAGIC
# MAGIC **_df_workforce** is the gold HR workforce monthly view. Used to resolve employee ID codes to full names (via `df_users_hr` built in Inputs - HR Workforce).

# COMMAND ----------

_df_workforce = spark.read.table("sd_prod_gold.hr.hr_workforce_gold_finance_view_monthly")

# COMMAND ----------

# DBTITLE 1,Import QIM events exposed
# MAGIC %md
# MAGIC    
# MAGIC ### Import QIM Events Exposed
# MAGIC
# MAGIC **df_events_exposed** is the gold exposed view of QIM events. Used in Tr 13 to enrich findings with `event_type` and `event_status` of the parent event.

# COMMAND ----------

# DBTITLE 1,Cell 22
df_events_exposed = spark.read.table(f"{PIPELINE_READ_ENV}_gold.quality.events_qim_exposed")

# COMMAND ----------

# DBTITLE 1,Import QIM Actions Exposed
# MAGIC %md
# MAGIC    
# MAGIC ### Import QIM Actions Exposed
# MAGIC
# MAGIC **df_actions_exposed** is the gold exposed view of QIM actions. Used to compute action progress per finding (total, completed, pending, progress %) and warning levels based on time consumed.

# COMMAND ----------

# DBTITLE 1,Cell 24
df_actions_exposed = spark.read.table(f"{PIPELINE_READ_ENV}_gold.quality.actions_qim_exposed")

# COMMAND ----------

# DBTITLE 1,Inputs File Read
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Inputs Manual Declaration
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# DBTITLE 1,Inputs - Functions
# MAGIC %md
# MAGIC    
# MAGIC ## Inputs - Functions
# MAGIC
# MAGIC | Function | Description |
# MAGIC |---|---|
# MAGIC | `format_employee_id(col_expr)` | Normalises an employee ID column expression to `L0XXXXXXX` format. IDs already starting with `L` are kept as-is. Null/empty values return null. |

# COMMAND ----------

def format_employee_id(col_expr):
    """Normalises an employee ID to L0XXXXXXX format (prefix L + 7-digit left-padded numeric part).
    IDs already starting with L are kept as-is. Null/empty values return null.
    """
    trimmed = f.trim(col_expr)
    return f.when(
        col_expr.isNotNull() & (trimmed != ""),
        f.when(trimmed.startswith("L"), trimmed)
         .otherwise(f.concat(f.lit("L"), f.lpad(trimmed, 7, "0")))
    )


# COMMAND ----------

# DBTITLE 1,Data Preparation
# MAGIC %md
# MAGIC    
# MAGIC # Data Preparation

# COMMAND ----------

# DBTITLE 1,Prep 1 - df_docs_ref
# MAGIC %md
# MAGIC    
# MAGIC ## Preparation 1 - df_docs_ref
# MAGIC
# MAGIC Select only `qim_ID`, `reference`, and `creation_date` from `df_docs_exposed`. Rename `reference` to `document_reference`.

# COMMAND ----------

df_docs_ref = df_docs_exposed.select("qim_ID", "reference", "creation_date")

# COMMAND ----------

# DBTITLE 1,Prep 2 - df_events_ref
# MAGIC %md
# MAGIC    
# MAGIC    
# MAGIC ## Preparation 2 - df_events_ref
# MAGIC
# MAGIC Select `event_ID` (alias of `qim_ID`) and `event_reference` from `df_docs_ref`. Used in Tr 2 to enrich findings with their parent event reference.

# COMMAND ----------

df_events_ref = df_docs_ref.select(
    f.col("qim_ID"),
    f.col("reference").alias("event_reference"),
)

# COMMAND ----------

# DBTITLE 1,Prep 3 - df_evt_lookup
# MAGIC %md
# MAGIC    
# MAGIC ## Preparation 3 - df_evt_lookup
# MAGIC
# MAGIC Select `qim_ID` (as join key), `event_name`, `event_type` and `computed_status` (renamed to `event_status`) from `df_events_exposed`. Used in Tr 13 to enrich findings via `event_ID = qim_ID` (unique PK, avoids duplication from non-unique `event_reference`).

# COMMAND ----------

df_evt_lookup = df_events_exposed.select(
    f.col("qim_ID").alias("_evt_id"),
    f.col("event_name"),
    f.col("event_type"),
    f.col("category").alias("event_category"),
    f.col("computed_status").alias("event_status"),
)

# COMMAND ----------

# DBTITLE 1,Prep 4 - df_users_hr
# MAGIC %md
# MAGIC    
# MAGIC    
# MAGIC ## Preparation 4 - df_users_hr
# MAGIC
# MAGIC Filter `_df_workforce` to the most recent extraction date, derive `employee_ID` (`L0XXXXXXX` format from `User_ID`) and `full_name` (`First_name` + `Last_name`). Used in Tr 10 to resolve employee ID codes to full names.

# COMMAND ----------

 # Read HR workforce view — keep only the most recent extraction date
_max_date = _df_workforce.agg(f.max("_leap_extraction_date")).first()[0]

df_users_hr = (
    _df_workforce
    .filter(f.col("_leap_extraction_date") == _max_date)
    .select("User_ID", "First_name", "Last_name")
    .dropDuplicates()
    .withColumn("full_name", f.concat_ws(" ", f.col("First_name"), f.col("Last_name")))
    .withColumn("employee_ID", f.concat(f.lit("L"), f.lpad(f.col("User_ID"), 7, "0")))
    .select("employee_ID", "full_name")
)

# COMMAND ----------

# DBTITLE 1,Prep 5 - df_actions_summary
# MAGIC %md
# MAGIC    
# MAGIC ## Preparation 5 - df_actions_summary
# MAGIC
# MAGIC Aggregate actions per finding from `df_actions_exposed`. Computes per-finding action counts and progress percentage.
# MAGIC

# COMMAND ----------

df_actions_summary = (
    df_actions_exposed
    .groupBy("finding_reference")
    .agg(
        f.count("*").alias("actions_total_count"),
        f.sum(f.when(f.col("status") == "Closed", 1).otherwise(0)).alias("actions_completed_count"),
        f.sum(f.when(f.col("status") == "Canceled", 1).otherwise(0)).alias("actions_cancelled_count"),
        f.sum(f.when(f.col("status") == "Opened", 1).otherwise(0)).alias("actions_pending_count"),
        f.concat_ws(", ", f.collect_list("action_reference")).alias("actions_list"),
    )
    .withColumn(
        "actions_progress_pct",
        f.when(
            (f.col("actions_total_count") - f.col("actions_cancelled_count")) > 0,
            f.round(
                f.col("actions_completed_count")
                / (f.col("actions_total_count") - f.col("actions_cancelled_count"))
                * 100,
                1,
            ),
        ).otherwise(f.lit(None).cast("double")),
    )
)

# COMMAND ----------

# DBTITLE 1,Data Transformations
# MAGIC %md
# MAGIC    
# MAGIC # Data Transformations

# COMMAND ----------

# DBTITLE 1,Tr 1 - Finding Document Reference
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 1 - Finding Document Reference
# MAGIC
# MAGIC Enrich findings with their own `finding_reference` and `creation_date`. Inner join on `qim_ID` (only matched records are kept).

# COMMAND ----------

# DBTITLE 1,Cell 44
# Inner join to enrich findings with their own document reference
df_findings_transf = (
    df_findings
    .join(df_docs_ref, on="qim_ID", how="inner")
    .withColumnRenamed("reference", "finding_reference")
)

# COMMAND ----------

# DBTITLE 1,Tr2 - Event Document Reference
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 2 - Event Document Reference
# MAGIC
# MAGIC Left join on `event_ID` with `df_events_ref` to retrieve the `event_reference` of the parent event.

# COMMAND ----------

df_findings_transf = (
    df_findings_transf
    .join(df_events_ref, on=df_findings_transf["event_qim_ID"] == df_events_ref["qim_ID"], how="left")
    .drop(df_events_ref["qim_ID"])
)

# COMMAND ----------

# DBTITLE 1,Tr3 - YES/NO to boolean
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 3 - Convert YES/NO columns to boolean
# MAGIC
# MAGIC All columns starting with `is_` contain `"Yes"`/`"No"` string values. Converted to proper `boolean` type.

# COMMAND ----------

# All is_* columns are YES/NO — convert to boolean
is_cols = [c for c in df_findings_transf.columns if c.startswith("is_")]

df_findings_transf = df_findings_transf.withColumns({
    c: f.when(f.upper(f.col(c)) == "YES", f.lit(True))
       .when(f.upper(f.col(c)) == "NO", f.lit(False))
       .otherwise(f.lit(None).cast("boolean"))
    for c in is_cols
})

# COMMAND ----------

# DBTITLE 1,Tr5 - Multi-value columns to arrays
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 4 - Convert multi-value columns to arrays
# MAGIC
# MAGIC Multi-value string columns converted to `array<string>`:
# MAGIC
# MAGIC | Column | Delimiters | Notes |
# MAGIC |---|---|---|
# MAGIC | `cc_subtype` | `;` | |
# MAGIC | `impacted_site_qim` | `;` | |
# MAGIC | `customer_name` | `{0}` and `;` | `{0}` normalized to `;` before split |
# MAGIC | `profit_center` | ` / ` and `;` | ` / ` normalized to `;` before split |

# COMMAND ----------

df_findings_transf = df_findings_transf.withColumns({
    "cc_subtype":        f.split(f.col("cc_subtype"), ";"),
    "impacted_site_qim": f.filter(
        f.split(f.col("impacted_site_qim"), ";"),
        lambda x: x.isNotNull() & (f.trim(x) != "")
    ),
    "customer_name":     f.split(f.regexp_replace(f.col("customer_name"), r"\{0\}", ";"), ";"),
    "profit_center":     f.split(f.regexp_replace(f.col("profit_center"), r" / ", ";"), ";"),
})

# COMMAND ----------

# DBTITLE 1,Tr 6 - Site Mapping (Impacted Site - array)
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 5 - Add Impacted Site Name (array)
# MAGIC
# MAGIC Each element of `impacted_site_qim` (raw QIM site codes) is resolved to its conventional site name, division and region using `business_rules.add_site_region_division` with `domain="qn"`. Results stored in `impacted_site`, `impacted_division`, `impacted_region`. Special cases applied per element:
# MAGIC - `FRN` — no entry in mapping table; name, division and region set directly to `"Supplier"`.
# MAGIC - `LFR-T` — mapping returns `"LATE Montredon"`; name overridden to `"LATE - Mach1"`; division and region kept from mapping.
# MAGIC - `CUSTA` — maps to `"LATE - Colomiers"`; if `branch == "Interconnection Systems"` → `"LFR1 - Colomiers"`.
# MAGIC - `HQ` — maps to `"LATE - Mach1"`; if `branch == "Interconnection Systems"` → `"LFR1 - Mach1"`.
# MAGIC
# MAGIC Approach: explode `impacted_site_qim` array → apply mapping → collect back (preserving original element order via position index).

# COMMAND ----------

# Explode impacted_site_qim array to apply per-element site name mapping
_df_sites = (
    df_findings_transf
    .select("qim_ID", "branch", f.posexplode_outer(f.col("impacted_site_qim")).alias("_pos", "_site_code"))
)

_df_sites = business_rules.add_site_region_division(
    df=_df_sites,
    site_col="_site_code",
    domain="qn",
    conventional_site_col="_site_name",
    division_col="_site_division",
    region_col="_site_region",
    reference_read_env=REFERENCE_READ_ENV,
)

# Special cases: FRN → name/division/region all set to 'Supplier'; LFR-T → name overridden to 'LATE - Mach1'
_df_sites = _df_sites.withColumns({
    "_site_resolved": (
        f.when(f.col("_site_code") == "FRN", f.lit("Supplier"))
         .when(f.col("_site_code") == "LFR-T", f.lit("LATE - Mach1"))
         .when((f.col("_site_code") == "CUSTA") & (f.col("branch") == "Interconnection Systems"), f.lit("LFR1 - Colomiers"))
         .when((f.col("_site_code") == "HQ")    & (f.col("branch") == "Interconnection Systems"), f.lit("LFR1 - Mach1"))
         .otherwise(f.coalesce(f.col("_site_name"), f.col("_site_code")))
    ),
    "_division_resolved": (
        f.when(f.col("_site_code") == "FRN", f.lit("Supplier"))
         .otherwise(f.col("_site_division"))
    ),
    "_region_resolved": (
        f.when(f.col("_site_code") == "FRN", f.lit("Supplier"))
         .otherwise(f.col("_site_region"))
    ),
})

# Collect back into ordered arrays (preserving original element order via _pos)
# Filter nulls: posexplode_outer on a null array yields one row with _site_code=null,
# which would produce [null] instead of null — exclude those rows so the left join returns null
# (empty strings already removed at split step in Tr 4)
_df_impacted_resolved = (
    _df_sites
    .filter(f.col("_site_code").isNotNull())
    .groupBy("qim_ID")
    .agg(
        f.sort_array(
            f.collect_list(f.struct(
                f.col("_pos").alias("pos"),
                f.col("_site_resolved").alias("site"),
                f.col("_division_resolved").alias("division"),
                f.col("_region_resolved").alias("region"),
            ))
        ).alias("_sorted")
    )
    .withColumns({
        "impacted_site":     f.transform(f.col("_sorted"), lambda x: x["site"]),
        "impacted_division": f.transform(f.col("_sorted"), lambda x: x["division"]),
        "impacted_region":   f.transform(f.col("_sorted"), lambda x: x["region"]),
    })
    .select("qim_ID", "impacted_site", "impacted_division", "impacted_region")
)

# impacted_site_qim is kept (raw codes); impacted_site/division/region are the new resolved columns
df_findings_transf = df_findings_transf.join(_df_impacted_resolved, on="qim_ID", how="left")

# COMMAND ----------

# DBTITLE 1,Tr 7 - Site Mapping (Liable Site)
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 6 - Add Liable Site Name
# MAGIC
# MAGIC Resolves `liable_site_qim` (raw QIM code) to its conventional name, division and region using `business_rules.add_site_region_division` with `domain="qn"`. Results stored in `liable_site`, `liable_division`, `liable_region`. Special cases applied after mapping:
# MAGIC - `FRN` — no entry in mapping table; name, division and region set directly to `"Supplier"`.
# MAGIC - `LFR-T` — mapping returns `"LATE Montredon"`; name overridden to `"LATE - Mach1"`; division and region kept from mapping.
# MAGIC - `CUSTA` — maps to `"LATE - Colomiers"`; if `branch == "Interconnection Systems"` → `"LFR1 - Colomiers"`.
# MAGIC - `HQ` — maps to `"LATE - Mach1"`; if `branch == "Interconnection Systems"` → `"LFR1 - Mach1"`.
# MAGIC - Fallback for site: if not found in mapping, keep raw `liable_site_qim` code.

# COMMAND ----------

# DBTITLE 1,Cell 54
df_findings_transf = business_rules.add_site_region_division(
    df=df_findings_transf,
    site_col="liable_site_qim",
    domain="qn",
    conventional_site_col="liable_site",
    division_col="liable_division",
    region_col="liable_region",
    reference_read_env=REFERENCE_READ_ENV,
)

# Special cases: FRN → name/division/region all 'Supplier'; LFR-T → name overridden to 'LATE - Mach1'
# Fallback for site: if not found in mapping, keep the original raw code from liable_site_qim
df_findings_transf = df_findings_transf.withColumns({
    "liable_site": (
        f.when(f.col("liable_site_qim") == "FRN", f.lit("Supplier"))
         .when(f.col("liable_site_qim") == "LFR-T", f.lit("LATE - Mach1"))
         .when((f.col("liable_site_qim") == "CUSTA") & (f.col("branch") == "Interconnection Systems"), f.lit("LFR1 - Colomiers"))
         .when((f.col("liable_site_qim") == "HQ")    & (f.col("branch") == "Interconnection Systems"), f.lit("LFR1 - Mach1"))
         .otherwise(f.coalesce(f.col("liable_site"), f.col("liable_site_qim")))
    ),
    "liable_division": (
        f.when(f.col("liable_site_qim") == "FRN", f.lit("Supplier"))
         .otherwise(f.col("liable_division"))
    ),
    "liable_region": (
        f.when(f.col("liable_site_qim") == "FRN", f.lit("Supplier"))
         .otherwise(f.col("liable_region"))
    ),
})

# COMMAND ----------

# DBTITLE 1,Tr6 - Normalize status values
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 7 - Normalize status values
# MAGIC
# MAGIC `"Submited"` (typo) and `"Submitted"` coexist in the source — both normalized to `"Submitted"`.

# COMMAND ----------

# Normalize status: "Submited" -> "Submitted"
df_findings_transf = df_findings_transf.withColumn(
    "status",
    f.when(f.col("status") == "Submited", f.lit("Submitted")).otherwise(f.col("status")),
)

# COMMAND ----------

# DBTITLE 1,Tr 9 - Event linkage flag
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 8 - Event Linkage Flag
# MAGIC
# MAGIC Derives `has_event` from `event_reference`: `true` if the finding is associated with a parent QIM event, `false` if orphaned (no event reference found).

# COMMAND ----------

df_findings_transf = df_findings_transf.withColumn(
    "has_event",
    f.col("event_reference").isNotNull(),
)

# COMMAND ----------

# DBTITLE 1,Tr 10 - Resolve Employee IDs to Full Names
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 9 - Resolve Employee IDs to Full Names
# MAGIC
# MAGIC Replaces employee ID codes in `analyst`, `assessor`, `step_one_validator` (scalar) and `auditors` (string) with the corresponding `full_name` from the HR workforce table.
# MAGIC
# MAGIC - **Scalar columns** (`analyst`, `assessor`, `step_one_validator`): IDs normalised to `L0XXXXXXX` format, left join on `employee_ID`, fallback to formatted ID.
# MAGIC - **`auditors`** (STRING, may contain `";"`-separated values): each element is resolved independently. Elements that match a numeric employee ID pattern (pure digits or `L+digits`) are resolved; plain text values (already names) are kept as-is. Result rejoined with `"; "`.

# COMMAND ----------

df_users_lookup = df_users_hr.select("employee_ID", "full_name")

# --- Scalar: analyst ---
df_findings_transf = df_findings_transf.withColumn("analyst", format_employee_id(f.col("analyst")))
log.info("LEFT JOIN: analyst → full_name (unmatched IDs kept as-is)")
df_findings_transf = (
    df_findings_transf
    .join(
        df_users_lookup.select(f.col("employee_ID").alias("analyst"), f.col("full_name").alias("_an")),
        on="analyst", how="left",
    )
    .withColumn("analyst", f.coalesce(f.col("_an"), f.col("analyst")))
    .drop("_an")
)

# --- Scalar: assessor ---
df_findings_transf = df_findings_transf.withColumn("assessor", format_employee_id(f.col("assessor")))
log.info("LEFT JOIN: assessor → full_name (unmatched IDs kept as-is)")
df_findings_transf = (
    df_findings_transf
    .join(
        df_users_lookup.select(f.col("employee_ID").alias("assessor"), f.col("full_name").alias("_as")),
        on="assessor", how="left",
    )
    .withColumn("assessor", f.coalesce(f.col("_as"), f.col("assessor")))
    .drop("_as")
)

# --- Scalar: step_one_validator ---
df_findings_transf = df_findings_transf.withColumn("step_one_validator", format_employee_id(f.col("step_one_validator")))
log.info("LEFT JOIN: step_one_validator → full_name (unmatched IDs kept as-is)")
df_findings_transf = (
    df_findings_transf
    .join(
        df_users_lookup.select(f.col("employee_ID").alias("step_one_validator"), f.col("full_name").alias("_sv")),
        on="step_one_validator", how="left",
    )
    .withColumn("step_one_validator", f.coalesce(f.col("_sv"), f.col("step_one_validator")))
    .drop("_sv")
)

# --- String (semicolons): auditors ---
# auditors is a STRING: null / plain text names / ';'-separated mixture of names and IDs
# Rule: elements matching a numeric ID pattern (pure digits or L+digits) are resolved;
#       plain text elements (already names) are kept as-is; null field stays null.
log.info("LEFT JOIN: auditors (string) → full_name per numeric element (text kept as-is)")

# Explode → join → collect_list using qim_ID as validated PK (same pattern as events)
_df_auditors_parts = (
    df_findings_transf
    .select("qim_ID", f.explode(f.split(f.col("auditors"), ";")).alias("_part"))
    .filter(f.trim(f.col("_part")) != "")
    .withColumn(
        "_formatted",
        f.when(
            f.trim(f.col("_part")).rlike(r"^\d+$") | f.trim(f.col("_part")).rlike(r"^L\d+$"),
            format_employee_id(f.trim(f.col("_part")))
        ).otherwise(f.trim(f.col("_part")))
    )
)

_df_auditors_parts = (
    _df_auditors_parts
    .join(
        df_users_lookup.select(f.col("employee_ID").alias("_formatted"), f.col("full_name").alias("_name")),
        on="_formatted", how="left",
    )
    .withColumn("_resolved", f.coalesce(f.col("_name"), f.col("_formatted")))
)

_df_auditors_resolved = (
    _df_auditors_parts
    .groupBy("qim_ID")
    .agg(f.collect_list("_resolved").alias("_parts"))
    .withColumn("auditors", f.array_join(f.col("_parts"), "; "))
    .select("qim_ID", "auditors")
)

df_findings_transf = (
    df_findings_transf
    .drop("auditors")
    .join(_df_auditors_resolved, on="qim_ID", how="left")
)

# COMMAND ----------

# DBTITLE 1,Tr 11 - Workflow Phase
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 10 - Derive Workflow Phase
# MAGIC
# MAGIC Following business rule, classifies each finding into a workflow phase. **Status-based overrides take priority** over `workflow_step`:
# MAGIC
# MAGIC | Condition | Phase |
# MAGIC |---|---|
# MAGIC | `status = 'Canceled'` | 5. Canceled |
# MAGIC | `status = 'Closed'` | 4. Efficiency and Evaluation |
# MAGIC
# MAGIC Then, for open findings, classification is based on `workflow_step`:
# MAGIC
# MAGIC | Steps | Phase |
# MAGIC |---|---|
# MAGIC | 01A/B/C, Completion | 1. Completion |
# MAGIC | 02–07, 2.\* | 2. Defect characterisation & RCA |
# MAGIC | 08–09, 3.\* | 3. Action Plan Follow-Up |
# MAGIC | 10–11, 4.\* | 4. Efficiency and Evaluation |
# MAGIC
# MAGIC Null `workflow_step` values yield `null`.

# COMMAND ----------

# Classify workflow_step into workflow phases
# Status-based overrides take priority: Canceled → '5. Canceled', Closed → '4. Efficiency and Evaluation'
df_findings_transf = df_findings_transf.withColumn(
    "workflow_phase",
    f.when(f.col("status") == "Canceled", f.lit("5. Canceled"))
     .when(f.col("status") == "Closed", f.lit("4. Efficiency and Evaluation"))
     # Standard steps: 01A/B/C, Completion → 1. Completion
     .when(f.col("workflow_step").startswith("01"), f.lit("1. Completion"))
     .when(f.col("workflow_step") == "Completion", f.lit("1. Completion"))
     # Standard steps: 02-07 → 2. Defect characterisation & RCA
     .when(f.col("workflow_step").startswith("02"), f.lit("2. Defect characterisation & RCA"))
     .when(f.col("workflow_step").startswith("03"), f.lit("2. Defect characterisation & RCA"))
     .when(f.col("workflow_step").startswith("04"), f.lit("2. Defect characterisation & RCA"))
     .when(f.col("workflow_step").startswith("05"), f.lit("2. Defect characterisation & RCA"))
     .when(f.col("workflow_step").startswith("06"), f.lit("2. Defect characterisation & RCA"))
     .when(f.col("workflow_step").startswith("07"), f.lit("2. Defect characterisation & RCA"))
     # Standard steps: 08-09 → 3. Action Plan Follow-Up
     .when(f.col("workflow_step").startswith("08"), f.lit("3. Action Plan Follow-Up"))
     .when(f.col("workflow_step").startswith("09"), f.lit("3. Action Plan Follow-Up"))
     # Standard steps: 10-11 → 4. Efficiency and Evaluation
     .when(f.col("workflow_step").startswith("10"), f.lit("4. Efficiency and Evaluation"))
     .when(f.col("workflow_step").startswith("11"), f.lit("4. Efficiency and Evaluation"))
     # Legacy steps (single-digit prefix without leading zero)
     .when(f.col("workflow_step").startswith("2."), f.lit("2. Defect characterisation & RCA"))
     .when(f.col("workflow_step").startswith("3."), f.lit("3. Action Plan Follow-Up"))
     .when(f.col("workflow_step").startswith("4."), f.lit("4. Efficiency and Evaluation"))
     .otherwise(f.lit(None).cast("string")),
)

# COMMAND ----------

# DBTITLE 1,Tr 11 - Overdue Tagging
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 11 - Overdue Tagging
# MAGIC
# MAGIC General overdue classification columns: tags, category, and group.

# COMMAND ----------

# DBTITLE 1,Tr 11 - General Overdue
# MAGIC %md
# MAGIC #### Tr 11 - General Overdue
# MAGIC
# MAGIC Adds columns for aging analysis:
# MAGIC
# MAGIC | Column | Type | Description |
# MAGIC |---|---|---|
# MAGIC | `calculated_closing_date` | date | Generic closure date: `COALESCE(finding_closing_date, expected_closure_date)` |
# MAGIC | `is_open` | boolean | `true` if finding is still open (status ≠ Closed/Canceled), `false` otherwise |
# MAGIC | `days_open` | int | Days between `creation_date` and `finding_closing_date` (if closed) or `current_date` (if open) |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC **Imputations before tagging:**
# MAGIC
# MAGIC - `finding_closing_date`: if status = Closed and NULL → defaults to `creation_date` so closed findings always have a reference date for comparison.
# MAGIC - `expected_closure_date`: `COALESCE(expected_closure_date, creation_date + 3 months)` — falls back to business rule default to minimize findings landing in the "No deadline" category.

# COMMAND ----------

# --- Impute missing finding_closing_date for Closed findings ---
# If a finding is Closed but has no actual closing date, default to creation_date
df_findings_transf = df_findings_transf.withColumn(
    "finding_closing_date",
    f.when(
        (f.col("status") == "Closed") & f.col("finding_closing_date").isNull(),
        f.col("creation_date")
    ).otherwise(f.col("finding_closing_date"))
)

# --- Impute missing expected_closure_date: default to creation_date + 3 months --- confirmed business rule
df_findings_transf = df_findings_transf.withColumn(
    "expected_closure_date",
    f.coalesce(
        f.col("expected_closure_date"),
        f.expr("creation_date + INTERVAL 3 MONTHS"),
    ),
)

# --- closing_date: generic closure date ---
df_findings_transf = df_findings_transf.withColumn(
    "calculated_closing_date",
    f.coalesce(f.col("finding_closing_date"), f.col("expected_closure_date")),
)

# --- is_open: true if finding is still open ---
df_findings_transf = df_findings_transf.withColumn(
    "is_open",
    ~f.col("status").isin("Closed", "Canceled"),
)

# --- days_open: days from creation_date to closing (or today if still open) ---
df_findings_transf = df_findings_transf.withColumn(
    "days_open",
    f.datediff(
        f.when(f.col("is_open"), f.current_date()).otherwise(f.col("finding_closing_date")),
        f.col("creation_date"),
    ),
)

# --- overdue_tag: based on expected_closure_date ---
# Closed findings: compare finding_closing_date vs expected_closure_date
# Open findings: compare current_date vs expected_closure_date (with buckets)
_days_overdue_general = f.datediff(f.current_date(), f.col("expected_closure_date"))

df_findings_transf = df_findings_transf.withColumn(
    "overdue_tag",
    f.when(f.col("status") == "Canceled", f.lit("Canceled"))
     .when(
         f.col("status") == "Closed",
         f.when(f.col("expected_closure_date").isNull(), f.lit("On Time (Closed)"))
          .when(f.col("finding_closing_date") <= f.col("expected_closure_date"), f.lit("On Time (Closed)"))
          .otherwise(f.lit("Overdue (Closed)"))
     )
     # Open findings
     .when(f.col("expected_closure_date").isNull(), f.lit("No deadline"))
     .when(_days_overdue_general <= 0, f.lit("On Time (Open)"))
     .when(_days_overdue_general.between(1, 13), f.lit("< 2w"))
     .when(_days_overdue_general.between(14, 30), f.lit("2w - 1m"))
     .when(_days_overdue_general.between(31, 90), f.lit("1-3m"))
     .when(_days_overdue_general > 90, f.lit("> 3m"))
     .otherwise(f.lit(None).cast("string"))
)

# --- overdue_tag_label: display-friendly version (no parentheses, 'Overdue' prefix on buckets) ---
df_findings_transf = df_findings_transf.withColumn(
    "overdue_tag_label",
    f.when(f.col("overdue_tag") == "Canceled", f.lit("Canceled"))
     .when(f.col("overdue_tag") == "On Time (Closed)", f.lit("On Time"))
     .when(f.col("overdue_tag") == "Overdue (Closed)", f.lit("Overdue"))
     .when(f.col("overdue_tag") == "On Time (Open)", f.lit("On Time"))
     .when(f.col("overdue_tag") == "No deadline", f.lit("No deadline"))
     .when(f.col("overdue_tag") == "< 2w", f.lit("Overdue < 2w"))
     .when(f.col("overdue_tag") == "2w - 1m", f.lit("Overdue 2w - 1m"))
     .when(f.col("overdue_tag") == "1-3m", f.lit("Overdue 1-3m"))
     .when(f.col("overdue_tag") == "> 3m", f.lit("Overdue > 3m"))
     .otherwise(f.lit(None).cast("string"))
)

# --- overdue_tag_label_2: binary On Time / Overdue ---
df_findings_transf = df_findings_transf.withColumn(
    "overdue_tag_label_2",
    f.when(f.col("overdue_tag") == "Canceled", f.lit("Canceled"))
     .when(f.col("overdue_tag").isin("On Time (Closed)", "On Time (Open)"), f.lit("On Time"))
     .otherwise(f.lit("Overdue"))
)

# --- overdue_category: simplified tag without buckets ---
# Collapses all overdue buckets into a single category.
# Highlights Major NCs with a distinct label when overdue.
df_findings_transf = df_findings_transf.withColumn(
    "overdue_category",
    f.when(f.col("status") == "Canceled", f.lit("Canceled"))
     .when(
         f.col("status") == "Closed",
         f.when(f.col("overdue_tag") == "On Time (Closed)", f.lit("On Time (Closed)"))
          .when(f.col("overdue_tag") == "Overdue (Closed)", f.lit("Overdue (Closed)"))
          .otherwise(f.lit("On Time (Closed)"))  # no expected_closure_date → assume on time
     )
     # Open findings
     .when(f.col("overdue_tag") == "No deadline", f.lit("No Deadline (Open)"))
     .when(f.col("overdue_tag") == "On Time (Open)", f.lit("On Time (Open)"))
     # All overdue buckets (< 1w, 1-2w, etc.) → single Overdue label
     .when(f.col("nc_subtype") == "Major", f.lit("Overdue Major (Open)"))
     .otherwise(f.lit("Overdue (Open)"))
)

# --- overdue_tag_rank: sort order for overdue_tag in Power BI ---

df_findings_transf = df_findings_transf.withColumn(
    "overdue_tag_rank",
    f.when(f.col("overdue_tag") == "Canceled", f.lit(9))
     .when(f.col("overdue_tag") == "On Time (Closed)", f.lit(1))
     .when(f.col("overdue_tag") == "Overdue (Closed)", f.lit(2))
     .when(f.col("overdue_tag") == "On Time (Open)", f.lit(3))
     .when(f.col("overdue_tag") == "< 2w", f.lit(4))
     .when(f.col("overdue_tag") == "2w - 1m", f.lit(5))
     .when(f.col("overdue_tag") == "1-3m", f.lit(6))
     .when(f.col("overdue_tag") == "> 3m", f.lit(7))
     .when(f.col("overdue_tag") == "No deadline", f.lit(10))
     .otherwise(f.lit(99))
)

# --- overdue_group: simplified grouping for chart (ignores open/closed distinction) ---
df_findings_transf = df_findings_transf.withColumn(
    "overdue_group",
    f.when(f.col("overdue_category") == "Canceled", f.lit("Canceled"))
     .when(f.col("overdue_category").contains("On Time"), f.lit("On Time"))
     .when(f.col("overdue_category") == "Overdue Major (Open)", f.lit("Overdue Major"))
     .when(f.col("overdue_category").contains("Overdue"), f.lit("Overdue"))
     .when(f.col("overdue_category").contains("No Deadline"), f.lit("No Deadline"))
     .otherwise(f.lit(None).cast("string"))
)

# --- overdue_group_rank: sort order for overdue_group in Power BI ---
df_findings_transf = df_findings_transf.withColumn(
    "overdue_group_rank",
    f.when(f.col("overdue_group") == "On Time", f.lit(1))
     .when(f.col("overdue_group") == "Overdue", f.lit(2))
     .when(f.col("overdue_group") == "Overdue Major", f.lit(3))
     .when(f.col("overdue_group") == "No Deadline", f.lit(4))
     .when(f.col("overdue_group") == "Canceled", f.lit(5))
     .otherwise(f.lit(99))
)

# --- overdue_category_rank: sort order for overdue_category in Power BI ---
df_findings_transf = df_findings_transf.withColumn(
    "overdue_category_rank",
    f.when(f.col("overdue_category") == "Canceled", f.lit(7))
     .when(f.col("overdue_category") == "On Time (Closed)", f.lit(1))
     .when(f.col("overdue_category") == "Overdue (Closed)", f.lit(3))
     .when(f.col("overdue_category") == "On Time (Open)", f.lit(2))
     .when(f.col("overdue_category") == "Overdue Major (Open)", f.lit(4))
     .when(f.col("overdue_category") == "Overdue (Open)", f.lit(5))
     .when(f.col("overdue_category") == "No Deadline (Open)", f.lit(6))
     .otherwise(f.lit(99))
)

# COMMAND ----------

# DBTITLE 1,Tr 12 - Event Type & Status
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 12 - Add Event Type & Status
# MAGIC
# MAGIC Enriches findings with `event_type` and `event_status` from the parent event. Left join on `event_ID = qim_ID` (PK of events table, avoids fan-out from duplicate `event_reference` values).
# MAGIC
# MAGIC - `event_type`: type of the parent QIM event (e.g. Internal Audit, Supplier Audit)
# MAGIC - `event_status`: computed status of the parent event (e.g. Closed, In progress, Overdue)
# MAGIC - `event_type_category`: concatenation of `event_type` and `event_category` (`event_type - event_category`)

# COMMAND ----------

# Left join to enrich findings with parent event type, category and status
df_findings_transf = (
    df_findings_transf
    .join(df_evt_lookup, df_findings_transf["event_qim_ID"] == df_evt_lookup["_evt_id"], how="left")
    .drop("_evt_id")
)

# Combined event type-category: "No Event" when both are null, otherwise concat
df_findings_transf = df_findings_transf.withColumn(
    "event_type_category",
    f.when(
        f.col("event_type").isNotNull() | f.col("event_category").isNotNull(),
        f.concat_ws(" - ", f.col("event_type"), f.col("event_category")),
    ).otherwise(f.lit("No Event")),
)

# Fill nulls for clean visualization
df_findings_transf = df_findings_transf.withColumns({
    "liable_site":     f.coalesce(f.col("liable_site"), f.lit("Unassigned")),
    "liable_division": f.coalesce(f.col("liable_division"), f.lit("Unassigned")),
    "event_name": f.coalesce(f.col("event_name"), f.lit("No Event")),
    "event_type": f.coalesce(f.col("event_type"), f.lit("No Event")),
    "event_category": f.coalesce(f.col("event_category"), f.lit("No Event")),
    "event_status": f.coalesce(f.col("event_status"), f.lit("No Event")),
    "nc_subtype":    f.coalesce(f.col("nc_subtype"), f.lit("Unassigned")),
    "finding_type": f.coalesce(f.col("finding_type"), f.lit("Unassigned")),
    "process": f.coalesce(f.col("process"), f.lit("Unassigned")),
    "supplier_name": f.coalesce(f.col("supplier_name"), f.lit("Unassigned")),
    "origin": f.coalesce(f.col("origin"), f.lit("Unassigned")),
    "analyst": f.coalesce(f.col("analyst"), f.lit("Unassigned"))
})

# COMMAND ----------

# DBTITLE 1,Tr 13 - Actions & Warning Level
# MAGIC %md
# MAGIC    
# MAGIC ### Tr 13 - Actions Summary & Warning Level
# MAGIC
# MAGIC Enriches findings with action progress metrics (`df_actions_summary`), time-based warning levels, and pending-closure flags.
# MAGIC
# MAGIC | Column | Description |
# MAGIC |---|---|
# MAGIC | `time_consumed_pct` | Elapsed days / total days × 100 (creation → expected closure) |
# MAGIC | `days_to_deadline` / `days_overdue` | Dashboard display metrics |
# MAGIC | `warning_level` | `On Track` (< 70%), `At Risk` (70–85%), `Near Overdue` (85–100%), `Overdue` (> 100%) — open findings only |
# MAGIC | `is_pending_closure` | All non-cancelled actions completed but finding still open |
# MAGIC | `actions_status` | `Closure Pending`, `Actions Pending`, `Actions To Be Created`, or null |

# COMMAND ----------

# --- Join with actions summary ---
df_findings_transf = (
    df_findings_transf
    .join(df_actions_summary, on="finding_reference", how="left")
)

# Fill nulls for findings without actions
df_findings_transf = df_findings_transf.withColumns({
    "actions_total_count":     f.coalesce(f.col("actions_total_count"), f.lit(0)),
    "actions_completed_count": f.coalesce(f.col("actions_completed_count"), f.lit(0)),
    "actions_cancelled_count": f.coalesce(f.col("actions_cancelled_count"), f.lit(0)),
    "actions_pending_count":   f.coalesce(f.col("actions_pending_count"), f.lit(0)),
})

# --- Time consumed percentage ---
_total_days = f.datediff(f.col("expected_closure_date"), f.col("creation_date"))
_elapsed_days = f.datediff(f.current_date(), f.col("creation_date"))

df_findings_transf = df_findings_transf.withColumn(
    "time_consumed_pct",
    f.when(
        _total_days > 0,
        f.round((_elapsed_days / _total_days) * 100, 1),
    ).otherwise(f.lit(None).cast("double")),
)

# --- Days to deadline and days overdue ---
df_findings_transf = df_findings_transf.withColumns({
    "days_to_deadline": f.datediff(f.col("expected_closure_date"), f.current_date()),
    "days_overdue": f.when(
        f.datediff(f.col("expected_closure_date"), f.current_date()) < 0,
        f.abs(f.datediff(f.col("expected_closure_date"), f.current_date())),
    ).otherwise(f.lit(0)),
})

# --- Warning level (only for open findings) ---
# days_to_deadline < 0 fallback catches edge cases where deadline < creation_date
df_findings_transf = df_findings_transf.withColumn(
    "warning_level",
    f.when(~f.col("is_open"), f.lit(None).cast("string"))
     .when(f.col("expected_closure_date").isNull(), f.lit("No Deadline"))
     .when(f.col("time_consumed_pct") > 100, f.lit("Overdue"))
     .when(f.col("days_to_deadline") < 0, f.lit("Overdue"))
     .when(f.col("time_consumed_pct") >= 85, f.lit("Near Overdue"))
     .when(f.col("time_consumed_pct") >= 70, f.lit("At Risk"))
     .otherwise(f.lit("On Track")),
)

# --- Warning level rank for sorting ---
df_findings_transf = df_findings_transf.withColumn(
    "warning_level_rank",
    f.when(f.col("warning_level") == "Overdue", f.lit(1))
     .when(f.col("warning_level") == "Near Overdue", f.lit(2))
     .when(f.col("warning_level") == "At Risk", f.lit(3))
     .when(f.col("warning_level") == "On Track", f.lit(4))
     .when(f.col("warning_level") == "No Deadline", f.lit(5))
     .otherwise(f.lit(99)),
)

# --- Pending closure flag ---
df_findings_transf = df_findings_transf.withColumn(
    "is_pending_closure",
    f.col("is_open")
    & ((f.col("actions_total_count") - f.col("actions_cancelled_count")) > 0)
    & (f.col("actions_pending_count") == 0),
)

# --- Actions status label ---
df_findings_transf = df_findings_transf.withColumn(
    "actions_status",
    f.when(~f.col("is_open"), f.lit(None).cast("string"))
     .when(f.col("is_pending_closure"), f.lit("Closure Pending"))
     .when(f.col("actions_pending_count") > 0, f.lit("Actions Pending"))
     .when(
         (~f.col("is_pending_closure")) & (f.col("actions_total_count") == 0),
         f.lit("Actions To Be Created"),
     )
     .otherwise(f.lit(None).cast("string")),
)

# COMMAND ----------

# DBTITLE 1,QC after Transformations
# MAGIC %md
# MAGIC    
# MAGIC #### Quality Check after Transformations

# COMMAND ----------

# Quality check: PK must be unique and not null
pk_col = "qim_ID"
df_gx = SparkDFDataset(df_findings_transf, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=pk_col),
    df_gx.expect_column_values_to_be_unique(column=pk_col),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message=f"All {pk_col}(s) are unique and not null",
    error_message="Quality checks failed for QIM Findings gold table - PK not unique or contains nulls",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="findings_qim",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# DBTITLE 1,Outputs
# MAGIC %md
# MAGIC    
# MAGIC # Outputs

# COMMAND ----------

# DBTITLE 1,Output LEAP Tables
# MAGIC %md
# MAGIC    
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# DBTITLE 1,Output Gold QIM Findings
# MAGIC %md
# MAGIC    
# MAGIC ### Output - Gold QIM Findings
# MAGIC
# MAGIC Saving of Gold QIM Findings table. Enriched with finding reference (`finding_reference`) and parent event document reference (`event_document_reference`). Columns reordered into logical groups. Any remaining columns (e.g. `FRM_ENREGISTREMENT` prefixed) are appended at the end.

# COMMAND ----------

ordered_cols = [
    # 1. Identifiers & references
    "qim_ID",
    "finding_reference", "creation_date",
    "event_reference", "event_name", "event_type", "event_category", "event_type_category", "event_status", "has_event",
    # 2. Core finding
    "finding_name", "finding_type", "status", "workflow_step", "workflow_phase",
    "calculated_closing_date", "is_open", "days_open",
    "overdue_tag", "overdue_tag_label", "overdue_tag_label_2", "overdue_tag_rank", "overdue_category", "overdue_category_rank", "overdue_group", "overdue_group_rank",
    # 2b. Warning level (time-consumed based)
    "time_consumed_pct", "warning_level", "warning_level_rank",
    "days_to_deadline", "days_overdue",
    "is_pending_closure", "actions_status",
    "category", "defect_category", "defect_main_category",
    "nc_subtype", "cc_subtype",
    "defect", "description", "detail", "precision_description",
    "free_text", "description_tree_list",
    # 3. Dates
    "finding_date", "reception_date", "expected_closure_date", "finding_closing_date",
    "action_checking_date",
    "assessment_validation_date", "root_causes_validation_date",
    "collaboration_date", "action_plan_closure_date", "action_plan_external_validation_date",

    # 4. Location
    "origin", "branch",
    "impacted_site", "impacted_division", "impacted_region",
    "liability", "liable_site", "liable_division", "liable_region", "liable_type", "detected_by",
    # 5. Program / part
    "profit_center", "process", "activity",
    "part_number", "subpart_number", "serial_numbers",
    "is_notification", "special_process_name", "special_process_details",
    # 6. People
    "analyst", "assessor", "assessment_level", "auditors", "step_one_validator",
    # 7. Impact
    "criticality", "customer_impact", "security_impact", "performance_impact",
    # 8. 5W1H
    "when_5wh", "where_5wh", "who_5wh", "what_5wh", "how_5wh", "why_5wh",
    # 9. Analysis (Ishikawa 6M)
    "analysis_method", "analysis_material",
    "analysis_machine_tooling", "analysis_measurement",
    "analysis_step", "evaluation_step",
    "rationale", "evaluation_comments",
    # 10. Action plan
    "is_actions_realised", "is_action_plan_external_validated",
    "actions_total_count", "actions_completed_count", "actions_cancelled_count", "actions_pending_count",
    "actions_progress_pct", "actions_list",
    # 11. Customer references
    "customer_name", "customer_rank", "customer_ref_ncqnam",
    # 12. Costs / quantities
    "total_cost", "total_curative_cost", "total_administrative_cost",
    "claims_quantity", "complaint_quantity",
    # 13. Misc
    "qrqc_details",
    # 14. Internal IDs (end)
    "event_qim_ID",
]

all_cols = df_findings_transf.columns
final_cols = [c for c in ordered_cols if c in all_cols] + [c for c in all_cols if c not in ordered_cols]
df_gold = df_findings_transf.select(final_cols)

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "quality"
DESTINATION_TABLE = "findings_qim"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_gold,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

# DBTITLE 1,PK constraint
# MAGIC %md
# MAGIC    
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key constraint if not already present
TABLE_CONSTRAINT_NAME = "gold_findings_qim_pk"
TABLE_PK_COLS = pk_col

nb_cons = spark.sql(
    f"SELECT COUNT(*) FROM system.information_schema.table_constraints "
    f"WHERE table_catalog='{CATALOG}' AND table_schema='{SCHEMA}' "
    f"AND table_name='{DESTINATION_TABLE}' AND constraint_name='{TABLE_CONSTRAINT_NAME}'"
).first()[0]

if nb_cons == 0:
    table_utils.set_table_column_not_null(
        table_path=DESTINATION_TABLE_FULL_PATH, column=TABLE_PK_COLS
    )
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
    log.info(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' added.")
else:
    log.info(f"Primary key constraint '{TABLE_CONSTRAINT_NAME}' already exists.")



# COMMAND ----------

# DBTITLE 1,Output - Gold Exposed QIM Findings
# MAGIC %md
# MAGIC ### Output - Gold Exposed QIM Findings
# MAGIC
# MAGIC Create or Replace the gold exposed view. Filters out columns still prefixed with `FRM_ENREGISTREMENT` (internal/meta columns not mapped by headers) and internal IDs already resolved as references.

# COMMAND ----------

# Exclude FRM_ENREGISTREMENT prefixed columns and raw internal IDs (resolved references already present)
selected_columns = [col for col in df_gold.columns if not col.startswith("FRM_FINDINGS")]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename=DESTINATION_TABLE_FULL_PATH,
    dest_full_tablename=f"{DESTINATION_TABLE_FULL_PATH}_exposed",
    select_statement=select_statement,
    replace_view=True,
)
