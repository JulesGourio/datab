# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Silver Optimu
# MAGIC
# MAGIC **Description:**
# MAGIC Builds the cleaned optimu view at tool intervention grain.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Optimu — Daily
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{reference_read_env}_bronze.headers_others.headers_optimu`
# MAGIC - `{reference_read_env}_bronze.optimu.v_ind_00000018_latest`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_silver.quality.optimu`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC 1. Specific formating for french incoming data, should be all in english
# MAGIC 2. `equipment_status_mapping` has two keys with a literal `?` ("Pas d'intervention enregistr?e", "R?form?") — the source sends these values mis-encoded; kept as a workaround alongside the correctly-encoded key.

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger and Constants

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

DEST_TABLE = f"{PIPELINE_WRITE_ENV}_silver.quality.optimu"

log.info(f"Destination table: {DEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Header Tables

# COMMAND ----------

df_header_optimu_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_others.headers_optimu")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze Source Tables

# COMMAND ----------

df_optimu_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.optimu.v_ind_00000018_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Language Mapping

# COMMAND ----------

equipment_status_mapping = {
    "A vérifier avant utilisation": "Not subject to calibration",
    "Alerte Etalonnage/Vérification": "Calibration/Verification warning",
    "Attente décision": "Awaiting decision",
    "Attente décision Etalonnage/Vérification": "Awaiting decision",
    "Attente intégration AR": "Not subject to calibration",
    "Dépassement tolérance Calibration": "Overdue",
    "Dépassement tolérance Etalonnage/Vérification": "Overdue",
    "Déstocké": "In service",
    "En service": "In service",
    "En service Vérifié": "In service verified",
    "En service/ In use": "In service",
    "Envoi Etalonnage/Vérification en cours": "Calibration/Verification in progress",
    "Envoi Vérif/Etalonnage - S2C en cours": "Calibration/Verification in progress",
    "Envoi Vérification/Etalonnage en cours": "Calibration/Verification in progress",
    "Etalonnage en cours": "Calibration/Verification in progress",
    "Etalonnage  en cours": "Calibration/Verification in progress",
    "Etalonnage/Vérification en cours": "Calibration/Verification in progress",
    "Inactif": "Placed in storage / Sleep",
    "Interdit d'utilisation": "Forbidden to use",
    "Interdit d'utilisation (perdu)/Forbidden to use (lost)": "Forbidden to use",
    "Maintenance en cours": "Maintenance in progress",
    "Mis en stock": "Placed in storage / Sleep",
    "Mise en sommeil": "Placed in storage / Sleep",
    "Sommeil": "Placed in storage / Sleep",
    "Non géré par la métrologie": "Not subject to calibration",
    "Non soumis à l'étalonnage": "Not subject to calibration",
    "Pas d'intervention enregistr?e": "Not subject to calibration",
    "Pas d'intervention enregistrée": "Not subject to calibration",
    "Perdu": "Lost",
    "Perdu/Lost": "Lost",
    "R?form?": "Scrapped",
    "Réformé": "Scrapped",
    "Retard": "Overdue",
    "Retard (dans tolérance) Etalonnage/Vérification": "Overdue (within tolerance) Calibration/Verification",
    "Retard Calibration": "Overdue",
    "Retard/Calibration": "Overdue",
    "Retard Calibration/Calibration": "Overdue",
    "Retard Calibration/Verification": "Overdue",
    "Retard Confirmation": "Overdue",
    "Retard Etalonnage/Vérification": "Overdue",
    "Retard Prêt": "Lost",
    "Retard Report d'étalonnage": "Overdue",
    "STOCK MAGASIN": "Placed in storage / Sleep",
    "Utilisation Interdite": "Forbidden to use",
    "Vendu": "Scrapped",
    "Vérification/Etalonnage en cours": "Calibration/Verification in progress",
    "Volé": "Lost",
}

# COMMAND ----------

# MAGIC %md
# MAGIC ## Functions
# MAGIC

# COMMAND ----------

def replace_value_with_null(df, columns: list, value: str = "/"):
    """
    Replace occurrences of a placeholder value with null across the specified columns.

    Args:
        df: Input DataFrame.
        columns: Column names to apply the replacement to.
        value: The placeholder value to replace with null (default: "/").

    Returns:
        DataFrame with the placeholder replaced by null in the specified columns.
    """
    return df.withColumns(
        {col_name: f.when(f.col(col_name) == value, None).otherwise(f.col(col_name)) for col_name in columns}
    )


def apply_initcap(df, columns: list):
    """
    Apply title-case (initcap) normalization to the specified string columns,
    word by word — a word already fully uppercase (e.g. an acronym like "RB46",
    "FARO") is left untouched instead of being mangled to "Rb46"/"Faro".

    Args:
        df: Input DataFrame.
        columns: Column names to apply initcap to.

    Returns:
        DataFrame with initcap applied to the specified columns.
    """
    def _initcap_preserve_acronyms(col):
        words = f.split(col, " ")
        kept_words = f.transform(words, lambda w: f.when(w == f.upper(w), w).otherwise(f.initcap(w)))
        return f.array_join(kept_words, " ")

    return df.withColumns({col_name: _initcap_preserve_acronyms(f.col(col_name)) for col_name in columns})


def translate_column(df, column: str, mapping: dict):
    """
    Translate values in a column using a dictionary mapping.

    Args:
        df: Input DataFrame.
        column: Name of the column to translate.
        mapping: Dictionary mapping source values to target values.

    Returns:
        DataFrame with translated values in the specified column.
    """
    # Normalize mapping keys to lowercase for case-insensitive + accent-case matching
    normalized_mapping = {}
    for k, v in mapping.items():
        norm_key = k.strip().lower()
        if norm_key not in normalized_mapping:
            normalized_mapping[norm_key] = v

    mapping_expr = f.create_map([f.lit(x) for pair in normalized_mapping.items() for x in pair])

    # Normalize column value: trim ALL whitespace (f.trim only strips spaces, not \n/\t)
    # and lowercase for matching — must match the Python .strip() used on mapping keys above.
    normalized_col = f.lower(f.regexp_replace(f.col(column), r"^\s+|\s+$", ""))

    return df.withColumn(
        column,
        f.coalesce(mapping_expr[normalized_col], f.col(column)),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optimu — Optimu Header

# COMMAND ----------

df_optimu_prep = table_utils.add_prefix_to_columns(df_optimu_raw, "optimu")
df_optimu_prep = table_utils.rename_columns_with_sap_business_header(df_optimu_prep, df_header_optimu_raw)

# Replace empty strings with null and trim whitespace across string columns
_string_cols = {c for c, t in df_optimu_prep.dtypes if t == "string"}
df_optimu_prep = df_optimu_prep.select(
    [
        f.when(f.trim(f.col(c)) == "", f.lit(None)).otherwise(f.trim(f.col(c))).alias(c)
        if c in _string_cols else f.col(c)
        for c in df_optimu_prep.columns
    ]
)

# Hoist .columns once before the loop to avoid repeated Analyze RPCs
df_optimu_prep_columns = set(df_optimu_prep.columns)
for row in df_header_optimu_raw.filter(f.lower(f.col("Format")).isin("float", "double")).select("Business_name").collect():
    col_name = row["Business_name"]
    if col_name in df_optimu_prep_columns:
        df_optimu_prep = table_utils.transform_float_column(df_optimu_prep, col_name)

# Source timestamps have mixed precision (some with millis, some without) — a rigid
# date_format throws CANNOT_PARSE_TIMESTAMP on those; None uses the lenient ISO parser instead.
df_optimu_prep = table_utils.cast_columns_with_sap_business_headers(
    df_optimu_prep, df_header_optimu_raw, date_format=None
)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Optimu - Optimu data
# MAGIC

# COMMAND ----------

# Replace "/" placeholder with null
df_optimu_prep = replace_value_with_null(df_optimu_prep, ["equipment_type", "resolution_unit"])

# Normalize casing with initcap
df_optimu_prep = apply_initcap(df_optimu_prep, ["intervention_result", "equipment_type",
                                                "equipment_name", "location"])

# The following are some manual overrides to align with the rest of the data
df_optimu_prep = df_optimu_prep.withColumn(
    "intervention_frequency_unit",
    f.when(f.col("intervention_frequency_unit") == "Ans", f.lit("An(s)"))
     .otherwise(f.col("intervention_frequency_unit")),
)

df_optimu_prep = translate_column(df_optimu_prep, "equipment_status", equipment_status_mapping)

# Normalize reading_mode: consolidate case variants, language synonyms, and long/short forms
# Currently keeping french values because they are predominant, eventually data should be in english
_reading_mode_map = [
    (r"(?i)^(digital[e]?|num[eé]rique|a\s+affichage\s+num[eé]rique)$", "Numérique"),
    (r"(?i)^(a\s+)?vernier$",                                          "Vernier"),
    (r"(?i)^a\s+tambour\s+gradu[eé]$",                                 "À tambour gradué"),
    (r"(?i)^a\s+cadran$",                                              "À cadran"),
]
_reading_mode_expr = f.col("reading_mode")
for _pattern, _replacement in _reading_mode_map:
    _reading_mode_expr = f.when(
        f.col("reading_mode").rlike(_pattern), f.lit(_replacement)
    ).otherwise(_reading_mode_expr)
df_optimu_prep = df_optimu_prep.withColumn("reading_mode", _reading_mode_expr)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Primary Key
# MAGIC `last_intervention_date` alone can collide (e.g. `LATEL-31`/`L3267`, two real interventions
# MAGIC same day) — `row_number` tiebreaker keeps both rows, ordered by a content hash for
# MAGIC stability across reruns.

# COMMAND ----------

# Technical/meta columns are near-constant within a single extract and don't help
# disambiguate — excluded so the hash reflects business content only.
_tiebreak_hash_cols = [
    c for c in df_optimu_prep.columns if "__meta_" not in c and not c.endswith("_rescued_data")
]
_intervention_tiebreak_window = Window.partitionBy(
    "equipment_ID", "code", "last_intervention_date"
).orderBy(
    f.sha2(f.concat_ws("|", *[f.col(c).try_cast("string") for c in _tiebreak_hash_cols]), 256)
)

df_optimu_out = df_optimu_prep.withColumn(
    "intervention_ID",
    f.concat_ws(
        "-", f.col("equipment_ID"), f.col("code"),
        f.col("last_intervention_date").try_cast("timestamp").try_cast("long"),
        f.row_number().over(_intervention_tiebreak_window),
    ),
)
remaining_cols = [c for c in df_optimu_out.columns if c != "intervention_ID"]
df_optimu_out = df_optimu_out.select("intervention_ID", *remaining_cols)
df_optimu_out.cache()

if DEBUG:
    log.debug(f"Silver optimu: {df_optimu_out.count()} rows")

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks
# MAGIC
# MAGIC `intervention_ID` concatenates `equipment_ID`, `code`, and `last_intervention_date` —
# MAGIC `concat_ws` silently drops null segments, so a null in any of the three could collapse
# MAGIC distinct interventions onto the same `intervention_ID` undetected. All three are checked
# MAGIC not-null below for that reason, not just because they're required fields.

# COMMAND ----------

dfgx = gx.dataset.SparkDFDataset(df_optimu_out, persist=False)
dfgx_headers = gx.dataset.SparkDFDataset(df_header_optimu_raw, persist=False)

red_results = [
    dfgx.expect_column_values_to_not_be_null(column="intervention_ID"),
    dfgx.expect_column_values_to_be_unique(column="intervention_ID"),
    dfgx.expect_column_values_to_not_be_null(column="equipment_ID"),
    dfgx.expect_column_values_to_not_be_null(column="code"),
    dfgx.expect_column_values_to_not_be_null(column="last_intervention_date"),
    # Guards mode="overwrite" below against silently wiping silver with a near-empty table.
    dfgx.expect_table_row_count_to_be_between(min_value=1),
    dfgx_headers.expect_table_row_count_to_be_between(min_value=1),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="RED checks passed: intervention_ID unique and not null; equipment_ID/code/last_intervention_date not null; optimu and headers_optimu non-empty",
    error_message="RED check failed on optimu — duplicate/missing intervention_ID, null equipment_ID/code/last_intervention_date, or optimu/headers_optimu came back empty",
)

# An unmapped source status falls through translate_column() untranslated (coalesce fallback)
# — this catches that silently instead of leaking French text into equipment_status.
amber_results = [
    dfgx.expect_column_distinct_values_to_be_in_set(
        column="equipment_status", value_set=set(equipment_status_mapping.values())
    ),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=amber_results,
    validation_level="AMBER",
    info_message="AMBER check passed: equipment_status values are all within the mapped set",
    error_message="AMBER warning on optimu — equipment_status has a value outside the mapping (untranslated source status)",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

_silver_table_existed = table_utils.UnityCatalogCheckTableExists(DEST_TABLE)

table_utils.save_table(
    dest_table=DEST_TABLE,
    df=df_optimu_out,
    mode="overwrite",
    overwrite_schema=True,
)

if not _silver_table_existed:
    table_utils.set_table_column_not_null(table_path=DEST_TABLE, column="intervention_ID")
    table_utils.add_table_primary_key(DEST_TABLE, "optimu_PK", "intervention_ID")

log.info(f"Saved: {DEST_TABLE}")
