# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Create Gold Optimu
# MAGIC
# MAGIC **Description:**
# MAGIC Build gold optimu table at intervention grain with daily stack historization.
# MAGIC Each daily run merges the full silver snapshot into gold (keyed by `optimu_snapshot_ID`), building a complete history partitioned by `observation_date`.
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - Stack historization: idempotent `merge_into` on `(observation_date, intervention_ID)` (re-running the same day updates matching rows in place instead of duplicating them)
# MAGIC - Composite PK: `optimu_snapshot_ID = observation_date - intervention_ID`
# MAGIC - `optimu_monthly_history`: monthly-grain table (one row per equipment per `reporting_month`), rebuilt each run by replacing only the current month's rows — not a plain view over the daily stack
# MAGIC - `country`: Mexico/Bulgaria/France/Others (`N/A - Obsolete` for obsolete equipment), mapped from `code`'s site prefix rather than free-text `location` — see Data Preparation *Add columns - country, is_obsolete*
# MAGIC - `is_obsolete`: obsolete instruments carry the `OBSOL` code prefix instead of a site one and stay permanently calibration-overdue. They are flagged, not dropped, so the history stays faithful — reporting filters them out of active-fleet KPIs — see Data Preparation *Add columns - country, is_obsolete* and Technical Debt 2
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Optimu — Daily
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{pipeline_write_env}_silver.quality.optimu`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC N/A
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{pipeline_write_env}_gold.quality.optimu_daily_history`
# MAGIC - `{pipeline_write_env}_gold.quality.optimu_monthly_history`
# MAGIC - `{pipeline_write_env}_gold.quality.optimu_latest`

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC 1. `status_start_date`'s island window in Data Transformations *Add columns - status_start_date* scans the full daily history every run — no incremental version yet, cost grows with the table.
# MAGIC 2. `is_obsolete` in Data Preparation *Add columns - country, is_obsolete* is derived from the `OBSOL` code prefix, not from a dedicated Optimu field — if the source ever marks obsolescence some other way this silently under-counts. Ask Metrology whether a proper obsolescence flag exists in the extract.

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Widgets

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Logger and Constants

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

DEST_TABLE = f"{PIPELINE_WRITE_ENV}_gold.quality.optimu_daily_history"
DEST_TABLE_MONTHLY = f"{PIPELINE_WRITE_ENV}_gold.quality.optimu_monthly_history"
DEST_VIEW_CURRENT = f"{PIPELINE_WRITE_ENV}_gold.quality.optimu_latest"

DUE_SOON_THRESHOLD_DAYS = 30

# optimu__meta_extraction_timestamp is a real instant, not a calendar day — reinterpret in
# Europe/Paris (site timezone) before truncating to DATE, or the cluster's UTC session lands
# on the wrong calendar day.
CALENDAR_TIMEZONE = "Europe/Paris"

OTHERS_LABEL = "Others"
# Obsolete instruments belong to no site, so "country" genuinely does not apply to them.
OBSOLETE_LABEL = "N/A - Obsolete"
OBSOLETE_SITE_CODE = "OBSOL"

# code's site prefix (e.g. "LATBU" from "LATBU-01") -> home country.
# SROLW has no confirmed country and stays in OTHERS_LABEL on purpose rather than guessed.
# OBSOL is not a site but the obsolescence marker used across all sites (per Metrology).
SITE_CODE_COUNTRY_MAPPING = {
    "LAMXA": "Mexico",
    "LAMXC": "Mexico",
    "LAMXD": "Mexico",
    "LATBU": "Bulgaria",
    "LATCN": "France",
    "LATEL": "France",
    "LATGI": "France",
    "LATME": "France",
    "LATTO": "France",
    "LFRCO": "France",
    "LFRGA": "France",
    "OBSOL": OBSOLETE_LABEL,
}

log.info(f"Destination table: {DEST_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Other config — table existence check

# COMMAND ----------

# --- Check if destination table already exists (for stack historization) ---
snapshot_table_exists = table_utils.UnityCatalogCheckTableExists(DEST_TABLE)
log.info(f"Destination table exists: {snapshot_table_exists}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Optimu

# COMMAND ----------

df_optimu_raw = spark.read.table(f"{PIPELINE_WRITE_ENV}_silver.quality.optimu")

# observation_date: extraction timestamp reinterpreted in Europe/Paris, truncated to DATE.
df_optimu_raw = df_optimu_raw.withColumn(
    "observation_date",
    f.to_date(f.from_utc_timestamp(f.col("optimu__meta_extraction_timestamp"), CALENDAR_TIMEZONE))
)

observation_date_value = df_optimu_raw.select(f.max("observation_date")).first()[0]
log.info(f"Observation date (from extraction timestamp): {observation_date_value}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Snapshot history

# COMMAND ----------

df_history = spark.read.table(DEST_TABLE) if snapshot_table_exists else None

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add columns - days_until_intervention

# COMMAND ----------

df_optimu_prep = df_optimu_raw.withColumn(
    "days_until_intervention",
    f.datediff(f.col("next_intervention_date"), f.col("observation_date")).try_cast("bigint")
)

if DEBUG:
    display(
        df_optimu_prep.select(
            "next_intervention_date", "observation_date", "days_until_intervention"
        ).orderBy("next_intervention_date").limit(10)
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add columns - Intervention status
# MAGIC `next_intervention_date` missing -> `days_until_intervention` and `intervention_status` both NULL.

# COMMAND ----------

# Add 'intervention_status' column based on 'next_intervention_date' relative to today
df_optimu_prep = df_optimu_prep.withColumn(
    "intervention_status",
    f.when(
        f.col("days_until_intervention") < 0, "Overdue"
    ).when(
        f.col("days_until_intervention") <= DUE_SOON_THRESHOLD_DAYS, "Due Soon"
    ).when(
        f.col("days_until_intervention") > DUE_SOON_THRESHOLD_DAYS, "Valid"
    ))

if DEBUG:
    display(df_optimu_prep.select("next_intervention_date", "intervention_status").orderBy("next_intervention_date").limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add columns - country, is_obsolete
# MAGIC `location` free text only names the country for Mexico and Bulgaria — French sites go straight
# MAGIC to the site name. So `country` comes from `code`'s site prefix alone (always populated,
# MAGIC RED-checked not-null in Silver).
# MAGIC
# MAGIC `OBSOL` marks obsolete instruments, which stay calibration-overdue in the source and would
# MAGIC distort fleet compliance. They are flagged with `is_obsolete` for reporting to exclude rather
# MAGIC than dropped, so the daily stack stays a faithful history of what Optimu sent.

# COMMAND ----------

_code_prefix = f.regexp_extract(f.col("code"), r"^[A-Za-z]+", 0)
_is_obsolete_expr = _code_prefix == f.lit(OBSOLETE_SITE_CODE)
_code_country_map = f.create_map([f.lit(x) for pair in SITE_CODE_COUNTRY_MAPPING.items() for x in pair])

df_optimu_prep = (
    df_optimu_prep
    .withColumn("is_obsolete", _is_obsolete_expr)
    .withColumn("country", f.coalesce(_code_country_map[_code_prefix], f.lit(OTHERS_LABEL)))
)

# Risky transform: any code prefix outside SITE_CODE_COUNTRY_MAPPING silently falls to
# OTHERS_LABEL here — real distribution checked for real in Quality Checks below.
log.info("country derived from code site-prefix — checking OTHERS_LABEL rate in Quality Checks")

if DEBUG:
    df_optimu_prep.select("code", "location", "country", "is_obsolete").distinct().limit(20).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Add columns - status_start_date
# MAGIC Gaps-and-islands: earliest `observation_date` within the current unbroken run of `equipment_status` (resets if the status changed since yesterday, not the first time it ever had this status).

# COMMAND ----------

if snapshot_table_exists:
    _status_order_window = Window.partitionBy("equipment_ID", "intervention_ID").orderBy("observation_date")
    df_status_islands = (
        df_history.filter(f.col("observation_date") != observation_date_value)
        .select("equipment_ID", "intervention_ID", "observation_date", "equipment_status")
        .unionByName(
            df_optimu_prep.select("equipment_ID", "intervention_ID", "observation_date", "equipment_status")
        )
        .withColumn(
            "_status_island",
            f.sum(
                f.when(
                    f.col("equipment_status").eqNullSafe(f.lag("equipment_status").over(_status_order_window)),
                    0
                ).otherwise(1)
            ).over(_status_order_window)
        )
        .withColumn(
            "status_start_date",
            f.min("observation_date").over(Window.partitionBy("equipment_ID", "intervention_ID", "_status_island"))
        )
        .filter(f.col("observation_date") == observation_date_value)
        .select("equipment_ID", "intervention_ID", "status_start_date")
    )
    df_optimu_prep = df_optimu_prep.join(
        df_status_islands, on=["equipment_ID", "intervention_ID"], how="left"
    )
else:
    # First run — no history available, status_start_date defaults to observation_date
    df_optimu_prep = df_optimu_prep.withColumn("status_start_date", f.col("observation_date"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Primary Key, Observation Date Stamp

# COMMAND ----------

# Build composite optimu_snapshot_ID
df_optimu_prep = df_optimu_prep.withColumn(
    "optimu_snapshot_ID",
    f.concat_ws("-", f.col("observation_date").try_cast("string"), f.col("intervention_ID"))
)

# Reorder columns: PK first, then observation_date, then rest
remaining_cols = [c for c in df_optimu_prep.columns if c not in ("optimu_snapshot_ID", "observation_date", "intervention_ID")]
df_optimu_end = df_optimu_prep.select("optimu_snapshot_ID", "observation_date", "intervention_ID", *remaining_cols)
df_optimu_end.cache()

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

if DEBUG:
    df_optimu_end.select(
        "optimu_snapshot_ID", "observation_date", "intervention_ID", "equipment_name",
        "location", "last_intervention_date", "next_intervention_date", "equipment_status"
    ).limit(5).display()

dfgx = gx.dataset.SparkDFDataset(df_optimu_end, persist=False)

red_results = [
    dfgx.expect_column_values_to_not_be_null(column="optimu_snapshot_ID"),
    dfgx.expect_column_values_to_be_unique(column="optimu_snapshot_ID"),
    dfgx.expect_column_values_to_not_be_null(column="intervention_ID"),
    # Guards the merge below: an empty/near-empty snapshot must not go through and
    # silently wipe out the current day's partition in gold.
    dfgx.expect_table_row_count_to_be_between(min_value=1),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_results,
    validation_level="RED",
    info_message="RED checks passed: optimu_snapshot_ID unique and not null; intervention_ID not null; row count non-empty",
    error_message="RED check failed on gold.optimu — duplicate snapshot keys, missing intervention key, or empty snapshot",
)

amber_results = [
    # Tight on purpose: these fields are normally fully populated (next_intervention_date slightly less).
    dfgx.expect_column_values_to_not_be_null(column="last_intervention_date", mostly=0.995),
    dfgx.expect_column_values_to_not_be_null(column="next_intervention_date", mostly=0.96),
    dfgx.expect_column_values_to_not_be_null(column="equipment_name", mostly=0.995),
    # SROLW is the only prefix expected in OTHERS_LABEL (see Config); the headroom above it
    # catches a new, unmapped site prefix. Re-size if SROLW ever gets a country.
    dfgx.expect_column_values_to_be_in_set(
        column="country", value_set=set(SITE_CODE_COUNTRY_MAPPING.values()), mostly=0.95
    ),
    # Obsolete instruments stay calibration-overdue forever, so their share drives the
    # headline compliance figure — this flags the fleet tipping towards obsolete.
    dfgx.expect_column_values_to_be_in_set(column="is_obsolete", value_set={False}, mostly=0.80),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=amber_results,
    validation_level="AMBER",
    info_message="AMBER checks passed: last_intervention_date coverage, next_intervention_date coverage, equipment_name coverage, country resolved rate, active (non-obsolete) share",
    error_message="AMBER warning on gold.optimu — check dates/tool names null rate, country falling to Others more than expected (new unmapped site prefix?), or obsolete equipment share above 20%",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stack historization — MERGE INTO
# MAGIC Keyed on `(observation_date, intervention_ID)` so a same-day rerun updates in place instead of duplicating.

# COMMAND ----------

# Single atomic MERGE — see markdown above for why it's keyed this way.
if snapshot_table_exists:
    table_utils.merge_into(
        df_source=df_optimu_end,
        target_table=DEST_TABLE,
        list_id_matching_columns=["observation_date", "intervention_ID"],
    )
    log.info(f"Stacked historization: merged partition observation_date={observation_date_value}")
else:
    table_utils.save_table(
        dest_table=DEST_TABLE,
        df=df_optimu_end,
        mode="overwrite",
        overwrite_schema=True,
        partition_col="observation_date",
    )
    table_utils.set_table_column_not_null(table_path=DEST_TABLE, column="optimu_snapshot_ID")
    table_utils.add_table_primary_key(DEST_TABLE, "optimu_daily_history_PK", "optimu_snapshot_ID")
    log.info("First run: created table with initial snapshot")

log.info(f"Saved: {DEST_TABLE} (partitioned by observation_date)")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Monthly snapshot
# MAGIC One row per equipment/intervention per `reporting_month`. Normal runs only replace the
# MAGIC current month's rows; if the table doesn't exist yet but the daily stack already has
# MAGIC prior months, those get backfilled once on creation instead of lost.

# COMMAND ----------

# Exclude ingestion technical/meta columns — not business data, shouldn't be exposed.
_exposed_cols = [c for c in df_optimu_end.columns if "__meta_" not in c and not c.endswith("_rescued_data")]

monthly_table_exists = table_utils.UnityCatalogCheckTableExists(DEST_TABLE_MONTHLY)

df_optimu_monthly = df_optimu_end.select(*_exposed_cols).withColumn(
    "reporting_month", f.trunc(f.col("observation_date"), "month")
)
current_month_value = df_optimu_monthly.select(f.max("reporting_month")).first()[0]

# Composite PK: unique per intervention within a reporting_month.
df_optimu_monthly = df_optimu_monthly.withColumn(
    "optimu_monthly_snapshot_ID",
    f.concat_ws("-", f.col("reporting_month").try_cast("string"), f.col("intervention_ID"))
)
_monthly_cols = [c for c in df_optimu_monthly.columns if c != "optimu_monthly_snapshot_ID"]
df_optimu_monthly = df_optimu_monthly.select("optimu_monthly_snapshot_ID", *_monthly_cols)

if monthly_table_exists:
    # Cheap path: the monthly table already has every closed month, just swap the current one.
    df_monthly_history = spark.read.table(DEST_TABLE_MONTHLY).filter(
        f.col("reporting_month") != current_month_value
    )
    df_optimu_monthly_end = df_monthly_history.unionByName(df_optimu_monthly, allowMissingColumns=True)
elif snapshot_table_exists:
    # One-time backfill: the monthly table doesn't exist yet but the daily stack already has
    # prior months in it — reconstruct their monthly snapshots now, so history isn't lost.
    # Runs once (this branch never fires again once the monthly table exists).
    _month_pick_window = Window.partitionBy("intervention_ID", "reporting_month").orderBy(f.col("observation_date").desc())
    df_backfill_monthly = (
        df_history.select(*_exposed_cols)
        .withColumn("reporting_month", f.trunc(f.col("observation_date"), "month"))
        .filter(f.col("reporting_month") != current_month_value)
        .withColumn("_rn", f.row_number().over(_month_pick_window))
        .filter(f.col("_rn") == 1)
        .drop("_rn")
        .withColumn(
            "optimu_monthly_snapshot_ID",
            f.concat_ws("-", f.col("reporting_month").try_cast("string"), f.col("intervention_ID"))
        )
    )
    # No allowMissingColumns here on purpose: both frames come from the same _exposed_cols in
    # this run, so a column mismatch should fail loudly, not silently null-fill a column.
    df_optimu_monthly_end = df_backfill_monthly.unionByName(df_optimu_monthly)
else:
    df_optimu_monthly_end = df_optimu_monthly

dfgx_monthly = gx.dataset.SparkDFDataset(df_optimu_monthly_end, persist=False)
monthly_red_results = [
    dfgx_monthly.expect_column_values_to_not_be_null(column="optimu_monthly_snapshot_ID"),
    dfgx_monthly.expect_column_values_to_be_unique(column="optimu_monthly_snapshot_ID"),
    dfgx_monthly.expect_table_row_count_to_be_between(min_value=1),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=monthly_red_results,
    validation_level="RED",
    info_message="RED checks passed: optimu_monthly_snapshot_ID unique and not null; row count non-empty",
    error_message="RED check failed on gold.optimu_monthly_history — duplicate/missing monthly snapshot key or empty result",
)

table_utils.save_table(
    dest_table=DEST_TABLE_MONTHLY,
    df=df_optimu_monthly_end,
    mode="overwrite",
    overwrite_schema=True,
)

if not monthly_table_exists:
    table_utils.set_table_column_not_null(table_path=DEST_TABLE_MONTHLY, column="optimu_monthly_snapshot_ID")
    table_utils.add_table_primary_key(DEST_TABLE_MONTHLY, "optimu_monthly_history_PK", "optimu_monthly_snapshot_ID")

log.info(f"Saved: {DEST_TABLE_MONTHLY} ({len(_exposed_cols) + 2} columns)")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Current view
# MAGIC Latest daily snapshot (global `MAX(observation_date)`), derived from gold rather than silver so a failed run doesn't stall it.

# COMMAND ----------

table_utils.create_table_view_generic(
    dest_full_tablename=DEST_VIEW_CURRENT,
    sql_select_statement=f"""
        SELECT {", ".join(_exposed_cols)}
        FROM {DEST_TABLE}
        WHERE observation_date = (SELECT MAX(observation_date) FROM {DEST_TABLE})
    """,
    replace_view=True,
)

log.info(f"Created current-state view: {DEST_VIEW_CURRENT}")
