# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim of this notebook is to create the gold table of quality notification (headers only) based on the silver table
# MAGIC - Adding type of quality notification
# MAGIC - Adding program information
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {PIPELINE_READ_ENV}_silver.quality.quality_notification
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.profit_center_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.production.workcenter_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.quality.quality_notification
# MAGIC   
# MAGIC **Triggered by:** 
# MAGIC Data asset - Quality notification 

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import time
import pyspark.sql.functions as f

from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC #Input

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

df_qn_silver_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.quality.quality_notification"
)

# COMMAND ----------

df_profit_center_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed"
)

# COMMAND ----------

df_work_center_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.production.workcenter_exposed"
)

# COMMAND ----------

df_material_plant_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed"
)

# COMMAND ----------

df_supplier_master_data_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed"
)

# COMMAND ----------

df_mapping_site_div_region = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region"
)

df_mapping_sites = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_sites"
)

# COMMAND ----------

df_material_plant_exposed_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Profit center table

# COMMAND ----------

df_profit_center_prep = (
    df_profit_center_raw.select(
        "customer_group",
        "aircraft_product",
        f.col("Short_Description").alias("profit_center_description"),
        f.col("Profit_Center_short").alias("profit_center"),
        "is_valid",
    )
    .where(f.col("is_valid"))
    .drop("is_valid")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - Workcenter

# COMMAND ----------

df_work_center_prep = df_work_center_raw.select(
    f.col("plant").alias("plant_of_material"),
    "workcenter_id", 
    "workcenter_code",
    "workcenter_description",
    "workcenter_group_desc",
    "workcenter"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 3 - Material plant master data

# COMMAND ----------

df_material_plant_prep = df_material_plant_raw.select(
    f.col("plant").alias("plant_of_material"),
    f.col("material_number"),
    f.col("MRP_Controller"),
    f.col("Standard_Price_EUR_Budget").alias("material_std_price_eur"),
    f.col("Category").alias("material_category"),
).dropDuplicates(["plant_of_material", "material_number"])

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 4 - Supplier master data

# COMMAND ----------

df_supplier_master_data_prep = df_supplier_master_data_raw.select(
    "supplier_code",
    "supplier_name",
    "supplier_country",
    "intercompany_flow",
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 5 - Mapping sites

# COMMAND ----------

df_mapping_sites = df_mapping_sites.select("site", "site_from_qn")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 6 - Material Plant

# COMMAND ----------

df_material_plant_exposed_prep = df_material_plant_exposed_raw.select(
    f.col("plant").alias("plant_of_material"),
    "material_number",
    "commodity",
    "sub_commodity",
    "raw_mat",
    "manuf_process",
    "manuf_type",
    "familly_manuf",
).dropDuplicates(["plant_of_material", "material_number"])

# COMMAND ----------

# MAGIC %md
# MAGIC #Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Add Non Quality type
# MAGIC As is in QM10 -> to be evolved with harmonisation

# COMMAND ----------

df_qn_transf = df_qn_silver_raw.withColumn(
    "non_quality_type",
    f.when(f.col("notification_type") == "ZI", f.lit("IQN"))
    .when(f.col("notification_type") == "ZM", f.lit("SCRAP"))
    .when(f.col("notification_type") == "ZQ", f.lit("AQF"))
    .when(f.col("notification_type") == "Z1", f.lit("Rework")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Join with PC 

# COMMAND ----------

df_qn_transf = df_qn_transf.join(df_profit_center_prep, ["profit_center"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr3 - Join with workcenter

# COMMAND ----------

df_qn_transf = df_qn_transf.withColumnRenamed('workcenter_code', 'workcenter_id')

# COMMAND ----------

df_qn_transf = df_qn_transf.join(
    df_work_center_prep, ["workcenter_id", "plant_of_material"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr4 - Join with material plant master data

# COMMAND ----------

df_qn_transf = df_qn_transf.join(
    df_material_plant_prep, ["plant_of_material", "material_number"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr5 - Join with supplier master data

# COMMAND ----------

df_qn_transf = df_qn_transf.join(
    df_supplier_master_data_prep, on="supplier_code", how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr6 - Site naming convention

# COMMAND ----------

df_qn_transf = df_qn_transf.withColumnRenamed(
    "imputed_site", "imputed_site_qn"
).withColumnRenamed("impacted_site", "impacted_site_qn")

# COMMAND ----------

df_qn_transf = (
    df_qn_transf.join(
        df_mapping_sites,
        df_qn_transf.imputed_site_qn == df_mapping_sites.site_from_qn,
        "left",
    )
    .drop("site_from_qn")
    .withColumnRenamed("site", "imputed_site")
    .join(
        df_mapping_sites,
        df_qn_transf.impacted_site_qn == df_mapping_sites.site_from_qn,
        "left",
    )
    .drop("site_from_qn")
    .withColumnRenamed("site", "impacted_site")
    .withColumn("site",
        f.coalesce(
            f.col("imputed_site"),
            f.col("impacted_site"),
            f.when(
                (f.col("imputed_site_qn") == "FRN") | (f.col("impacted_site_qn") == "FRN"),
                f.lit("Supplier")
            )
        )
    )
)

# COMMAND ----------

df_qn_transf = df_qn_transf.join(df_mapping_site_div_region, ["site"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr7 - Join with material plant

# COMMAND ----------

df_qn_transf = df_qn_transf.join(
    df_material_plant_exposed_prep, ["plant_of_material", "material_number"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality Check

# COMMAND ----------

pk_col = "notification_ID"
columns = df_qn_transf.columns
columns.remove(pk_col)
new_column_order = [pk_col] + columns
df_qn_transf = df_qn_transf.select(new_column_order)

# COMMAND ----------

validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx_supplier = SparkDFDataset(df_supplier_master_data_prep, persist=False)
df_gx_final = SparkDFDataset(df_qn_transf, persist=False)

quality_check_results = [
    df_gx_supplier.expect_column_values_to_be_unique("supplier_code"),
    df_gx_final.expect_column_values_to_be_unique("notification_ID"),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level="RED",
    info_message="All checks inspection",
    error_message="Quality checks failed for quality notification and supplier master data table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="quality_notification_and_supplier_master_data",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Gold Table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "quality"
DESTINATION_TABLE = "quality_notification"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_qn_transf,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_qn_transf.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "quality_notification_pk"
TABLE_PK_COLS = "notification_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ###Save Gold exposed table

# COMMAND ----------

dest_full_tablename = f"{DESTINATION_TABLE_FULL_PATH}_exposed"
Begin_By = "QMEL"
selected_columns = [
    col
    for col in df_qn_transf.columns
    if not col.startswith(Begin_By)
]
select_statement = ", ".join(selected_columns)
# --------------------------------------------------------------------------------
table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH, dest_full_tablename, select_statement, replace_view=True
)