# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim of this notebook is to create the gold table of quality notification item based on the silver table
# MAGIC - Adding type of quality notification item
# MAGIC - Adding program information
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {PIPELINE_READ_ENV}_silver.quality.quality_notification_item
# MAGIC   - {PIPELINE_READ_ENV}_gold.quality.quality_notification_exposed
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.qpct_latest --> Table with cause code description (all languages)
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.qpgt_latest --> Table with cause group code description (all languages)
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.quality.quality_notification_item
# MAGIC   
# MAGIC **Triggered by:** 
# MAGIC Data asset - Quality notification item

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import time
import pyspark.sql.functions as f

from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC #Input

# COMMAND ----------

df_qnitem_silver_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.quality.quality_notification_item"
)

# COMMAND ----------

df_qn_header_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.quality.quality_notification_exposed"
)

# COMMAND ----------

df_qpct_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.qpct_latest"
)

# COMMAND ----------

df_qpgt_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.qpgt_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep1 - QPCT table

# COMMAND ----------

df_qpct_prep = (
    df_qpct_raw.select("code", "sprache", "kurztext")
    .withColumnsRenamed(
        {
            "code": "cause_code",
            "kurztext": "cause_code_desc",
        }
    )
    # English language
    .filter(f.col("sprache") == "E")
    .groupBy("cause_code")
    .agg(f.concat_ws(" -- ", f.collect_set("cause_code_desc")).alias("cause_code_desc"))
    .dropDuplicates()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep1 - QPGT table

# COMMAND ----------

df_qpgt_prep = (
    df_qpgt_raw.select("codegruppe", "sprache", "kurztext")
    .withColumnsRenamed(
        {
            "codegruppe": "cause_group",
            "kurztext": "cause_group_desc",
        }
    )
    # English language
    .filter(f.col("sprache").isin(["E", "F"]))
    .groupBy("cause_group")
    .agg(
          f.first(
              f.when(f.col("sprache") == "E", f.col("cause_group_desc")),
              ignorenulls=True
          ).alias("desc_E"),
          f.first(
              f.when(f.col("sprache") == "F", f.col("cause_group_desc")),
              ignorenulls=True
          ).alias("desc_F")
      )
      .withColumn(
          "cause_group_desc",
          f.coalesce(f.col("desc_E"), f.col("desc_F"))
      )
      .select("cause_group", "cause_group_desc")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Join header to item

# COMMAND ----------

df_qn_item_transf = (
    df_qnitem_silver_raw.join(df_qn_header_raw, on="notification_ID", how="left")
    .withColumn("notification_code", f.col("notification_ID"))
    .filter(f.col("notification_date").isNotNull())
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Business ID 
# MAGIC Concat notication code and item

# COMMAND ----------

df_qn_item_transf = df_qn_item_transf.withColumn(
    "notification_code_item_ID",
    f.concat_ws("-", f.col("notification_code"), f.col("notification_item_number")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr3 - Add description of cause code

# COMMAND ----------

df_qn_item_transf = df_qn_item_transf.join(
    df_qpct_prep, on="cause_code", how="left"
).join(df_qpgt_prep, on="cause_group", how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality Check

# COMMAND ----------

pk_col = "notification_code_item_ID"
columns = df_qn_item_transf.columns
columns.remove(pk_col)
new_column_order = [pk_col] + columns
df_qn_item_transf = df_qn_item_transf.select(new_column_order)

# COMMAND ----------

validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx_final = SparkDFDataset(df_qn_item_transf, persist=False)

quality_check_results = [
    df_gx_final.expect_column_values_to_be_unique("notification_code_item_ID"),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level="RED",
    info_message="All checks inspection",
    error_message="Quality checks failed for quality notification item table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="quality_notification_item",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Gold Table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "quality"
DESTINATION_TABLE = "quality_notification_item"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_qn_item_transf,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_qn_item_transf.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "quality_notification_item_pk"
TABLE_PK_COLS = "notification_code_item_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ###Save Gold exposed table

# COMMAND ----------

dest_full_tablename = f"{DESTINATION_TABLE_FULL_PATH}_exposed"
Begin_By = "QMFE"
selected_columns = [
    col
    for col in df_qn_item_transf.columns
    if not col.startswith(Begin_By)
]
select_statement = ", ".join(selected_columns)
# --------------------------------------------------------------------------------
table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH, dest_full_tablename, select_statement, replace_view=True
)
