# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim of this notebook is to create the gold table of quality notification activities based on the silver table
# MAGIC - Adding type of quality notification
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {PIPELINE_READ_ENV}_silver.quality.quality_notification_activity
# MAGIC   - {PIPELINE_READ_ENV}_gold.quality.quality_notification_exposed
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.quality.quality_notification_activity
# MAGIC   
# MAGIC **Triggered by:** 
# MAGIC Data asset - Quality notification activity

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import time
import pyspark.sql.functions as f

from leap_utils.data_asset import table_utils
from leap_utils.common import logger
from pyspark.sql.types import StructType, StructField, StringType

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC #Input

# COMMAND ----------

df_qn_activity_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.quality.quality_notification_activity"
)

# COMMAND ----------

df_qn_header_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.quality.quality_notification_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1

# COMMAND ----------

data = [
    ("NC01", "Document de conception"),
    ("NC02", "Documentation du technicien"),
    ("NC03", "Programme de NC"),
    ("NC04", "GABARIT"),
    ("NC05", "Erreur du salarié"),
    ("NC06", "Mauvaise méthode de contrôle"),
    ("NC07", "Manipulation, stockage"),
    ("NC08", "Fournisseur"),
    ("NC09", "Outil – ajustement sur machine"),
    ("NC10", "Outil – ajustement"),
    ("NC11", "Outil – dommage"),
    ("NC12", "Ajustement machine"),
    ("NC13", "Panne de machine"),
    ("NC14", "Coupage de la matière première"),
    ("NC15", "Erreur aléatoire (voir texte)"),
    ("NC16", "NTTL"),
    ("NC17", "Essai"),
    ("NC18", "Moule d'estampage"),
    ("NC19", "Développement tech"),
    ("NC20", "Erreur préparation"),
    ("NC21", "Navigabilité"),
    ("NC22", "Responsable qualité"),
    ("NC23", "Evaluateur des contraintes"),
    ("NC24", "Responsable calcul"),
    ("NC25", "Alimentation électrique coupée"),
    ("NC26", "Echec de l'appareil"),
    ("NC27", "Analyse chimique"),
    ("NC28", "Outils de travail"),
    ("NC29", "Dégraissage insuffisant"),
    ("NC30", "Contamination du bain"),
    ("NC31", "Bain trop rempli"),
    ("AC01", "Rebut"),
    ("AC02", "Retouche en cours"),
    ("AC03", "FNC en cours"),
    ("AC04", "AQF en cours"),
    ("AC05", "IQN processing"),
    ("AC08", "Retouche contrôlée"),
    ("AC14", "OF de réparation terminé et contrôlé"),
    ("AC16", "Utiliser en l'état"),
    ("AC18", "OF terminé et contrôlé"),
    ("AC20", "Travaux Restants Terminés"),
    ("AC34", "Avis Défaut en cours"),
    ("AC37", "Avis sur procédé en cours"),
    ("AC38", "Avis étalonnage en cours"),
    ("AC47", "Retouche fourn. in situ ctrlée"),
    ("AC49", "Retour en cours"),
    ("AC52", "Transférer en stock bloqué"),
    ("AC53", "Réintégration dans le stock"),
]

# Define schema
schema = StructType([
    StructField("activity_type_code", StringType(), False),
    StructField("activity_code_description", StringType(), False)
])

# Create dataframe
df_nc = spark.createDataFrame(data, schema=schema)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Join notification table to activity table

# COMMAND ----------

df_qn_activity_transf = df_qn_activity_raw.join(
    df_qn_header_raw,
    on=df_qn_activity_raw.notification_code == df_qn_header_raw.notification_ID,
    how="inner",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Get activity code description

# COMMAND ----------

df_qn_activity_transf = df_qn_activity_transf.join(
    df_nc, on=["activity_type_code"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr3 - Business ID 
# MAGIC Concat notication code and item

# COMMAND ----------

df_qn_activity_transf = df_qn_activity_transf.withColumn(
    "notification_code_item_activity_ID",
    f.concat_ws("-", f.col("notification_code"), f.col("notification_item_number"), f.col("activity_ID")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality Check

# COMMAND ----------

pk_col = "notification_code_item_activity_ID"
columns = df_qn_activity_transf.columns
columns.remove(pk_col)
new_column_order = [pk_col] + columns
df_qn_activity_transf = df_qn_activity_transf.select(new_column_order)

# COMMAND ----------

validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx_final = SparkDFDataset(df_qn_activity_transf, persist=False)

quality_check_results = [
    df_gx_final.expect_column_values_to_be_unique("notification_code_item_activity_ID"),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level="RED",
    info_message="All checks inspection",
    error_message="Quality checks failed for quality notification item table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="quality_notification_task",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Gold Table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "quality"
DESTINATION_TABLE = "quality_notification_activity"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_qn_activity_transf,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_qn_activity_transf.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "quality_notification_activity_pk"
TABLE_PK_COLS = "notification_code_item_activity_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ###Save Gold exposed table

# COMMAND ----------

dest_full_tablename = f"{DESTINATION_TABLE_FULL_PATH}_exposed"
Begin_By = "QMUR"
selected_columns = [
    col
    for col in df_qn_activity_transf.columns
    if not col.startswith(Begin_By)
]
select_statement = ", ".join(selected_columns)
# --------------------------------------------------------------------------------
table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH, dest_full_tablename, select_statement, replace_view=True
)
