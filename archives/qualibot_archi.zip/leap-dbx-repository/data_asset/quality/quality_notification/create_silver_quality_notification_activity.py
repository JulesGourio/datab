# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim of this notebook is to create the silver table of quality notification activities based on SAP QMUR table. 
# MAGIC - Cleaning of data format
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.qmur_atest
# MAGIC   - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_qmur
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_silver.quality.quality_notification_activities
# MAGIC   
# MAGIC **Triggered by:** 
# MAGIC Data asset - Quality notification activities

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

df_qmur_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.qmur_latest"
)

df_header_qmur = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_qmur"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Inputs - Manual declaration

# COMMAND ----------

OUTPUT_SILVER_TABLE_QUALITY_ACTIVITY  = (
    f"{PIPELINE_WRITE_ENV}_silver.quality.quality_notification_activity"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep1 - Renaming & casting columns

# COMMAND ----------

df_qmur_raw = table_utils.add_prefix_to_columns(df_qmur_raw, "QMUR")

table_utils.check_schema_of_the_header_file(df_header_qmur)

df_qn_activity_prep = table_utils.rename_columns_with_sap_business_header(
    df_qmur_raw, df_header_qmur
)

df_qn_activity_prep = table_utils.cast_columns_with_sap_business_headers(
    df_qn_activity_prep, df_header_qmur
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep2 - Cleaning

# COMMAND ----------

COL_CLEANING_LEADING_ZEROS = ["notification_code"]

df_qn_activity_prep = table_utils.remove_leading_zeros(
    df_qn_activity_prep, COL_CLEANING_LEADING_ZEROS
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    OUTPUT_SILVER_TABLE_QUALITY_ACTIVITY, df_qn_activity_prep, "overwrite", True
)
