# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim of this notebook is to create the silver table of quality notification item based on SAP QMFE table. 
# MAGIC - Cleaning of data format
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.qmfe_atest
# MAGIC   - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_qmfe
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_silver.quality.quality_notification_item
# MAGIC   
# MAGIC **Triggered by:** 
# MAGIC Data asset - Quality notification item

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

df_qmfe_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.qmfe_latest"
)

df_header_qmfe = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_qmfe"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Inputs - Manual declaration

# COMMAND ----------

OUTPUT_SILVER_TABLE_QUALITY_NOTIFICATION_ITEM  = (
    f"{PIPELINE_WRITE_ENV}_silver.quality.quality_notification_item"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Renaming columns

# COMMAND ----------

df_qmfe_raw = table_utils.add_prefix_to_columns(df_qmfe_raw, "QMFE")

table_utils.check_schema_of_the_header_file(df_header_qmfe)

df_qmfe_prep = table_utils.rename_columns_with_sap_business_header(
    df_qmfe_raw, df_header_qmfe
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - Columns cleaning

# COMMAND ----------

COL_CLEANING_LEADING_ZEROS = ["notification_ID"]

df_qmfe_prep = table_utils.remove_leading_zeros(
    df_qmfe_prep, COL_CLEANING_LEADING_ZEROS
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    OUTPUT_SILVER_TABLE_QUALITY_NOTIFICATION_ITEM, df_qmfe_prep, "overwrite", True
)
