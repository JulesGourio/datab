# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim of this notebook is to create the silver table of quality notification task based on SAP QMSM table. 
# MAGIC - Cleaning of data format
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.qmsm_atest
# MAGIC   - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_qmsm
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_silver.quality.quality_notification_task
# MAGIC   
# MAGIC **Triggered by:** 
# MAGIC Data asset - Quality notification task

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ##LEAP tables

# COMMAND ----------

df_qmsm_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.qmsm_latest"
)

df_header_qmsm = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_qmsm"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Manual declaration

# COMMAND ----------

OUTPUT_SILVER_TABLE_QUALITY_NOTIFICATION_TASKS  = (
    f"{PIPELINE_WRITE_ENV}_silver.quality.quality_notification_task"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Renaming & casting columns

# COMMAND ----------

df_qmsm_raw = table_utils.add_prefix_to_columns(df_qmsm_raw, "QMSM")

table_utils.check_schema_of_the_header_file(df_header_qmsm)

df_qmsm_prep = table_utils.rename_columns_with_sap_business_header(
    df_qmsm_raw, df_header_qmsm
)

df_qmsm_prep = table_utils.cast_columns_with_sap_business_headers(
    df_qmsm_prep, df_header_qmsm
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep2 - Cleaning

# COMMAND ----------

df_qmsm_prep = table_utils.remove_leading_zeros(
    df_qmsm_prep, ["notification_ID"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Deletion indicator

# COMMAND ----------

df_qn_tasks_transf = df_qmsm_prep.withColumn(
    "is_task_deleted",
    f.when(f.col("task_deletion_indicator") == "X", f.lit(True)).otherwise(
        f.lit(False)
    ),
).drop("task_deletion_indicator")

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    OUTPUT_SILVER_TABLE_QUALITY_NOTIFICATION_TASKS,
    df_qn_tasks_transf,
    "overwrite",
    True,
)
