# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim of this notebook is to create the gold table of supplier quality notification based on quality notification silver tables
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {PIPELINE_READ_ENV}_gold.quality.quality_notification_exposed
# MAGIC   - {REFERENCE_READ_ENV}_silver.quality.quality_notification_item
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.quality.supplier_quality_notification
# MAGIC   
# MAGIC **Triggered by:** 
# MAGIC Data asset - Supplier quality notification

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import time
import pyspark.sql.functions as f

from leap_utils.data_asset import table_utils
from leap_utils.common import logger

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = dbutils.widgets.get("log_level")

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC #Input

# COMMAND ----------

df_qn_header_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.quality.quality_notification"
)

# COMMAND ----------

df_qn_item_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_silver.quality.quality_notification_item"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep1 - qn_item

# COMMAND ----------

df_qn_item_prep = (
    df_qn_item_raw.select(
        "notification_ID",
        "cause_code",
        "cause_group",
        "QMFE_feqklas",
        "QMFE_oteil",
    )
    .withColumnRenamed("QMFE_feqklas", "defect_class")
    .withColumnRenamed("QMFE_oteil", "defect_source")
    .groupBy("notification_ID")
    .agg(
        f.min(f.col("defect_class")).alias("defect_class"),
        f.concat_ws("-", f.collect_set("cause_code")).alias("cause_code"),
        f.concat_ws("-", f.collect_set("cause_group")).alias("cause_group"),
        f.first("defect_source").alias("defect_source"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep2 - qn_header

# COMMAND ----------

df_qn_header_prep = (
    df_qn_header_raw.select("notification_ID", "QMEL_objnr")
    .distinct()
    .withColumnRenamed("QMEL_objnr", "objnr")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr1 - Filter on ZQ only (supplier quality notification)

# COMMAND ----------

df_zq = df_qn_header_raw.filter(f.col("notification_type") == "ZQ")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr2 - Union with associated ZM quality notificaton

# COMMAND ----------

df_zq_and_zm = (
    df_zq.unionByName(
        df_zq.select("SI_reference_number").dropDuplicates().join(
            df_qn_header_raw.filter(f.col("notification_type") == "ZM"),
            "SI_reference_number",
            "inner",
        ),
        allowMissingColumns=True,
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr3 - Union with associated Z1 quality notificaton (rework)

# COMMAND ----------

df_zq_and_zm_and_z1 = (
    df_zq_and_zm.unionByName(
        df_zq.select("SI_reference_number").dropDuplicates().join(
            df_qn_header_raw.filter(f.col("notification_type") == "Z1"),
            "SI_reference_number",
            "inner",
        ),
        allowMissingColumns=True,
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr4 - Union with associated Z2 quality notificaton (concession)

# COMMAND ----------

df_zq_and_zm_and_z1_and_z2 = (
    df_zq_and_zm_and_z1.unionByName(
        df_zq.select("SI_reference_number").dropDuplicates().join(
            df_qn_header_raw.filter(f.col("notification_type") == "Z2"),
            "SI_reference_number",
            "inner",
        ),
        allowMissingColumns=True,
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr5 - Add column "is_reworked"

# COMMAND ----------

df_supplier_qn = df_zq_and_zm_and_z1_and_z2.join(
    df_qn_header_raw.filter(f.col("notification_type") == "Z1")
    .select("SI_reference_number")
    .dropDuplicates()
    .withColumn("is_reworked", f.lit(True)),
    on="SI_reference_number",
    how="left",
).withColumn(
    "is_reworked",
    f.when(
        (f.col("notification_type") == "ZQ") & (f.col("is_reworked")), f.lit(True)
    ).otherwise(f.lit(False)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr5bis - Add column "is_concession"

# COMMAND ----------

df_supplier_qn = df_supplier_qn.join(
    df_qn_header_raw.filter(f.col("notification_type") == "Z2")
    .select("SI_reference_number")
    .dropDuplicates()
    .withColumn("is_concession", f.lit(True)),
    on="SI_reference_number",
    how="left",
).withColumn(
    "is_concession",
    f.when(
        (f.col("notification_type") == "ZQ") & (f.col("is_concession")), f.lit(True)
    ).otherwise(f.lit(False)),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr6 - Join with quality notification item

# COMMAND ----------

df_supplier_qn = df_supplier_qn.join(df_qn_item_prep, on="notification_ID", how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr7 - Join with supplier data

# COMMAND ----------

df_supplier_qn = df_supplier_qn.withColumn(
    "is_internal",
    f.when(
        (f.col("intercompany_flow") == "X000") | (f.col("intercompany_flow").isNull()),
        f.lit(False),
    ).otherwise(f.lit(True)),
).drop("intercompany_flow")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr8 - Drop useless columns

# COMMAND ----------

df_supplier_qn = df_supplier_qn.drop(
    "work_order", "delivery_rank", "workcenter_description", "workcenter_group_desc"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr9 - Adding objnr column

# COMMAND ----------

df_supplier_qn =df_supplier_qn.join(df_qn_header_prep, on="notification_ID", how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality Check

# COMMAND ----------

pk_col = "notification_ID"
columns = df_supplier_qn.columns
columns.remove(pk_col)
new_column_order = [pk_col] + columns
df_supplier_qn = df_supplier_qn.select(new_column_order)

# COMMAND ----------

validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx_final = SparkDFDataset(df_supplier_qn, persist=False)

quality_check_results = [
    df_gx_final.expect_column_values_to_be_unique("notification_ID"),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level="RED",
    info_message="All checks inspection",
    error_message="Quality checks failed for quality notification item table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="quality_notification_item",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Gold Table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "quality"
DESTINATION_TABLE = "supplier_quality_notification"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_supplier_qn,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_supplier_qn.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "supplier_quality_notification_exposed_pk"
TABLE_PK_COLS = "notification_ID"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ###Save Gold exposed table

# COMMAND ----------

dest_full_tablename = f"{DESTINATION_TABLE_FULL_PATH}_exposed"
selected_columns = [
    col
    for col in df_supplier_qn.columns
    if not (col.startswith("QMFE") | col.startswith("QMEL"))
]
select_statement = ", ".join(selected_columns)
# --------------------------------------------------------------------------------
table_utils.create_table_view(
    DESTINATION_TABLE_FULL_PATH, dest_full_tablename, select_statement, replace_view=True
)
