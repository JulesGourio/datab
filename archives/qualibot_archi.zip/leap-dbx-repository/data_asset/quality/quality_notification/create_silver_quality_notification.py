# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim of this notebook is to create the silver table of quality notification (headers only) based on SAP QMEL table. 
# MAGIC - Cleaning of data format
# MAGIC
# MAGIC **Input table(s):**  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.qmel_latest
# MAGIC   - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_qmel_v2
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.jest_latest
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_silver.quality.quality_notification
# MAGIC   
# MAGIC **Triggered by:** 
# MAGIC Data asset - Quality notification 

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

import pyspark.sql.functions as f

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

df_qmel_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.qmel_latest"
)

df_header_qmel = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_qmel_v2"
)

# COMMAND ----------

df_jest = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.jest_latest"
)

df_tj30t = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tj30t_latest"
)

df_tj02t = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.tj02t_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Inputs - Manual declaration

# COMMAND ----------

OUTPUT_SILVER_TABLE_QUALITY_NOTIFICATION = (
    f"{PIPELINE_WRITE_ENV}_silver.quality.quality_notification"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Renaming & casting columns

# COMMAND ----------

df_qmel_raw = table_utils.add_prefix_to_columns(df_qmel_raw, "QMEL")

table_utils.check_schema_of_the_header_file(df_header_qmel)

df_qmel_prep = table_utils.rename_columns_with_sap_business_header(
    df_qmel_raw, df_header_qmel
)

df_qmel_prep = table_utils.cast_columns_with_sap_business_headers(df_qmel_prep, df_header_qmel, date_format="yyyyMMdd")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - Columns cleaning

# COMMAND ----------

COL_CLEANING_LEADING_ZEROS = [
    "work_order",
    "material_number",
    "notification_ID",
    "rework_order",
    "production_work_order",
    "rank_MSN",
    "rank_LE",
    "delivery_rank",
    "profit_center",
    "workcenter_code",
    "PO_item_number",
    "PO_number",
]

df_qmel_prep = table_utils.remove_leading_zeros(
    df_qmel_prep, COL_CLEANING_LEADING_ZEROS
)

# COMMAND ----------

for col in COL_CLEANING_LEADING_ZEROS:
    df_qmel_prep = df_qmel_prep.withColumn(
        col, f.when(f.col(col) == "", f.lit(None)).otherwise(f.col(col))
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 3 - Event status

# COMMAND ----------

df_jest_prep = (
    df_jest.filter(f.col("inact").isNull())
    .select("objnr", "stat")
    .withColumnRenamed("objnr", "QMEL_objnr")
    .where(
        f.col("stat") == "I0076"
    )  # I0076 corresponds to deleted notification (TSUP in french, DLT in english)
    .where(f.col("QMEL_objnr").startswith("QM"))  # filter on Quality notifications
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - is_deleted column
# MAGIC Coalesce between X deletion flag and TSUP status.

# COMMAND ----------

df_qmel_transf = df_qmel_prep.join(df_jest_prep, ['QMEL_objnr'], how='left')

# COMMAND ----------

df_qmel_transf = df_qmel_transf.withColumn(
    "is_notification_deleted",
    f.when(f.col("deletion_indicator") == "X", f.lit(True))
    .when(f.col("stat") == "I0076", f.lit(True))
    .otherwise(f.lit(False)),
).drop("deletion_indicator", "stat")

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    OUTPUT_SILVER_TABLE_QUALITY_NOTIFICATION, df_qmel_transf, "overwrite", True
)
