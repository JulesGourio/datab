# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for Logistics movement based on bronze sap MKPF & MSEG tables. 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_silver.logistics_movement_latest
# MAGIC   
# MAGIC **Intput :**  
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.mkpf_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.mseg_latest  
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.makt_latest
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC - Ingestion Raw SAP  
# MAGIC
# MAGIC **Things to do:** 
# MAGIC  - Join Header and Item + Description
# MAGIC  - Correction SAP Decimal  
# MAGIC  - Renaming Header according business rules  

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame

from leap_utils.data_asset import table_utils

# Correction Amount for SAP currency with 3 digits
from leap_utils.data_asset.amount_correction import (
    create_corrected_amounts,
)

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Table from SAP

# COMMAND ----------

# Upload SAP Header of log Mvt
df_mkpf = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.mkpf_latest")
# Renaming starting with MKPF_
df_mkpf = table_utils.add_prefix_to_columns(df_mkpf, "MKPF")

# Upload SAP item of log Mvt
df_mseg = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.mseg_latest")
# Renaming starting with MKPF_
df_mseg = table_utils.add_prefix_to_columns(df_mseg, "MSEG")

# Upload SAP Description Material
df_makt = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.makt_latest")
# Keep only English Description
df_makt = df_makt.filter(f.col("spras") == "E")

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Headers & Item for Logistics Movements & Description

# COMMAND ----------

# Rename and Select Description for join
df_makt = df_makt.withColumnRenamed("maktx", "Material_Description")
df_makt = df_makt.select("matnr", "Material_Description")

df_join = (
    df_mkpf.alias("A")
    .join(
        df_mseg.alias("B"),
        (f.col("A.MKPF_mblnr") == f.col("B.MSEG_mblnr"))
        & (f.col("A.MKPF_mjahr") == f.col("B.MSEG_mjahr")),
        "left",
    )
    .join(df_makt.alias("C"), f.col("B.MSEG_matnr") == f.col("C.matnr"), "left")
)
df_join = df_join.drop("MSEG_mandt", "MSEG_mblnr", "MSEG_mjahr", "matnr")

# COMMAND ----------

# MAGIC %md
# MAGIC # Management of Wrong SAP decimal for spécific currency (TND, JPY,...)

# COMMAND ----------

# Correction Amount Item Value
df_log_corrected = create_corrected_amounts(df_join, "MSEG_dmbtr", "MSEG_waers")
df_log_corrected = df_log_corrected.drop("MSEG_dmbtr")
df_log_corrected = df_log_corrected.withColumnRenamed(
    "MSEG_dmbtr_corrected", "MSEG_dmbtr"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming Header with business entries

# COMMAND ----------

# Upload Header Business MKPF
df_name_mkpf = spark.read.table("prod_bronze.headers_sap.headers_sap_business_mkpf")
# Call function Check Header files
check_schema_of_the_file(df_name_mkpf)
# Call Function Delete rows null
df_name_mkpf = delete_null_rows(df_name_mkpf)

# Upload Header Business MSEG
df_name_mseg = spark.read.table("prod_bronze.headers_sap.headers_sap_business_mseg")
# Call function Check Header files
check_schema_of_the_file(df_name_mseg)
# Call Function Delete rows null
df_name_mseg = delete_null_rows(df_name_mseg)

# Union Headers
df_names_all = df_name_mkpf.unionByName(df_name_mseg)

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_log_corrected, df_names_all
)
# Call Funtion Create Columns on Date format
df_log = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_names_all
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Cleasing raw data from material data asset

# COMMAND ----------

# Formatting Material_Number without '0' on left side
df_log_format = df_log.withColumn(
    "Material_number", f.regexp_replace(df_log.Material_number, "^0+", "")
)
# Formatting WO_Number without '0' on left side
df_log_format = df_log_format.withColumn(
    "Work_order", f.regexp_replace(df_log_format.Work_order, "^0+", "")
)
# Formatting Profit_Center without '0' on left side
df_log_format = df_log_format.withColumn(
    "Profit_center", f.regexp_replace(df_log_format.Profit_center, "^0+", "")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save table

# COMMAND ----------

catalog = f"{WRITE_ENV}_silver"
domain = "supply_chain_logistic"
table = "part_movement"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_log_format,
    mode="overwrite",
    overwrite_schema=True
)
