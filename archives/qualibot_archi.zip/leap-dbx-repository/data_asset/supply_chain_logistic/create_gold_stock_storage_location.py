# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # [STOCK BY STORAGE LOCATION]
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC The aim of this notebook is to create a data asset for stock quantity by storage location & plant
# MAGIC
# MAGIC **Highlighted complexities:**
# MAGIC - N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Build for Use Case 2 - Inventory
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mard_latest/stack
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mslb_latest/stack
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eket_latest/stack
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekko_latest/stack
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekpo_latest/stack
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mssa_latest/stack
# MAGIC - {PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.stock_by_storage_location_daily_history
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - N/A
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.stock_by_storage_location
# MAGIC - {PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.stock_by_storage_location_daily_history
# MAGIC - {PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.stock_by_storage_location_weekly
# MAGIC - {PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.stock_by_storage_location_monthly
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f, Column
from functools import reduce

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC - **cast_column** required to manage casting of column
# MAGIC - **save_table** required for saving Table on DBX
# MAGIC - **get_latest_version_for_each_id_column** required for getting latest data in weekly/monthly modes
# MAGIC - **UnityCatalogCheckTableExists** required for checking if daily history table exists

# COMMAND ----------

from leap_utils.data_asset.table_utils import (
    cast_column,
    save_table,
    get_latest_version_for_each_id_column,
    UnityCatalogCheckTableExists
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("period", "daily")
PERIOD = dbutils.widgets.get("period")

dbutils.widgets.text("max_days_daily_history", "90")
try:
    MAX_DAILY_HISTORY = dbutils.widgets.get("max_days_daily_history")
except ValueError:
    raise ValueError("Widget parameter 'max_days_daily_history' must be an integer.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not.

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config other

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Folder Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC #### Input Folder location

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC #### Min Date to consider parameter

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

def load_reference_table(table_name, REFERENCE_READ_ENV, PERIOD):
    """
    Load and filter a reference table according to the period (daily, weekly, monthly).

    Args:
        table_name (str): Table name without suffix (_latest or _stack).
        REFERENCE_READ_ENV (str): Environment prefix (dev, preprod...).
        PERIOD (str): "daily", "weekly" or "monthly".

    Returns:
        DataFrame: Processed table.
    """

    if PERIOD == "daily":
        df = spark.read.table(
            f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.{table_name}_latest"
        )

    elif PERIOD in ["weekly", "monthly"]:
        df = spark.read.table(
            f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.{table_name}_stack"
        )
        # On weekly mod we take the closest date from the last monday at 0:01
        if PERIOD == "weekly":
            date_ref = f.date_sub(f.next_day(f.current_date(), "Monday"), 7)
        else:
            # On monthly mod we take the closest date from the 02 of the month at 0:01
            date_ref = f.date_add(
                f.to_timestamp(f.trunc(f.current_timestamp(), "month")), 1
            )

        df = df.withColumn("Date_Ref", date_ref.try_cast("timestamp"))

        df = df.withColumn(
            "Gap_Date", f.abs(f.col("extraction_timestamp") - f.col("Date_Ref"))
        )

        df_temp = df.select("Gap_Date", "extraction_timestamp").dropDuplicates()
        closest_date = (
            df_temp.orderBy("Gap_Date").select("extraction_timestamp").head()[0]
        )

        df = df.filter(f.col("extraction_timestamp") <= closest_date).drop(
            "Gap_Date", "Date_Ref"
        )

        # ====================================================================
        # OPTIMIZATION - Filter after last FULL
        # ====================================================================
        max_date_full = (
            df.filter(f.col("file_mode") == "FULL")
            .select(f.max("extraction_timestamp"))
            .first()["max(extraction_timestamp)"]
        )

        if max_date_full:
            df = df.filter(f.col("extraction_timestamp") >= max_date_full)

        df = df.repartition("ID")
        df = get_latest_version_for_each_id_column(df, "ID", "extraction_timestamp")

    else:
        raise ValueError(f"Unsupported PERIOD: {PERIOD}")

    return df


# COMMAND ----------

def cast_to_double_sap_column(col: str) -> Column:
    """
    SAP places the minus sign at the end so we need to move it to the beginning
    if there is one, before casting to double

    :param col: name of the column to alter
    :return: altered column
    """
    return (
        f.when(f.col(col).endswith("-"),
               -f.regexp_replace(f.col(col), "-", "").try_cast("double"))
         .otherwise(f.col(col).try_cast("double"))
         .alias(col)
    )


# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ## Schema - Daily history
# MAGIC Write daily history schema, but don't read because we will just filter the table then append.

# COMMAND ----------

StockStorageLocationDailyHistoryInputOutput = (
    f"{PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.stock_by_storage_location_daily_history"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - MARD from SAP
# MAGIC
# MAGIC **df_mard** Bronze Table From SAP - Storage Location Data for Material
# MAGIC For **Weekly** run, we take Latest Version
# MAGIC For **Monthly** we take last version of previous month
# MAGIC Table managed on FULL mode, we keep only last stack

# COMMAND ----------

df_mard = load_reference_table("mard", REFERENCE_READ_ENV, PERIOD)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - MSLB from SAP
# MAGIC
# MAGIC **df_mslb** Bronze Table From SAP - Special Stocks Vendor
# MAGIC For **Weekly** run, we take Latest Version
# MAGIC For **Monthly** we take last version of previous month
# MAGIC Table managed on FULL mode, we keep only last stack

# COMMAND ----------

df_mslb = load_reference_table("mslb", REFERENCE_READ_ENV, PERIOD)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - EKET from SAP
# MAGIC
# MAGIC **df_eket** Bronze Table From SAP - Scheduling Agreement Schedule Lines
# MAGIC For **Weekly** run, we take Latest Version
# MAGIC For **Monthly** we take last version of previous month
# MAGIC Table managed on FULL mode, we keep only last stack

# COMMAND ----------

df_eket = load_reference_table("eket", REFERENCE_READ_ENV, PERIOD)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - EKKO from SAP
# MAGIC
# MAGIC **df_ekko** Bronze Table From SAP - Purchasing Document Header
# MAGIC For **Weekly** run, we take Latest Version
# MAGIC For **Monthly** we take last version of previous month
# MAGIC Table managed on FULL mode, we keep only last stack

# COMMAND ----------

df_ekko = load_reference_table("ekko", REFERENCE_READ_ENV, PERIOD)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - EKPO from SAP
# MAGIC
# MAGIC **df_ekpo** Bronze Table From SAP - Purchasing Document Item
# MAGIC For **Weekly** run, we take Latest Version
# MAGIC For **Monthly** we take last version of previous month
# MAGIC Table managed on FULL mode, we keep only last stack

# COMMAND ----------

df_ekpo = load_reference_table("ekpo", REFERENCE_READ_ENV, PERIOD)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import - MSSA from SAP
# MAGIC
# MAGIC **df_mssa** Bronze Table From SAP - Stock Customer Orders on Hand
# MAGIC For **Weekly** run, we take Latest Version
# MAGIC For **Monthly** we take last version of previous month
# MAGIC Table managed on FULL mode, we keep only last stack

# COMMAND ----------

df_mssa = load_reference_table("mssa", REFERENCE_READ_ENV, PERIOD)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation MARD - Storage Location Data for Material

# COMMAND ----------

# Selection Columns & Renaming Headers
df_mard_selected = df_mard.select(
    [
        f.col("matnr").alias("Material_Number"),
        f.col("werks").alias("Plant"),
        f.col("lgort").alias("Storage_Location"),
        f.col("labst").alias("Free_Stock"),
        f.col("umlme").alias("Transfert_Stock"),
        f.col("insme").alias("Quality_Stock"),
        f.col("einme").alias("UnFree_Stock"),
        f.col("speme").alias("Block_Stock"),
        f.col("retme").alias("Return_Stock"),
        f.col("diskz").alias("MRP_Code"),
        f.col("lgpbe").alias("Location"),
        f.col("klabs").alias("VMI"),
    ]
)
# ---------------------------------------------------------------------------------
# casting columns
columns_to_cast = ["Free_Stock",
                   "Transfert_Stock",
                   "Quality_Stock",
                   "UnFree_Stock",
                   "Block_Stock",
                   "Return_Stock",
                   "VMI"]
                   
df_mard_end = df_mard_selected.select(
    *[cast_to_double_sap_column(c) for c in columns_to_cast],
    *[c for c in df_mard_selected.columns if c not in columns_to_cast]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation MSLB- Special Stocks Vendor

# COMMAND ----------

# Selection Columns & Renaming Headers
df_mslb_formatted = df_mslb.select(
    [
        f.col("matnr").alias("Material_Number"),
        f.col("werks").alias("Plant"),
        f.col("lifnr").alias("Storage_Location"),
        f.col("lblab").alias("Free_Stock_Supplier"),
        f.col("lbins").alias("Quality_Stock_Supplier"),
    ]
)
# ---------------------------------------------------------------------------------
# casting columns
columns_to_cast = ["Free_Stock_Supplier","Quality_Stock_Supplier"]
df_mslb_cast = df_mslb_formatted.select(
    *[cast_to_double_sap_column(c) for c in columns_to_cast],
    *[c for c in df_mslb_formatted.columns if c not in columns_to_cast]
)
# ---------------------------------------------------------------------------------
# Apply filter in order to keep only entries where quantity is gretar than 0
df_mslb_end = df_mslb_cast.filter(
    (f.col("Free_Stock_Supplier") != "0") | (f.col("Quality_Stock_Supplier") != "0")
)
df_mslb_end = df_mslb_end.withColumn(
    "Supplier_Stock", f.col("Free_Stock_Supplier") + f.col("Quality_Stock_Supplier")
).drop("Free_Stock_Supplier", "Quality_Stock_Supplier")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation EKET - Scheduling Agreement Schedule Lines

# COMMAND ----------

# Selection Columns & Renaming Headers
df_eket_selected = df_eket.select(
    [
        f.col("wamng").alias("Qty_Delivered"),
        f.col("wemng").alias("Qty_Outbound_Delivery"),
        f.col("ebeln").alias("Po_Number"),
        f.col("ebelp").alias("Po_Number_Item"),
    ]
)
# ---------------------------------------------------------------------------------
# casting columns
columns_to_cast = ["Qty_Delivered","Qty_Outbound_Delivery"]
df_eket_cast = df_eket_selected.select(
    *[cast_to_double_sap_column(c) for c in columns_to_cast],
    *[c for c in df_eket_selected.columns if c not in columns_to_cast]
)
# ---------------------------------------------------------------------------------
# Formatting Remove lead Zero
df_eket_formatted = df_eket_cast.withColumn(
    "Po_Number",
    f.regexp_replace(df_eket_cast.Po_Number, "^0+", ""),
).withColumn(
    "Po_Number_Item",
    f.regexp_replace(df_eket_cast.Po_Number_Item, "^0+", ""),
)
# ---------------------------------------------------------------------------------
# Filter - We keep only Entries where quantity delivered is not equal to outbound Delivery
df_eket_end = df_eket_formatted.filter(
    f.col("Qty_Delivered") != f.col("Qty_Outbound_Delivery")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation EKKO - Purchasing Document Header

# COMMAND ----------

# Selection Columns & Renaming Headers
df_ekko_selected = df_ekko.select(
    f.col("reswk").alias("Delivery_Plant"),
    f.col("ebeln").alias("Po_Number"),
)
# ---------------------------------------------------------------------------------
# Formatting Remove lead Zero
df_ekko_formatted = df_ekko_selected.withColumn(
    "Po_Number",
    f.regexp_replace(df_ekko_selected.Po_Number, "^0+", ""),
)
# ---------------------------------------------------------------------------------
# Filter - We keep only Interco & Intra Purchase Order
# (Ie : Delivery plant not equal to empty)
df_ekko_end = df_ekko_selected.filter(f.col("Delivery_Plant") != "").drop(
    "Delivery_Plant"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation EKPO - Purchasing Document Item

# COMMAND ----------

# Selection Columns & Renaming Headers
df_ekpo_selected = df_ekpo.select(
    [
        f.col("umrez").alias("Qty_Ordered"),
        f.col("umren").alias("Coeff"),
        f.col("ebeln").alias("Po_Number"),
        f.col("ebelp").alias("Po_Number_Item"),
        f.col("matnr").alias("Material_Number"),
        f.col("werks").alias("Plant"),
        f.col("lgort").alias("Storage_Location"),
        f.col("retpo").alias("Return_Item"),
        f.col("loekz").alias("Cancel_Flag"),
        f.col("bstyp").alias("Purchase_Type"),
        f.col("stapo").alias("Stat"),
        f.col("elikz").alias("Final_Delivery"),
    ]
)
# ---------------------------------------------------------------------------------
# casting columns
columns_to_cast = ["Qty_Ordered","Coeff"]
df_ekpo_cast = df_ekpo_selected.select(
    *[cast_to_double_sap_column(c) for c in columns_to_cast],
    *[c for c in df_ekpo_selected.columns if c not in columns_to_cast]
)
# ---------------------------------------------------------------------------------
# Formatting Remove lead Zero
df_ekpo_formatted = df_ekpo_cast.withColumn(
    "Po_Number",
    f.regexp_replace(df_ekpo_cast.Po_Number, "^0+", ""),
).withColumn(
    "Po_Number_Item",
    f.regexp_replace(df_ekpo_cast.Po_Number_Item, "^0+", ""),
)
# ---------------------------------------------------------------------------------
# Filter - We keep only Purchase Order Not cancelled
# Not Delivered, on Industrial Type and with no statistic

df_ekpo_end = df_ekpo_formatted.filter(
    (f.col("Cancel_Flag").isNull())
    & (f.col("Stat").isNull())
    & (f.col("Final_Delivery").isNull())
    & ((f.col("Purchase_Type") == "F") | (f.col("Purchase_Type") == "L"))
).drop("Stat", "Purchase_Type", "Final_Delivery", "Cancel_Flag")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation MSSA - Stock Customer Orders on Hand

# COMMAND ----------

# Selection Columns & Renaming Headers
df_mssa_selected = df_mssa.select(
    [
        f.col("matnr").alias("Material_Number"),
        f.col("werks").alias("Plant"),
        f.col("vbeln").alias("Sales_Order"),
        f.col("posnr").alias("Sales_Order_Item"),
        f.col("salab").alias("Qty_Free"),
        f.col("sains").alias("Qty_Quality"),
        f.col("satra").alias("Qty_Transit"),
    ]
)
# ---------------------------------------------------------------------------------
# casting columns
columns_to_cast = ["Qty_Free","Qty_Quality","Qty_Transit"]
df_mssa_end = df_mssa_selected.select(
    *[cast_to_double_sap_column(c) for c in columns_to_cast],
    *[c for c in df_mssa_selected.columns if c not in columns_to_cast]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 0 - Filter daily history
# MAGIC
# MAGIC For **Daily** run, we apply a filter on the date (keep only MAX_DAILY_HISTORY days) - for **Weekly/Monthly** pass.

# COMMAND ----------

if PERIOD == "daily" and UnityCatalogCheckTableExists(StockStorageLocationDailyHistoryInputOutput):    
    spark.sql(f"""
    DELETE FROM {StockStorageLocationDailyHistoryInputOutput}
    WHERE `Observation_Day` <= current_date() - INTERVAL {MAX_DAILY_HISTORY} DAYS
    OR `Observation_Day` == current_date()
    """)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 1 - Creation DataFrame Stock Transit
# MAGIC
# MAGIC Stock Transit is not stored in SAP Table - We need to calculate according Purchase Order Table
# MAGIC We will use EKKO/EKPO/EKET table
# MAGIC

# COMMAND ----------

# 1st Join PO_Item with only delivery still in progress
df_join_eket_ekpo = df_ekpo_end.join(
    df_eket_end,
    on=["Po_Number", "Po_Number_Item"],
    how="inner",
)
# ---------------------------------------------------------------------------------
# 2nd Join in order to keep only Interco flows
df_join_purchase = df_join_eket_ekpo.join(df_ekko_end, on=["Po_Number"], how="inner")
# ---------------------------------------------------------------------------------
# Calcul transit stock
df_transit_stock = df_join_purchase.withColumn(
    "Transit_Stock",
    f.when(
        f.col("Return_Item") == "X",
        f.try_divide(-1
        * (f.col("Qty_Delivered") - f.col("Qty_Outbound_Delivery"))
        * f.col("Qty_Ordered"),
        f.col("Coeff")),
    ).otherwise(
        f.try_divide((f.col("Qty_Delivered") - f.col("Qty_Outbound_Delivery"))
        * f.col("Qty_Ordered"),
        f.col("Coeff"))
    ),
).withColumn("Storage_Location", f.lit("Transit"))

df_transit_stock = df_transit_stock.withColumn(
    "Transit_Stock",
    f.when(f.col("Transit_Stock") < 0, f.lit(0)).otherwise(f.col("Transit_Stock")),
)
# ---------------------------------------------------------------------------------
df_transit_stock_end = df_transit_stock.select(
    "Material_Number", "Plant", "Storage_Location", "Transit_Stock"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 2 - Creation DataFrame Stock Customers
# MAGIC Stock Customers are stock allocated directly to a specific Sales Order

# COMMAND ----------

# Generate Column to categorize Stock
df_customers_stock = df_mssa_end.withColumn("Storage_Location", f.lit("Customers"))
# ---------------------------------------------------------------------------------
# Calculate Stock Available for Customers
df_customers_stock_calc = df_customers_stock.withColumn(
    "Customers_Stock", f.col("Qty_Free") + f.col("Qty_Quality") + f.col("Qty_Transit")
).drop("Qty_Free", "Qty_Quality", "Qty_Transit")
# ---------------------------------------------------------------------------------
# Filter - We keep only entries with value greater than 0
df_customers_stock_end = df_customers_stock_calc.filter(f.col("Customers_Stock") > 0)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr. 3 - Union Stock Tables
# MAGIC Union Table Stock(Mard) / Vendor Stock(mlsb) / Customers Stock(mssa) / Transit Stock

# COMMAND ----------

df_stock_table = (
    df_mard_end.unionByName(df_mslb_end, allowMissingColumns=True)
    .unionByName(df_transit_stock_end, allowMissingColumns=True)
    .unionByName(df_customers_stock_end, allowMissingColumns=True)
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr 3.1 - cast Columns
# MAGIC Description of transformation 2.1

# COMMAND ----------

# cast Column to double
columns_to_cast = [
    "Free_Stock",
    "Transfert_Stock",
    "Quality_Stock",
    "UnFree_Stock",
    "Block_Stock",
    "Return_Stock",
    "VMI",
    "Transit_Stock",
    "Customers_Stock",
    "Supplier_Stock",
]
df_stock_table_cast = df_stock_table.select(
    *[cast_to_double_sap_column(c) for c in columns_to_cast],
    *[c for c in df_stock_table.columns if c not in columns_to_cast]
)
# ---------------------------------------------------------------------------------
# Replace null value by 0
df_stock_table_cast = df_stock_table_cast.fillna(0, subset=columns_to_cast)
# ---------------------------------------------------------------------------------
# Remove lead 0 on Material Number
df_stock_table_end = df_stock_table_cast.withColumn(
    "Material_Number",
    f.regexp_replace(df_stock_table_cast.Material_Number, "^0+", ""),
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr 3.2 - Calcul sum of Stock on Hand by Material Number / Plant /Storage Location

# COMMAND ----------

df_stock_table_end = df_stock_table_end.withColumn(
    "Stock_On_Hand",
    reduce(
        lambda x, y: x + y,
        [df_stock_table_end[col] for col in columns_to_cast],
    ),
)
# Filter - We keep only entries with value greater than 0
df_stock_table_end = df_stock_table_end.filter(
    (f.col("Transit_Stock") != 0)
    | (f.col("Stock_On_Hand") != 0)
    | (f.col("VMI") != 0)
    | (f.col("Customers_Stock") != 0)
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tr 3.3 - Add date for history table

# COMMAND ----------

if PERIOD == "daily":
    df_history_stock_table = df_stock_table_end.withColumn(
        "Observation_Day", f.current_date()
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Checks

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Common Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold Stock On Hand by storage location
# MAGIC
# MAGIC Saving of Gold Stock On Hand table - This represents the enriched LATECOERE SAP ECC6 Stock on Hand.

# COMMAND ----------

if PERIOD == "daily":
    StockStorageLocationOutput = (
        f"{PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.stock_by_storage_location"
    )
    save_table(
        dest_table=StockStorageLocationOutput, df=df_stock_table_end, mode="overwrite"
    )
if PERIOD == "weekly":
    StockStorageLocationOutput = f"{PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.stock_by_storage_location_weekly"
    save_table(
        dest_table=StockStorageLocationOutput, df=df_stock_table_end, mode="overwrite"
    )
if PERIOD == "monthly":
    StockStorageLocationOutput = f"{PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.stock_by_storage_location_monthly"
    save_table(
        dest_table=StockStorageLocationOutput, df=df_stock_table_end, mode="overwrite"
    )


# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - Gold Stock On Hand by storage location daily history

# COMMAND ----------

if PERIOD == "daily":
    if not UnityCatalogCheckTableExists(StockStorageLocationDailyHistoryInputOutput):
        mode = "overwrite"
    else:
        mode = "append"

    save_table(
        dest_table=StockStorageLocationDailyHistoryInputOutput,
        df=df_history_stock_table,
        cluster_cols="Observation_Day",
        mode=mode
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
