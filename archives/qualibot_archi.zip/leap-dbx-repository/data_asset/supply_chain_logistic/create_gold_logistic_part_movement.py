# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold  & Gold Exposed table for part Movement List
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_gold.supply_chain_logistic.part_movement
# MAGIC   - {WRITE_ENV}_gold.supply_chain_logistic.part_movement_planif_exposed
# MAGIC
# MAGIC **Input :**  
# MAGIC   - {READ_ENV}_silver.supply_chain_logistic.part_movement
# MAGIC   
# MAGIC **Triggered by:**  
# MAGIC   - NoteBook Silver_Part_movement
# MAGIC
# MAGIC **Things to do:** 
# MAGIC
# MAGIC   - ...

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC # Extraction Tables 

# COMMAND ----------

df_database = spark.read.table(f"{READ_ENV}_silver.supply_chain_logistic.part_movement")

# COMMAND ----------

# MAGIC %md
# MAGIC #Add specific need from business
# MAGIC

# COMMAND ----------

# Nothing to do

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "supply_chain_logistic"
table = "part_movement"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_database,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold exposed table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "supply_chain_logistic"
table = "part_movement"
src_full_tablename = f"{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "MKPF"
Begin_By_2 = "MSEG"

selected_columns = [
    col
    for col in df_database.columns
    if not col.startswith(Begin_By) and not col.startswith(Begin_By_2)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
