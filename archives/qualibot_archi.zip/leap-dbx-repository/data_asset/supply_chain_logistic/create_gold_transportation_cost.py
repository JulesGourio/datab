# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table for transportation related cost (All cost related to transportations)
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.transportation_cost
# MAGIC
# MAGIC **Input :**  
# MAGIC   - {REFERENCE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_sap_exposed  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekbe_latest
# MAGIC
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC SCHEDULE 
# MAGIC
# MAGIC **Things performed in this Notebook:**  
# MAGIC -  get PO for transportation budget
# MAGIC -  get EKBE for transportation invoices
# MAGIC - Create consolidate dataAsset

# COMMAND ----------

# MAGIC %md
# MAGIC # Import

# COMMAND ----------

import pyspark.sql.functions as f

from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC # Widget

# COMMAND ----------

# Get read reference environment variable
dbutils.widgets.text("REFERENCE_READ_ENV", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("REFERENCE_READ_ENV")
# Get write environment variable
dbutils.widgets.text("PIPELINE_WRITE_ENV", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("PIPELINE_WRITE_ENV")
# Get read pipeline environment variable
dbutils.widgets.text("PIPELINE_READ_ENV", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("PIPELINE_READ_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Renaming dictionnary

# COMMAND ----------

ekbe_mapping_renaming = {
    "ebeln": "PO_number",
    "ebelp": "PO_item_number",
    "waers": "currency",
    "wrbtr": "price",
    "budat": "accountable_date",
    "belnr": "document_number_PO_doc",
}

# COMMAND ----------

# MAGIC %md
# MAGIC ## Uplaod Tables LEAP

# COMMAND ----------

# MAGIC %md
# MAGIC ### GOLD - Purchase Order

# COMMAND ----------

df_po = spark.read.table(f"{REFERENCE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_sap_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ### BRONZE - EKBE

# COMMAND ----------

df_ekbe = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ekbe_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1  - EKBE

# COMMAND ----------

df_purchasing_document_history = (
    df_ekbe.withColumnsRenamed(ekbe_mapping_renaming)
    .filter(f.col("document_number_PO_doc").startswith("6"))
    .select(*ekbe_mapping_renaming.values())
).withColumn("accountable_date", f.to_date(f.col("accountable_date"), "yyyyMMdd"))

df_purchasing_document_history_converted = table_utils.currency_conversion(
    df=df_purchasing_document_history,
    document_currency_column=df_purchasing_document_history.currency,
    rate_types=["Budget"],
    rate_dates=[df_purchasing_document_history.accountable_date],
    target_currency_value="EUR",
    document_amounts=[df_purchasing_document_history.price],
)
df_purchasing_document_history_converted = table_utils.remove_leading_zeros(
    df_purchasing_document_history_converted, ["PO_number","PO_item_number"]
)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 - Purchase Order

# COMMAND ----------

po_transport_related = [
    "0062480000",
    "0062410000",
    "0062411000",
    "0062420000",
    "0062421000",
    "0063581000",
]
po_transport_related_rp = ["0060800020", "0060800010"]

df_po_filtered = df_po.filter(
    (f.col("cost_element").isin(po_transport_related))
    | ((f.col("cost_element").isin(po_transport_related_rp)) & (f.col("plant_delivered") == "3000"))
).withColumnRenamed("net_order_price_per_price_base_in_EUR_budget", "budget_per_year")

df_po_converted = df_po_filtered.withColumns(
    {
        "process_description": f.when(
            f.size(f.split(f.col("PO_item_description"), r"\|\|")) > 2,
            f.split(f.col("PO_item_description"), r"\|\|")[0],
        ).otherwise(None),
        "departure_site": f.when(
            f.size(f.split(f.col("PO_item_description"), r"\|\|")) > 2,
            f.split(f.col("PO_item_description"), r"\|\|")[1],
        ).otherwise(None),
        "arrival_site": f.when(
            f.size(f.split(f.col("PO_item_description"), r"\|\|")) > 2,
            f.split(f.col("PO_item_description"), r"\|\|")[2],
        ).otherwise(None),
    }
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformation
# MAGIC

# COMMAND ----------

df_transportation_cost = df_po_converted.join(
    df_purchasing_document_history_converted,
    on=["PO_Number", "PO_Item_Number"],
    how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Save Table

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.transportation_cost",
    df=df_transportation_cost,
    mode="overwrite",
)
