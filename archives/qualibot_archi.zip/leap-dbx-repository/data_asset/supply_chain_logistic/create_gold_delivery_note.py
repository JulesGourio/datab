# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE GOLD DELIVERY NOTE SAP
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the gold table from the silver table of delivery note. Delivery note is a document issued by the supplier that lists detailed information about the articles sent.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Delivery note
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {PIPELINE_READ_ENV}_silver.supply_chain_logistic.delivery_note
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.delivery_note
# MAGIC - {PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.delivery_note_exposed
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Configuration

# COMMAND ----------

from leap_utils.data_asset import table_utils

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Input

# COMMAND ----------

df_delivery_note_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.supply_chain_logistic.delivery_note"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# NOTHING TO CHANGE HERE

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.delivery_note",
    df=df_delivery_note_silver,
    overwrite_schema=True,
    mode="overwrite",
)

# COMMAND ----------

begin_by_1 = "LIKP"
begin_by_2 = "LIPS"

selected_columns = [
    col
    for col in df_delivery_note_silver.columns
    if not col.startswith(begin_by_1) and not col.startswith(begin_by_2)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    f"{PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.delivery_note",
    f"{PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.delivery_note_exposed",
    select_statement,
    replace_view=True,
)
