# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # CREATE SILVER DELIVERY NOTE
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC The script creates the silver table on delivery note. Delivery note is a document issued by the supplier that lists detailed information about the articles sent.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC #N/A
# MAGIC
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Data asset - Delivery note - SAP
# MAGIC
# MAGIC **Input Tables**
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.likp_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.lips_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_likp
# MAGIC - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_lips
# MAGIC
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.supply_chain_logistic.delivery_note
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Imports

# COMMAND ----------

# LEAP FUNCTION
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - **df_likp_raw** is the bronze latest LIKP SAP table (SD Document: Delivery Header Data): LIKP is a key table in the Sales and Distribution (SD) module of SAP, which stores header information for delivery documents. Each record in LIKP corresponds to a single delivery, and this table contains high-level details such as delivery date, shipping point, and overall status of the delivery. The primary key of this table includes the delivery document number, and it is used to manage and track the delivery process from a holistic perspective.
# MAGIC - **df_lips_raw** is the bronze latest LIPS SAP table (SD document: Delivery: Item data): LIPS is another critical table in the SD module, storing detailed line item information for each delivery document found in LIKP. Each delivery document can have multiple line items, and LIPS holds data specific to these items, such as material number, quantity delivered, and individual item statuses. The primary key for LIPS includes both the delivery document number and the item number, ensuring that each line item within a delivery is uniquely identifiable.
# MAGIC - **df_likp_headers** is the header of the SAP table LIKP
# MAGIC - **df_lips_headers** is the header of the SAP table LIPS
# MAGIC

# COMMAND ----------

df_likp_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.likp_latest"
)
df_lips_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.lips_latest"
)

# COMMAND ----------

df_likp_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_likp"
)
df_lips_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_lips"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Inputs - Manual declaration

# COMMAND ----------

LIKP_PREFIX = "LIKP"
LIPS_PREFIX = "LIPS"

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Renaming & casting columns

# COMMAND ----------

df_likp_prep = table_utils.add_prefix_to_columns(df_likp_raw, LIKP_PREFIX)
df_lips_prep = table_utils.add_prefix_to_columns(df_lips_raw, LIPS_PREFIX)

table_utils.check_schema_of_the_header_file(df_likp_headers)
table_utils.check_schema_of_the_header_file(df_lips_headers)

df_likp_prep = table_utils.rename_columns_with_sap_business_header(
    df_likp_prep, df_likp_headers
)
df_lips_prep = table_utils.rename_columns_with_sap_business_header(
    df_lips_prep, df_lips_headers
)

df_likp_prep = table_utils.cast_columns_with_sap_business_headers(
    df_likp_prep, df_likp_headers
)
df_lips_prep = table_utils.cast_columns_with_sap_business_headers(
    df_lips_prep, df_lips_headers
)

df_likp_prep = table_utils.remove_leading_zeros(
    df=df_likp_prep, column_names=["delivery"]
)
df_lips_prep = table_utils.remove_leading_zeros(
    df=df_lips_prep, column_names=["delivery", "material_number", "profit_center"]
)

df_lips_prep = df_lips_prep.replace("000000", None, subset=["sales_document_item"])

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Join likp and lips tables on delivery

# COMMAND ----------

df_delivery_note_raw = df_lips_prep.join(df_likp_prep, on=["delivery"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_silver.supply_chain_logistic.delivery_note",
    df=df_delivery_note_raw,
    overwrite_schema=True,
    mode="overwrite",
)
