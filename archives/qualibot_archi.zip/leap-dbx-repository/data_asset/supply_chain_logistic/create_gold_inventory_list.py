# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Inventory List Silver to Gold
# MAGIC
# MAGIC
# MAGIC **Description:**
# MAGIC This notebook is dedicated to creating a refined Inventory List data asset in Databricks. The Inventory List contains all the items inventoried during the year.
# MAGIC
# MAGIC The focus is on performing quality checks on the dataset sourced from the silver layer, ensuring data integrity, consistency, and accuracy before transitioning it to the gold layer.
# MAGIC
# MAGIC Furter information on materials and plant is retreived by the join with the master_data **material_master_data_plant_exposed**.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - https://dbc-77b87d5a-6bcb.cloud.databricks.com/jobs/584376666133366?o=1210945332048776
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_silver.supply_chain_logistic.inventory_list
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_gold.supply_chain_logistic.inventory_list
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read reference environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")
# Get read pipeline environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Inventory List silver

# COMMAND ----------

df_inventory_list_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.supply_chain_logistic.inventory_list"
)

# Remove items with material_number == SPLIT (Management items)
df_inventory_list_silver = df_inventory_list_silver.filter(
    f.col("material_number") != "SPLIT"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Material Master Data Plant
# MAGIC
# MAGIC This dataset is used to retreive information regarding each Material and the Plant.
# MAGIC All the columns are named in Maiuscule, in order to standardize them, they are renamed with only lower cases.

# COMMAND ----------

df_data_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_master_data_plant_exposed"
)
cols = ["Material_Number", "Plant", "Profit_Center", "Description", "Material_Type"]
df_data_plant = df_data_plant.select(cols).drop_duplicates()
for i in cols:
    df_data_plant = df_data_plant.withColumnRenamed(i, i.lower())

df_data_plant = df_data_plant.withColumnRenamed("Description", "material_description")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join material_master_data_plant
# MAGIC
# MAGIC Join the dataset with **material_master_data_plant** on "material_number" and "plant", in order to obtain additional information on the material and the plant:
# MAGIC - profit_center,
# MAGIC - description,
# MAGIC - material_type

# COMMAND ----------

df_inventory_list = df_inventory_list_silver.join(
    df_data_plant, ["material_number", "plant"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Quality Checks
# MAGIC
# MAGIC **Data Type Check:**
# MAGIC
# MAGIC - date Columns: We checked that these columns are of the date type to ensure that date-related operations can be performed accurately.
# MAGIC - quantity Column: We checked that this column is of the double (floating-point) type to ensure precise numerical operations.
# MAGIC
# MAGIC
# MAGIC **Data Format Check:**
# MAGIC
# MAGIC - plant Column: We verified that the values in this column are exactly 4 digits long, ensuring consistency in plant codes.
# MAGIC
# MAGIC **Unicity Check**
# MAGIC

# COMMAND ----------

# Wrap the dataframe with the great expectations object, use persist=True just if it increases the speed of execution
dfgx = gx.dataset.SparkDFDataset(df_inventory_list, persist=False)

# Define the red quality checks here
red_quality_check_results = [
    dfgx.expect_column_values_to_be_of_type(column="posting_date", type_="DateType"),
    dfgx.expect_column_values_to_be_of_type(column="count_date", type_="DateType"),
    dfgx.expect_column_values_to_be_of_type(
        column="counted_quantity", type_="DoubleType"
    ),
    dfgx.expect_column_values_to_be_of_type(column="book_quantity", type_="DoubleType"),
    dfgx.expect_column_values_to_be_of_type(
        column="difference_amount", type_="DoubleType"
    ),
    dfgx.expect_column_value_lengths_to_equal(column="plant", value=4),
]

# Validate all red quality checks, if at least one fails the job stops
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level="RED",
    info_message="Quality Checks passed for Inventory Count table - RED",
    error_message="Quality checks failed for Inventory Count table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="inventory_list_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables inventory_list

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "supply_chain_logistic"
table = "inventory_list"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_inventory_list,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables inventory_list_exposed

# COMMAND ----------

select_exposed_statement = ", ".join(
    [
        col
        for col in df_inventory_list.columns
        if not (col.startswith("IKPF") or col.startswith("ISEG"))
    ]
)

table_utils.create_table_view(
    src_full_tablename=f"{catalog}.{domain}.{table}",
    dest_full_tablename=f"{catalog}.{domain}.{table}_exposed",
    select_statement=select_exposed_statement,
    replace_view=True,
)
