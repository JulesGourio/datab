# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Inventory List Bronze to Silver
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC In this notebook, we aim to create a data asset in Databricks to obtain the Inventory List.
# MAGIC
# MAGIC **Performed in this Notebook:**
# MAGIC - Cleaning data
# MAGIC - Renaming Headers
# MAGIC - Join inventory listing (**iseg**) with additional inventory information (**ikpf**)
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - https://dbc-77b87d5a-6bcb.cloud.databricks.com/jobs/584376666133366?o=1210945332048776
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ikpf_latest
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.iseg_latest
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.supply_chain_logistic.inventory_list
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports

# COMMAND ----------

from leap_utils.data_asset import table_utils

from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read reference environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")
# Get read pipeline environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import SAP ISEG
# MAGIC
# MAGIC For each Fiscal Year and each Physical_Inventory_Doc, materials and its respective quantity (counted and from the books) are listed:
# MAGIC - fiscal_year, phys_inventory_doc
# MAGIC - material_number, plant, storage_location
# MAGIC - book_quantity, counted_quantity,
# MAGIC - book_quantity_value, counted_quantity_value, currency
# MAGIC - count_date, posting_date

# COMMAND ----------

df_iseg_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.iseg_latest"
)
df_iseg_headers_sap = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze.headers_sap.headers_sap_business_iseg"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import SAP IKPF
# MAGIC
# MAGIC SAP dataset **ikfp** contains additional information regarding the inventory. Namely:
# MAGIC - fiscal_year, physical_inventory_doc (columns used to perform the join with **iseg**)
# MAGIC - physical_inventory_no

# COMMAND ----------

df_ikpf_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ikpf_latest"
)
df_ikpf_headers_sap = spark.read.table(
    f"{PIPELINE_READ_ENV}_bronze.headers_sap.headers_sap_business_ikpf"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation ISEG
# MAGIC
# MAGIC
# MAGIC Rename columns in agreement with sap_business_header.
# MAGIC Clean and format columns.

# COMMAND ----------

# Rename columns
df_iseg_prefix = table_utils.add_prefix_to_columns(df_iseg_headers, "ISEG")
table_utils.check_schema_of_the_header_file(df_iseg_headers_sap)
df_iseg_renamed = table_utils.rename_columns_with_sap_business_header(
    df_iseg_prefix, df_iseg_headers_sap
)
# Format columns
df_iseg_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_iseg_renamed, df_iseg_headers_sap
)
df_iseg_cleaned = table_utils.remove_leading_zeros(
    df=df_iseg_renamed, column_names=["material_number", "physical_inventory_doc"]
)
# Filter Data
df_iseg_prepared = df_iseg_cleaned

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation IKPF
# MAGIC
# MAGIC Rename columns in agreement with sap_business_header.
# MAGIC Clean and format columns.

# COMMAND ----------

# Rename columns
df_ikpf_prefix = table_utils.add_prefix_to_columns(df_ikpf_headers, "IKPF")
table_utils.check_schema_of_the_header_file(df_ikpf_headers_sap)
df_ikpf_renamed = table_utils.rename_columns_with_sap_business_header(
    df_ikpf_prefix, df_ikpf_headers_sap
)
# Format columns
df_ikpf_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_ikpf_renamed, df_ikpf_headers_sap
)
df_ikpf_cleaned = table_utils.remove_leading_zeros(
    df=df_ikpf_renamed, column_names=["physical_inventory_doc"]
)
# Filter Data
df_ikpf_prepared = df_ikpf_cleaned

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformation
# MAGIC
# MAGIC Join **ikpf** with **iseg** on "physical_inventory_doc" and "fiscal_year" in order to add additional information of the Inventory:

# COMMAND ----------

df_inventory_join = df_iseg_prepared.join(
    df_ikpf_prepared, on=["physical_inventory_doc", "fiscal_year"], how="left"
)

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Create boolean columns

# COMMAND ----------

df_inventory_list = (
    df_inventory_join.withColumn(
        "is_item_counted",
        f.when(f.col("item_counted").isNotNull(), True).otherwise(False),
    )
    .withColumn(
        "is_item_deleted",
        f.when(f.col("item_deleted").isNotNull(), True).otherwise(False),
    )
    .withColumn(
        "is_item_recounted",
        f.when(f.col("item_recounted").isNotNull(), True).otherwise(False),
    )
    .withColumn(
        "is_difference_posted",
        f.when(f.col("difference_posted").isNotNull(), True).otherwise(False),
    )
    .drop("item_counted", "item_deleted", "item_recounted", "difference_posted")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "supply_chain_logistic"
table = "inventory_list"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_inventory_list,
    mode="overwrite",
    overwrite_schema=True,
)
