# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purchasing Info Record - Bronze to silver
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC
# MAGIC This notebook processes SAP ECC6 purchasing info record data from raw bronze tables and enriches it for Silver layer usage.  
# MAGIC Key steps include:
# MAGIC - Rename column using SAP header
# MAGIC - Join table EINE and EINA on column INFNR
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eine_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_eine`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eina_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_eina`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{PIPELINE_WRITE_ENV}_silver.procurement_purchasing.purchasing_info_record_sap`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC
# MAGIC     1. primary_key column: It is now purchasing_info_record_id column, but we still keep the old column to reduce the risk of impacting downstream tables

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils 

# Logging imports 
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

#dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### EINE - Purchasing Info Record: Purchasing Organization Data
# MAGIC
# MAGIC Contains line-item level data of purchasing info record, including:
# MAGIC - Number of Purchasing info Record
# MAGIC - Purchasing Organization
# MAGIC - Plant
# MAGIC
# MAGIC Used as the core dataset to build the PIR records.
# MAGIC

# COMMAND ----------

df_eine = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eine_latest")
df_eine_header_sap = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_eine")

# COMMAND ----------

# MAGIC %md
# MAGIC ### EINA - Purchasing Info Record: Genaral Data
# MAGIC
# MAGIC Contains class object assignments for purchasing info record (e.g., material, supplier, characteristics values).
# MAGIC
# MAGIC Used to add class and characteristics in that class to the purchasing info record.

# COMMAND ----------

df_eina = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.eina_latest")
df_eina_header_sap = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_eina")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Initial cleanup and structuring of raw EINE/EINA datasets.
# MAGIC Includes:
# MAGIC - Prefixing technical columns
# MAGIC - Renaming columns using SAP header files
# MAGIC - Type casting of field

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation – EINE
# MAGIC Applies:
# MAGIC - Column prefixing
# MAGIC - Business-name-based renaming
# MAGIC - Format casting based on SAP header metadata

# COMMAND ----------

df_eine_header_prefix = table_utils.add_prefix_to_columns(df_eine, "EINE")
table_utils.check_schema_of_the_header_file(df_eine_header_sap)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_eine_header_prefix, df_eine_header_sap
)
df_eine_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_eine_header_sap
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation – EINA
# MAGIC
# MAGIC Applies:
# MAGIC - Transform float columns with minus sign at the end
# MAGIC - Column prefixing
# MAGIC - Business-name-based renaming
# MAGIC - Format casting based on SAP header metadata

# COMMAND ----------

list_float_columns = ["mahn1", "mahn2", "mahn3"]
for col in list_float_columns:
    df_eina = table_utils.transform_float_column(df_eina, col)
df_eina_header_prefix = table_utils.add_prefix_to_columns(df_eina, "EINA")
table_utils.check_schema_of_the_header_file(df_eina_header_sap)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_eina_header_prefix, df_eina_header_sap
)
df_eina_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_eina_header_sap
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##  Transformation 1 – Enrich PIRs with General information
# MAGIC
# MAGIC Joins PIR data with:
# MAGIC - Purchasing info Record: General data (EINE)
# MAGIC
# MAGIC Result: A unified view of the PIR line.

# COMMAND ----------

df_pir_joined = df_eine_header_renamed.join(
    df_eina_header_renamed,
    ["number_of_purchasing_info_record"],
    "left"  
)
df_pir_joined = df_pir_joined.withColumn(
    "minimum_purchase_order_quantity_in_stock_unit",
    f.col("minimum_purchase_order_quantity")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

#create primary key
df_w_pk = df_pir_joined.withColumn(
    "purchasing_info_record_id",
    f.concat_ws(
        "-",
        f.col("number_of_purchasing_info_record"),
        f.col("purchasing_organization"),
        f.col("purchasing_info_record_category"),
        f.col("plant")
    )
).withColumn(
    "primary_key",
    f.col("purchasing_info_record_id")
)

pk_col = "purchasing_info_record_id"
# reorder columns list to have  PK in first
columns = df_w_pk.columns
columns.remove(pk_col)
new_column_order = [pk_col] + columns
df_w_pk = df_w_pk.select(new_column_order)

df_to_check = df_w_pk
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=pk_col),
    df_gx.expect_column_values_to_be_unique(column=pk_col),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {pk_col}(s) are unique and not null",
    error_message="Quality checks failed for PIR silver table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="purchasing_info_record_sap",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "procurement_purchasing"
DESTINATION_TABLE = "purchasing_info_record_sap"

DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"
# Adding constraint primary key in DBX
# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "purchasing_info_record_sap_PK"  
TABLE_PK_COLS = "purchasing_info_record_id"


spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_w_pk,
    mode="overwrite",
    overwrite_schema=True,
)

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
