# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purchasing Info Record – Final Gold Layer Transformation
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC
# MAGIC This notebook transforms SAP ECC6 purchasing info record (PIR) data into a final Gold Layer dataset used for reporting and analytics.  
# MAGIC It enriches the PIR data with:
# MAGIC - Enrich it with supplier additional information (supplier name and supplier label) based on supplier code.
# MAGIC - Enrich it with material information (material description) based on material_number.
# MAGIC - Calculate a minimum order quantity
# MAGIC
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC
# MAGIC - Logic to calculate minimum order quantity stock unit based on purchase order quantity
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{PIPELINE_READ_ENV}_silver.procurement_purchasing.purchasing_info_record_sap`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{REFERENCE_READ_ENV}_gold.master_data.material_exposed`
# MAGIC - `{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.procurement_purchasing.purchasing_info_record_sap`
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.procurement_purchasing.purchasing_info_record_sap_exposed`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils 

# Logging imports 
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

#dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Purchase Request – Silver Layer
# MAGIC
# MAGIC This is the processed PIR dataset from the Silver layer, already structured from raw EINE/EINA sources.
# MAGIC Used as the base for enrichment and final Gold formatting.

# COMMAND ----------

df_silver = spark.read.table(f"{PIPELINE_READ_ENV}_silver.procurement_purchasing.purchasing_info_record_sap")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Material Master Data
# MAGIC
# MAGIC Provides enriched material-level attributes such as: 
# MAGIC - Material Description
# MAGIC
# MAGIC Used to enhance the purchasing info record dataset with product metadata.

# COMMAND ----------

df_mat = spark.read.table(f"{REFERENCE_READ_ENV}_gold.master_data.material_exposed").select(
    "material_number",
    "material_description",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Supplier Master Data
# MAGIC
# MAGIC Provides vendor-level attributes like:
# MAGIC - Supplier Name
# MAGIC
# MAGIC Used to contextualize supplier behavior and classification.

# COMMAND ----------

df_supplier = spark.read.table(f"{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed").select(
    "supplier_code",
    "supplier_name",
).drop_duplicates()


# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 – Supplier Label creation
# MAGIC
# MAGIC This step joins create supplier_label information in the Supplier Master Data from:
# MAGIC - Supplier Code
# MAGIC - Supplier Name

# COMMAND ----------

df_supplier = df_supplier.withColumn(
    "supplier_label",
    f.concat_ws(
        ": ",
        f.col("supplier_code"),
        f.col("supplier_name"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 – Supplier and Material Information
# MAGIC
# MAGIC This step joins the PO dataset with supplier and material master data to enrich the purchasing information with:
# MAGIC - Supplier name
# MAGIC - Material description

# COMMAND ----------

# remove leading zero of material_number
df_silver_zeros = table_utils.remove_leading_zeros(df_silver, ["material_number"])

df_pir_w_supplier = df_silver_zeros.join(
    df_supplier,
    ["supplier_code"],
    "left",
).join(
    df_mat,
    ["material_number"],
    "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 – Calculate minimum order quantity
# MAGIC
# MAGIC Calculate minimum order in stock unit:
# MAGIC - From minimum purchase order quantity to stock unit using conversion
# MAGIC - Coalesce with mininum purchase order quantity for cases without conversion or conversion = 0

# COMMAND ----------

df_pir_w_stock_unit = df_pir_w_supplier.withColumn(
    "minimum_purchase_order_quantity_in_stock_unit",
    f.coalesce(
        (
            (
                f.col("numerator_for_conversion_of_order_unit_to_base_unit") /
                f.col("denominator_for_conversion_of_order_unit_to_base_unit")
            ) * f.col("minimum_purchase_order_quantity")
        ),
        f.col("minimum_purchase_order_quantity")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_to_check = df_pir_w_stock_unit
col_pk = "purchasing_info_record_id"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for BOM table, please check log messages",
)

columns = df_pir_w_stock_unit.columns
columns.remove(col_pk)
new_column_order = [col_pk] + columns
df_pir_w_stock_unit = df_pir_w_stock_unit.select(new_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – LEAP Table (Gold Layer)
# MAGIC
# MAGIC This section writes the fully transformed purchase order dataset to the LEAP Gold Layer using a robust overwrite method.
# MAGIC
# MAGIC Target:
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.procurement_purchasing.purchasing_info_record`

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "procurement_purchasing"
table = "purchasing_info_record_sap"

DESTINATION_TABLE_FULL_PATH = f"{catalog}.{domain}.{table}"
DESTINATION_TABLE = table
TABLE_CONSTRAINT_NAME = "purchasing_info_record_PK"
TABLE_PK_COLS = col_pk

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_pir_w_stock_unit,
    mode="overwrite",
    overwrite_schema=True
) 


# COMMAND ----------

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{catalog}' and table_SCHEMA='{domain}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – Exposed Table View
# MAGIC
# MAGIC Creates a filtered view excluding low-level technical columns (EINE, EINA, etc.) for analytics or dashboard exposure.
# MAGIC
# MAGIC Target:
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.procurement_purchasing.purchasing_info_record_exposed`

# COMMAND ----------

src_full_tablename = f"{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = ["EINE", "EINA"]

selected_columns = [
    col for col in df_pir_w_stock_unit.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

log.info(f"The table view {dest_full_tablename} has been successfully created")
