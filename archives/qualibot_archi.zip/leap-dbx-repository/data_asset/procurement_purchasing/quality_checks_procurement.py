# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to process quality checks on procurement tables.
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - {PIPELINE_WRITE_ENV}_bronze.data_quality.quality_event_table
# MAGIC
# MAGIC **Inputs:**
# MAGIC   - {PIPELINE_READ_ENV}_gold.procurement.payment_term
# MAGIC   - {PIPELINE_READ_ENV}_gold.procurement.purchasing_info_record_sap
# MAGIC   - {PIPELINE_READ_ENV}_gold.procurement.purchasing_source_list
# MAGIC   - To be continued : see dictionary
# MAGIC
# MAGIC **Used by:**
# MAGIC procurement pipeline

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f
import great_expectations as gx
import logging

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config LEAP Function Imports

# COMMAND ----------

from leap_utils.common.validation import gx_validation, quality_checks
from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.dropdown(
    "skip_quality_checks",
    defaultValue="False",
    choices=["True", "False"]
)
SKIP_QUALITY_CHECKS = dbutils.widgets.get("skip_quality_checks") == "True"

# COMMAND ----------

# MAGIC %md
# MAGIC ### log_level Str
# MAGIC
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.dropdown(
    "log_level",
    defaultValue="info",
    choices=["debug", "info", "warning", "error", "critical"],
)
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = setup_applevel_logger(
    log_level=LOG_LEVEL,
    file_log_level=LOG_LEVEL,
    log_format="%(asctime)s - %(name)s - %(levelname)s - %(funcName)s - %(message)s",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Tables to check

# COMMAND ----------

tables_info = {
    "procurement_gold_payment_term": {
        "table_name": f"{PIPELINE_READ_ENV}_gold.procurement.payment_term",
        "primary_key": ["payment_term_id"]
    },
    "procurement_silver_payment_term": {
        "table_name": f"{PIPELINE_READ_ENV}_silver.procurement.payment_term",
        "primary_key": ["payment_term_id"]
    },
    "procurement_gold_purchasing_source_list": {
        "table_name": f"{PIPELINE_READ_ENV}_gold.procurement.purchasing_source_list",
        "primary_key": ["purchasing_source_list_id"]
    },
    "procurement_silver_purchasing_source_list": {
        "table_name": f"{PIPELINE_READ_ENV}_silver.procurement.purchasing_source_list",
        "primary_key": ["purchasing_source_list_id"]
    },
    "procurement_gold_purchasing_info_record_sap": {
        "table_name": f"{PIPELINE_READ_ENV}_gold.procurement.purchasing_info_record_sap",
        "primary_key": ["primary_key"]
    },
    "procurement_silver_purchasing_info_record_sap": {
        "table_name": f"{PIPELINE_READ_ENV}_silver.procurement.purchasing_info_record_sap",
        "primary_key": ["primary_key"]
    },
    "procurement_purchasing_gold_purchasing_contract": {
        "table_name": f"{PIPELINE_READ_ENV}_gold.procurement_purchasing.purchasing_contract",
        "primary_key": ["purchasing_contract_id"]
    },
    "procurement_commodity_forecast_reliability_rate": {
        "table_name": f"{PIPELINE_READ_ENV}_proj.procurement_commodity_forecast.reliability_rate",
        "primary_key": ["profit_center"]
    },
    "procurement_commodity_forecast_demand_rate": {
        "table_name": f"{PIPELINE_READ_ENV}_proj.procurement_commodity_forecast.demand_rate",
        "primary_key": ["profit_center"]
    },
    "procurement_exceptions_purchase_requests_exception": {
        "table_name": f"{PIPELINE_READ_ENV}_proj.procurement_exceptions.purchase_requests_exception",
        "primary_key": ["PR_item"]
    },
    "procurement_exceptions_exceptions_by_po": {
        "table_name": f"{PIPELINE_READ_ENV}_proj.procurement_exceptions.exceptions_by_po",
        "primary_key": ["po_item_pk"]
    },
    "procurement_insights_payment_terms_insights": {
        "table_name": f"{PIPELINE_READ_ENV}_proj.procurement_insights.payment_terms_insights",
        "primary_key": ["payment_term_id"]
    },
    "procurement_insights_po_contract_payment_term_exceptions": {
        "table_name": f"{PIPELINE_READ_ENV}_proj.procurement_insights.po_contract_payment_term_exceptions",
        "primary_key": ["exception_payment_term_id"]
    },
    "procurement_insights_po_contract_payment_term_exceptions_agg": {
        "table_name": f"{PIPELINE_READ_ENV}_proj.procurement_insights.po_contract_payment_term_exceptions_agg",
        "primary_key": ["payment_term_exceptions_aggregated_id"]
    },
    "procurement_insights_po_contract_payment_term_insights": {
        "table_name": f"{PIPELINE_READ_ENV}_proj.procurement_insights.po_contract_payment_term_insights",
        "primary_key": ["primary_key"]
    },
    "procurement_material_refererence_and_benchmark_prices_procurement_material_plant_budget_tool": {
        "table_name": f"{PIPELINE_READ_ENV}_proj.procurement_material_refererence_and_benchmark_prices.procurement_material_plant_budget_tool",
        "primary_key": ["budget_tool_id"]
    },
}

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# Done further down in Prep 2

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - check primary key constraint in catalog
# MAGIC

# COMMAND ----------

# Catch all PRIMARY KEY from UC
primary_key_df = spark.sql("""
    SELECT tc.table_catalog, tc.table_schema, tc.table_name, ccu.column_name, ccu.constraint_name
    FROM system.information_schema.table_constraints AS tc
    JOIN system.information_schema.constraint_column_usage AS ccu
    ON tc.table_catalog = ccu.table_catalog
    AND tc.table_schema = ccu.table_schema
    AND tc.table_name = ccu.table_name
    AND tc.constraint_catalog = ccu.constraint_catalog
    AND tc.constraint_schema = ccu.constraint_schema
    AND tc.constraint_name = ccu.constraint_name
    WHERE tc.constraint_type = 'PRIMARY KEY'
""")

# Aggregation by table
primary_key_mapping = (
    primary_key_df.groupBy("table_catalog", "table_schema", "table_name","constraint_name")
    .agg(f.collect_set("column_name").alias("pk_columns"))
    .collect()
)

# Dict : {table_name: {"constraint_name": ..., "pk_columns": set(...) }}
pk_constraints = {
    f"{row.table_catalog}.{row.table_schema}.{row.table_name}": {
        "constraint_name": row.constraint_name,
        "pk_columns": set(row.pk_columns),
    }
    for row in primary_key_mapping
}

# Verification and add constraint_name
for table_key, info in tables_info.items():
    table_name = info["table_name"]
    expected_pk = set(info["primary_key"])

    pk_info = pk_constraints.get(table_name)

    found_pk = pk_info["pk_columns"] if pk_info else set()
    constraint_name = pk_info["constraint_name"] if pk_info else None

    info["catalog_primary_key"] = constraint_name if expected_pk.issubset(found_pk) else None

result_primary_key = {
    info["table_name"]: info["catalog_primary_key"] is not None
    for info in tables_info.values()
}

raw_result_primary_key = {
    info["table_name"]:
    {
        "success": info["catalog_primary_key"] is not None,
        "expectation_type": "check_table_primary_key",
        "table_name": info["table_name"],
        "expected_pk_columns": info["primary_key"],
        "catalog_primary_key": info["catalog_primary_key"] or "MISSING PRIMARY KEY",
    }
    for info in tables_info.values()
}

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 2 - read input tables

# COMMAND ----------

# Read tables
tables_to_check_dict = {}
tables_missing = {}
for table_key, info in tables_info.items():
    if table_utils.UnityCatalogCheckTableExists(info["table_name"]):
        df = spark.read.table(info["table_name"])
        tables_to_check_dict[table_key] = {**info, "dataframe": df}
        log.info(f"✅ Table {info['table_name']} will be checked")
    else:
        tables_missing[table_key] = {**info, "dataframe": None}
        log.error(f"❌ Table {info['table_name']} does not exist")

# COMMAND ----------

# Debug
if LOG_LEVEL == logging.DEBUG:
    for table_key, info in tables_to_check_dict.items():
        log.debug(f"Table {info["table_name"]}:")
        display(
            tables_to_check_dict[table_key]["dataframe"]
            .select(tables_to_check_dict[table_key]["primary_key"])
        )

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 3 - gx dataframes

# COMMAND ----------

# Read tables
for table_key, info in tables_to_check_dict.items():
    df = info["dataframe"]
    dfgx = gx.dataset.SparkDFDataset(df, persist=False)
    info["gx_dataframe"] = dfgx

# Updated dict
tables_to_check_dict_with_gx = tables_to_check_dict

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Quality Checks

# COMMAND ----------

# MAGIC %md
# MAGIC ##Data quality checks 1 - check primary key constraint in catalog
# MAGIC

# COMMAND ----------

# Quality check validation and logging

validation_level = "AMBER"

quality_checks.validate_and_log_quality_check_results(
    results_dict=result_primary_key,
    validation_level=validation_level,
    info_message=f"All tables with {validation_level} validation are complete, primary key exist in catalog",
    error_message="Tables are not all complete, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    expectation_type="check_table_primary_key",
    log_to_event_table=True,
    log_successes=True,
    raw_result=raw_result_primary_key,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Data quality checks 2 - check primary key unicity
# MAGIC

# COMMAND ----------

# Define the red quality checks here

validation_level = "AMBER" if SKIP_QUALITY_CHECKS else "RED"

red_quality_check_results = []

for table_key, info in tables_to_check_dict_with_gx.items():
    dfgx = info["gx_dataframe"]
    primary_keys = info["primary_key"]

    if len(primary_keys) == 1:
        # Simple primary key
        pk_col = primary_keys[0]
        red_quality_check_results.append(dfgx.expect_column_values_to_be_unique(column=pk_col, meta={"table_path": info["table_name"]}))
    else:
        # Composite primary key
        red_quality_check_results.append(dfgx.expect_compound_columns_to_be_unique(column_list=primary_keys, meta={"table_path": info["table_name"]}))

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"Quality Checks passed for tables - All Primary Keys are unique - RED",
    error_message=f"Quality checks failed for tables - Some Primary Keys are not unique, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="procurement_table_xxx", # will be overriden by the table name because of : meta={"table_path": info["table_name"]}
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# For missing tables, log a failed quality check
validation_level = "AMBER" if SKIP_QUALITY_CHECKS else "RED"

result_primary_key = {
    info["table_name"]: False
    for info in tables_missing.values()
}

raw_result_primary_key = {
    info["table_name"]:
    {
        "success": False,
        "expectation_type": "expect_column_values_to_be_unique",
        "table_name": info["table_name"],
        "expected_unique_columns": info["primary_key"],
        "result": f"MISSING TABLE {info['table_name']}",
    }
    for info in tables_missing.values()
}

quality_checks.validate_and_log_quality_check_results(
    results_dict=result_primary_key,
    validation_level=validation_level,
    info_message=f"All tables with {validation_level} validation are complete, primary key exist in catalog",
    error_message="Tables are not all complete, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    expectation_type="expect_column_values_to_be_unique",
    log_to_event_table=True,
    log_successes=True,
    raw_result=raw_result_primary_key,
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Outputs

# COMMAND ----------

if LOG_LEVEL == logging.DEBUG:
    spark.sql(f"select * from {PIPELINE_WRITE_ENV}_bronze.data_quality.quality_event_table order by event_timestamp desc limit 100").display()
