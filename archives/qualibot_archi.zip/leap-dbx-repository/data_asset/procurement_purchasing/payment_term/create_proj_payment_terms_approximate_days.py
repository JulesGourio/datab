# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Project Payment Terms Approximate days
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create the project table for Payment term.
# MAGIC
# MAGIC **Input :** 
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest`
# MAGIC   - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052u_latest`
# MAGIC   - `{REFERENCE_READ_ENV}_proj.procurement_insights.manual_input_payment_terms_approximate_days`
# MAGIC   
# MAGIC **Output table(s):**  
# MAGIC   - `{PIPELINE_WRITE_ENV}_proj.procurement_insights.payment_terms_insights`

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC - **gx_validation** required for quality checks - **need "great-expectations" installed on the cluster**
# MAGIC - **logger** for inline logging
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils

from leap_utils.common import logger
import great_expectations as gx
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

#dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Payment Term – Bronze Layer
# MAGIC
# MAGIC This is the processed Payment term dataset from raw T052 & T052u sources.
# MAGIC Used as the base for enrichment and final Project formatting.

# COMMAND ----------

df_t052_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest")
df_t052u_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052u_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Payment Term Approximate days
# MAGIC
# MAGIC Provides enriched payment terms attribute: approximate payment days.
# MAGIC Used to enhance the payment term dataset with `approximate_net_payment_days`.

# COMMAND ----------

# change to prod later
df_proxy_days = spark.read.table(f"{REFERENCE_READ_ENV}_proj.procurement_insights.manual_input_payment_terms_approximate_days")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 – Cleanup manual input payment_terms_apporximate_days
# MAGIC
# MAGIC This step cleanup the payment term approximate days:
# MAGIC - Reference data mapping to payment terms approximate days
# MAGIC - Create key to join with payment terms

# COMMAND ----------

df_proxy_days_w_key = df_proxy_days.withColumn(
    "payment_term_id",
    f.concat_ws(
        "-",
        f.col("terms_of_payment_key_ZTERM"),
        f.col("day_limit_ZTAGG")
    )   
)

df_proxy_days_w_key = df_proxy_days_w_key.select(
    "payment_term_id",
    "approximate_net_payment_days"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2 – Payment term select, rename & approximate days
# MAGIC
# MAGIC This step joins the payment term dataset with payment term apporximate days to enrich the `approximate_net_payment_days`.

# COMMAND ----------

# Collect payment term explanation
df_t052u_raw = df_t052u_raw.filter(
    f.col("spras") == "E"
).select(
    f.col("zterm"),
    f.col("ztagg"),
    f.col("text1").alias("payment_term_explanation")
).withColumn(
    "payment_term_id",
    f.concat_ws("-", f.col("zterm"), f.col("ztagg"))    
  ).drop("zterm", "ztagg")

# COMMAND ----------

# Rename payment term columns and complete with payment term explanation
df_t052_raw = df_t052_raw.select(
  f.col("zterm").alias("payment_term_key"),
  f.col("ztagg").alias("payment_term_day_of_month_threshold")
).withColumn(
    "payment_term_id",
    f.concat_ws("-", f.col("payment_term_key"), f.col("payment_term_day_of_month_threshold"))
).join(
    df_t052u_raw,
    ["payment_term_id"],
    "left",
)

# COMMAND ----------

# Join with main table
df_w_proxy_days = df_t052_raw.join(
    df_proxy_days_w_key,
    on="payment_term_id",
    how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

# check primary key
df_to_check = df_w_proxy_days
col_pk = "payment_term_id"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = gx.dataset.SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for payment term project table, please check log messages",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Output

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Project Tables

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_proj"
domain = "procurement_insights"
table = "payment_terms_approximate_days"

DESTINATION_TABLE_FULL_PATH = f"{catalog}.{domain}.{table}"
TABLE_CONSTRAINT_NAME = "payment_terms_approximate_days_PK"
TABLE_PK_COLS = col_pk

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_w_proxy_days,
    mode="overwrite",
    overwrite_schema=True
)


# COMMAND ----------

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{catalog}' and table_SCHEMA='{domain}' and table_name='{table}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
