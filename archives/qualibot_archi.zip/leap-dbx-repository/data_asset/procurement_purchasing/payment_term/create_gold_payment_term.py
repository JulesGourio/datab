# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Payment term - Silver to Final Gold Layer Transformation
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC
# MAGIC This notebook transforms SAP ECC6 payment term data into a final Gold Layer dataset used for reporting and analytics.  
# MAGIC It enriches the payment term data with the description of term of payment. 
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC
# MAGIC - Enrich with English description of term of payment.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Name of pipeline(s) the script was built for.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{PIPELINE_READ_ENV}_silver.procurement_purchasing.payment_term`
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052u_latest`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.procurement_purchasing.payment_term`
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.procurement_purchasing.payment_term_exposed`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

import pyspark.sql.functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC
# MAGIC Example:
# MAGIC - **Create_corrected_amounts** required for currency correction of SAP currencies with 3 digits
# MAGIC - **gx_validation** required for quality checks - **need "great-expectations" installed on the cluster**
# MAGIC - **logger** for inline logging
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils

from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

#dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Payment Term – Silver Layer
# MAGIC
# MAGIC This is the processed Payment term dataset from the Silver layer, already structured from raw T052 sources.
# MAGIC Used as the base for enrichment and final Gold formatting.

# COMMAND ----------

df_silver = spark.read.table(f"{PIPELINE_READ_ENV}_silver.procurement_purchasing.payment_term")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Own Explanations for Terms of Payment Data
# MAGIC
# MAGIC Provides enriched payment terms description attributes such as:
# MAGIC - Language Key
# MAGIC - Own explanation of term of payment
# MAGIC
# MAGIC Used to enhance the payment term dataset with description.

# COMMAND ----------

df_explanation = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052u_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 – Filter and cleanup raw T052U dataset
# MAGIC
# MAGIC This step filter and cleanup the payment term explanation:
# MAGIC - Filter for English description
# MAGIC - Reference data mapping to payment terms
# MAGIC - Create key to join with payment terms

# COMMAND ----------

df_explanation_cleaned = df_explanation.filter(
    f.col("spras") == "E"
).select(
    f.col("zterm"),
    f.col("ztagg"),
    f.col("text1").alias("payment_term_explanation")
)

df_explanation_cleaned = df_explanation_cleaned.withColumn(
    "payment_term_id",
    f.concat_ws("-", f.col("zterm"), f.col("ztagg"))    
).drop("zterm", "ztagg")


# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 1 – Payment term Explanation
# MAGIC
# MAGIC This step joins the payment term dataset with payment term explanation data to enrich the explanation of term of payment.

# COMMAND ----------

df_pt_w_explanation = df_silver.join(
    df_explanation_cleaned,
    ["payment_term_id"],
    "left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation 2 – Concatenate explanation of term of payment
# MAGIC
# MAGIC Concatenate `payment_term_explanation` from `payment_term_key` and `payment_term_explanation`.

# COMMAND ----------

df_pt_w_explanation = df_pt_w_explanation.withColumn(
    "payment_term_explanation",
    f.concat_ws(
        ": ",
        f.col("payment_term_key"),
        f.col("payment_term_explanation")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_to_check = df_pt_w_explanation
col_pk = "payment_term_id"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for payment_term table, please check log messages",
)

columns = df_pt_w_explanation.columns
columns.remove(col_pk)
new_column_order = [col_pk] + columns
df_pt_w_explanation = df_pt_w_explanation.select(new_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – LEAP Table (Gold Layer)
# MAGIC
# MAGIC This section writes the fully transformed purchase order dataset to the LEAP Gold Layer using a robust overwrite method.
# MAGIC
# MAGIC Target:
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.procurement_purchasing.payment_term`

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "procurement_purchasing"
table = "payment_term"

DESTINATION_TABLE_FULL_PATH = f"{catalog}.{domain}.{table}"
DESTINATION_TABLE = table
TABLE_CONSTRAINT_NAME = "payment_term_id"
TABLE_PK_COLS = col_pk

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_pt_w_explanation,
    mode="overwrite",
    overwrite_schema=True
) 


# COMMAND ----------

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{catalog}' and table_SCHEMA='{domain}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output – Exposed Table View
# MAGIC
# MAGIC Creates a filtered view excluding low-level technical columns (T052, etc.) for analytics or dashboard exposure.
# MAGIC
# MAGIC Target:
# MAGIC - `{PIPELINE_WRITE_ENV}_gold.procurement_purchasing.payment_term_exposed`

# COMMAND ----------

src_full_tablename = f"{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = ["T052"]

selected_columns = [
    col for col in df_pt_w_explanation.columns
    if not any(col.startswith(prefix) for prefix in Begin_By)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

log.info(f"The table view {dest_full_tablename} has been successfully created")
