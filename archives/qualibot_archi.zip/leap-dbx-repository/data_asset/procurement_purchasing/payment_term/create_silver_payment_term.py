# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Payment term - Bronze to silver
# MAGIC
# MAGIC
# MAGIC **Description:**  
# MAGIC
# MAGIC This notebook processes SAP ECC6 payment term data from raw bronze tables and enriches it for Silver layer usage.  
# MAGIC Key steps include:
# MAGIC - Renaming and formatting T052 data.
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - Name of pipeline(s) the script was built for.
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - `{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest`
# MAGIC - `{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_t052`
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - `{PIPELINE_WRITE_ENV}_silver.procurement_purchasing.payment_term`
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC

# COMMAND ----------

from leap_utils.data_asset import table_utils

# Logging imports 
from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

#dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### T052 – Terms of Payment
# MAGIC
# MAGIC Contains terms of payment information, including:
# MAGIC - Payment key
# MAGIC - Day limit
# MAGIC
# MAGIC Used as the core dataset to build the Payment term dataset.

# COMMAND ----------

df_t052 = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t052_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Headers SAP Business - T052

# COMMAND ----------

df_t052_header_sap = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_t052")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Initial cleanup and structuring of raw T052 datasets.
# MAGIC Includes:
# MAGIC - Prefixing technical columns
# MAGIC - Renaming columns using SAP header files
# MAGIC - Type casting of field

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Preparation – T052
# MAGIC
# MAGIC Applies:
# MAGIC - Column prefixing
# MAGIC - Business-name-based renaming
# MAGIC - Format casting based on SAP header metadata

# COMMAND ----------

df_t052_header_prefix = table_utils.add_prefix_to_columns(df_t052, "T052")
table_utils.check_schema_of_the_header_file(df_t052_header_sap)
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_t052_header_prefix, df_t052_header_sap
)
df_t052_header_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_t052_header_sap
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

#create primary key
df_w_pk = df_t052_header_renamed.withColumn(
    "payment_term_id",
    f.concat_ws("-", f.col("payment_term_key"), f.col("payment_term_day_of_month_threshold"))
)

df_to_check = df_w_pk
col_pk = "payment_term_id"

columns = df_w_pk.columns
columns.remove(col_pk)
new_column_order = [col_pk] + columns
df_w_pk = df_w_pk.select(new_column_order)

validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for BOM table, please check log messages",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "procurement_purchasing"
table = "payment_term"


DESTINATION_TABLE_FULL_PATH = f"{catalog}.{domain}.{table}"
TABLE_CONSTRAINT_NAME = "silver_payment_term_PK"
TABLE_PK_COLS = col_pk

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=DESTINATION_TABLE_FULL_PATH,
    df=df_w_pk,
    mode="overwrite",
    overwrite_schema=True,
)
 

# COMMAND ----------

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{catalog}' and table_SCHEMA='{domain}' and table_name='{table}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
