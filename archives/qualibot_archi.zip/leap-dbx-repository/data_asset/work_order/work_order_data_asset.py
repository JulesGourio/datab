# Databricks notebook source
# %% Imports
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.removeAll()

dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Constants
WO_BULG_TEST = "000003504615"

WORK_ORDER_DATABASE = f"{WRITE_ENV}_gold.supply_chain_production"
WORK_ORDER_GOLD_TABLE = f"{WORK_ORDER_DATABASE}.work_order_latest"

# COMMAND ----------

# %% Functions


def get_latest_extraction_sap_table_using_history(sap_tablename: str, debug=DEBUG):
    df_sap_history = spark.read.table(f"prod_bronze.sap_latecoere_ecc6.{sap_tablename}_stack")

    df_history_latest_extraction_timestamp = df_sap_history.select(
        f.max("extraction_timestamp")
    ).collect()[0][0]

    if debug:
        print(
            f"Latest extraction timestamp for {sap_tablename}: {df_history_latest_extraction_timestamp}"
        )

    df_latest = df_sap_history.where(
        f.col("extraction_timestamp") == df_history_latest_extraction_timestamp
    )

    sap_tablename_no_domain = sap_tablename[3:]

    df_latest = table_utils.add_prefix_to_columns(df_latest, sap_tablename_no_domain)

    return df_latest


def debug_table(df_table, debug=DEBUG):
    """TODO remove, for debug purpose only"""
    import inspect

    def retrieve_name(var):
        callers_local_vars = inspect.currentframe().f_back.f_back.f_locals.items()
        return [var_name for var_name, var_val in callers_local_vars if var_val is var]

    caller_table_name = retrieve_name(df_table)
    print(f"debugging table {caller_table_name}")

    if debug:
        print(f"{caller_table_name}.columns={df_table.columns}")

    aufnr_list = list(filter(lambda col_name: "_aufnr" in col_name, df_table.columns))

    if debug:
        print(f"{aufnr_list=}")

    first_aufnr_column_name = aufnr_list[0]

    df_table.where(f.col(first_aufnr_column_name) == WO_BULG_TEST).show()


# COMMAND ----------

# %% Latest AFKO
df_afko = get_latest_extraction_sap_table_using_history("afko")

if DEBUG:
    debug_table(df_afko)

# COMMAND ----------

# %% Latest AUFK
df_aufk = get_latest_extraction_sap_table_using_history("aufk")

if DEBUG:
    debug_table(df_aufk)

# COMMAND ----------

# %% Filter AUFK to keep only work orders (AUFK_autyp equals to "10")
df_aufk_work_orders = df_aufk.where(f.col("aufk_autyp") == "10")

if DEBUG:
    debug_table(df_aufk_work_orders)

# COMMAND ----------

# %% Join AFKO and AUFK
df_afko_aufk = df_afko.join(
    df_aufk_work_orders,
    on=[
        f.col("afko_mandt") == f.col("aufk_mandt"),
        f.col("afko_aufnr") == f.col("aufk_aufnr"),
    ],
    how="left",
)

if DEBUG:
    debug_table(df_afko_aufk)

# COMMAND ----------

# %% Latest AFPO
df_afpo = get_latest_extraction_sap_table_using_history("afpo")

if DEBUG:
    debug_table(df_afpo)

# COMMAND ----------

# %% Join AFKO-AUFK on AFPO
df_afko_aufk_afpo = df_afko_aufk.join(
    df_afpo,
    on=[
        f.col("afko_mandt") == f.col("afpo_mandt"),
        f.col("afko_aufnr") == f.col("afpo_aufnr"),
    ],
    how="left",
)

if DEBUG:
    debug_table(df_afko_aufk_afpo)

# COMMAND ----------

# %% Latest MAKT
df_makt = get_latest_extraction_sap_table_using_history("makt")

if DEBUG:
    print(f"debugging table {f'{df_makt=}'.split('=')[0]}")
    df_makt.where(df_makt.matnr == "PLATES_1100VU_A5V").show()

# COMMAND ----------

# %% Join AFKO-AUFK-AFPO on MAKT
# Note: we decided to filter on item description to be only english to reduce compute time on the join.
df_afko_aufk_afpo_makt = df_afko_aufk_afpo.join(
    df_makt.where(f.col("makt_spras") == "E"),
    on=[
        f.col("afpo_mandt") == f.col("makt_mandt"),
        f.col("afpo_matnr") == f.col("makt_matnr"),
    ],
    how="left",
)

if DEBUG:
    debug_table(df_afko_aufk_afpo_makt)

# COMMAND ----------

# %% Save latest work order data asset
spark.sql(f"CREATE DATABASE IF NOT EXISTS {WORK_ORDER_DATABASE}")

table_utils.save_table(
    dest_table=WORK_ORDER_GOLD_TABLE,
    df=df_afko_aufk_afpo_makt,
    mode="overwrite",
    overwrite_schema=True
)
