# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # [GOLD - MATERIAL PLANT DATABASE]
# MAGIC
# MAGIC **Summary:**  
# MAGIC This notebook focuses on building a gold table for Master Data Material by plant.   
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table for Master Data Material by plant   
# MAGIC This reference material table ensures the quality, consistency, and performance of material data throughout the entire company.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - W_1_SAP_Master_Data_Material-Asset  
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_silver.master_data.material
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.material

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from pyspark.sql.types import MapType, StringType, DoubleType, FloatType
import time
import logging

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC

# COMMAND ----------

# Utils imports
from leap_utils.data_asset import table_utils, amount_correction

# leap logger
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("bypass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

log = setup_applevel_logger(log_level=LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

def extract_needs_quantity(df_mrp: DataFrame) -> DataFrame:
    """
    Filters and processes a DataFrame containing Material Resource Planning (MRP) data to compute the sum of needs for each unique combination of material number, material number origin, profit center, and plant.

    :param df_mrp: The input DataFrame containing MRP data.
    :type df_mrp: DataFrame
    :return: A DataFrame grouped by material number, material number origin, profit center, and plant with the summed quantity of needs (negative movements) under the column "needs_quantity".
    :rtype: DataFrame
    """
    # Filter MRP DataAsset -> Keep only Needs from Mrp List (-: needs / +:Resources)
    df_mrp = df_mrp.filter(f.col("Code_mvt") == "-")
    df_mrp = df_mrp.withColumn("quantity", f.col("quantity").cast("float"))

    df_mrp_quantity = df_mrp.groupBy(
        "material_number", "plant", "planif_unit", "material_number_origin"
    ).agg(f.sum("quantity").alias("needs_quantity"))
    return df_mrp_quantity


def add_profit_center_origin(
    df_material_end: DataFrame, df_mrp_quantity: DataFrame
) -> DataFrame:
    """
    Joins a DataFrame containing material master data with another DataFrame containing MRP needs quantity data to associate the profit center origin of each material number Origin.

    :param df_material_end: The material master data DataFrame.
    :type df_material_end: DataFrame
    :param df_mrp_quantity: The MRP needs quantity DataFrame to be enriched with profit center origin information.
    :type df_mrp_quantity: DataFrame
    :return: A DataFrame resulting from the MRP needs quantity DataFrame with the material master data, enriched with the profit center origin for each material number origin.
    :rtype: DataFrame
    """
    filter_material_df = df_material_end.select(
        "material_number", "plant", "mrp_unit", "profit_center"
    )
    filter_material_df = filter_material_df.dropDuplicates(
        ["material_number", "plant", "mrp_unit", "profit_center"]
    )
    filter_material_df = (
        filter_material_df.withColumnRenamed("profit_center", "profit_center_origin")
        .withColumnRenamed("plant", "plant_ref")
        .withColumnRenamed("material_number", "material_number_ref")
    )

    df_mrp_origin_profit_center = df_mrp_quantity.join(
        filter_material_df,
        (
            df_mrp_quantity["material_number_origin"]
            == filter_material_df["material_number_ref"]
        )
        & (df_mrp_quantity["plant"] == filter_material_df["plant_ref"])
        & (df_mrp_quantity["planif_unit"] == filter_material_df["mrp_unit"]),
        "left",
    )
    df_mrp_origin_profit_center = df_mrp_origin_profit_center.drop(
        "plant_ref", "material_number_ref", "mrp_unit"
    )
    df_mrp_origin_profit_center = df_mrp_origin_profit_center.withColumnRenamed(
        "planif_unit", "mrp_unit"
    )
    return df_mrp_origin_profit_center


def add_total_quantity_needs(df_mrp_origin_profit_center: DataFrame) -> DataFrame:
    """
    Enhances a DataFrame containing MRP needs quantity data with a total needs quantity for each material number by summing up the needs quantities across all origins and plants.

    :param df_mrp_origin_profit_center: The MRP needs quantity DataFrame to be enriched with total needs quantities.
    :type df_mrp_origin_profit_center: DataFrame
    :return: The input DataFrame enriched with a new column "total_needs_quantity" representing the sum of needs quantities for each material number across all origins and plants.
    :rtype: DataFrame
    """
    # Create new df that sum stock quantity for Each Material_Number
    mrp_total_quantity_df = df_mrp_origin_profit_center.groupBy(
        "material_number", "plant", "mrp_unit"
    ).agg(f.sum("needs_quantity").alias("total_needs_quantity"))

    mrp_total_quantity_df = (
        mrp_total_quantity_df.withColumnRenamed(
            "material_number", "material_number_tot"
        )
        .withColumnRenamed("plant", "plant_tot")
        .withColumnRenamed("mrp_unit", "mrp_unit_tot")
    )

    mrp_full = df_mrp_origin_profit_center.join(
        mrp_total_quantity_df,
        (
            (
                mrp_total_quantity_df["material_number_tot"]
                == df_mrp_origin_profit_center["material_number"]
            )
            & (
                mrp_total_quantity_df["plant_tot"]
                == df_mrp_origin_profit_center["plant"]
            )
            & (
                mrp_total_quantity_df["mrp_unit_tot"]
                == df_mrp_origin_profit_center["mrp_unit"]
            )
        ),
        "left",
    )
    mrp_full = mrp_full.drop(
        "material_number_tot", "plant_tot", "material_number_origin"
    )
    return mrp_full


def fill_na_with_label(df: DataFrame, label: str) -> DataFrame:
    """
    Fills null values in the 'Profit_Center_Origin' column of the given DataFrame with a specified label.

    :param df: The DataFrame containing 'Profit_Center_Origin' column with null values to be filled.
    :type df: DataFrame
    :param label: The label to fill in for null values in the 'Profit_Center_Origin' column.
    :type label: str
    :return: The DataFrame with null values in the 'Profit_Center_Origin' column filled with the specified label.
    :rtype: DataFrame
    """
    mrp_full = df.na.fill(value=label, subset=["profit_center_origin"])
    return mrp_full


def compute_PF_affectation(df_mrp_full: DataFrame) -> DataFrame:
    """
    Creates a new column 'PF_pourcentage' in the 'df_mrp_full' DataFrame that calculates, for each combination of 'Material_Number', the percentage of 'Profit_Center' quantity used out of the total needs quantity.

    :param df_mrp_full: The MRP DataFrame to calculate the 'Profit_Center' usage percentage.
    :type df_mrp_full: DataFrame
    :return: The 'df_mrp_full' DataFrame with a new column 'PF_pourcentage' representing the calculated percentage.
    :rtype: DataFrame
    """
    df_mrp_composition = df_mrp_full.withColumn(
        "PF_pourcentage",
        f.create_map(
            f.col("profit_center_origin"),
            f.col("needs_quantity") / f.col("total_needs_quantity"),
        ),
    )
    return df_mrp_composition


def merge_dicts(dict_list):
    """
    Merges dictionaries within a list into a single dictionary, aggregating values by keys.

    :param dict_list: A list of dictionaries to be merged. Each dictionary represents
                      a 'Profit_Center' to its percentage allocation for a 'Material_Number'.
    :type dict_list: list
    :return: A single dictionary with keys from the input dictionaries and aggregated values.
             If initial values for a key are None, they contribute to an equal distribution
             based on the total sum of non-None values.
    :rtype: dict
    """
    result = {}
    nb_null_value = 0
    tot_value = 0
    PF_composition = {}
    for dictionary in dict_list:
        for key, value in dictionary.items():
            if value is None:
                nb_null_value += 1
            else:
                tot_value += value

    for dictionary in dict_list:
        for key, value in dictionary.items():
            if key in result:
                if value is None:
                    if tot_value == 0:
                        result[key] += 1 / nb_null_value
                else:
                    result[key] += value
            else:
                if value is None:
                    if tot_value == 0:
                        result[key] = 1 / nb_null_value
                else:
                    result[key] = value
    return result


def compute_global_PF_affectation(df_mrp_composition: DataFrame) -> DataFrame:
    """
    Computes the global 'Profit Center' (PF) affectation percentages for each 'Material_Number'
    by merging individual 'PF_pourcentage' dictionaries into a single dictionary per 'Material_Number'.

    :param df_mrp_composition: A DataFrame containing 'Material_Number' and 'PF_pourcentage'.
    :type df_mrp_composition: DataFrame
    :return: DataFrame
    :rtype: DataFrame
    """
    merge_dicts_udf = udf(merge_dicts, MapType(StringType(), DoubleType()))
    df_material_composition = df_mrp_composition.groupBy(
        "material_number", "plant", "mrp_unit"
    ).agg(
        merge_dicts_udf(f.collect_list("PF_pourcentage")).alias(
            "PF_pourcentage_affectation"
        )
    )
    return df_material_composition


def set_na_w_last_snapshot(
    df_last_master_data_snapshot: DataFrame, df_material_composition: DataFrame
) -> DataFrame:
    """
    Set Null Values of PF_pourcentage_affectation with last snapshot.

    :param df_last_master_data_snapshot: The DataFrame containing the last master data snapshot.
    :type df_last_master_data_snapshot: DataFrame
    :param df_material_composition: The DataFrame containing material composition data.
    :type df_material_composition: DataFrame
    :return: The DataFrame with replaced unknown values in the 'PF_pourcentage_affectation' column.
    :rtype: DataFrame
    """
    affectation_column_name = "PF_pourcentage_affectation"
    if affectation_column_name in df_last_master_data_snapshot.columns:
        df_last_master_data_snapshot = df_last_master_data_snapshot.select(
            "material_number", "plant", "PF_pourcentage_affectation", "mrp_unit"
        )
        df_last_master_data_snapshot = df_last_master_data_snapshot.dropDuplicates(
            ["material_number", "plant", "mrp_unit"]
        )
        df_last_master_data_snapshot = (
            df_last_master_data_snapshot.withColumnRenamed("plant", "plant_last")
            .withColumnRenamed("material_number", "material_number_last")
            .withColumnRenamed("mrp_unit", "mrp_unit_last")
            .withColumnRenamed(
                "PF_pourcentage_affectation", "PF_pourcentage_affectation_last"
            )
        )
        df_material_composition_tot = df_material_composition.join(
            df_last_master_data_snapshot,
            (
                df_last_master_data_snapshot["material_number_last"]
                == df_material_composition["material_number"]
            )
            & (
                df_last_master_data_snapshot["plant_last"]
                == df_material_composition["plant"]
            )
            & (
                df_last_master_data_snapshot["mrp_unit_last"]
                == df_material_composition["mrp_unit"]
            ),
            "left",
        )
        df_material_composition_without_null_values = (
            df_material_composition_tot.withColumn(
                "PF_pourcentage_affectation",
                f.when(
                    f.col("PF_pourcentage_affectation").isNull(),
                    f.col("PF_pourcentage_affectation_last"),
                ).otherwise(
                    f.col("PF_pourcentage_affectation"),
                ),
            )
        )
        df_material_composition = df_material_composition_without_null_values.drop(
            "plant_last",
            "material_number_last",
            "mrp_unit_last",
            "PF_pourcentage_affectation_last",
        )
    return df_material_composition


def handle_unknown_values_from_affectation(df_material: DataFrame) -> DataFrame:
    """
    Handle affectation flagged as "unknown" and Null.

    :param df_material: material master data
    :type df_material: DataFrame
    :return: _description_
    :rtype: DataFrame
    """
    allocate_profit_center_base_condition = (
        (f.col("profit_center_affectation") == "Unknown")
        | f.isnull(f.col("profit_center_affectation"))
    ) & (
        (~f.col("profit_center").startswith("98"))
        | (~f.col("profit_center").endswith("W"))
    )

    allocate_others_condition = (
        (f.col("profit_center_affectation") == "Unknown")
        | f.isnull(f.col("profit_center_affectation"))
    ) & (
        (f.col("profit_center").startswith("98"))
        | (f.col("profit_center").endswith("W"))
    )

    df_exploded = df_material.select(
        f.col("*"),
        f.explode_outer(f.col("PF_pourcentage_affectation")).alias(
            "profit_center_affectation", "value"
        ),
    ).withColumn(
        "value",
        f.when(f.col("PF_pourcentage_affectation").isNull(), f.lit(1)).otherwise(f.col("value"))
    )

    df_transformed = df_exploded.withColumn(
        "profit_center_affectation",
        f.when(
            allocate_profit_center_base_condition,
            df_exploded["profit_center"],
        )
        .when(
            allocate_others_condition,
            f.lit("Others"),
        )
        .when(
            (f.col("Profit_Center").isNull()) & (f.col("Profit_Center_Affectation").isNull()),
            f.lit("Unknown")
        )
        .otherwise(df_exploded["profit_center_affectation"]),
    )
    df_grouped_by_PF_affectation = df_transformed.groupBy(
        "material_number", "plant", "mrp_unit", "profit_center_affectation"
    ).agg(f.sum("value").alias("value"))
    df_grouped = (
        df_grouped_by_PF_affectation.groupBy("material_number", "plant", "mrp_unit")
        .agg(
            f.collect_list(f.expr("struct(profit_center_affectation, value)")).alias(
                "key_value_pairs"
            )
        )
        .withColumn("PF_pourcentage_affectation", f.map_from_entries("key_value_pairs"))
        .select("material_number", "plant", "mrp_unit", "PF_pourcentage_affectation")
    )
    return df_grouped


def join_with_material_master_data_base(
    material_master_data: DataFrame, df_right: DataFrame
) -> DataFrame:
    """
    Join sub dataframe of material master data into material master data on "material_number", "plant", "mrp_unit".

    :param material_master_data: material master data reference
    :type material_master_data: DataFrame
    :param df_right: Sub dataframe of material master data
    :type df_right: DataFrame
    :return: Joined dataframe
    :rtype: DataFrame
    """
    df_material_composition = (
        df_right.withColumnRenamed("material_number", "material_number_composition")
        .withColumnRenamed("plant", "plant_composition")
        .withColumnRenamed("mrp_unit", "mrp_unit_composition")
    )
    df_material_end = material_master_data.join(
        df_material_composition,
        (
            material_master_data["material_number"]
            == df_material_composition["material_number_composition"]
        )
        & (
            material_master_data["plant"]
            == df_material_composition["plant_composition"]
        )
        & (
            material_master_data["mrp_unit"]
            == df_material_composition["mrp_unit_composition"]
        ),
        "left",
    )
    df_material_end = df_material_end.drop(
        "material_number_composition", "plant_composition", "mrp_unit_composition"
    )
    return df_material_end


def transform_map(map_col):
    if map_col is None:
        return None
    return {
        k: round(1.0 if v > 1 else v, 2) if v is not None else None
        for k, v in map_col.items()
    }


transform_map_udf = f.udf(transform_map, MapType(StringType(), DoubleType()))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Bronze Special procurement key  
# MAGIC
# MAGIC **df_bronze_t460a** Special procurement key to link Procurement type to a plant 

# COMMAND ----------

df_bronze_t460a = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t460a_latest"
).select("werks", "sobsl", "wrk02")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Bronze Manual Mapping division site  
# MAGIC **df_bronze_site** Mapping site-division-region  
# MAGIC **df_bronze_site_plant** Mapping site-plant  

# COMMAND ----------

df_bronze_site = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_site_division_region"
)
df_bronze_site_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_plant_site"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Bronze Manual Mapping mrp controller category
# MAGIC **df_bronze_mrpcontroller**  mrp controller category mapping

# COMMAND ----------

df_bronze_mrpcontroller = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mapping_mrp_controller_category"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Silver Material plant  
# MAGIC
# MAGIC **df_silver_material_plant** General Material Data  

# COMMAND ----------

df_silver_material_plant = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.master_data.material_plant"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Gold Source List
# MAGIC **df_gold_sourcelist** sourcelist raw Master Data

# COMMAND ----------

df_gold_sourcelist = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.procurement_purchasing.source_list_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Gold Material 
# MAGIC
# MAGIC **df_gold_material** General Material Data 

# COMMAND ----------

df_gold_material = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.master_data.material_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Gold Currency Exchange
# MAGIC **df_gold_currency** Currency Exchange data

# COMMAND ----------

# Upload Gold Currency to convert all prices in EUR
df_gold_currency = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.currency_exchange")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Gold Profit Center
# MAGIC **df_gold_profitcenter** profit center master data
# MAGIC

# COMMAND ----------

df_gold_profitcenter = spark.read.table(f"{REFERENCE_READ_ENV}_gold.finance.profit_center_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Gold plant
# MAGIC **df_gold_plant** Currency Exchange data

# COMMAND ----------

df_gold_plant = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Gold Mrp list
# MAGIC **df_gold_mrp** Extraction of MRP List

# COMMAND ----------

df_gold_mrp = spark.read.table(f"{REFERENCE_READ_ENV}_gold.mrp.list_mrp_full_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Gold Supplier
# MAGIC **df_gold_supplier** Supplier Master Data

# COMMAND ----------

df_gold_supplier = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain.supplier_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Gold Quota arrangment
# MAGIC **df_gold_quota** Quota Arragement Master Data

# COMMAND ----------

df_gold_quota = spark.read.table(f"{REFERENCE_READ_ENV}_gold.production.quotas_arrangement_exposed")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# MAGIC %md
# MAGIC ### Example File import
# MAGIC
# MAGIC Description of file imports found in folder x that represent Y coming form system Z

# COMMAND ----------

#N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep.1 - Select and rename Master Data Plant 
# MAGIC

# COMMAND ----------

df_gold_plant = df_gold_plant.toDF(*[c.lower() for c in df_gold_plant.columns])
df_gold_plant = df_gold_plant.select(
    "plant",
    "currency",
    f.col("plant_description_new").alias("production_site"),
    "company",
    "company_description",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep.2 - Select and translate Site mapping

# COMMAND ----------

df_bronze_site = df_bronze_site.withColumnRenamed("site", "stock_site").withColumn(
    "stock_site", f.translate("stock_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
).distinct()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep.2 - Filter and rename Mrp List

# COMMAND ----------

df_gold_mrp = df_gold_mrp.toDF(*[c.lower() for c in df_gold_mrp.columns])
# Keep only Needs from Mrp List (-: needs / +:Resources)
df_gold_mrp = df_gold_mrp.filter(f.col("Code_mvt") == "-")

# Exclusion needs from PEX
# Segment 04 - Smoothing prod out MRP
# Segment 26 - Segment 26 Subcontracted Needs already take in account in segment 02
df_gold_mrp_filtered = df_gold_mrp.filter(
    (f.col("Segment_planif") != "04") & (f.col("segment_planif") != "26")
)
# Determination of need Plant
df_mrp_full = df_gold_mrp_filtered.withColumn(
    "plant_need",
    f.when(f.col("plant_delivered").isNull(), f.col("plant")).otherwise(
        f.col("plant_delivered")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep.3 - Select and rename Supplier 

# COMMAND ----------

df_gold_supplier = df_gold_supplier.toDF(*[c.lower() for c in df_gold_supplier.columns])
df_gold_supplier_for_quota = df_gold_supplier.select("supplier_code", "supplier_name")
df_gold_supplier_for_quota = df_gold_supplier_for_quota.dropDuplicates()
df_gold_supplier_for_sourcelist = df_gold_supplier.select(
    "supplier_code",
    f.col("supplier_name").alias("supplier_name_sourcelist"),
    f.col("plant").alias("plant_sourcelist"),
    f.col("purch_organization").alias("purchasing_organization"),
)
df_gold_supplier_for_sourcelist = df_gold_supplier_for_sourcelist.dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep.4 - Select and rename Quotas arragement 

# COMMAND ----------

# Keep only active Quota.
df_gold_quotas_active = df_gold_quota.filter(
    (f.col("start_validity") < f.current_date())
    & (f.col("end_validity") > f.current_date())
).filter(f.col("quota") != 0)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep.5 - Select and rename Source List

# COMMAND ----------

## Keep Only Active Source List in SAP
# Actual Date between Start_Validity_Date (source_list_record_valid_from) and source_list_record_valid_from (EORD_bdatu)
# And Supplier allocated to material Number(EORD_flifn or EORD_febel)

df_gold_sourcelist = df_gold_sourcelist.filter(
    (f.col("source_list_record_valid_from") < f.current_date())
    & (f.col("source_list_record_valid_to") > f.current_date())
    & (
        (f.col("is_fixed_contract_item") == True)
        | (f.col("is_fixed_vendor") == True)
        | (f.col("planification_code") == "1")
    )
)
df_source = df_gold_sourcelist.select(
    "material_number",
    "plant",
    "supplier_code",
    "purchasing_organization",
    "planification_code",
    "contract_number",
    "contract_item",
    "is_fixed_contract_item",
    "is_fixed_vendor",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep.6 - Select and rename Special procurement key

# COMMAND ----------

df_intraco = df_bronze_t460a.select(
    f.col("werks").alias("plant"),
    f.col("sobsl").alias("procurement_special_type"),
    f.col("wrk02").alias("plant_linked"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep.7 - Select MRP Controller Affectation

# COMMAND ----------

df_mrpcontroller = df_bronze_mrpcontroller.select("plant", "mrp_controller", "category")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr.1 - Add material basics

# COMMAND ----------

df_material_join = df_silver_material_plant.join(
    df_gold_material, ["material_number"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr.2 - Add plant and Company info

# COMMAND ----------

df_material_company = df_material_join.join(df_gold_plant, ["plant"], "left")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr.3 - Determination Branch & Production Site & Inventory Site  
# MAGIC On AS side, we have 4 distinct plants grouped into a single plant in SAP (1000)  
# MAGIC and 2 distinct plants grouped into a single plan in SAP (Plant 1900)

# COMMAND ----------

# MAGIC %md
# MAGIC Solveig start
# MAGIC
# MAGIC
# MAGIC Step 1: determination of the site 
# MAGIC 1. relation 1>1 between a plant code to a site 
# MAGIC 2. DES identification inside plant 1000 through the profit center --> based on the field PC_attributed_site (from SAP) of the profit center master data 
# MAGIC 3. Separation Montredon / Gimont through the MRP controller 
# MAGIC 4. Plant 2000 in Labège: they buy parts for everyone
# MAGIC
# MAGIC Step 2: from the site, determination of the division and the region 

# COMMAND ----------

# ----------------------------------------------------------------------------------
# We keep only in the mapping plant code when there are associated to a unique site
window_plant = Window.partitionBy("plant_code")
df_bronze_site_plant = (
    df_bronze_site_plant.withColumn("_tmp_count", f.count("*").over(window_plant))
    .filter(f.col("_tmp_count") == 1)
    .drop("_tmp_count")
).withColumnsRenamed({"plant_code": "plant", "site": "_tmp_site_case_1"})
# ----------------------------------------------------------------------------------
df_gold_profitcenter = df_gold_profitcenter.select(
    f.col("profit_center_short").alias("profit_center"),
    f.col("PC_Attributed_Site").alias("_tmp_site_case_2"),
).where(f.col("_tmp_site_case_2") == "LATE-LFR1 - Labège Systems")

# COMMAND ----------

# Determination of Branch
# -----------------------------------------------------------------
# Determination 1:1 relationship
df_material_w_site = df_material_company.join(df_bronze_site_plant, ["plant"], "left")
# Determination DES
df_material_w_site = df_material_w_site.join(
    df_gold_profitcenter, ["profit_center"], "left"
)
# Determination dispatch plant 1000 and 2000
df_material_w_site = df_material_w_site.withColumn(
    "_tmp_site_case_3",
    f.when(
        f.col("plant") == "2000",
        f.lit("LFR1 - Labège"),
    ),
)
df_material_w_site = df_material_w_site.withColumn(
    "_tmp_site_case_4",
    f.when(
        (f.col("plant") == "1000") & (f.col("decopling_point").startswith("MON")),
        f.lit("LATE - Montredon"),
    )
    .when(
        ((f.col("plant") == "1000") | (f.col("plant") == "2000"))
        & (f.col("mrp_controller").startswith("DE")),
        f.lit("LATE-LFR1 - Labege Systems"),
    )
    .when(
        (f.col("plant") == "1000") & (f.col("decopling_point").startswith("GMT")),
        f.lit("LATE - Gimont"),
    )
    .when(
        (f.col("plant") == "1000")
        & (
            (f.col("decopling_point").startswith("CUS"))
            | (f.col("decopling_point").startswith("DES"))
        ),
        f.lit("LATE-LFR1 - Labege Systems"),
    )
    .otherwise(f.lit("LATE - Gabardie")),
)
df_material_w_site = df_material_w_site.withColumn(
    "stock_site",
    f.coalesce(
        f.col("_tmp_site_case_1"),
        f.col("_tmp_site_case_2"),
        f.col("_tmp_site_case_3"),
        f.col("_tmp_site_case_4"),
    ),
)
df_material_w_site = df_material_w_site.select(
    [col for col in df_material_w_site.columns if not col.startswith("_tmp")]
)
# -----------------------------------------------------------------
# Remove all accents in site so as to join correctly
df_material_w_site = df_material_w_site.withColumn(
    "stock_site", f.translate("stock_site", "éèêëàâäîïôöùûüç", "eeeeaaaiioouuuc")
)

df_material_w_site = df_material_w_site.join(df_bronze_site, ["stock_site"], "left")

# Quality check: all lines must have a site
if df_material_w_site.where(f.col("stock_site").isNull()).count() > 0:
    raise Exception("At least 1 row with blank site")
# -----------------------------------------------------------------

# COMMAND ----------

# -----------------------------------------------------------------------------
# Dispatch Production Site for Plant 1000 (Gimont/Montredon/HUB/DES)
df_material_prod = df_material_w_site.withColumn(
    "production_site",
    f.when(f.col("Plant") != "1000", f.col("stock_site"))
    .when(
        (f.col("procurement_type") == "F") & (f.col("stock_site") == "LATE - Gimont"),
        f.lit("LATE - Gimont"),
    )
    .when(
        (f.col("procurement_type") == "F") & (f.col("stock_site") == "LATE - Colomiers"),
        f.lit("LATE - Colomiers"),
    )
    .when(
        (f.col("procurement_type") == "F") & (f.col("stock_site") == "LATE - Montredon"),
        f.lit("LATE - Montredon"),
    )
    .when((f.col("procurement_type") == "F"), f.lit("LATE - Gabardie"))
    .when(f.col("mrp_controller").startswith("O"), f.lit("LATE - Montredon"))
    .otherwise(f.lit("LATE - Gimont")),
)
# -----------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr.4 - Management Currency

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR4.1 - Management of Wrong SAP decimal for spécific currency (TND, JPY,...)

# COMMAND ----------

# Use Fonction to correct wrong amount coming from SAP
df_material_price = amount_correction.create_corrected_amounts(
    df_material_prod, "average_price", "currency"
)
df_material_price = amount_correction.create_corrected_amounts(
    df_material_price, "standard_price", "currency"
)
df_material_price = amount_correction.create_corrected_amounts(
    df_material_price, "budget_price", "currency"
)
# ---------------------------------------------------------------
df_material_price = df_material_price.drop(
    "average_price", "standard_price", "budget_price"
)
# ---------------------------------------------------------------
rename_mapping = {
    "average_price_corrected": "average_price",
    "standard_price_corrected": "standard_price",
    "budget_price_corrected": "budget_price",
}

for old_col, new_col in rename_mapping.items():
    df_material_price = df_material_price.withColumnRenamed(old_col, new_col)
# ---------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR4.2 - Convert price in EUR curency

# COMMAND ----------

# Take the max date from Gold Currency
latest_currency_date = df_gold_currency.agg(
    f.max("Validity_Date_DateFormat").alias("Latest currency date")
).collect()[0][0]

df_material_price = df_material_price.withColumn(
    "document_conversion_date", f.lit(latest_currency_date)
)

df_material_price_corrected = table_utils.currency_conversion(
    df=df_material_price,
    document_currency_column=[f.col("currency")],
    rate_types=["Spot", "Budget"],
    rate_dates=[f.col("document_conversion_date")],
    target_currency_value="EUR",
    document_amounts=[
        f.col("standard_price"),
        f.col("average_price"),
        f.col("budget_price"),
    ],
)
df_material_price_end = (
    df_material_price_corrected.withColumnRenamed(
        "standard_price_from_currency_to_EUR_in_Spot_rate_at_document_conversion_date",
        "standard_price_eur_spot",
    )
    .withColumnRenamed(
        "standard_price_from_currency_to_EUR_in_Budget_rate_at_document_conversion_date",
        "standard_price_eur_budget",
    )
    .withColumnRenamed(
        "average_price_from_currency_to_EUR_in_Spot_rate_at_document_conversion_date",
        "average_price_eur_spot",
    )
    .withColumnRenamed(
        "average_price_from_currency_to_EUR_in_Budget_rate_at_document_conversion_date",
        "average_price_eur_budget",
    )
    .withColumnRenamed(
        "budget_price_from_currency_to_EUR_in_Spot_rate_at_document_conversion_date",
        "budget_price_eur_spot",
    )
    .withColumnRenamed(
        "budget_price_from_currency_to_EUR_in_Budget_rate_at_document_conversion_date",
        "budget_price_eur_budget",
    )
)
# Take in coonsideration unit price
df_material_price_end = (
    df_material_price_end.withColumn(
        "standard_price_eur_budget",
        f.col("standard_price_eur_budget") / f.col("Price_Base"),
    )
    .withColumn(
        "average_price_eur_budget",
        f.col("average_price_eur_budget") / f.col("Price_Base"),
    )
    .withColumn(
        "standard_price_eur_spot",
        f.col("standard_price_eur_spot") / f.col("Price_Base"),
    )
    .withColumn(
        "budget_price_eur_spot", f.col("budget_price_eur_spot") / f.col("Price_Base")
    )
    .withColumn(
        "budget_price_eur_budget",
        f.col("budget_price_eur_budget") / f.col("Price_Base"),
    )
    .drop(
        "currency_to_EUR_in_Budget_rate_at_document_conversion_date",
        "currency_to_EUR_in_Spot_rate_at_document_conversion_date",
        "Document_conversion_date",
        "standard_price",
        "average_price",
        "budget_price",
        "price_base",
        "currency",
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR.4.3 - Management Price Upper Green-Line
# MAGIC Specific AS

# COMMAND ----------

# For all Material upper the Green-Line (ie :IndivColl = 1)
# Price is collected on WBS, Standard and average price need to set to 0
# Normally done in SAP but checked again here

price_columns = [
    "standard_price_eur_budget",
    "average_price_eur_budget",
    "standard_price_eur_spot",
    "average_price_eur_spot",
    "budget_price_eur_spot",
    "budget_price_eur_budget",
]

df_material_end = df_material_price_end
for col_name in price_columns:
    df_material_end = df_material_end.withColumn(
        col_name, f.when(f.col("indivcoll") == "1", f.lit(0)).otherwise(f.col(col_name))
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr.5 - Management of Needs  
# MAGIC Here we collect the requirements in order to determine the part categories as well as the final assembly sites.

# COMMAND ----------

# Keep one DataFrame for All Needs for one plant
df_mrp_all = df_mrp_full.groupBy("plant", "material_number").agg(
    f.sum("quantity").alias("total_needs")
)

# Keep one DataFrame for Needs coming from an another Plant (Interco_Need)
df_mrp_plant = df_mrp_full.filter(f.col("Plant") != f.col("plant_need"))

df_mrp_plant = df_mrp_plant.groupBy("plant", "material_number").agg(
    f.sum("quantity").alias("interco_need")
)
# Add Full need and interco needs to Material Master Data
df_material_needs = df_material_end.join(
    df_mrp_all, ["plant", "material_number"], "left"
).join(df_mrp_plant, ["plant", "material_Number"], "left")
# ------------------------------------------------------------------------
# Gestion Null value
columns_to_replace = ["total_needs", "interco_need"]
df_material_needs = df_material_needs.na.fill(0, columns_to_replace)

# Calcul of net needs by plant
df_material_needs = df_material_needs.withColumn(
    "net_needs", f.col("total_needs") - f.col("interco_need")
)
df_material_needs = df_material_needs.drop("interco_need")
# ------------------------------------------------------------------------
# Management of VB Planification (Reordo Point)
df_material_needs = df_material_needs.withColumn(
    "net_needs",
    f.when(
        (f.col("mrp_type") == "VB")
        & (f.col("net_needs") == 0)
        & (f.col("total_needs") == 0),
        f.col("reorder_point") * 3,
    ).otherwise(f.col("net_needs")),
)
# ------------------------------------------------------------------------
# Add Safety Stock to Needs
df_material_needs = df_material_needs.withColumn(
    "total_needs", f.col("total_needs") + f.col("safety_stock")
)
df_material_needs = df_material_needs.withColumn(
    "net_needs", f.col("net_needs") + f.col("safety_stock")
)
# Determination of Categorisation Parts
df_material_needs = df_material_needs.withColumn(
    "needs_category",
    f.when(f.col("total_needs") == 0, f.lit("No_Need")).otherwise(f.lit("Needs_OK")),
)
# ------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr.6 - Management of Final Assembly  
# MAGIC Here we determine the final consumption site of the part. If a part is intended to be consumed at multiple sites, the site with the highest consumption is declared as the final assembly site.

# COMMAND ----------

# If Net Needs upper than 0 or Need_Category = No_Need
# Final Assembly is Stock Site
df_material_assembly = df_material_needs.withColumn(
    "assy_final",
    f.when(
        (f.col("needs_category") == "No_Need") | (f.col("Net_Needs") != 0),
        f.col("stock_site"),
    ).otherwise(f.lit("TBD")),
)
# ----------------------------------------------------------------------
# When Total Needs => 0 we keep the assy plant with high value of needs
window_spec = Window.partitionBy(
    "material_number",
).orderBy(f.col("net_needs").desc())
df_with_row_number = df_material_assembly.withColumn(
    "row_number", f.row_number().over(window_spec)
)
df_result = df_with_row_number.filter(f.col("row_number") == 1)

df_result = df_result.select(
    "material_number", f.col("assy_final").alias("assy_final_")
)

df_material_join = df_material_assembly.join(df_result, ["material_number"], "left")
# ----------------------------------------------------------------------
# At this point if final Assembly can't be determine, we have problems
# in dataSource SAP -> Put Garbage to highlight to business that something going wrong
df_material_assembly = df_material_join.withColumn(
    "assy_final",
    f.when(
        (f.col("assy_final") == "TBD") & (f.col("assy_final_") == "TBD"),
        f.lit("Garbage"),
    )
    .when(f.col("assy_final") == "TBD", f.col("assy_final_"))
    .otherwise(f.col("assy_final")),
)
df_material_assembly = df_material_assembly.drop("assy_final_")
# ----------------------------------------------------------------------


# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr.7 - Management of Supplier Assignment
# MAGIC Here we determine the supplier assigned to the material/plant pair. If the assigned supplier is an intercompany supplier, we retrieve the supplier from plant of the intercompany supplier.

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR.7.1 - Management Source List 

# COMMAND ----------

# If we have several active entries for plant / Material_Number / Purchase Organization
# We sort by plannification flag, then by Prefered source, then by Supplier affectation
# and we take the first one.

window_spec = Window.partitionBy("material_number", "plant").orderBy(
    f.desc(f.col("planification_code")),
    f.desc(f.col("is_fixed_contract_item")),
    f.desc(f.col("is_fixed_vendor")),
    f.desc(f.col("supplier_code")),
    f.desc(f.col("contract_number")),
    f.desc(f.col("contract_item")),
)
# Add row number
df_source = df_source.withColumn("row_number", f.rank().over(window_spec))
# Keep only one entry
df_source = df_source.filter(f.col("row_number") == 1).drop(
    "row_number", "contract_number", "contract_item"
)
df_source = df_source.dropDuplicates(["material_number", "plant"])

# Take Gold Table Supplier for description
# Join Source List and Supplier Table on Supplier_Code and Purch_Organization
df_source_list = df_source.join(
    df_gold_supplier_for_sourcelist,
    ["supplier_code", "purchasing_organization"],
    "left",
).drop("purchasing_organization")

# Delete leading zeros on Material_Number
df_source_list = table_utils.remove_leading_zeros(df_source_list, ["material_number"])

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR.7.2 - Quota Management

# COMMAND ----------

df_join_quota = df_gold_quotas_active.join(
    df_gold_supplier_for_quota, ["supplier_code"], "left"
)
# Determine Naming for Internal Parts
df_quotas_internal = df_join_quota.withColumn(
    "supplier_name",
    f.when(f.col("procurement_type") == "F", f.col("supplier_name")).otherwise(
        f.concat(f.lit("Internal_"), f.col("plant"))
    ),
)
df_quotas_internal_fix = df_quotas_internal.groupBy("material_number", "plant").agg(
    f.first("supplier_name").alias("supplier_name_1"),
    f.last("supplier_name").alias("supplier_name_2"),
    f.first("supplier_code").alias("supplier_code_1"),
    f.last("supplier_code").alias("supplier_code_2"),
    f.first("quota").alias("quota_1"),
    f.last("quota").alias("quota_2"),
)
df_gold_supplier_for_sourcelist_quotas = df_gold_supplier_for_sourcelist.select(
    "supplier_code", "plant_sourcelist"
).dropDuplicates()
df_quotas_internal_fix_1 = (
    df_quotas_internal_fix.alias("A")
    .join(
        df_gold_supplier_for_sourcelist_quotas.alias("B"),
        f.col("A.supplier_code_1") == f.col("B.supplier_code"),
        "left",
    )
    .withColumnRenamed("plant_sourcelist", "plant_sourcelist_1")
)

df_quotas_internal_fix_2 = (
    df_quotas_internal_fix_1.alias("A")
    .join(
        df_gold_supplier_for_sourcelist_quotas.alias("B"),
        f.col("A.supplier_code_2") == f.col("B.supplier_code"),
        "left",
    )
    .withColumnRenamed("plant_sourcelist", "plant_sourcelist_2")
    .drop("supplier_code", "supplier_code_1", "supplier_code_2")
)

# COMMAND ----------

df_quotas_1 = df_quotas_internal_fix_2.join(
    df_source_list.select(
        f.col("plant").alias("plant_sourcelist_1"),
        "supplier_name_sourcelist",
        "material_number",
    ),
    ["material_number", "plant_sourcelist_1"],
    "left",
)
df_quotas_1 = df_quotas_1.withColumn(
    "supplier_name_1",
    f.coalesce(f.col("supplier_name_sourcelist"), f.col("supplier_name_1")),
).drop("plant_sourcelist_1", "supplier_name_sourcelist")

# Second pass fir supplier 2
df_quotas_2 = df_quotas_1.join(
    df_source_list.select(
        f.col("plant").alias("plant_sourcelist_2"),
        "supplier_name_sourcelist",
        "material_number",
    ),
    ["material_number", "plant_sourcelist_2"],
    "left",
)
df_quotas_2 = df_quotas_2.withColumn(
    "supplier_name_2",
    f.coalesce(f.col("supplier_name_sourcelist"), f.col("supplier_name_2")),
).drop("plant_sourcelist_2", "supplier_name_sourcelist")
df_quotas_end = df_quotas_2.withColumn(
    "suppliersandquotas",
    f.concat(
        f.col("supplier_name_1"),
        f.lit(" - "),
        f.col("quota_1"),
        f.lit(" / "),
        f.col("supplier_name_2"),
        f.lit(" - "),
        f.col("quota_2"),
    ),
).drop("quota_1", "supplier_name_1", "supplier_name_2", "quota_2")


# COMMAND ----------

# MAGIC %md
# MAGIC ### TR.7.3 - Join DataBase with Quota and source List 

# COMMAND ----------

df_material_supplier_join = df_material_assembly.join(
    df_quotas_end, ["material_number", "plant"], "left"
).join(df_source_list, ["material_number", "plant"], "left")
# ------------------------------------------------------------------------------------
# In SAP Quotas Arrangement take the lead on Source List
# Activation of Quota is managed in SAP through Quotas_Usage field in Master Data
# 3 or 4 value -> Activate Quota arrangement.

df_material_supplier_name = df_material_supplier_join.withColumn(
    "supplier_name",
    f.when(
        (f.col("quota_usage") == "4") | (f.col("quota_usage") == "3"),
        f.col("suppliersandquotas"),
    ).otherwise(f.col("supplier_name_sourcelist")),
)
df_material_supplier_name = df_material_supplier_name.withColumn(
    "supplier_code",
    f.when(
        (f.col("quota_usage") == "4") | (f.col("quota_usage") == "3"), f.lit("quotas")
    ).otherwise(f.col("supplier_code")),
)
df_material_supplier_name = df_material_supplier_name.drop(
    "supplier_name_sourcelist", "suppliersandquotas"
)
# ------------------------------------------------------------------------------------
# Management of Internal (not Include in Source list)
# Internal Parts are not managed by Source List
# If Procurement Type is E(Internal) We create a supplier Name
# with prefix INT_ and Plant value
df_material_supplier_int = df_material_supplier_name.withColumn(
    "supplier_code",
    f.when(
        f.col("procurement_type") == "E", f.concat(f.lit("INT_"), f.col("plant"))
    ).otherwise(f.col("supplier_code")),
)
df_material_supplier_int = df_material_supplier_int.withColumn(
    "supplier_name",
    f.when(
        f.col("procurement_type") == "E", f.concat(f.lit("INTERNAL_"), f.col("plant"))
    ).otherwise(f.col("supplier_name")),
)
# # ------------------------------------------------------------------------------------
df_material_supplier_int = df_material_supplier_int.withColumn(
    "plant_sourcelist",
    f.when(
        (f.col("procurement_type") == "E") | (f.col("supplier_code") == "quotas"),
        f.lit(None),
    ).otherwise(f.col("plant_sourcelist")),
)
# Management of Intercompany FLows
# Plant_Buy determine where the parts are bought or produced
df_material_supplier_int = df_material_supplier_int.withColumn(
    "plant_buy",
    f.when(f.col("plant_sourcelist").isNull(), f.col("plant")).otherwise(
        f.col("plant_sourcelist")
    ),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR.7.4 - Management intraco Flows

# COMMAND ----------

df_update_intraco = df_material_supplier_int.join(
    df_intraco, ["plant", "procurement_special_type"], "left"
)
# Take priority on Plant linked to Special Procurement Type (T460A)
df_update_intraco = df_update_intraco.withColumn(
    "plant_sourcelist",
    f.when(f.col("supplier_code") == "quotas", f.lit(None))
    .when(f.col("plant_linked").isNotNull(), f.col("plant_linked"))
    .otherwise(f.col("plant_sourcelist")),
)
df_update_intraco = df_update_intraco.withColumn(
    "plant_buy",
    f.when(f.col("plant_linked").isNotNull(), f.col("plant_linked")).otherwise(
        f.col("plant")
    ),
)
df_update_intraco = df_update_intraco.drop("plant_linked")

# COMMAND ----------

# MAGIC %md
# MAGIC ### TR.7.5 - Management interco flows

# COMMAND ----------

# Ad some plant buy or produce Part for others plant, we need to take right Supplier or Internal site
# For that we make same operation 3 times (manage 6 interco_Flow on a row )
# to be sure that we have the first Supplier and not an Interco_Supplier
# 2023 we have max 3 intercoFlow on a row
# ---------------------------------------------------------------------------------------
def apply_interco_loop(df, loop_number):
    suffix = str(loop_number)

    df_temp = df.select(
        f.col("plant").alias(f"plant{suffix}"),
        f.col("material_number").alias(f"material_number{suffix}"),
        f.col("supplier_code").alias(f"supplier_code{suffix}"),
        f.col("supplier_name").alias(f"supplier_name{suffix}"),
        f.col("plant_sourcelist").alias(f"plant_sourcelist{suffix}"),
        f.col("production_site").alias(f"production_site{suffix}"),
    )

    # Join Material Master with Interco_Plant
    df_joined = (
        df.alias("A")
        .join(
            df_temp.alias("B"),
            (f.col("A.material_number") == f.col(f"B.material_number{suffix}"))
            & (f.col("A.plant_sourcelist") == f.col(f"B.plant{suffix}")),
            "left",
        )
        .drop(f"material_number{suffix}", f"plant{suffix}")
    )

    # Management Interco rules
    df_result = (
        df_joined.withColumn(
            "supplier_code",
            f.coalesce(f.col(f"supplier_code{suffix}"), f.col("supplier_code")),
        )
        .withColumn(
            "supplier_name",
            f.coalesce(f.col(f"supplier_name{suffix}"), f.col("supplier_name")),
        )
        .withColumn(
            "plant_sourcelist",
            f.coalesce(f.col(f"plant_sourcelist{suffix}"), f.col("plant_sourcelist")),
        )
        .withColumn(
            "plant_buy", f.coalesce(f.col("plant_sourcelist"), f.col("plant_buy"))
        )
        .withColumn(
            "production_site",
            f.coalesce(f.col(f"production_site{suffix}"), f.col("production_site")),
        )
        .drop(
            f"supplier_code{suffix}",
            f"supplier_name{suffix}",
            f"plant_sourcelist{suffix}",
            f"production_site{suffix}",
        )
    )
    return df_result


# ---------------------------------------------------------------------------------------
# Execution 3 loops
df_material_supplier_first = apply_interco_loop(df_update_intraco, 1)
df_material_supplier_second = apply_interco_loop(df_material_supplier_first, 2)
df_material_supplier_third = apply_interco_loop(df_material_supplier_second, 3)
# ---------------------------------------------------------------------------------------
# drop columns used for calculation
df_material_supplier_third = df_material_supplier_third.drop(
    "plant_sourcelist", "planification_code","is_fixed_contract_item","is_fixed_vendor"
).dropDuplicates()
# ---------------------------------------------------------------------------------------
# Keep only first entry if we have several production_plant for a same material_number
window_spec = Window.partitionBy("material_number", "plant", "mrp_unit").orderBy(
    f.col("production_site")
)
df_material_supplier_third = (
    df_material_supplier_third.withColumn(
        "row_number", f.row_number().over(window_spec)
    )
    .filter(f.col("row_number") == 1)
    .drop("row_number")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr.8 - Management Category of Product

# COMMAND ----------

# Upload Manual Table for Category of Parts
# On AS side, Mrp Controller gives information about Product Category related to MRP Controller
# On IS side no rules clearly defined yet, so Categorization is set to OTHERS
df_material_mrp = df_material_supplier_third.join(
    df_mrpcontroller, ["plant", "mrp_controller"], "left"
)

df_material_mrp = df_material_mrp.withColumn(
    "category", f.coalesce(f.col("category"), f.lit("TBD"))
)
# -------------------------------------------------------------------------------
# Management of Entries not found in manual table
# IS Management also we take Production site to determine Category
df_material_end = df_material_mrp.withColumn(
    "category",
    f.when(
        f.col("mrp_controller").isNull(),
        f.concat(f.substring(f.col("production_site"), 1, 3), f.lit("-Others")),
    )
    .when(
        (f.col("division") == "IS") & (~f.col("plant").startswith("1")),
        f.concat(f.substring(f.col("production_site"), 6, 6), f.lit("-Others")),
    )
    .when(
        (f.col("division") == "IS") & (f.col("plant").startswith("1")),
        f.concat(f.substring(f.col("production_site"), 1, 3), f.lit("-Others")),
    )
    .otherwise(f.col("category")),
).dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr.9 - Add Mekko Classification
# MAGIC Creation of a special classification of part for MEKKO PBI Visualisation on Inventory

# COMMAND ----------

# Rules had been defined by Business
df_material_end_class = df_material_end.withColumn(
       "Mekko_classif",
       f.when(f.col("familly_std").startswith("02"), f.lit("6-RAW_MATERIAL"))
       .when(f.col("familly_std").startswith("BZ"), f.lit("6-RAW_MATERIAL"))
       .when(f.col("familly_std").isNotNull(), f.lit("5-STANDARD_PARTS"))
       .when(f.col("familly_std").startswith("AA"), f.lit("2-SUB_ASSY"))
       .when(
           (f.col("familly_std").startswith("AB")) | (f.col("familly_std").startswith("AC")),
           f.lit("1-ASSY"),
       )
       .when(f.col("familly_manuf").startswith("01"), f.lit("1-ASSY"))
       .otherwise(f.lit("DETAIL_PART"))
   )
# -------------------------------------------------------------------------------------
# Management Assy Sub Assy according individual Category for AS
df_material_end_class = df_material_end_class.withColumn(
    "mekko_classif",
    f.when(
        (
            (f.col("mekko_classif") == "1-ASSY")
            | (f.col("mekko_classif") == "2-SUB_ASSY")
        )
        & (f.col("indivcoll") == "1")
        & (f.col("division").startswith("AS")),
        f.lit("1-ASSY"),
    )
    .when(
        (
            (f.col("mekko_classif") == "1-ASSY")
            | (f.col("mekko_classif") == "2-SUB_ASSY")
        )
        & (f.col("indivcoll") == "2")
        & (f.col("division").startswith("AS")),
        f.lit("2-SUB_ASSY"),
    )
    .otherwise(f.col("mekko_classif")),
)
# -------------------------------------------------------------------------------------
# Management of Internal or External details parts
df_material_end = df_material_end_class.withColumn(
    "mekko_classif",
    f.when(
        (f.col("mekko_classif") == "DETAIL_PART")
        & (f.col("supplier_code").startswith("INT")),
        f.lit("3-INTERNAL_DP"),
    )
    .when(f.col("mekko_classif") == "DETAIL_PART", f.lit("4-PURCHASED_DP"))
    .when(f.col("mekko_classif").isNull(), f.lit("9-OTHERS"))
    .otherwise(f.col("mekko_classif")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr.10 - Add Material Profit Center Usage

# COMMAND ----------

# Get old master_material_data to handle null values
df_last_master_data_snapshot = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_plant"
)

# COMMAND ----------

df_mrp_quantity = extract_needs_quantity(df_mrp=df_gold_mrp)

df_mrp_origin_profit_center = add_profit_center_origin(
    df_material_end=df_material_end, df_mrp_quantity=df_mrp_quantity
)
df_final_mrp = add_total_quantity_needs(
    df_mrp_origin_profit_center=df_mrp_origin_profit_center
)
df_final_mrp = fill_na_with_label(df=df_final_mrp, label="Unknown")
df_mrp_composition = compute_PF_affectation(df_mrp_full=df_final_mrp)
df_material_composition_compute = compute_global_PF_affectation(
    df_mrp_composition=df_mrp_composition
)
df_material_joined = join_with_material_master_data_base(
    material_master_data=df_material_end, df_right=df_material_composition_compute
)
df_material_composition = set_na_w_last_snapshot(
    df_last_master_data_snapshot=df_last_master_data_snapshot,
    df_material_composition=df_material_joined,
)
df_material_complete = handle_unknown_values_from_affectation(
    df_material=df_material_composition
)
df_material_end = join_with_material_master_data_base(
    material_master_data=df_material_end, df_right=df_material_complete
).withColumn(
    "PF_pourcentage_affectation", transform_map_udf(f.col("PF_pourcentage_affectation"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality check
# MAGIC

# COMMAND ----------

df_material_end = df_material_end.withColumn(
    "material_plant_id",
    f.concat_ws("-", f.col("material_number"), f.col("plant"), ("mrp_unit")),
)
columns = df_material_end.columns
columns.remove("material_plant_id")
new_column_order = ["material_plant_id"] + columns
df_gold_material = df_material_end.select(new_column_order)

# COMMAND ----------

df_to_check = df_material_end
col_to_check = "material_plant_id"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_to_check),
    df_gx.expect_column_values_to_be_unique(column=col_to_check),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"No null values found in {col_to_check}",
    error_message=f"Null values found in {col_to_check}, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="material_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Gold Table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "master_data"
DESTINATION_TABLE = "material_plant"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_material_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_material_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_material_plant_pk"
TABLE_PK_COLS = "material_plant_id"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ###Save Gold exposed table

# COMMAND ----------

catalog = "gold"
domain = "master_data"
table = "material_plant"
src_full_tablename = f"{PIPELINE_WRITE_ENV}_{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"


tables = ["MARC","MBEW"]

selected_columns = [
    col for col in df_gold_material.columns
    if not any(col.startswith(table_h) for table_h in tables)
]

select_statement = ", ".join(selected_columns)
# --------------------------------------------------------------------------------
table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
