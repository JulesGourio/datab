# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for Master data of Plant. 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_silver.master_data.plant_master_data_latest
# MAGIC   
# MAGIC **Intput :**  
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.t001_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.t001k_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.t001w_latest
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC   - SAP Ingestion Bronze  
# MAGIC
# MAGIC **Things to do:** 
# MAGIC - Rename Headers
# MAGIC - Join T001/T001k/T001w  

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions Renaming Columns

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )
# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC #Import Tables from SAP 

# COMMAND ----------

# -----------------------------------------------------------------------------------------------
# T001: Upload SAP Company Master Data
df_t001 = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.t001_latest")
df_t001 = table_utils.add_prefix_to_columns(df_t001, "T001")  # <- Add T001 on headers
# -----------------------------------------------------------------------------------------------
# T001W: Upload SAP Plant Master Data
df_t001w = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.t001w_latest")
df_t001w = table_utils.add_prefix_to_columns(df_t001w, "T001W")  # <- Add T001W on headers
# -----------------------------------------------------------------------------------------------
# T001k: Upload SAP Currency Master Data
df_t001k = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.t001k_latest")
df_t001k = table_utils.add_prefix_to_columns(df_t001k, "T001K")  # <- Add T001K on headers

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Table SAP T001 // T001K // T001W

# COMMAND ----------

df_join_company = (
    df_t001w.alias("A")
    .join(
        df_t001k.alias("B"), (f.col("A.T001W_werks") == f.col("B.T001K_bwkey")), "left"
    )
    .join(df_t001.alias("C"), (f.col("B.T001K_bukrs") == f.col("C.T001_bukrs")), "left")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming according Header files

# COMMAND ----------

# Upload Header file for T001 SAP Table
df_name_T001 = spark.read.table(
    "prod_bronze.headers_sap.headers_sap_business_t001"
)  
# Call function Check Header files
check_schema_of_the_file(df_name_T001)  

# Upload Header file for T001W SAP Table
df_name_T001W = spark.read.table(
    "prod_bronze.headers_sap.headers_sap_business_t001w"
)  
# Call function Check Header files
check_schema_of_the_file(df_name_T001W)  
# Union df_name_T001 & df_name_T001W
df_column_names_union = df_name_T001.unionByName(
    df_name_T001W
) 
# Call Function Delete rows null 
df_union_names = delete_null_rows(
    df_column_names_union
)  
# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_join_company, df_union_names
)  
# Call Funtion Create Columns on Format according header files
df_end = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_union_names
)  

# COMMAND ----------

# MAGIC %md
# MAGIC #Save table

# COMMAND ----------

catalog = f"{WRITE_ENV}_silver"
domain = "master_data"
table = "plant_master_data_latest"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_end,
    mode="overwrite",
    overwrite_schema=True
)
