# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The goal of this notebook is to create the gold tables for Customer Master Data.
# MAGIC
# MAGIC **Input(s):**
# MAGIC - `{read_env}_silver.finance.customer_master_data_latest`
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - `{write_env}_gold.finance.customer_master_data_latest`
# MAGIC - `{write_env}_gold.finance.customer_master_data_latest_exposed`
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - Databricks job named `KN Customer Master Data Pipeline`
# MAGIC
# MAGIC **Things to do:**

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports and widgets

# COMMAND ----------

from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# Get read environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Functions

# COMMAND ----------

# DBTITLE 1,Get gold exposed column names
def get_exposed_columns(df, column_name_starts_with):
    return [
        column_name
        for column_name in filter(
            lambda name: not name.startswith(column_name_starts_with), df.columns
        )
    ]


# COMMAND ----------

# DBTITLE 1,Create a table view
def create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, debug=False
):

    table_view_sql_statement = f"""
CREATE OR REPLACE VIEW {dest_full_tablename}
AS (
    SELECT {select_statement}
    FROM {src_full_tablename}
)
"""

    if debug:
        print(table_view_sql_statement)

    spark.sql(table_view_sql_statement)


# COMMAND ----------

# MAGIC %md
# MAGIC # Run

# COMMAND ----------

# DBTITLE 1,Read silver table
df_customer_silver = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.finance.customer_master_data_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Enrichments

# COMMAND ----------

# DBTITLE 1,Create a single column for customer code using any non null value of customer code of KNA1, KNB1 or KNVV
df_customer_gold = df_customer_silver.withColumn(
    "Customer_Code",
    f.coalesce("KNA1_Customer_Code", "KNB1_Customer_Code", "KNVV_Customer_Code"),
)

# COMMAND ----------

# DBTITLE 1,Create single column for customer payment term using KNVV then KNB1
df_customer_gold = df_customer_gold.withColumn(
    "Customer_Payment_Term",
    f.coalesce("KNVV_Customer_Payment_Term", "KNB1_Customer_Payment_Term"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save tables

# COMMAND ----------

# DBTITLE 1,Save original gold table
catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "finance"
table = "customer_master_data_latest"

CreateSchemaIfNotExists = False

if CreateSchemaIfNotExists:
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_customer_gold,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# DBTITLE 1,Save gold exposed
catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "finance"
src_table = "customer_master_data_latest"
dest_table = "customer_master_data_latest_exposed"

gold_exposed_columns = get_exposed_columns(
    df_customer_gold, column_name_starts_with="KN"
)
select_gold_exposed_columns = ", ".join(gold_exposed_columns)

create_table_view(
    f"{catalog}.{domain}.{src_table}",
    f"{catalog}.{domain}.{dest_table}",
    select_gold_exposed_columns,
)
