# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The goal of this notebook is to create a silver table for Customer Master Data.
# MAGIC
# MAGIC **Input(s):**
# MAGIC - `{read_env}_bronze.sap_latecoere_ecc6.kna1_latest`
# MAGIC - `{read_env}_bronze.sap_latecoere_ecc6.knb1_latest`
# MAGIC - `{read_env}_bronze.sap_latecoere_ecc6.knvv_latest`
# MAGIC - `{read_env}_bronze.manual_input.company_link_sales_org` (Manual Input)
# MAGIC
# MAGIC **Output table(s):**
# MAGIC - `{write_env}_silver.finance.customer_master_data_latest`
# MAGIC
# MAGIC **Triggered by:**
# MAGIC - Databricks job named `KN Customer Master Data Pipeline`
# MAGIC
# MAGIC **Things to do:**

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports and widgets

# COMMAND ----------

from databricks.sdk.runtime import dbutils
from pyspark.sql import DataFrame
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# Get read environment variable
dbutils.widgets.text("reference_read_env", "dev")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# Renaming Sap Columns // add Table Name in header
def add_table_name(df: DataFrame, table_name: str) -> DataFrame:
    for col in df.columns:
        df = df.withColumnRenamed(f"{col}", f"{table_name}_{col}")
    return df


# --------------------------------------------------------------------------------------------------------------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# --------------------------------------------------------------------------------------------------------------

# Rename Columns according with Imput file 'Header Renaming
def rename_sap_column_names(df: DataFrame, df_names: DataFrame) -> DataFrame:

    dfp_names = df_names.toPandas()
    dfp_names["table_field"] = dfp_names["Table_name"] + "_" + dfp_names["Field"]
    for i, r in dfp_names.iterrows():
        df = df.withColumnRenamed(
            r["table_field"], r["Business_name"].replace(" ", "_")
        )

    return df


# --------------------------------------------------------------------------------------------------------------

# Create date format columns when indicated in the headers file
def create_a_date_format_column(df: DataFrame, df_names: DataFrame) -> DataFrame:
    """
    Create a date column when it is asked in the column name config file
    """
    for col in df.columns:
        if df_names.filter(f.col("Business_name") == col).count() > 0:
            if (
                df_names.filter(f.col("Business_name") == col)
                .select("Format")
                .collect()[0][0]
                == "date"
            ):
                df = df.withColumn(
                    f"{col}_DateFormat", f.to_date(f.col(f"{col}"), "yyyyMMdd")
                )

    return df


# --------------------------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table and Renaming

# COMMAND ----------

# Upload KNA1 <- Master Data Customers from SAP
df_kna1 = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.kna1_latest"
)
df_kna1 = add_table_name(df_kna1, "KNA1")  # <- Renaming // KNA1_XXXX
# Upload KNB1 <- Company Data Customers from SAP
df_knb1 = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.knb1_latest"
)
df_knb1 = add_table_name(df_knb1, "KNB1")  # <- Renaming // KNB1_XXXX
# Upload KNVV <- Commercial Data Customers from SAP
df_knvv = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.knvv_latest"
)
df_knvv = add_table_name(df_knvv, "KNVV")  # <- Renaming // KNVV_XXXX
# Upload Manual linked Puchase Organisation to company
df_knvv_temp = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.company_link_sales_org"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Premier Passage KNA1->KNB1->KNVV

# COMMAND ----------

# Add Company in KNVV avec table manuelle table SAP table according manual
df_join_knvv = (
    df_knvv.alias("A")
    .join(df_knvv_temp.alias("B"), f.col("A.KNVV_vkorg") == f.col("B.VKORG"), "left")
    .select(
        f.col("A.*"),
        f.col("B.BUKRS").alias("KNVV_bukrs"),
    )
)
# Join KNA1-KNB1 on Customer_Code
df_join = df_kna1.alias("A").join(
    df_knb1.alias("B"), f.col("A.KNA1_kunnr") == f.col("B.KNB1_kunnr"), "left"
)
# Add view from KNVV on Customer_Code and Company
df_join1 = df_join.alias("A").join(
    df_join_knvv.alias("B"),
    (f.col("A.KNA1_kunnr") == f.col("B.KNVV_kunnr"))
    & (f.col("A.KNB1_bukrs") == f.col("B.KNVV_bukrs")),
    "left",
)

# COMMAND ----------

# -------------------------------------------------------------------------------------------------------------------------------------  ----------------------------------

# Keep value on dataframe where all join matched
df_dataOk = df_join1.filter(f.col("KNVV_bukrs").isNotNull())

# Keep value on dataframe where KNVV value are missing for second step without last digit on supplier_code
df_missed = df_join1.filter(
    f.col("KNVV_bukrs").isNull() & f.col("KNB1_bukrs").isNotNull()
)
Begin_By = "KNVV"
df_missed = df_missed.select(
    [col for col in df_missed.columns if not col.startswith(Begin_By)]
)  # <- Drop Columns Starting by LFM
# -----------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Creation of new datframe based on KNVV table with trunc of last digit
df_knvv_new = df_join_knvv.withColumn(
    "KNVV_kunnr", f.expr("substring(KNVV_kunnr, 0, length(KNVV_kunnr)-1)")
)  # <- A revoir //////////////////////////////////////////////
df_knvv_new = df_knvv_new.dropDuplicates(
    ["KNVV_kunnr", "KNVV_bukrs", "KNVV_vkorg"]
)  # <- Cancel double generated

# Join Missing value with new KNVV
df_join2 = df_missed.alias("A").join(
    df_knvv_new.alias("B"),
    (f.col("A.KNA1_kunnr") == f.col("B.KNVV_kunnr"))
    & (f.col("A.KNB1_bukrs") == f.col("B.KNVV_bukrs")),
    "left",
)

# Add Commercial Orga. if unknown
df_join2 = (
    df_join2.alias("A")
    .join(df_knvv_temp.alias("B"), f.col("A.KNB1_bukrs") == f.col("B.BUKRS"), "left")
    .select(
        f.col("A.*"),
        f.col("B.VKORG").alias("vkorg_temp"),
    )
)
df_join3 = df_join2.withColumn(
    "KNVV_vkorg",
    f.when(f.col("KNVV_vkorg").isNull(), f.col("vkorg_temp")).otherwise(
        f.col("KNVV_vkorg")
    ),
).drop("vkorg_temp")

# Union Base Ok & new base
df_database1 = df_dataOk.unionByName(df_join3)

# COMMAND ----------

# MAGIC %md
# MAGIC #2eme Passage KNA1->KNVV->KNB1

# COMMAND ----------

# Join KNA1-KNVV on Supplier_Code
df_join = df_kna1.alias("A").join(
    df_join_knvv.alias("B"), f.col("A.KNA1_kunnr") == f.col("B.KNVV_kunnr"), "left"
)

# Add view from KNB1 on Supplier_Code and Company
df_join1 = df_join.alias("A").join(
    df_knb1.alias("B"),
    (f.col("A.KNA1_kunnr") == f.col("B.KNB1_kunnr"))
    & (f.col("A.KNVV_bukrs") == f.col("B.KNB1_bukrs")),
    "left",
)
# -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Keep value on dataframe where all join matched
df_dataOk = df_join1.filter(f.col("KNB1_bukrs").isNotNull())

# Keep value on dataframe where KNB1 value are missing for second step without last digit on supplier_code
df_missed = df_join1.filter(
    f.col("KNB1_bukrs").isNull() & f.col("KNVV_bukrs").isNotNull()
)
df_missed = df_missed.withColumn(
    "kunnr_TEMP", f.expr("substring(KNA1_kunnr, 0, length(KNA1_kunnr)-1)")
)
Begin_By = "KNB"
df_missed = df_missed.select(
    [col for col in df_missed.columns if not col.startswith(Begin_By)]
)  # <- Drop Columns Starting by LFB
# -----------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Join Missing value with new KNB1
df_join2 = df_missed.alias("A").join(
    df_knb1.alias("B"),
    (f.col("A.kunnr_TEMP") == f.col("B.KNB1_kunnr"))
    & (f.col("A.KNVV_bukrs") == f.col("B.KNB1_bukrs")),
    "left",
)
df_join2 = df_join2.drop("kunnr_TEMP")
df_join2 = df_join2.withColumn(
    "KNB1_bukrs",
    f.when(f.col("KNB1_bukrs").isNull(), f.col("KNVV_bukrs")).otherwise(
        f.col("KNB1_bukrs")
    ),
)
df_join2 = df_join2.withColumn(
    "KNB1_bukrs",
    f.when(f.col("KNB1_bukrs").isNull(), f.lit("Unknown")).otherwise(
        f.col("KNB1_bukrs")
    ),
)

# Union Base Ok & new base
df_database2 = df_dataOk.unionByName(df_join2)
df_database_end = df_database1.unionByName(df_database2)
df_database_end = df_database_end.dropDuplicates(
    (["KNA1_kunnr", "KNB1_bukrs", "KNVV_vkorg"])
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming according Header files

# COMMAND ----------

df_name_1 = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_knxx"
)
check_schema_of_the_file(df_name_1)  # <- call function Check Header files
df_name_1 = delete_null_rows(df_name_1)  # <- Call Function Delete rows null
df_column_names = rename_sap_column_names(
    df_database_end, df_name_1
)  # <- Call Function Rename Columns according header file
df = create_a_date_format_column(
    df_column_names, df_name_1
)  # <- Call Funtion Create Columns on Date format

# COMMAND ----------

# MAGIC %md
# MAGIC #Quality checks

# COMMAND ----------

# None

# COMMAND ----------

# MAGIC %md
# MAGIC #Save table

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "finance"
table = "customer_master_data_latest"

CreateSchemaIfNotExists = False

if CreateSchemaIfNotExists:
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df,
    mode="overwrite",
    overwrite_schema=True
)
