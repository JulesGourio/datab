# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to create a gold table & Gold_exposed for master data Material. It should integrate commodities information from Purchasing
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - {WRITE_ENV}_gold.master_data.material
# MAGIC   - {WRITE_ENV}_gold.master_data.material_exposed
# MAGIC
# MAGIC **Input :**
# MAGIC   - {PIPELINE_READ_ENV}_silver.master_data.material
# MAGIC   - {REFERENCE_READ_ENV}_bronze.manual_input.purchasing_taxonomy"
# MAGIC
# MAGIC **Triggered by:**
# MAGIC Notebook create_silver_master_data_material
# MAGIC
# MAGIC **Remarks:**
# MAGIC Enrichment is done form a Manual file. This is a temporary one as this information is intended to be defined in SAP.

# COMMAND ----------

# MAGIC %md
# MAGIC # Change Log
# MAGIC
# MAGIC 30Apr2025 :
# MAGIC Creation of notebook by Claire Arnoud
# MAGIC
# MAGIC adding business_id as per [PR check list - template & rules](http://confluence.lat.corp:8090/pages/viewpage.action?pageId=46273406) rule v2.1

# COMMAND ----------

# MAGIC %md
# MAGIC # Import and setup of dbutils.widgets

# COMMAND ----------

import time
import logging

from leap_utils.data_asset import table_utils

# leap logger
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# quality checks
dbutils.widgets.text("bypass_quality_checks", "false")  # history/update
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC #Log_level setup
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC # Reading Tables

# COMMAND ----------

# read silver.master_data.material
df_material = spark.read.table(f"{PIPELINE_READ_ENV}_silver.master_data.material")
# read manual file purchasing taxonomy
df_taxonomy_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.purchasing_taxonomy"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Taxonomy table
# MAGIC
# MAGIC as it will be part of
# MAGIC material master data tables , need to prefix all column with "material_"

# COMMAND ----------

dict_to_rename_taxonomy_columns = {
    "direct_indirect": "material_direct_indirect_PUR",
    "commodity": "material_commodity_PUR",
    "sub_commodity": "material_sub_commodity_PUR",
}

# COMMAND ----------

df_taxonomy = df_taxonomy_raw.withColumnsRenamed(dict_to_rename_taxonomy_columns)

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter rules From Business

# COMMAND ----------

# Application filter
# Nothing

# COMMAND ----------

# MAGIC %md
# MAGIC # Enrichment Gold
# MAGIC This enrichment comes currently from a manual file but in short  term should be setup in SAP. This is why the enrichment is already done at  gold level from a manual file

# COMMAND ----------

# joining table  purchasing taxonomy with material master to get commodities information
df_join_material = df_material.join(df_taxonomy, on=["material_group"], how="left")

# COMMAND ----------

# MAGIC %md
# MAGIC # Generating primary key
# MAGIC adding primary key  as per [PR check list - template & rules](http://confluence.lat.corp:8090/pages/viewpage.action?pageId=46273406) rule v2.1
# MAGIC
# MAGIC it should be  inherited form the silver  pk :  material_number

# COMMAND ----------

columns = df_join_material.columns
columns.remove("material_number")
new_column_order = ["material_number"] + columns
df_join_material = df_join_material.select(new_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check if pk contains nulls

# COMMAND ----------

df_to_check = df_join_material
col_to_check = "material_number"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

quality_check_results = [df_gx.expect_column_values_to_not_be_null(column=col_to_check)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"No null values found in {col_to_check}",
    error_message=f"Null values found in {col_to_check}, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="material_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###  Check if pk is unique

# COMMAND ----------

df_to_check = df_join_material
col_pk = "material_number"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

quality_check_results = [df_gx.expect_column_values_to_be_unique(column=col_pk)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique",
    error_message=f"{col_pk}(s) are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="material_gold",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "master_data"
DESTINATION_TABLE = "material"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_join_material,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_join_material.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_material_pk"
TABLE_PK_COLS = "material_number"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold exposed table

# COMMAND ----------

catalog = "gold"
domain = "master_data"
table = "material"
src_full_tablename = f"{PIPELINE_WRITE_ENV}_{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "MARA"
selected_columns = [
    col for col in df_join_material.columns if not col.startswith(Begin_By)
]
select_statement = ", ".join(selected_columns)

# COMMAND ----------

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
