# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to create a silver table for Master Data Material for  purchasing. It uses a nex sap header  file to get   MARA_maktl renamed from March_group to Material_group.
# MAGIC Original file was [data_asset/master_data/create_silver_material-master-data-basics](https://dbc-c623749d-731b.cloud.databricks.com/editor/notebooks/2236393708522655?o=2865348338307293)
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - {WRITE_ENV}_silver.master_data.material
# MAGIC
# MAGIC **Input :**
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mara_latest
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.makt_latest
# MAGIC
# MAGIC **Triggered by:**
# MAGIC  - SAP Bronze Ingestion
# MAGIC
# MAGIC **Things to do:**
# MAGIC
# MAGIC - Cleaning data
# MAGIC - Renaming Headers
# MAGIC - Add Description
# MAGIC - adding a primary key : material_number

# COMMAND ----------

# MAGIC %md
# MAGIC # Change Log
# MAGIC 30 apr 2025 Claire Arnoud:
# MAGIC
# MAGIC - Changing  f.when  with F.coalesce() to tak the first non null description  Cell 14 row 24
# MAGIC - using leap utils functions for  trim and remove zero  Cell 17
# MAGIC - as it  is a master data , columns are  prefixed with material_
# MAGIC as mentionned in [http://confluence.lat.corp:8090/display/LEAP/Master+data+refacto](http://confluence.lat.corp:8090/display/LEAP/Master+data+refacto)
# MAGIC
# MAGIC 27 May 2025
# MAGIC
# MAGIC adding pk on the dataset

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame

from leap_utils.data_asset import table_utils

import time
import logging

# leap logger
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("bypass_quality_checks", "false")  # history/update
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC #Log_level setup
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------


# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table and Renaming

# COMMAND ----------

# Upload MARA <- Master Data material from SAP
df_mara = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mara_latest"
)
df_mara = table_utils.add_prefix_to_columns(df_mara, "MARA")  # <- Renaming // MARA_XXXX

# Upload MAKT <- Material Description from SAP
df_makt = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.makt_latest"
)
df_makt = table_utils.add_prefix_to_columns(df_makt, "MAKT")  # <- Renaming // MAKT_XXXX

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming according Header files

# COMMAND ----------

## Renaming MARA -Basic Master Data from SAP
df_name_mara = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_mara_v2"
)
# Call function Check Header files
table_utils.check_schema_of_the_header_file(df_name_mara)
# Call Function Delete rows null
df_name_mara = delete_null_rows(df_name_mara)
# Call Function Rename Columns according header file
df_column_mara = table_utils.rename_columns_with_sap_business_header(
    df_mara, df_name_mara
)
# Call Funtion Create Columns on Date format
df_mara = table_utils.cast_columns_with_sap_business_headers(
    df_column_mara, df_name_mara
)
# -----------------------------------------------------------------------------------
## Renaming MAKT - Description Material from SAP
df_name_makt = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_makt"
)
# Call function Check Header files
table_utils.check_schema_of_the_header_file(df_name_makt)
# Call Function Delete rows null
df_name_makt = delete_null_rows(df_name_makt)
# Call Function Rename Columns according header file
df_column_makt = table_utils.rename_columns_with_sap_business_header(
    df_makt, df_name_makt
)
# Call Funtion Create Columns on Date format
df_makt = table_utils.cast_columns_with_sap_business_headers(
    df_column_makt, df_name_makt
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Filter on Master Data Material

# COMMAND ----------

# selection only mandant= 600 for all table
df_mara = df_mara.filter(f.col("MARA_mandt") == "600")
df_makt = df_makt.filter(f.col("MAKT_mandt") == "600")

# Exclusion Material cancelled
df_mara = df_mara.filter(f.col("MARA_lvorm").isNull())

# COMMAND ----------

# MAGIC %md
# MAGIC #Management Description of material

# COMMAND ----------

## Goal -> keep only one description for each material
# Priority is done on English language, then French then any others languages
# Creation DF for English LG
df_makt_en = df_makt.filter(f.col("makt_spras") == "E")
df_makt_en = df_makt_en.withColumnRenamed(
    "material_number", "Material_Number_en"
).withColumnRenamed("description", "Description_en")
df_makt_en = df_makt_en.select("Material_Number_en", "Description_en")
# ---------------------------------------------------------------------------
# Creation DF for French LG
df_makt_fr = df_makt.filter(f.col("makt_spras") == "F")
df_makt_fr = df_makt_fr.withColumnRenamed(
    "material_number", "Material_Number_fr"
).withColumnRenamed("description", "Description_fr")
df_makt_fr = df_makt_fr.select("Material_Number_fr", "Description_fr")
# ---------------------------------------------------------------------------
# Creation DF for others LG
df_makt_all = df_makt.select(
    f.col(
        "material_number",
    ),
    f.col("description"),
)
df_makt_all = df_makt_all.filter(f.col("Description").isNotNull())
df_makt_all = df_makt_all.dropDuplicates(["material_number"])
df_makt_all = df_makt_all.withColumnRenamed(
    "material_number", "Material_Number_all"
).withColumnRenamed("description", "Description_all")

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Basic Data & Descriptions (E/F/Others)

# COMMAND ----------

df_join_material = (
    df_mara.alias("A")
    .join(
        df_makt_en.alias("B"),
        f.col("A.material_number") == f.col("B.Material_Number_en"),
        "left",
    )
    .join(
        df_makt_fr.alias("C"),
        f.col("A.material_number") == f.col("C.Material_Number_fr"),
        "left",
    )
    .join(
        df_makt_all.alias("D"),
        f.col("A.material_number") == f.col("D.Material_Number_all"),
        "left",
    )
)
df_join_material = df_join_material.drop(
    "Material_Number_en", "Material_Number_fr", "Material_Number_all"
)
# Keep EN first, then FR, then all
df_material = df_join_material.withColumn(
    "material_description",
    f.coalesce(
        f.col("Description_en"), f.col("Description_fr"), f.col("Description_all")
    ),
)
df_material_end = df_material.drop(
    "Description_en", "Description_fr", "Description_all"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Cleasing raw data from material data asset
# MAGIC

# COMMAND ----------

# Cancel 0 on begin material_Number
df_material_end = table_utils.remove_leading_zeros(df_material_end, ["material_number"])

# trim all columns - useful for material dezcription that  can contain extra space
df_material_end = table_utils.trim_dataframe(df_material_end)

# COMMAND ----------

# MAGIC %md
# MAGIC # comparing with existing dev_silver.master_data.material_master_data_basics
# MAGIC
# MAGIC All differences are  due to the trim that is made in this dataset and not in the original one. Material description column contains some extra spaces thatare trimmed

# COMMAND ----------

# MAGIC %md
# MAGIC  df_silver_orig = spark.read.table(f"{REFERENCE_READ_ENV}_silver.master_data.material_master_data_basics")
# MAGIC  display(df_silver_orig.describe())
# MAGIC  display(df_material_end.describe())
# MAGIC  diff_df = df_material_new[["new_material_number","new_description"]].subtract(df_silver_orig[["orig_Material_Number","orig_Description"]])
# MAGIC .union(df_material_end.subtract(df_silver_orig))
# MAGIC  display(diff_df)
# MAGIC  type(diff_df)
# MAGIC  df_silver_orig= table_utils.add_prefix_to_columns(df_silver_orig,"orig")
# MAGIC  df_material_new=table_utils.add_prefix_to_columns(df_material_end,"new")
# MAGIC  diff_df2 = df_silver_orig[["orig_material_number", "orig_description"]].join(
# MAGIC  df_material_new[["new_material_number", "new_description"]],
# MAGIC  on=(f.col("orig_material_number") == f.col("new_material_number"))
# MAGIC  & (f.col("orig_description") == f.col("new_description")),
# MAGIC  how="left_anti",
# MAGIC  )
# MAGIC  diff_df3=df_silver_orig[["orig_material_number", "orig_description"]].subtract(df_material_new[["new_material_number", "new_description"]])
# MAGIC  diff_df3 = diff_df3.join(df_material_new[["new_material_number", "new_description"]], on=f.col("orig_material_number")==f.col("new_material_number"), how="left")
# MAGIC  diff_df3 = diff_df3.withColumn("orig_lenght",f.length("orig_description")).withColumn("new_lenght",f.length("new_description")).withColumn("diff",f.col("orig_lenght")-f.col("new_lenght"))

# COMMAND ----------

# MAGIC %md
# MAGIC # Creating primary key for this dataset
# MAGIC pk is  material number so no new column to be  created

# COMMAND ----------

# MAGIC %md
# MAGIC ### set 1st column as primary key

# COMMAND ----------

columns = df_material_end.columns
columns.remove("material_number")
new_column_order = ["material_number"] + columns
df_material_end = df_material_end.select(new_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check if pk contains nulls

# COMMAND ----------

df_to_check = df_material_end
col_to_check = "material_number"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

quality_check_results = [df_gx.expect_column_values_to_not_be_null(column=col_to_check)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"No null values found in {col_to_check}",
    error_message=f"Null values found in {col_to_check}, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="material_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###  Check if pk is unique

# COMMAND ----------

df_to_check = df_material_end
col_pk = "material_number"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

quality_check_results = [df_gx.expect_column_values_to_be_unique(column=col_pk)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique",
    error_message=f"{col_pk}(s) are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="material_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Silver table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "master_data"
DESTINATION_TABLE = "material"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_material_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_material_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "silver_material_pk"
TABLE_PK_COLS = "material_number"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
