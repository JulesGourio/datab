# Databricks notebook source
# MAGIC %md
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold  & Gold Exposed table for Company Master Data
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {write_env}_gold.master_data.company_master_data_latest
# MAGIC   - {write_env}_gold.master_data.company_master_data_latest_exposed
# MAGIC
# MAGIC **Input :**  
# MAGIC   - {read_env}_silver.master_data.company_master_data_latest
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC   - Create_silver_company_master_data
# MAGIC
# MAGIC **Things to do:** 
# MAGIC   - Management of Company Description and company entity

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable 
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable 
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md 
# MAGIC #Import Data-Asset silver

# COMMAND ----------

# Upload silver table for Company Master Data
df_comp = spark.read.table(
    f"{READ_ENV}_silver.master_data.company_master_data_latest"
)  

# COMMAND ----------

# MAGIC %md 
# MAGIC #Management Company Description

# COMMAND ----------

df_comp = df_comp.withColumn(
    "Company_Description",
    f.when(
        f.col("Company_description_manual").isNull() == False,
        f.col("Company_description_manual"),
    ).otherwise(f.col("Company_Description")),
)
df_comp = df_comp.withColumn(
    "Company_Entity",
    f.when(
        f.col("Company_Entity").isNull() == False, f.col("Company_Entity")
    ).otherwise(f.lit("Unknown")),
)
df_comp = df_comp.drop("Company_description_manual")

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold Company Master Data Table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "master_data"
table = "company_master_data_latest"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_comp,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold Master Data exposed table

# COMMAND ----------

catalog = "gold"
domain = "master_data"
table = "company_master_data_latest"
src_full_tablename = f"{WRITE_ENV}_{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = 'T001'
Begin_By2 = 'T005'
selected_columns = [col for col in df_comp.columns if not col.startswith(Begin_By)and not col.startswith(Begin_By2)]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
