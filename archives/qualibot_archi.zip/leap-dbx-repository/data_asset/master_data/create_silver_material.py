# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # [SILVER - MATERIAL DATABASE]
# MAGIC
# MAGIC **Summary:**  
# MAGIC This notebook focuses on building a silver table for Master Data Material.  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for Master Data Material.  
# MAGIC This reference material table ensures the quality, consistency, and performance of material data throughout the entire company.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - W_1_SAP_Master_Data_Material-Asset
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mara_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.makt_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ausp_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cawn_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cawnt_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_mara  
# MAGIC - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_makt
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {REFERENCE_READ_ENV}_silver.master_data.material_basis

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
import time


# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC

# COMMAND ----------

# Utils imports
from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments

# COMMAND ----------

# Get read environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("bypass_quality_checks", "false")  # history/update
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

log = setup_applevel_logger(log_level=LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import MARA (SAP)
# MAGIC
# MAGIC **df_mara_raw** General Material Data  
# MAGIC It contains general data about a material that does not depend on the organization (such as company or plant) or storage level.

# COMMAND ----------

df_mara_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mara_latest")
df_mara_header = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_mara")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import MAKT (SAP)
# MAGIC
# MAGIC **df_makt_raw** Material Descriptions  
# MAGIC This table contains material descriptions in different languages. It is linked to the MARA table by the material number (MATNR).

# COMMAND ----------

df_makt_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.makt_latest")
df_makt_header = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_makt")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import AUSP (SAP)
# MAGIC
# MAGIC **df_ausp_raw** Characteristic Values  
# MAGIC The AUSP table stores characteristic values for objects that are classified using the SAP classification system (CL01, CL02, CL03 for classes; CT04 for characteristics).

# COMMAND ----------

df_ausp_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ausp_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import CAWN (SAP)
# MAGIC
# MAGIC **df_cawn_raw** Characteristic Values  
# MAGIC This table contains the allowed (possible) values for a characteristic defined in AUSP.

# COMMAND ----------

df_cawn_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cawn_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import CAWNT (SAP)
# MAGIC
# MAGIC **df_cawnt_raw** Characteristic Values
# MAGIC It contains the descriptive texts (labels) of characteristic values, in multiple languages.

# COMMAND ----------

df_cawnt_raw = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cawnt_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Renaming of Columns to include table suffix in name
# MAGIC
# MAGIC In this section we want to add the table prefix to the columns as later in the joins there will be duplicate column names AND we will need to know which table the column came from

# COMMAND ----------

# MAGIC %md
# MAGIC #### Preparation 1.1 - Renaming MARA Table

# COMMAND ----------

df_mara = table_utils.add_prefix_to_columns(df_mara_raw, "MARA")
# Call Function Delete rows null
df_name_mara = delete_null_rows(df_mara_header)
# Call Function Rename Columns according header file
df_column_mara = table_utils.rename_columns_with_sap_business_header(
    df_mara, df_name_mara
)
# Call Funtion Create Columns on Date format
df_mara = table_utils.cast_columns_with_sap_business_headers(
    df_column_mara, df_name_mara
)
#---------------------------------------------------------------------
# Keep Only Material active
df_mara = df_mara.filter(f.col("MARA_lvorm").isNull())

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Preparation 1.2 - Renaming MAKT Table

# COMMAND ----------

df_makt = table_utils.add_prefix_to_columns(df_makt_raw, "MAKT")
# Call Function Delete rows null
df_name_makt = delete_null_rows(df_makt_header)
# Call Function Rename Columns according header file
df_column_makt = table_utils.rename_columns_with_sap_business_header(
    df_makt, df_name_makt
)
# Call Funtion Create Columns on Date format
df_makt = table_utils.cast_columns_with_sap_business_headers(
    df_column_makt, df_name_makt
)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Preparation 1.3 - Renaming AUSP Table

# COMMAND ----------

df_ausp = table_utils.add_prefix_to_columns(df_ausp_raw, "AUSP")

df_ausp_selected = df_ausp.select(
    f.col("AUSP_objek").alias("material_number"),
    f.col("AUSP_klart").alias("category_class"),
    f.col("AUSP_atinn").alias("caracteristic"),
    f.col("AUSP_atwrt").alias("caracteristic_value"),
)

# Filter only on material cassification (kart = 001) and special caracteristics :
# "0000000253": "manuf_process" / "0000000255": "Assembly_level" / "0000000256": "raw_mat"
# "0000000266": "familly_std" / "0000000268": "classe_std" / "0000000331": "familly_manuf"
# "0000000250": "manuf_type" / "0000000254": "material_size" /

classif_atinn = [
    "0000000253",
    "0000000255",
    "0000000256",
    "0000000266",
    "0000000268",
    "0000000331",
    "0000000250",
    "0000000254",
]
df_ausp_filtered = df_ausp_selected.filter(
    (f.col("category_class") == "001") & (f.col("caracteristic").isin(classif_atinn))
)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Preparation 1.3 - Renaming CAWN Table

# COMMAND ----------

df_cawn = table_utils.add_prefix_to_columns(df_cawn_raw, "CAWN")

df_cawn_selected = df_cawn.select(
    f.col("CAWN_atinn").alias("caracteristic"),
    f.col("CAWN_atzhl").alias("internal_counter_value"),
    f.col("CAWN_atwrt").alias("caracteristic_value"),
)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Preparation 1.4 - Renaming CAWNT Table

# COMMAND ----------

df_cawnt = table_utils.add_prefix_to_columns(df_cawnt_raw, "CAWNT")
df_cawnt_selected = df_cawnt.select(
    f.col("CAWNT_atinn").alias("caracteristic"),
    f.col("CAWNT_spras").alias("language"),
    f.col("CAWNT_atzhl").alias("internal_counter_value"),
    f.col("CAWNT_atwtb").alias("internal_counter"),
).filter(f.col("language") == "E")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transf. 1 # Management Description of material
# MAGIC
# MAGIC Keep only one description for each material  
# MAGIC Priority is done on English language, then French then any others languages

# COMMAND ----------

# Creation DataFrame for English Language
df_makt_en = df_makt.filter(f.col("makt_spras") == "E")
df_makt_en = df_makt_en.withColumnRenamed("material_description", "material_description_en")
df_makt_en = df_makt_en.select("material_number", "material_description_en")
# ---------------------------------------------------------------------------
# Creation DataFrame for French Language
df_makt_fr = df_makt.filter(f.col("makt_spras") == "F")
df_makt_fr = df_makt_fr.withColumnRenamed("material_description", "material_description_fr")
df_makt_fr = df_makt_fr.select("material_number", "material_description_fr")
# ---------------------------------------------------------------------------
# Creation DataFrame for others Language
df_makt_all = df_makt.filter((f.col("makt_spras") != "F")&(f.col("makt_spras") != "E"))
df_makt_all = df_makt_all.filter(f.col("material_description").isNotNull())
df_makt_all = df_makt_all.dropDuplicates(["material_number"])
df_makt_all = df_makt_all.withColumnRenamed("material_description", "material_description_all")
# ---------------------------------------------------------------------------

# COMMAND ----------

# Join Basic Data & Descriptions (E/F/Others)
df_join_material = (df_mara.join(
        df_makt_en,["material_number"],"left").join(df_makt_fr,["material_number"],"left").join(
        df_makt_all,["material_number"],"left")
    )
# Keep EN first, then FR, then all using coalesce to display
df_material = df_join_material.withColumn(
    "material_description",
    f.coalesce(
        f.col("material_description_en"),
        f.col("material_description_fr"),
        f.col("material_description_all")
    ),
).drop(
    "material_description_en", "material_description_fr", "material_description_all"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transf.2 # Management Parts Classification
# MAGIC
# MAGIC Add classification on Material Dataframe

# COMMAND ----------

caracteristic_map = {
    "0000000253": "manuf_process",
    "0000000255": "assembly_level",
    "0000000256": "raw_mat",
    "0000000266": "familly_std",
    "0000000268": "classe_std",
    "0000000331": "familly_manuf",
    "0000000254": "material_size",
    "0000000250": "manuf_type",
}
df_caracteristic = df_ausp_filtered.join(
    df_cawn_selected, ["caracteristic", "caracteristic_value"], "left"
).join(df_cawnt_selected, ["caracteristic", "internal_counter_value"], "left")
df_caracteristic = df_caracteristic.withColumn(
    "carac_value",
    f.concat_ws(" - ", f.col("caracteristic_value"), f.col("internal_counter")),
)

df_caracteristic_pivot = (
    df_caracteristic.groupBy("material_number")
    .pivot("caracteristic", list(caracteristic_map.keys()))
    .agg(f.first("carac_value"))
)

for code, name in caracteristic_map.items():
    df_caracteristic_pivot = df_caracteristic_pivot.withColumnRenamed(code, name)

# ---------------------------------------------------------------------------------
# Join Base with Caracteristics
df_material_join = df_material.join(df_caracteristic_pivot, ["material_number"], "left")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Transf. 3 # Cleaning Base

# COMMAND ----------

# Cancel 0 on begin material_Number
df_material_end = table_utils.remove_leading_zeros(df_material_join, ["material_number"])

# trim all columns - useful for material description that can contain extra space
df_material_end = table_utils.trim_dataframe(df_material_end)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_material_end = df_material_end.withColumn(
    "material_number_id", f.col("material_number")
)
columns = df_material_end.columns
columns.remove("material_number_id")
new_column_order = ["material_number_id"] + columns
df_material_end = df_material_end.select(new_column_order)

# COMMAND ----------

df_to_check = df_material_end
col_pk = "material_number_id"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"No null values found in {col_pk}",
    error_message=f"Null values found in {col_pk}, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="material_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Silver Table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "master_data"
DESTINATION_TABLE = "material"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_material_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_material_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "silver_material_pk"
TABLE_PK_COLS = "material_number_id"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
