# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a Gold & Gold Exposed table for Plant Master Data. 
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {write_env}_gold.plant_master_data
# MAGIC   - {write_env}_gold.plant_master_data_explosed
# MAGIC   
# MAGIC **Intput :**  
# MAGIC   - {read_env}_silver.master_data.plant_master_data  
# MAGIC   - prod_bronze.manual_input.plant_description  
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC   Notebook create_silver_plant_master_data
# MAGIC   
# MAGIC **Things to do:**  
# MAGIC  - Add manual Description  
# MAGIC  - Add Branch  

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable 
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable 
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC # Extraction & join Tables 

# COMMAND ----------

# Upload Silver Plant Master Data
df_plant = spark.read.table(
    f"{READ_ENV}_silver.master_data.plant_master_data_latest"
)  
# Upload Manual Plant Description
df_manual_plant = spark.read.table(
    "prod_bronze.manual_input.plant_description"
)  

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Silver Table with Manual Plant Description

# COMMAND ----------

df_join = (
    df_plant.alias("A")
    .join(df_manual_plant.alias("B"), f.col("A.Plant") == f.col("B.Plant_Div"), "Left")
    .drop("Plant_Div")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Gold enrichment

# COMMAND ----------

# Branch Affectation
df_end = df_join.withColumn(
    "Branch", f.when((f.substring(f.col("Plant"), 0, 1) == "2"), "IS").otherwise("AS")
)  

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "master_data"
table = "plant_master_data_latest"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_end,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold exposed table

# COMMAND ----------

catalog = "gold"
domain = "master_data"
table = "plant_master_data_latest"
src_full_tablename = f"{WRITE_ENV}_{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "T001"
selected_columns = [col for col in df_join.columns if not col.startswith(Begin_By)]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
