# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # [GOLD - MATERIAL DATABASE]
# MAGIC
# MAGIC **Summary:**  
# MAGIC This notebook focuses on building a gold table for Master Data Material.  
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table for Master Data Material.  
# MAGIC This reference material table ensures the quality, consistency, and performance of material data throughout the entire company.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - W_1_SAP_Master_Data_Material-Asset  
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC - {REFERENCE_READ_ENV}_silver.master_data.material
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {REFERENCE_READ_ENV}_gold.master_data.material

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
import time

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC

# COMMAND ----------

# Utils imports
from leap_utils.data_asset import table_utils
from leap_utils.common.logger import LOGGER_MAPPING, setup_applevel_logger

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments

# COMMAND ----------

# Get read environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("bypass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

log = setup_applevel_logger(log_level=LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - SAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Bronze - Commodity
# MAGIC
# MAGIC **df_bronze_commodity** Manual Commodity  

# COMMAND ----------

df_bronze_commodity = spark.read.table(f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.zmmproccommod_latest")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Silver Material LEAP Table  
# MAGIC
# MAGIC **df_silver_material** General Material Data  

# COMMAND ----------

df_silver_material = spark.read.table(f"{PIPELINE_READ_ENV}_silver.master_data.material")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 - Commodity selection

# COMMAND ----------

df_commodity_prepared = df_bronze_commodity.select(
    f.col("matkl").alias("material_group"), "commodity_l1", "commodity_l2"
).dropDuplicates()


# in case of several comodity exist for un material group, we keep the first one found
df_commodity_prepared = df_commodity_prepared.groupBy("material_group").agg(
    f.first("commodity_l1").alias("commodity"),
    f.first("commodity_l2").alias("sub_commodity"),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 1 - Add Commodity to material Base

# COMMAND ----------

df_gold_material = df_silver_material.join(
    df_commodity_prepared, ["material_group"], "left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality check

# COMMAND ----------

columns = df_gold_material.columns
columns.remove("material_number_id")
new_column_order = ["material_number_id"] + columns
df_gold_material = df_gold_material.select(new_column_order)

# COMMAND ----------

df_to_check = df_gold_material
col_to_check = "material_number_id"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_to_check),
    df_gx.expect_column_values_to_be_unique(column=col_to_check),
]
gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"No null values found in {col_to_check}",
    error_message=f"Null values found in {col_to_check}, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="material_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Gold Table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "master_data"
DESTINATION_TABLE = "material"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_gold_material,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_gold_material.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_material_pk"
TABLE_PK_COLS = "material_number_id"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ###Save Gold exposed table

# COMMAND ----------

catalog = "gold"
domain = "master_data"
table = "material"
src_full_tablename = f"{PIPELINE_WRITE_ENV}_{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "MARA"
Begin_By2 = "MAKT"
selected_columns = [
    col
    for col in df_gold_material.columns
    if not col.startswith(Begin_By) and not col.startswith(Begin_By2)
]
select_statement = ", ".join(selected_columns)
# --------------------------------------------------------------------------------
table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
