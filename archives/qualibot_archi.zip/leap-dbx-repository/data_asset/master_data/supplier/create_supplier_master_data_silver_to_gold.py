# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Gold Supplier Master Data
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table & Gold_exposed for Supplier Master data.
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.master_data.supplier
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.master_data.supplier_exposed  
# MAGIC
# MAGIC **Input :**  
# MAGIC   - {REFERENCE_READ_ENV}_silver.master_data.supplier
# MAGIC   - {REFERENCE_READ_ENV}_bronze.manual_input.supplier_category_sap  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ausp_latest
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t024_latest
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Notebook create_silver_supplier-master-data  
# MAGIC
# MAGIC **Things to do:** 
# MAGIC - Add Supplier Category from manual input
# MAGIC - Add is_supplier_a_distributor from SAP ausp
# MAGIC - Add supplier_GCL_full_name from SAP t024  
# MAGIC - Add information for SOTD Calculation  
# MAGIC - Derive indicator columns: is_supplier_a_distributor, supplier_GCL_full_name

# COMMAND ----------

# MAGIC %md
# MAGIC # Technical Debt
# MAGIC - Enrichement from bronze table ( AUSP and T024 ) to be added in silver layer instead.
# MAGIC - Enrichement done in gold layer from a manual input to be reviewed
# MAGIC - Enrichement with company gold done in silver to be reviewed

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils

from leap_utils.common import logger
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

#dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Quality checks
dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not.
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Input LEAP table

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import silver supplier_latest

# COMMAND ----------

df_database = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.master_data.supplier"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Gold Stack Purchase order & Purchase Requests to determine active Supplier

# COMMAND ----------

df_popr = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.supply_chain_ordering.purchase_orders_sap_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extraction Manual input for determination Supplier category

# COMMAND ----------

df_supplier = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.supplier_category_sap"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extract SAP AUSP raw data for supplier caracteristic

# COMMAND ----------

df_ausp_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.ausp_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extract SAP cawnt raw data for link caracteristic description

# COMMAND ----------

df_cawn_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cawn_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extract SAP cawnt raw data for caracteristic description

# COMMAND ----------

df_cawnt_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.cawnt_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extract SAP T024 raw data for supplier GCL name

# COMMAND ----------

df_t024_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t024_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 1 - AUSP data: Characteristic Values

# COMMAND ----------

# Filter on class_type_|_KLART = 010 and characteristic_value_|_ATWRT = R
df_ausp = df_ausp_raw.filter(
    (f.col("klart") == "010") & (f.col("atwrt") == "R"),
).withColumn("is_supplier_a_distributor", f.lit(True))
df_ausp = df_ausp.select(
    f.col("objek").alias("Supplier_Code"), "is_supplier_a_distributor"
).drop_duplicates(["Supplier_Code"])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 2 - CAWNT data: Characteristic Description

# COMMAND ----------

df_cawn = df_cawn_raw.select("atinn", "atzhl", "atwrt")
df_cawn = table_utils.remove_leading_zeros(df_cawn, ["atinn"])
df_cawnt = df_cawnt_raw.filter(
    (f.col("spras") == "E") | (f.col("spras") == "F")
).select("atinn", "atzhl", "atwtb", "spras")
df_cawnt = table_utils.remove_leading_zeros(df_cawnt, ["atinn"])

# ---------------------------------------------------------------------------------------
# Prioritize English, then French, and remove duplicates
window_spec = Window.partitionBy("atinn", "atzhl").orderBy(
    f.when(f.col("spras") == "E", 0).when(f.col("spras") == "F", 1)
)
df_cawnt = (
    df_cawnt.withColumn("row_num", f.row_number().over(window_spec))
    .filter(f.col("row_num") == 1)
    .drop("row_num")
)

df_cawn_prepared = df_cawn.join(df_cawnt, ["atinn", "atzhl"], "left").drop(
    "atzhl", "spras"
)
# ---------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 3 - Characteristic Values to identify SOTD parameters

# COMMAND ----------

# In SAP table ausp keep only user specified values in column "atinn" == OTD_COLLABORATION"
df_supplier_otd_raw = table_utils.remove_leading_zeros(df_ausp_raw,["atinn"])
#-------------------------------------------------------------------------------------------
list_collab = ["442", "443", "444", "445", "446"]
df_supplier_otd = (
    df_supplier_otd_raw.select(f.col("objek").alias("supplier_code"), "atinn", "klart", "atwrt", "atflv")
    .filter(f.col("klart") == "010")  # Supplier Classification
    .filter(f.col("atinn").isin(list_collab))
)
#-------------------------------------------------------------------------------------------
df_supplier_otd = (
    df_supplier_otd.withColumn(
        "limit_neg_OTD",
        f.when(f.col("atinn") == "445", f.col("atflv").cast("double")).otherwise(
            f.lit(None)
        ),
    )
    .withColumn(
        "limit_pos_OTD",
        f.when(f.col("atinn") == "446", f.col("atflv").cast("double")).otherwise(
            f.lit(None)
        ),
    )
    .withColumn(
        "KCP", f.when(f.col("atinn") == "443", f.col("atwrt")).otherwise(None)
    )
    .withColumn(
        "SQAL", f.when(f.col("atinn") == "442", f.col("atwrt")).otherwise(None)
    )
    .withColumn(
        "collabored_OTD",
        f.when(f.col("atinn") == "444", f.col("atwrt")).otherwise(None),
    )
    .drop("atinn", "atwrt", "atflv", "klart")
)
#-------------------------------------------------------------------------------------------
# Use group by to aggregate all information for each supplier into one row.
df_supplier_otd = df_supplier_otd.groupBy("supplier_code").agg(
    f.first("limit_neg_OTD", ignorenulls=True).alias("limit_neg_OTD"),
    f.first("limit_pos_OTD", ignorenulls=True).alias("limit_pos_OTD"),
    f.first("KCP", ignorenulls=True).alias("KCP"),
    f.first("SQAL", ignorenulls=True).alias("SQAL"),
    f.first("collabored_OTD", ignorenulls=True).alias("collabored_OTD"),
)
#-------------------------------------------------------------------------------------------
# A column for the user to retrieve whether supplier information is recorded in SAP.
df_supplier_otd = df_supplier_otd.withColumn(
    "is_supplier_valid_for_OTD",
    f.when(
        (f.col("KCP").isNull())
        | (f.col("collabored_OTD").isNull())
        | (f.col("SQAL").isNull()),
        f.lit(False),
    )
    .when(
        f.col("collabored_OTD") == "Y",
        (f.col("limit_neg_OTD").isNotNull()) & (f.col("limit_pos_OTD").isNotNull()),
    )
    .otherwise(f.lit(True)),
)
#-------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 4 - Characteristic Values to identify Supplier Caracteristics

# COMMAND ----------

# -------------------------------------------------------------------------------
# 113 - Latecoere agreement             // 114 - Latecoere agreement date      //
# 116 - Certificate 9100                // 117 - EN9100 certificate limit date //
# 118 - AS9100 certificate limit date   // 119 - BS9100 certificate limit date //
# 375 - Supplier performance            // 460 - Merchandise group             //
# -------------------------------------------------------------------------------
list_carac_frn = ["113", "114", "116", "117", "118", "119", "375", "460"]
df_supplier_carac = (
    df_supplier_otd_raw.select(
        f.col("objek").alias("supplier_code"), "atinn", "klart", "atwrt", "atflv"
    )
    .filter(f.col("klart") == "010")  # Supplier Classification
    .filter(f.col("atinn").isin(list_carac_frn))
)
df_supplier_carac = df_supplier_carac.join(df_cawn_prepared, ["atinn", "atwrt"], "left")
# -------------------------------------------------------------------------------
# Conversion of atflv to date:
# atflv is in scientific notation (e.g., 2.0180914E+07 = 20180914)
# -> cast to double -> cast to long -> cast to string -> to_date yyyyMMdd
df_supplier_carac = df_supplier_carac.withColumn(
    "atflv",
    f.when(
        f.col("atflv").cast("double") > 0,
        f.to_date(
            f.col("atflv").cast("double").cast("long").cast("string"), "yyyyMMdd"
        ),
    ),
)
# -------------------------------------------------------------------------------
df_supplier_carac_tmp = (
    df_supplier_carac.withColumn(
        "latecoere_agreement",
        f.when(f.col("atinn") == "113", f.col("atwtb")).otherwise(f.lit(None)),
    )
    .withColumn(
        "latecoere_agreement_date",
        f.when(f.col("atinn") == "114", f.col("atflv")).otherwise(f.lit(None)),
    )
    .withColumn(
        "certificat_9100",
        f.when(f.col("atinn") == "116", f.col("atwtb")).otherwise(None),
    )
    .withColumn(
        "date_limit_certificat_1",
        f.when(f.col("atinn") == "117", f.col("atflv")).otherwise(None),
    )
    .withColumn(
        "date_limit_certificat_2",
        f.when(f.col("atinn") == "118", f.col("atflv")).otherwise(None),
    )
    .withColumn(
        "date_limit_certificat_3",
        f.when(f.col("atinn") == "119", f.col("atflv")).otherwise(None),
    )
    .withColumn(
        "perfo_supplier",
        f.when(f.col("atinn") == "375", f.col("atwtb")).otherwise(None),
    )
    .withColumn(
        "merchandise_group",
        f.when(f.col("atinn") == "460", f.col("atwrt")).otherwise(None),
    )
)
# -------------------------------------------------------------------------------------------
# Use group by to aggregate all information for each supplier into one row.
df_supplier_carac_tmp = df_supplier_carac_tmp.groupBy("supplier_code").agg(
    f.first("latecoere_agreement", ignorenulls=True).alias("latecoere_agreement"),
    f.first("latecoere_agreement_date", ignorenulls=True).alias(
        "latecoere_agreement_date"
    ),
    f.first("certificat_9100", ignorenulls=True).alias("certificat_9100"),
    f.first("perfo_supplier", ignorenulls=True).alias("perfo_supplier"),
    f.first("merchandise_group", ignorenulls=True).alias("merchandise_group"),
    f.first("date_limit_certificat_1", ignorenulls=True).alias(
        "date_limit_certificat_1"
    ),
    f.first("date_limit_certificat_2", ignorenulls=True).alias(
        "date_limit_certificat_2"
    ),
    f.first("date_limit_certificat_3", ignorenulls=True).alias(
        "date_limit_certificat_3"
    ),
)
df_supplier_carac_end = (
    df_supplier_carac_tmp.withColumn(
        "date_limit_certificat",
        f.when(f.col("certificat_9100") == "EN9100", f.col("date_limit_certificat_1"))
        .when(f.col("certificat_9100") == "AS9100", f.col("date_limit_certificat_2"))
        .when(f.col("certificat_9100") == "BS9100", f.col("date_limit_certificat_3"))
        .otherwise(None),
    )
).drop("date_limit_certificat_1", "date_limit_certificat_2", "date_limit_certificat_3")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 5 - Keep Only Supplier Code with Purchase orders to manage SOTD

# COMMAND ----------

df_popr_temp = df_popr.filter((f.col("PO_creation_date") > f.current_date() - 720))
# Take only these kind of Purchase Orders
list_po = ["NB", "ZOTH", "ZEDI"]
df_popr_temp = df_popr_temp.filter(f.col("PO_type").isin(list_po))
# ---------------------------------------------------------------------------
# Exclusion Free Item -- Except For KAL Supplier
df_popr_temp = df_popr_temp.filter(
    (f.col("net_order_price_per_price_base_in_EUR_budget") != "0")
    | (f.col("supplier_code") == "F01286A")
)
# ---------------------------------------------------------------------------
# Exclusion Item Without Part Number not Link to a work order
df_popr_temp = df_popr_temp.filter(
    f.col("material_number").isNotNull() | f.col("WO_number").isNotNull()
)

df_popr_temp = df_popr_temp.select("supplier_code").distinct()
df_popr_prepared = df_popr_temp.withColumn("is_supplier_active_for_OTD", f.lit(True))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prep. 6 - Select purchasing group id and purchasing group name as a concatanation of id and name

# COMMAND ----------

df_t024_prepared = df_t024_raw.select(
    f.col("ekgrp").alias("purchasing_group"),
    f.concat(
        f.col("ekgrp"),
        f.lit(" - "),
        f.coalesce(
            f.initcap(
                f.regexp_replace(f.split(f.col("smtp_addr"), "@")[0], "\\.", " ")
            ),
            f.col("eknam"),
        ),
    ).alias("supplier_GCL_full_name"),
).drop_duplicates(["purchasing_group"])

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr 1 - Enrich information for Supplier
# MAGIC
# MAGIC - Add Supplier_Category according manual table for Supplier category link to KTOKK
# MAGIC - Add is_supplier_a_distributor from SAP ausp
# MAGIC - Add is_supplier_active
# MAGIC - Add is_supplier_valid_for_OTD
# MAGIC - Add supplier_GCL_full_name from SAP t024

# COMMAND ----------

df_join = (
    df_database.alias("A")
    .join(df_supplier.alias("B"), f.col("A.LFA1_ktokk") == f.col("B.ktokk"), "left")
    .select(
        f.col("A.*"),
        f.col("B.Supplier_Category").alias("supplier_category"),
    )
    .join(df_ausp, "supplier_code", "left")
    .join(df_supplier_otd, "supplier_code", "left")
    .join(df_popr_prepared, "supplier_code", "left")
    .join(df_t024_prepared, "purchasing_group", "left")
    .join(df_supplier_carac_end, "supplier_code", "left")
)
df_join = df_join.withColumn(
    "is_supplier_active_for_OTD",f.coalesce(f.col("is_supplier_active_for_OTD"), f.lit(False))
).withColumn(
    "is_supplier_valid_for_OTD",f.coalesce(f.col("is_supplier_valid_for_OTD"), f.lit(False))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 2 - Calculate indicators

# COMMAND ----------

df_enriched = df_join.withColumn(
    "is_supplier_a_distributor",
    f.when(f.col("is_supplier_a_distributor"), True).otherwise(False),
)

# Derive indicator columns
df_enriched = df_enriched.withColumn(
    "is_automatic_generation_of_purchase_allowed_for_supplier",
    f.when(
        f.col("automatic_generation_of_purchase_allowed_for_supplier") == "X", True
    ).otherwise(False),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr. 3 - Drop duplicate supplier_code

# COMMAND ----------

df_enriched_w_pk = df_enriched.withColumn(
    "supplier_company_id",
    f.concat(f.col("supplier_code"), f.lit("-"), f.col("company_code")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality Check

# COMMAND ----------

df_to_check = df_enriched_w_pk
col_pk = "supplier_company_id"
validation_level = "RED"

if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"
df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_pk),
    df_gx.expect_column_values_to_be_unique(column=col_pk),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique and not null",
    error_message="Quality checks failed for po_with_exceptions table, please check log messages",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="proj_po_with_exceptions",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - supplier

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_gold"
domain = "master_data"
table = "supplier"

DESTINATION_TABLE_FULL_PATH = f"{catalog}.{domain}.{table}"
TABLE_CONSTRAINT_NAME = "supplier_PK"
TABLE_PK_COLS = col_pk

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_to_check,
    mode="overwrite",
    overwrite_schema=True,
)

# COMMAND ----------

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{catalog}' and table_SCHEMA='{domain}' and table_name='{table}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - supplier_exposed

# COMMAND ----------

src_full_tablename = f"{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "LF"
selected_columns = [col for col in df_enriched.columns if not col.startswith(Begin_By)]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
