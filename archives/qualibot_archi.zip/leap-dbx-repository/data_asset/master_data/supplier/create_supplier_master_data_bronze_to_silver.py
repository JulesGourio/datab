# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Silver Supplier Master Data
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for Supplier Master Data  
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {PIPELINE_WRITE_ENV}_silver.master_data.supplier
# MAGIC   
# MAGIC **Input :**  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.lfa1_latest  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.lfb1_latest  
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.lfm1_latest 
# MAGIC   - {REFERENCE_READ_ENV}_gold.master_data.company_master_data_latest_exposed
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC  - SAP Bronze Ingestion  
# MAGIC  
# MAGIC **Things to do:** 
# MAGIC
# MAGIC - Cleaning data
# MAGIC - Renaming Headers
# MAGIC - Join Company Master Data

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame

from leap_utils.data_asset import table_utils

from leap_utils.common import logger

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments
# MAGIC
# MAGIC - PIPELINE_WRITE_ENV -> Used for specifying which catalog environment the script should write data to, NOTE by definition any writing table would mean it is part of the same "pipeline"
# MAGIC - PIPELINE_READ_ENV -> Used for specifying which catalog environment the upstream pipeline data is in.
# MAGIC - REFERENCE_READ_ENV -> Used for specifying which catalog environment that non-pipeline "reference" data is in (generally used in enrichments).

# COMMAND ----------

#dbutils.widgets.removeAll()

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# Quality checks
dbutils.widgets.text("by_pass_quality_checks", "false")
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("by_pass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not.
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook

# COMMAND ----------

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

dbutils.widgets.dropdown("log_level", defaultValue="info", choices=["debug", "info", "warning", "error", "critical"])
LOG_LEVEL = dbutils.widgets.get("log_level")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config logger

# COMMAND ----------

log = logger.setup_applevel_logger(log_level=logger.LOGGER_MAPPING[LOG_LEVEL])

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

#Check Header from Manual Input file 
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ['Table_name', 'Field', 'Business_name', 'Format']:
        print('Correct schema')
    else:
        raise Exception(f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format") 

# COMMAND ----------

#Delete rows when field is null 
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col('Field').isNotNull() == True)
    return df_names_new   

# COMMAND ----------

# MAGIC %md
# MAGIC ## Input LEAP table

# COMMAND ----------

# MAGIC %md
# MAGIC ### LFA1 <- Master Data suppliers from SAP

# COMMAND ----------

df_lfa1 = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.lfa1_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### LFB1 <- Company Data suppliers from SAP

# COMMAND ----------

df_lfb1 = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.lfb1_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### LFA1 <- Purchasing Data suppliers from SAP

# COMMAND ----------

df_lfm1 = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.lfm1_latest"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Gold Company Master-Data

# COMMAND ----------

df_comp = spark.read.table(
    f"{PIPELINE_READ_ENV}_gold.master_data.company_master_data_latest_exposed"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1: Renaming // LFA1_XXXX

# COMMAND ----------

df_lfa1 = table_utils.add_prefix_to_columns(df_lfa1, "LFA1")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 2: Renaming // LFB1_XXXX

# COMMAND ----------

df_lfb1 = table_utils.add_prefix_to_columns(df_lfb1, "LFB1")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 3: Renaming // LFM1_XXXX

# COMMAND ----------

df_lfm1 = table_utils.add_prefix_to_columns(df_lfm1, "LFM1")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 1: Premier Passage LFA1->LFB1->LFM1

# COMMAND ----------

# Add Company in LFM with Company master Data
df_join_lfm1 = (
    df_lfm1.alias("A")
    .join(
        df_comp.alias("B"),
        f.col("A.LFM1_ekorg") == f.col("B.Purchase_Organization"),
        "left",
    )
    .select(
        f.col("A.*"),
        f.col("B.Company").alias("LFM1_bukrs"),
    )
)
# Join LFA1-LFB1 on Supplier_Code
df_join = df_lfa1.alias("A").join(
    df_lfb1.alias("B"), f.col("A.LFA1_lifnr") == f.col("B.LFB1_lifnr"), "left"
)
# Add view from LFM1 on Supplier_Code and Company
df_join1 = df_join.alias("A").join(
    df_join_lfm1.alias("B"),
    (f.col("A.LFA1_lifnr") == f.col("B.LFM1_lifnr"))
    & (f.col("A.LFB1_bukrs") == f.col("B.LFM1_bukrs")),
    "left",
)

# COMMAND ----------

# Keep value on dataframe where all join matched
df_dataOk = df_join1.filter(f.col("LFM1_bukrs").isNotNull())

# Keep value on dataframe where LFM1 value are missing for second step without last digit on supplier_code
df_missed = df_join1.filter(
    f.col("LFM1_bukrs").isNull() & f.col("LFB1_bukrs").isNotNull()
)
# Drop Columns Starting by LFM
Begin_By = "LFM"
df_missed = df_missed.select(
    [col for col in df_missed.columns if not col.startswith(Begin_By)]
)

# COMMAND ----------

# Creation of new datframe based on LFM1 table with trunc of last digit
df_lfm1_new = df_join_lfm1.withColumn(
    "LFM1_lifnr", f.expr("substring(LFM1_lifnr, 0, length(LFM1_lifnr)-1)")
)
# Cancel double generated
df_lfm1_new = df_lfm1_new.dropDuplicates(["LFM1_lifnr", "LFM1_bukrs", "LFM1_ekorg"])

# Join Missing value with new LFM1
df_join2 = df_missed.alias("A").join(
    df_lfm1_new.alias("B"),
    (f.col("A.LFA1_lifnr") == f.col("B.LFM1_lifnr"))
    & (f.col("A.LFB1_bukrs") == f.col("B.LFM1_bukrs")),
    "left",
)

# Add Purch. Orga if unknown
df_join2 = (
    df_join2.alias("A")
    .join(
        df_comp.alias("B"),
        f.col("A.LFB1_bukrs") == f.col("B.Purchase_Organization"),
        "left",
    )
    .select(
        f.col("A.*"),
        f.col("B.Purchase_Organization").alias("ekorg_temp"),
    )
)

df_join3 = df_join2.withColumn(
    "LFM1_ekorg",
    f.when(f.col("LFM1_ekorg").isNull(), f.col("ekorg_temp")).otherwise(
        f.col("LFM1_ekorg")
    ),
).drop("ekorg_temp")

# COMMAND ----------

# Union Base Ok & new base
df_database1 = df_dataOk.unionByName(df_join3)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 2: 2eme Passage LFA1->LFM1->LFB1

# COMMAND ----------

# Join LFA1-LFM1 on Supplier_Code
df_join_ = df_lfa1.alias("A").join(
    df_join_lfm1.alias("B"), f.col("A.LFA1_lifnr") == f.col("B.LFM1_lifnr"), "left"
)

# Add view from LFB1 on Supplier_Code and Company
df_join1_ = df_join_.alias("A").join(
    df_lfb1.alias("B"),
    (f.col("A.LFA1_lifnr") == f.col("B.LFB1_lifnr"))
    & (f.col("A.LFM1_bukrs") == f.col("B.LFB1_bukrs")),
    "left",
)

# COMMAND ----------

# Keep value on dataframe where all join matched
df_dataOk_ = df_join1_.filter(f.col("LFB1_bukrs").isNotNull())

# Keep value on dataframe where LFB1 value are missing for second step without last digit on supplier_code
df_missed_ = df_join1_.filter(
    f.col("LFB1_bukrs").isNull() & f.col("LFM1_bukrs").isNotNull()
)
df_missed_ = df_missed_.withColumn(
    "LIFNR_TEMP", f.expr("substring(LFA1_lifnr, 0, length(LFA1_lifnr)-1)")
)
# Drop Columns Starting by LFB
Begin_By = "LFB"
df_missed_ = df_missed_.select(
    [col for col in df_missed_.columns if not col.startswith(Begin_By)]
)

# COMMAND ----------

# Join Missing value with new LFB1
df_join2_ = df_missed_.alias("A").join(
    df_lfb1.alias("B"),
    (f.col("A.LIFNR_TEMP") == f.col("B.LFB1_lifnr"))
    & (f.col("A.LFM1_bukrs") == f.col("B.LFB1_bukrs")),
    "left",
)
df_join2_ = df_join2_.drop("LIFNR_TEMP")
df_join2_ = df_join2_.withColumn(
    "LFB1_bukrs",
    f.when(f.col("LFB1_bukrs").isNull(), f.col("LFM1_bukrs")).otherwise(
        f.col("LFB1_bukrs")
    ),
)
df_join2_ = df_join2_.withColumn(
    "LFB1_bukrs",
    f.when(f.col("LFB1_bukrs").isNull(), f.lit("Unknown")).otherwise(
        f.col("LFB1_bukrs")
    ),
)

# Union Base Ok & new base
df_database2 = df_dataOk_.unionByName(df_join2_)
df_database_end = df_database1.unionByName(df_database2)
df_database_end = df_database_end.dropDuplicates(
    (["LFA1_lifnr", "LFB1_bukrs", "LFM1_ekorg"])
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transformation 3: Renaming according Header files

# COMMAND ----------

df_name_1 = spark.read.table("prod_bronze.headers_sap.headers_sap_lfxx")
# Call function Check Header files
check_schema_of_the_file(df_name_1)

# Call Function Delete rows null
df_name_1 = delete_null_rows(df_name_1)

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_database_end, df_name_1
)
# Call Funtion Create Columns on Date format
df = table_utils.cast_columns_with_sap_business_headers(df_column_names, df_name_1)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output - supplier

# COMMAND ----------

catalog = f"{PIPELINE_WRITE_ENV}_silver"
domain = "master_data"
table = "supplier"

DESTINATION_TABLE_FULL_PATH = f"{catalog}.{domain}.{table}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df,
    mode="overwrite",
    overwrite_schema=True,
)
