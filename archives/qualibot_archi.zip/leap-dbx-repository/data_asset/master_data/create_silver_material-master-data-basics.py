# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**
# MAGIC The aim is to create a silver table for Material Master Data Basics
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - {WRITE_ENV}_silver.master_data.material_master_data_basics
# MAGIC
# MAGIC **Input :**
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.mara_latest
# MAGIC   - {READ_ENV}_bronze.sap_latecoere_ecc6.makt_latest
# MAGIC
# MAGIC **Triggered by:**
# MAGIC  - SAP Bronze Ingestion
# MAGIC
# MAGIC **Things to do:**
# MAGIC
# MAGIC - Cleaning data
# MAGIC - Renaming Headers
# MAGIC - Add Description

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame

from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC #Functions

# COMMAND ----------

# Check Header from Manual Input file
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ["Table_name", "Field", "Business_name", "Format"]:
        print("Correct schema")
    else:
        raise Exception(
            f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format"
        )


# --------------------------------------------------------------------------------------------------------------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# COMMAND ----------

# MAGIC %md
# MAGIC #Upload Table and Renaming

# COMMAND ----------

# Upload MARA <- Master Data material from SAP
df_mara = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.mara_latest")
df_mara = table_utils.add_prefix_to_columns(df_mara, "MARA")  # <- Renaming // MARA_XXXX

# Upload LFB1 <- Material Description from SAP
df_makt = spark.read.table(f"{READ_ENV}_bronze.sap_latecoere_ecc6.makt_latest")
df_makt = table_utils.add_prefix_to_columns(df_makt, "MAKT")  # <- Renaming // MAKT_XXXX

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming according Header files

# COMMAND ----------

## Renaming MARA -Basic Master Data from SAP
df_name_mara = spark.read.table("prod_bronze.headers_sap.headers_sap_business_mara")
# Call function Check Header files
check_schema_of_the_file(df_name_mara)
# Call Function Delete rows null
df_name_mara = delete_null_rows(df_name_mara)
# Call Function Rename Columns according header file
df_column_mara = table_utils.rename_columns_with_sap_business_header(
    df_mara, df_name_mara
)
# Call Funtion Create Columns on Date format
df_mara = table_utils.cast_columns_with_sap_business_headers(
    df_column_mara, df_name_mara
)
# -----------------------------------------------------------------------------------
## Renaming MAKT - Description Material from SAP
df_name_makt = spark.read.table("prod_bronze.headers_sap.headers_sap_business_makt")
# Call function Check Header files
check_schema_of_the_file(df_name_makt)
# Call Function Delete rows null
df_name_makt = delete_null_rows(df_name_makt)
# Call Function Rename Columns according header file
df_column_makt = table_utils.rename_columns_with_sap_business_header(
    df_makt, df_name_makt
)
# Call Funtion Create Columns on Date format
df_makt = table_utils.cast_columns_with_sap_business_headers(
    df_column_makt, df_name_makt
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Filter on Master Data Material

# COMMAND ----------

# Exclusion Material cancelled
df_mara = df_mara.filter(f.col("MARA_lvorm").isNull())

# COMMAND ----------

# MAGIC %md
# MAGIC #Management Description of material

# COMMAND ----------

## Goal -> keep only one description for each material
# Priority is done on English language, then French then any others languages
# Creation DF for English LG
df_makt_en = df_makt.filter(f.col("makt_spras") == "E")
df_makt_en = df_makt_en.withColumnRenamed(
    "Material_Number", "Material_Number_en"
).withColumnRenamed("Description", "Description_en")
df_makt_en = df_makt_en.select("Material_Number_en", "Description_en")
# ---------------------------------------------------------------------------
# Creation DF for French LG
df_makt_fr = df_makt.filter(f.col("makt_spras") == "F")
df_makt_fr = df_makt_fr.withColumnRenamed(
    "Material_Number", "Material_Number_fr"
).withColumnRenamed("Description", "Description_fr")
df_makt_fr = df_makt_fr.select("Material_Number_fr", "Description_fr")
# ---------------------------------------------------------------------------
# Creation DF for others LG
df_makt_all = df_makt.select(
    f.col(
        "Material_Number",
    ),
    f.col("Description"),
)
df_makt_all = df_makt_all.filter(f.col("Description").isNotNull())
df_makt_all = df_makt_all.dropDuplicates(["Material_Number"])
df_makt_all = df_makt_all.withColumnRenamed(
    "Material_Number", "Material_Number_all"
).withColumnRenamed("Description", "Description_all")

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Basic Data & Descriptions (E/F/Others)

# COMMAND ----------

df_join_material = (
    df_mara.alias("A")
    .join(
        df_makt_en.alias("B"),
        f.col("A.Material_Number") == f.col("B.Material_Number_en"),
        "left",
    )
    .join(
        df_makt_fr.alias("C"),
        f.col("A.Material_Number") == f.col("C.Material_Number_fr"),
        "left",
    )
    .join(
        df_makt_all.alias("D"),
        f.col("A.Material_Number") == f.col("D.Material_Number_all"),
        "left",
    )
)
df_join_material = df_join_material.drop(
    "Material_Number_en", "Material_Number_fr", "Material_Number_all"
)
# Keep EN first, then FR, then all
df_material = df_join_material.withColumn(
    "Description",
    f.when(f.col("Description_en").isNotNull(), f.col("Description_en"))
    .when(f.col("Description_fr").isNotNull(), f.col("Description_fr"))
    .otherwise(f.col("Description_all")),
)
df_material_end = df_material.drop(
    "Description_en", "Description_fr", "Description_all"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Cleasing raw data from material data asset
# MAGIC

# COMMAND ----------

# Cancel 0 on begin material_Number
df_material_end = df_material_end.withColumn(
    "Material_Number", f.regexp_replace(df_join_material.Material_Number, "^0+", "")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Silver table

# COMMAND ----------

catalog = f"{WRITE_ENV}_silver"
domain = "master_data"
table = "material_master_data_basics"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_material_end,
    mode="overwrite",
    overwrite_schema=True
)
