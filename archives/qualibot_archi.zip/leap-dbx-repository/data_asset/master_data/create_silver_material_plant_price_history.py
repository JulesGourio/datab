# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for Material Master Data History by plant and Domain Prices  
# MAGIC This Table will contain all Parameters linked with plant details (MRP, Procurement,...)
# MAGIC
# MAGIC **Input :**
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mbew_latest
# MAGIC   - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mbewh_latest
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - {PIPELINE_WRITE_ENV}_silver.master_data.material_plant_price_history

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Imports

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - **df_mbew_raw** is the bronze latest MBEW SAP table
# MAGIC - **df_mbewh_raw** is the bronze latest MBEWH SAP table
# MAGIC - **df_mbew_headers** is the header of the SAP table MBEW
# MAGIC - **df_mbewh_headers** is the header of the SAP table MBEWH
# MAGIC

# COMMAND ----------

df_mbew_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mbew_latest"
)
df_mbewh_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mbewh_latest"
)

# COMMAND ----------

df_mbew_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_mbew_v2"
)
df_mbewh_headers = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_mbewh"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Inputs - Manual declaration

# COMMAND ----------

MBEW_PREFIX = "MBEW"
MBEWH_PREFIX = "MBEWH"

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Prep 1 - Renaming & casting columns

# COMMAND ----------

df_mbew_prep = table_utils.add_prefix_to_columns(df_mbew_raw, MBEW_PREFIX)
table_utils.check_schema_of_the_header_file(df_mbew_headers)
df_mbew_prep = table_utils.rename_columns_with_sap_business_header(
    df_mbew_prep, df_mbew_headers
)
df_mbew_prep = table_utils.cast_columns_with_sap_business_headers(
    df_mbew_prep, df_mbew_headers
)
df_mbew_prep = table_utils.remove_leading_zeros(
    df=df_mbew_prep, column_names=["material_number"]
)

# COMMAND ----------

df_mbewh_prep = table_utils.add_prefix_to_columns(df_mbewh_raw, MBEWH_PREFIX)
table_utils.check_schema_of_the_header_file(df_mbewh_headers)
df_mbewh_prep = table_utils.rename_columns_with_sap_business_header(
    df_mbewh_prep, df_mbewh_headers
)
df_mbewh_prep = table_utils.cast_columns_with_sap_business_headers(
    df_mbewh_prep, df_mbewh_headers
)
df_mbewh_prep = table_utils.remove_leading_zeros(
    df=df_mbewh_prep, column_names=["material_number"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

window_spec = Window.partitionBy("material_number", "plant").orderBy(
    f.col("fiscal_year").desc(), f.col("current_period").desc()
)

df_mbew_prep = (
    df_mbew_prep.withColumn("row_num", f.row_number().over(window_spec))
    .filter("row_num = 1")
    .drop("row_num")
)

# COMMAND ----------

df_mbew_prep = df_mbew_prep.withColumn("data_type", f.lit("Actual"))
df_mbewh_prep = df_mbewh_prep.withColumn("data_type", f.lit("History"))

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Union MBEW and MBEWH tables

# COMMAND ----------

df_material_history = df_mbew_prep.unionByName(df_mbewh_prep, allowMissingColumns=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr2 - Delete SPLIT and keep valuation_type = null when there are multi lines

# COMMAND ----------

df_material_history = df_material_history.filter(f.col("material_number") != "SPLIT")

# COMMAND ----------

group_cols = ["material_number", "plant", "current_period", "fiscal_year"]
multi_row_groups = (
    df_material_history.groupBy(group_cols)
    .count()
    .filter(f.col("count") > 1)
    .drop("count")
)

df_multi = df_material_history.join(multi_row_groups, on=group_cols, how="inner")
df_multi_nulls = df_multi.filter(f.col("valuation_type").isNull())

df_single = df_material_history.join(multi_row_groups, on=group_cols, how="left_anti")
df_material_history = df_single.unionByName(df_multi_nulls)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_silver.master_data.material_plant_price_history",
    df=df_material_history,
    overwrite_schema=True,
    mode="overwrite",
)
