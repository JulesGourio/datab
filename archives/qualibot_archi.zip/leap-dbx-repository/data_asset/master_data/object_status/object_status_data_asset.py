# Databricks notebook source
# %% Imports
from databricks.sdk.runtime import dbutils
from pyspark.sql import functions as f

from leap_utils.config import spark
from leap_utils.data_asset import table_utils

# COMMAND ----------

# %% Widgets
dbutils.widgets.removeAll()

dbutils.widgets.text("write_env", "dev")
WRITE_ENV = dbutils.widgets.get("write_env")

dbutils.widgets.text("debug", "False")
DEBUG = dbutils.widgets.get("debug").lower() == "true"

# COMMAND ----------

# %% Constants
WO_BULG_TEST = "000003504615"
OBJECT_STATUS_OBJECT_EXAMPLE = "OR000003504615"

OBJECT_STATUS_DATABASE = f"{WRITE_ENV}_gold.master_data"
OBJECT_STATUS_GOLD_TABLE = f"{OBJECT_STATUS_DATABASE}.object_status_latest"

# COMMAND ----------

# %% Functions


def get_latest_extraction_sap_table_using_history(sap_tablename: str, debug=DEBUG):
    df_sap_history = spark.read.table(f"prod_bronze.sap_latecoere_ecc6.{sap_tablename}_stack")

    df_history_latest_extraction_timestamp = df_sap_history.select(
        f.max("extraction_timestamp")
    ).collect()[0][0]

    if debug:
        print(
            f"Latest extraction timestamp for {sap_tablename}: {df_history_latest_extraction_timestamp}"
        )

    df_latest = df_sap_history.where(
        f.col("extraction_timestamp") == df_history_latest_extraction_timestamp
    )

    sap_tablename_no_domain = sap_tablename[3:]

    df_latest = table_utils.add_prefix_to_columns(df_latest, sap_tablename_no_domain)

    return df_latest


def debug_table(df_table, debug=DEBUG):
    """TODO remove, for debug purpose only"""
    import inspect

    def retrieve_name(var):
        callers_local_vars = inspect.currentframe().f_back.f_back.f_locals.items()
        return [var_name for var_name, var_val in callers_local_vars if var_val is var]

    caller_table_name = retrieve_name(df_table)
    print(f"debugging table {caller_table_name}")

    if debug:
        print(f"{caller_table_name}.columns={df_table.columns}")

    objnr_list = list(filter(lambda col_name: "_objnr" in col_name, df_table.columns))

    if debug:
        print(f"{objnr_list=}")

    first_objnr_column_name = objnr_list[0]

    df_table.where(
        f.col(first_objnr_column_name) == OBJECT_STATUS_OBJECT_EXAMPLE
    ).show()


# COMMAND ----------

# %% Latest JEST
df_jest = get_latest_extraction_sap_table_using_history("jest")

if DEBUG:
    debug_table(df_jest)

# COMMAND ----------

# %% Latest TJ02T for status code in a certain language
df_tj02t = get_latest_extraction_sap_table_using_history("tj02t")

if DEBUG:
    debug_table(df_tj02t)

# COMMAND ----------

# %% Join JEST on TJ02T
# Note: we decided to filter on status description to be only english to reduce compute time on the join.
df_jest_tj02t = df_jest.join(
    df_tj02t.where(f.col("tj02t_spras") == "E"),
    on=[
        f.col("jest_stat") == f.col("tj02t_istat"),
    ],
    how="left",
)

if DEBUG:
    debug_table(df_jest_tj02t)

# COMMAND ----------

# %% Save latest object status data asset
spark.sql(f"CREATE DATABASE IF NOT EXISTS {OBJECT_STATUS_DATABASE}")

table_utils.save_table(
    dest_table=OBJECT_STATUS_GOLD_TABLE,
    df=df_jest_tj02t,
    mode="overwrite",
    overwrite_schema=True
)
