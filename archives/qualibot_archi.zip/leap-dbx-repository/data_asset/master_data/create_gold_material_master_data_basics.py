# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table & Gold_explosed for Material Master data basics
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_gold.master_data.material_master_data_basics
# MAGIC   - {WRITE_ENV}_gold.master_data.material_master_data_basics_explosed
# MAGIC
# MAGIC **Intput :**  
# MAGIC   - {READ_ENV}_silver.master_data.material_master_data_basics 
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Notebook create_silver_material_master_data_basics 
# MAGIC
# MAGIC **Things to do:** 
# MAGIC -  

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC # Extraction & join Tables 

# COMMAND ----------

df_material = spark.read.table(
    f"{READ_ENV}_silver.master_data.material_master_data_basics"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter rules From Business

# COMMAND ----------

# Application filter business finance
# Nothing

# COMMAND ----------

# MAGIC %md
# MAGIC # Enrichment Gold

# COMMAND ----------

# Nothing

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "master_data"
table = "material_master_data_basics"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_material,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold exposed table

# COMMAND ----------

catalog = "gold"
domain = "master_data"
table = "material_master_data_basics"
src_full_tablename = f"{WRITE_ENV}_{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "MARA"
selected_columns = [col for col in df_material.columns if not col.startswith(Begin_By)]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
