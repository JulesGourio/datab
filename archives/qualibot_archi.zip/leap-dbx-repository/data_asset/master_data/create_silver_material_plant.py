# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # [SILVER - MATERIAL PLANT DATABASE]
# MAGIC
# MAGIC **Summary:**  
# MAGIC This notebook focuses on building a silver table for Master Data Material by plant.   
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for Master Data Material by plant.    
# MAGIC This reference material table ensures the quality, consistency, and performance of material data throughout the entire company.
# MAGIC
# MAGIC **Highlighted complexities:**  
# MAGIC - N/A
# MAGIC
# MAGIC **Intended Pipeline**
# MAGIC - W_1_SAP_Master_Data_Material-Asset  
# MAGIC
# MAGIC **Input Tables Pipeline**
# MAGIC - N/A
# MAGIC
# MAGIC **Inputs Reference Data**
# MAGIC  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.marc_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mbew_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdma_latest  
# MAGIC - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_marc  
# MAGIC - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_mbew    
# MAGIC - {REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_mdma  
# MAGIC
# MAGIC **Output Tables (Pipeline)**
# MAGIC - {PIPELINE_WRITE_ENV}_silver.master_data.material_plant
# MAGIC
# MAGIC **Warning: the key of this table include the MRP unit**   

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Package Imports

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
import time
import logging

# COMMAND ----------

# MAGIC %md
# MAGIC ### Config LEAP Function Imports
# MAGIC

# COMMAND ----------

# Utils imports
from leap_utils.data_asset import table_utils

# leap logger
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pipeline Environments

# COMMAND ----------


# Get read environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("bypass_quality_checks", "false")  # history/update
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Debug Boolean
# MAGIC
# MAGIC - DEBUG -> Used for specifying whether or not the script should be in "debug mode" or not. 
# MAGIC - LOG_LEVEL -> Used for specifying what log level is defined inside the notebook
# MAGIC

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]

log = setup_applevel_logger(log_level=LOG_LEVEL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config - Common Functions (across whole notebook)

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Functions

# COMMAND ----------

# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import MARC (SAP)
# MAGIC
# MAGIC **df_marc_raw** Plant Data for Material  
# MAGIC It contains the data specific to a material for a plant.

# COMMAND ----------

df_marc_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.marc_latest"
)
df_marc_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_marc"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import MBEW (SAP)
# MAGIC
# MAGIC **df_mbew_raw** Material Valuation  
# MAGIC it contains the valuation data of materials in SAP. It's essential for inventory management and accounting, as it links materials to their financial value in a valuation area..

# COMMAND ----------

df_mbew_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mbew_latest"
)
df_mbew_header = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_mbew"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import MDMA (SAP)
# MAGIC
# MAGIC **df_mdma_raw** MRP Area for Material  
# MAGIC This table stores material requirements planning (MRP) data specific to an MRP Area for a given material.

# COMMAND ----------

# Upload Master Data MRP Unit from SAP
df_mdma_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mdma_latest"
)
# As is part of MARC table, we use same header than MARC to be sure that we had same column name
df_mdma_header = df_marc_header

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - File Read

# COMMAND ----------

# MAGIC %md
# MAGIC ### Example File import
# MAGIC
# MAGIC Description of file imports found in folder x that represent Y coming form system Z

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - Manual declaration

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Preparation
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation - Common Functions
# MAGIC
# MAGIC Script specific functions used in dataset preparation

# COMMAND ----------

# N/A

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparation 1 - Renaming of Columns to include table suffix in name
# MAGIC
# MAGIC In this section we want to add the table prefix to the columns as later in the joins there will be duplicate column names AND we will need to know which table the column came from

# COMMAND ----------

# MAGIC %md
# MAGIC #### Preparation 1.1 - Renaming MARC Table

# COMMAND ----------

df_marc = table_utils.add_prefix_to_columns(df_marc_raw, "MARC")
# Call Function Delete rows null
df_name_marc = delete_null_rows(df_marc_header)
# Call Function Rename Columns according header file
df_column_marc = table_utils.rename_columns_with_sap_business_header(
    df_marc, df_name_marc
)
# Call Funtion Create Columns on Date format
df_marc = table_utils.cast_columns_with_sap_business_headers(
    df_column_marc, df_name_marc
)
# ---------------------------------------------------------------------
# Keep Only Material active /
# Exclusion Plant 1500 created by mistake / SPLIt management parts
df_marc = (
    df_marc.filter(f.col("MARC_lvorm").isNull())
    .filter(f.col("material_number") != "SPLIT")
    .filter(f.col("plant") != "1500")
)
# ---------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Preparation 1.2 - Renaming MBEW Table

# COMMAND ----------

df_mbew = table_utils.add_prefix_to_columns(df_mbew_raw, "MBEW")
# Call Function Delete rows null
df_name_mbew = delete_null_rows(df_mbew_header)
# Call Function Rename Columns according header file
df_column_mbew = table_utils.rename_columns_with_sap_business_header(
    df_mbew, df_name_mbew
)
# Call Funtion Create Columns on Date format
df_mbew = table_utils.cast_columns_with_sap_business_headers(
    df_column_mbew, df_name_mbew
)
# ---------------------------------------------------------------------
# Exclusion Test Valorisation
df_mbew = df_mbew.filter(f.col("MBEW_bwtar").isNull())
# ---------------------------------------------------------------------

# COMMAND ----------

display(df_mbew)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Preparation 1.3 - Renaming MDMA Table

# COMMAND ----------

df_mdma = table_utils.add_prefix_to_columns(df_mdma_raw, "MARC")
# Call Function Delete rows null
df_name_mdma = delete_null_rows(df_mdma_header)
# Call Function Rename Columns according header file
df_column_mdma = table_utils.rename_columns_with_sap_business_header(
    df_mdma, df_name_mdma
)
# Call Funtion Create Columns on Date format
df_mdma = table_utils.cast_columns_with_sap_business_headers(
    df_column_mdma, df_name_mdma
)
# Rename key Mrp_Unit
df_mdma = df_mdma.withColumnRenamed("MARC_berid", "mrp_unit")

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transf. 1 # Join Material data and price

# COMMAND ----------

df_material_join = df_marc.join(
    df_mbew,
    (df_marc["material_number"] == df_mbew["material_number"])
    & (df_marc["plant"] == df_mbew["domain"]),
    "left",
).drop(df_mbew["material_number"])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transf. 2 # Append MRP_Unit in Material Base

# COMMAND ----------

# Set the 'mrp_unit' column to the value of 'plant'
df_material_join = df_material_join.withColumn("mrp_unit", f.col("plant"))

# Cancel all columns in df_material_join founded in df_mdma, except material_number and plant
cols_to_remove = set(
    [col for col in df_mdma.columns if col not in ["material_number", "plant"]]
)
cols_to_keep = [col for col in df_material_join.columns if col not in cols_to_remove]
df_material_tmp = df_material_join.select(cols_to_keep)

# Inner Join with df_mdma on material_number and plant
df_material_tmp_joined = df_material_tmp.join(
    df_mdma, on=["material_number", "plant"], how="inner"
)
# Append material plant & Mrp_unit
df_material_appended = df_material_join.unionByName(
    df_material_tmp_joined, allowMissingColumns=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transf. 3 # Add Boolean for automatic po

# COMMAND ----------

df_material_bool= df_material_appended.withColumn(
        "is_automatic_purchase_order_allowed",
        f.when(f.col("indicator_automatic_purchase_order_allowed") == "X", f.lit(True)).otherwise(f.lit(False)),
    ).drop("indicator_automatic_purchase_order_allowed")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transf. 4 # Cleaning Base

# COMMAND ----------

# Remove leading zero
df_material_end = table_utils.remove_leading_zeros(
    df_material_bool, ["material_number", "profit_center"]
)

# COMMAND ----------

sorted(df_material_end.columns)

# COMMAND ----------

# MAGIC %md
# MAGIC # Quality check

# COMMAND ----------

df_material_end = df_material_end.withColumn(
    "material_plant_id",
    f.concat_ws("-", f.col("material_number"), f.col("plant"), ("mrp_unit")),
)
columns = df_material_end.columns
columns.remove("material_plant_id")
new_column_order = ["material_plant_id"] + columns
df_material_end = df_material_end.select(new_column_order)

# COMMAND ----------

df_to_check = df_material_end
col_to_check = "material_plant_id"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)
red_quality_check_results = [
    df_gx.expect_column_values_to_not_be_null(column=col_to_check),
    df_gx.expect_column_values_to_be_unique(column=col_to_check),
]

gx_validation.validate_and_log_gx_results(
    quality_check_results=red_quality_check_results,
    validation_level=validation_level,
    info_message=f"No null values found in {col_to_check}",
    error_message=f"Null values found in {col_to_check}, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="material_plant_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Outputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - LEAP Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save Silver Table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "master_data"
DESTINATION_TABLE = "material_plant"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_material_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_material_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "silver_material_plant_pk"
TABLE_PK_COLS = "material_plant_id"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Output - Files

# COMMAND ----------

# N/A
