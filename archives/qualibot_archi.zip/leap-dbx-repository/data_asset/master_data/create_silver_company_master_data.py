# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a silver table for company master data
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {write_env}_silver.master_data.company_master_data_latest
# MAGIC   
# MAGIC **Input :**  
# MAGIC   
# MAGIC   - {read_env}_bronze.sap_latecoere_ecc6.t001_latest
# MAGIC   - {read_env}__bronze.sap_latecoere_ecc6.t005t_latest
# MAGIC   - prod_bronze.manual_input.company_description
# MAGIC   - prod_bronze.headers_sap.headers_sap_business_t001
# MAGIC   
# MAGIC **Triggered by:**  
# MAGIC   - Ingestion SAP Bronze 
# MAGIC
# MAGIC **Things to do:** 
# MAGIC   - Rename Headers 
# MAGIC   - upload Manual Description

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable 
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable 
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")


# COMMAND ----------

# MAGIC %md 
# MAGIC #Functions

# COMMAND ----------

#Check Header from Manual Input file 
def check_schema_of_the_file(df_names: DataFrame):
    """Check if we have the right columns"""
    if df_names.columns == ['Table_name', 'Field', 'Business_name', 'Format']:
        print('Correct schema')
    else:
        raise Exception(f"Bad Table schema. Expecting 4 columns, Table_name, Field, Business_name and Format")
#--------------------------------------------------------------------------------------------------------------

#Delete rows when field is null 
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col('Field').isNotNull() == True)
    return df_names_new    
#-------------------------------------------------------------------------------------------------------------- 

# COMMAND ----------

# MAGIC %md
# MAGIC #Import Tables MRP & Plant Master

# COMMAND ----------

# Upload Company Master Data SAP
df_t001 = spark.read.table(
    f"{READ_ENV}_bronze.sap_latecoere_ecc6.t001_latest"
)  
df_t001_end = table_utils.add_prefix_to_columns(df_t001, "T001")
# Upload Country Master Data SAP
df_t005t = spark.read.table(
    f"{READ_ENV}_bronze.sap_latecoere_ecc6.t005t_latest"
)  
df_t005_end = table_utils.add_prefix_to_columns(df_t005t, "T005T")
# Upload Company Master Data Manual
df_t001m = spark.read.table(
    "prod_bronze.manual_input.company_description"
)  

# COMMAND ----------

# MAGIC %md
# MAGIC #Renaming Headers according Business entries

# COMMAND ----------

df_name_t001 = spark.read.table("prod_bronze.headers_sap.headers_sap_business_t001")
# Call function Check Header files
check_schema_of_the_file(df_name_t001)  
# Call Function Delete rows null
df_name_t001 = delete_null_rows(df_name_t001)  
# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_t001_end, df_name_t001
)  
# Call Funtion Create Columns on Date format
df_t001_end = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_t001
)  
#----------------------------------------------------------------------------------------
df_name_t005 = spark.read.table("prod_bronze.headers_sap.headers_sap_business_t005t")
# Call function Check Header files
check_schema_of_the_file(df_name_t005)
# Call Function Delete rows null
df_name_t005 = delete_null_rows(df_name_t005)
# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_t005_end, df_name_t005
)  
# Call Funtion Create Columns on Date format
df_t005_end = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_name_t005
)  

# COMMAND ----------

# MAGIC %md
# MAGIC #Add manual description & Branch

# COMMAND ----------

df_t001m = df_t001m.withColumnRenamed(
    "Company_description", "Company_description_manual"
)
df_t001_end = df_t001_end.withColumnRenamed("Country", "Country_Code_")
# Keep only English Description
df_t005_end = df_t005_end.filter(
    f.col("Language") == "E"
)  

df_join_company = (
    df_t001_end.alias("A")
    .join(df_t001m.alias("B"), (f.col("A.Company") == f.col("B.Company_Code")), "left")
    .join(
        df_t005_end.alias("C"),
        (f.col("A.Country_Code_") == f.col("C.Country_Code")),
        "left",
    )
    .drop("Company_Code", "Country_Code_", "Language")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Silver Company data asset

# COMMAND ----------

# Save the silver Company data asset
catalog = f"{WRITE_ENV}_silver"
domain = "master_data"
table = "company_master_data_latest"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_join_company,
    mode="overwrite",
    overwrite_schema=True
)
