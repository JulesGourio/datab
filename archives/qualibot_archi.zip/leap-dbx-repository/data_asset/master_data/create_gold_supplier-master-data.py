# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table & Gold_exposed for Supplier Master data.
# MAGIC
# MAGIC **Output table(s):**  
# MAGIC   - {WRITE_ENV}_gold.supplier_lf_master_latest
# MAGIC   - {WRITE_ENV}_gold.supplier_lf_master_latest_exposed  
# MAGIC
# MAGIC **Intput :**  
# MAGIC   - {READ_ENV}_silver.master_data.supplier_lf_master_latest 
# MAGIC   -  prod_bronze.manual_input.supplier_category_sap  
# MAGIC
# MAGIC **Triggered by:**  
# MAGIC Notebook create_silver_supplier-master-data  
# MAGIC
# MAGIC **Things to do:** 
# MAGIC - Add Supplier Category  

# COMMAND ----------

from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

from leap_utils.data_asset import table_utils

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("READ_ENV", "prod")
READ_ENV = dbutils.widgets.get("READ_ENV")
# Get write environment variable
dbutils.widgets.text("WRITE_ENV", "dev")
WRITE_ENV = dbutils.widgets.get("WRITE_ENV")

# COMMAND ----------

# MAGIC %md
# MAGIC # Extraction & join Tables 

# COMMAND ----------

df_database = spark.read.table(
    f"{READ_ENV}_silver.supply_chain.supplier_master_data_latest"
)
# Extraction Manual input for determination Supplier category
df_supplier = spark.read.table("prod_bronze.manual_input.supplier_category_sap")

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter rules From Business

# COMMAND ----------

# Application filter business finance
# Nothing

# COMMAND ----------

# MAGIC %md
# MAGIC # Enrichment Gold

# COMMAND ----------

# Add Supplier_Category according manual table for Supplier category link to KTOKK
df_join = (
    df_database.alias("A")
    .join(df_supplier.alias("B"), f.col("A.LFA1_ktokk") == f.col("B.ktokk"), "left")
    .select(
        f.col("A.*"),
        f.col("B.Supplier_Category"),
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

catalog = f"{WRITE_ENV}_gold"
domain = "supply_chain"
table = "supplier_master_data_latest"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {catalog}.{domain}")

table_utils.save_table(
    dest_table=f"{catalog}.{domain}.{table}",
    df=df_join,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold exposed table

# COMMAND ----------

catalog = "gold"
domain = "supply_chain"
table = "supplier_master_data_latest"
src_full_tablename = f"{WRITE_ENV}_{catalog}.{domain}.{table}"
dest_full_tablename = f"{src_full_tablename}_exposed"
Begin_By = "LF"
selected_columns = [col for col in df_join.columns if not col.startswith(Begin_By)]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    src_full_tablename, dest_full_tablename, select_statement, replace_view=True
)
