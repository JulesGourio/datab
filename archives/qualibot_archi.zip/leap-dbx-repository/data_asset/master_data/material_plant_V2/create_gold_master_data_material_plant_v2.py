# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook create_gold_master_data_material_plant_v2

# COMMAND ----------

# MAGIC %md
# MAGIC #  Purpose
# MAGIC
# MAGIC  **Description:**
# MAGIC  The aim is to create a gold table & Gold_explosed for Master data Material by plant View. It is a refacto to stick to best practices and to help with Palantir Migration. This master data should have an primary key based on material and plant columns.
# MAGIC  There will be a lot of transformations removed from the original file
# MAGIC  /data_asset/master_data/create_gold_material_master_data_plant
# MAGIC as those ones are  not to be placed in a master data dataset and that are breaking uniqueness of primary key.
# MAGIC
# MAGIC  **Output table(s):**
# MAGIC    - {PIPELINE_WRITE_ENV}_gold.master_data.material_plant
# MAGIC    - {PIPELINE_WRITE_ENV}_gold.master_data.material_plant_exposed
# MAGIC
# MAGIC  ** Input from Bronze **
# MAGIC      - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t460a_latest
# MAGIC
# MAGIC
# MAGIC  **Input from Silver:**
# MAGIC    -  silver material_plant : {PIPELINE_READ_ENV}_silver.master_data.material_plant
# MAGIC
# MAGIC  **Input from Gold**
# MAGIC    - gold material :  {REFERENCE_READ_ENV}_gold.master_data.material_exposed")
# MAGIC    -  gold plant :  {REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed
# MAGIC
# MAGIC
# MAGIC  **Triggered by:**
# MAGIC  Notebook  /data_asset/master_data/material_plant_V2/create_silver_master_data_material_plant_v2
# MAGIC
# MAGIC  **Things performed in this Notebook:**
# MAGIC  -  Add Material Master Data including purchasig taxonomy
# MAGIC  -  Add Plant & Company Master Data
# MAGIC  -  Add Branch / Production Site / Inventory Site
# MAGIC  -  Management Intra Flows
# MAGIC  - Management Category of Product
# MAGIC
# MAGIC
# MAGIC  - Adding a primary key in gold dataset
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Questions to be answered
# MAGIC
# MAGIC - confirm that business rules are to be applied  in a master data?
# MAGIC
# MAGIC  - price  calculation are to be  handled in a separate dataframe that will take timeline into account such as material_price_object
# MAGIC  - Determination Branch & Production Site & Inventory Site : are those  businness rule applicables in a master dataset?
# MAGIC  - adding the MRP unit from MDMA tables breaks the unicity for material_plant primary key so in this case  it is no more a material_plant master data hence calculation of profit center repartition cannot  be done  in this dataset as it  is linked to MRP unit.
# MAGIC   - shall we put the profit center caculation with "material price object" calculation based on MBEWH to have a monthly consumption ?
# MAGIC  - for cost center repartition , what was the time period considered for the repartition ?
# MAGIC  - MRP unit column  to be renamed as generally Unit stands for physical mesures ( m2, m, kg... ) and not entity as to seems to be for MRP unit

# COMMAND ----------

# MAGIC %md
# MAGIC # ChangeLog
# MAGIC  05May25
# MAGIC  - Notebook creation by claire  Arnoud
# MAGIC  - Changing all inputs to use reference _read_env , pipeline_read_env widgets
# MAGIC  - changing col names to respect name  convention for column name ( snake_case), renaming final columns to lower case
# MAGIC  - removing
# MAGIC  price calculation ,  management need , Management Price Upper Green-Line  (as it will be replaced by  prod_gold.master_data.material_price_history)
# MAGIC - Removing Determination of Final Assembly, Management Supplier affectation as it is not a data for master data dataset
# MAGIC -Removing   Inter co flow as it is based on supplier too
# MAGIC - removing mekko classification as related to supplier
# MAGIC - removing MRP unit addition as in this case  it breaks the uniqueness of material_plant
# MAGIC - Removing   profit center  repartition that was based on MRP unit addition

# COMMAND ----------

# MAGIC %md
# MAGIC # Packages load

# COMMAND ----------

from pyspark.sql import functions as f

# from pyspark.sql import DataFrame
# from pyspark.sql.window import Window
# from pyspark.sql.types import MapType, StringType, DoubleType, FloatType
import time

# from leap_utils.data_asset import amount_correction
from leap_utils.data_asset import table_utils

# validation package
from leap_utils.common.validation import gx_validation
from great_expectations.dataset import SparkDFDataset
from pyspark.sql.utils import AnalysisException

# logging packages
import logging
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# COMMAND ----------

# MAGIC %md
# MAGIC # Widget setup

# COMMAND ----------

dbutils.widgets.removeAll()
# Get reference read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")
# Get pipeline read environment variable
dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")
# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

# set bypass quality checks
dbutils.widgets.text("bypass_quality_checks", "false")  # history/update
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC #Log_level setup
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

log.debug(f"PIPELINE_READ_ENV is:  {PIPELINE_READ_ENV}")
log.debug(f"PIPELINE_WRITE_ENV is:  {PIPELINE_WRITE_ENV}")
log.debug(f"REFERENCE_READ_ENV is:  {REFERENCE_READ_ENV}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Silver table Material

# COMMAND ----------

df_material_plant = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.master_data.material_plant"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Enrichment Gold

# COMMAND ----------

# MAGIC %md
# MAGIC ## Upload & Join Material Master

# COMMAND ----------

# Upload Master Data Material  new version (which contains commodity)
df_material = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.material_exposed"
).select(
    "material_number",
    "material_description",
    "material_type",
    "material_base_unit",
    "material_commodity_PUR",
    "material_sub_commodity_PUR",
    "material_direct_indirect_PUR",
)

# COMMAND ----------

df_material_plant = df_material_plant.join(
    df_material, on=["material_number"], how="left"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Upload & join Plant Master data & Company

# COMMAND ----------

# Upload Master Data plant
df_plant = (
    spark.read.table(
        f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
    )
    .select(
        "Plant", "Currency", "Plant_Description_new", "Company", "Company_Description"
    )
    .withColumnRenamed("Plant_Description_new", "production_site")
)

df_plant = df_plant.toDF(*[c.lower() for c in df_plant.columns])

df_material_plant = df_material_plant.join(
    df_plant,
    on=["plant"],
    how="left",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Determination Branch & Production Site & Inventory Site

# COMMAND ----------

## On AS side, we have 4 distinct plants grouped into a single plant in SAP (1000)
# and 2 distinct plants grouped into a single plan in SAP (Plant 1900)

# Here under Rules to dispatch Stock and Production activities between
# LFR-Gimont / LFR-Montredon / LFR- HUB / LFR-DES for plant 1000
# LFR-Cust / LFR-DES for plant 1900

DES_Prog = ["BCL", "HAP", "297", "298", "299", "DEW"]
# Determination Stock Site for Plant 1000 (Gimont/Montredon/HUB/DES)

df_material_storage = df_material_plant.withColumn(
    "stock_site",
    f.when(
        (f.col("plant") != "1000") & (f.col("plant") != "1900"),
        f.col("production_site"),
    )
    .when(
        (f.col("profit_center").isin(DES_Prog))
        | (f.col("profit_center").startswith("V"))
        | (f.col("mrp_controller").startswith("DE")),
        f.lit("LFR-DES"),
    )
    .when(f.col("decopling_point").startswith("MON"), f.lit("LFR-Montredon"))
    .when(f.col("decopling_point").startswith("GMT"), f.lit("LFR-Gimont"))
    .when(f.col("plant") == "1900", f.lit("LFR-Cust"))
    .otherwise(f.lit("LFR-HUB")),
)

# Dispatch Production Site for Plant 1000 (Gimont/Montredon/HUB/DES)
df_material_prod = df_material_storage.withColumn(
    "production_site",
    f.when(f.col("plant") != "1000", f.col("production_site"))
    .when(f.col("MRP_Controller") == "DET", f.lit("LFR-DES"))
    .when(
        (f.col("procurement_type") == "F") & (f.col("stock_site") == "LFR-Gimont"),
        f.lit("LFR-Gimont"),
    )
    .when(
        (f.col("procurement_type") == "F") & (f.col("stock_site") == "LFR-DES"),
        f.lit("LFR-DES"),
    )
    .when(
        (f.col("procurement_type") == "F") & (f.col("stock_site") == "LFR-Montredon"),
        f.lit("LFR-Montredon"),
    )
    .when((f.col("procurement_type") == "F"), f.lit("LFR-HUB"))
    .when(f.col("mrp_controller").startswith("O"), f.lit("LFR-Montredon"))
    .otherwise(f.lit("LFR-Gimont")),
)
# Determination Branch AS / IS
df_material_branch = df_material_prod.withColumn(
    "branch",
    f.when(
        (f.col("stock_site") == "LFR-DES") | (f.col("plant").startswith("2")),
        f.lit("IS"),
    ).otherwise(f.lit("AS")),
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Management of Intraco Flow
# MAGIC  removed as it replaces somes plant with others breaking the unicity of primary key material_plant

# COMMAND ----------

# # Upload Master Data for Intraco Flow
# # Determine with plant is linked with Special Procurement Type
# df_intraco = spark.read.table(
#     f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.t460a_latest"
# ).select("werks", "sobsl", "wrk02", "mandt")
# # keeping  data for mandant =600
# df_intraco = df_intraco.filter(f.col("mandt") == "600").drop("mandt")
# df_intraco = df_intraco.select(
#     [f.col(col).alias(col.lower()) for col in df_intraco.columns]
# )

# # Join Material MAster data with Custo IntraCo Flow
# df_update_intraco = (
#     df_material_branch.alias("A")
#     .join(
#         df_intraco.alias("B"),
#         (f.col("A.plant") == f.col("B.werks"))
#         & (f.col("A.procurement_special_type") == f.col("B.sobsl")),
#         "left",
#     )
#     .drop("werks", "sobsl")
# )
# # Take priority on plant linked to Special Procurement Type (T460A)
# df_update_intraco = df_update_intraco.withColumn(
#     "plant", f.coalesce(f.col("wrk02"), f.col("plant"))
# )


# df_update_intraco = df_update_intraco.drop("wrk02")

# COMMAND ----------

# MAGIC %md
# MAGIC # Management Category of Product

# COMMAND ----------

# Upload Manual Table for category of Parts
# On AS side, Mrp Controller gives information about Product category related to MRP Controller
# On IS side no rules clearly defined yet, so Categorization is set to OTHERS
df_cat = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.manual_input.mrp_controller_category"
).select("plant", "mrp_controller", "category")
df_cat = df_cat.withColumnRenamed("plant", "plant_").withColumnRenamed(
    "mrp_controller", "mrp_controller_"
)

# COMMAND ----------

df_join_material = (
    df_material_branch.alias("A")
    .join(
        df_cat.alias("B"),
        (f.col("A.plant") == f.col("B.plant_"))
        & (f.col("A.mrp_controller") == f.col("B.mrp_controller_")),
        "left",
    )
    .drop("mrp_controller_", "plant_")
)

# COMMAND ----------

df_join_material = df_join_material.withColumn(
    "category", f.coalesce(f.col("category"), f.lit("Tbd"))
)
# Management of Entries not found in manual table
# IS Management also we take Production site to determine category
df_join_material = df_join_material.withColumn(
    "category",
    f.when(
        f.col("mrp_controller").isNull(),
        f.concat(f.substring(f.col("production_site"), 1, 3), f.lit("-Others")),
    )
    .when(
        (f.col("branch") == "IS") & (~f.col("plant").startswith("1")),
        f.concat(f.substring(f.col("production_site"), 6, 6), f.lit("-Others")),
    )
    .when(
        (f.col("branch") == "IS") & (f.col("plant").startswith("1")),
        f.concat(f.substring(f.col("production_site"), 1, 3), f.lit("-Others")),
    )
    .otherwise(f.col("category")),
)
df_material_end = df_join_material.dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC # Checking primary key for this dataset
# MAGIC ( inherited form silver dataset)
# MAGIC pk is concatenation of material and plant

# COMMAND ----------

# MAGIC %md
# MAGIC ## reordering columns to get  pk as first  col

# COMMAND ----------

# Reordoring columns to get primary_key as firsdt  columns
columns = df_material_end.columns
columns.remove("material_plant")
new_column_order = ["material_plant"] + columns
df_material_end = df_material_end.select(new_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Checking Pk has non null values

# COMMAND ----------

startTime = time.time()
df_to_check = df_material_end
col_to_check = "material_plant"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

quality_check_results = [df_gx.expect_column_values_to_not_be_null(column=col_to_check)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"No null values found in {col_to_check}",
    error_message=f"Null values found in {col_to_check}, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="material_plant_v2_gold",
    log_to_event_table=True,
    log_successes=True,
)

duration = time.time() - startTime
log.info(f"Check pk has no null done in {duration} seconds.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Checking PK is unique

# COMMAND ----------

startTime = time.time()
df_to_check = df_material_end
col_pk = "material_plant"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

quality_check_results = [df_gx.expect_column_values_to_be_unique(column=col_pk)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique",
    error_message=f"{col_pk}(s) are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="material_plant_v2_gold",
    log_to_event_table=True,
    log_successes=True,
)

duration = time.time() - startTime
log.info(f"Check pk is unique  done in {duration} seconds.")

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_gold"
SCHEMA = "master_data"
DESTINATION_TABLE = "material_plant"
FULL_SCHEMA = f"{CATALOG}.{SCHEMA}"
DESTINATION_TABLE_FULL_PATH = f"{FULL_SCHEMA}.{DESTINATION_TABLE}"

spark.sql(f"CREATE DATABASE IF NOT EXISTS {FULL_SCHEMA}")

# COMMAND ----------

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_material_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_material_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Add primary key in Databrick for Gold table

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "gold_material_plant_pk"
TABLE_PK_COLS = "material_plant"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Gold exposed table

# COMMAND ----------

CATALOG = "gold"
DOMAIN = "master_data"
DESTINATION_TABLE = "material_plant"
src_full_table_name = f"{PIPELINE_WRITE_ENV}_{CATALOG}.{DOMAIN}.{DESTINATION_TABLE}"
dest_full_tablename = f"{src_full_table_name}_exposed"
Begin_By = "MARC"
Begin_By2 = "MBEW"
selected_columns = [
    col
    for col in df_material_end.columns
    if not col.startswith(Begin_By) and not col.startswith(Begin_By2)
]
# renaming all colums to be  in snake case
lowercase_selected_columns = [s.lower() for s in selected_columns]

select_statement = ", ".join(lowercase_selected_columns)

# COMMAND ----------

table_utils.create_table_view(
    src_full_table_name, dest_full_tablename, select_statement, replace_view=True
)
