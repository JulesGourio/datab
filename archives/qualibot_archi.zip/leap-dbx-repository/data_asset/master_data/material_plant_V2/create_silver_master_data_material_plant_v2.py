# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook create_silver_master_data_material_plant_v2
# MAGIC #  Purpose
# MAGIC
# MAGIC  **Description:**
# MAGIC  The aim is to create a silver table for Material Master Data by plant and Domain Prices
# MAGIC  This Table will contain all Parameters linked with plant details (MRP, Procurement,...)
# MAGIC  This Version 2 isa refacto previous one done during Palantir migration
# MAGIC
# MAGIC  **Output table(s):**
# MAGIC    - {PIPELINE_WRITE_ENV}_silver.master_data.material_plant
# MAGIC
# MAGIC  **Input :**
# MAGIC    - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.marc_latest
# MAGIC    - {REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mbew_latest
# MAGIC
# MAGIC  **Triggered by:**
# MAGIC   - SAP Bronze Ingestion
# MAGIC
# MAGIC  **Things performed in this NoteBook**
# MAGIC
# MAGIC  - Join Plant Material with prices by Domain
# MAGIC  - Renaming Headers
# MAGIC  - Cleaning raw data

# COMMAND ----------

# MAGIC %md
# MAGIC # Change Log
# MAGIC  30 Apr 2025:
# MAGIC  - Notebook creation by Claire Arnoud
# MAGIC  - Removing local function to use the ones from table_utils when they exists
# MAGIC  - Grouping all fitering at same place
# MAGIC  - Creation of new headers_sap_business files to respect [leap data assets rules and philosophy](http://confluence.lat.corp:8090/pages/viewpage.action?pageId=46273406)
# MAGIC - Adding Primary key to silver dataset ans setting pk as first column in dataset
# MAGIC
# MAGIC 27 May 2025
# MAGIC
# MAGIC changing concatenation character  to -

# COMMAND ----------

# MAGIC %md
# MAGIC # Packages load

# COMMAND ----------

import time
import logging
from pyspark.sql import functions as f
from pyspark.sql import DataFrame

# leap table utils
from leap_utils.data_asset import table_utils

# leap logger
from leap_utils.common.logger import LOGGER_MAPPING, get_logger, setup_applevel_logger

# functions for data quality check for pk and table creation
from great_expectations.dataset import SparkDFDataset
from leap_utils.common.validation import gx_validation
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# MAGIC %md
# MAGIC # Widget setup

# COMMAND ----------

dbutils.widgets.removeAll()
# Get read environment variable
dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

# Get write environment variable
dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("bypass_quality_checks", "false")  # history/update
BYPASS_QUALITY_CHECKS = dbutils.widgets.get("bypass_quality_checks").lower() == "true"

# COMMAND ----------

# MAGIC %md
# MAGIC #Log_level setup
# MAGIC log_level -> log level "info" by default, or "debug"

# COMMAND ----------

# Set log level (for debugging)
dbutils.widgets.text("log_level", "info")
LOG_LEVEL = LOGGER_MAPPING[dbutils.widgets.get("log_level")]
log = get_logger(module_name=__name__)
setup_applevel_logger(log_level=LOG_LEVEL, file_log_level=logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC  #Functions
# MAGIC -

# COMMAND ----------


# Delete rows when field is null
def delete_null_rows(df_names: DataFrame) -> DataFrame:
    """Delete rows where the field is null"""
    df_names_new = df_names.filter(f.col("Field").isNotNull() == True)
    return df_names_new


# COMMAND ----------

# MAGIC %md
# MAGIC # Upload Table and adding prefix to SAP table
# MAGIC
# MAGIC

# COMMAND ----------

# Upload MARC <- Master Data material by Plant from SAP
df_marc = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.marc_latest"
)
df_marc = table_utils.add_prefix_to_columns(df_marc, "MARC")  # <- Renaming // MARC_XXXX

# Upload MBEW <- Price Master Data material by Plant from SAP
df_mbew = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.sap_latecoere_ecc6.mbew_latest"
)
df_mbew = table_utils.add_prefix_to_columns(df_mbew, "MBEW")  # <- Renaming // MBEW_XXXX

# COMMAND ----------

# MAGIC %md
# MAGIC # Filtering MARC

# COMMAND ----------

# Keeping material for mandt 600
df_marc = df_marc.filter(f.col("MARC_mandt") == "600")
# Exclusion Temporary of SPLIT management
#  Refacto:  kept as it is  but  to be  confirmed ????????

df_marc = df_marc.filter(f.col("MARC_matnr") != "SPLIT")
# Exclusion Plant 1500 created by mistake
df_marc = df_marc.filter(f.col("MARC_werks") != "1500")
# Exclusion Material cancelled
df_marc = df_marc.filter(f.col("MARC_lvorm").isNull())

# COMMAND ----------

# MAGIC %md
# MAGIC # Filtering MBEW

# COMMAND ----------

# keeping MBEW data for mandant =600
df_mbew = df_mbew.filter(f.col("MBEW_mandt") == "600")
# Exclusion Valorisation Test
df_mbew = df_mbew.filter(f.col("MBEW_bwtar").isNull())

# COMMAND ----------

# MAGIC %md
# MAGIC # Join Material Plant with MBEW Material Valuation

# COMMAND ----------

df_material = (
    df_marc.alias("A")
    .join(
        df_mbew.alias("B"),
        (f.col("A.MARC_matnr") == f.col("B.MBEW_matnr"))
        & (f.col("A.MARC_werks") == f.col("B.MBEW_bwkey")),
        "left",
    )
    .drop("MBEW_matnr", "MBEW_bwkey")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Reading Header files

# COMMAND ----------

# -----------------------------------------------------------------------------------
## Renaming MARC - Material plant from SAP
df_name_marc = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_marc_v2"
)
# Call function Check Header files
table_utils.check_schema_of_the_header_file(df_name_marc)
# Call Function Delete rows null
df_name_marc = delete_null_rows(df_name_marc)
# -----------------------------------------------------------------------------------
## Renaming MBEW - Price Material from SAP
df_name_mbew = spark.read.table(
    f"{REFERENCE_READ_ENV}_bronze.headers_sap.headers_sap_business_mbew_v2"
)
# Call function Check Header files
table_utils.check_schema_of_the_header_file(df_name_mbew)
# Call Function Delete rows null
df_name_mbew = delete_null_rows(df_name_mbew)

# Union Marc-MBEW
df_names_all = df_name_marc.unionByName(df_name_mbew)

# Call Function Rename Columns according header file
df_column_names = table_utils.rename_columns_with_sap_business_header(
    df_material, df_names_all
)
# Call Funtion Create Columns on Date format
df_material_renamed = table_utils.cast_columns_with_sap_business_headers(
    df_column_names, df_names_all
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Cleasing raw data from material data asset
# MAGIC for profit center et material
# MAGIC

# COMMAND ----------

# Delete leading zeros on Material_Number
df_material_end = table_utils.remove_leading_zeros(
    df_material_renamed, ["material_number", "profit_center"]
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Creating primary key for this dataset
# MAGIC pk is concatenation of  material and plant

# COMMAND ----------

df_material_end = df_material_end.withColumn(
    "material_plant", f.concat(f.col("material_number"), f.lit("-"), f.col("plant"))
)

# COMMAND ----------

columns = df_material_end.columns
columns.remove("material_plant")
new_column_order = ["material_plant"] + columns
df_material_end = df_material_end.select(new_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check if pk contains nulls

# COMMAND ----------

df_to_check = df_material_end
col_to_check = "material_plant"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

quality_check_results = [df_gx.expect_column_values_to_not_be_null(column=col_to_check)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"No null values found in {col_to_check}",
    error_message=f"Null values found in {col_to_check}, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="material_plant_v2_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###  Check if pk is unique

# COMMAND ----------

df_to_check = df_material_end
col_pk = "material_plant"
validation_level = "RED"
if BYPASS_QUALITY_CHECKS:
    validation_level = "AMBER"

df_gx = SparkDFDataset(df_to_check, persist=False)

quality_check_results = [df_gx.expect_column_values_to_be_unique(column=col_pk)]

gx_validation.validate_and_log_gx_results(
    quality_check_results=quality_check_results,
    validation_level=validation_level,
    info_message=f"All {col_pk}(s) are unique",
    error_message=f"{col_pk}(s) are not unique, check the summary of this run",
    pipeline_write_env=PIPELINE_WRITE_ENV,
    table_name="material_plant_v2_silver",
    log_to_event_table=True,
    log_successes=True,
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save Silver table

# COMMAND ----------

CATALOG = f"{PIPELINE_WRITE_ENV}_silver"
SCHEMA = "master_data"
DESTINATION_TABLE = "material_plant"
DESTINATION_TABLE_FULL_PATH = f"{CATALOG}.{SCHEMA}.{DESTINATION_TABLE}"

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG}.{SCHEMA}")

try:
    startTime = time.time()
    result = table_utils.save_table(
        dest_table=DESTINATION_TABLE_FULL_PATH,
        df=df_material_end,
        mode="overwrite",
        overwrite_schema=True,
    )
except AnalysisException as e:
    log.error(
        f"Table {DESTINATION_TABLE_FULL_PATH} has not been created, an error occured during saveAsTable. \nError is {e}"
    )
    raise Exception()
else:
    duration = time.time() - startTime
    log.info(f"Table {DESTINATION_TABLE_FULL_PATH} saved in {duration} seconds.")
    log.info(f"Wrote {df_material_end.count()} rows.")
    if result is not None:
        result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Adding constraint primary key in DBX

# COMMAND ----------

# Add Primary Key if not exists
TABLE_CONSTRAINT_NAME = "silver_material_plant_pk"
TABLE_PK_COLS = "material_plant"

nb_cons = spark.sql(
    f"select count(*) from system.information_SCHEMA.table_constraints where table_CATALOG='{CATALOG}' and table_SCHEMA='{SCHEMA}' and table_name='{DESTINATION_TABLE}' and constraint_name='{TABLE_CONSTRAINT_NAME}' "
).first()[0]

if nb_cons == 0:
    # Before adding Primary Key, need to set columns NOT NULL
    table_dest_pk_cols_list = TABLE_PK_COLS.split(",")
    for col in table_dest_pk_cols_list:
        table_utils.set_table_column_not_null(
            table_path=DESTINATION_TABLE_FULL_PATH, column=col.strip()
        )

    # Add primary key
    table_utils.add_table_primary_key(
        table_path=DESTINATION_TABLE_FULL_PATH,
        pk_name=TABLE_CONSTRAINT_NAME,
        columns=TABLE_PK_COLS,
    )
