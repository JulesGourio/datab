# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Purpose
# MAGIC
# MAGIC **Description:**  
# MAGIC The aim is to create a gold table for Material Master Data History by plant Prices  
# MAGIC
# MAGIC **Input :**
# MAGIC   - {REFERENCE_READ_ENV}_silver.master_data.material_plant_price_history
# MAGIC   - {REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed
# MAGIC   - {REFERENCE_READ_ENV}_gold.finance.currency_exchange
# MAGIC
# MAGIC **Output table(s):**
# MAGIC   - {PIPELINE_WRITE_ENV}_gold.master_data.material_plant_price_history

# COMMAND ----------

# MAGIC %md
# MAGIC # Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Standard Imports

# COMMAND ----------

from pyspark.sql import functions as f
from leap_utils.data_asset import table_utils
from leap_utils.data_asset import amount_correction

# COMMAND ----------

# MAGIC %md
# MAGIC ## Config Widgets

# COMMAND ----------

dbutils.widgets.text("pipeline_write_env", "dev")
PIPELINE_WRITE_ENV = dbutils.widgets.get("pipeline_write_env")

dbutils.widgets.text("pipeline_read_env", "dev")
PIPELINE_READ_ENV = dbutils.widgets.get("pipeline_read_env")

dbutils.widgets.text("reference_read_env", "prod")
REFERENCE_READ_ENV = dbutils.widgets.get("reference_read_env")

# COMMAND ----------

# MAGIC %md
# MAGIC # Inputs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inputs - LEAP tables
# MAGIC - **df_material_price_raw** is the silver material price table
# MAGIC - **df_plant_raw** is the plant master data table
# MAGIC - **df_currency_raw** is the gold currency table
# MAGIC

# COMMAND ----------

df_material_price_raw = spark.read.table(
    f"{PIPELINE_READ_ENV}_silver.master_data.material_plant_price_history"
)

# COMMAND ----------

df_plant_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.master_data.plant_master_data_latest_exposed"
)

# COMMAND ----------

# Upload Gold Currency to convert all prices in EUR
df_currency_raw = spark.read.table(
    f"{REFERENCE_READ_ENV}_gold.finance.currency_exchange"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Data preparation

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Prep 1 - Selecting & renaming columns

# COMMAND ----------

df_plant_prep = df_plant_raw.select(
    "plant", "currency", "plant_description_new", "company", "company_description"
).withColumnRenamed("plant_description_new", "production_site")

# COMMAND ----------

# MAGIC %md
# MAGIC #Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ##Tr1 - Join silver material price table with plant master data table

# COMMAND ----------

df_material_price_end = (
    df_material_price_raw
    .join(
        df_plant_prep,
        "plant",
        "left",
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr2 - Management of Wrong SAP decimal for spécific currency (TND, JPY,...)

# COMMAND ----------

df_material_price_end = df_material_price_end.withColumn(
    "budget_price", f.coalesce(f.col("budget_price"), f.lit(0))
)

# Use Fonction to correct wrong amount coming from SAP
df_material_price_end = amount_correction.create_corrected_amounts(
    df_material_price_end, "average_price", "currency"
)
df_material_price_end = amount_correction.create_corrected_amounts(
    df_material_price_end, "standard_price", "currency"
)
df_material_price_end = amount_correction.create_corrected_amounts(
    df_material_price_end, "budget_price", "currency"
)

df_material_price_end = df_material_price_end.drop(
    "average_price", "standard_price", "budget_price"
).withColumnsRenamed(
    {
        "average_price_corrected": "average_price",
        "standard_price_corrected": "standard_price",
        "budget_price_corrected": "budget_price",
    }
)

df_material_price_end = df_material_price_end.withColumn(
    "currency_date", f.date_sub(f.current_date(), 1)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tr3 - Convert all in EUR on Budget & Spot Price

# COMMAND ----------

df_material_price_end = df_material_price_end.withColumn(
    "standard_price", f.col("standard_price") / f.col("price_base")
).withColumn(
    "average_price", f.col("average_price") / f.col("price_base")
).withColumn(
    "budget_price", f.col("budget_price") / f.col("price_base")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr3.1 - Add currency_date column

# COMMAND ----------

df_material_price_end = df_material_price_end.withColumn(
    "currency_date",
    f.to_date(
        f.concat(
            f.col("fiscal_year").cast("int"),
            f.lpad(f.col("current_period").cast("int").cast("string"), 2, "0"),
            f.lit("01")
        ),
        "yyyyMMdd"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr3.2 - Convert price using currency_conversion function from leap_utils

# COMMAND ----------

df_material_price_end = table_utils.currency_conversion(
    df=df_material_price_end,
    document_currency_column=f.col("currency"),
    rate_types=["Budget", "Spot"],
    rate_dates=[f.col("currency_date")],
    target_currency_value="EUR",
    document_amounts=[
        f.col(col) for col in ["average_price", "standard_price", "budget_price"]
    ],
    df_currency=df_currency_raw,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tr3.3 - Renaming columns

# COMMAND ----------

df_material_price_end = (
    df_material_price_end
    .withColumnRenamed("standard_price", "standard_price_company_currency")
    .withColumnRenamed("average_price", "average_price_company_currency")
    .withColumnRenamed("budget_price", "budget_price_company_currency")
    .withColumnRenamed("standard_price_from_currency_to_EUR_in_Budget_rate_at_currency_date", "standard_price_EUR_budget")
    .withColumnRenamed("average_price_from_currency_to_EUR_in_Budget_rate_at_currency_date", "average_price_EUR_Budget")
    .withColumnRenamed("budget_price_from_currency_to_EUR_in_Budget_rate_at_currency_date", "budget_price_EUR_Budget")
    .withColumnRenamed("standard_price_from_currency_to_EUR_in_Spot_rate_at_currency_date", "standard_price_EUR_spot")
    .withColumnRenamed("average_price_from_currency_to_EUR_in_Spot_rate_at_currency_date", "average_price_EUR_Spot")
    .withColumnRenamed("budget_price_from_currency_to_EUR_in_Spot_rate_at_currency_date", "budget_price_EUR_Spot")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Output

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save Gold table

# COMMAND ----------

table_utils.save_table(
    dest_table=f"{PIPELINE_WRITE_ENV}_gold.master_data.material_plant_price_history",
    df=df_material_price_end,
    mode="overwrite",
    overwrite_schema=True
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save Gold exposed table

# COMMAND ----------

Begin_By = "MBEW"
Begin_By2 = "MBEWH"
selected_columns = [
    col
    for col in df_material_price_end.columns
    if not col.startswith(Begin_By) and not col.startswith(Begin_By2)
]
select_statement = ", ".join(selected_columns)

table_utils.create_table_view(
    f"{PIPELINE_WRITE_ENV}_gold.master_data.material_plant_price_history",
    f"{PIPELINE_WRITE_ENV}_gold.master_data.material_plant_price_history_exposed",
    select_statement,
    replace_view=True,
)
